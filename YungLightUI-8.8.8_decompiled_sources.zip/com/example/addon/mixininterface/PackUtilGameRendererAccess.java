/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixininterface;

public interface PackUtilGameRendererAccess {
    public void packutil$flushGuiState();
}
