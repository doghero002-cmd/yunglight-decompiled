/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilMacro;

public static class PackUtilLANSync.SyncContext {
    public final long executionId;
    public final boolean isMacro;
    public final String macroName;
    public final String command;
    public final PackUtilMacro macro;
    public final boolean isInitiator;

    public PackUtilLANSync.SyncContext(long executionId, boolean isMacro, String macroName, String command, PackUtilMacro macro, boolean isInitiator) {
        this.executionId = executionId;
        this.isMacro = isMacro;
        this.macroName = macroName;
        this.command = command;
        this.macro = macro;
        this.isInitiator = isInitiator;
    }
}
