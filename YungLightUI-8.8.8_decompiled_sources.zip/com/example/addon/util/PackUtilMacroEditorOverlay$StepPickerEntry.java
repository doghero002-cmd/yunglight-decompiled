/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final class PackUtilMacroEditorOverlay.StepPickerEntry {
    private final String categoryId;
    private final String label;
    private final String description;
    private final Runnable action;

    private PackUtilMacroEditorOverlay.StepPickerEntry(String categoryId, String label, String description, Runnable action) {
        this.categoryId = categoryId;
        this.label = label;
        this.description = description;
        this.action = action;
    }
}
