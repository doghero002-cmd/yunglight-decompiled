/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketInspector;
import java.util.Collections;
import java.util.List;

public static final class PackUtilPacketInspector.PacketInspection {
    private final String title;
    private final List<PackUtilPacketInspector.InspectionLine> lines;
    private final String copyText;

    private PackUtilPacketInspector.PacketInspection(String title, List<PackUtilPacketInspector.InspectionLine> lines, String copyText) {
        this.title = title;
        this.lines = Collections.unmodifiableList(lines);
        this.copyText = copyText;
    }

    public String getTitle() {
        return this.title;
    }

    public List<PackUtilPacketInspector.InspectionLine> getLines() {
        return this.lines;
    }

    public String getCopyText() {
        return this.copyText;
    }
}
