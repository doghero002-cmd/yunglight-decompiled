/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final record PackUtilPacketLoggerOverlay.LogCaptureContext {
    private final String blockStateSummary;
    private final String screenSummary;
    private static final PackUtilPacketLoggerOverlay.LogCaptureContext EMPTY = new PackUtilPacketLoggerOverlay.LogCaptureContext(null, null);

    private PackUtilPacketLoggerOverlay.LogCaptureContext(String blockStateSummary, String screenSummary) {
        this.blockStateSummary = blockStateSummary;
        this.screenSummary = screenSummary;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String blockStateSummary() {
        return this.blockStateSummary;
    }

    public String screenSummary() {
        return this.screenSummary;
    }
}
