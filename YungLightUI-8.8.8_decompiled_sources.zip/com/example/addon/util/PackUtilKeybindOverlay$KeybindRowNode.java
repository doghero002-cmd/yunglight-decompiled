/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiCompactRow;
import com.example.addon.gui.packui.PackUiFormRow;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiLabel;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.PackUtilKeybindOverlay;

private final class PackUtilKeybindOverlay.KeybindRowNode
extends PackUiFormRow {
    private final int index;
    private final PackUtilKeybindOverlay.KeybindEntry entry;
    private final PackUiLabel labelNode;
    private final PackUiCompactRow controlRow;
    private final PackUiButton bindButton;
    private final PackUiButton clearButton;

    private PackUtilKeybindOverlay.KeybindRowNode(int index, PackUtilKeybindOverlay.KeybindEntry entry) {
        super(new PackUiLabel(entry.label, PackUiTone.BODY).setTrimToBounds(true), new PackUiCompactRow());
        this.index = index;
        this.entry = entry;
        this.height = 18f;
        this.growX = true;
        this.labelNode = (PackUiLabel)this.labelNode();
        this.controlRow = (PackUiCompactRow)this.controlNode();
        this.bindButton = (PackUiButton)this.controlRow.add(new PackUiButton("NONE", PackUiButton.Variant.SECONDARY, this::toggleCapture).setPreferredWidth((float)packUtilKeybindOverlay.bindButtonWidth()).setMinWidth((float)packUtilKeybindOverlay.bindButtonWidth()).setMaxWidth((float)packUtilKeybindOverlay.bindButtonWidth()).setHorizontalPadding(packUtilKeybindOverlay.bindButtonPadding()).setButtonHeight(packUtilKeybindOverlay.chooserButtonHeight()).setTextYOffset(0));
        this.clearButton = (PackUiButton)this.controlRow.add(new PackUiButton("X", PackUiButton.Variant.DANGER, this::clearBind).setPreferredWidth((float)packUtilKeybindOverlay.clearButtonWidth()).setMinWidth((float)packUtilKeybindOverlay.clearButtonWidth()).setMaxWidth((float)packUtilKeybindOverlay.clearButtonWidth()).setHorizontalPadding(0).setButtonHeight(packUtilKeybindOverlay.chooserButtonHeight()).setTextYOffset(0));
        this.controlRow.setGap(packUtilKeybindOverlay.buttonGap()).setPadding(PackUiInsets.NONE).setUnderlineOnHover(false);
        this.setLabelWidth((float)packUtilKeybindOverlay.computeLabelColumnWidth());
        this.setGap(packUtilKeybindOverlay.rowLabelGap());
        this.setAlignControlEnd(true);
        this.setPadding(PackUiInsets.NONE);
    }

    public float preferredWidth(PackUiRenderContext context) {
        return (float)(PackUtilKeybindOverlay.this.panelWidth - PackUtilKeybindOverlay.this.panelPadding() * 2);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return (float)PackUtilKeybindOverlay.this.rowHeight();
    }

    public void render(PackUiRenderContext context) {
        this.bindButton.setText(PackUtilKeybindOverlay.this.bindButtonText(this.index, this.entry));
        this.bindButton.setVariant(PackUtilKeybindOverlay.this.capturingIndex == this.index ? PackUiButton.Variant.PRIMARY : this.entry.getter.getAsInt() == -1 ? PackUiButton.Variant.GHOST : PackUiButton.Variant.SECONDARY);
        this.labelNode.setTone(PackUiTone.BODY);
        super.render(context);
        if (this.labelNode.contains(context.mouseX(), context.mouseY())) {
            PackUtilKeybindOverlay.this.hoveredTooltip = this.entry.tooltip;
            PackUtilKeybindOverlay.this.tooltipUiX = context.mouseX() + (float)PackUtilKeybindOverlay.this.tooltipOffsetX();
            PackUtilKeybindOverlay.this.tooltipUiY = context.mouseY() - (float)PackUtilKeybindOverlay.this.tooltipOffsetY();
        }
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        return super.mouseClicked(context, mouseX, mouseY, button);
    }

    private void toggleCapture() {
        PackUtilKeybindOverlay.this.capturingIndex = PackUtilKeybindOverlay.this.capturingIndex == this.index ? -1 : this.index;
    }

    private void clearBind() {
        this.entry.setter.accept(-1);
        PackUtilKeybindOverlay.this.getConfig().save();
        if (PackUtilKeybindOverlay.this.capturingIndex == this.index) {
            PackUtilKeybindOverlay.this.capturingIndex = -1;
        }
    }
}
