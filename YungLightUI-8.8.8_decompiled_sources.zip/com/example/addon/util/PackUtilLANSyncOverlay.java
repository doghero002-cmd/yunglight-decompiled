/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiControlGlyphs;
import com.example.addon.gui.packui.PackUiLegacyLayout;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiScrollList;
import com.example.addon.gui.packui.PackUiScrollViewport;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilChatField;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroManager;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilText;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroExecutor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilLANSyncOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final PackUiTheme PACKUI_THEME = new PackUiTheme();
    private static PackUtilLANSyncOverlay sharedOverlay;
    private static final int CONTENT_SCROLLBAR_WIDTH = 4;
    private static final int CONTENT_SCROLLBAR_GUTTER = 12;
    private static final int SAME_MACRO_LIST_MAX_VISIBLE_ROWS = 6;
    private static final int SAME_MACRO_LIST_SCROLLBAR_WIDTH = 3;
    private int PANEL_BASE_WIDTH = 292;
    private int panelX = 500;
    private int panelY = 5;
    private int PANEL_WIDTH = this.PANEL_BASE_WIDTH;
    private int PANEL_HEIGHT = 220;
    private static final int HEADER_HEIGHT = 16;
    private int TAB_HEIGHT = 16;
    private int BUTTON_HEIGHT = 16;
    private int ROW_HEIGHT = 14;
    private int CONTENT_PADDING = 8;
    private int CHAT_FIELD_HEIGHT = 16;
    private int CHAT_AREA_HEIGHT = this.CHAT_FIELD_HEIGHT + 10;
    private boolean isDragging = false;
    private boolean isResizing = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    private double resizeStartMouseX = 0;
    private double resizeStartMouseY = 0;
    private int resizeStartWidth = 0;
    private int resizeStartHeight = 0;
    private boolean collapsed = false;
    private boolean visible = false;
    private final class_327 textRenderer;
    private static final String[] TAB_NAMES;
    private int activeTab = 0;
    private int scrollOffset = 0;
    private int maxScroll = 0;
    private int renderScrollOffset = 0;
    private boolean scrollbarDragging = false;
    private int scrollbarGrabOffset = 0;
    private final PackUiSmoothScroll contentScrollState = new PackUiSmoothScroll();
    private PackUiScrollList<PackUtilMacro> sameMacroList = null;
    private int sameMacroListX = 0;
    private int sameMacroListY = 0;
    private int sameMacroListWidth = 0;
    private int sameMacroListHeight = 0;
    private PackUiScrollViewport perUserListViewport = null;
    private int perUserListX = 0;
    private int perUserListY = 0;
    private int perUserListWidth = 0;
    private int perUserListHeight = 0;
    private int tickCounter = 0;
    private static final int REFRESH_INTERVAL = 10;
    private String selectedMacroName = null;
    private boolean perUserMode = false;
    private final Map<String, String> perUserAssignments = new LinkedHashMap();
    private String expandedExecutePeer = null;
    private String selectedPeer = null;
    private final List<PackUtilLANSyncOverlay.ClickRegion> clickRegions = new ArrayList();
    private PackUtilChatField lanChatField;

    public PackUtilLANSyncOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.applyPresetMetrics();
        this.PANEL_WIDTH = this.PANEL_BASE_WIDTH;
        this.PANEL_HEIGHT = this.defaultPanelHeight();
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        sync.setOnClientJoined(PackUtilLANSyncOverlay::lambda$new$0);
        sync.setOnClientLeft(PackUtilLANSyncOverlay::lambda$new$1);
        sync.setOnSyncStateChanged(PackUtilLANSyncOverlay::lambda$new$2);
        sync.setOnSpreadCalculated(PackUtilLANSyncOverlay::lambda$new$3);
        sync.setOnPeerStatusChanged(PackUtilLANSyncOverlay::lambda$new$4);
    }

    public static synchronized PackUtilLANSyncOverlay getSharedOverlay(class_327 textRenderer) {
        if (sharedOverlay == null) {
            sharedOverlay = new PackUtilLANSyncOverlay(textRenderer);
            sharedOverlay.restoreState();
        }
        return sharedOverlay;
    }

    public int getMinWidth() {
        return this.PANEL_BASE_WIDTH;
    }

    public int getMinHeight() {
        return this.minimumPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = this.PANEL_BASE_WIDTH;
        this.PANEL_HEIGHT = Math.max(this.getMinHeight(), clamped.height);
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visible) {
            PackUtilLANSync sync = PackUtilLANSync.getInstance();
            PackUtilModule module = PackUtilModule.get();
            if (module.isActive()) {
                if (module.isLANSyncEnabled()) {
                    if (!sync.isRunning()) {
                        sync.start();
                    }
                }
            }
            PackUtilOverlayManager.get().bringToFront(this);
        } else {
            if (this.lanChatField != null) {
                this.lanChatField.setFocused(false);
            }
        }
        this.saveState();
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.saveState();
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean hasTextFieldFocused() {
        return this.lanChatField != null && this.lanChatField.isFocused();
    }

    public void clearTextFieldFocus() {
        if (this.lanChatField != null) {
            if (this.lanChatField.isFocused()) {
                this.lanChatField.setFocused(false);
            }
        }
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        int h = this.collapsed ? 16 : this.getPanelHeight();
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + h);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + 16) && !this.isOverWindowControl(mouseX, mouseY, bounds);
    }

    private int getPanelHeight() {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        if (!sync.isRunning()) {
            return 56;
        }
        if (!sync.isInSession()) {
            if (sync.isSearching()) {
                return 76;
            }
            return 86;
        }
        int contentH = this.estimateTabContentHeight(sync);
        int total = 16 + this.TAB_HEIGHT + 2 + contentH + this.CHAT_AREA_HEIGHT + 8;
        return Math.max(140, Math.min(total, 500));
    }

    private int estimateTabContentHeight(PackUtilLANSync sync) {
        switch (this.activeTab) {
            case 0::
                int h = 70;
                if (sync.getLastSpreadResult() != null) {
                    h += 12;
                }
                if (!sync.getSpreadHistory().isEmpty()) {
                    h += 14;
                }
                h = h + (4 + this.BUTTON_HEIGHT + 4);
                return h;
            case 1::
                peerCount = sync.getConnectedCount();
                int h = 4 + peerCount * (this.ROW_HEIGHT + 1);
                if (this.selectedPeer != null) {
                    h += 64;
                }
                return Math.max(h + 4, 60);
            case 2::
                h = 4 + this.BUTTON_HEIGHT + 6;
                if (this.perUserMode) {
                    listContentHeight = this.estimatePerUserListContentHeight(sync);
                    h = h + (14 + this.cappedListViewportHeight(listContentHeight));
                    h = h + (18 + this.BUTTON_HEIGHT + 6);
                } else {
                    macros = PackUtilMacroManager.get().getAll().size();
                    h = h + (14 + (macros == 0 ? 12 : this.macroListViewportHeight(macros)) + 8);
                    if (this.selectedMacroName != null) {
                        h += 48;
                    }
                    h = h + (this.BUTTON_HEIGHT + 6);
                }
                if (MacroExecutor.isRunning()) {
                    h = h + (this.BUTTON_HEIGHT + 6);
                }
                h += 35;
                return h;
            case 3::
                return 44 + this.BUTTON_HEIGHT + 8 + this.BUTTON_HEIGHT + 4;
            default:
                return 120;
        }
    }

    public void saveState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setLanSyncOverlayVisible(this.visible);
        shared.setLanSyncOverlayX(this.panelX);
        shared.setLanSyncOverlayY(this.panelY);
        shared.setLanSyncOverlayActiveTab(this.activeTab);
        shared.setLanSyncOverlayScrollOffset(this.scrollOffset);
        shared.setLanSyncOverlayPerUserMode(this.perUserMode);
        shared.setLanSyncOverlaySelectedMacroName(this.selectedMacroName);
        shared.setLanSyncOverlayExpandedExecutePeer(this.expandedExecutePeer);
        shared.setLanSyncOverlaySelectedPeer(this.selectedPeer);
        this.saveLayout();
    }

    public void restoreState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.restoreLayout();
        this.visible = shared.isLanSyncOverlayVisible();
        this.panelX = shared.getLanSyncOverlayX();
        this.panelY = shared.getLanSyncOverlayY();
        this.activeTab = Math.max(0, Math.min(TAB_NAMES.length - 1, shared.getLanSyncOverlayActiveTab()));
        this.scrollOffset = Math.max(0, shared.getLanSyncOverlayScrollOffset());
        this.contentScrollState.restore(this.scrollOffset);
        this.perUserMode = shared.isLanSyncOverlayPerUserMode();
        this.selectedMacroName = PackUtilLANSyncOverlay.emptyToNull(shared.getLanSyncOverlaySelectedMacroName());
        this.expandedExecutePeer = PackUtilLANSyncOverlay.emptyToNull(shared.getLanSyncOverlayExpandedExecutePeer());
        this.selectedPeer = PackUtilLANSyncOverlay.emptyToNull(shared.getLanSyncOverlaySelectedPeer());
        this.PANEL_WIDTH = this.PANEL_BASE_WIDTH;
    }

    private void clampScrollOffset() {
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScroll));
    }

    private PackUiScrollbar.Metrics getContentScrollbarMetrics(int contentY, int contentHeight) {
        int totalContentHeight = this.maxScroll + contentHeight;
        return PackUiScrollbar.compute(totalContentHeight, contentHeight, this.panelX + this.PANEL_WIDTH - 6, contentY, 4, contentHeight, this.contentScrollState.tick(0f, Math.max(0, totalContentHeight - contentHeight)));
    }

    private boolean hasScrollableSessionContent(PackUtilLANSync sync) {
        return sync.isRunning() && sync.isInSession() && !sync.isSearching();
    }

    private int getTabContentY() {
        return this.panelY + 16 + this.TAB_HEIGHT + 2;
    }

    private int getTabContentHeight(int panelHeight) {
        int chatTopY = this.panelY + panelHeight - this.CHAT_AREA_HEIGHT;
        return Math.max(40, chatTopY - 4 - this.getTabContentY());
    }

    private int getContentWidth() {
        return PackUiLegacyLayout.contentWidth(this.PANEL_WIDTH, this.CONTENT_PADDING);
    }

    private int getListWidth(boolean hasScroll) {
        return PackUiLegacyLayout.reserveScrollbar(this.getContentWidth(), hasScroll, 12);
    }

    private int sameMacroListRowPitch() {
        return this.ROW_HEIGHT + 1;
    }

    private int macroListViewportHeight(int macroCount) {
        int visibleRows = Math.max(1, Math.min(6, macroCount));
        return Math.max(this.sameMacroListRowPitch(), visibleRows * this.sameMacroListRowPitch());
    }

    private int macroListContentHeight(int macroCount) {
        if (macroCount <= 0) {
            return 0;
        }
        return macroCount * this.sameMacroListRowPitch();
    }

    private int cappedListViewportHeight(int contentHeight) {
        int maxVisibleRows = Math.max(1, 6);
        int maxHeight = maxVisibleRows * this.sameMacroListRowPitch();
        int clampedHeight = Math.max(this.sameMacroListRowPitch(), Math.min(contentHeight, maxHeight));
        return (clampedHeight + this.sameMacroListRowPitch() - 1) / this.sameMacroListRowPitch() * this.sameMacroListRowPitch();
    }

    private void clearSameMacroListViewport() {
        this.sameMacroList = null;
        this.sameMacroListX = 0;
        this.sameMacroListY = 0;
        this.sameMacroListWidth = 0;
        this.sameMacroListHeight = 0;
    }

    private boolean hasSameMacroListViewport() {
        return this.sameMacroList != null && this.sameMacroListWidth > 0 && this.sameMacroListHeight > 0;
    }

    private boolean isOverSameMacroList(double mouseX, double mouseY) {
        return this.hasSameMacroListViewport() && mouseX >= (double)this.sameMacroListX && mouseX < (double)(this.sameMacroListX + this.sameMacroListWidth) && mouseY >= (double)this.sameMacroListY && mouseY < (double)(this.sameMacroListY + this.sameMacroListHeight);
    }

    private void clearPerUserListViewport() {
        this.perUserListViewport = null;
        this.perUserListX = 0;
        this.perUserListY = 0;
        this.perUserListWidth = 0;
        this.perUserListHeight = 0;
    }

    private boolean hasPerUserListViewport() {
        return this.perUserListViewport != null && this.perUserListWidth > 0 && this.perUserListHeight > 0;
    }

    private boolean isOverPerUserList(double mouseX, double mouseY) {
        return this.hasPerUserListViewport() && mouseX >= (double)this.perUserListX && mouseX < (double)(this.perUserListX + this.perUserListWidth) && mouseY >= (double)this.perUserListY && mouseY < (double)(this.perUserListY + this.perUserListHeight);
    }

    private void syncPerUserAssignments(PackUtilLANSync sync) {
        Set<String> connectedPeers = sync.getConnectedClients().keySet();
        Map<String, String> synced = connectedPeers.iterator();
        while (synced.hasNext()) {
            String peer = (String)synced.next();
            this.perUserAssignments.putIfAbsent(peer, "");
        }
        this.perUserAssignments.keySet().retainAll(connectedPeers);
        synced = sync.getSyncedAssignments();
        peer = synced.entrySet().iterator();
        while (peer.hasNext()) {
            Map.Entry<String, String> se = (Map.Entry)peer.next();
            if (!connectedPeers.contains(se.getKey())) continue;
            this.perUserAssignments.put((String)se.getKey(), (String)se.getValue());
        }
    }

    private int estimatePerUserListContentHeight(PackUtilLANSync sync) {
        this.syncPerUserAssignments(sync);
        int contentHeight = 0;
        var var3 = new ArrayList(this.perUserAssignments.entrySet()).iterator();
        while (var3.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var3.next();
            String peer = (String)entry.getKey();
            contentHeight = contentHeight + this.sameMacroListRowPitch();
            if (!peer.equals(this.expandedExecutePeer)) continue;
            contentHeight = contentHeight + (this.estimateExpandedPeerPickerHeight(sync, peer) + 4);
        }
        return Math.max(this.sameMacroListRowPitch(), contentHeight);
    }

    private int estimateExpandedPeerPickerHeight(PackUtilLANSync sync, String peer) {
        int contentHeight = 0;
        List<PackUtilMacro> myMacroList = PackUtilMacroManager.get().getAll();
        Map<String, Integer> myMacroMap = new LinkedHashMap();
        Map<String, Map<String, PackUtilMacro>> allRemote = myMacroList.iterator();
        while (allRemote.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)allRemote.next();
            myMacroMap.put(macro.name, macro.actions != null ? macro.actions.size() : 0);
        }
        if (peer.equals(sync.getMyUsername())) {
            return myMacroList.size() * this.sameMacroListRowPitch();
        }
        allRemote = sync.getAllRemoteMacros();
        peerMacroData = (Map)allRemote.getOrDefault(peer, Collections.emptyMap());
        Map<String, Integer> peerMacroMap = new LinkedHashMap();
        List<String> shared = peerMacroData.entrySet().iterator();
        while (shared.hasNext()) {
            Map.Entry<String, PackUtilMacro> entry = (Map.Entry)shared.next();
            peerMacroMap.put((String)entry.getKey(), ((PackUtilMacro)entry.getValue()).actions != null ? ((PackUtilMacro)entry.getValue()).actions.size() : 0);
        }
        shared = new ArrayList();
        different = new LinkedHashMap();
        List<String> peerOnly = new ArrayList();
        List<String> mineOnly = new ArrayList();
        int rowPitch = peerMacroMap.keySet().iterator();
        while (rowPitch.hasNext()) {
            String name = (String)rowPitch.next();
            if (myMacroMap.containsKey(name)) {
                int diffs = PackUtilLANSyncOverlay.countActionDifferences(PackUtilMacroManager.get().get(name), (PackUtilMacro)peerMacroData.get(name));
                if (diffs == 0) {
                    shared.add(name);
                } else {
                    different.put(name, diffs);
                }
            } else {
                peerOnly.add(name);
            }
        }
        rowPitch = myMacroMap.keySet().iterator();
        while (rowPitch.hasNext()) {
            name = (String)rowPitch.next();
            if (peerMacroMap.containsKey(name)) continue;
            mineOnly.add(name);
        }
        rowPitch = this.sameMacroListRowPitch();
        if (!shared.isEmpty()) {
            contentHeight = contentHeight + shared.size() * rowPitch;
        }
        contentHeight = contentHeight + different.size() * rowPitch;
        if (!peerOnly.isEmpty()) {
            contentHeight = contentHeight + peerOnly.size() * rowPitch;
        }
        if (!mineOnly.isEmpty()) {
            contentHeight = contentHeight + mineOnly.size() * rowPitch;
        }
        if (shared.isEmpty()) {
            if (different.isEmpty()) {
                if (peerOnly.isEmpty()) {
                    if (mineOnly.isEmpty()) {
                        contentHeight = contentHeight + rowPitch;
                    }
                }
            }
        }
        return Math.max(rowPitch, contentHeight);
    }

    private void drawUiText(class_332 ctx, String text, PackUiTone tone, int color, int x, int y) {
        PackUiText.draw(ctx, this.textRenderer, text, PACKUI_THEME.fontFor(tone), color, x, y, false);
    }

    private void drawOverlayButton(class_332 ctx, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean enabled, int mx, int my) {
        this.drawOverlayButton(ctx, x, y, w, h, label, variant, enabled, PackUiTone.BODY, mx, my);
    }

    private void drawOverlayButton(class_332 ctx, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean enabled, PackUiTone tone, int mx, int my) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), PackUtilLANSyncOverlay::lambda$drawOverlayButton$5);
        button.setWidth(w);
        button.setVariant(variant);
        button.setTone(tone);
        button.active = enabled;
        PackUiOverlayButton.renderStyled(ctx, this.textRenderer, button, mx, my);
    }

    private static String emptyToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    public void render(class_332 ctx, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        PackUtilModule module = PackUtilModule.get();
        this.tickCounter = this.tickCounter + 1;
        if (this.tickCounter >= 10) {
            this.tickCounter = 0;
            if (!sync.isRunning()) {
                if (module.isActive()) {
                    if (module.isLANSyncEnabled()) {
                        sync.start();
                    }
                }
            }
        }
        this.clickRegions.clear();
        int panelHeight = this.getPanelHeight();
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, panelHeight, this.visible, this.collapsed);
        this.renderWindowFrame(ctx, mouseX, mouseY, bounds, "LAN Sync", this.collapsed, this.isDragging);
        boolean clipBody = this.beginWindowBodyClip(ctx, bounds, this.collapsed);
        if (!clipBody) {
            this.renderWindowInactiveOverlay(ctx, bounds, this.collapsed, this.isDragging);
            return;
        }
        try {
            this.ensureLanChatField(panelHeight);
            int contentY = this.panelY + 16;
            int chatTopY = this.panelY + panelHeight - this.CHAT_AREA_HEIGHT;
            if (!sync.isRunning()) {
                this.renderNotRunning(ctx, mouseX, mouseY, contentY);
            } else {
                if (!sync.isInSession()) {
                    if (!sync.isSearching()) {
                        this.renderNoSession(ctx, mouseX, mouseY, contentY);
                    }
                } else {
                    if (sync.isSearching()) {
                        this.renderSearching(ctx, mouseX, mouseY, contentY);
                    } else {
                        this.renderTabBar(ctx, mouseX, mouseY, contentY);
                        int tabContentY = this.getTabContentY();
                        int actualTabContentH = this.getTabContentHeight(panelHeight);
                        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScroll));
                        this.contentScrollState.setTarget(this.scrollOffset, this.maxScroll);
                        this.renderScrollOffset = this.contentScrollState.tick(delta, this.maxScroll);
                        this.maxScroll = 0;
                        PackUtilUiScale.enableOverlayScissor(ctx, this.panelX, tabContentY, this.panelX + this.PANEL_WIDTH, tabContentY + actualTabContentH);
                        switch (this.activeTab) {
                            case 0::
                                this.renderDashboard(ctx, mouseX, mouseY, tabContentY, actualTabContentH);
                                /* goto @457; */
                            case 1::
                                this.renderPeers(ctx, mouseX, mouseY, tabContentY, actualTabContentH);
                                /* goto @457; */
                            case 2::
                                this.renderExecute(ctx, mouseX, mouseY, tabContentY, actualTabContentH);
                                /* goto @457; */
                            case 3::
                                this.renderQueue(ctx, mouseX, mouseY, tabContentY, actualTabContentH);
                            default:
                                ctx.method_44380();
                                Metrics scrollbarMetrics = this.getContentScrollbarMetrics(tabContentY, actualTabContentH);
                                PackUiScrollbar.draw(ctx, scrollbarMetrics, scrollbarMetrics.contains((double)mouseX, (double)mouseY), this.scrollbarDragging);
                        }
                    }
                }
            }
            if (sync.isRunning()) {
                if (sync.isInSession()) {
                    this.renderLanChatField(ctx, mouseX, mouseY);
                }
            }
        }
        finally {
            this.endWindowBodyClip(ctx, clipBody);
            this.renderWindowInactiveOverlay(ctx, bounds, this.collapsed, this.isDragging);
            throw var15;
        }
    }

    private void renderNotRunning(class_332 ctx, int mx, int my, int y) {
        int lx = this.panelX + this.CONTENT_PADDING;
        this.drawUiText(ctx, "Not running", PackUiTone.LABEL, -43691, lx, y + 8);
        this.drawUiText(ctx, "LAN Sync is currently stopped", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, y + 22);
    }

    private void renderNoSession(class_332 ctx, int mx, int my, int y) {
        int lx = this.panelX + this.CONTENT_PADDING;
        this.drawUiText(ctx, "Quick Start", PackUiTone.LABEL, PACKUI_THEME.color(PackUiTone.BODY), lx, y + 6);
        this.drawUiText(ctx, "Host creates, others search & join", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, y + 20);
        int btnY = y + 40;
        int halfW = (this.PANEL_WIDTH - 24) / 2;
        this.drawOverlayButton(ctx, this.panelX + 8, btnY, halfW, this.BUTTON_HEIGHT, "Create", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(this.panelX + 8, btnY, halfW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderNoSession$6));
        this.drawOverlayButton(ctx, this.panelX + 12 + halfW, btnY, halfW, this.BUTTON_HEIGHT, "Search", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(this.panelX + 12 + halfW, btnY, halfW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderNoSession$7));
    }

    private void renderSearching(class_332 ctx, int mx, int my, int y) {
        int secondsLeft = PackUtilLANSync.getInstance().getSearchSecondsRemaining();
        String text = "Searching... " + secondsLeft + "s";
        int tw = PackUiText.width(this.textRenderer, text, PACKUI_THEME.fontFor(PackUiTone.LABEL), -22016);
        this.drawUiText(ctx, text, PackUiTone.LABEL, -22016, this.panelX + (this.PANEL_WIDTH - tw) / 2, y + 10);
        int btnY = y + 35;
        this.drawOverlayButton(ctx, this.panelX + 30, btnY, this.PANEL_WIDTH - 60, this.BUTTON_HEIGHT, "Cancel Search", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(this.panelX + 30, btnY, this.PANEL_WIDTH - 60, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderSearching$8));
    }

    private void ensureLanChatField(int panelHeight) {
        if (this.lanChatField == null) {
            this.lanChatField = new PackUtilChatField(MC, this.textRenderer, this.panelX + this.CONTENT_PADDING, this.panelY, this.PANEL_WIDTH - this.CONTENT_PADDING * 2, this.CHAT_FIELD_HEIGHT, true);
            this.lanChatField.setSubmitHandler(PackUtilLANSyncOverlay::lambda$ensureLanChatField$9);
        }
        int fieldX = this.panelX + this.CONTENT_PADDING;
        int fieldY = this.panelY + panelHeight - this.CHAT_FIELD_HEIGHT - 6;
        int fieldWidth = this.PANEL_WIDTH - this.CONTENT_PADDING * 2;
        this.lanChatField.setX(fieldX);
        this.lanChatField.setY(fieldY);
        this.lanChatField.setWidth(fieldWidth);
        boolean enabled = PackUtilLANSync.getInstance().isRunning() && PackUtilLANSync.getInstance().isInSession();
        this.lanChatField.setEditable(enabled);
        this.lanChatField.setSubmitOnEnter(enabled);
        this.lanChatField.setPlaceholder(class_2561.method_43470(enabled ? "Sync message to all peers..." : "Join or create a session first"));
        if (!enabled) {
            this.lanChatField.setFocused(false);
        }
    }

    private void renderLanChatField(class_332 ctx, int mouseX, int mouseY) {
        if (this.lanChatField == null) {
            return;
        }
        int labelY = this.lanChatField.getY() - 10;
        PackUtilText.draw(ctx, this.textRenderer, "Sync Send", PackUtilText.Tone.MUTED, this.lanChatField.getX(), labelY, false);
        this.lanChatField.render(ctx, mouseX, mouseY, 0f);
    }

    private void renderTabBar(class_332 ctx, int mx, int my, int y) {
        int tabW = this.PANEL_WIDTH / TAB_NAMES.length;
        for (int i = 0; i < TAB_NAMES.length; i++) {
            int tx = this.panelX + i * tabW;
            if (i == this.activeTab) {
                this.drawOverlayButton(ctx, tx, y, tabW, this.TAB_HEIGHT, TAB_NAMES[i], PackUiOverlayButton.Variant.PRIMARY, true, PackUiTone.LABEL, mx, my);
            } else {
                this.drawOverlayButton(ctx, tx, y, tabW, this.TAB_HEIGHT, TAB_NAMES[i], PackUiOverlayButton.Variant.SECONDARY, true, PackUiTone.LABEL, mx, my);
            }
            int tabIdx = i;
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(tx, y, tabW, this.TAB_HEIGHT, this::lambda$renderTabBar$10 /* captured: tabIdx */));
        }
    }

    private void renderDashboard(class_332 ctx, int mx, int my, int y, int h) {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        int lx = this.panelX + this.CONTENT_PADDING;
        int cy = y + 4;
        this.drawUiText(ctx, "Session", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, cy);
        this.drawUiText(ctx, sync.getSessionId(), PackUiTone.BODY, -1, lx + 50, cy);
        cy += 12;
        String role = sync.isHost() ? "Host" : "Client";
        int roleColor = sync.isHost() ? -22016 : -11141291;
        this.drawUiText(ctx, "Role", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, cy);
        this.drawUiText(ctx, role, PackUiTone.BODY, roleColor, lx + 50, cy);
        cy += 12;
        this.drawUiText(ctx, "Peers", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, cy);
        this.drawUiText(ctx, String.valueOf(sync.getConnectedCount()), PackUiTone.BODY, -1, lx + 50, cy);
        cy += 12;
        if (sync.isReconnecting()) {
            this.drawUiText(ctx, "Reconnecting...", PackUiTone.LABEL, -22016, lx, cy);
            cy += 12;
        }
        cy += 4;
        SyncState state = sync.getSyncState();
        String stateStr = state.name();
        int stateColor = this.getSyncStateColor(state);
        this.drawUiText(ctx, "Sync", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, cy);
        this.drawUiText(ctx, stateStr, PackUiTone.BODY, stateColor, lx + 50, cy);
        cy += 14;
        SpreadResult spread = sync.getLastSpreadResult();
        if (spread != null) {
            String spreadStr = String.format("%.1fms", spread.getSpreadMs());
            int spreadColor = this.getSpreadColor(spread.getSpreadMs());
            this.drawUiText(ctx, "Spread", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, cy);
            this.drawUiText(ctx, spreadStr, PackUiTone.BODY, spreadColor, lx + 50, cy);
            if (spread.lateClient != null) {
                if (!spread.lateClient.isEmpty()) {
                    if (spread.getSpreadMs() > 0) {
                        this.drawUiText(ctx, " (" + spread.lateClient + ")", PackUiTone.MUTED, PackUtilColors.textDim(), lx + 50 + PackUiText.width(this.textRenderer, spreadStr, PACKUI_THEME.fontFor(PackUiTone.BODY), spreadColor), cy);
                    }
                }
            }
            cy += 12;
        }
        history = sync.getSpreadHistory();
        if (history.isEmpty()) { /* goto L560; */ }
        this.drawUiText(ctx, "History", PackUiTone.MUTED, PackUtilColors.textSecondary(), lx, cy);
        dotX = lx + 52;
        var var17 = history.iterator();
        while (var17.hasNext()) {
            SpreadResult sr = (PackUtilLANSync.SpreadResult)var17.next();
            int dotColor = this.getSpreadColor(sr.getSpreadMs());
            ctx.method_25294(dotX, cy + 2, dotX + 6, cy + 8, dotColor);
            dotX += 9;
        }
        cy += 14;
        L560: ;
        btnY = y + h - this.BUTTON_HEIGHT - 4;
        this.drawOverlayButton(ctx, this.panelX + this.CONTENT_PADDING, btnY, this.PANEL_WIDTH - this.CONTENT_PADDING * 2, this.BUTTON_HEIGHT, "Leave Session", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(this.panelX + this.CONTENT_PADDING, btnY, this.PANEL_WIDTH - this.CONTENT_PADDING * 2, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderDashboard$11));
    }

    private void renderPeers(class_332 ctx, int mx, int my, int y, int h) {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        int lx = this.panelX + this.CONTENT_PADDING;
        int cy = y + 4;
        int rowWidth = this.getContentWidth() + 4;
        Map<String, PackUtilLANSync.ClientInfo> clients = sync.getConnectedClients();
        List<PackUtilLANSync.ClientInfo> sortedClients = new ArrayList(clients.values());
        sortedClients.sort(PackUtilLANSyncOverlay::lambda$renderPeers$12);
        var var12 = sortedClients.iterator();
        while (var12.hasNext()) {
            ClientInfo client = (PackUtilLANSync.ClientInfo)var12.next();
            boolean isSelected = client.username.equals(this.selectedPeer);
            boolean isHov = this.isHovered(mx, my, lx - 2, cy, this.PANEL_WIDTH - this.CONTENT_PADDING * 2 + 4, this.ROW_HEIGHT);
            PackUiListRenderer.drawRow(ctx, this.textRenderer, "", lx - 2, cy, rowWidth, this.ROW_HEIGHT, isHov, isSelected, PackUiListRenderer.RowTone.NORMAL);
            PackUiControlGlyphs.drawChevron(ctx, lx + 1, cy + 3, 8, isSelected ? PackUiControlGlyphs.ChevronDirection.DOWN : PackUiControlGlyphs.ChevronDirection.RIGHT, isSelected ? -593937 : -1911596, -1204284392, 1f);
            PeerStatus status = sync.getPeerStatus(client.username);
            int dotColor = status == PackUtilLANSync.PeerStatus.HEALTHY ? -11141291 : status == PackUtilLANSync.PeerStatus.STALE ? -22016 : -7829368;
            ctx.method_25294(lx + 10, cy + 4, lx + 15, cy + 9, dotColor);
            boolean isSelf = client.username.equals(sync.getMyUsername());
            int nameColor = isHov ? -2245633 : client.isHost ? -22016 : -1;
            int rightReserve = 4;
            if (!isSelf) continue;
            rightReserve = rightReserve + (PackUiText.width(this.textRenderer, " (YOU)", PACKUI_THEME.fontFor(PackUiTone.MUTED), PackUtilColors.textSecondary()) + 2);
            if (!client.isHost) continue;
            rightReserve = rightReserve + (PackUiText.width(this.textRenderer, " [HOST]", PACKUI_THEME.fontFor(PackUiTone.LABEL), -22016) + 2);
            int offset = client.delayOffsetMs;
            if (!offset > 0) continue;
            rightReserve = rightReserve + (PackUiText.width(this.textRenderer, "+" + offset + "ms", PACKUI_THEME.fontFor(PackUiTone.BODY), -11149825) + 4);
            int nameMaxW = Math.max(20, rowWidth - 18 - rightReserve);
            String displayName = PackUtilText.trimToWidth(this.textRenderer, client.username, nameMaxW, PackUtilText.Tone.BODY);
            PackUiText.draw(ctx, this.textRenderer, displayName, PACKUI_THEME.fontFor(PackUiTone.BODY), nameColor, lx + 18, cy + 3, false);
            int badgeX = lx + 18 + PackUiText.width(this.textRenderer, displayName, PACKUI_THEME.fontFor(PackUiTone.BODY), nameColor) + 4;
            if (isSelf) {
                this.drawUiText(ctx, "(YOU)", PackUiTone.MUTED, PackUtilColors.textSecondary(), badgeX, cy + 3);
                badgeX = badgeX + (PackUiText.width(this.textRenderer, "(YOU)", PACKUI_THEME.fontFor(PackUiTone.MUTED), PackUtilColors.textSecondary()) + 4);
            }
            if (!client.isHost) continue;
            this.drawUiText(ctx, "[HOST]", PackUiTone.LABEL, -22016, badgeX, cy + 3);
            if (offset > 0) {
                String offsetStr = "+" + offset + "ms";
                int ofw = PackUiText.width(this.textRenderer, offsetStr, PACKUI_THEME.fontFor(PackUiTone.BODY), -11149825);
                this.drawUiText(ctx, offsetStr, PackUiTone.BODY, -11149825, this.panelX + this.PANEL_WIDTH - this.CONTENT_PADDING - ofw, cy + 3);
            }
            peerName = client.username;
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx - 2, cy, rowWidth, this.ROW_HEIGHT, this::lambda$renderPeers$13 /* captured: peerName */));
            cy = cy + (this.ROW_HEIGHT + 1);
            if (!isSelected) { /* goto @1249; */ }
            detailBg = PackUtilColors.background();
            int detailH = 62;
            ctx.method_25294(lx + 4, cy, this.panelX + this.PANEL_WIDTH - this.CONTENT_PADDING - 4, cy + detailH, detailBg);
            ctx.method_25294(lx + 4, cy, lx + 5, cy + detailH, PackUtilColors.secondary());
            int dx = lx + 10;
            int dy = cy + 4;
            this.drawUiText(ctx, "Status: " + status.name(), PackUiTone.BODY, status == PackUtilLANSync.PeerStatus.HEALTHY ? -11141291 : -22016, dx, dy);
            dy += 12;
            this.drawUiText(ctx, isSelf ? "(This is you)" : "Connected peer", PackUiTone.MUTED, PackUtilColors.textDim(), dx, dy);
            dy += 13;
            this.drawUiText(ctx, "Exec delay", PackUiTone.MUTED, PackUtilColors.textSecondary(), dx, dy);
            dy += 11;
            int ctrlX = dx + 4;
            int btnS = 14;
            this.drawOverlayButton(ctx, ctrlX, dy, btnS, btnS, "-", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(ctrlX, dy, btnS, btnS, PackUtilLANSyncOverlay::lambda$renderPeers$14 /* captured: sync, peerName */));
            ctrlX = ctrlX + (btnS + 3);
            String valStr = offset + "ms";
            int valW = PackUiText.width(this.textRenderer, valStr, PACKUI_THEME.fontFor(PackUiTone.BODY), -1) + 8;
            ctx.method_25294(ctrlX, dy, ctrlX + valW, dy + btnS, PackUtilColors.rowNormal());
            this.drawUiText(ctx, valStr, PackUiTone.BODY, -1, ctrlX + 4, dy + 2);
            ctrlX = ctrlX + (valW + 3);
            this.drawOverlayButton(ctx, ctrlX, dy, btnS, btnS, "+", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(ctrlX, dy, btnS, btnS, PackUtilLANSyncOverlay::lambda$renderPeers$15 /* captured: sync, peerName */));
            ctrlX = ctrlX + (btnS + 5);
            int resetW = PackUiText.width(this.textRenderer, "Reset", PACKUI_THEME.fontFor(PackUiTone.BODY), PACKUI_THEME.color(PackUiTone.BODY)) + 10;
            this.drawOverlayButton(ctx, ctrlX, dy, resetW, btnS, "Reset", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(ctrlX, dy, resetW, btnS, PackUtilLANSyncOverlay::lambda$renderPeers$16 /* captured: sync, peerName */));
            cy = cy + (detailH + 2);
        }
        this.maxScroll = 0;
        this.clampScrollOffset();
    }

    private void renderQueue(class_332 ctx, int mx, int my, int y, int h) {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        int lx = this.panelX + this.CONTENT_PADDING;
        int cy = y + 6;
        PackUtilSharedState state = PackUtilSharedState.get();
        int queueSize = state.getDelayedPackets() != null ? state.getDelayedPackets().size() : 0;
        this.drawUiText(ctx, "My Queue", PackUiTone.LABEL, -1, lx, cy);
        cy += 12;
        this.drawUiText(ctx, queueSize + " packets queued", PackUiTone.BODY, queueSize > 0 ? -11141291 : PackUtilColors.textDim(), lx, cy);
        cy += 16;
        int btnW = this.PANEL_WIDTH - this.CONTENT_PADDING * 2;
        this.drawOverlayButton(ctx, lx, cy, btnW, this.BUTTON_HEIGHT, "Share Queue", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx, cy, btnW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderQueue$17 /* captured: sync */));
        cy = cy + (this.BUTTON_HEIGHT + 8);
        this.drawOverlayButton(ctx, lx, cy, btnW, this.BUTTON_HEIGHT, "Sync Execute", PackUiOverlayButton.Variant.PRIMARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx, cy, btnW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderQueue$18 /* captured: sync */));
        this.maxScroll = 0;
    }

    private void renderExecute(class_332 ctx, int mx, int my, int y, int h) {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        int lx = this.panelX + this.CONTENT_PADDING;
        int cy = y + 4;
        int btnW = this.PANEL_WIDTH - this.CONTENT_PADDING * 2;
        String modeLabel = this.perUserMode ? "Mode: Per-User" : "Mode: Shared Macro";
        this.drawOverlayButton(ctx, lx, cy, btnW, this.BUTTON_HEIGHT, modeLabel, PackUiOverlayButton.Variant.PRIMARY, true, mx, my);
        this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx, cy, btnW, this.BUTTON_HEIGHT, this::lambda$renderExecute$19 /* captured: sync */));
        cy = cy + (this.BUTTON_HEIGHT + 6);
        if (this.perUserMode) {
            this.clearSameMacroListViewport();
            cy = this.renderExecutePerUser(ctx, mx, my, cy, lx, btnW, sync);
        } else {
            this.clearPerUserListViewport();
            cy = this.renderExecuteSameMacro(ctx, mx, my, cy, lx, btnW, sync);
        }
        boolean anyRunning = MacroExecutor.isRunning();
        if (anyRunning) {
            this.drawOverlayButton(ctx, lx, cy, btnW, this.BUTTON_HEIGHT, "Sync Stop All", PackUiOverlayButton.Variant.DANGER, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx, cy, btnW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderExecute$20 /* captured: sync */));
            cy = cy + (this.BUTTON_HEIGHT + 6);
        }
        ctx.method_25294(lx - 2, cy, this.panelX + this.PANEL_WIDTH - this.CONTENT_PADDING + 2, cy + 1, PackUtilColors.secondary());
        cy += 6;
        SyncState state = sync.getSyncState();
        String stateStr = this.formatSyncState(state, sync);
        int stateColor = this.getSyncStateColor(state);
        this.drawUiText(ctx, "Status: " + stateStr, PackUiTone.BODY, stateColor, lx, cy);
        cy += 14;
        String setBy = sync.getAssignmentSetBy();
        this.drawUiText(ctx, "Assigned by: " + setBy, PackUiTone.MUTED, PackUtilColors.textDim(), lx, cy);
        if (this.perUserMode && !setBy.isEmpty()) {
            cy += 12;
        }
        SpreadResult spread = sync.getLastSpreadResult();
        if (spread != null) {
            String spreadStr = String.format("Last spread: %.1fms (%d clients)", spread.getSpreadMs(), spread.clientCount);
            this.drawUiText(ctx, spreadStr, PackUiTone.BODY, this.getSpreadColor(spread.getSpreadMs()), lx, cy);
            cy += 14;
        }
        this.maxScroll = 0;
        this.clampScrollOffset();
    }

    private int renderExecuteSameMacro(class_332 ctx, int mx, int my, int cy, int lx, int btnW, PackUtilLANSync sync) {
        PackUiListRenderer.drawHeader(ctx, this.textRenderer, "Local Macros", lx, cy);
        cy += 14;
        List<PackUtilMacro> localMacros = PackUtilMacroManager.get().getAll();
        if (localMacros.isEmpty()) {
            this.clearSameMacroListViewport();
            this.drawUiText(ctx, "No macros", PackUiTone.MUTED, PackUtilColors.textDim(), lx, cy);
            cy += 12;
        } else {
            this.sameMacroListX = lx - 2;
            this.sameMacroListY = cy;
            this.sameMacroListWidth = this.getContentWidth() + 4;
            this.sameMacroListHeight = this.macroListViewportHeight(localMacros.size());
            if (this.sameMacroList == null || this.sameMacroList.getX() != this.sameMacroListX || this.sameMacroList.getY() != this.sameMacroListY || this.sameMacroList.getWidth() != this.sameMacroListWidth || this.sameMacroList.getHeight() != this.sameMacroListHeight) {
                this.sameMacroList = new PackUiScrollList(this.sameMacroListX, this.sameMacroListY, this.sameMacroListWidth, this.sameMacroListHeight, this.sameMacroListRowPitch(), 3, PackUtilLANSyncOverlay::lambda$renderExecuteSameMacro$21, this::lambda$renderExecuteSameMacro$22);
                this.sameMacroList.setSecondaryTextExtractor(PackUtilLANSyncOverlay::lambda$renderExecuteSameMacro$23);
                this.sameMacroList.setSelectedIndex(-1);
            }
            this.sameMacroList.setItems(localMacros);
            int i = 0;
            while (i < localMacros.size()) {
                if (((PackUtilMacro)localMacros.get(i)).name.equals(this.selectedMacroName)) {
                    this.sameMacroList.setSelectedIndex(i);
                } else {
                    i++;
                }
            }
            this.sameMacroList.render(ctx, this.textRenderer, (double)mx, (double)my);
            cy = cy + this.sameMacroListHeight;
        }
        cy += 8;
        syncStatus = this.analyzeSameMacroStatus(sync, this.selectedMacroName);
        if (this.selectedMacroName == null) { /* goto L609; */ }
        String selectedLine = PackUtilText.trimToWidth(this.textRenderer, "Selected: " + this.selectedMacroName, btnW, PackUtilText.Tone.BODY);
        this.drawUiText(ctx, selectedLine, PackUiTone.BODY, -1, lx, cy);
        cy += 12;
        if (!syncStatus.missingPeers.isEmpty()) {
            String missingLine = PackUtilText.trimToWidth(this.textRenderer, "Missing on: " + this.formatNameSummary(syncStatus.missingPeers), btnW, PackUtilText.Tone.BODY);
            this.drawUiText(ctx, missingLine, PackUiTone.BODY, -38037, lx, cy);
            cy += 12;
        }
        if (!syncStatus.differentPeers.isEmpty()) {
            differentLine = PackUtilText.trimToWidth(this.textRenderer, "Different on: " + this.formatDifferenceSummary(syncStatus.differentPeers), btnW, PackUtilText.Tone.BODY);
            this.drawUiText(ctx, differentLine, PackUiTone.BODY, -14249, lx, cy);
            cy += 12;
        }
        if (syncStatus.missingPeers.isEmpty()) {
            if (!syncStatus.differentPeers.isEmpty()) { /* goto @575; */ }
            readyLine = sync.getConnectedCount() > 1 ? "All peers have this macro" : "Ready to execute";
            this.drawUiText(ctx, readyLine, PackUiTone.BODY, -9837157, lx, cy);
            cy += 12;
        } else {
            if (syncStatus.missingPeers.isEmpty()) {
                this.drawUiText(ctx, "Execution allowed in Same Macro mode", PackUiTone.BODY, -9837157, lx, cy);
                cy += 12;
            }
        }
        shareW = Math.min(112, Math.max(94, PackUiText.width(this.textRenderer, "Send To Peers", PACKUI_THEME.fontFor(PackUiTone.BODY), PackUtilColors.textPrimary()) + 12));
        executeX = lx + shareW + 4;
        int executeW = btnW - shareW - 4;
        boolean shareEnabled = this.selectedMacroName != null && sync.getConnectedCount() > 1;
        boolean executeEnabled = this.selectedMacroName != null && syncStatus.canExecute();
        if (shareEnabled) {
            this.drawOverlayButton(ctx, lx, cy, shareW, this.BUTTON_HEIGHT, "Send To Peers", PackUiOverlayButton.Variant.SUCCESS, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx, cy, shareW, this.BUTTON_HEIGHT, this::lambda$renderExecuteSameMacro$24 /* captured: sync */));
        } else {
            this.drawOverlayButton(ctx, lx, cy, shareW, this.BUTTON_HEIGHT, "Send To Peers", PackUiOverlayButton.Variant.SUCCESS, false, mx, my);
        }
        if (this.selectedMacroName == null) {
            String executeLabel = "Select a macro";
        } else {
            if (!executeEnabled) {
                String executeLabel = "Need all peers to have it";
            } else {
                String executeLabel = "Sync Execute";
            }
        }
        if (executeEnabled) {
            this.drawOverlayButton(ctx, executeX, cy, executeW, this.BUTTON_HEIGHT, executeLabel, PackUiOverlayButton.Variant.PRIMARY, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(executeX, cy, executeW, this.BUTTON_HEIGHT, this::lambda$renderExecuteSameMacro$25 /* captured: sync */));
        } else {
            this.drawOverlayButton(ctx, executeX, cy, executeW, this.BUTTON_HEIGHT, executeLabel, PackUiOverlayButton.Variant.PRIMARY, false, mx, my);
        }
        cy = cy + (this.BUTTON_HEIGHT + 6);
        return cy;
    }

    private int renderExecutePerUser(class_332 ctx, int mx, int my, int cy, int lx, int btnW, PackUtilLANSync sync) {
        this.syncPerUserAssignments(sync);
        int rowW = this.getContentWidth() + 4;
        this.perUserListX = lx - 2;
        this.perUserListY = cy;
        this.perUserListWidth = rowW;
        int perUserListContentHeight = this.estimatePerUserListContentHeight(sync);
        this.perUserListHeight = this.cappedListViewportHeight(perUserListContentHeight);
        if (this.perUserListViewport == null || this.perUserListViewport.getX() != this.perUserListX || this.perUserListViewport.getY() != this.perUserListY || this.perUserListViewport.getWidth() != this.perUserListWidth || this.perUserListViewport.getHeight() != this.perUserListHeight) {
            this.perUserListViewport = new PackUiScrollViewport(this.perUserListX, this.perUserListY, this.perUserListWidth, this.perUserListHeight, this.sameMacroListRowPitch(), 3);
        }
        this.perUserListViewport.setContentHeight(perUserListContentHeight);
        int drawScroll = this.perUserListViewport.getScrollOffset();
        int clipTop = this.perUserListY + 1;
        int clipBottom = this.perUserListY + this.perUserListHeight - 1;
        int rowPitch = this.perUserListViewport.getRowHeight();
        ctx.method_25294(this.perUserListX, this.perUserListY, this.perUserListX + this.perUserListWidth, this.perUserListY + this.perUserListHeight, 905969664);
        ctx.method_25294(this.perUserListX, this.perUserListY, this.perUserListX + this.perUserListWidth, this.perUserListY + 1, PACKUI_THEME.borderSoft());
        ctx.method_25294(this.perUserListX, this.perUserListY + this.perUserListHeight - 1, this.perUserListX + this.perUserListWidth, this.perUserListY + this.perUserListHeight, PACKUI_THEME.borderSoft());
        ctx.method_25294(this.perUserListX, this.perUserListY, this.perUserListX + 1, this.perUserListY + this.perUserListHeight, PACKUI_THEME.borderSoft());
        ctx.method_25294(this.perUserListX + this.perUserListWidth - 1, this.perUserListY, this.perUserListX + this.perUserListWidth, this.perUserListY + this.perUserListHeight, PACKUI_THEME.borderSoft());
        PackUtilUiScale.enableOverlayScissor(ctx, this.perUserListX + 1, this.perUserListY + 1, this.perUserListX + this.perUserListWidth - 1, this.perUserListY + this.perUserListHeight - 1);
        try {
            cy = this.perUserListY - drawScroll;
            AssignmentSyncStatus status = new ArrayList(this.perUserAssignments.entrySet()).iterator();
            while (status.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry)status.next();
                String peer = (String)entry.getKey();
                String assigned = (String)entry.getValue();
                boolean isExpanded = peer.equals(this.expandedExecutePeer);
                boolean isMe = peer.equals(sync.getMyUsername());
                boolean rowVisible = cy + rowPitch > clipTop && cy < clipBottom;
                boolean rowHov = rowVisible && this.isHovered(mx, my, lx - 2, cy, rowW, rowPitch);
                int rowBg = isExpanded ? PackUtilColors.rowSelected() : rowHov ? PackUtilColors.rowHover() : PackUtilColors.rowNormal();
                String peerLabel = peer + isMe ? " (you)" : "";
                String assignLabel = assigned.isEmpty() ? "(none)" : assigned;
                int assignColor = assigned.isEmpty() ? PackUtilColors.textDim() : -11141291;
                int maxAssignW = Math.min((rowW - 12) / 2, PackUiText.width(this.textRenderer, assignLabel, PACKUI_THEME.fontFor(PackUiTone.BODY), assignColor));
                int peerNameMaxW = Math.max(20, rowW - 10 - maxAssignW - 8 - 12);
                if (!rowVisible) { /* goto L971; */ }
                int rowTop = Math.max(cy, clipTop);
                int rowBottom = Math.min(cy + rowPitch, clipBottom);
                if (rowBottom <= rowTop) { /* goto L971; */ }
                ctx.method_25294(this.perUserListX + 1, rowTop, this.perUserListX + this.perUserListWidth - 1, rowBottom, rowBg);
                int chevronY = Math.max(cy + 3, clipTop + 1);
                if (chevronY >= clipBottom - 10) { /* goto L839; */ }
                PackUiControlGlyphs.drawChevron(ctx, lx + 1, chevronY, 8, isExpanded ? PackUiControlGlyphs.ChevronDirection.DOWN : PackUiControlGlyphs.ChevronDirection.RIGHT, isExpanded ? -593937 : -1911596, -1204284392, 1f);
                L839: ;
                int textY = Math.max(cy + 3, clipTop + 1);
                if (textY >= clipBottom - 2) { /* goto L971; */ }
                String truncPeerLabel = PackUtilText.trimToWidth(this.textRenderer, peerLabel, peerNameMaxW, PackUtilText.Tone.BODY);
                this.drawUiText(ctx, truncPeerLabel, PackUiTone.BODY, isMe ? PackUtilColors.textSecondary() : -1, lx + 10, textY);
                String truncAssign = PackUtilText.trimToWidth(this.textRenderer, assignLabel, maxAssignW, PackUtilText.Tone.BODY);
                int truncAssignW = PackUiText.width(this.textRenderer, truncAssign, PACKUI_THEME.fontFor(PackUiTone.BODY), assignColor);
                this.drawUiText(ctx, truncAssign, PackUiTone.BODY, assignColor, PackUiLegacyLayout.rightAlign(lx, rowW - 12, truncAssignW, 4), textY);
                L971: ;
                peerKey = peer;
                if (rowVisible) {
                    this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx - 2, cy, rowW, rowPitch, this::lambda$renderExecutePerUser$26 /* captured: peerKey */));
                }
                cy = cy + rowPitch;
                if (!isExpanded) { /* goto @2086; */ }
                detailLx = lx + 6;
                detailRx = this.panelX + this.PANEL_WIDTH - this.CONTENT_PADDING - 4;
                myMacroList = PackUtilMacroManager.get().getAll();
                myMacroMap = new LinkedHashMap();
                allRemote = myMacroList.iterator();
                while (allRemote.hasNext()) {
                    m = (PackUtilMacro)allRemote.next();
                    myMacroMap.put(m.name, m.actions != null ? m.actions.size() : 0);
                }
                if (isMe) {
                    allRemote = myMacroList.iterator();
                    while (allRemote.hasNext()) {
                        macro = (PackUtilMacro)allRemote.next();
                        cy = this.renderPickerRowClipped(ctx, mx, my, cy, detailLx, detailRx, rowW, macro.name, assigned, null, peerKey, sync, false, clipTop, clipBottom, rowPitch);
                    }
                } else {
                    allRemote = sync.getAllRemoteMacros();
                    peerMacroData = (Map)allRemote.getOrDefault(peer, Collections.emptyMap());
                    Map<String, Integer> peerMacroMap = new LinkedHashMap();
                    List<String> shared = peerMacroData.entrySet().iterator();
                    while (shared.hasNext()) {
                        Map.Entry<String, PackUtilMacro> e = (Map.Entry)shared.next();
                        peerMacroMap.put((String)e.getKey(), ((PackUtilMacro)e.getValue()).actions != null ? ((PackUtilMacro)e.getValue()).actions.size() : 0);
                    }
                    shared = new ArrayList();
                    different = new LinkedHashMap();
                    List<String> peerOnly = new ArrayList();
                    List<String> mineOnly = new ArrayList();
                    int rowTop = peerMacroMap.keySet().iterator();
                    while (rowTop.hasNext()) {
                        String name = (String)rowTop.next();
                        if (myMacroMap.containsKey(name)) {
                            int diffs = PackUtilLANSyncOverlay.countActionDifferences(PackUtilMacroManager.get().get(name), (PackUtilMacro)peerMacroData.get(name));
                            if (diffs == 0) {
                                shared.add(name);
                            } else {
                                different.put(name, diffs);
                            }
                        } else {
                            peerOnly.add(name);
                        }
                    }
                    rowTop = myMacroMap.keySet().iterator();
                    while (rowTop.hasNext()) {
                        name = (String)rowTop.next();
                        if (peerMacroMap.containsKey(name)) continue;
                        mineOnly.add(name);
                    }
                    if (shared.isEmpty()) { /* goto L1646; */ }
                    rowTop = shared.iterator();
                    while (rowTop.hasNext()) {
                        name = (String)rowTop.next();
                        cy = this.renderPickerRowClipped(ctx, mx, my, cy, detailLx, detailRx, rowW, name, assigned, null, peerKey, sync, false, clipTop, clipBottom, rowPitch);
                    }
                    if (different.isEmpty()) { /* goto L1780; */ }
                    rowTop = different.entrySet().iterator();
                    while (rowTop.hasNext()) {
                        de = (Map.Entry)rowTop.next();
                        String name = (String)de.getKey();
                        int diff = ((Integer)de.getValue()).intValue();
                        String badge = " +" + diff + " Difference" + diff > 1 ? "s" : "";
                        cy = this.renderPickerRowClipped(ctx, mx, my, cy, detailLx, detailRx, rowW, name, assigned, badge, peerKey, sync, false, clipTop, clipBottom, rowPitch);
                    }
                    if (peerOnly.isEmpty()) { /* goto L1857; */ }
                    rowTop = peerOnly.iterator();
                    while (rowTop.hasNext()) {
                        name = (String)rowTop.next();
                        cy = this.renderPickerRowClipped(ctx, mx, my, cy, detailLx, detailRx, rowW, name, assigned, null, peerKey, sync, true, clipTop, clipBottom, rowPitch);
                    }
                    if (mineOnly.isEmpty()) { /* goto L1934; */ }
                    rowTop = mineOnly.iterator();
                    while (rowTop.hasNext()) {
                        name = (String)rowTop.next();
                        cy = this.renderPickerRowClipped(ctx, mx, my, cy, detailLx, detailRx, rowW, name, assigned, null, peerKey, sync, false, clipTop, clipBottom, rowPitch);
                    }
                    if (shared.isEmpty()) {
                        if (different.isEmpty()) {
                            if (peerOnly.isEmpty()) {
                                if (mineOnly.isEmpty()) {
                                    if (cy + rowPitch > clipTop) {
                                        if (cy < clipBottom) {
                                            rowTop = Math.max(cy, clipTop);
                                            rowBottom = Math.min(cy + rowPitch, clipBottom);
                                            if (rowBottom > rowTop) {
                                                ctx.method_25294(detailLx - 2, rowTop, detailRx, rowBottom, 553648127);
                                                textY = Math.max(cy + 3, clipTop + 1);
                                                if (textY < clipBottom - 2) {
                                                    this.drawUiText(ctx, "No macros available", PackUiTone.MUTED, PackUtilColors.textDim(), detailLx, textY);
                                                }
                                            }
                                        }
                                    }
                                    cy = cy + rowPitch;
                                }
                            }
                        }
                    }
                }
                cy += 4;
            }
        }
        finally {
            ctx.method_44380();
            throw var45;
        }
        this.perUserListViewport.renderScrollbar(ctx, (double)mx, (double)my);
        cy = this.perUserListY + this.perUserListHeight;
        status = this.analyzeAssignmentStatus(sync);
        shareableMissingMacros = this.getShareableMissingMacros(status);
        cy += 6;
        if (!status.missingAssignments.isEmpty()) {
            missingLine = PackUtilText.trimToWidth(this.textRenderer, "Missing: " + this.formatMissingAssignmentsSummary(status.missingAssignments), btnW, PackUtilText.Tone.BODY);
            this.drawUiText(ctx, missingLine, PackUiTone.BODY, -38037, lx, cy);
            cy += 12;
        } else {
            if (status.hasAssignments()) {
                this.drawUiText(ctx, "Assigned macros are ready", PackUiTone.BODY, -9837157, lx, cy);
                cy += 12;
            }
        }
        shareW = Math.min(112, Math.max(96, PackUiText.width(this.textRenderer, "Send Missing", PACKUI_THEME.fontFor(PackUiTone.BODY), PackUtilColors.textPrimary()) + 12));
        executeX = lx + shareW + 4;
        executeW = btnW - shareW - 4;
        if (!shareableMissingMacros.isEmpty()) {
            sendLabel = shareableMissingMacros.size() > 1 ? "Send Missing (" + shareableMissingMacros.size() + ")" : "Send Missing";
            this.drawOverlayButton(ctx, lx, cy, shareW, this.BUTTON_HEIGHT, sendLabel, PackUiOverlayButton.Variant.SUCCESS, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(lx, cy, shareW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderExecutePerUser$27 /* captured: shareableMissingMacros, sync */));
        } else {
            this.drawOverlayButton(ctx, lx, cy, shareW, this.BUTTON_HEIGHT, "Send Missing", PackUiOverlayButton.Variant.SUCCESS, false, mx, my);
        }
        if (!status.hasAssignments()) {
            puLabel = "Assign macros to users above";
        } else {
            if (!status.canExecute()) {
                puLabel = "Need missing macros first";
            } else {
                puLabel = "Sync Execute (Per-User)";
            }
        }
        if (status.canExecute()) {
            this.drawOverlayButton(ctx, executeX, cy, executeW, this.BUTTON_HEIGHT, puLabel, PackUiOverlayButton.Variant.PRIMARY, true, mx, my);
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(executeX, cy, executeW, this.BUTTON_HEIGHT, PackUtilLANSyncOverlay::lambda$renderExecutePerUser$28 /* captured: status, sync */));
        } else {
            this.drawOverlayButton(ctx, executeX, cy, executeW, this.BUTTON_HEIGHT, puLabel, PackUiOverlayButton.Variant.PRIMARY, false, mx, my);
        }
        cy = cy + (this.BUTTON_HEIGHT + 6);
        return cy;
    }

    private PackUtilLANSyncOverlay.MacroSyncStatus analyzeSameMacroStatus(PackUtilLANSync sync, String macroName) {
        List<String> missingPeers = new ArrayList(sync.getPeersMissingMacro(macroName));
        Map<String, Integer> differentPeers = new LinkedHashMap();
        if (macroName == null || macroName.isBlank()) {
            return new PackUtilLANSyncOverlay.MacroSyncStatus(missingPeers, differentPeers);
        }
        PackUtilMacro localMacro = PackUtilMacroManager.get().get(macroName);
        if (localMacro == null) {
            return new PackUtilLANSyncOverlay.MacroSyncStatus(missingPeers, differentPeers);
        }
        Set<String> missingPeerSet = new HashSet(missingPeers);
        Map<String, Map<String, PackUtilMacro>> allRemote = sync.getAllRemoteMacros();
        List<String> peers = new ArrayList(sync.getConnectedClients().keySet());
        Collections.sort(peers);
        var var9 = peers.iterator();
        while (var9.hasNext()) {
            String peer = (String)var9.next();
            if (peer.equals(sync.getMyUsername())) continue;
            while (missingPeerSet.contains(peer)) {
            }
            Map<String, PackUtilMacro> peerMacros = (Map)allRemote.get(peer);
            while (peerMacros == null) {
            }
            PackUtilMacro remoteMacro = (PackUtilMacro)peerMacros.get(macroName);
            int differences = PackUtilLANSyncOverlay.countActionDifferences(localMacro, remoteMacro);
            if (!differences > 0) continue;
            differentPeers.put(peer, differences);
        }
        return new PackUtilLANSyncOverlay.MacroSyncStatus(missingPeers, differentPeers);
    }

    private PackUtilLANSyncOverlay.AssignmentSyncStatus analyzeAssignmentStatus(PackUtilLANSync sync) {
        Map<String, String> assignments = new LinkedHashMap();
        Set<String> connectedPeers = new LinkedHashSet(sync.getConnectedClients().keySet());
        Map<String, String> missingAssignments = new LinkedHashMap(this.perUserAssignments).entrySet().iterator();
        while (missingAssignments.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)missingAssignments.next();
            String username = (String)entry.getKey();
            String macroName = (String)entry.getValue();
            while (!connectedPeers.contains(username)) {
            }
            if (macroName == null) continue;
            while (macroName.isBlank()) {
            }
            assignments.put(username, macroName);
        }
        missingAssignments = sync.getMissingAssignedMacros(assignments);
        return new PackUtilLANSyncOverlay.AssignmentSyncStatus(assignments, missingAssignments);
    }

    private LinkedHashSet<String> getShareableMissingMacros(PackUtilLANSyncOverlay.AssignmentSyncStatus status) {
        LinkedHashSet<String> shareable = new LinkedHashSet();
        var var3 = status.missingAssignments.values().iterator();
        while (var3.hasNext()) {
            String macroName = (String)var3.next();
            if (macroName == null) continue;
            while (macroName.isBlank()) {
            }
            if (PackUtilMacroManager.get().get(macroName) == null) continue;
            shareable.add(macroName);
        }
        return shareable;
    }

    private String formatNameSummary(List<String> names) {
        if (names == null || names.isEmpty()) {
            return "none";
        }
        return String.join(", ", names);
    }

    private String formatDifferenceSummary(Map<String, Integer> differences) {
        if (differences == null || differences.isEmpty()) {
            return "none";
        }
        List<String> parts = new ArrayList();
        var var3 = differences.entrySet().iterator();
        while (var3.hasNext()) {
            Map.Entry<String, Integer> entry = (Map.Entry)var3.next();
            int diffCount = Math.max(1, ((Integer)entry.getValue()).intValue());
            parts.add((String)entry.getKey() + " (+" + diffCount + ")");
        }
        return String.join(", ", parts);
    }

    private String formatMissingAssignmentsSummary(Map<String, String> missingAssignments) {
        if (missingAssignments == null || missingAssignments.isEmpty()) {
            return "none";
        }
        List<String> parts = new ArrayList();
        var var3 = missingAssignments.entrySet().iterator();
        while (var3.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var3.next();
            parts.add((String)entry.getKey() + "=" + (String)entry.getValue());
        }
        return String.join(", ", parts);
    }

    private int renderPickerRowClipped(class_332 ctx, int mx, int my, int cy, int detailLx, int detailRx, int rowW, String macroName, String assigned, String badge, String peerKey, PackUtilLANSync sync, boolean allowImport, int clipTop, int clipBottom, int rowPitch) {
        boolean isCurrent = macroName.equals(assigned);
        int importW = allowImport ? 42 : 0;
        int assignW = Math.max(24, detailRx - (detailLx - 2) - importW - 2);
        boolean rowVisible = cy + rowPitch > clipTop && cy < clipBottom;
        if (!rowVisible) {
            return cy + rowPitch;
        }
        int drawY = Math.max(cy, clipTop);
        int drawH = Math.min(cy + rowPitch, clipBottom) - drawY;
        if (drawH <= 0) {
            return cy + rowPitch;
        }
        boolean mHov = this.isHovered(mx, my, detailLx - 2, cy, assignW, rowPitch);
        PackUiListRenderer.drawRow(ctx, this.textRenderer, "", detailLx - 2, drawY, detailRx - (detailLx - 2), drawH, mHov, isCurrent, badge != null ? PackUiListRenderer.RowTone.WARNING : PackUiListRenderer.RowTone.NORMAL);
        int tx = detailLx;
        int nameMaxW = Math.max(24, detailRx - tx - importW - (badge != null ? 74 : 4));
        String displayName = PackUtilText.trimToWidth(this.textRenderer, macroName, nameMaxW, PackUtilText.Tone.BODY);
        int textY = Math.max(cy + 3, clipTop + 1);
        if (textY >= clipBottom - 2) { /* goto L278; */ }
        PackUiText.draw(ctx, this.textRenderer, displayName, PACKUI_THEME.fontFor(PackUiTone.BODY), isCurrent ? PackUtilColors.rowSelectedText() : -1, tx, textY, false);
        L278: ;
        if (badge == null) { /* goto L346; */ }
        if (textY >= clipBottom - 2) { /* goto L346; */ }
        int badgeX = tx + PackUiText.width(this.textRenderer, displayName, PACKUI_THEME.fontFor(PackUiTone.BODY), isCurrent ? PackUtilColors.rowSelectedText() : -1) + 4;
        this.drawUiText(ctx, badge, PackUiTone.MUTED, -22016, badgeX, textY);
        L346: ;
        mName = macroName;
        if (rowVisible) {
            this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(detailLx - 2, cy, assignW, rowPitch, this::lambda$renderPickerRowClipped$29 /* captured: peerKey, mName, sync */));
        }
        if (allowImport) {
            int importX = detailRx - importW + 2;
            int importY = Math.max(cy + 1, clipTop + 1);
            if (importY < clipBottom - 4) {
                this.drawOverlayButton(ctx, importX, importY, importW - 4, Math.min(rowPitch - 2, clipBottom - importY - 1), "Import", PackUiOverlayButton.Variant.SECONDARY, true, mx, my);
            }
            if (rowVisible) {
                this.clickRegions.add(new PackUtilLANSyncOverlay.ClickRegion(importX, cy, importW - 4, rowPitch, PackUtilLANSyncOverlay::lambda$renderPickerRowClipped$30 /* captured: sync, peerKey, mName */));
            }
        }
        return cy + rowPitch;
    }

    private static int countActionDifferences(PackUtilMacro a, PackUtilMacro b) {
        if (a == null || b == null) {
            return -1;
        }
        List<MacroAction> aActions = a.actions != null ? a.actions : Collections.emptyList();
        List<MacroAction> bActions = b.actions != null ? b.actions : Collections.emptyList();
        int diffs = 0;
        int maxLen = Math.max(aActions.size(), bActions.size());
        for (int i = 0; i < maxLen; i++) {
            if (i >= aActions.size() || i >= bActions.size()) {
                diffs++;
            } else {
                class_2487 tagA = ((MacroAction)aActions.get(i)).toTag();
                class_2487 tagB = ((MacroAction)bActions.get(i)).toTag();
                if (tagA.equals(tagB)) continue;
                diffs++;
            }
        }
        return diffs;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        if (button != 0) { /* goto L171; */ }
        if (mouseX < (double)this.panelX) { /* goto L171; */ }
        if (mouseX > (double)(this.panelX + this.PANEL_WIDTH)) { /* goto L171; */ }
        if (mouseY < (double)this.panelY) { /* goto L171; */ }
        if (mouseY > (double)(this.panelY + 16)) { /* goto L171; */ }
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.collapsed ? 16 : this.getPanelHeight(), this.visible, this.collapsed);
        if (this.isOverCollapseButton(mouseX, mouseY, bounds)) {
            this.toggleCollapsed();
            return true;
        }
        if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
            this.setVisible(false);
            return true;
        }
        this.isDragging = true;
        this.dragOffsetX = mouseX - (double)this.panelX;
        this.dragOffsetY = mouseY - (double)this.panelY;
        return true;
        L171: ;
        if (this.collapsed) {
            return false;
        }
        if (this.lanChatField != null) {
            click = new class_11909(mouseX, mouseY, new class_11910(button, 0));
            if (this.lanChatField.mouseClicked(click, false)) {
                this.lanChatField.setFocused(true);
                return true;
            }
            this.lanChatField.setFocused(false);
        }
        sync = PackUtilLANSync.getInstance();
        if (button == 0) {
            if (this.hasScrollableSessionContent(sync)) {
                int panelHeight = this.getPanelHeight();
                int tabContentY = this.getTabContentY();
                int tabContentH = this.getTabContentHeight(panelHeight);
                Metrics scrollbarMetrics = this.getContentScrollbarMetrics(tabContentY, tabContentH);
                if (scrollbarMetrics.hasScroll()) {
                    if (scrollbarMetrics.contains(mouseX, mouseY)) {
                        this.scrollbarDragging = true;
                        this.scrollbarGrabOffset = Math.max(0, (int)Math.round(mouseY) - scrollbarMetrics.thumbY());
                        this.scrollOffset = PackUiScrollbar.scrollFromThumb(scrollbarMetrics, (double)(int)Math.round(mouseY), this.scrollbarGrabOffset);
                        this.contentScrollState.jumpTo(this.scrollOffset, scrollbarMetrics.maxScroll());
                        this.saveState();
                        return true;
                    }
                }
            }
        }
        if (button != 0) { /* goto L485; */ }
        if (this.activeTab != 2) { /* goto L485; */ }
        if (this.perUserMode) { /* goto L485; */ }
        if (!this.hasSameMacroListViewport()) { /* goto L485; */ }
        if (!this.sameMacroList.contains(mouseX, mouseY)) { /* goto L485; */ }
        if (!this.sameMacroList.mouseClicked(mouseX, mouseY, button)) { /* goto L485; */ }
        if (this.sameMacroList.isScrollbarDragging()) { /* goto L483; */ }
        selected = (PackUtilMacro)this.sameMacroList.getSelectedItem();
        if (selected == null) { /* goto L483; */ }
        this.selectedMacroName = selected.name.equals(this.selectedMacroName) ? null : selected.name;
        this.saveState();
        return true;
        if (button == 0 && this.activeTab == 2 && this.perUserMode && this.hasPerUserListViewport() && this.perUserListViewport.contains(mouseX, mouseY) && this.perUserListViewport.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (button != 0) { /* goto L603; */ }
        selected = this.clickRegions.iterator();
        while (selected.hasNext()) {
            region = (PackUtilLANSyncOverlay.ClickRegion)selected.next();
            if (region.contains(mouseX, mouseY)) {
                region.action.run();
                return true;
            }
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (this.hasSameMacroListViewport()) {
                this.sameMacroList.mouseReleased();
            }
            if (this.hasPerUserListViewport()) {
                this.perUserListViewport.mouseReleased();
            }
            if (this.scrollbarDragging) {
                this.saveState();
            }
            this.scrollbarDragging = false;
            if (this.isDragging || this.isResizing) {
                this.saveState();
            }
            this.isDragging = false;
            this.isResizing = false;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.scrollbarDragging) {
            int panelHeight = this.getPanelHeight();
            int tabContentY = this.getTabContentY();
            int tabContentH = this.getTabContentHeight(panelHeight);
            Metrics scrollbarMetrics = this.getContentScrollbarMetrics(tabContentY, tabContentH);
            this.scrollOffset = PackUiScrollbar.scrollFromThumb(scrollbarMetrics, (double)(int)Math.round(mouseY), this.scrollbarGrabOffset);
            this.contentScrollState.jumpTo(this.scrollOffset, scrollbarMetrics.maxScroll());
            return true;
        }
        this.sameMacroList.mouseDragged(mouseX, mouseY);
        if (this.hasSameMacroListViewport() && this.sameMacroList.isScrollbarDragging()) {
            return true;
        }
        this.perUserListViewport.mouseDragged(mouseX, mouseY);
        if (this.hasPerUserListViewport() && this.perUserListViewport.isScrollbarDragging()) {
            return true;
        }
        if (this.isResizing) {
            nextBounds = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.resizeStartWidth + (int)Math.round(mouseX - this.resizeStartMouseX), this.resizeStartHeight + (int)Math.round(mouseY - this.resizeStartMouseY), this.visible, this.collapsed));
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.PANEL_WIDTH = nextBounds.width;
            this.PANEL_HEIGHT = nextBounds.height;
            return true;
        }
        if (this.isDragging) {
            nextBounds = this.clampToScreen(this, new PackUtilWindowLayout((int)(mouseX - this.dragOffsetX), (int)(mouseY - this.dragOffsetY), this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed));
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            return true;
        }
        return false;
    }

    public boolean keyPressed(int key, int scancode, int modifiers) {
        if (this.lanChatField != null) {
            if (this.lanChatField.isFocused()) {
                if (key == 256) {
                    this.lanChatField.setFocused(false);
                    return true;
                }
                this.lanChatField.keyPressed(new class_11908(key, scancode, modifiers));
                return true;
            }
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible || this.collapsed || !this.isMouseOver(mouseX, mouseY)) {
            return false;
        }
        if (this.activeTab == 2 && !this.perUserMode && this.hasSameMacroListViewport()) {
            return this.sameMacroList.mouseScrolled(mouseX, mouseY, amount);
        }
        if (this.activeTab == 2 && this.perUserMode && this.hasPerUserListViewport()) {
            return this.perUserListViewport.mouseScrolled(mouseX, mouseY, amount);
        }
        this.scrollOffset = Math.max(0, Math.min(this.maxScroll, this.scrollOffset - (int)(amount * 14)));
        this.saveState();
        return true;
    }

    public boolean charTyped(char chr, int modifiers) {
        if (this.lanChatField != null && this.lanChatField.isFocused()) {
            return this.lanChatField.charTyped(new class_11905(chr, modifiers));
        }
        return false;
    }

    private boolean isHovered(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int getSyncStateColor(PackUtilLANSync.SyncState state) {
        switch (PackUtilLANSyncOverlay.1.$SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[state.ordinal()]) {
            case 1::
                return PackUtilColors.textDim();
            case 2::
                return -22016;
            case 3::
                return -11141291;
            case 4::
                return -11141121;
            case 5::
                return -11141291;
            case 6::
                return -22016;
            case 7::
                return -11141291;
            default:
                return PackUtilColors.textSecondary();
        }
    }

    private String formatSyncState(PackUtilLANSync.SyncState state, PackUtilLANSync sync) {
        switch (PackUtilLANSyncOverlay.1.$SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[state.ordinal()]) {
            case 1::
                return "Idle";
            case 2::
                int ready = 0;
                int total = sync.getConnectedCount();
                return "Preparing (" + ready + "/" + total + " ready)";
            case 3::
                return "All Ready!";
            case 4::
                return "GO!";
            case 5::
                return "Executing...";
            case 6::
                return "Collecting results...";
            case 7::
                return "Done";
            default:
                return state.name();
        }
    }

    private int getSpreadColor(double spreadMs) {
        if (spreadMs <= 1) {
            return -11141291;
        }
        if (spreadMs <= 5) {
            return -22016;
        }
        return -43691;
    }

    private void applyPresetMetrics() {
        this.PANEL_BASE_WIDTH = 292;
        this.TAB_HEIGHT = 16;
        this.BUTTON_HEIGHT = 16;
        this.ROW_HEIGHT = 14;
        this.CONTENT_PADDING = 8;
        this.CHAT_FIELD_HEIGHT = 16;
        this.CHAT_AREA_HEIGHT = this.CHAT_FIELD_HEIGHT + 10;
    }

    private int minimumPanelHeight() {
        return 140;
    }

    private int defaultPanelHeight() {
        return 220;
    }

    static {
        String[] tmp0 = new String[4];
        tmp0[0] = "Info";
        tmp0[1] = "Peers";
        tmp0[2] = "Macros";
        tmp0[3] = "Queue";
        TAB_NAMES = tmp0;
    }
}
