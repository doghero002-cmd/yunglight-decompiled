/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilMacroEditorOverlay.StepRowMotionKind {
    public static final PackUtilMacroEditorOverlay.StepRowMotionKind ENTER = new PackUtilMacroEditorOverlay.StepRowMotionKind("ENTER", 0);
    public static final PackUtilMacroEditorOverlay.StepRowMotionKind MOVE = new PackUtilMacroEditorOverlay.StepRowMotionKind("MOVE", 1);
    public static final PackUtilMacroEditorOverlay.StepRowMotionKind EXIT = new PackUtilMacroEditorOverlay.StepRowMotionKind("EXIT", 2);
    private static final /* synthetic */ PackUtilMacroEditorOverlay.StepRowMotionKind[] $VALUES;

    public static PackUtilMacroEditorOverlay.StepRowMotionKind[] values() {
        return (PackUtilMacroEditorOverlay.StepRowMotionKind[])$VALUES.clone();
    }

    public static PackUtilMacroEditorOverlay.StepRowMotionKind valueOf(String name) {
        return (PackUtilMacroEditorOverlay.StepRowMotionKind)Enum.valueOf(PackUtilMacroEditorOverlay.StepRowMotionKind.class, name);
    }

    private PackUtilMacroEditorOverlay.StepRowMotionKind() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilMacroEditorOverlay.StepRowMotionKind.$values();
    }
}
