/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketLoggerOverlay;
import java.util.Locale;
import net.minecraft.class_2596;

public static class PackUtilPacketLoggerOverlay.LogEntry {
    public final long id;
    public final long timestampMs;
    public final int gameTick;
    public final String direction;
    public final String shortName;
    public final String searchKey;
    public final String groupKey;
    public final Class<?> packetClass;
    public final class_2596<?> packetRef;
    public final boolean isInventory;
    public final boolean isMovement;
    public final String capturedBlockState;
    public final String capturedScreen;

    public PackUtilPacketLoggerOverlay.LogEntry(long ts, int tick, String dir, String name, Class<?> cls, class_2596<?> ref, boolean inv, boolean mov, String capturedBlockState, String capturedScreen) {
        PackUtilPacketLoggerOverlay.idCounter = PackUtilPacketLoggerOverlay.idCounter + 1L;
        PackUtilPacketLoggerOverlay.idCounter.id = this;
        this.timestampMs = ts;
        this.gameTick = tick;
        this.direction = dir;
        this.shortName = name;
        this.searchKey = name == null ? "" : name.toLowerCase(Locale.ROOT);
        this.groupKey = dir + ":" + name;
        this.packetClass = cls;
        this.packetRef = ref;
        this.isInventory = inv;
        this.isMovement = mov;
        this.capturedBlockState = capturedBlockState;
        this.capturedScreen = capturedScreen;
        return;
        /* note: operand stack not empty at end: 1 values */
    }
}
