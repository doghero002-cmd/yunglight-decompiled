/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilServerInfoOverlay;

private static final class PackUtilServerInfoOverlay.PluginListRow {
    final boolean header;
    final String title;
    final String plugin;
    final PackUtilServerInfoOverlay.PluginEvidence evidence;

    private PackUtilServerInfoOverlay.PluginListRow(boolean header, String title, String plugin, PackUtilServerInfoOverlay.PluginEvidence evidence) {
        this.header = header;
        this.title = title;
        this.plugin = plugin;
        this.evidence = evidence;
    }

    static PackUtilServerInfoOverlay.PluginListRow header(String title) {
        return new PackUtilServerInfoOverlay.PluginListRow(true, title, null, PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN);
    }

    static PackUtilServerInfoOverlay.PluginListRow plugin(String plugin, PackUtilServerInfoOverlay.PluginEvidence evidence) {
        return new PackUtilServerInfoOverlay.PluginListRow(false, null, plugin, evidence);
    }
}
