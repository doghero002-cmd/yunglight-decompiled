/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPresetManager;

private static final class PackUtilCustomFilterPresetOverlay.PresetRow {
    private final boolean header;
    private final boolean note;
    private final String label;
    private final PackUtilPresetManager.PresetEntry entry;

    private PackUtilCustomFilterPresetOverlay.PresetRow(boolean header, boolean note, String label, PackUtilPresetManager.PresetEntry entry) {
        this.header = header;
        this.note = note;
        this.label = label;
        this.entry = entry;
    }

    private static PackUtilCustomFilterPresetOverlay.PresetRow header(String label) {
        return new PackUtilCustomFilterPresetOverlay.PresetRow(true, false, label, null);
    }

    private static PackUtilCustomFilterPresetOverlay.PresetRow note(String label) {
        return new PackUtilCustomFilterPresetOverlay.PresetRow(false, true, label, null);
    }

    private static PackUtilCustomFilterPresetOverlay.PresetRow entry(PackUtilPresetManager.PresetEntry entry) {
        return new PackUtilCustomFilterPresetOverlay.PresetRow(false, false, null, entry);
    }
}
