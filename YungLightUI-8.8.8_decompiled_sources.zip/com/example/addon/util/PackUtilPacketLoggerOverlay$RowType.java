/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

static enum PackUtilPacketLoggerOverlay.RowType {
    public static final PackUtilPacketLoggerOverlay.RowType ENTRY = new PackUtilPacketLoggerOverlay.RowType("ENTRY", 0);
    public static final PackUtilPacketLoggerOverlay.RowType GROUP = new PackUtilPacketLoggerOverlay.RowType("GROUP", 1);
    private static final /* synthetic */ PackUtilPacketLoggerOverlay.RowType[] $VALUES;

    public static PackUtilPacketLoggerOverlay.RowType[] values() {
        return (PackUtilPacketLoggerOverlay.RowType[])$VALUES.clone();
    }

    public static PackUtilPacketLoggerOverlay.RowType valueOf(String name) {
        return (PackUtilPacketLoggerOverlay.RowType)Enum.valueOf(PackUtilPacketLoggerOverlay.RowType.class, name);
    }

    private PackUtilPacketLoggerOverlay.RowType() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilPacketLoggerOverlay.RowType.$values();
    }
}
