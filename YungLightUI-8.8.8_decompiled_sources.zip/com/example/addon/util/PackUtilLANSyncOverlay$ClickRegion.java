/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static class PackUtilLANSyncOverlay.ClickRegion {
    final int x;
    final int y;
    final int width;
    final int height;
    final Runnable action;

    PackUtilLANSyncOverlay.ClickRegion(int x, int y, int width, int height, Runnable action) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.action = action;
    }

    boolean contains(double mx, double my) {
        return mx >= (double)this.x && mx < (double)(this.x + this.width) && my >= (double)this.y && my < (double)(this.y + this.height);
    }
}
