/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2820;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_7923;

public class NbtBookAction
implements MacroAction {
    public int pages = 100;
    public String title = "EldenRingLore";
    public boolean onlyAscii = false;
    public String customText = "";
    public int delayTicks = 20;
    public int bookCount = 1;
    private boolean enabled = true;
    public transient String pasteInfo = "";
    private static final int MAX_PAGES = 100;
    private static final int LINES_PER_PAGE = 14;
    private static final float LINE_WIDTH_PX = 114f;

    public boolean executeSingleBook(class_310 mc, int bookIndex, int totalBooks) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo player or network connection!");
            return false;
        }
        int bookSlot = this.findWritableBook(mc);
        if (bookSlot >= 0) { /* goto L56; */ }
        if (bookIndex == 0) {
            PackUtilClientMessaging.sendPrefixed("§cNo Book & Quill found in inventory!");
        } else {
            PackUtilClientMessaging.sendPrefixed("§eRan out of books after " + bookIndex + " signed.");
        }
        return false;
        L56: ;
        int hotbarSlot = bookSlot;
        if (bookSlot <= 8) { /* goto L124; */ }
        int targetHotbar = 0;
        int i = 0;
        while (i <= 8) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960()) {
                targetHotbar = i;
            } else {
                i++;
            }
        }
        PackUtilInventoryHelper.swapInventorySlots(mc, bookSlot, targetHotbar);
        hotbarSlot = targetHotbar;
        L124: ;
        PackUtilInventoryHelper.selectHotbarSlot(mc, hotbarSlot);
        numPages = Math.min(100, Math.max(1, this.pages));
        if (!this.customText.isEmpty()) {
            pageList = NbtBookAction.splitTextIntoPages(mc.field_1772, this.customText, numPages);
        } else {
            pageList = this.generatePages(mc, numPages);
        }
        String bookTitle = this.title;
        if (totalBooks > 1) {
            if (bookIndex > 0) {
                bookTitle = this.title + " #" + bookIndex + 1;
            }
        }
        mc.method_1562().method_52787(new class_2820(hotbarSlot, pageList, Optional.of(bookTitle)));
        int estimatedBytes = this.estimateBytes(pageList);
        PackUtilClientMessaging.sendPrefixed("§aSigned book " + bookIndex + 1 + "/" + totalBooks + " (~" + estimatedBytes / 1024 + "KB, " + pageList.size() + " pages)");
        return true;
    }

    public void execute(class_310 mc) {
        this.executeSingleBook(mc, 0, 1);
    }

    private int findWritableBook(class_310 mc) {
        if (mc.field_1724 == null) {
            return -1;
        }
        class_2960 writableBookId = class_2960.method_60655("minecraft", "writable_book");
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() && class_7923.field_41178.method_10221(stack.method_7909()).equals(writableBookId)) continue;
            return i;
        }
        return -1;
    }

    public static List<String> splitTextIntoPages(class_327 tr, String text, int maxPages) {
        if (text == null || text.isEmpty()) {
            return new ArrayList(List.of(""));
        }
        String[] paragraphs = text.split("\n", -1);
        List<String> visualLines = new ArrayList();
        List<String> pages = paragraphs;
        StringBuilder page = pages.length;
        for (int linesOnPage = 0; linesOnPage < page; linesOnPage++) {
            String para = pages[linesOnPage];
            if (para.isEmpty()) {
                visualLines.add("");
            } else {
                NbtBookAction.wrapParagraph(tr, para, visualLines);
            }
        }
        pages = new ArrayList();
        page = new StringBuilder();
        linesOnPage = 0;
        para = visualLines.iterator();
        while (para.hasNext()) {
            String line = (String)para.next();
            if (linesOnPage >= 14) {
                pages.add(page.toString());
                if (!pages.size() >= maxPages) continue;
                return pages;
                page = new StringBuilder();
                linesOnPage = 0;
            }
            if (!linesOnPage > 0) continue;
            page.append(10);
            page.append(line);
            linesOnPage++;
        }
        if (page.length() > 0) {
            pages.add(page.toString());
        }
        if (pages.isEmpty()) {
            pages.add("");
        }
        return pages;
    }

    private static void wrapParagraph(class_327 tr, String para, List<String> out) {
        int idx = 0;
        while (idx < para.length()) {
            float width = 0f;
            int lineEnd = idx;
            int lastSpace = -1;
            while (lineEnd < para.length()) {
                char c = para.charAt(lineEnd);
                float cw = (float)tr.method_1727(String.valueOf(c));
                if (width + cw > 114f) {
                } else {
                    if (c != 32) continue;
                    lastSpace = lineEnd;
                    width = width + cw;
                    lineEnd++;
                }
            }
            if (lineEnd >= para.length()) {
                out.add(para.substring(idx));
                return;
            }
            if (lastSpace > idx) {
                out.add(para.substring(idx, lastSpace));
                idx = lastSpace + 1;
            } else {
                out.add(para.substring(idx, lineEnd));
                idx = lineEnd;
            }
        }
    }

    public static int calculatePagesNeeded(class_327 tr, String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        return NbtBookAction.splitTextIntoPages(tr, text, 100).size();
    }

    private List<String> generatePages(class_310 mc, int numPages) {
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        List<String> result = new ArrayList(numPages);
        if (this.onlyAscii) {
            OfInt chars = rng.ints(33, 127).filter(NbtBookAction::lambda$generatePages$0).iterator();
            for (int p = 0; p < numPages; p++) {
                if (!chars.hasNext()) break;
                StringBuilder page = new StringBuilder();
                for (int line = 0; line < 14; line++) {
                    if (!chars.hasNext()) break;
                    if (!line > 0) continue;
                    page.append(10);
                    float lineWidth = 0f;
                    while (chars.hasNext()) {
                        int c = chars.nextInt();
                        float cw = (float)mc.field_1772.method_1727(Character.toString((char)c));
                        if (!cw <= 0f) continue;
                        cw = 6f;
                        if (lineWidth + cw > 114f) {
                        } else {
                            lineWidth = lineWidth + cw;
                            page.append((char)c);
                        }
                    }
                }
                result.add(page.toString());
            }
        } else {
            int charsPerPage = 512;
            int charsPerLine = charsPerPage / 14;
            int remainder = charsPerPage % 14;
            OfInt chars = rng.ints(2048, 65536).filter(NbtBookAction::lambda$generatePages$1).iterator();
            for (int p = 0; p < numPages; p++) {
                if (!chars.hasNext()) break;
                StringBuilder page = new StringBuilder();
                for (int line = 0; line < 14; line++) {
                    if (!chars.hasNext()) break;
                    if (!line > 0) continue;
                    page.append(10);
                    int lineMax = charsPerLine + (line < remainder ? 1 : 0);
                    for (int ci = 0; ci < lineMax; ci++) {
                        if (!chars.hasNext()) break;
                        page.append((char)chars.nextInt());
                    }
                }
                result.add(page.toString());
            }
        }
        return result;
    }

    private int estimateBytes(List<String> pageList) {
        int bytes = 0;
        var var3 = pageList.iterator();
        while (var3.hasNext()) {
            String page = (String)var3.next();
            for (int i = 0; i < page.length(); i++) {
                char c = page.charAt(i);
                if (c < 128) {
                    bytes++;
                } else {
                    if (c < 2048) {
                        bytes += 2;
                    } else {
                        bytes += 3;
                    }
                }
            }
        }
        return bytes;
    }

    public MacroActionType getType() {
        return MacroActionType.NBT_BOOK;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("pages", this.pages);
        tag.method_10582("title", this.title);
        tag.method_10556("onlyAscii", this.onlyAscii);
        tag.method_10582("customText", this.customText);
        tag.method_10569("delayTicks", this.delayTicks);
        tag.method_10569("bookCount", this.bookCount);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("pages")) {
            this.pages = tag.method_68083("pages", 100);
        } else {
            if (tag.method_10545("targetSizeKB")) {
                this.pages = Math.min(100, tag.method_68083("targetSizeKB", 150));
            }
        }
        if (tag.method_10545("title")) {
            this.title = tag.method_68564("title", "EldenRingLore");
        }
        if (tag.method_10545("onlyAscii")) {
            this.onlyAscii = tag.method_68566("onlyAscii", false);
        }
        if (tag.method_10545("customText")) {
            this.customText = tag.method_68564("customText", "");
        }
        if (tag.method_10545("delayTicks")) {
            this.delayTicks = tag.method_68083("delayTicks", 20);
        }
        if (tag.method_10545("bookCount")) {
            this.bookCount = tag.method_68083("bookCount", 1);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        String mode = this.customText.isEmpty() ? this.onlyAscii ? "ASCII" : "Random" : "Custom";
        String count = this.bookCount > 1 ? ", x" + this.bookCount : "";
        return "NBT Book (" + this.pages + "pg, " + mode + count + ")";
    }

    public String getIcon() {
        return "B";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
