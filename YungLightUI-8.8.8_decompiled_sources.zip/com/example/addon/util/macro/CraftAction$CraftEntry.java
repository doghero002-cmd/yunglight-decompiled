/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilCraftingHelper;
import net.minecraft.class_2487;

public static final class CraftAction.CraftEntry {
    public int recipeId = -1;
    public String recipeKey = "";
    public String resultName = "";
    public int resultCount = 1;
    public int amount = 1;
    public boolean useMaxAmount = false;

    public CraftAction.CraftEntry copy() {
        CraftEntry copy = new CraftAction.CraftEntry();
        copy.recipeId = this.recipeId;
        copy.recipeKey = this.recipeKey;
        copy.resultName = this.resultName;
        copy.resultCount = this.resultCount;
        copy.amount = this.amount;
        copy.useMaxAmount = this.useMaxAmount;
        return copy;
    }

    public boolean hasRecipe() {
        if (this.resultName.isBlank()) { /* goto @31; */ }
        return this.recipeId >= 0 || !this.recipeKey.isBlank();
    }

    public String getDisplayName() {
        if (!this.hasRecipe()) {
            return "unset";
        }
        return this.useMaxAmount ? this.resultName + " [Max]" : this.resultName + " x" + Math.max(1, this.amount);
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10569("recipeId", this.recipeId);
        tag.method_10582("recipeKey", this.recipeKey == null ? "" : this.recipeKey);
        tag.method_10582("resultName", this.resultName == null ? "" : this.resultName);
        tag.method_10569("resultCount", Math.max(1, this.resultCount));
        tag.method_10569("amount", Math.max(1, this.amount));
        tag.method_10556("useMaxAmount", this.useMaxAmount);
        return tag;
    }

    public static CraftAction.CraftEntry fromTag(class_2487 tag) {
        CraftEntry entry = new CraftAction.CraftEntry();
        if (tag == null) {
            return entry;
        }
        entry.recipeId = tag.method_68083("recipeId", -1);
        entry.recipeKey = tag.method_68564("recipeKey", "");
        entry.resultName = tag.method_68564("resultName", "");
        entry.resultCount = Math.max(1, tag.method_68083("resultCount", 1));
        entry.amount = Math.max(1, tag.method_68083("amount", 1));
        entry.useMaxAmount = tag.method_68566("useMaxAmount", false);
        return entry;
    }

    public static CraftAction.CraftEntry fromOption(PackUtilCraftingHelper.CraftableRecipeOption option, int amount, boolean useMaxAmount) {
        CraftEntry entry = new CraftAction.CraftEntry();
        if (option == null) {
            return entry;
        }
        entry.recipeId = option.recipeId;
        entry.recipeKey = option.recipeKey;
        entry.resultName = option.label;
        entry.resultCount = Math.max(1, option.result.method_7947());
        entry.amount = Math.max(1, amount);
        entry.useMaxAmount = useMaxAmount;
        return entry;
    }
}
