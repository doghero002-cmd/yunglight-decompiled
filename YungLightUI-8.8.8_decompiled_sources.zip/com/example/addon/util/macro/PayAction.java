/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class PayAction
implements MacroAction {
    public String commandTemplate = "/pay <player> <amount>";
    public String amountInput = "1";
    public int delayMs = 1000;
    public boolean delayEnabled = true;
    public List<String> players = new ArrayList();
    private boolean enabled = true;

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("commandTemplate", this.commandTemplate);
        tag.method_10582("amountInput", this.amountInput);
        tag.method_10569("delayMs", PayAction.normalizeDelay(this.delayMs));
        tag.method_10556("delayEnabled", this.delayEnabled);
        class_2499 list = new class_2499();
        var var3 = this.players.iterator();
        while (var3.hasNext()) {
            String player = (String)var3.next();
            if (player != null) {
                if (player.isBlank()) continue;
                list.add(class_2519.method_23256(player));
            }
        }
        tag.method_10566("players", list);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("commandTemplate")) {
            this.commandTemplate = tag.method_68564("commandTemplate", this.commandTemplate);
        }
        if (tag.method_10545("amountInput")) {
            this.amountInput = tag.method_68564("amountInput", this.amountInput);
        }
        if (tag.method_10545("delayMs")) {
            this.delayMs = PayAction.normalizeDelay(tag.method_68083("delayMs", 1000));
        }
        if (tag.method_10545("delayEnabled")) {
            this.delayEnabled = tag.method_68566("delayEnabled", true);
        }
        this.players.clear();
        if (!tag.method_10545("players")) { /* goto L211; */ }
        class_2499 list = (class_2499)tag.method_10554("players").orElse(new class_2499());
        var var3 = list.iterator();
        while (var3.hasNext()) {
            class_2520 element = (class_2520)var3.next();
            String value = ((String)element.method_68658().orElse("")).trim();
            if (!value.isEmpty()) {
                if (this.players.contains(value)) continue;
                this.players.add(value);
            }
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.PAY;
    }

    public String getDisplayName() {
        String target = this.players.isEmpty() ? "no players" : this.players.size() == 1 ? (String)this.players.get(0) : this.players.size() + " players";
        String amount = this.amountInput == null || this.amountInput.isBlank() ? "?" : this.amountInput.trim();
        return "Pay " + target + " " + amount;
    }

    public String getIcon() {
        return "$";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public long resolvedAmount() {
        return PayAction.parseAmount(this.amountInput);
    }

    public long totalAmount() {
        return this.resolvedAmount() * (long)Math.max(0, this.players.size());
    }

    public static int normalizeDelay(int delayMs) {
        return Math.max(0, delayMs);
    }

    public static long parseAmount(String input) {
        if (input == null) {
            return 0L;
        }
        String normalized = input.trim().replace(" ", "").replace("_", "");
        if (normalized.isEmpty()) {
            return 0L;
        }
        char suffix = Character.toUpperCase(normalized.charAt(normalized.length() - 1));
        BigDecimal multiplier = BigDecimal.ONE;
        if (suffix != 75) {
            if (suffix == 77) { /* goto @70; */ }
        }
        normalized = normalized.substring(0, normalized.length() - 1);
        switch (suffix) {
            case 75::
                multiplier = new BigDecimal("1000");
                break;
            case 77::
                multiplier = new BigDecimal("1000000");
                break;
            case 66::
                multiplier = new BigDecimal("1000000000");
                break;
            default:
                multiplier = BigDecimal.ONE;
                break;
        }
        if (normalized.contains(",")) {
            if (normalized.contains(".")) {
                normalized = normalized.replace(",", "");
            }
        } else {
            if (normalized.contains(",")) {
                normalized = normalized.replace(44, 46);
            }
        }
        if (normalized.isEmpty() || normalized.equals(".")) {
            return 0L;
        }
        try {
            BigDecimal value = new BigDecimal(normalized);
            return value.multiply(multiplier).setScale(0, RoundingMode.HALF_UP).longValue();
        }
        catch (NumberFormatException e) {
            return 0L;
        }
    }

    public static String formatAmount(long amount) {
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
        DecimalFormat format = new DecimalFormat("#,##0", symbols);
        return format.format(amount);
    }
}
