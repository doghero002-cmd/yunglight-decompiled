/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.WaitForSlotChangeAction;

public static class WaitForSlotChangeAction.WaitEntry {
    public String target = "";
    public ItemTarget itemTarget = new ItemTarget();
    public WaitForSlotChangeAction.WaitMode waitMode = WaitForSlotChangeAction.WaitMode.NOT_EMPTY;
    public int targetCount = 1;

    public WaitForSlotChangeAction.WaitEntry() {
    }

    public WaitForSlotChangeAction.WaitEntry(String target, WaitForSlotChangeAction.WaitMode waitMode, int targetCount) {
        this.target = target;
        this.itemTarget = ItemTarget.fromLegacyEntry(target);
        this.waitMode = waitMode;
        this.targetCount = targetCount;
    }

    public WaitForSlotChangeAction.WaitEntry copy() {
        WaitEntry copy = new WaitForSlotChangeAction.WaitEntry(this.target, this.waitMode, this.targetCount);
        copy.itemTarget = this.itemTarget == null ? new ItemTarget() : this.itemTarget.copy();
        return copy;
    }

    public String modeLabel() {
        switch (this.waitMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return "has";
            case 1::
                return "empty";
            case 2::
                return ">=" + this.targetCount;
            case 3::
                return "<" + this.targetCount;
            case 4::
                return "~";
        }
    }

    public void cycleMode() {
        WaitMode[] modes = WaitForSlotChangeAction.WaitMode.values();
        this.waitMode = modes[(this.waitMode.ordinal() + 1) % modes.length];
    }

    public ItemTarget resolvedTarget() {
        if (this.itemTarget != null) {
            if (this.itemTarget.hasSlot() || this.itemTarget.hasIdentity()) {
                return this.itemTarget;
            }
        }
        this.itemTarget = ItemTarget.fromLegacyEntry(this.target);
        return this.itemTarget;
    }
}
