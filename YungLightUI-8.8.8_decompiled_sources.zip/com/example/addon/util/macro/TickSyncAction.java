/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class TickSyncAction
implements MacroAction {
    public int tickOffset = 1;
    public int preGenCount = -1;

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("tickOffset", this.tickOffset);
        tag.method_10569("preGenCount", this.preGenCount);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.tickOffset = tag.method_68083("tickOffset", 1);
        this.preGenCount = tag.method_68083("preGenCount", -1);
    }

    public MacroActionType getType() {
        return MacroActionType.TICK_SYNC;
    }

    public String getDisplayName() {
        StringBuilder sb = new StringBuilder("Tick Sync");
        if (this.tickOffset > 0) {
            sb.append(" +").append(this.tickOffset);
        }
        if (this.preGenCount > 0) {
            sb.append(" (").append(this.preGenCount).append(" pkts)");
        } else {
            if (this.preGenCount == -1) {
                sb.append(" (all)");
            }
        }
        return sb.toString();
    }

    public String getIcon() {
        return "Tick";
    }
}
