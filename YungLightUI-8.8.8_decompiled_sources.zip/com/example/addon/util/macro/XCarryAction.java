/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilContainerTarget;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2815;
import net.minecraft.class_310;

public class XCarryAction
implements MacroAction {
    public static final int MAX_ENTRIES = 4;
    public final List<String> entries = new ArrayList();
    public final List<ItemTarget> entryTargets = new ArrayList();
    public XCarryAction.Mode mode = XCarryAction.Mode.PUT_IN;
    public XCarryAction.TransferMode transferMode = XCarryAction.TransferMode.FAST;
    private boolean enabled = true;

    public void execute(class_310 mc) {
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        if (mc.field_1724.field_7512 != mc.field_1724.field_7498) {
            this.executeWithContainerOpen(mc);
            return;
        }
        class_1723 handler = mc.field_1724.field_7498;
        if (!handler.method_34255().method_7960()) {
            return;
        }
        switch (this.mode.ordinal()) {
            case 0::
                this.executePutIn(handler, mc);
                /* goto @120; */
            case 1::
                this.executeTakeOut(handler, mc);
                /* goto @120; */
            case 2::
                this.executeDrop(handler, mc);
            default:
                return;
        }
    }

    private void executeWithContainerOpen(class_310 mc) {
        if (mc.method_1562() == null) {
            return;
        }
        PackUtilContainerTarget containerTarget = PackUtilSharedState.get().getLastContainerTarget();
        if (containerTarget == null) {
            return;
        }
        class_1723 playerHandler = mc.field_1724.field_7498;
        if (!playerHandler.method_34255().method_7960()) {
            return;
        }
        class_1703 containerHandler = mc.field_1724.field_7512;
        if (this.mode != XCarryAction.Mode.PUT_IN) { /* goto L236; */ }
        List<ItemTarget> targets = this.resolvedEntryTargets();
        int limit = Math.min(4, targets.size());
        for (int i = 0; i < limit; i++) {
            ItemTarget itemTarget = (ItemTarget)targets.get(i);
            if (itemTarget == null) { /* goto L230; */ }
            if (itemTarget.hasSlot()) { /* goto L230; */ }
            if (!itemTarget.hasIdentity()) {
            } else {
                var var9 = containerHandler.field_7761.iterator();
                while (var9.hasNext()) {
                    class_1735 slot = (class_1735)var9.next();
                    while (slot.method_7677().method_7960()) {
                    }
                    while (slot.field_7871 instanceof class_1661) {
                    }
                    if (!XCarryAction.matchesTarget(slot.method_7677(), itemTarget, -1)) { /* goto @227; */ }
                    mc.field_1761.method_2906(containerHandler.field_7763, slot.field_7874, 0, class_1713.field_7794, mc.field_1724);
                    break;
                }
            }
        }
        mc.method_1562().method_52787(new class_2815(containerHandler.field_7763));
        mc.field_1724.field_7512 = playerHandler;
        switch (this.mode.ordinal()) {
            case 0::
                this.executePutIn(playerHandler, mc);
                /* goto @320; */
            case 1::
                this.executeTakeOut(playerHandler, mc);
                /* goto @320; */
            case 2::
                this.executeDrop(playerHandler, mc);
            default:
                mc.field_1724.field_7512 = containerHandler;
                containerTarget.interact(mc);
                return;
        }
    }

    private void executePutIn(class_1723 handler, class_310 mc) {
        int moved = 0;
        L2: ;
        PutInMove move = this.findNextPutInMove(handler);
        if (move == null) {
        } else {
            while (XCarryAction.moveStack(handler, mc, move.sourceSlotId, move.targetSlotId)) {
                moved++;
            }
            if (!handler.method_34255().method_7960()) {
            } else {
                /* goto @2; */
            }
        }
        if (moved > 0 || XCarryAction.hasCraftingGridItems(handler)) {
            active = XCarryAction.hasCraftingGridItems(handler);
            PackUtilSharedState.get().setXCarryForced(active);
            PackUtilSharedState.get().setXCarryActive(active);
        }
    }

    private void executeTakeOut(class_1723 handler, class_310 mc) {
        for (int slotId = true; slotId <= 4; slotId++) {
            if (slotId >= handler.field_7761.size()) break;
            class_1735 slot = (class_1735)handler.field_7761.get(slotId);
            if (slot.method_7677().method_7960()) {
            } else {
                if (!this.entries.isEmpty() && !this.matchesCraftingSlot(slot, slotId)) {
                } else {
                    mc.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7794, mc.field_1724);
                }
            }
        }
        active = XCarryAction.hasCraftingGridItems(handler);
        PackUtilSharedState.get().setXCarryForced(active);
        PackUtilSharedState.get().setXCarryActive(active);
    }

    private void executeDrop(class_1723 handler, class_310 mc) {
        for (int slotId = true; slotId <= 4; slotId++) {
            if (slotId >= handler.field_7761.size()) break;
            class_1735 slot = (class_1735)handler.field_7761.get(slotId);
            if (slot.method_7677().method_7960()) {
            } else {
                if (!this.entries.isEmpty() && !this.matchesCraftingSlot(slot, slotId)) {
                } else {
                    mc.field_1761.method_2906(handler.field_7763, slotId, 1, class_1713.field_7795, mc.field_1724);
                }
            }
        }
        active = XCarryAction.hasCraftingGridItems(handler);
        PackUtilSharedState.get().setXCarryForced(active);
        PackUtilSharedState.get().setXCarryActive(active);
    }

    private boolean matchesCraftingSlot(class_1735 slot, int slotId) {
        var var3 = this.resolvedEntryTargets().iterator();
        while (var3.hasNext()) {
            ItemTarget entryTarget = (ItemTarget)var3.next();
            while (entryTarget == null) {
            }
            if (entryTarget.hasSlot()) {
                if (entryTarget.slot == slotId) {
                    if (!entryTarget.hasIdentity() || XCarryAction.matchesTarget(slot.method_7677(), entryTarget, slotId)) {
                        return true;
                        L78: ;
                        if (entryTarget.hasIdentity()) {
                            if (!XCarryAction.matchesTarget(slot.method_7677(), entryTarget, slotId)) continue;
                            return true;
                        }
                    }
                }
            }
            if (entryTarget.hasIdentity()) {
                if (!XCarryAction.matchesTarget(slot.method_7677(), entryTarget, slotId)) continue;
                return true;
            }
        }
        return false;
    }

    XCarryAction.PutInMove findNextPutInMove(class_1723 handler) {
        if (handler == null) {
            return null;
        }
        List<ItemTarget> targets = this.resolvedEntryTargets();
        int limit = Math.min(4, targets.size());
        int nextTarget = 1;
        for (int i = 0; i < limit; i++) {
            int sourceSlotId = XCarryAction.findSourceSlot(handler, (ItemTarget)targets.get(i));
            if (sourceSlotId < 0) {
            } else {
                while (nextTarget <= 4) {
                    if (((class_1735)handler.field_7761.get(nextTarget)).method_7677().method_7960()) break;
                    nextTarget++;
                }
                if (!nextTarget > 4) continue;
                return null;
                int targetSlotId = nextTarget++;
                if (sourceSlotId == targetSlotId) {
                } else {
                    return new XCarryAction.PutInMove(sourceSlotId, targetSlotId);
                }
            }
        }
        return null;
    }

    List<Integer> collectContainerTransferSlots(class_1703 containerHandler) {
        List<Integer> slotIds = new ArrayList();
        if (containerHandler == null) {
            return slotIds;
        }
        List<ItemTarget> targets = this.resolvedEntryTargets();
        int limit = Math.min(4, targets.size());
        for (int i = 0; i < limit; i++) {
            ItemTarget itemTarget = (ItemTarget)targets.get(i);
            if (itemTarget == null) { /* goto L172; */ }
            if (itemTarget.hasSlot()) { /* goto L172; */ }
            if (!itemTarget.hasIdentity()) {
            } else {
                var var7 = containerHandler.field_7761.iterator();
                L87: ;
                if (!var7.hasNext()) { /* goto @172; */ }
                class_1735 slot = (class_1735)var7.next();
                while (slot.method_7677().method_7960()) {
                }
                while (slot.field_7871 instanceof class_1661) {
                }
                while (!XCarryAction.matchesTarget(slot.method_7677(), itemTarget, -1)) {
                }
                slotIds.add(slot.field_7874);
                /* goto @172; */
            }
        }
        return slotIds;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", MacroActionType.XCARRY.name());
        tag.method_10582("mode", this.mode.name());
        tag.method_10582("transferMode", this.transferMode.name());
        List<ItemTarget> targets = this.resolvedEntryTargets();
        tag.method_10566("entries", ItemTarget.toTagList(targets.subList(0, Math.min(4, targets.size()))));
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.entries.clear();
        this.entryTargets.clear();
        String modeStr = tag.method_68564("mode", "PUT_IN");
        try {
            this.mode = XCarryAction.Mode.valueOf(modeStr);
        }
        catch (IllegalArgumentException e) {
            this.mode = XCarryAction.Mode.PUT_IN;
            L48: ;
            transferModeStr = tag.method_68564("transferMode", "FAST");
            this.transferMode = XCarryAction.TransferMode.valueOf(transferModeStr);
            /* goto @79; */
        }
        transferModeStr = tag.method_68564("transferMode", "FAST");
        try {
            this.transferMode = XCarryAction.TransferMode.valueOf(transferModeStr);
        }
        catch (IllegalArgumentException e) {
            this.transferMode = XCarryAction.TransferMode.FAST;
            L79: ;
            if (!tag.method_10545("entries")) { /* goto @200; */ }
            list = (class_2499)tag.method_10554("entries").orElse(new class_2499());
            var var5 = ItemTarget.fromElementList(list).iterator();
            L123: ;
            if (!var5.hasNext()) { /* goto @200; */ }
            ItemTarget target = (ItemTarget)var5.next();
            if (target == null) { /* goto L123; */ }
            while (!target.hasSlot()) {
                if (target.hasIdentity()) break;
            }
        }
        if (!tag.method_10545("entries")) { /* goto L200; */ }
        list = (class_2499)tag.method_10554("entries").orElse(new class_2499());
        var5 = ItemTarget.fromElementList(list).iterator();
        while (var5.hasNext()) {
            target = (ItemTarget)var5.next();
            if (target == null) continue;
            while (!target.hasSlot()) {
                if (target.hasIdentity()) break;
            }
            this.entryTargets.add(target);
            if (this.entryTargets.size() < 4) { /* goto @197; */ }
            break;
        }
        this.syncLegacyEntries();
        this.enabled = tag.method_68566("enabled", true);
    }

    public MacroActionType getType() {
        return MacroActionType.XCARRY;
    }

    public String getDisplayName() {
        switch (this.mode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                String prefix = this.transferMode == XCarryAction.TransferMode.CLICK ? "XCarry Click" : "XCarry";
                break;
            case 1::
                prefix = "XCarry Out";
                break;
            case 2::
                prefix = "XCarry Drop";
                break;
        }
        if (this.entries.isEmpty()) {
            return prefix;
        }
        String first = XCarryAction.formatEntry((String)this.entries.get(0));
        if (this.entries.size() > 1) {
            first = first + " (+" + this.entries.size() - 1 + ")";
        }
        return prefix + " [" + first + "]";
    }

    public String getIcon() {
        return "XC";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public static String normalizeEntry(String raw) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (!trimmed.startsWith("#")) {
            return trimmed;
        }
        int separator = trimmed.indexOf(124);
        String slotPart = separator >= 0 ? trimmed.substring(1, separator) : trimmed.substring(1);
        try {
            int slot = Integer.parseInt(slotPart.trim());
            if (slot < 0) {
                return null;
            }
        }
        catch (NumberFormatException ignored) {
            return null;
        }
        try {
            String name = separator >= 0 && separator + 1 < trimmed.length() ? trimmed.substring(separator + 1).trim() : "";
            if (!name.isEmpty()) {
                return "#" + slot + "|" + name;
            }
        }
        catch (NumberFormatException ignored) {
            return null;
        }
        try {
            return "#" + slot;
        }
        catch (NumberFormatException ignored) {
            return null;
        }
    }

    public static String formatEntry(String entry) {
        String normalized = XCarryAction.normalizeEntry(entry);
        if (normalized == null) {
            return "";
        }
        int slot = XCarryAction.parseEntrySlot(normalized);
        String name = XCarryAction.parseEntryName(normalized);
        if (slot >= 0 && !name.isEmpty()) {
            return name + " @ Slot " + slot;
        }
        if (slot >= 0) {
            return "Slot " + slot;
        }
        return normalized;
    }

    private static int findSourceSlot(class_1723 handler, ItemTarget target) {
        if (target == null) {
            return -1;
        }
        if (!target.hasSlot()) { /* goto L70; */ }
        int exactSlot = XCarryAction.resolvePlayerVisibleSlot(handler, target.slot);
        if (exactSlot < 0) {
            return -1;
        }
        if (!target.hasIdentity()) {
            return exactSlot;
        }
        class_1735 slot = (class_1735)handler.field_7761.get(exactSlot);
        return XCarryAction.matchesTarget(slot.method_7677(), target, target.slot) ? exactSlot : -1;
        exactSlot = handler.field_7761.iterator();
        while (exactSlot.hasNext()) {
            slot = (class_1735)exactSlot.next();
            while (!XCarryAction.isEligibleSourceSlot(slot)) {
            }
            int visibleSlot = XCarryAction.resolveVisibleSlotForPlayerSlot(handler, slot.field_7874);
            if (!XCarryAction.matchesTarget(slot.method_7677(), target, visibleSlot)) continue;
            return slot.field_7874;
        }
        return -1;
    }

    private static boolean moveStack(class_1723 handler, class_310 mc, int fromSlotId, int toSlotId) {
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        if (fromSlotId < 0 || fromSlotId >= handler.field_7761.size()) {
            return false;
        }
        if (toSlotId < 0 || toSlotId >= handler.field_7761.size()) {
            return false;
        }
        if (fromSlotId == toSlotId) {
            return true;
        }
        if (!handler.method_34255().method_7960()) {
            return false;
        }
        if (((class_1735)handler.field_7761.get(fromSlotId)).method_7677().method_7960()) {
            return false;
        }
        if (!((class_1735)handler.field_7761.get(toSlotId)).method_7677().method_7960()) {
            return false;
        }
        mc.field_1761.method_2906(handler.field_7763, fromSlotId, 0, class_1713.field_7790, mc.field_1724);
        if (handler.method_34255().method_7960()) {
            return false;
        }
        mc.field_1761.method_2906(handler.field_7763, toSlotId, 0, class_1713.field_7790, mc.field_1724);
        if (!handler.method_34255().method_7960()) { /* goto L225; */ }
        return ((class_1735)handler.field_7761.get(fromSlotId)).method_7677().method_7960() && !((class_1735)handler.field_7761.get(toSlotId)).method_7677().method_7960();
        mc.field_1761.method_2906(handler.field_7763, fromSlotId, 0, class_1713.field_7790, mc.field_1724);
        return false;
    }

    public static boolean hasCraftingGridItems(class_1723 handler) {
        for (int slotId = 1; slotId <= 4; slotId++) {
            if (slotId >= handler.field_7761.size()) break;
            if (((class_1735)handler.field_7761.get(slotId)).method_7677().method_7960()) continue;
            return true;
        }
        return false;
    }

    static void sendOpenTarget(class_310 mc, PackUtilContainerTarget target) {
        if (target == null) {
            return;
        }
        target.interact(mc);
    }

    private static boolean isEligibleSourceSlot(class_1735 slot) {
        return slot != null && slot.field_7874 >= 5 && !slot.method_7677().method_7960();
    }

    private static int resolvePlayerVisibleSlot(class_1703 handler, int configuredSlot) {
        var var2 = handler.field_7761.iterator();
        while (var2.hasNext()) {
            class_1735 slot = (class_1735)var2.next();
            if (slot == null) continue;
            if (slot.field_7874 < 0) continue;
            while (slot.field_7874 >= handler.field_7761.size()) {
            }
            while (slot.field_7874 <= 4) {
            }
            while (slot.field_7874 >= 5) {
                if (slot.field_7874 > 8) break;
            }
            while (slot.field_7874 == 45) {
            }
            while (slot.field_7871 == null) {
            }
            if (slot.field_7871 instanceof class_1661) {
                int index = slot.method_34266();
                if (index != configuredSlot) continue;
                return slot.field_7874;
            }
        }
        return -1;
    }

    private static boolean matchesTarget(class_1799 stack, ItemTarget target, int visibleSlot) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (target == null || !target.hasIdentity()) {
            return true;
        }
        return target.matches(stack, visibleSlot);
    }

    private static int parseEntrySlot(String entry) {
        if (entry == null || !entry.startsWith("#")) {
            return -1;
        }
        int separator = entry.indexOf(124);
        String raw = separator >= 0 ? entry.substring(1, separator) : entry.substring(1);
        try {
            return Integer.parseInt(raw);
        }
        catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private static String parseEntryName(String entry) {
        if (entry == null || entry.isBlank()) {
            return "";
        }
        if (!entry.startsWith("#")) {
            return entry.trim();
        }
        int separator = entry.indexOf(124);
        return separator >= 0 && separator + 1 < entry.length() ? entry.substring(separator + 1).trim() : "";
    }

    private static int resolveVisibleSlotForPlayerSlot(class_1723 handler, int handlerSlotId) {
        if (handlerSlotId < 0 || handlerSlotId >= handler.field_7761.size()) {
            return -1;
        }
        class_1735 slot = (class_1735)handler.field_7761.get(handlerSlotId);
        if (slot == null || !(slot.field_7871 instanceof class_1661)) {
            return -1;
        }
        return slot.method_34266();
    }

    private List<ItemTarget> resolvedEntryTargets() {
        if (!this.entryTargets.isEmpty()) {
            return this.entryTargets;
        }
        var var1 = this.entries.iterator();
        while (var1.hasNext()) {
            String entry = (String)var1.next();
            String normalized = XCarryAction.normalizeEntry(entry);
            while (normalized == null) {
            }
            ItemTarget target = ItemTarget.fromLegacyEntry(normalized);
            if (!target.hasSlot() || target.hasIdentity()) continue;
            this.entryTargets.add(target);
            if (this.entryTargets.size() < 4) { /* goto @108; */ }
            break;
        }
        return this.entryTargets;
    }

    private void syncLegacyEntries() {
        this.entries.clear();
        var var1 = this.entryTargets.iterator();
        while (var1.hasNext()) {
            ItemTarget target = (ItemTarget)var1.next();
            while (target == null) {
            }
            String entry = XCarryAction.normalizeEntry(target.toLegacyEntry());
            if (entry == null) continue;
            while (this.entries.contains(entry)) {
            }
            this.entries.add(entry);
            if (this.entries.size() < 4) { /* goto @100; */ }
            break;
        }
    }
}
