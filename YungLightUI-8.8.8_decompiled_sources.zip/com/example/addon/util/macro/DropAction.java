/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class DropAction
implements MacroAction,
WaitsForGui {
    public DropAction.DropMode mode = DropAction.DropMode.TIMES;
    public int dropCount = 1;
    public List<String> itemNames = new ArrayList();
    public List<ItemTarget> itemTargets = new ArrayList();
    public List<Integer> itemCounts = new ArrayList();
    public boolean waitForGui = false;
    public String guiName = "";
    public boolean useHandlerSlots = true;
    private boolean enabled = true;

    public int getItemCount(int index) {
        return index < this.itemCounts.size() ? (Integer)this.itemCounts.get(index) : 1;
    }

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        if (this.itemNames.isEmpty()) { /* goto L180; */ }
        for (int ei = 0; ei < this.itemNames.size(); ei++) {
            ItemTarget entryTarget = this.getItemTarget(ei);
            int count = this.getItemCount(ei);
            String entryName = DropAction.parseEntryName(entryTarget.toLegacyEntry());
            int configuredSlot = entryTarget.hasSlot() ? entryTarget.slot : -1;
            if (configuredSlot >= 0) {
                if (entryName.isEmpty()) continue;
                this.dropMatchingItemInSpecificSlot(mc, configuredSlot, entryName, count);
            } else {
                if (configuredSlot >= 0) {
                    if (this.useHandlerSlots) {
                        int resolvedSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, configuredSlot);
                        if (!resolvedSlot >= 0) continue;
                        this.dropFromHandlerSlot(mc, resolvedSlot, count);
                    } else {
                        this.dropFromInvSlot(mc, configuredSlot, count);
                    }
                } else {
                    if (entryName.isEmpty()) continue;
                    this.dropMatchingItemsByName(mc, entryName, count);
                }
            }
        }
    }

    private void dropMatchingItemInSpecificSlot(class_310 mc, int configuredSlot, String itemName, int count) {
        ItemTarget target = ItemTarget.fromLegacyEntry(itemName);
        if (!target.hasIdentity()) {
            return;
        }
        if (!this.useHandlerSlots) { /* goto L153; */ }
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null) {
            return;
        }
        int resolvedSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, configuredSlot);
        if (resolvedSlot < 0 || resolvedSlot >= handler.field_7761.size()) {
            return;
        }
        class_1735 slot = (class_1735)handler.field_7761.get(resolvedSlot);
        if (slot == null || slot.method_7677().method_7960()) {
            return;
        }
        int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, resolvedSlot);
        if (!target.matches(slot.method_7677(), visibleSlot)) {
            return;
        }
        int toDrop = count == 0 ? 0 : Math.min(count, slot.method_7677().method_7947());
        this.dropFromHandlerSlot(mc, resolvedSlot, toDrop);
        return;
        if (configuredSlot < 0 || configuredSlot >= 36) {
            return;
        }
        stack = mc.field_1724.method_31548().method_5438(configuredSlot);
        if (stack.method_7960() || !target.matches(stack, configuredSlot)) {
            return;
        }
        toDrop = count == 0 ? 0 : Math.min(count, stack.method_7947());
        this.dropFromInvSlot(mc, configuredSlot, toDrop);
    }

    private void dropMatchingItemsByName(class_310 mc, String itemName, int count) {
        ItemTarget target = ItemTarget.fromLegacyEntry(itemName);
        if (!target.hasIdentity()) {
            return;
        }
        int remaining = count;
        if (!this.useHandlerSlots) { /* goto L184; */ }
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null) {
            return;
        }
        class_1799 stack = handler.field_7761.iterator();
        while (stack.hasNext()) {
            class_1735 s = (class_1735)stack.next();
            if (s == null) continue;
            while (s.method_7677().method_7960()) {
            }
            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, s.field_7874);
            while (!target.matches(s.method_7677(), visibleSlot)) {
            }
            while (count == 0) {
                this.dropFromHandlerSlot(mc, s.field_7874, 0);
            }
            if (remaining <= 0) {
            } else {
                int toDrop = Math.min(remaining, s.method_7677().method_7947());
                this.dropFromHandlerSlot(mc, s.field_7874, toDrop);
                remaining = remaining - toDrop;
            }
        }
        return;
        L184: ;
        for (i = 0; i < 36; i++) {
            stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) { /* goto L282; */ }
            if (!target.matches(stack, i)) {
            } else {
                if (count == 0) {
                    this.dropFromInvSlot(mc, i, 0);
                } else {
                    if (remaining <= 0) {
                    } else {
                        toDrop = Math.min(remaining, stack.method_7947());
                        this.dropFromInvSlot(mc, i, toDrop);
                        remaining = remaining - toDrop;
                    }
                }
            }
        }
    }

    private void dropFromInvSlot(class_310 mc, int invSlot, int count) {
        int screenSlot = invSlot >= 0 && invSlot <= 8 ? 36 + invSlot : invSlot;
        class_1799 stack = mc.field_1724.method_31548().method_5438(invSlot);
        int syncId = mc.field_1724.field_7512.field_7763;
        if (count != 0) {
            if (stack.method_7960()) { /* goto @88; */ }
        }
        mc.field_1761.method_2906(syncId, screenSlot, 1, class_1713.field_7795, mc.field_1724);
        /* goto L122; */
        L88: ;
        for (int i = 0; i < count; i++) {
            mc.field_1761.method_2906(syncId, screenSlot, 0, class_1713.field_7795, mc.field_1724);
        }
    }

    private void dropFromHandlerSlot(class_310 mc, int handlerSlotId, int count) {
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null || handlerSlotId < 0 || handlerSlotId >= handler.field_7761.size()) {
            return;
        }
        class_1799 stack = ((class_1735)handler.field_7761.get(handlerSlotId)).method_7677();
        int syncId = handler.field_7763;
        if (count != 0) {
            if (stack.method_7960()) { /* goto @97; */ }
        }
        mc.field_1761.method_2906(syncId, handlerSlotId, 1, class_1713.field_7795, mc.field_1724);
        /* goto L130; */
        L97: ;
        for (int i = 0; i < count; i++) {
            mc.field_1761.method_2906(syncId, handlerSlotId, 0, class_1713.field_7795, mc.field_1724);
        }
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.guiName;
    }

    public void setWaitGuiName(String name) {
        this.guiName = name;
    }

    public MacroActionType getType() {
        return MacroActionType.DROP;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "DROP");
        tag.method_10582("mode", this.mode.name());
        tag.method_10569("count", this.dropCount);
        tag.method_10566("itemNames", ItemTarget.toTagList(this.resolvedItemTargets()));
        class_2499 counts = new class_2499();
        var var3 = this.itemCounts.iterator();
        while (var3.hasNext()) {
            int c = ((Integer)var3.next()).intValue();
            counts.add(class_2519.method_23256(String.valueOf(c)));
        }
        tag.method_10566("itemCounts", counts);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        tag.method_10556("useHandlerSlots", this.useHandlerSlots);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.mode = DropAction.DropMode.valueOf(tag.method_68564("mode", "TIMES"));
        }
        catch (IllegalArgumentException ignored) {
            this.mode = DropAction.DropMode.TIMES;
            L28: ;
            this.dropCount = tag.method_68083("count", 1);
            this.itemTargets.clear();
            this.itemNames.clear();
            if (!tag.method_10545("itemNames")) { /* goto @106; */ }
            nl = (class_2499)tag.method_10554("itemNames").orElse(new class_2499());
            this.itemTargets.addAll(ItemTarget.fromElementList(nl));
            /* goto @147; */
        }
        this.dropCount = tag.method_68083("count", 1);
        this.itemTargets.clear();
        this.itemNames.clear();
        if (tag.method_10545("itemNames")) {
            nl = (class_2499)tag.method_10554("itemNames").orElse(new class_2499());
            this.itemTargets.addAll(ItemTarget.fromElementList(nl));
        } else {
            if (tag.method_10545("itemName")) {
                old = tag.method_68564("itemName", "");
                if (!old.isEmpty()) {
                    this.itemTargets.add(ItemTarget.fromLegacyEntry(old));
                }
            }
        }
        this.syncLegacyItemNames();
        this.itemCounts.clear();
        if (tag.method_10545("itemCounts")) {
            cl = (class_2499)tag.method_10554("itemCounts").orElse(new class_2499());
            var var3 = cl.iterator();
            L196: ;
            if (var3.hasNext()) {
                class_2520 el = (class_2520)var3.next();
            }
        }
        try {
            this.itemCounts.add(Integer.parseInt((String)el.method_68658().orElse("1")));
        }
        catch (NumberFormatException e) {
            this.itemCounts.add(1);
            L267: ;
            /* goto @196; */
            while (this.itemCounts.size() < this.itemNames.size()) {
                this.itemCounts.add(1);
            }
        }
        /* goto @196; */
        while (this.itemCounts.size() < this.itemNames.size()) {
            this.itemCounts.add(1);
        }
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", false);
        }
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
        this.useHandlerSlots = true;
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        List<ItemTarget> targets = this.resolvedItemTargets();
        if (targets.isEmpty()) { /* goto L149; */ }
        String e0 = ((ItemTarget)targets.get(0)).toLegacyEntry();
        int slot = DropAction.parseEntrySlot(e0);
        String itemName = DropAction.parseEntryName(e0);
        if (slot >= 0) {
            if (!itemName.isEmpty()) {
                String first = "\"" + itemName + "\" @ Slot " + slot;
            }
        } else {
            if (slot >= 0) {
                String first = "Slot " + slot;
            } else {
                String first = "\"" + itemName + "\"";
            }
        }
        if (this.itemNames.size() > 1) {
            first = first + " (+" + this.itemNames.size() - 1 + ")";
        }
        return this.mode == DropAction.DropMode.ALL ? "Drop All [" + first + "]" : "Drop [" + first + "]";
        return "Drop (no items set)";
    }

    public String getIcon() {
        return "D";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private static int parseEntrySlot(String entry) {
        if (entry == null || !entry.startsWith("#")) {
            return -1;
        }
        int separator = entry.indexOf(124);
        String raw = separator >= 0 ? entry.substring(1, separator) : entry.substring(1);
        try {
            return Integer.parseInt(raw);
        }
        catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private static String parseEntryName(String entry) {
        if (entry == null || entry.isBlank()) {
            return "";
        }
        if (!entry.startsWith("#")) {
            return entry.trim();
        }
        int separator = entry.indexOf(124);
        return separator >= 0 && separator + 1 < entry.length() ? entry.substring(separator + 1).trim() : "";
    }

    private List<ItemTarget> resolvedItemTargets() {
        if (!this.itemTargets.isEmpty()) {
            return this.itemTargets;
        }
        var var1 = this.itemNames.iterator();
        while (var1.hasNext()) {
            String itemName = (String)var1.next();
            ItemTarget target = ItemTarget.fromLegacyEntry(itemName);
            if (!target.hasSlot() || target.hasIdentity()) continue;
            this.itemTargets.add(target);
        }
        return this.itemTargets;
    }

    private ItemTarget getItemTarget(int index) {
        List<ItemTarget> targets = this.resolvedItemTargets();
        if (index >= 0 && index < targets.size()) {
            return (ItemTarget)targets.get(index);
        }
        return new ItemTarget();
    }

    private void syncLegacyItemNames() {
        this.itemNames.clear();
        var var1 = this.itemTargets.iterator();
        while (var1.hasNext()) {
            ItemTarget target = (ItemTarget)var1.next();
            while (target == null) {
            }
            String entry = target.toLegacyEntry();
            if (entry.isBlank()) continue;
            this.itemNames.add(entry);
        }
    }
}
