/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2846;
import net.minecraft.class_2886;
import net.minecraft.class_310;

public class UseItemAction
implements MacroAction {
    public String itemName = "";
    public ItemTarget itemTarget = new ItemTarget();
    public UseItemAction.UseMode useMode = UseItemAction.UseMode.AUTOMATIC;
    public int holdTicks = 20;
    public int useCount = 1;
    private boolean enabled = true;

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            return;
        }
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            PackUtilInventoryHelper.selectHotbarItem(mc, target, mc.field_1724.method_31548().method_67532());
        }
        mc.method_1562().method_52787(new class_2886(class_1268.field_5808, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
    }

    public void sendRelease(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
    }

    public MacroActionType getType() {
        return MacroActionType.USE_ITEM;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "USE_ITEM");
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            tag.method_10566("itemName", target.toTag());
        }
        tag.method_10582("useMode", this.useMode.name());
        tag.method_10569("holdTicks", this.holdTicks);
        tag.method_10569("useCount", this.useCount);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.itemTarget = (ItemTarget)tag.method_10562("itemName").map(ItemTarget::fromTag).orElseGet(UseItemAction::lambda$fromTag$0 /* captured: tag */);
        this.itemName = this.itemTarget.toLegacyEntry();
        if (tag.method_10545("useMode")) {
            String modeName = tag.method_68564("useMode", "AUTOMATIC");
            if ("INSTANT".equals(modeName)) {
                modeName = "AUTOMATIC";
            }
            if ("HOLD".equals(modeName)) {
                modeName = "CUSTOM_HOLD";
            }
        }
        try {
            this.useMode = UseItemAction.UseMode.valueOf(modeName);
        }
        catch (IllegalArgumentException ignored) {
            this.useMode = UseItemAction.UseMode.AUTOMATIC;
            L104: ;
            if (tag.method_10545("holdTicks")) {
                this.holdTicks = tag.method_68083("holdTicks", 20);
            }
            if (tag.method_10545("useCount")) {
                this.useCount = Math.max(1, tag.method_68083("useCount", 1));
            }
            if (tag.method_10545("enabled")) {
                this.enabled = tag.method_68566("enabled", true);
            }
            return;
        }
        if (tag.method_10545("holdTicks")) {
            this.holdTicks = tag.method_68083("holdTicks", 20);
        }
        if (tag.method_10545("useCount")) {
            this.useCount = Math.max(1, tag.method_68083("useCount", 1));
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        ItemTarget target = this.resolvedItemTarget();
        String item = target.hasSlot() || target.hasIdentity() ? target.summaryText() : "current";
        String count = this.useCount > 1 ? " x" + this.useCount : "";
        return this.useMode == UseItemAction.UseMode.CUSTOM_HOLD ? "Use Item (" + item + ", hold " + this.holdTicks + "t)" : "Use Item (" + item + count + ")";
    }

    public String getIcon() {
        return "U";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private ItemTarget resolvedItemTarget() {
        if (this.itemTarget != null) {
            if (this.itemTarget.hasSlot() || this.itemTarget.hasIdentity()) {
                return this.itemTarget;
            }
        }
        this.itemTarget = ItemTarget.fromLegacyEntry(this.itemName);
        return this.itemTarget;
    }
}
