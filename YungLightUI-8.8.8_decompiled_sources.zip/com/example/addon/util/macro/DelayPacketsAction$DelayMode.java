/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum DelayPacketsAction.DelayMode {
    public static final DelayPacketsAction.DelayMode ENABLE = new DelayPacketsAction.DelayMode("ENABLE", 0);
    public static final DelayPacketsAction.DelayMode DISABLE = new DelayPacketsAction.DelayMode("DISABLE", 1);
    private static final /* synthetic */ DelayPacketsAction.DelayMode[] $VALUES;

    public static DelayPacketsAction.DelayMode[] values() {
        return (DelayPacketsAction.DelayMode[])$VALUES.clone();
    }

    public static DelayPacketsAction.DelayMode valueOf(String name) {
        return (DelayPacketsAction.DelayMode)Enum.valueOf(DelayPacketsAction.DelayMode.class, name);
    }

    private DelayPacketsAction.DelayMode() {
        super(var1, var2);
    }

    static {
        $VALUES = DelayPacketsAction.DelayMode.$values();
    }
}
