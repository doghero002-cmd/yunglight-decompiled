/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum XCarryAction.TransferMode {
    public static final XCarryAction.TransferMode FAST = new XCarryAction.TransferMode("FAST", 0);
    public static final XCarryAction.TransferMode CLICK = new XCarryAction.TransferMode("CLICK", 1);
    private static final /* synthetic */ XCarryAction.TransferMode[] $VALUES;

    public static XCarryAction.TransferMode[] values() {
        return (XCarryAction.TransferMode[])$VALUES.clone();
    }

    public static XCarryAction.TransferMode valueOf(String name) {
        return (XCarryAction.TransferMode)Enum.valueOf(XCarryAction.TransferMode.class, name);
    }

    private XCarryAction.TransferMode() {
        super(var1, var2);
    }

    static {
        $VALUES = XCarryAction.TransferMode.$values();
    }
}
