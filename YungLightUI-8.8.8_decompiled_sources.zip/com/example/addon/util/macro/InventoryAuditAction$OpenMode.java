/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum InventoryAuditAction.OpenMode {
    public static final InventoryAuditAction.OpenMode COMMAND = new InventoryAuditAction.OpenMode("COMMAND", 0);
    public static final InventoryAuditAction.OpenMode CONTAINER = new InventoryAuditAction.OpenMode("CONTAINER", 1);
    private static final /* synthetic */ InventoryAuditAction.OpenMode[] $VALUES;

    public static InventoryAuditAction.OpenMode[] values() {
        return (InventoryAuditAction.OpenMode[])$VALUES.clone();
    }

    public static InventoryAuditAction.OpenMode valueOf(String name) {
        return (InventoryAuditAction.OpenMode)Enum.valueOf(InventoryAuditAction.OpenMode.class, name);
    }

    private InventoryAuditAction.OpenMode() {
        super(var1, var2);
    }

    static {
        $VALUES = InventoryAuditAction.OpenMode.$values();
    }
}
