/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class WaitForChatAction
implements MacroAction,
WaitsForGui {
    public String pattern = "";
    public String patternJson = "";
    public boolean useRegex = false;
    public int fuzzyPercent = 100;
    public boolean serverMessageOnly = false;
    public int timeoutMs = 0;
    private boolean enabled = true;
    public boolean waitForGui = false;
    public String waitGuiName = "";

    public WaitForChatAction() {
    }

    public WaitForChatAction(String pattern) {
        this.pattern = pattern;
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("pattern", this.pattern);
        tag.method_10582("patternJson", this.patternJson == null ? "" : this.patternJson);
        tag.method_10556("useRegex", this.useRegex);
        tag.method_10569("fuzzyPercent", this.fuzzyPercent);
        tag.method_10556("serverMessageOnly", this.serverMessageOnly);
        tag.method_10569("timeoutMs", this.timeoutMs);
        tag.method_10556("enabled", this.enabled);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("waitGuiName", this.waitGuiName);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("pattern")) {
            this.pattern = tag.method_68564("pattern", "");
        }
        if (tag.method_10545("patternJson")) {
            this.patternJson = tag.method_68564("patternJson", "");
        } else {
            this.patternJson = "";
        }
        if (tag.method_10545("useRegex")) {
            this.useRegex = tag.method_68566("useRegex", false);
        }
        if (tag.method_10545("fuzzyPercent")) {
            this.fuzzyPercent = WaitForChatAction.clampFuzzyPercent(tag.method_68083("fuzzyPercent", 100));
        } else {
            this.fuzzyPercent = 100;
        }
        if (tag.method_10545("serverMessageOnly")) {
            this.serverMessageOnly = tag.method_68566("serverMessageOnly", false);
        }
        if (tag.method_10545("timeoutMs")) {
            this.timeoutMs = tag.method_68083("timeoutMs", 0);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", false);
        }
        if (tag.method_10545("waitGuiName")) {
            this.waitGuiName = tag.method_68564("waitGuiName", "");
        }
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_CHAT;
    }

    public String getDisplayName() {
        String desc = this.pattern.isEmpty() ? "Any Chat" : this.pattern;
        if (!this.useRegex) {
            desc = desc + " (~" + WaitForChatAction.clampFuzzyPercent(this.fuzzyPercent) + "%)";
        }
        if (this.serverMessageOnly) {
            desc = desc + " [Server]";
        }
        if (this.timeoutMs > 0) {
            desc = desc + " (" + this.timeoutMs + "ms)";
        }
        return "Wait Chat: " + desc;
    }

    public String getIcon() {
        return "WCH";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.waitGuiName;
    }

    public void setWaitGuiName(String name) {
        this.waitGuiName = name;
    }

    public static int clampFuzzyPercent(int percent) {
        int clamped = Math.max(40, Math.min(100, percent));
        int snapped = Math.round((float)clamped / 10f) * 10;
        return Math.max(40, Math.min(100, snapped));
    }
}
