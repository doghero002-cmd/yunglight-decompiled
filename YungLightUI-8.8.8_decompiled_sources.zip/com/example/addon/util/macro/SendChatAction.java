/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SendChatAction
implements MacroAction,
WaitsForGui {
    public String message = "";
    public boolean waitForGui = true;
    public String guiName = "";
    private boolean enabled = true;

    public SendChatAction() {
    }

    public SendChatAction(String message) {
        this.message = message;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", MacroActionType.SEND_CHAT.name());
        tag.method_10582("message", this.message);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("message")) {
            this.message = tag.method_68564("message", "");
        }
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", false);
        }
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public void execute(class_310 mc) {
        if (this.message == null || this.message.isEmpty()) {
            return;
        }
        if (mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_45730(this.message.substring(1));
        if (this.message.startsWith("/") && this.message.length() > 1) {
        } else {
            mc.method_1562().method_45729(this.message);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.SEND_CHAT;
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.guiName;
    }

    public void setWaitGuiName(String name) {
        this.guiName = name != null ? name : "";
    }

    public String getDisplayName() {
        String preview = this.message.length() > 20 ? this.message.substring(0, 20) + "..." : this.message;
        return "Chat: " + preview;
    }

    public String getIcon() {
        return "CH";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
