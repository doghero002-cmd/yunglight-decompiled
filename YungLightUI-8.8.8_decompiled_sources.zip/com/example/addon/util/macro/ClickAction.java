/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import net.minecraft.class_1268;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class ClickAction
implements MacroAction,
WaitsForGui {
    public ClickAction.ClickType type;
    public int clickCount = 1;
    public boolean waitForGui = false;
    public String guiName = "";

    public ClickAction() {
    }

    public ClickAction(ClickAction.ClickType type) {
        this.type = type;
        this.clickCount = 1;
    }

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        if (this.type == ClickAction.ClickType.LEFT) {
            if (mc.field_1765 == null) { /* goto L45; */ }
            if (mc.field_1765.method_17783() == class_239.class_240.field_1333) {
                mc.field_1724.method_6104(class_1268.field_5808);
            } else {
                if (mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                    mc.field_1761.method_2918(mc.field_1724, ((class_3966)mc.field_1765).method_17782());
                    mc.field_1724.method_6104(class_1268.field_5808);
                } else {
                    if (mc.field_1765.method_17783() == class_239.class_240.field_1332) {
                        mc.field_1761.method_2910(((class_3965)mc.field_1765).method_17777(), ((class_3965)mc.field_1765).method_17780());
                        mc.field_1724.method_6104(class_1268.field_5808);
                    }
                }
            }
        } else {
            if (mc.field_1765 == null) { /* goto L179; */ }
            if (mc.field_1765.method_17783() == class_239.class_240.field_1333) {
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            } else {
                if (mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                    mc.field_1761.method_2905(mc.field_1724, ((class_3966)mc.field_1765).method_17782(), class_1268.field_5808);
                } else {
                    if (mc.field_1765.method_17783() == class_239.class_240.field_1332) {
                        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, (class_3965)mc.field_1765);
                    }
                }
            }
        }
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.guiName;
    }

    public void setWaitGuiName(String name) {
        this.guiName = name;
    }

    public MacroActionType getType() {
        return MacroActionType.CLICK;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("clickType", (this.type == null ? ClickAction.ClickType.RIGHT : this.type).name());
        tag.method_10569("clickCount", this.clickCount);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.type = ClickAction.ClickType.valueOf(tag.method_68564("clickType", "RIGHT"));
        }
        catch (IllegalArgumentException e) {
            this.type = ClickAction.ClickType.RIGHT;
            L35: ;
            if (this.type == null) {
                this.type = ClickAction.ClickType.RIGHT;
            }
            if (tag.method_10545("clickCount")) {
                this.clickCount = tag.method_68083("clickCount", 1);
            }
            if (tag.method_10545("waitForGui")) {
                this.waitForGui = tag.method_68566("waitForGui", false);
            }
            if (tag.method_10545("guiName")) {
                this.guiName = tag.method_68564("guiName", "");
            }
            return;
        }
        if (this.type == null) {
            this.type = ClickAction.ClickType.RIGHT;
        }
        if (tag.method_10545("clickCount")) {
            this.clickCount = tag.method_68083("clickCount", 1);
        }
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", false);
        }
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
    }

    public String getDisplayName() {
        String base = this.type == ClickAction.ClickType.LEFT ? "Left Click" : "Right Click";
        return this.clickCount > 1 ? base + " x" + this.clickCount : base;
    }

    public String getIcon() {
        return this.type == ClickAction.ClickType.LEFT ? "L" : "R";
    }
}
