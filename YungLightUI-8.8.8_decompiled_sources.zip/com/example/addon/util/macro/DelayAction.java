/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class DelayAction
implements MacroAction {
    public int delayMs = 1000;
    public boolean useTicks = false;
    public int delayTicks = 20;

    public DelayAction() {
    }

    public DelayAction(int delayMs) {
        this.delayMs = delayMs;
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("delayMs", this.delayMs);
        tag.method_10556("useTicks", this.useTicks);
        tag.method_10569("delayTicks", this.delayTicks);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("delayMs")) {
            this.delayMs = tag.method_68083("delayMs", 0);
        } else {
            if (tag.method_10545("delayTicks")) {
                if (!tag.method_10545("useTicks")) {
                    this.delayMs = tag.method_68083("delayTicks", 0) * 50;
                }
            }
        }
        if (tag.method_10545("useTicks")) {
            this.useTicks = tag.method_68566("useTicks", false);
        }
        if (tag.method_10545("delayTicks")) {
            this.delayTicks = tag.method_68083("delayTicks", 20);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.DELAY;
    }

    public String getDisplayName() {
        return this.useTicks ? "Delay: " + this.delayTicks + " ticks" : "Delay: " + this.delayMs + " ms";
    }

    public String getIcon() {
        return "Wait";
    }
}
