/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum WaitForGuiAction.WaitMode {
    public static final WaitForGuiAction.WaitMode OPEN = new WaitForGuiAction.WaitMode("OPEN", 0);
    public static final WaitForGuiAction.WaitMode CLOSE = new WaitForGuiAction.WaitMode("CLOSE", 1);
    private static final /* synthetic */ WaitForGuiAction.WaitMode[] $VALUES;

    public static WaitForGuiAction.WaitMode[] values() {
        return (WaitForGuiAction.WaitMode[])$VALUES.clone();
    }

    public static WaitForGuiAction.WaitMode valueOf(String name) {
        return (WaitForGuiAction.WaitMode)Enum.valueOf(WaitForGuiAction.WaitMode.class, name);
    }

    private WaitForGuiAction.WaitMode() {
        super(var1, var2);
    }

    static {
        $VALUES = WaitForGuiAction.WaitMode.$values();
    }
}
