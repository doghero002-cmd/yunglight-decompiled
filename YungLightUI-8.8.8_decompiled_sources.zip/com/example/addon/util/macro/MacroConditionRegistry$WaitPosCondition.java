/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_3532;

static class MacroConditionRegistry.WaitPosCondition
implements MacroConditionRegistry.PendingCondition {
    final double x;
    final double y;
    final double z;
    final double leewaySquared;
    final boolean checkRotation;
    final float yaw;
    final float pitch;
    final float rotLeeway;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.WaitPosCondition(double x, double y, double z, double leeway, boolean checkRotation, float yaw, float pitch, float rotLeeway, CompletableFuture<Void> future) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.leewaySquared = leeway * leeway;
        this.checkRotation = checkRotation;
        this.yaw = yaw;
        this.pitch = pitch;
        this.rotLeeway = rotLeeway;
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1724 == null) {
            return false;
        }
        double dx = mc.field_1724.method_23317() - this.x;
        double dy = mc.field_1724.method_23318() - this.y;
        double dz = mc.field_1724.method_23321() - this.z;
        if (dx * dx + dy * dy + dz * dz > this.leewaySquared) {
            return false;
        }
        if (this.checkRotation) {
            float currentYaw = class_3532.method_15393(mc.field_1724.method_36454());
            float currentPitch = class_3532.method_15393(mc.field_1724.method_36455());
            float targetYaw = class_3532.method_15393(this.yaw);
            float targetPitch = class_3532.method_15393(this.pitch);
            if (Math.abs(currentYaw - targetYaw) > this.rotLeeway) {
                return false;
            }
            if (Math.abs(currentPitch - targetPitch) > this.rotLeeway) {
                return false;
            }
        }
        return true;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
