/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.WaitForBlockAction;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_7923;

static class MacroConditionRegistry.BlockCondition
implements MacroConditionRegistry.PendingCondition {
    final WaitForBlockAction action;
    final Set<String> blockIdSet;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.BlockCondition(WaitForBlockAction action, CompletableFuture<Void> future) {
        this.action = action;
        this.blockIdSet = new HashSet(action.blockIds);
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return false;
        }
        boolean destroyed = this.action.waitBehavior == WaitForBlockAction.WaitBehavior.DESTROYED;
        boolean anyBlock = this.action.anyBlock;
        switch (MacroConditionRegistry.1.$SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[this.action.checkMode.ordinal()]) {
            case 1::
                class_2248 b = mc.field_1687.method_8320(this.action.blockPos).method_26204();
                boolean isAir = b == class_2246.field_10124;
                if (!destroyed) { /* goto L167; */ }
                if (anyBlock) {
                    return isAir;
                }
                if (isAir) {
                    return true;
                }
                return !this.blockIdSet.contains(class_7923.field_41175.method_10221(b).toString());
                if (isAir) {
                    return false;
                }
                if (!anyBlock && !this.blockIdSet.isEmpty() && !this.blockIdSet.contains(class_7923.field_41175.method_10221(b).toString())) {
                    return false;
                }
                if (this.action.mustBeInReach) {
                    return this.isAtPosReachable(mc);
                }
                return true;
            case 2::
                r = (int)Math.ceil(this.action.searchRadius);
                cx = (int)mc.field_1724.method_23317();
                int cy = (int)mc.field_1724.method_23318();
                int cz = (int)mc.field_1724.method_23321();
                class_2339 mut = new class_2338.class_2339();
                if (!destroyed) { /* goto L423; */ }
                if (anyBlock) {
                    return false;
                }
                for (int dx = -r; dx <= r; dx++) {
                    for (int dy = -r; dy <= r; dy++) {
                        for (int dz = -r; dz <= r; dz++) {
                            mut.method_10103(cx + dx, cy + dy, cz + dz);
                            class_2248 b = mc.field_1687.method_8320(mut).method_26204();
                            if (!b != class_2246.field_10124 && this.blockIdSet.contains(class_7923.field_41175.method_10221(b).toString())) continue;
                            return false;
                        }
                    }
                }
                return true;
                L423: ;
                for (dx = -r; dx <= r; dx++) {
                    for (dy = -r; dy <= r; dy++) {
                        for (dz = -r; dz <= r; dz++) {
                            mut.method_10103(cx + dx, cy + dy, cz + dz);
                            b = mc.field_1687.method_8320(mut).method_26204();
                            if (b == class_2246.field_10124) {
                            } else {
                                if (!anyBlock || this.blockIdSet.isEmpty()) continue;
                                return true;
                                if (!this.blockIdSet.contains(class_7923.field_41175.method_10221(b).toString())) continue;
                                return true;
                            }
                        }
                    }
                }
                return false;
            case 3::
                if (!destroyed) { /* goto L671; */ }
                if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) {
                    return anyBlock;
                }
                if (anyBlock) { /* goto L669; */ }
                if (this.blockIdSet.isEmpty()) { /* goto L669; */ }
                bhr = (class_3965)mc.field_1765;
                b = mc.field_1687.method_8320(bhr.method_17777()).method_26204();
                return !this.blockIdSet.contains(class_7923.field_41175.method_10221(b).toString());
                return false;
                L671: ;
                if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) {
                    return false;
                }
                bhr = (class_3965)mc.field_1765;
                if (anyBlock || this.blockIdSet.isEmpty()) {
                    return true;
                }
                b = mc.field_1687.method_8320(bhr.method_17777()).method_26204();
                return this.blockIdSet.contains(class_7923.field_41175.method_10221(b).toString());
            default:
                return false;
        }
    }

    private boolean isAtPosReachable(class_310 mc) {
        class_243 center = this.action.blockPos.method_46558();
        if (mc.field_1724.method_5707(center) > 36) {
            return false;
        }
        class_3959 ctx = new class_3959(mc.field_1724.method_33571(), center, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, mc.field_1724);
        class_3965 result = mc.field_1687.method_17742(ctx);
        return result.method_17783() == class_239.class_240.field_1332 && result.method_17777().equals(this.action.blockPos);
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
