/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class RevisionSyncAction
implements MacroAction {
    public int revisionOffset = 1;
    public int preGenCount = -1;

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("revisionOffset", this.revisionOffset);
        tag.method_10569("preGenCount", this.preGenCount);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.revisionOffset = tag.method_68083("revisionOffset", 1);
        this.preGenCount = tag.method_68083("preGenCount", -1);
    }

    public MacroActionType getType() {
        return MacroActionType.REVISION_SYNC;
    }

    public String getDisplayName() {
        StringBuilder sb = new StringBuilder("Rev Sync");
        sb.append(" +").append(this.revisionOffset);
        if (this.preGenCount > 0) {
            sb.append(" (").append(this.preGenCount).append(" pkts)");
        } else {
            if (this.preGenCount == -1) {
                sb.append(" (all)");
            }
        }
        return sb.toString();
    }

    public String getIcon() {
        return "Rev";
    }
}
