/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_310;

public class StoreItemAction
implements MacroAction {
    public StoreItemAction.Mode mode = StoreItemAction.Mode.STORE;
    public List<String> targetItems = new ArrayList();
    public List<ItemTarget> itemTargets = new ArrayList();
    public boolean persistent = false;
    public boolean closeAfter = false;
    public boolean allItems = false;
    public boolean closeSendPkt = true;
    private boolean enabled = true;

    public void doTransfer(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        class_1703 h = mc.field_1724.field_7512;
        if (h == mc.field_1724.field_7498) {
            return;
        }
        for (int i = 0; i < h.field_7761.size(); i++) {
            class_1735 slot = (class_1735)h.field_7761.get(i);
            if (slot == null) {
            } else {
                boolean playerInventorySlot = PackUtilInventoryHelper.isPlayerInventorySlot(mc, slot);
                if (this.mode == StoreItemAction.Mode.LOOT) {
                } else {
                    if (this.mode == StoreItemAction.Mode.STORE) {
                    } else {
                        class_1799 stack = slot.method_7677();
                        if (stack.method_7960()) {
                        } else {
                            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, slot.field_7874);
                            if (!this.matchesAny(stack, visibleSlot)) continue;
                            mc.field_1761.method_2906(h.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                        }
                    }
                }
            }
        }
        if (this.closeAfter) {
            if (!this.persistent) {
                if (mc.field_1724.field_7512 != mc.field_1724.field_7498) {
                    if (!this.closeSendPkt) {
                        PackUtilSharedState.get().setSuppressNextClosePacket(true);
                    }
                    mc.field_1724.method_7346();
                }
            }
        }
    }

    public void execute(class_310 mc) {
        this.doTransfer(mc);
    }

    public boolean matchesAny(class_1799 stack) {
        return this.matchesAny(stack, -1);
    }

    public boolean matchesAny(class_1799 stack, int visibleSlot) {
        if (stack.method_7960()) {
            return false;
        }
        if (this.allItems) {
            return true;
        }
        List<ItemTarget> targets = this.resolvedTargets();
        if (targets.isEmpty()) {
            return false;
        }
        var var4 = targets.iterator();
        while (var4.hasNext()) {
            ItemTarget target = (ItemTarget)var4.next();
            if (!this.matchesTargetEntry(stack, visibleSlot, target)) continue;
            return true;
        }
        return false;
    }

    private boolean matchesTargetEntry(class_1799 stack, int visibleSlot, ItemTarget target) {
        if (target != null) {
            if (target.hasSlot()) { /* goto @20; */ }
        }
        return false;
        L20: ;
        return target.matches(stack, visibleSlot);
    }

    public MacroActionType getType() {
        return MacroActionType.STORE_ITEM;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "STORE_ITEM");
        tag.method_10582("mode", this.mode.name());
        tag.method_10556("persistent", this.persistent);
        tag.method_10556("closeAfter", this.closeAfter);
        tag.method_10556("allItems", this.allItems);
        tag.method_10556("closeSendPkt", this.closeSendPkt);
        tag.method_10566("targetItems", ItemTarget.toTagList(this.resolvedTargets()));
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.mode = StoreItemAction.Mode.valueOf(tag.method_68564("mode", "LOOT"));
        }
        catch (IllegalArgumentException ignored) {
            this.mode = StoreItemAction.Mode.LOOT;
            L36: ;
            if (tag.method_10545("persistent")) {
                this.persistent = tag.method_68566("persistent", false);
            }
            if (tag.method_10545("closeAfter")) {
                this.closeAfter = tag.method_68566("closeAfter", false);
            }
            if (tag.method_10545("allItems")) {
                this.allItems = tag.method_68566("allItems", false);
            }
            if (tag.method_10545("closeSendPkt")) {
                this.closeSendPkt = tag.method_68566("closeSendPkt", true);
            }
            this.itemTargets.clear();
            this.targetItems.clear();
            if (tag.method_10545("targetItems")) {
                list = (class_2499)tag.method_10554("targetItems").orElse(new class_2499());
                this.itemTargets.addAll(ItemTarget.fromElementList(list));
            }
            this.syncLegacyTargetItems();
            if (tag.method_10545("enabled")) {
                this.enabled = tag.method_68566("enabled", true);
            }
            return;
        }
        if (tag.method_10545("persistent")) {
            this.persistent = tag.method_68566("persistent", false);
        }
        if (tag.method_10545("closeAfter")) {
            this.closeAfter = tag.method_68566("closeAfter", false);
        }
        if (tag.method_10545("allItems")) {
            this.allItems = tag.method_68566("allItems", false);
        }
        if (tag.method_10545("closeSendPkt")) {
            this.closeSendPkt = tag.method_68566("closeSendPkt", true);
        }
        this.itemTargets.clear();
        this.targetItems.clear();
        if (tag.method_10545("targetItems")) {
            list = (class_2499)tag.method_10554("targetItems").orElse(new class_2499());
            this.itemTargets.addAll(ItemTarget.fromElementList(list));
        }
        this.syncLegacyTargetItems();
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        String modeStr = this.mode == StoreItemAction.Mode.LOOT ? "Loot" : "Store";
        if (!this.allItems) { /* goto L50; */ }
        return modeStr + " All" + this.persistent ? " [Inf]" : "";
        List<ItemTarget> targets = this.resolvedTargets();
        if (targets.isEmpty()) {
            return modeStr + " (nothing)";
        }
        String what = targets.size() == 1 ? StoreItemAction.formatTargetEntry(((ItemTarget)targets.get(0)).toLegacyEntry()) : targets.size() + " items";
        return modeStr + " " + what + this.persistent ? " [Inf]" : "";
    }

    public static String normalizeTargetEntry(String raw) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (!trimmed.startsWith("#")) {
            if (trimmed.matches("\\d+")) {
                trimmed = "#" + trimmed;
            }
        }
        if (!trimmed.startsWith("#")) {
            return trimmed;
        }
        int separator = trimmed.indexOf(124);
        String slotRaw = separator >= 0 ? trimmed.substring(1, separator).trim() : trimmed.substring(1).trim();
        if (slotRaw.isEmpty()) {
            return null;
        }
        try {
            int slot = Integer.parseInt(slotRaw);
            if (slot < 0) {
                return null;
            }
        }
        catch (NumberFormatException ignored) {
            return trimmed;
        }
        try {
            String itemPart = separator >= 0 && separator + 1 < trimmed.length() ? trimmed.substring(separator + 1).trim() : "";
            return itemPart.isEmpty() ? "#" + slot : "#" + slot + "|" + itemPart;
        }
        catch (NumberFormatException ignored) {
            return trimmed;
        }
    }

    public static String buildCapturedTargetEntry(String itemName, String registryId, int visibleSlot) {
        if (registryId.isBlank()) { /* goto @18; */ }
        String itemPart = registryId != null ? registryId.trim() : itemName != null ? itemName.trim() : "";
        if (!itemPart.isEmpty()) {
            return itemPart;
        }
        return visibleSlot >= 0 ? "#" + visibleSlot : null;
    }

    public static String formatTargetEntry(String entry) {
        if (entry == null || entry.isBlank()) {
            return "";
        }
        ItemTarget target = ItemTarget.fromLegacyEntry(entry);
        String label = target.displayLabel();
        if (target.hasSlot() && label.isBlank()) {
            return "#" + target.slot;
        }
        if (target.hasSlot()) {
            return target.slot + ": " + label;
        }
        return label;
    }

    private static int parseTargetSlot(String entry) {
        if (entry == null || !entry.startsWith("#")) {
            return -1;
        }
        int separator = entry.indexOf(124);
        String slotRaw = separator >= 0 ? entry.substring(1, separator).trim() : entry.substring(1).trim();
        if (slotRaw.isEmpty()) {
            return -1;
        }
        try {
            int slot = Integer.parseInt(slotRaw);
            return slot >= 0 ? slot : -1;
        }
        catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private static String parseTargetName(String entry) {
        if (entry == null || entry.isBlank()) {
            return "";
        }
        int separator = entry.indexOf(124);
        if (separator < 0 || separator + 1 >= entry.length()) {
            return "";
        }
        return entry.substring(separator + 1).trim();
    }

    public String getIcon() {
        return this.mode == StoreItemAction.Mode.LOOT ? "LOT" : "STR";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private List<ItemTarget> resolvedTargets() {
        if (!this.itemTargets.isEmpty()) {
            return this.itemTargets;
        }
        var var1 = this.targetItems.iterator();
        while (var1.hasNext()) {
            String target = (String)var1.next();
            ItemTarget parsed = ItemTarget.fromLegacyEntry(target);
            if (!parsed.hasSlot() || parsed.hasIdentity()) continue;
            this.itemTargets.add(parsed);
        }
        return this.itemTargets;
    }

    private void syncLegacyTargetItems() {
        this.targetItems.clear();
        var var1 = this.itemTargets.iterator();
        while (var1.hasNext()) {
            ItemTarget target = (ItemTarget)var1.next();
            while (target == null) {
            }
            String entry = target.toLegacyEntry();
            if (entry.isBlank()) continue;
            this.targetItems.add(entry);
        }
    }
}
