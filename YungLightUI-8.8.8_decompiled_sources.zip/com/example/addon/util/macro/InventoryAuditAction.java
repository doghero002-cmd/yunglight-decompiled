/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.MacroConditionRegistry;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_10938;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2813;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class InventoryAuditAction
implements MacroAction {
    private static final int MAX_DELAY_MS = 10000;
    private static final int MAX_ITERATIONS = 100;
    private static final int AUTO_GUI_TIMEOUT_MS = 12000;
    private static final int GUI_POLL_MS = 50;
    private static final int GUI_STABLE_POLLS_REQUIRED = 3;
    public InventoryAuditAction.Mode mode = InventoryAuditAction.Mode.DUPE;
    public List<String> targetItems = new ArrayList();
    public List<ItemTarget> itemTargets = new ArrayList();
    public String openCommand = "/ec";
    public InventoryAuditAction.OpenMode openMode = InventoryAuditAction.OpenMode.COMMAND;
    public class_2338 containerPos;
    public InventoryAuditAction.DupeVector dupeVector;
    public int delayBeforeReopen;
    public int delayAfterReopen;
    public int iterations;
    public int maxTransferAttempts;
    public int transferRetryDelayMs;
    public boolean multipleStacks;
    public int spamCount;
    public int spamDelayMs;
    private boolean enabled;

    public InventoryAuditAction() {
        this.containerPos = class_2338.field_10980;
        this.dupeVector = InventoryAuditAction.DupeVector.DESYNC_REOPEN;
        this.delayBeforeReopen = 200;
        this.delayAfterReopen = 500;
        this.iterations = 1;
        this.maxTransferAttempts = 5;
        this.transferRetryDelayMs = 50;
        this.multipleStacks = false;
        this.spamCount = 3;
        this.spamDelayMs = 50;
        this.enabled = true;
    }

    public boolean hasValidTargetSelection() {
        return this.hasConfiguredTargets();
    }

    public boolean hasConfiguredTargets() {
        var var1 = this.resolvedTargets().iterator();
        while (var1.hasNext()) {
            ItemTarget target = (ItemTarget)var1.next();
            if (target != null) {
                if (!target.hasSlot() || target.hasIdentity()) continue;
                return true;
            }
        }
        return false;
    }

    public void execute(class_310 mc) {
        if (mc == null || mc.field_1724 == null) {
            return;
        }
        if (this.mode == InventoryAuditAction.Mode.DUPE || this.mode == InventoryAuditAction.Mode.DUPE_SPAM) {
            return;
        }
    }

    public void executeDupe(class_310 mc) throws InterruptedException {
        if (mc == null || mc.field_1724 == null) {
            return;
        }
        String cmd = this.normalizedOpenCommand();
        int runIterations = this.clampIterations(this.iterations);
        int maxAttempts = Math.max(1, Math.min(this.maxTransferAttempts, 20));
        int retryDelay = Math.max(10, Math.min(this.transferRetryDelayMs, 500));
        for (int iter = 0; iter < runIterations; iter++) {
            if (!Thread.interrupted()) continue;
            return;
            if (this.openMode == InventoryAuditAction.OpenMode.CONTAINER) {
                this.sendContainerOpen(mc, this.containerPos);
            } else {
                this.sendCommand(mc, cmd);
            }
            if (this.waitForGuiStable(mc, 12000L)) continue;
            return;
            InventorySnapshot before = this.captureOnGameThread(mc);
            if (!before == null || before.slots().isEmpty()) continue;
            return;
            Map<String, Integer> targetContainerItems = this.collectTargetContainerTotals(before);
            if (targetContainerItems.isEmpty()) {
                InventorySnapshot playerSnapshot = this.capturePlayerInventoryOnly(mc);
                Map<String, Integer> playerTargetItems = this.collectTargetPlayerTotals(playerSnapshot);
                if (playerTargetItems.isEmpty()) { /* goto L289; */ }
                boolean transferred = this.transferItemsToContainer(mc, playerTargetItems);
                if (!transferred) { /* goto L289; */ }
                this.closeGuiOnGameThread(mc, true);
                if (this.waitForGuiClosed(mc, 12000L)) continue;
                return;
                if (this.openMode == InventoryAuditAction.OpenMode.CONTAINER) {
                    this.sendContainerOpen(mc, this.containerPos);
                } else {
                    this.sendCommand(mc, cmd);
                }
                if (this.waitForGuiStable(mc, 12000L)) continue;
                return;
                before = this.captureOnGameThread(mc);
                if (!before == null || before.slots().isEmpty()) continue;
                return;
                targetContainerItems = this.collectTargetContainerTotals(before);
                L289: ;
                if (!targetContainerItems.isEmpty()) continue;
                this.closeGuiOnGameThread(mc, true);
            } else {
                if (this.mode != InventoryAuditAction.Mode.DUPE_SPAM) { /* goto L406; */ }
                int spamOpens = Math.max(1, Math.min(this.spamCount, 20));
                int spamDelay = Math.max(10, Math.min(this.spamDelayMs, 1000));
                for (int spam = true; spam < spamOpens; spam++) {
                    Thread.sleep((long)spamDelay);
                    if (this.openMode == InventoryAuditAction.OpenMode.CONTAINER) {
                        this.sendContainerOpen(mc, this.containerPos);
                    } else {
                        this.sendCommand(mc, cmd);
                    }
                }
                Thread.sleep(100L);
                L406: ;
                this.executeDupeVector(mc);
                totalTransferAttempts = 1;
                targetSlots = this.getTargetSlots(mc);
                while (totalTransferAttempts < maxAttempts) {
                    guiState = this.readGuiState(mc);
                    if (guiState.open()) { /* goto L486; */ }
                    if (this.openMode == InventoryAuditAction.OpenMode.CONTAINER) {
                        this.sendContainerOpen(mc, this.containerPos);
                    } else {
                        this.sendCommand(mc, cmd);
                    }
                    if (this.waitForGuiStable(mc, 12000L)) { /* goto L500; */ }
                    break;
                    L486: ;
                    if (!this.waitForGuiStable(mc, 12000L)) {
                    } else {
                        Thread.sleep((long)retryDelay);
                        TransferAttempt attempt = this.transferTargetsAggressive(mc, targetSlots);
                        totalTransferAttempts++;
                        if (attempt.slotCount() > 0) { /* goto @529; */ }
                        /* goto @532; */
                    }
                }
                if (this.prepareForReopen(mc, 12000L)) continue;
                return;
                if (this.openMode == InventoryAuditAction.OpenMode.CONTAINER) {
                    this.sendContainerOpen(mc, this.containerPos);
                } else {
                    this.sendCommand(mc, cmd);
                }
                if (this.waitForGuiStable(mc, 12000L)) continue;
                return;
                this.closeGuiOnGameThread(mc, true);
                if (!iter < runIterations - 1) continue;
                Thread.sleep(500L);
            }
        }
    }

    private Set<Integer> getTargetSlots(class_310 mc) {
        Set<Integer> slots = new HashSet();
        List<ItemTarget> targets = this.resolvedTargets();
        if (targets.isEmpty()) { /* goto L83; */ }
        var var4 = targets.iterator();
        while (var4.hasNext()) {
            ItemTarget target = (ItemTarget)var4.next();
            if (target != null) {
                if (!target.hasSlot()) continue;
                slots.add(target.slot);
            }
        }
        return slots;
    }

    private InventoryAuditAction.TransferAttempt transferTargetsAggressive(class_310 mc, Set<Integer> targetSlots) throws InterruptedException {
        TransferAttempt[] result = new InventoryAuditAction.TransferAttempt[1];
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(this::lambda$transferTargetsAggressive$0 /* captured: mc, result, targetSlots, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
        return result[0] != null ? result[0] : new InventoryAuditAction.TransferAttempt(0, new LinkedHashMap());
    }

    private void verifyActualDuplication(InventoryAuditAction.InventorySnapshot before, InventoryAuditAction.InventorySnapshot after, InventoryAuditAction.TransferAttempt transfer, String iterLabel, int transferAttempts) {
    }

    private InventoryAuditAction.TransferAttempt executeDupeVector(class_310 mc) throws InterruptedException {
        switch (this.dupeVector.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return this.executeDesyncReopen(mc);
            case 1::
                return this.executeCloseNoPacket(mc);
            case 2::
                return this.executeShiftClickReopen(mc);
            case 3::
                return this.executeDelayedPackets(mc);
            case 4::
                return this.executeSwapHotbar(mc);
            case 5::
                return this.executeDropExploit(mc);
            case 6::
                return this.executeDelayedDesyncReopen(mc);
            case 7::
                return this.executeSwapDesyncReopen(mc);
            case 8::
                return this.executeDropDelayedPackets(mc);
        }
    }

    private InventoryAuditAction.TransferAttempt executeDesyncReopen(class_310 mc) throws InterruptedException {
        TransferAttempt transfer = this.shiftClickTargets(mc);
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(InventoryAuditAction::lambda$executeDesyncReopen$1 /* captured: mc, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
        Thread.sleep(100L);
        this.closeGuiOnGameThread(mc, false);
        return transfer;
    }

    private InventoryAuditAction.TransferAttempt executeCloseNoPacket(class_310 mc) throws InterruptedException {
        TransferAttempt transfer = this.shiftClickTargets(mc);
        this.closeGuiOnGameThread(mc, false);
        return transfer;
    }

    private InventoryAuditAction.TransferAttempt executeShiftClickReopen(class_310 mc) throws InterruptedException {
        TransferAttempt[] result = new InventoryAuditAction.TransferAttempt[1];
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(this::lambda$executeShiftClickReopen$2 /* captured: mc, result, latch */);
        latch.await(3000L, TimeUnit.MILLISECONDS);
        return result[0] != null ? result[0] : new InventoryAuditAction.TransferAttempt(0, new LinkedHashMap());
    }

    private InventoryAuditAction.TransferAttempt executeSwapDesyncReopen(class_310 mc) throws InterruptedException {
        TransferAttempt transfer = this.swapTargetsToHotbar(mc);
        this.sendClosePacketOnGameThread(mc);
        Thread.sleep(100L);
        this.closeGuiOnGameThread(mc, false);
        return transfer;
    }

    private InventoryAuditAction.TransferAttempt executeDelayedPackets(class_310 mc) throws InterruptedException {
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean previousDelayPackets = shared.shouldDelayGuiPackets();
        boolean previousUseCustomPackets = shared.shouldUseCustomPackets();
        Set<Class<? extends class_2596<?>>> previousC2SPackets = new HashSet(shared.getC2SPackets());
        Set<Class<? extends class_2596<?>>> previousS2CPackets = new HashSet(shared.getS2CPackets());
        shared.setUseCustomPackets(true);
        shared.setC2SPackets(Set.of(class_2813.class));
        shared.setS2CPackets(Set.of());
        shared.setDelayGuiPackets(true);
        try {
            TransferAttempt transfer = this.shiftClickTargets(mc);
            int[] tmp0 = new int[1];
            tmp0[0] = 0;
            int[] flushed = tmp0;
            CountDownLatch flushLatch = new CountDownLatch(1);
            mc.execute(InventoryAuditAction::lambda$executeDelayedPackets$3 /* captured: mc, flushed, shared, flushLatch */);
            flushLatch.await(3000L, TimeUnit.MILLISECONDS);
            this.closeGuiOnGameThread(mc, false);
            var var10 = transfer;
        }
        finally {
            shared.setDelayGuiPackets(previousDelayPackets);
            shared.setUseCustomPackets(previousUseCustomPackets);
            shared.setC2SPackets(previousC2SPackets);
            shared.setS2CPackets(previousS2CPackets);
            throw var11;
        }
    }

    private InventoryAuditAction.TransferAttempt executeDelayedDesyncReopen(class_310 mc) throws InterruptedException {
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean previousDelayPackets = shared.shouldDelayGuiPackets();
        boolean previousUseCustomPackets = shared.shouldUseCustomPackets();
        Set<Class<? extends class_2596<?>>> previousC2SPackets = new HashSet(shared.getC2SPackets());
        Set<Class<? extends class_2596<?>>> previousS2CPackets = new HashSet(shared.getS2CPackets());
        shared.setUseCustomPackets(true);
        shared.setC2SPackets(Set.of(class_2813.class));
        shared.setS2CPackets(Set.of());
        shared.setDelayGuiPackets(true);
        try {
            TransferAttempt transfer = this.shiftClickTargets(mc);
            CountDownLatch flushLatch = new CountDownLatch(1);
            mc.execute(InventoryAuditAction::lambda$executeDelayedDesyncReopen$4 /* captured: mc, shared, flushLatch */);
            flushLatch.await(3000L, TimeUnit.MILLISECONDS);
            Thread.sleep(100L);
            this.closeGuiOnGameThread(mc, false);
            var var9 = transfer;
        }
        finally {
            shared.setDelayGuiPackets(previousDelayPackets);
            shared.setUseCustomPackets(previousUseCustomPackets);
            shared.setC2SPackets(previousC2SPackets);
            shared.setS2CPackets(previousS2CPackets);
            throw var10;
        }
    }

    private InventoryAuditAction.TransferAttempt executeSwapHotbar(class_310 mc) throws InterruptedException {
        TransferAttempt[] result = new InventoryAuditAction.TransferAttempt[1];
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(this::lambda$executeSwapHotbar$5 /* captured: mc, result, latch */);
        latch.await(3000L, TimeUnit.MILLISECONDS);
        return result[0] != null ? result[0] : new InventoryAuditAction.TransferAttempt(0, new LinkedHashMap());
    }

    private InventoryAuditAction.TransferAttempt executeDropExploit(class_310 mc) throws InterruptedException {
        TransferAttempt transfer = this.throwTargets(mc);
        this.closeGuiOnGameThread(mc, false);
        return transfer;
    }

    private InventoryAuditAction.TransferAttempt executeDropDelayedPackets(class_310 mc) throws InterruptedException {
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean previousDelayPackets = shared.shouldDelayGuiPackets();
        boolean previousUseCustomPackets = shared.shouldUseCustomPackets();
        Set<Class<? extends class_2596<?>>> previousC2SPackets = new HashSet(shared.getC2SPackets());
        Set<Class<? extends class_2596<?>>> previousS2CPackets = new HashSet(shared.getS2CPackets());
        shared.setUseCustomPackets(true);
        shared.setC2SPackets(Set.of(class_2813.class));
        shared.setS2CPackets(Set.of());
        shared.setDelayGuiPackets(true);
        try {
            TransferAttempt transfer = this.throwTargets(mc);
            CountDownLatch flushLatch = new CountDownLatch(1);
            mc.execute(InventoryAuditAction::lambda$executeDropDelayedPackets$6 /* captured: mc, shared, flushLatch */);
            flushLatch.await(3000L, TimeUnit.MILLISECONDS);
            this.closeGuiOnGameThread(mc, false);
            var var9 = transfer;
        }
        finally {
            shared.setDelayGuiPackets(previousDelayPackets);
            shared.setUseCustomPackets(previousUseCustomPackets);
            shared.setC2SPackets(previousC2SPackets);
            shared.setS2CPackets(previousS2CPackets);
            throw var10;
        }
    }

    private void sendCommand(class_310 mc, String cmd) {
        mc.execute(InventoryAuditAction::lambda$sendCommand$7 /* captured: mc, cmd */);
    }

    private void sendContainerOpen(class_310 mc, class_2338 pos) {
        mc.execute(InventoryAuditAction::lambda$sendContainerOpen$8 /* captured: mc, pos */);
    }

    private void sendClosePacketOnGameThread(class_310 mc) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(InventoryAuditAction::lambda$sendClosePacketOnGameThread$9 /* captured: mc, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
    }

    private boolean waitForGui(class_310 mc, long timeoutMs) throws InterruptedException {
        CompletableFuture<Void> future = MacroConditionRegistry.waitForGui("");
        try {
            future.get(timeoutMs, TimeUnit.MILLISECONDS);
            return true;
        }
        catch (Exception e) {
            future.cancel(true);
            return false;
        }
    }

    private boolean waitForGuiStable(class_310 mc, long timeoutMs) throws InterruptedException {
        if (!this.readGuiState(mc).open() && !this.waitForGui(mc, timeoutMs)) {
            return false;
        }
        long deadline = System.currentTimeMillis() + timeoutMs;
        GuiState previous = null;
        int stablePolls = 0;
        while (System.currentTimeMillis() <= deadline) {
            GuiState current = this.readGuiState(mc);
            if (!current.open()) { /* goto L90; */ }
            if (current.equals(previous)) {
                stablePolls++;
            } else {
                previous = current;
                stablePolls = 1;
            }
            if (stablePolls >= 3) {
                return true;
                L90: ;
                previous = null;
                stablePolls = 0;
            }
            Thread.sleep(50L);
        }
        return false;
    }

    private boolean waitForGuiClosed(class_310 mc, long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() <= deadline) {
            if (this.readGuiState(mc).open()) continue;
            return true;
            Thread.sleep(50L);
        }
        return !this.readGuiState(mc).open();
    }

    private boolean prepareForReopen(class_310 mc, long timeoutMs) throws InterruptedException {
        if (this.readGuiState(mc).open()) {
            this.closeGuiOnGameThread(mc, true);
        }
        return this.waitForGuiClosed(mc, timeoutMs);
    }

    private InventoryAuditAction.GuiState readGuiState(class_310 mc) throws InterruptedException {
        InventoryAuditAction.GuiState[] tmp0 = new InventoryAuditAction.GuiState[1];
        tmp0[0] = new InventoryAuditAction.GuiState(false, -1, -1, 0, 0);
        GuiState[] state = tmp0;
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(InventoryAuditAction::lambda$readGuiState$10 /* captured: mc, state, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
        return state[0];
    }

    private void closeGuiOnGameThread(class_310 mc, boolean sendPacket) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(InventoryAuditAction::lambda$closeGuiOnGameThread$11 /* captured: mc, sendPacket, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
    }

    private InventoryAuditAction.TransferAttempt shiftClickTargets(class_310 mc) throws InterruptedException {
        TransferAttempt[] result = new InventoryAuditAction.TransferAttempt[1];
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(this::lambda$shiftClickTargets$12 /* captured: mc, result, latch */);
        latch.await(3000L, TimeUnit.MILLISECONDS);
        return result[0] != null ? result[0] : new InventoryAuditAction.TransferAttempt(0, new LinkedHashMap());
    }

    private InventoryAuditAction.TransferAttempt swapTargetsToHotbar(class_310 mc) throws InterruptedException {
        TransferAttempt[] result = new InventoryAuditAction.TransferAttempt[1];
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(this::lambda$swapTargetsToHotbar$13 /* captured: mc, result, latch */);
        latch.await(3000L, TimeUnit.MILLISECONDS);
        return result[0] != null ? result[0] : new InventoryAuditAction.TransferAttempt(0, new LinkedHashMap());
    }

    private InventoryAuditAction.TransferAttempt throwTargets(class_310 mc) throws InterruptedException {
        TransferAttempt[] result = new InventoryAuditAction.TransferAttempt[1];
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(this::lambda$throwTargets$14 /* captured: mc, result, latch */);
        latch.await(3000L, TimeUnit.MILLISECONDS);
        return result[0] != null ? result[0] : new InventoryAuditAction.TransferAttempt(0, new LinkedHashMap());
    }

    private boolean shouldTransferSlot(class_1799 stack, int visibleSlot) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (this.targetItems.isEmpty()) {
            return false;
        }
        return this.matchesTargetEntry(stack, visibleSlot);
    }

    private boolean matchesTargetEntry(class_1799 stack, int visibleSlot) {
        List<ItemTarget> targets = this.resolvedTargets();
        if (targets.isEmpty()) {
            return false;
        }
        var var4 = targets.iterator();
        while (var4.hasNext()) {
            ItemTarget itemTarget = (ItemTarget)var4.next();
            while (itemTarget.hasSlot()) {
                if (itemTarget.slot == visibleSlot) break;
            }
            if (itemTarget.hasIdentity() || itemTarget.matches(stack, visibleSlot)) continue;
            return true;
        }
        return false;
    }

    private Map<String, Integer> collectTargetContainerTotals(InventoryAuditAction.InventorySnapshot snapshot) {
        Map<String, Integer> totals = new LinkedHashMap();
        if (snapshot == null) {
            return totals;
        }
        var var3 = snapshot.slots().values().iterator();
        while (var3.hasNext()) {
            SlotSnapshot slot = (InventoryAuditAction.SlotSnapshot)var3.next();
            class_1799 stack = slot.stack();
            if (stack == null) continue;
            while (stack.method_7960()) {
            }
            while (this.isPlayerVisibleSlot(slot.visibleSlot())) {
            }
            while (!this.shouldTransferSlot(stack, slot.visibleSlot())) {
            }
            totals.merge(this.shortItemId(stack), stack.method_7947(), Integer::sum);
        }
        return totals;
    }

    private int sumTotals(Map<String, Integer> totals, Set<String> items) {
        int sum = 0;
        var var4 = items.iterator();
        while (var4.hasNext()) {
            String item = (String)var4.next();
            sum = sum + ((Integer)totals.getOrDefault(item, 0)).intValue();
        }
        return sum;
    }

    private boolean isPlayerVisibleSlot(int visibleSlot) {
        return visibleSlot >= 0 && visibleSlot < 41;
    }

    private InventoryAuditAction.InventorySnapshot capturePlayerInventoryOnly(class_310 mc) throws InterruptedException {
        CompletableFuture<InventoryAuditAction.InventorySnapshot> future = new CompletableFuture();
        mc.execute(this::lambda$capturePlayerInventoryOnly$15 /* captured: mc, future */);
        try {
            return (InventoryAuditAction.InventorySnapshot)future.get(3000L, TimeUnit.MILLISECONDS);
        }
        catch (Exception e) {
            return null;
        }
    }

    private Map<String, Integer> collectTargetPlayerTotals(InventoryAuditAction.InventorySnapshot snapshot) {
        Map<String, Integer> totals = new LinkedHashMap();
        List<ItemTarget> targets = this.resolvedTargets();
        if (snapshot == null || targets.isEmpty()) {
            return totals;
        }
        var var4 = snapshot.slots().values().iterator();
        while (var4.hasNext()) {
            SlotSnapshot slot = (InventoryAuditAction.SlotSnapshot)var4.next();
            class_1799 stack = slot.stack();
            if (stack == null) continue;
            while (stack.method_7960()) {
            }
            String itemId = this.shortItemId(stack);
            var var8 = targets.iterator();
            while (var8.hasNext()) {
                ItemTarget itemTarget = (ItemTarget)var8.next();
                if (!itemTarget.matches(stack, slot.visibleSlot())) { /* goto @167; */ }
                totals.merge(itemId, stack.method_7947(), Integer::sum);
                break;
            }
        }
        return totals;
    }

    private boolean transferItemsToContainer(class_310 mc, Map<String, Integer> targetItemsToTransfer) {
        if (mc.field_1724 == null || mc.field_1724.field_7512 == null) {
            return false;
        }
        if (mc.method_1562() == null) {
            return false;
        }
        class_1703 handler = mc.field_1724.field_7512;
        boolean anyTransferred = false;
        var var5 = handler.field_7761.iterator();
        while (var5.hasNext()) {
            class_1735 slot = (class_1735)var5.next();
            while (slot == null) {
            }
            class_1799 stack = slot.method_7677();
            if (stack == null) continue;
            while (stack.method_7960()) {
            }
            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, slot.field_7874);
            while (!this.isPlayerVisibleSlot(visibleSlot)) {
            }
            String itemId = this.shortItemId(stack);
            var var10 = targetItemsToTransfer.keySet().iterator();
            while (var10.hasNext()) {
                String targetId = (String)var10.next();
                if (itemId.equalsIgnoreCase(targetId)) {
                    short slotId = (short)slot.field_7874;
                    mc.method_1562().method_52787(new class_2813(handler.field_7763, handler.method_37421(), slotId, 0, class_1713.field_7794, new Int2ObjectOpenHashMap(), class_10938.field_58176));
                    anyTransferred = true;
                    if (this.multipleStacks) continue;
                    return true;
                }
            }
        }
        return anyTransferred;
    }

    private InventoryAuditAction.InventorySnapshot captureOnGameThread(class_310 mc) throws InterruptedException {
        CompletableFuture<InventoryAuditAction.InventorySnapshot> future = new CompletableFuture();
        mc.execute(this::lambda$captureOnGameThread$16 /* captured: mc, future */);
        try {
            return (InventoryAuditAction.InventorySnapshot)future.get(3000L, TimeUnit.MILLISECONDS);
        }
        catch (Exception e) {
            return null;
        }
    }

    private InventoryAuditAction.InventorySnapshot captureAutoTestSnapshot(class_310 mc, class_1703 handler) {
        String title = mc.field_1755 != null && mc.field_1755.method_25440() != null ? mc.field_1755.method_25440().getString() : "";
        Map<Integer, InventoryAuditAction.SlotSnapshot> slots = this.captureAllSlots(mc, handler);
        return new InventoryAuditAction.InventorySnapshot(title, System.currentTimeMillis(), slots);
    }

    private Map<Integer, InventoryAuditAction.SlotSnapshot> captureAllSlots(class_310 mc, class_1703 handler) {
        Map<Integer, InventoryAuditAction.SlotSnapshot> slots = new LinkedHashMap();
        var var4 = handler.field_7761.iterator();
        while (var4.hasNext()) {
            class_1735 slot = (class_1735)var4.next();
            while (slot == null) {
            }
            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, slot.field_7874);
            slots.putIfAbsent(visibleSlot, new InventoryAuditAction.SlotSnapshot(visibleSlot, this.formatSlotLabel(visibleSlot), this.copyStack(slot.method_7677())));
        }
        return slots;
    }

    private class_1799 copyStack(class_1799 stack) {
        return stack == null || stack.method_7960() ? class_1799.field_8037 : stack.method_7972();
    }

    private String formatSlotLabel(int visibleSlot) {
        return "Slot " + visibleSlot;
    }

    private String shortItemId(class_1799 stack) {
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        return itemId.startsWith("minecraft:") ? itemId.substring("minecraft:".length()) : itemId;
    }

    private int clampDelayMs(int value) {
        return Math.max(0, Math.min(value, 10000));
    }

    private int clampIterations(int value) {
        return Math.max(1, Math.min(value, 100));
    }

    private String normalizedOpenCommand() {
        String raw = this.openCommand == null ? "" : this.openCommand.trim();
        return raw.isEmpty() ? "/ec" : raw;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("mode", this.mode.name());
        tag.method_10566("targetItems", ItemTarget.toTagList(this.resolvedTargets()));
        tag.method_10582("openCommand", this.normalizedOpenCommand());
        tag.method_10582("openMode", this.openMode.name());
        tag.method_10569("containerX", this.containerPos.method_10263());
        tag.method_10569("containerY", this.containerPos.method_10264());
        tag.method_10569("containerZ", this.containerPos.method_10260());
        tag.method_10582("dupeVector", this.dupeVector.name());
        tag.method_10569("delayBeforeReopen", this.clampDelayMs(this.delayBeforeReopen));
        tag.method_10569("delayAfterReopen", this.clampDelayMs(this.delayAfterReopen));
        tag.method_10569("iterations", this.clampIterations(this.iterations));
        tag.method_10569("maxTransferAttempts", Math.max(1, Math.min(this.maxTransferAttempts, 20)));
        tag.method_10569("transferRetryDelayMs", Math.max(10, Math.min(this.transferRetryDelayMs, 500)));
        tag.method_10556("multipleStacks", this.multipleStacks);
        tag.method_10569("spamCount", Math.max(1, Math.min(this.spamCount, 20)));
        tag.method_10569("spamDelayMs", Math.max(10, Math.min(this.spamDelayMs, 1000)));
        tag.method_10569("grabPreDelayMs", 0);
        tag.method_10556("closeAfterGrab", true);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            String modeStr = tag.method_68564("mode", "DUPE");
            if (!"AUTO_TEST".equals(modeStr)) {
                if (!"GRAB".equals(modeStr)) {
                    if (!"SAVE".equals(modeStr)) {
                        if ("COMPARE".equals(modeStr)) { /* goto @71; */ }
                    }
                }
            }
            this.mode = InventoryAuditAction.Mode.DUPE;
            /* goto @89; */
            L81: ;
            this.mode = InventoryAuditAction.Mode.valueOf(modeStr);
        }
        catch (IllegalArgumentException ignored) {
            this.mode = InventoryAuditAction.Mode.DUPE;
            /* goto @110; */
        }
        this.itemTargets.clear();
        this.targetItems.clear();
        if (tag.method_10545("targetItems")) {
            list = (class_2499)tag.method_10554("targetItems").orElse(new class_2499());
            this.itemTargets.addAll(ItemTarget.fromElementList(list));
        }
        this.syncLegacyTargetItems();
        if (tag.method_10545("openCommand")) {
            this.openCommand = tag.method_68564("openCommand", "/ec");
        }
        try {
            this.openMode = InventoryAuditAction.OpenMode.valueOf(tag.method_68564("openMode", "COMMAND"));
        }
        catch (IllegalArgumentException ignored) {
            this.openMode = InventoryAuditAction.OpenMode.COMMAND;
            L238: ;
            if (tag.method_10545("containerX") || tag.method_10545("containerY") || tag.method_10545("containerZ")) {
                this.containerPos = new class_2338(tag.method_68083("containerX", 0), tag.method_68083("containerY", 0), tag.method_68083("containerZ", 0));
            }
            if (!tag.method_10545("dupeVector")) { /* goto @341; */ }
            this.dupeVector = InventoryAuditAction.DupeVector.valueOf(tag.method_68564("dupeVector", "DESYNC_REOPEN"));
            /* goto @341; */
        }
        if (tag.method_10545("containerX") || tag.method_10545("containerY") || tag.method_10545("containerZ")) {
            this.containerPos = new class_2338(tag.method_68083("containerX", 0), tag.method_68083("containerY", 0), tag.method_68083("containerZ", 0));
        }
        try {
            this.dupeVector = InventoryAuditAction.DupeVector.valueOf(tag.method_68564("dupeVector", "DESYNC_REOPEN"));
        }
        catch (IllegalArgumentException ignored) {
            this.dupeVector = InventoryAuditAction.DupeVector.DESYNC_REOPEN;
            L341: ;
            if (tag.method_10545("delayBeforeReopen")) {
                this.delayBeforeReopen = tag.method_68083("delayBeforeReopen", 200);
            }
            if (tag.method_10545("delayAfterReopen")) {
                this.delayAfterReopen = tag.method_68083("delayAfterReopen", 500);
            }
            if (tag.method_10545("iterations")) {
                this.iterations = tag.method_68083("iterations", 1);
            }
            if (tag.method_10545("maxTransferAttempts")) {
                this.maxTransferAttempts = tag.method_68083("maxTransferAttempts", 5);
            }
            if (tag.method_10545("transferRetryDelayMs")) {
                this.transferRetryDelayMs = tag.method_68083("transferRetryDelayMs", 50);
            }
            if (tag.method_10545("multipleStacks")) {
                this.multipleStacks = tag.method_68566("multipleStacks", false);
            }
            if (tag.method_10545("spamCount")) {
                this.spamCount = tag.method_68083("spamCount", 3);
            }
            if (tag.method_10545("spamDelayMs")) {
                this.spamDelayMs = tag.method_68083("spamDelayMs", 50);
            }
            this.delayBeforeReopen = this.clampDelayMs(this.delayBeforeReopen);
            this.delayAfterReopen = this.clampDelayMs(this.delayAfterReopen);
            this.iterations = this.clampIterations(this.iterations);
            this.openCommand = this.normalizedOpenCommand();
            if (tag.method_10545("enabled")) {
                this.enabled = tag.method_68566("enabled", true);
            }
            return;
        }
        if (tag.method_10545("delayBeforeReopen")) {
            this.delayBeforeReopen = tag.method_68083("delayBeforeReopen", 200);
        }
        if (tag.method_10545("delayAfterReopen")) {
            this.delayAfterReopen = tag.method_68083("delayAfterReopen", 500);
        }
        if (tag.method_10545("iterations")) {
            this.iterations = tag.method_68083("iterations", 1);
        }
        if (tag.method_10545("maxTransferAttempts")) {
            this.maxTransferAttempts = tag.method_68083("maxTransferAttempts", 5);
        }
        if (tag.method_10545("transferRetryDelayMs")) {
            this.transferRetryDelayMs = tag.method_68083("transferRetryDelayMs", 50);
        }
        if (tag.method_10545("multipleStacks")) {
            this.multipleStacks = tag.method_68566("multipleStacks", false);
        }
        if (tag.method_10545("spamCount")) {
            this.spamCount = tag.method_68083("spamCount", 3);
        }
        if (tag.method_10545("spamDelayMs")) {
            this.spamDelayMs = tag.method_68083("spamDelayMs", 50);
        }
        this.delayBeforeReopen = this.clampDelayMs(this.delayBeforeReopen);
        this.delayAfterReopen = this.clampDelayMs(this.delayAfterReopen);
        this.iterations = this.clampIterations(this.iterations);
        this.openCommand = this.normalizedOpenCommand();
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.INVENTORY_AUDIT;
    }

    public String getDisplayName() {
        String src = this.openMode == InventoryAuditAction.OpenMode.CONTAINER ? "(" + this.containerPos.method_10263() + "," + this.containerPos.method_10264() + "," + this.containerPos.method_10260() + ")" : this.normalizedOpenCommand();
        switch (this.mode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return "Dupe " + this.dupeVector.name() + " " + src;
            case 1::
                return "DupeSpam " + this.dupeVector.name() + " " + src + " (x" + this.spamCount + ")";
        }
    }

    public String getIcon() {
        return this.mode == InventoryAuditAction.Mode.DUPE_SPAM ? "DSP" : "DUP";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    private List<ItemTarget> resolvedTargets() {
        if (!this.itemTargets.isEmpty()) {
            return this.itemTargets;
        }
        var var1 = this.targetItems.iterator();
        while (var1.hasNext()) {
            String target = (String)var1.next();
            ItemTarget parsed = ItemTarget.fromLegacyEntry(target);
            if (!parsed.hasSlot() || parsed.hasIdentity()) continue;
            this.itemTargets.add(parsed);
        }
        return this.itemTargets;
    }

    private void syncLegacyTargetItems() {
        this.targetItems.clear();
        var var1 = this.itemTargets.iterator();
        while (var1.hasNext()) {
            ItemTarget target = (ItemTarget)var1.next();
            while (target == null) {
            }
            String entry = target.toLegacyEntry();
            if (entry.isBlank()) continue;
            this.targetItems.add(entry);
        }
    }
}
