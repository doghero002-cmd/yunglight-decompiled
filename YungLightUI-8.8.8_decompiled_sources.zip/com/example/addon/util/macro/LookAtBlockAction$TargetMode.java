/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum LookAtBlockAction.TargetMode {
    public static final LookAtBlockAction.TargetMode SPECIFIC = new LookAtBlockAction.TargetMode("SPECIFIC", 0);
    public static final LookAtBlockAction.TargetMode BLOCK = new LookAtBlockAction.TargetMode("BLOCK", 1);
    public static final LookAtBlockAction.TargetMode ENTITY = new LookAtBlockAction.TargetMode("ENTITY", 2);
    private static final /* synthetic */ LookAtBlockAction.TargetMode[] $VALUES;

    public static LookAtBlockAction.TargetMode[] values() {
        return (LookAtBlockAction.TargetMode[])$VALUES.clone();
    }

    public static LookAtBlockAction.TargetMode valueOf(String name) {
        return (LookAtBlockAction.TargetMode)Enum.valueOf(LookAtBlockAction.TargetMode.class, name);
    }

    private LookAtBlockAction.TargetMode() {
        super(var1, var2);
    }

    static {
        $VALUES = LookAtBlockAction.TargetMode.$values();
    }
}
