/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.Locale;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class WaitForHealthAction
implements MacroAction {
    public static final String COMPARISON_DROPS_BELOW = "Drops Below";
    public static final String COMPARISON_RISES_ABOVE = "Rises Above";
    public float healthThreshold = 20f;
    public boolean below = true;

    public WaitForHealthAction() {
    }

    public WaitForHealthAction(float healthThreshold, boolean below) {
        this.healthThreshold = healthThreshold;
        this.below = below;
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10548("healthThreshold", this.healthThreshold);
        tag.method_10556("below", this.below);
        tag.method_10582("comparison", this.comparisonLabel());
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("healthThreshold")) {
            this.healthThreshold = tag.method_66563("healthThreshold", 20f);
        }
        if (tag.method_10545("comparison")) {
            this.below = "Drops Below".equals(tag.method_68564("comparison", "Drops Below"));
        } else {
            if (tag.method_10545("below")) {
                this.below = tag.method_68566("below", true);
            }
        }
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_HEALTH;
    }

    public String getDisplayName() {
        return "Wait HP: " + this.comparisonLabel() + " " + this.thresholdText();
    }

    public String getIcon() {
        return "HP";
    }

    public String comparisonLabel() {
        return this.below ? "Drops Below" : "Rises Above";
    }

    public String thresholdText() {
        return String.format(Locale.ROOT, "%.1f", this.healthThreshold);
    }

    public String waitingStatusText() {
        return this.below ? "Waiting for health to drop below " + this.thresholdText() : "Waiting for health to rise above " + this.thresholdText();
    }
}
