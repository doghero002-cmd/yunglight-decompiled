/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.WaitForEntityAction;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_7923;

static class MacroConditionRegistry.EntityCondition
implements MacroConditionRegistry.PendingCondition {
    final WaitForEntityAction action;
    final Set<String> entityIdSet;
    final Set<String> specificUuids;
    final double radiusSq;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.EntityCondition(WaitForEntityAction action, CompletableFuture<Void> future) {
        this.action = action;
        this.entityIdSet = new HashSet();
        this.specificUuids = new HashSet();
        var var3 = action.entityIds.iterator();
        while (var3.hasNext()) {
            String entry = (String)var3.next();
            if (entry.startsWith("~")) {
                String[] p = entry.split("~", 4);
                if (p.length >= 2) {
                    if (p[1].isEmpty()) continue;
                    this.specificUuids.add(p[1]);
                }
            } else {
                this.entityIdSet.add(entry);
            }
        }
        this.radiusSq = action.radius * action.radius;
        this.future = future;
    }

    private boolean entityMatches(class_1297 entity) {
        if (this.entityIdSet.isEmpty() && this.specificUuids.isEmpty()) {
            return true;
        }
        if (!this.entityIdSet.isEmpty()) {
            String typeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
            if (this.entityIdSet.contains(typeId)) {
                return true;
            }
        }
        if (!this.specificUuids.isEmpty() && this.specificUuids.contains(entity.method_5845())) {
            return true;
        }
        return false;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return false;
        }
        switch (MacroConditionRegistry.1.$SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode[this.action.checkMode.ordinal()]) {
            case 1::
                class_1297 targeted = mc.field_1692;
                if (targeted == null || targeted == mc.field_1724) {
                    return false;
                }
                return this.entityMatches(targeted);
            case 2::
                reachSq = mc.field_1724.method_55755() * mc.field_1724.method_55755();
                class_1297 entity = mc.field_1687.method_18112().iterator();
                while (entity.hasNext()) {
                    class_1297 entity = (class_1297)entity.next();
                    while (entity == mc.field_1724) {
                    }
                    while (entity.method_5858(mc.field_1724) > reachSq) {
                    }
                    if (!this.entityMatches(entity)) continue;
                    return true;
                }
                return false;
            default:
                center = this.action.centerOnPlayer ? new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()) : new class_243(this.action.x, this.action.y, this.action.z);
                var var3 = mc.field_1687.method_18112().iterator();
                while (var3.hasNext()) {
                    entity = (class_1297)var3.next();
                    while (entity == mc.field_1724) {
                    }
                    while (entity.method_5707(center) > this.radiusSq) {
                    }
                    if (!this.entityMatches(entity)) continue;
                    return true;
                }
                return false;
        }
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
