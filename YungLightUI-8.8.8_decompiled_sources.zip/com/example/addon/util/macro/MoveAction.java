/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_304;
import net.minecraft.class_310;

public class MoveAction
implements MacroAction {
    public MoveAction.Direction direction = MoveAction.Direction.FORWARD;
    public int durationTicks = 20;
    public boolean nonBlocking = false;
    private boolean enabled = true;

    public MoveAction() {
    }

    public MoveAction(MoveAction.Direction direction, int durationTicks) {
        this.direction = direction;
        this.durationTicks = durationTicks;
    }

    public class_304 getKey(class_310 mc) {
        if (mc.field_1690 == null) {
            return null;
        }
        switch (this.direction.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return mc.field_1690.field_1894;
            case 1::
                return mc.field_1690.field_1881;
            case 2::
                return mc.field_1690.field_1913;
            case 3::
                return mc.field_1690.field_1849;
        }
    }

    public void execute(class_310 mc) {
        class_304 key = this.getKey(mc);
        if (key != null) {
            key.method_23481(true);
        }
    }

    public void release(class_310 mc) {
        class_304 key = this.getKey(mc);
        if (key != null) {
            key.method_23481(false);
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("direction", this.direction.name());
        tag.method_10569("durationTicks", this.durationTicks);
        tag.method_10556("nonBlocking", this.nonBlocking);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.direction = MoveAction.Direction.valueOf(tag.method_68564("direction", "FORWARD"));
        }
        catch (Exception e) {
            this.direction = MoveAction.Direction.FORWARD;
            L35: ;
            if (tag.method_10545("durationTicks")) {
                this.durationTicks = tag.method_68083("durationTicks", 20);
            }
            if (tag.method_10545("nonBlocking")) {
                this.nonBlocking = tag.method_68566("nonBlocking", false);
            }
            if (tag.method_10545("enabled")) {
                this.enabled = tag.method_68566("enabled", true);
            }
            return;
        }
        if (tag.method_10545("durationTicks")) {
            this.durationTicks = tag.method_68083("durationTicks", 20);
        }
        if (tag.method_10545("nonBlocking")) {
            this.nonBlocking = tag.method_68566("nonBlocking", false);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.MOVE;
    }

    public String getDisplayName() {
        return "Move " + this.direction.displayName() + " (" + this.durationTicks + "t)" + this.nonBlocking ? " [BG]" : "";
    }

    public String getIcon() {
        return "MOV";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
