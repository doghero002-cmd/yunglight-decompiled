/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum DisconnectAction.DisconnectMode {
    public static final DisconnectAction.DisconnectMode DISCONNECT = new DisconnectAction.DisconnectMode("DISCONNECT", 0);
    public static final DisconnectAction.DisconnectMode KICK = new DisconnectAction.DisconnectMode("KICK", 1);
    public static final DisconnectAction.DisconnectMode KICK_DUPE = new DisconnectAction.DisconnectMode("KICK_DUPE", 2);
    public static final DisconnectAction.DisconnectMode AUTO_DISCONNECT = new DisconnectAction.DisconnectMode("AUTO_DISCONNECT", 3);
    private static final /* synthetic */ DisconnectAction.DisconnectMode[] $VALUES;

    public static DisconnectAction.DisconnectMode[] values() {
        return (DisconnectAction.DisconnectMode[])$VALUES.clone();
    }

    public static DisconnectAction.DisconnectMode valueOf(String name) {
        return (DisconnectAction.DisconnectMode)Enum.valueOf(DisconnectAction.DisconnectMode.class, name);
    }

    private DisconnectAction.DisconnectMode() {
        super(var1, var2);
    }

    static {
        $VALUES = DisconnectAction.DisconnectMode.$values();
    }
}
