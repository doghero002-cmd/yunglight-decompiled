/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class ToggleModuleAction
implements MacroAction {
    public String moduleName = "";
    public ToggleModuleAction.ToggleMode toggleMode = ToggleModuleAction.ToggleMode.TOGGLE;
    public List<ToggleModuleAction.ModuleEntry> entries = new ArrayList();
    private boolean enabled = true;

    public ToggleModuleAction() {
    }

    public ToggleModuleAction(String moduleName) {
        this.moduleName = moduleName;
    }

    public void execute(class_310 mc) {
        if (this.entries.isEmpty()) { /* goto L78; */ }
        var var2 = this.entries.iterator();
        while (var2.hasNext()) {
            ModuleEntry entry = (ToggleModuleAction.ModuleEntry)var2.next();
            if (entry != null) {
                if (entry.moduleName != null) {
                    if (entry.moduleName.isBlank()) continue;
                    PackUtilCompatManager.toggleMeteorModule(entry.moduleName, entry.toggleMode);
                }
            }
        }
        return;
        L78: ;
        PackUtilCompatManager.toggleMeteorModule(this.moduleName, this.toggleMode);
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("moduleName", this.moduleName);
        tag.method_10582("toggleMode", this.toggleMode.name());
        class_2499 list = new class_2499();
        var var3 = this.entries.iterator();
        while (var3.hasNext()) {
            ModuleEntry entry = (ToggleModuleAction.ModuleEntry)var3.next();
            if (entry != null) {
                if (entry.moduleName != null) {
                    if (entry.moduleName.isBlank()) continue;
                    list.add(entry.toTag());
                }
            }
        }
        tag.method_10566("entries", list);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("moduleName")) {
            this.moduleName = tag.method_68564("moduleName", "");
        }
        try {
            this.toggleMode = ToggleModuleAction.ToggleMode.valueOf(tag.method_68564("toggleMode", "TOGGLE"));
        }
        catch (IllegalArgumentException ignored) {
            this.toggleMode = ToggleModuleAction.ToggleMode.TOGGLE;
            L56: ;
            this.entries.clear();
            if (!tag.method_10545("entries")) { /* goto @175; */ }
            list = (class_2499)tag.method_10554("entries").orElse(new class_2499());
            var var3 = list.iterator();
            while (var3.hasNext()) {
                class_2520 element = (class_2520)var3.next();
                if (element instanceof class_2487) {
                    class_2487 compound = (class_2487)element;
                    ModuleEntry entry = ToggleModuleAction.ModuleEntry.fromTag(compound);
                    if (entry.moduleName != null) {
                        if (entry.moduleName.isBlank()) continue;
                        this.entries.add(entry);
                    }
                }
            }
        }
        this.entries.clear();
        if (!tag.method_10545("entries")) { /* goto L175; */ }
        list = (class_2499)tag.method_10554("entries").orElse(new class_2499());
        var3 = list.iterator();
        while (var3.hasNext()) {
            element = (class_2520)var3.next();
            if (element instanceof class_2487) {
                compound = (class_2487)element;
                entry = ToggleModuleAction.ModuleEntry.fromTag(compound);
                if (entry.moduleName != null) {
                    if (entry.moduleName.isBlank()) continue;
                    this.entries.add(entry);
                }
            }
        }
        if (this.entries.isEmpty()) {
            if (this.moduleName != null) {
                if (!this.moduleName.isBlank()) {
                    this.entries.add(new ToggleModuleAction.ModuleEntry(this.moduleName, this.toggleMode));
                }
            }
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.TOGGLE_MODULE;
    }

    public String getDisplayName() {
        if (this.entries.isEmpty()) { /* goto L83; */ }
        return this.entries.size() == 1 ? ToggleModuleAction.formatMode(((ToggleModuleAction.ModuleEntry)this.entries.get(0)).toggleMode) + " Module (" + ((ToggleModuleAction.ModuleEntry)this.entries.get(0)).moduleName + ")" : "Module Batch (" + this.entries.size() + ")";
        switch (this.toggleMode.ordinal()) {
            case 1::
                String modeStr = "Enable";
                break;
            case 2::
                modeStr = "Disable";
                break;
            default:
                modeStr = "Toggle";
                break;
        }
        return modeStr + " Module (" + this.moduleName.isEmpty() ? "None" : this.moduleName + ")";
    }

    public String getIcon() {
        return "M";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private static String formatMode(ToggleModuleAction.ToggleMode mode) {
        switch (mode.ordinal()) {
            case 1::
                return "Enable";
            case 2::
                return "Disable";
            default:
                return "Toggle";
        }
    }
}
