/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_437;

static class MacroConditionRegistry.GuiChangeCondition
implements MacroConditionRegistry.PendingCondition {
    final class_437 prevScreen;
    final CompletableFuture<Void> future;
    private volatile boolean cancelled = false;

    MacroConditionRegistry.GuiChangeCondition(class_437 prevScreen, CompletableFuture<Void> future) {
        this.prevScreen = prevScreen;
        this.future = future;
    }

    public boolean check(class_310 mc) {
        return mc.field_1755 != this.prevScreen;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.cancelled = true;
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.cancelled || this.future.isCancelled();
    }
}
