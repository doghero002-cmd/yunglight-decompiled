/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public enum MacroActionType {
    public static final MacroActionType DELAY = new MacroActionType("DELAY", 0);
    public static final MacroActionType PACKET = new MacroActionType("PACKET", 1);
    public static final MacroActionType WAIT_PACKET = new MacroActionType("WAIT_PACKET", 2);
    public static final MacroActionType WAIT_HEALTH = new MacroActionType("WAIT_HEALTH", 3);
    public static final MacroActionType WAIT_ITEM = new MacroActionType("WAIT_ITEM", 4);
    public static final MacroActionType WAIT_BLOCK = new MacroActionType("WAIT_BLOCK", 5);
    public static final MacroActionType WAIT_GUI = new MacroActionType("WAIT_GUI", 6);
    public static final MacroActionType CLICK = new MacroActionType("CLICK", 7);
    public static final MacroActionType ROTATE = new MacroActionType("ROTATE", 8);
    public static final MacroActionType USE_ITEM = new MacroActionType("USE_ITEM", 9);
    public static final MacroActionType INVENTORY = new MacroActionType("INVENTORY", 10);
    public static final MacroActionType SEND_PACKET = new MacroActionType("SEND_PACKET", 11);
    public static final MacroActionType CRAFT = new MacroActionType("CRAFT", 12);
    public static final MacroActionType SELECT_SLOT = new MacroActionType("SELECT_SLOT", 13);
    public static final MacroActionType XCARRY = new MacroActionType("XCARRY", 14);
    public static final MacroActionType DROP = new MacroActionType("DROP", 15);
    public static final MacroActionType ITEM = new MacroActionType("ITEM", 16);
    public static final MacroActionType TICK_SYNC = new MacroActionType("TICK_SYNC", 17);
    public static final MacroActionType REVISION_SYNC = new MacroActionType("REVISION_SYNC", 18);
    public static final MacroActionType SERVER_TICK_SYNC = new MacroActionType("SERVER_TICK_SYNC", 19);
    public static final MacroActionType CLOSE_GUI = new MacroActionType("CLOSE_GUI", 20);
    public static final MacroActionType SWAP_SLOTS = new MacroActionType("SWAP_SLOTS", 21);
    public static final MacroActionType WAIT_COOLDOWN = new MacroActionType("WAIT_COOLDOWN", 22);
    public static final MacroActionType GO_TO = new MacroActionType("GO_TO", 23);
    public static final MacroActionType WAIT_POS = new MacroActionType("WAIT_POS", 24);
    public static final MacroActionType DISCONNECT = new MacroActionType("DISCONNECT", 25);
    public static final MacroActionType TOGGLE_MODULE = new MacroActionType("TOGGLE_MODULE", 26);
    public static final MacroActionType STOP_MACRO = new MacroActionType("STOP_MACRO", 27);
    public static final MacroActionType SNEAK = new MacroActionType("SNEAK", 28);
    public static final MacroActionType JUMP = new MacroActionType("JUMP", 29);
    public static final MacroActionType SPRINT = new MacroActionType("SPRINT", 30);
    public static final MacroActionType MOVE = new MacroActionType("MOVE", 31);
    public static final MacroActionType LOOK_AT_BLOCK = new MacroActionType("LOOK_AT_BLOCK", 32);
    public static final MacroActionType REPEAT = new MacroActionType("REPEAT", 33);
    public static final MacroActionType WAIT_CHAT = new MacroActionType("WAIT_CHAT", 34);
    public static final MacroActionType WAIT_ENTITY = new MacroActionType("WAIT_ENTITY", 35);
    public static final MacroActionType WAIT_SLOT_CHANGE = new MacroActionType("WAIT_SLOT_CHANGE", 36);
    public static final MacroActionType OPEN_CONTAINER = new MacroActionType("OPEN_CONTAINER", 37);
    public static final MacroActionType DESYNC = new MacroActionType("DESYNC", 38);
    public static final MacroActionType RESTORE_GUI = new MacroActionType("RESTORE_GUI", 39);
    public static final MacroActionType SAVE_GUI = new MacroActionType("SAVE_GUI", 40);
    public static final MacroActionType SEND_TOGGLE = new MacroActionType("SEND_TOGGLE", 41);
    public static final MacroActionType DELAY_PACKETS = new MacroActionType("DELAY_PACKETS", 42);
    public static final MacroActionType INVENTORY_AUDIT = new MacroActionType("INVENTORY_AUDIT", 43);
    public static final MacroActionType STORE_ITEM = new MacroActionType("STORE_ITEM", 44);
    public static final MacroActionType WAIT_SOUND = new MacroActionType("WAIT_SOUND", 45);
    public static final MacroActionType MINE = new MacroActionType("MINE", 46);
    public static final MacroActionType PAY = new MacroActionType("PAY", 47);
    public static final MacroActionType SEND_CHAT = new MacroActionType("SEND_CHAT", 48);
    public static final MacroActionType NBT_BOOK = new MacroActionType("NBT_BOOK", 49);
    public static final MacroActionType WAIT_LAN_STEP = new MacroActionType("WAIT_LAN_STEP", 50);
    private static final /* synthetic */ MacroActionType[] $VALUES;

    public static MacroActionType[] values() {
        return (MacroActionType[])$VALUES.clone();
    }

    public static MacroActionType valueOf(String name) {
        return (MacroActionType)Enum.valueOf(MacroActionType.class, name);
    }

    private MacroActionType() {
        super(var1, var2);
    }

    static {
        $VALUES = MacroActionType.$values();
    }
}
