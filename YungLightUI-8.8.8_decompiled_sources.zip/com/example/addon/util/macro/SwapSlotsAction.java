/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SwapSlotsAction
implements MacroAction {
    public int fromSlot = -1;
    public int toSlot = -1;
    public String fromItemName = "";
    public String toItemName = "";
    public ItemTarget fromItemTarget = new ItemTarget();
    public ItemTarget toItemTarget = new ItemTarget();
    public boolean fromUseItemName = false;
    public boolean toUseItemName = false;
    public boolean useHandlerSlots = true;
    private boolean enabled = true;

    public void execute(class_310 mc) {
        if (mc.field_1724 == null) {
            return;
        }
        int resolvedFrom = this.fromSlot;
        int resolvedTo = this.toSlot;
        if (this.fromUseItemName) {
            ItemTarget target = this.resolvedFromItemTarget();
            if (!target.hasSlot() && !target.hasIdentity()) {
                return;
            }
            resolvedFrom = PackUtilInventoryHelper.findUserVisibleSlot(mc, target);
            if (resolvedFrom == -1) {
                return;
            }
        }
        if (this.toUseItemName) {
            target = this.resolvedToItemTarget();
            if (!target.hasSlot() && !target.hasIdentity()) {
                return;
            }
            resolvedTo = PackUtilInventoryHelper.findUserVisibleSlot(mc, target);
            if (resolvedTo == -1) {
                return;
            }
        }
        fromHandlerSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, resolvedFrom);
        int toHandlerSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, resolvedTo);
        if (fromHandlerSlot < 0 || toHandlerSlot < 0) {
            return;
        }
        PackUtilInventoryHelper.swapHandlerSlots(mc, fromHandlerSlot, toHandlerSlot);
    }

    public MacroActionType getType() {
        return MacroActionType.SWAP_SLOTS;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "SWAP_SLOTS");
        tag.method_10569("fromSlot", this.fromSlot);
        tag.method_10569("toSlot", this.toSlot);
        ItemTarget fromTarget = this.resolvedFromItemTarget();
        ItemTarget toTarget = this.resolvedToItemTarget();
        if (fromTarget.hasSlot() || fromTarget.hasIdentity()) {
            tag.method_10566("fromItemName", fromTarget.toTag());
        }
        if (toTarget.hasSlot() || toTarget.hasIdentity()) {
            tag.method_10566("toItemName", toTarget.toTag());
        }
        tag.method_10556("fromUseItemName", this.fromUseItemName);
        tag.method_10556("toUseItemName", this.toUseItemName);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.fromSlot = tag.method_68083("fromSlot", -1);
        this.toSlot = tag.method_68083("toSlot", -1);
        this.fromItemTarget = (ItemTarget)tag.method_10562("fromItemName").map(ItemTarget::fromTag).orElseGet(SwapSlotsAction::lambda$fromTag$0 /* captured: tag */);
        this.toItemTarget = (ItemTarget)tag.method_10562("toItemName").map(ItemTarget::fromTag).orElseGet(SwapSlotsAction::lambda$fromTag$1 /* captured: tag */);
        this.fromItemName = this.fromItemTarget.toLegacyEntry();
        this.toItemName = this.toItemTarget.toLegacyEntry();
        this.fromUseItemName = tag.method_10545("fromUseItemName") ? tag.method_68566("fromUseItemName", false) : !this.fromItemName.isEmpty();
        this.toUseItemName = tag.method_10545("toUseItemName") ? tag.method_68566("toUseItemName", false) : !this.toItemName.isEmpty();
        this.useHandlerSlots = true;
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        String from = this.fromUseItemName ? "\"" + this.resolvedFromItemTarget().summaryText() + "\"" : String.valueOf(this.fromSlot);
        String to = this.toUseItemName ? "\"" + this.resolvedToItemTarget().summaryText() + "\"" : String.valueOf(this.toSlot);
        return "Swap " + from + " <-> " + to;
    }

    public String getIcon() {
        return "SWP";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private ItemTarget resolvedFromItemTarget() {
        if (this.fromItemTarget != null) {
            if (this.fromItemTarget.hasSlot() || this.fromItemTarget.hasIdentity()) {
                return this.fromItemTarget;
            }
        }
        this.fromItemTarget = ItemTarget.fromLegacyEntry(this.fromItemName);
        return this.fromItemTarget;
    }

    private ItemTarget resolvedToItemTarget() {
        if (this.toItemTarget != null) {
            if (this.toItemTarget.hasSlot() || this.toItemTarget.hasIdentity()) {
                return this.toItemTarget;
            }
        }
        this.toItemTarget = ItemTarget.fromLegacyEntry(this.toItemName);
        return this.toItemTarget;
    }
}
