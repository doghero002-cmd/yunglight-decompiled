/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum WaitForSlotChangeAction.WaitMode {
    public static final WaitForSlotChangeAction.WaitMode NOT_EMPTY = new WaitForSlotChangeAction.WaitMode("NOT_EMPTY", 0);
    public static final WaitForSlotChangeAction.WaitMode IS_EMPTY = new WaitForSlotChangeAction.WaitMode("IS_EMPTY", 1);
    public static final WaitForSlotChangeAction.WaitMode COUNT_AT_LEAST = new WaitForSlotChangeAction.WaitMode("COUNT_AT_LEAST", 2);
    public static final WaitForSlotChangeAction.WaitMode COUNT_BELOW = new WaitForSlotChangeAction.WaitMode("COUNT_BELOW", 3);
    public static final WaitForSlotChangeAction.WaitMode ANY_CHANGE = new WaitForSlotChangeAction.WaitMode("ANY_CHANGE", 4);
    private static final /* synthetic */ WaitForSlotChangeAction.WaitMode[] $VALUES;

    public static WaitForSlotChangeAction.WaitMode[] values() {
        return (WaitForSlotChangeAction.WaitMode[])$VALUES.clone();
    }

    public static WaitForSlotChangeAction.WaitMode valueOf(String name) {
        return (WaitForSlotChangeAction.WaitMode)Enum.valueOf(WaitForSlotChangeAction.WaitMode.class, name);
    }

    private WaitForSlotChangeAction.WaitMode() {
        super(var1, var2);
    }

    static {
        $VALUES = WaitForSlotChangeAction.WaitMode.$values();
    }
}
