/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum WaitForBlockAction.WaitBehavior {
    public static final WaitForBlockAction.WaitBehavior PLACED = new WaitForBlockAction.WaitBehavior("PLACED", 0);
    public static final WaitForBlockAction.WaitBehavior DESTROYED = new WaitForBlockAction.WaitBehavior("DESTROYED", 1);
    private static final /* synthetic */ WaitForBlockAction.WaitBehavior[] $VALUES;

    public static WaitForBlockAction.WaitBehavior[] values() {
        return (WaitForBlockAction.WaitBehavior[])$VALUES.clone();
    }

    public static WaitForBlockAction.WaitBehavior valueOf(String name) {
        return (WaitForBlockAction.WaitBehavior)Enum.valueOf(WaitForBlockAction.WaitBehavior.class, name);
    }

    private WaitForBlockAction.WaitBehavior() {
        super(var1, var2);
    }

    static {
        $VALUES = WaitForBlockAction.WaitBehavior.$values();
    }
}
