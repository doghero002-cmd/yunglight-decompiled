/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class MineAction
implements MacroAction {
    public List<String> targetBlocks = new ArrayList();
    public boolean stopInventoryFull = false;
    public boolean stopSlotsUsed = false;
    public int slotsUsedThreshold = 18;
    public boolean stopMinedCount = false;
    public int minedCountTarget = 64;
    public boolean stopAfterTime = false;
    public int timeoutSeconds = 60;
    private boolean enabled = true;

    public MacroActionType getType() {
        return MacroActionType.MINE;
    }

    public void execute(class_310 mc) {
    }

    public String getDisplayName() {
        if (this.targetBlocks.isEmpty()) {
            return "Mine: (none)";
        }
        String first = PackUtilRegistryLabels.block((String)this.targetBlocks.get(0));
        return this.targetBlocks.size() == 1 ? "Mine: " + first : "Mine: " + first + " (+" + this.targetBlocks.size() - 1 + ")";
    }

    public String getIcon() {
        return "MN";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        class_2499 list = new class_2499();
        var var3 = this.targetBlocks.iterator();
        while (var3.hasNext()) {
            String id = (String)var3.next();
            list.add(class_2519.method_23256(id));
        }
        tag.method_10566("targetBlocks", list);
        tag.method_10556("stopInventoryFull", this.stopInventoryFull);
        tag.method_10556("stopSlotsUsed", this.stopSlotsUsed);
        tag.method_10569("slotsUsedThreshold", this.slotsUsedThreshold);
        tag.method_10556("stopMinedCount", this.stopMinedCount);
        tag.method_10569("minedCountTarget", this.minedCountTarget);
        tag.method_10556("stopAfterTime", this.stopAfterTime);
        tag.method_10569("timeoutSeconds", this.timeoutSeconds);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.targetBlocks.clear();
        if (!tag.method_10545("targetBlocks")) { /* goto L103; */ }
        class_2499 list = (class_2499)tag.method_10554("targetBlocks").orElse(new class_2499());
        var var3 = list.iterator();
        while (var3.hasNext()) {
            class_2520 el = (class_2520)var3.next();
            String s = (String)el.method_68658().orElse("");
            if (s.isEmpty()) continue;
            this.targetBlocks.add(s);
        }
        this.stopInventoryFull = tag.method_68566("stopInventoryFull", false);
        this.stopSlotsUsed = tag.method_68566("stopSlotsUsed", false);
        this.slotsUsedThreshold = tag.method_68083("slotsUsedThreshold", 18);
        this.stopMinedCount = tag.method_68566("stopMinedCount", false);
        this.minedCountTarget = tag.method_68083("minedCountTarget", 64);
        this.stopAfterTime = tag.method_68566("stopAfterTime", false);
        this.timeoutSeconds = tag.method_68083("timeoutSeconds", 60);
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }
}
