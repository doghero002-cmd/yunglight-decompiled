/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.WaitForSoundAction;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;

static class MacroConditionRegistry.SoundCondition
implements MacroConditionRegistry.PendingCondition {
    final WaitForSoundAction action;
    final CompletableFuture<Void> future;
    private volatile boolean cancelled = false;

    MacroConditionRegistry.SoundCondition(WaitForSoundAction action, CompletableFuture<Void> future) {
        this.action = action;
        this.future = future;
    }

    public boolean matches(class_310 mc, String soundId, double x, double y, double z) {
        if (this.action.soundIds.isEmpty()) { /* goto L79; */ }
        boolean found = false;
        var var10 = this.action.soundIds.iterator();
        while (var10.hasNext()) {
            String id = (String)var10.next();
            if (!id.equalsIgnoreCase(soundId)) { /* goto @69; */ }
            found = true;
            break;
        }
        if (!found) {
            return false;
        }
        if (this.action.checkDistance) {
            if (mc.field_1724 != null) {
                dx = mc.field_1724.method_23317() - x;
                dy = mc.field_1724.method_23318() - y;
                double dz = mc.field_1724.method_23321() - z;
                if (dx * dx + dy * dy + dz * dz > this.action.maxDistance * this.action.maxDistance) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean check(class_310 mc) {
        return false;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.cancelled = true;
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.cancelled || this.future.isCancelled();
    }
}
