/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.mixin.accessor.PackUtilClientConnectionAccessor;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.PackUtilContainerTarget;
import com.example.addon.util.PackUtilCraftingHelper;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PacketRegenerator;
import com.example.addon.util.macro.ClickAction;
import com.example.addon.util.macro.CraftAction;
import com.example.addon.util.macro.DelayAction;
import com.example.addon.util.macro.DisconnectAction;
import com.example.addon.util.macro.GoToAction;
import com.example.addon.util.macro.InventoryAuditAction;
import com.example.addon.util.macro.ItemAction;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.JumpAction;
import com.example.addon.util.macro.LookAtBlockAction;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.MineAction;
import com.example.addon.util.macro.MoveAction;
import com.example.addon.util.macro.NbtBookAction;
import com.example.addon.util.macro.PayAction;
import com.example.addon.util.macro.RepeatAction;
import com.example.addon.util.macro.RevisionSyncAction;
import com.example.addon.util.macro.RotateAction;
import com.example.addon.util.macro.SendPacketAction;
import com.example.addon.util.macro.ServerTickSyncAction;
import com.example.addon.util.macro.ServerTickTracker;
import com.example.addon.util.macro.SneakAction;
import com.example.addon.util.macro.SprintAction;
import com.example.addon.util.macro.StopMacroAction;
import com.example.addon.util.macro.StoreItemAction;
import com.example.addon.util.macro.TickSyncAction;
import com.example.addon.util.macro.UseItemAction;
import com.example.addon.util.macro.WaitForBlockAction;
import com.example.addon.util.macro.WaitForChatAction;
import com.example.addon.util.macro.WaitForCooldownAction;
import com.example.addon.util.macro.WaitForEntityAction;
import com.example.addon.util.macro.WaitForGuiAction;
import com.example.addon.util.macro.WaitForHealthAction;
import com.example.addon.util.macro.WaitForLanStepAction;
import com.example.addon.util.macro.WaitForPacketAction;
import com.example.addon.util.macro.WaitForSlotChangeAction;
import com.example.addon.util.macro.WaitForSoundAction;
import com.example.addon.util.macro.WaitPosAction;
import com.example.addon.util.macro.WaitsForGui;
import com.example.addon.util.macro.XCarryAction;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import java.lang.reflect.Method;
import java.lang.reflect.RecordComponent;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.text.Normalizer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_640;
import net.minecraft.class_642;
import net.minecraft.class_742;
import net.minecraft.class_7438;
import net.minecraft.class_7439;
import net.minecraft.class_746;
import net.minecraft.class_7827;
import net.minecraft.class_7923;
import net.minecraft.class_8824;

public class MacroExecutor {
    private static final Gson GSON = new Gson();
    private static final AtomicBoolean isRunning = new AtomicBoolean(false);
    private static PackUtilMacro currentMacro = null;
    private static Thread macroThread = null;
    private static final AtomicReference<String> lastReceivedPacket = new AtomicReference("");
    private static String currentStatus = "";
    private static volatile int currentStepIndex = -1;
    private static volatile int totalSteps = 0;
    private static final AtomicBoolean isWaitingForPacket = new AtomicBoolean(false);
    private static final AtomicReference<String> waitingPacketName = new AtomicReference("");
    private static final Object packetWaitLock = new Object();
    private static final AtomicBoolean isWaitingForChat = new AtomicBoolean(false);
    private static final AtomicReference<String> waitingChatPattern = new AtomicReference("");
    private static final AtomicBoolean waitingChatIsRegex = new AtomicBoolean(false);
    private static final AtomicReference<String> waitingChatPatternJson = new AtomicReference("");
    private static final AtomicInteger waitingChatFuzzyPercent = new AtomicInteger(100);
    private static final AtomicBoolean waitingChatServerOnly = new AtomicBoolean(false);
    private static final AtomicReference<String> lastMatchedChat = new AtomicReference("");
    private static final Object recentChatLock = new Object();
    private static final Deque<MacroExecutor.RecentChatMessage> recentChatMessages = new ArrayDeque();
    private static final int MAX_RECENT_CHAT_MESSAGES = 60;
    private static String recentChatServerKey = "";
    private static volatile CompletableFuture<Void> activePacketFuture = null;
    private static volatile CompletableFuture<Void> activeChatFuture = null;
    private static volatile CompletableFuture<Void> activeBaritoneGoalFuture = null;
    private static final AtomicBoolean isRotating = new AtomicBoolean(false);
    private static float targetYaw;
    private static float targetPitch;
    private static double rotationSpeed;
    private static int rotationAlignedFrames;
    private static final CopyOnWriteArrayList<MacroAction> persistentActions = new CopyOnWriteArrayList();
    private static final ConcurrentHashMap<MoveAction, int[]> backgroundMoves = new ConcurrentHashMap();

    public static void execute(PackUtilMacro macro) {
        if (isRunning.get()) {
            PackUtilClientMessaging.sendPrefixed("Â§cMacro already running!");
            return;
        }
        if (macro.actions.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("Â§cMacro has no actions!");
            return;
        }
        currentMacro = macro;
        isRunning.set(true);
        PackUtilClientMessaging.sendPrefixed("Â§aStarted macro: " + macro.name);
        try {
            PackUtilLANSync sync = PackUtilLANSync.getInstance();
            if (sync.isInSession()) {
                sync.broadcastStepProgress(0, macro.actions.size(), macro.name);
            }
        }
        catch (Exception sync) {
            macroThread = new Thread(MacroExecutor::lambda$execute$0 /* captured: macro */, "PackUtil-Macro-Thread");
            macroThread.start();
            return;
        }
        macroThread = new Thread(MacroExecutor::lambda$execute$0 /* captured: macro */, "PackUtil-Macro-Thread");
        macroThread.start();
    }

    private static void run(PackUtilMacro macro) {
        /* decompile fallback: decompile timeout (preflight complexity guard: code_len=5170, exception_table=34, branches=335) */
        /* decompile technical detail:
         * category: timeout
         * stage: preflight_complexity_analysis
         * detail: decompile timeout (preflight complexity guard: code_len=5170, exception_table=34, branches=335)
         * explanation: budgeted mode rejected this method before structured decompilation because the bytecode complexity metrics exceeded the configured low-budget guardrail
         * emitted_body: raw bytecode disassembly follows
         */
        /* @obfuscation score:2/10 signals:fallback_preflight_complexity_guard hint:complex but likely not obfuscated — LLM should do well */
        /* bytecode:
          0000: invokestatic #273 // net.minecraft.class_310.method_1551()Lnet.minecraft.class_310;
          0003: astore_1
          0004: iconst_0
          0005: istore_2
          0006: aload_0
          0007: getfield #277 // com.example.addon.util.PackUtilMacro.loop:Z
          000a: ifeq 34
          000d: aload_0
          000e: getfield #280 // com.example.addon.util.PackUtilMacro.loopCount:I
          0011: iconst_m1
          0012: if_icmpne 27
          0015: ldc_w #281 // 2147483647
          0018: goto 35
          001b: aload_0
          001c: getfield #280 // com.example.addon.util.PackUtilMacro.loopCount:I
          001f: goto 35
          0022: iconst_1
          0023: istore_3
          0024: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0027: invokevirtual #288 // java.util.concurrent.CopyOnWriteArrayList.clear()V
          002a: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          002d: invokevirtual #293 // java.util.concurrent.ConcurrentHashMap.clear()V
          0030: new #235 // class java.lang.Thread
          0033: dup
          0034: aload_1
          0035: invokedynamic #301 // invokedynamic(bsm=2) run(Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          003a: ldc_w #303 // "PackUtil-Persistent-Thread"
          003d: invokespecial #256 // java.lang.Thread.<init>(Ljava.lang.Runnable;Ljava.lang.String;)V
          0040: astore 4
          0042: aload 4
          0044: iconst_1
          0045: invokevirtual #306 // java.lang.Thread.setDaemon(Z)V
          0048: aload 4
          004a: invokevirtual #261 // java.lang.Thread.start()V
          004d: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0050: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0053: ifeq 4796
          0056: iload_2
          0057: iload_3
          0058: if_icmpge 4796
          005b: aload_0
          005c: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          005f: invokeinterface #193 count=1 // java.util.List.isEmpty()Z
          0064: ifeq 112
          0067: ldc_w #308 // "Â§cMacro stopped: no actions left."
          006a: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          006d: goto 4796
          0070: iload_2
          0071: iconst_1
          0072: iadd
          0073: iload_3
          0074: ldc_w #281 // 2147483647
          0077: if_icmpne 128
          007a: ldc_w #310 // ""
          007d: goto 134
          0080: iload_3
          0081: invokedynamic #315 // invokedynamic(bsm=3) makeConcatWithConstants(I)Ljava.lang.String;
          0086: invokedynamic #322 // invokedynamic(bsm=4) makeConcatWithConstants(ILjava.lang.String;)Ljava.lang.String;
          008b: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          008e: invokestatic #329 // com.example.addon.modules.PackUtilModule.get()Lcom.example.addon.modules.PackUtilModule;
          0091: astore 5
          0093: aload 5
          0095: invokevirtual #332 // com.example.addon.modules.PackUtilModule.usePacketBurstMode()Z
          0098: istore 6
          009a: aload_0
          009b: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          009e: invokeinterface #229 count=1 // java.util.List.size()I
          00a3: putstatic #334 // com.example.addon.util.macro.MacroExecutor.totalSteps:I
          00a6: iconst_0
          00a7: istore 7
          00a9: iload 7
          00ab: aload_0
          00ac: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          00af: invokeinterface #229 count=1 // java.util.List.size()I
          00b4: if_icmpge 4658
          00b7: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          00ba: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          00bd: ifne 195
          00c0: goto 4658
          00c3: iload 7
          00c5: putstatic #336 // com.example.addon.util.macro.MacroExecutor.currentStepIndex:I
          00c8: aload_0
          00c9: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          00cc: iload 7
          00ce: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          00d3: checkcast #341 // class com.example.addon.util.macro.MacroAction
          00d6: astore 8
          00d8: aload 8
          00da: invokeinterface #344 count=1 // com.example.addon.util.macro.MacroAction.isEnabled()Z
          00df: ifne 229
          00e2: goto 4652
          00e5: aconst_null
          00e6: astore 9
          00e8: aload 8
          00ea: instanceof #346 // class com.example.addon.util.macro.WaitsForGui
          00ed: ifeq 291
          00f0: aload 8
          00f2: checkcast #346 // class com.example.addon.util.macro.WaitsForGui
          00f5: astore 10
          00f7: aload 10
          00f9: invokeinterface #349 count=1 // com.example.addon.util.macro.WaitsForGui.isWaitForGui()Z
          00fe: ifeq 291
          0101: aload 10
          0103: invokeinterface #352 count=1 // com.example.addon.util.macro.WaitsForGui.isWaitForGuiChange()Z
          0108: ifeq 279
          010b: aload_1
          010c: getfield #356 // net.minecraft.class_310.field_1755:Lnet.minecraft.class_437;
          010f: invokestatic #362 // com.example.addon.util.macro.MacroConditionRegistry.waitForGuiChange(Lnet.minecraft.class_437;)Ljava.util.concurrent.CompletableFuture;
          0112: astore 9
          0114: goto 291
          0117: aload 10
          0119: invokeinterface #368 count=1 // com.example.addon.util.macro.WaitsForGui.getWaitGuiName()Ljava.lang.String;
          011e: invokestatic #372 // com.example.addon.util.macro.MacroConditionRegistry.waitForGui(Ljava.lang.String;)Ljava.util.concurrent.CompletableFuture;
          0121: astore 9
          0123: iload 6
          0125: ifeq 391
          0128: aload 8
          012a: instanceof #374 // class com.example.addon.util.macro.SendPacketAction
          012d: ifeq 391
          0130: new #376 // class java.util.ArrayList
          0133: dup
          0134: invokespecial #377 // java.util.ArrayList.<init>()V
          0137: astore 10
          0139: iload 7
          013b: istore 11
          013d: iload 11
          013f: aload_0
          0140: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          0143: invokeinterface #229 count=1 // java.util.List.size()I
          0148: if_icmpge 376
          014b: aload_0
          014c: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          014f: iload 11
          0151: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          0156: instanceof #374 // class com.example.addon.util.macro.SendPacketAction
          0159: ifeq 376
          015c: aload 10
          015e: aload_0
          015f: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          0162: iload 11
          0164: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          0169: checkcast #374 // class com.example.addon.util.macro.SendPacketAction
          016c: invokeinterface #381 count=2 // java.util.List.add(Ljava.lang.Object;)Z
          0171: pop
          0172: iinc 11 1
          0175: goto 317
          0178: aload_1
          0179: aload 10
          017b: invokestatic #385 // com.example.addon.util.macro.MacroExecutor.executeBurstPackets(Lnet.minecraft.class_310;Ljava.util.List;)V
          017e: iload 11
          0180: iconst_1
          0181: isub
          0182: istore 7
          0184: goto 4652
          0187: aload 8
          0189: instanceof #387 // class com.example.addon.util.macro.DelayAction
          018c: ifeq 470
          018f: aload 8
          0191: checkcast #387 // class com.example.addon.util.macro.DelayAction
          0194: astore 15
          0196: aload 15
          0198: getfield #390 // com.example.addon.util.macro.DelayAction.useTicks:Z
          019b: ifeq 458
          019e: iconst_0
          019f: istore 16
          01a1: iload 16
          01a3: aload 15
          01a5: getfield #393 // com.example.addon.util.macro.DelayAction.delayTicks:I
          01a8: if_icmpge 455
          01ab: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          01ae: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          01b1: ifne 439
          01b4: goto 455
          01b7: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          01ba: astore 17
          01bc: aload 17
          01be: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          01c1: iinc 16 1
          01c4: goto 417
          01c7: goto 467
          01ca: aload 15
          01cc: getfield #404 // com.example.addon.util.macro.DelayAction.delayMs:I
          01cf: i2l
          01d0: invokestatic #408 // java.lang.Thread.sleep(J)V
          01d3: goto 4529
          01d6: aload 8
          01d8: instanceof #410 // class com.example.addon.util.macro.WaitForPacketAction
          01db: ifeq 561
          01de: aload 8
          01e0: checkcast #410 // class com.example.addon.util.macro.WaitForPacketAction
          01e3: invokevirtual #414 // com.example.addon.util.macro.WaitForPacketAction.effectiveList()Ljava.util.List;
          01e6: astore 15
          01e8: aload 15
          01ea: invokeinterface #193 count=1 // java.util.List.isEmpty()Z
          01ef: ifeq 507
          01f2: ldc_w #310 // ""
          01f5: invokestatic #417 // com.example.addon.util.macro.MacroExecutor.awaitPacket(Ljava.lang.String;)V
          01f8: goto 558
          01fb: aload 15
          01fd: invokeinterface #421 count=1 // java.util.List.iterator()Ljava.util.Iterator;
          0202: astore 16
          0204: aload 16
          0206: invokeinterface #426 count=1 // java.util.Iterator.hasNext()Z
          020b: ifeq 558
          020e: aload 16
          0210: invokeinterface #430 count=1 // java.util.Iterator.next()Ljava.lang.Object;
          0215: checkcast #317 // class java.lang.String
          0218: astore 17
          021a: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          021d: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0220: ifne 550
          0223: goto 558
          0226: aload 17
          0228: invokestatic #417 // com.example.addon.util.macro.MacroExecutor.awaitPacket(Ljava.lang.String;)V
          022b: goto 516
          022e: goto 4529
          0231: aload 8
          0233: instanceof #432 // class com.example.addon.util.macro.WaitForHealthAction
          0236: ifeq 612
          0239: aload 8
          023b: checkcast #432 // class com.example.addon.util.macro.WaitForHealthAction
          023e: astore 15
          0240: aload 15
          0242: invokevirtual #435 // com.example.addon.util.macro.WaitForHealthAction.waitingStatusText()Ljava.lang.String;
          0245: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0248: aload 15
          024a: getfield #438 // com.example.addon.util.macro.WaitForHealthAction.healthThreshold:F
          024d: aload 15
          024f: getfield #441 // com.example.addon.util.macro.WaitForHealthAction.below:Z
          0252: invokestatic #445 // com.example.addon.util.macro.MacroConditionRegistry.waitForHealth(FZ)Ljava.util.concurrent.CompletableFuture;
          0255: astore 16
          0257: aload 16
          0259: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          025c: goto 609
          025f: astore 16
          0261: goto 4529
          0264: aload 8
          0266: instanceof #447 // class com.example.addon.util.macro.WaitForBlockAction
          0269: ifeq 655
          026c: aload 8
          026e: checkcast #447 // class com.example.addon.util.macro.WaitForBlockAction
          0271: astore 15
          0273: aload 15
          0275: invokevirtual #450 // com.example.addon.util.macro.WaitForBlockAction.getDisplayName()Ljava.lang.String;
          0278: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          027b: aload 15
          027d: invokestatic #454 // com.example.addon.util.macro.MacroConditionRegistry.waitForBlock(Lcom.example.addon.util.macro.WaitForBlockAction;)Ljava.util.concurrent.CompletableFuture;
          0280: astore 16
          0282: aload 16
          0284: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0287: goto 652
          028a: astore 16
          028c: goto 4529
          028f: aload 8
          0291: instanceof #17 // class com.example.addon.util.macro.WaitForGuiAction
          0294: ifeq 753
          0297: aload 8
          0299: checkcast #17 // class com.example.addon.util.macro.WaitForGuiAction
          029c: astore 15
          029e: aload 15
          02a0: getfield #458 // com.example.addon.util.macro.WaitForGuiAction.waitMode:Lcom.example.addon.util.macro.WaitForGuiAction$WaitMode;
          02a3: getstatic #461 // com.example.addon.util.macro.WaitForGuiAction$WaitMode.CLOSE:Lcom.example.addon.util.macro.WaitForGuiAction$WaitMode;
          02a6: if_acmpne 717
          02a9: aload 15
          02ab: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          02ae: invokedynamic #467 // invokedynamic(bsm=5) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          02b3: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          02b6: aload 15
          02b8: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          02bb: invokestatic #470 // com.example.addon.util.macro.MacroConditionRegistry.waitForGuiClose(Ljava.lang.String;)Ljava.util.concurrent.CompletableFuture;
          02be: astore 16
          02c0: aload 16
          02c2: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          02c5: goto 750
          02c8: astore 16
          02ca: goto 750
          02cd: aload 15
          02cf: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          02d2: invokedynamic #473 // invokedynamic(bsm=6) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          02d7: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          02da: aload 15
          02dc: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          02df: invokestatic #372 // com.example.addon.util.macro.MacroConditionRegistry.waitForGui(Ljava.lang.String;)Ljava.util.concurrent.CompletableFuture;
          02e2: astore 16
          02e4: aload 16
          02e6: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          02e9: goto 750
          02ec: astore 16
          02ee: goto 4529
          02f1: aload 8
          02f3: instanceof #475 // class com.example.addon.util.macro.WaitForCooldownAction
          02f6: ifeq 853
          02f9: aload 8
          02fb: checkcast #475 // class com.example.addon.util.macro.WaitForCooldownAction
          02fe: astore 15
          0300: aload 15
          0302: getfield #479 // com.example.addon.util.macro.WaitForCooldownAction.itemTarget:Lcom.example.addon.util.macro.ItemTarget;
          0305: aload 15
          0307: getfield #482 // com.example.addon.util.macro.WaitForCooldownAction.itemName:Ljava.lang.String;
          030a: invokestatic #486 // com.example.addon.util.macro.MacroExecutor.resolveItemTarget(Lcom.example.addon.util.macro.ItemTarget;Ljava.lang.String;)Lcom.example.addon.util.macro.ItemTarget;
          030d: astore 16
          030f: aload 16
          0311: invokestatic #490 // com.example.addon.util.macro.MacroExecutor.describeItemTarget(Lcom.example.addon.util.macro.ItemTarget;)Ljava.lang.String;
          0314: astore 17
          0316: aload 17
          0318: invokevirtual #491 // java.lang.String.isEmpty()Z
          031b: ifne 803
          031e: aload 17
          0320: goto 820
          0323: aload 15
          0325: getfield #496 // com.example.addon.util.macro.WaitForCooldownAction.checkMainHand:Z
          0328: ifeq 817
          032b: ldc_w #498 // "Main Hand"
          032e: goto 820
          0331: ldc_w #500 // "Off Hand"
          0334: invokedynamic #503 // invokedynamic(bsm=7) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0339: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          033c: aload 16
          033e: aload 15
          0340: getfield #496 // com.example.addon.util.macro.WaitForCooldownAction.checkMainHand:Z
          0343: invokestatic #507 // com.example.addon.util.macro.MacroConditionRegistry.waitForCooldown(Lcom.example.addon.util.macro.ItemTarget;Z)Ljava.util.concurrent.CompletableFuture;
          0346: astore 18
          0348: aload 18
          034a: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          034d: goto 850
          0350: astore 18
          0352: goto 4529
          0355: aload 8
          0357: instanceof #509 // class com.example.addon.util.macro.WaitPosAction
          035a: ifeq 977
          035d: aload 8
          035f: checkcast #509 // class com.example.addon.util.macro.WaitPosAction
          0362: astore 15
          0364: ldc_w #511 // "%.0f, %.0f, %.0f"
          0367: iconst_3
          0368: anewarray #4 // class java.lang.Object
          036b: dup
          036c: iconst_0
          036d: aload 15
          036f: getfield #514 // com.example.addon.util.macro.WaitPosAction.x:D
          0372: invokestatic #520 // java.lang.Double.valueOf(D)Ljava.lang.Double;
          0375: aastore
          0376: dup
          0377: iconst_1
          0378: aload 15
          037a: getfield #523 // com.example.addon.util.macro.WaitPosAction.y:D
          037d: invokestatic #520 // java.lang.Double.valueOf(D)Ljava.lang.Double;
          0380: aastore
          0381: dup
          0382: iconst_2
          0383: aload 15
          0385: getfield #526 // com.example.addon.util.macro.WaitPosAction.z:D
          0388: invokestatic #520 // java.lang.Double.valueOf(D)Ljava.lang.Double;
          038b: aastore
          038c: invokestatic #530 // java.lang.String.format(Ljava.lang.String;[Ljava.lang.Object;)Ljava.lang.String;
          038f: invokedynamic #533 // invokedynamic(bsm=8) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0394: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0397: aload 15
          0399: getfield #514 // com.example.addon.util.macro.WaitPosAction.x:D
          039c: aload 15
          039e: getfield #523 // com.example.addon.util.macro.WaitPosAction.y:D
          03a1: aload 15
          03a3: getfield #526 // com.example.addon.util.macro.WaitPosAction.z:D
          03a6: aload 15
          03a8: getfield #536 // com.example.addon.util.macro.WaitPosAction.leeway:D
          03ab: aload 15
          03ad: getfield #539 // com.example.addon.util.macro.WaitPosAction.checkRotation:Z
          03b0: aload 15
          03b2: getfield #542 // com.example.addon.util.macro.WaitPosAction.yaw:F
          03b5: aload 15
          03b7: getfield #545 // com.example.addon.util.macro.WaitPosAction.pitch:F
          03ba: aload 15
          03bc: getfield #548 // com.example.addon.util.macro.WaitPosAction.rotLeeway:F
          03bf: invokestatic #552 // com.example.addon.util.macro.MacroConditionRegistry.waitForPos(DDDDZFFF)Ljava.util.concurrent.CompletableFuture;
          03c2: astore 16
          03c4: aload 16
          03c6: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          03c9: goto 974
          03cc: astore 16
          03ce: goto 4529
          03d1: aload 8
          03d3: instanceof #554 // class com.example.addon.util.macro.JumpAction
          03d6: ifeq 1078
          03d9: aload 8
          03db: checkcast #554 // class com.example.addon.util.macro.JumpAction
          03de: astore 15
          03e0: aload_1
          03e1: aload 15
          03e3: aload_1
          03e4: invokedynamic #562 // invokedynamic(bsm=9) run(Lcom.example.addon.util.macro.JumpAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          03e9: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          03ec: aload 15
          03ee: getfield #568 // com.example.addon.util.macro.JumpAction.tap:Z
          03f1: ifeq 1025
          03f4: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          03f7: astore 16
          03f9: aload 16
          03fb: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          03fe: goto 1063
          0401: iconst_0
          0402: istore 16
          0404: iload 16
          0406: aload 15
          0408: getfield #571 // com.example.addon.util.macro.JumpAction.durationTicks:I
          040b: if_icmpge 1063
          040e: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0411: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0414: ifeq 1063
          0417: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          041a: astore 17
          041c: aload 17
          041e: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0421: iinc 16 1
          0424: goto 1028
          0427: aload_1
          0428: aload 15
          042a: aload_1
          042b: invokedynamic #576 // invokedynamic(bsm=10) run(Lcom.example.addon.util.macro.JumpAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0430: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0433: goto 4529
          0436: aload 8
          0438: instanceof #578 // class com.example.addon.util.macro.SneakAction
          043b: ifeq 1168
          043e: aload 8
          0440: checkcast #578 // class com.example.addon.util.macro.SneakAction
          0443: astore 15
          0445: aload_1
          0446: aload 15
          0448: aload_1
          0449: invokedynamic #586 // invokedynamic(bsm=11) run(Lcom.example.addon.util.macro.SneakAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          044e: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0451: aload 15
          0453: getfield #589 // com.example.addon.util.macro.SneakAction.persistent:Z
          0456: ifeq 1145
          0459: aload 15
          045b: getfield #592 // com.example.addon.util.macro.SneakAction.sneak:Z
          045e: ifeq 1145
          0461: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0464: invokedynamic #603 // invokedynamic(bsm=12) test()Ljava.util.function.Predicate;
          0469: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          046c: pop
          046d: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0470: aload 15
          0472: invokevirtual #608 // java.util.concurrent.CopyOnWriteArrayList.add(Ljava.lang.Object;)Z
          0475: pop
          0476: goto 1165
          0479: aload 15
          047b: getfield #592 // com.example.addon.util.macro.SneakAction.sneak:Z
          047e: ifne 1165
          0481: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0484: invokedynamic #613 // invokedynamic(bsm=13) test()Ljava.util.function.Predicate;
          0489: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          048c: pop
          048d: goto 4529
          0490: aload 8
          0492: instanceof #615 // class com.example.addon.util.macro.SprintAction
          0495: ifeq 1258
          0498: aload 8
          049a: checkcast #615 // class com.example.addon.util.macro.SprintAction
          049d: astore 15
          049f: aload_1
          04a0: aload 15
          04a2: aload_1
          04a3: invokedynamic #623 // invokedynamic(bsm=14) run(Lcom.example.addon.util.macro.SprintAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          04a8: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          04ab: aload 15
          04ad: getfield #624 // com.example.addon.util.macro.SprintAction.persistent:Z
          04b0: ifeq 1235
          04b3: aload 15
          04b5: getfield #627 // com.example.addon.util.macro.SprintAction.sprint:Z
          04b8: ifeq 1235
          04bb: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          04be: invokedynamic #632 // invokedynamic(bsm=15) test()Ljava.util.function.Predicate;
          04c3: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          04c6: pop
          04c7: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          04ca: aload 15
          04cc: invokevirtual #608 // java.util.concurrent.CopyOnWriteArrayList.add(Ljava.lang.Object;)Z
          04cf: pop
          04d0: goto 1255
          04d3: aload 15
          04d5: getfield #627 // com.example.addon.util.macro.SprintAction.sprint:Z
          04d8: ifne 1255
          04db: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          04de: invokedynamic #637 // invokedynamic(bsm=16) test()Ljava.util.function.Predicate;
          04e3: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          04e6: pop
          04e7: goto 4529
          04ea: aload 8
          04ec: instanceof #22 // class com.example.addon.util.macro.DisconnectAction
          04ef: ifeq 1663
          04f2: aload 8
          04f4: checkcast #22 // class com.example.addon.util.macro.DisconnectAction
          04f7: astore 15
          04f9: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          04fc: astore 16
          04fe: aload 16
          0500: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          0503: ifeq 1308
          0506: aload 16
          0508: iload 7
          050a: iconst_1
          050b: iadd
          050c: aload_0
          050d: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          0510: invokeinterface #229 count=1 // java.util.List.size()I
          0515: aload_0
          0516: getfield #204 // com.example.addon.util.PackUtilMacro.name:Ljava.lang.String;
          0519: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          051c: goto 1313
          051f: astore 16
          0521: aload 15
          0523: getfield #641 // com.example.addon.util.macro.DisconnectAction.mode:Lcom.example.addon.util.macro.DisconnectAction$DisconnectMode;
          0526: getstatic #644 // com.example.addon.util.macro.DisconnectAction$DisconnectMode.DISCONNECT:Lcom.example.addon.util.macro.DisconnectAction$DisconnectMode;
          0529: if_acmpne 1356
          052c: aload 15
          052e: getfield #645 // com.example.addon.util.macro.DisconnectAction.delayMs:I
          0531: ifle 1341
          0534: aload 15
          0536: getfield #645 // com.example.addon.util.macro.DisconnectAction.delayMs:I
          0539: i2l
          053a: invokestatic #408 // java.lang.Thread.sleep(J)V
          053d: aload_1
          053e: aload 15
          0540: aload_1
          0541: invokedynamic #653 // invokedynamic(bsm=17) run(Lcom.example.addon.util.macro.DisconnectAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0546: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0549: goto 1653
          054c: aload 15
          054e: getfield #641 // com.example.addon.util.macro.DisconnectAction.mode:Lcom.example.addon.util.macro.DisconnectAction$DisconnectMode;
          0551: getstatic #656 // com.example.addon.util.macro.DisconnectAction$DisconnectMode.AUTO_DISCONNECT:Lcom.example.addon.util.macro.DisconnectAction$DisconnectMode;
          0554: if_acmpne 1398
          0557: aload 15
          0559: getfield #660 // com.example.addon.util.macro.DisconnectAction.trigger:Lcom.example.addon.util.macro.DisconnectAction$AutoTrigger;
          055c: invokevirtual #662 // com.example.addon.util.macro.DisconnectAction$AutoTrigger.name()Ljava.lang.String;
          055f: invokedynamic #665 // invokedynamic(bsm=18) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0564: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0567: aload 15
          0569: aload_1
          056a: invokevirtual #667 // com.example.addon.util.macro.DisconnectAction.execute(Lnet.minecraft.class_310;)V
          056d: ldc_w #669 // "Auto Disconnect: executed"
          0570: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0573: goto 1653
          0576: aload 15
          0578: getfield #641 // com.example.addon.util.macro.DisconnectAction.mode:Lcom.example.addon.util.macro.DisconnectAction$DisconnectMode;
          057b: getstatic #672 // com.example.addon.util.macro.DisconnectAction$DisconnectMode.KICK_DUPE:Lcom.example.addon.util.macro.DisconnectAction$DisconnectMode;
          057e: if_acmpne 1641
          0581: aload 15
          0583: getfield #675 // com.example.addon.util.macro.DisconnectAction.useNextAction:Z
          0586: ifeq 1641
          0589: new #376 // class java.util.ArrayList
          058c: dup
          058d: invokespecial #377 // java.util.ArrayList.<init>()V
          0590: astore 16
          0592: iconst_m1
          0593: istore 17
          0595: iload 7
          0597: iconst_1
          0598: iadd
          0599: istore 18
          059b: iload 18
          059d: aload_0
          059e: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          05a1: invokeinterface #229 count=1 // java.util.List.size()I
          05a6: if_icmpge 1608
          05a9: aload_0
          05aa: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          05ad: iload 18
          05af: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          05b4: checkcast #341 // class com.example.addon.util.macro.MacroAction
          05b7: astore 19
          05b9: aload 19
          05bb: instanceof #22 // class com.example.addon.util.macro.DisconnectAction
          05be: ifeq 1476
          05c1: goto 1608
          05c4: aload 19
          05c6: invokeinterface #344 count=1 // com.example.addon.util.macro.MacroAction.isEnabled()Z
          05cb: ifne 1489
          05ce: goto 1602
          05d1: aload 19
          05d3: instanceof #387 // class com.example.addon.util.macro.DelayAction
          05d6: ifne 1602
          05d9: aload 19
          05db: instanceof #432 // class com.example.addon.util.macro.WaitForHealthAction
          05de: ifne 1602
          05e1: aload 19
          05e3: instanceof #447 // class com.example.addon.util.macro.WaitForBlockAction
          05e6: ifne 1602
          05e9: aload 19
          05eb: instanceof #17 // class com.example.addon.util.macro.WaitForGuiAction
          05ee: ifne 1602
          05f1: aload 19
          05f3: instanceof #475 // class com.example.addon.util.macro.WaitForCooldownAction
          05f6: ifne 1602
          05f9: aload 19
          05fb: instanceof #509 // class com.example.addon.util.macro.WaitPosAction
          05fe: ifne 1602
          0601: aload 19
          0603: instanceof #677 // class com.example.addon.util.macro.WaitForEntityAction
          0606: ifne 1602
          0609: aload 19
          060b: instanceof #679 // class com.example.addon.util.macro.WaitForSoundAction
          060e: ifne 1602
          0611: aload 19
          0613: instanceof #681 // class com.example.addon.util.macro.WaitForSlotChangeAction
          0616: ifne 1602
          0619: aload 19
          061b: instanceof #410 // class com.example.addon.util.macro.WaitForPacketAction
          061e: ifne 1602
          0621: aload 19
          0623: instanceof #683 // class com.example.addon.util.macro.WaitForChatAction
          0626: ifne 1602
          0629: aload 19
          062b: instanceof #685 // class com.example.addon.util.macro.GoToAction
          062e: ifeq 1588
          0631: goto 1602
          0634: aload 16
          0636: aload 19
          0638: invokeinterface #381 count=2 // java.util.List.add(Ljava.lang.Object;)Z
          063d: pop
          063e: iload 18
          0640: istore 17
          0642: iinc 18 1
          0645: goto 1435
          0648: aload 15
          064a: aload 16
          064c: invokevirtual #689 // com.example.addon.util.macro.DisconnectAction.setNextActions(Ljava.util.List;)V
          064f: aload_1
          0650: aload 15
          0652: aload_1
          0653: invokedynamic #694 // invokedynamic(bsm=19) run(Lcom.example.addon.util.macro.DisconnectAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0658: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          065b: iload 17
          065d: iload 7
          065f: if_icmple 1638
          0662: iload 17
          0664: istore 7
          0666: goto 1653
          0669: aload_1
          066a: aload 15
          066c: aload_1
          066d: invokedynamic #699 // invokedynamic(bsm=20) run(Lcom.example.addon.util.macro.DisconnectAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0672: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0675: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0678: iconst_0
          0679: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          067c: goto 4658
          067f: aload 8
          0681: instanceof #701 // class com.example.addon.util.macro.NbtBookAction
          0684: ifeq 1802
          0687: aload 8
          0689: checkcast #701 // class com.example.addon.util.macro.NbtBookAction
          068c: astore 10
          068e: iconst_1
          068f: aload 10
          0691: getfield #704 // com.example.addon.util.macro.NbtBookAction.bookCount:I
          0694: invokestatic #710 // java.lang.Math.max(II)I
          0697: istore 15
          0699: iconst_1
          069a: aload 10
          069c: getfield #711 // com.example.addon.util.macro.NbtBookAction.delayTicks:I
          069f: invokestatic #710 // java.lang.Math.max(II)I
          06a2: i2l
          06a3: ldc2_w #712 // 50
          06a6: lmul
          06a7: lstore 16
          06a9: iconst_0
          06aa: istore 18
          06ac: iload 18
          06ae: iload 15
          06b0: if_icmpge 1799
          06b3: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          06b6: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          06b9: ifne 1727
          06bc: goto 1799
          06bf: iload 18
          06c1: istore 19
          06c3: new #364 // class java.util.concurrent.CompletableFuture
          06c6: dup
          06c7: invokespecial #714 // java.util.concurrent.CompletableFuture.<init>()V
          06ca: astore 20
          06cc: aload_1
          06cd: aload 20
          06cf: aload 10
          06d1: aload_1
          06d2: iload 19
          06d4: iload 15
          06d6: invokedynamic #722 // invokedynamic(bsm=21) run(Ljava.util.concurrent.CompletableFuture;Lcom.example.addon.util.macro.NbtBookAction;Lnet.minecraft.class_310;II)Ljava.lang.Runnable;
          06db: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          06de: aload 20
          06e0: invokevirtual #724 // java.util.concurrent.CompletableFuture.get()Ljava.lang.Object;
          06e3: checkcast #726 // class java.lang.Boolean
          06e6: astore 21
          06e8: aload 21
          06ea: invokevirtual #729 // java.lang.Boolean.booleanValue()Z
          06ed: ifne 1779
          06f0: goto 1799
          06f3: iload 18
          06f5: iload 15
          06f7: iconst_1
          06f8: isub
          06f9: if_icmpge 1793
          06fc: lload 16
          06fe: invokestatic #408 // java.lang.Thread.sleep(J)V
          0701: iinc 18 1
          0704: goto 1708
          0707: goto 4529
          070a: aload 8
          070c: instanceof #685 // class com.example.addon.util.macro.GoToAction
          070f: ifeq 1826
          0712: aload 8
          0714: checkcast #685 // class com.example.addon.util.macro.GoToAction
          0717: astore 15
          0719: aload_1
          071a: aload 15
          071c: invokestatic #733 // com.example.addon.util.macro.MacroExecutor.runGoToAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.GoToAction;)V
          071f: goto 4529
          0722: aload 8
          0724: instanceof #735 // class com.example.addon.util.macro.MoveAction
          0727: ifeq 1951
          072a: aload 8
          072c: checkcast #735 // class com.example.addon.util.macro.MoveAction
          072f: astore 15
          0731: aload 15
          0733: getfield #738 // com.example.addon.util.macro.MoveAction.nonBlocking:Z
          0736: ifeq 1886
          0739: aload_1
          073a: aload 15
          073c: aload_1
          073d: invokedynamic #746 // invokedynamic(bsm=22) run(Lcom.example.addon.util.macro.MoveAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0742: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0745: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          0748: aload 15
          074a: iconst_1
          074b: newarray int
          074d: dup
          074e: iconst_0
          074f: aload 15
          0751: getfield #747 // com.example.addon.util.macro.MoveAction.durationTicks:I
          0754: iconst_1
          0755: isub
          0756: iastore
          0757: invokevirtual #751 // java.util.concurrent.ConcurrentHashMap.put(Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;
          075a: pop
          075b: goto 1948
          075e: iconst_0
          075f: istore 16
          0761: iload 16
          0763: aload 15
          0765: getfield #747 // com.example.addon.util.macro.MoveAction.durationTicks:I
          0768: if_icmpge 1936
          076b: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          076e: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0771: ifeq 1936
          0774: aload_1
          0775: aload 15
          0777: aload_1
          0778: invokedynamic #756 // invokedynamic(bsm=23) run(Lcom.example.addon.util.macro.MoveAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          077d: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0780: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          0783: astore 17
          0785: aload 17
          0787: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          078a: iinc 16 1
          078d: goto 1889
          0790: aload_1
          0791: aload 15
          0793: aload_1
          0794: invokedynamic #761 // invokedynamic(bsm=24) run(Lcom.example.addon.util.macro.MoveAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0799: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          079c: goto 4529
          079f: aload 8
          07a1: instanceof #30 // class com.example.addon.util.macro.LookAtBlockAction
          07a4: ifeq 2037
          07a7: aload 8
          07a9: checkcast #30 // class com.example.addon.util.macro.LookAtBlockAction
          07ac: astore 15
          07ae: aload_1
          07af: aload 15
          07b1: invokestatic #765 // com.example.addon.util.macro.MacroExecutor.resolveLookAtTargetOnClient(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.LookAtBlockAction;)Lcom.example.addon.util.macro.LookAtBlockAction$RotationTarget;
          07b4: astore 16
          07b6: aload 16
          07b8: ifnonnull 1982
          07bb: goto 4652
          07be: aload 15
          07c0: getfield #768 // com.example.addon.util.macro.LookAtBlockAction.smooth:Z
          07c3: ifeq 2022
          07c6: aload 16
          07c8: invokevirtual #771 // com.example.addon.util.macro.LookAtBlockAction$RotationTarget.yaw()F
          07cb: aload 16
          07cd: invokevirtual #773 // com.example.addon.util.macro.LookAtBlockAction$RotationTarget.pitch()F
          07d0: aload 15
          07d2: invokevirtual #777 // com.example.addon.util.macro.LookAtBlockAction.getRotationStep()D
          07d5: invokestatic #781 // com.example.addon.util.macro.MacroExecutor.startSmoothRotation(FFD)V
          07d8: aload 15
          07da: getfield #784 // com.example.addon.util.macro.LookAtBlockAction.waitForCompletion:Z
          07dd: ifeq 2034
          07e0: invokestatic #787 // com.example.addon.util.macro.MacroExecutor.waitForSmoothRotationCompletion()V
          07e3: goto 2034
          07e6: aload_1
          07e7: aload_1
          07e8: aload 16
          07ea: invokedynamic #795 // invokedynamic(bsm=25) run(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.LookAtBlockAction$RotationTarget;)Ljava.lang.Runnable;
          07ef: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          07f2: goto 4529
          07f5: aload 8
          07f7: instanceof #797 // class com.example.addon.util.macro.RepeatAction
          07fa: ifeq 2197
          07fd: aload 8
          07ff: checkcast #797 // class com.example.addon.util.macro.RepeatAction
          0802: astore 15
          0804: iload 7
          0806: iconst_1
          0807: iadd
          0808: istore 16
          080a: iload 16
          080c: aload 15
          080e: getfield #800 // com.example.addon.util.macro.RepeatAction.stepCount:I
          0811: iadd
          0812: aload_0
          0813: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          0816: invokeinterface #229 count=1 // java.util.List.size()I
          081b: invokestatic #803 // java.lang.Math.min(II)I
          081e: istore 17
          0820: iconst_0
          0821: istore 18
          0823: iload 18
          0825: aload 15
          0827: getfield #806 // com.example.addon.util.macro.RepeatAction.repeatCount:I
          082a: if_icmpge 2188
          082d: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0830: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0833: ifeq 2188
          0836: iload 18
          0838: iconst_1
          0839: iadd
          083a: aload 15
          083c: getfield #806 // com.example.addon.util.macro.RepeatAction.repeatCount:I
          083f: invokedynamic #811 // invokedynamic(bsm=26) makeConcatWithConstants(II)Ljava.lang.String;
          0844: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0847: iload 16
          0849: istore 19
          084b: iload 19
          084d: iload 17
          084f: if_icmpge 2182
          0852: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0855: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0858: ifeq 2182
          085b: aload_0
          085c: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          085f: iload 19
          0861: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          0866: checkcast #341 // class com.example.addon.util.macro.MacroAction
          0869: astore 20
          086b: aload 20
          086d: invokeinterface #344 count=1 // com.example.addon.util.macro.MacroAction.isEnabled()Z
          0872: ifne 2168
          0875: goto 2176
          0878: aload_1
          0879: aload 20
          087b: aload 5
          087d: invokestatic #815 // com.example.addon.util.macro.MacroExecutor.executeSingleActionWithWaits(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.MacroAction;Lcom.example.addon.modules.PackUtilModule;)V
          0880: iinc 19 1
          0883: goto 2123
          0886: iinc 18 1
          0889: goto 2083
          088c: iload 17
          088e: iconst_1
          088f: isub
          0890: istore 7
          0892: goto 4529
          0895: aload 8
          0897: instanceof #683 // class com.example.addon.util.macro.WaitForChatAction
          089a: ifeq 2233
          089d: aload 8
          089f: checkcast #683 // class com.example.addon.util.macro.WaitForChatAction
          08a2: astore 15
          08a4: aload 15
          08a6: getfield #818 // com.example.addon.util.macro.WaitForChatAction.pattern:Ljava.lang.String;
          08a9: invokedynamic #821 // invokedynamic(bsm=27) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          08ae: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          08b1: aload 15
          08b3: invokestatic #825 // com.example.addon.util.macro.MacroExecutor.awaitChat(Lcom.example.addon.util.macro.WaitForChatAction;)V
          08b6: goto 4529
          08b9: aload 8
          08bb: instanceof #677 // class com.example.addon.util.macro.WaitForEntityAction
          08be: ifeq 2276
          08c1: aload 8
          08c3: checkcast #677 // class com.example.addon.util.macro.WaitForEntityAction
          08c6: astore 15
          08c8: aload 15
          08ca: invokevirtual #826 // com.example.addon.util.macro.WaitForEntityAction.getDisplayName()Ljava.lang.String;
          08cd: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          08d0: aload 15
          08d2: invokestatic #830 // com.example.addon.util.macro.MacroConditionRegistry.waitForEntity(Lcom.example.addon.util.macro.WaitForEntityAction;)Ljava.util.concurrent.CompletableFuture;
          08d5: astore 16
          08d7: aload 16
          08d9: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          08dc: goto 2273
          08df: astore 16
          08e1: goto 4529
          08e4: aload 8
          08e6: instanceof #679 // class com.example.addon.util.macro.WaitForSoundAction
          08e9: ifeq 2356
          08ec: aload 8
          08ee: checkcast #679 // class com.example.addon.util.macro.WaitForSoundAction
          08f1: astore 15
          08f3: aload 15
          08f5: getfield #833 // com.example.addon.util.macro.WaitForSoundAction.soundIds:Ljava.util.List;
          08f8: invokeinterface #193 count=1 // java.util.List.isEmpty()Z
          08fd: ifeq 2310
          0900: ldc_w #835 // "any"
          0903: goto 2324
          0906: aload 15
          0908: getfield #833 // com.example.addon.util.macro.WaitForSoundAction.soundIds:Ljava.util.List;
          090b: iconst_0
          090c: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          0911: checkcast #317 // class java.lang.String
          0914: astore 16
          0916: aload 16
          0918: invokedynamic #838 // invokedynamic(bsm=28) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          091d: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0920: aload 15
          0922: invokestatic #842 // com.example.addon.util.macro.MacroConditionRegistry.waitForSound(Lcom.example.addon.util.macro.WaitForSoundAction;)Ljava.util.concurrent.CompletableFuture;
          0925: astore 17
          0927: aload 17
          0929: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          092c: goto 2353
          092f: astore 17
          0931: goto 4529
          0934: aload 8
          0936: instanceof #844 // class com.example.addon.util.macro.MineAction
          0939: ifeq 2380
          093c: aload 8
          093e: checkcast #844 // class com.example.addon.util.macro.MineAction
          0941: astore 15
          0943: aload_1
          0944: aload 15
          0946: invokestatic #848 // com.example.addon.util.macro.MacroExecutor.runMineAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.MineAction;)V
          0949: goto 4529
          094c: aload 8
          094e: instanceof #681 // class com.example.addon.util.macro.WaitForSlotChangeAction
          0951: ifeq 2423
          0954: aload 8
          0956: checkcast #681 // class com.example.addon.util.macro.WaitForSlotChangeAction
          0959: astore 15
          095b: aload 15
          095d: invokevirtual #849 // com.example.addon.util.macro.WaitForSlotChangeAction.getDisplayName()Ljava.lang.String;
          0960: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0963: aload 15
          0965: invokestatic #853 // com.example.addon.util.macro.MacroConditionRegistry.waitForSlotChange(Lcom.example.addon.util.macro.WaitForSlotChangeAction;)Ljava.util.concurrent.CompletableFuture;
          0968: astore 16
          096a: aload 16
          096c: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          096f: goto 2420
          0972: astore 16
          0974: goto 4529
          0977: aload 8
          0979: instanceof #855 // class com.example.addon.util.macro.WaitForLanStepAction
          097c: ifeq 2466
          097f: aload 8
          0981: checkcast #855 // class com.example.addon.util.macro.WaitForLanStepAction
          0984: astore 15
          0986: aload 15
          0988: invokevirtual #856 // com.example.addon.util.macro.WaitForLanStepAction.getDisplayName()Ljava.lang.String;
          098b: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          098e: aload 15
          0990: invokestatic #860 // com.example.addon.util.macro.MacroConditionRegistry.waitForLanStep(Lcom.example.addon.util.macro.WaitForLanStepAction;)Ljava.util.concurrent.CompletableFuture;
          0993: astore 16
          0995: aload 16
          0997: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          099a: goto 2463
          099d: astore 16
          099f: goto 4529
          09a2: aload 8
          09a4: instanceof #862 // class com.example.addon.util.macro.StopMacroAction
          09a7: ifeq 2530
          09aa: ldc_w #864 // "Stopping Macro"
          09ad: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          09b0: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          09b3: astore 15
          09b5: aload 15
          09b7: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          09ba: ifeq 2515
          09bd: aload 15
          09bf: iload 7
          09c1: iconst_1
          09c2: iadd
          09c3: aload_0
          09c4: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          09c7: invokeinterface #229 count=1 // java.util.List.size()I
          09cc: aload_0
          09cd: getfield #204 // com.example.addon.util.PackUtilMacro.name:Ljava.lang.String;
          09d0: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          09d3: goto 2520
          09d6: astore 15
          09d8: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          09db: iconst_0
          09dc: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          09df: goto 4658
          09e2: aload 8
          09e4: instanceof #866 // class com.example.addon.util.macro.TickSyncAction
          09e7: ifeq 2687
          09ea: aload 8
          09ec: checkcast #866 // class com.example.addon.util.macro.TickSyncAction
          09ef: astore 15
          09f1: aload_1
          09f2: getfield #870 // net.minecraft.class_310.field_1687:Lnet.minecraft.class_638;
          09f5: ifnonnull 2555
          09f8: goto 4652
          09fb: aload_0
          09fc: iload 7
          09fe: iconst_1
          09ff: iadd
          0a00: aload 15
          0a02: getfield #873 // com.example.addon.util.macro.TickSyncAction.preGenCount:I
          0a05: invokestatic #877 // com.example.addon.util.macro.MacroExecutor.preGeneratePackets(Lcom.example.addon.util.PackUtilMacro;II)Ljava.util.List;
          0a08: astore 16
          0a0a: aload_1
          0a0b: getfield #870 // net.minecraft.class_310.field_1687:Lnet.minecraft.class_638;
          0a0e: invokevirtual #883 // net.minecraft.class_638.method_75260()J
          0a11: aload 15
          0a13: getfield #886 // com.example.addon.util.macro.TickSyncAction.tickOffset:I
          0a16: i2l
          0a17: ladd
          0a18: lstore 17
          0a1a: lload 17
          0a1c: aload 16
          0a1e: invokeinterface #229 count=1 // java.util.List.size()I
          0a23: invokedynamic #891 // invokedynamic(bsm=29) makeConcatWithConstants(JI)Ljava.lang.String;
          0a28: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0a2b: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0a2e: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0a31: ifeq 2634
          0a34: aload_1
          0a35: getfield #870 // net.minecraft.class_310.field_1687:Lnet.minecraft.class_638;
          0a38: invokevirtual #883 // net.minecraft.class_638.method_75260()J
          0a3b: lload 17
          0a3d: lcmp
          0a3e: ifge 2634
          0a41: ldc2_w #892 // 1000000
          0a44: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0a47: goto 2603
          0a4a: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0a4d: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0a50: ifeq 2684
          0a53: aload_1
          0a54: aload 16
          0a56: invokestatic #901 // com.example.addon.util.macro.MacroExecutor.executePreGeneratedBurst(Lnet.minecraft.class_310;Ljava.util.List;)V
          0a59: iload 7
          0a5b: aload_0
          0a5c: iload 7
          0a5e: iconst_1
          0a5f: iadd
          0a60: aload 16
          0a62: invokeinterface #229 count=1 // java.util.List.size()I
          0a67: invokestatic #905 // com.example.addon.util.macro.MacroExecutor.countPreGeneratedActions(Lcom.example.addon.util.PackUtilMacro;II)I
          0a6a: iadd
          0a6b: istore 7
          0a6d: aload 16
          0a6f: invokeinterface #229 count=1 // java.util.List.size()I
          0a74: invokedynamic #908 // invokedynamic(bsm=30) makeConcatWithConstants(I)Ljava.lang.String;
          0a79: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0a7c: goto 4529
          0a7f: aload 8
          0a81: instanceof #910 // class com.example.addon.util.macro.RevisionSyncAction
          0a84: ifeq 2902
          0a87: aload 8
          0a89: checkcast #910 // class com.example.addon.util.macro.RevisionSyncAction
          0a8c: astore 15
          0a8e: aload_1
          0a8f: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0a92: ifnull 4652
          0a95: aload_1
          0a96: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0a99: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0a9c: ifnonnull 2722
          0a9f: goto 4652
          0aa2: aload_0
          0aa3: iload 7
          0aa5: iconst_1
          0aa6: iadd
          0aa7: aload 15
          0aa9: getfield #921 // com.example.addon.util.macro.RevisionSyncAction.preGenCount:I
          0aac: invokestatic #877 // com.example.addon.util.macro.MacroExecutor.preGeneratePackets(Lcom.example.addon.util.PackUtilMacro;II)Ljava.util.List;
          0aaf: astore 16
          0ab1: aload_1
          0ab2: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0ab5: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0ab8: invokevirtual #926 // net.minecraft.class_1703.method_37421()I
          0abb: istore 17
          0abd: iload 17
          0abf: aload 15
          0ac1: getfield #929 // com.example.addon.util.macro.RevisionSyncAction.revisionOffset:I
          0ac4: iadd
          0ac5: istore 18
          0ac7: iload 18
          0ac9: aload 16
          0acb: invokeinterface #229 count=1 // java.util.List.size()I
          0ad0: invokedynamic #932 // invokedynamic(bsm=31) makeConcatWithConstants(II)Ljava.lang.String;
          0ad5: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0ad8: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0adb: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0ade: ifeq 2832
          0ae1: aload_1
          0ae2: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0ae5: ifnull 2832
          0ae8: aload_1
          0ae9: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0aec: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0aef: ifnonnull 2805
          0af2: goto 2832
          0af5: aload_1
          0af6: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0af9: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0afc: invokevirtual #926 // net.minecraft.class_1703.method_37421()I
          0aff: iload 18
          0b01: if_icmplt 2823
          0b04: goto 2832
          0b07: ldc2_w #933 // 500000
          0b0a: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0b0d: goto 2776
          0b10: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0b13: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0b16: ifeq 2899
          0b19: aload_1
          0b1a: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b1d: ifnull 2899
          0b20: aload_1
          0b21: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b24: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0b27: ifnull 2899
          0b2a: aload_1
          0b2b: aload 16
          0b2d: invokestatic #901 // com.example.addon.util.macro.MacroExecutor.executePreGeneratedBurst(Lnet.minecraft.class_310;Ljava.util.List;)V
          0b30: iload 7
          0b32: aload_0
          0b33: iload 7
          0b35: iconst_1
          0b36: iadd
          0b37: aload 16
          0b39: invokeinterface #229 count=1 // java.util.List.size()I
          0b3e: invokestatic #905 // com.example.addon.util.macro.MacroExecutor.countPreGeneratedActions(Lcom.example.addon.util.PackUtilMacro;II)I
          0b41: iadd
          0b42: istore 7
          0b44: aload 16
          0b46: invokeinterface #229 count=1 // java.util.List.size()I
          0b4b: invokedynamic #937 // invokedynamic(bsm=32) makeConcatWithConstants(I)Ljava.lang.String;
          0b50: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0b53: goto 4529
          0b56: aload 8
          0b58: instanceof #939 // class com.example.addon.util.macro.ServerTickSyncAction
          0b5b: ifeq 3277
          0b5e: aload 8
          0b60: checkcast #939 // class com.example.addon.util.macro.ServerTickSyncAction
          0b63: astore 15
          0b65: aload_1
          0b66: invokevirtual #943 // net.minecraft.class_310.method_1562()Lnet.minecraft.class_634;
          0b69: ifnonnull 2927
          0b6c: goto 4652
          0b6f: aload_0
          0b70: iload 7
          0b72: iconst_1
          0b73: iadd
          0b74: aload 15
          0b76: getfield #944 // com.example.addon.util.macro.ServerTickSyncAction.preGenCount:I
          0b79: invokestatic #877 // com.example.addon.util.macro.MacroExecutor.preGeneratePackets(Lcom.example.addon.util.PackUtilMacro;II)Ljava.util.List;
          0b7c: astore 16
          0b7e: iconst_0
          0b7f: istore 17
          0b81: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0b84: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0b87: ifeq 3030
          0b8a: invokestatic #949 // com.example.addon.util.macro.ServerTickTracker.isReady()Z
          0b8d: ifne 3030
          0b90: iload 17
          0b92: aload 15
          0b94: getfield #952 // com.example.addon.util.macro.ServerTickSyncAction.maxWaitMs:I
          0b97: if_icmpge 3030
          0b9a: invokestatic #955 // com.example.addon.util.macro.ServerTickTracker.getWarmupProgress()F
          0b9d: fstore 18
          0b9f: ldc_w #957 // "ServerSync warmup %.0f%% (%d samples, %dms)"
          0ba2: iconst_3
          0ba3: anewarray #4 // class java.lang.Object
          0ba6: dup
          0ba7: iconst_0
          0ba8: fload 18
          0baa: ldc_w #958 // 100
          0bad: fmul
          0bae: invokestatic #963 // java.lang.Float.valueOf(F)Ljava.lang.Float;
          0bb1: aastore
          0bb2: dup
          0bb3: iconst_1
          0bb4: invokestatic #966 // com.example.addon.util.macro.ServerTickTracker.getSampleCount()I
          0bb7: invokestatic #971 // java.lang.Integer.valueOf(I)Ljava.lang.Integer;
          0bba: aastore
          0bbb: dup
          0bbc: iconst_2
          0bbd: invokestatic #974 // com.example.addon.util.macro.ServerTickTracker.getTrackingTimeMs()J
          0bc0: invokestatic #979 // java.lang.Long.valueOf(J)Ljava.lang.Long;
          0bc3: aastore
          0bc4: invokestatic #530 // java.lang.String.format(Ljava.lang.String;[Ljava.lang.Object;)Ljava.lang.String;
          0bc7: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0bca: ldc2_w #712 // 50
          0bcd: invokestatic #408 // java.lang.Thread.sleep(J)V
          0bd0: iinc 17 50
          0bd3: goto 2945
          0bd6: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0bd9: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0bdc: ifne 3042
          0bdf: goto 4652
          0be2: aload 15
          0be4: getfield #982 // com.example.addon.util.macro.ServerTickSyncAction.bufferMs:I
          0be7: aload 15
          0be9: getfield #985 // com.example.addon.util.macro.ServerTickSyncAction.ignorePing:Z
          0bec: invokestatic #989 // com.example.addon.util.macro.ServerTickTracker.getOptimalSendTime(IZ)J
          0bef: lstore 18
          0bf1: lload 18
          0bf3: invokestatic #994 // java.lang.System.nanoTime()J
          0bf6: lsub
          0bf7: ldc2_w #892 // 1000000
          0bfa: ldiv
          0bfb: lstore 20
          0bfd: invokestatic #997 // com.example.addon.util.macro.ServerTickTracker.getPingMs()I
          0c00: istore 22
          0c02: aload 15
          0c04: getfield #985 // com.example.addon.util.macro.ServerTickSyncAction.ignorePing:Z
          0c07: ifeq 3088
          0c0a: ldc_w #999 // " (no ping)"
          0c0d: goto 3095
          0c10: iload 22
          0c12: invokedynamic #1002 // invokedynamic(bsm=33) makeConcatWithConstants(I)Ljava.lang.String;
          0c17: astore 23
          0c19: lconst_0
          0c1a: lload 20
          0c1c: invokestatic #1005 // java.lang.Math.max(JJ)J
          0c1f: aload 23
          0c21: aload 16
          0c23: invokeinterface #229 count=1 // java.util.List.size()I
          0c28: invokedynamic #1010 // invokedynamic(bsm=34) makeConcatWithConstants(JLjava.lang.String;I)Ljava.lang.String;
          0c2d: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0c30: invokestatic #994 // java.lang.System.nanoTime()J
          0c33: lstore 24
          0c35: aload 15
          0c37: getfield #952 // com.example.addon.util.macro.ServerTickSyncAction.maxWaitMs:I
          0c3a: i2l
          0c3b: ldc2_w #892 // 1000000
          0c3e: lmul
          0c3f: lstore 26
          0c41: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0c44: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0c47: ifeq 3210
          0c4a: invokestatic #994 // java.lang.System.nanoTime()J
          0c4d: lstore 28
          0c4f: lload 28
          0c51: lload 24
          0c53: lsub
          0c54: lload 26
          0c56: lcmp
          0c57: iflt 3165
          0c5a: goto 3210
          0c5d: lload 28
          0c5f: lload 18
          0c61: lcmp
          0c62: iflt 3176
          0c65: goto 3210
          0c68: lload 18
          0c6a: lload 28
          0c6c: lsub
          0c6d: lstore 30
          0c6f: lload 30
          0c71: ldc2_w #1011 // 2000000
          0c74: lcmp
          0c75: ifle 3204
          0c78: lload 30
          0c7a: ldc2_w #1011 // 2000000
          0c7d: lsub
          0c7e: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0c81: goto 3207
          0c84: invokestatic #1015 // java.lang.Thread.onSpinWait()V
          0c87: goto 3137
          0c8a: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0c8d: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0c90: ifeq 3274
          0c93: aload_1
          0c94: aload 16
          0c96: invokestatic #901 // com.example.addon.util.macro.MacroExecutor.executePreGeneratedBurst(Lnet.minecraft.class_310;Ljava.util.List;)V
          0c99: iload 7
          0c9b: aload_0
          0c9c: iload 7
          0c9e: iconst_1
          0c9f: iadd
          0ca0: aload 16
          0ca2: invokeinterface #229 count=1 // java.util.List.size()I
          0ca7: invokestatic #905 // com.example.addon.util.macro.MacroExecutor.countPreGeneratedActions(Lcom.example.addon.util.PackUtilMacro;II)I
          0caa: iadd
          0cab: istore 7
          0cad: invokestatic #994 // java.lang.System.nanoTime()J
          0cb0: lload 18
          0cb2: lsub
          0cb3: ldc2_w #892 // 1000000
          0cb6: ldiv
          0cb7: lstore 28
          0cb9: aload 16
          0cbb: invokeinterface #229 count=1 // java.util.List.size()I
          0cc0: lload 28
          0cc2: invokedynamic #1020 // invokedynamic(bsm=35) makeConcatWithConstants(IJ)Ljava.lang.String;
          0cc7: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0cca: goto 4529
          0ccd: aload 8
          0ccf: instanceof #1022 // class com.example.addon.util.macro.RotateAction
          0cd2: ifeq 3347
          0cd5: aload 8
          0cd7: checkcast #1022 // class com.example.addon.util.macro.RotateAction
          0cda: astore 15
          0cdc: aload 15
          0cde: getfield #1023 // com.example.addon.util.macro.RotateAction.smooth:Z
          0ce1: ifeq 3332
          0ce4: aload 15
          0ce6: getfield #1024 // com.example.addon.util.macro.RotateAction.yaw:F
          0ce9: aload 15
          0ceb: getfield #1025 // com.example.addon.util.macro.RotateAction.pitch:F
          0cee: aload 15
          0cf0: invokevirtual #1026 // com.example.addon.util.macro.RotateAction.getRotationStep()D
          0cf3: invokestatic #781 // com.example.addon.util.macro.MacroExecutor.startSmoothRotation(FFD)V
          0cf6: aload 15
          0cf8: getfield #1027 // com.example.addon.util.macro.RotateAction.waitForCompletion:Z
          0cfb: ifeq 3344
          0cfe: invokestatic #787 // com.example.addon.util.macro.MacroExecutor.waitForSmoothRotationCompletion()V
          0d01: goto 3344
          0d04: aload_1
          0d05: aload 8
          0d07: aload_1
          0d08: invokedynamic #1035 // invokedynamic(bsm=36) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0d0d: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0d10: goto 4529
          0d13: aload 8
          0d15: instanceof #30 // class com.example.addon.util.macro.LookAtBlockAction
          0d18: ifeq 3433
          0d1b: aload 8
          0d1d: checkcast #30 // class com.example.addon.util.macro.LookAtBlockAction
          0d20: astore 11
          0d22: aload_1
          0d23: aload 11
          0d25: invokestatic #765 // com.example.addon.util.macro.MacroExecutor.resolveLookAtTargetOnClient(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.LookAtBlockAction;)Lcom.example.addon.util.macro.LookAtBlockAction$RotationTarget;
          0d28: astore 15
          0d2a: aload 15
          0d2c: ifnonnull 3378
          0d2f: goto 4652
          0d32: aload 11
          0d34: getfield #768 // com.example.addon.util.macro.LookAtBlockAction.smooth:Z
          0d37: ifeq 3418
          0d3a: aload 15
          0d3c: invokevirtual #771 // com.example.addon.util.macro.LookAtBlockAction$RotationTarget.yaw()F
          0d3f: aload 15
          0d41: invokevirtual #773 // com.example.addon.util.macro.LookAtBlockAction$RotationTarget.pitch()F
          0d44: aload 11
          0d46: invokevirtual #777 // com.example.addon.util.macro.LookAtBlockAction.getRotationStep()D
          0d49: invokestatic #781 // com.example.addon.util.macro.MacroExecutor.startSmoothRotation(FFD)V
          0d4c: aload 11
          0d4e: getfield #784 // com.example.addon.util.macro.LookAtBlockAction.waitForCompletion:Z
          0d51: ifeq 3430
          0d54: invokestatic #787 // com.example.addon.util.macro.MacroExecutor.waitForSmoothRotationCompletion()V
          0d57: goto 3430
          0d5a: aload_1
          0d5b: aload_1
          0d5c: aload 15
          0d5e: invokedynamic #1040 // invokedynamic(bsm=37) run(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.LookAtBlockAction$RotationTarget;)Ljava.lang.Runnable;
          0d63: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0d66: goto 4529
          0d69: aload 8
          0d6b: instanceof #35 // class com.example.addon.util.macro.UseItemAction
          0d6e: ifeq 3683
          0d71: aload 8
          0d73: checkcast #35 // class com.example.addon.util.macro.UseItemAction
          0d76: astore 15
          0d78: aload 15
          0d7a: getfield #1044 // com.example.addon.util.macro.UseItemAction.useMode:Lcom.example.addon.util.macro.UseItemAction$UseMode;
          0d7d: getstatic #1047 // com.example.addon.util.macro.UseItemAction$UseMode.CUSTOM_HOLD:Lcom.example.addon.util.macro.UseItemAction$UseMode;
          0d80: if_acmpne 3580
          0d83: new #1049 // class java.util.concurrent.CountDownLatch
          0d86: dup
          0d87: iconst_1
          0d88: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0d8b: astore 16
          0d8d: aload_1
          0d8e: aload 15
          0d90: aload_1
          0d91: aload 16
          0d93: invokedynamic #1060 // invokedynamic(bsm=38) run(Lcom.example.addon.util.macro.UseItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0d98: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0d9b: aload 16
          0d9d: ldc2_w #1061 // 200
          0da0: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0da3: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0da6: pop
          0da7: aload 15
          0da9: getfield #1075 // com.example.addon.util.macro.UseItemAction.holdTicks:I
          0dac: ifle 3577
          0daf: iconst_0
          0db0: istore 17
          0db2: iload 17
          0db4: aload 15
          0db6: getfield #1075 // com.example.addon.util.macro.UseItemAction.holdTicks:I
          0db9: if_icmpge 3541
          0dbc: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0dbf: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0dc2: ifeq 3541
          0dc5: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          0dc8: astore 18
          0dca: aload 18
          0dcc: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0dcf: iinc 17 1
          0dd2: goto 3506
          0dd5: new #1049 // class java.util.concurrent.CountDownLatch
          0dd8: dup
          0dd9: iconst_1
          0dda: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0ddd: astore 17
          0ddf: aload_1
          0de0: aload 15
          0de2: aload_1
          0de3: aload 17
          0de5: invokedynamic #1080 // invokedynamic(bsm=39) run(Lcom.example.addon.util.macro.UseItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0dea: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0ded: aload 17
          0def: ldc2_w #1061 // 200
          0df2: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0df5: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0df8: pop
          0df9: goto 3680
          0dfc: iconst_1
          0dfd: aload 15
          0dff: getfield #1083 // com.example.addon.util.macro.UseItemAction.useCount:I
          0e02: invokestatic #710 // java.lang.Math.max(II)I
          0e05: istore 16
          0e07: iconst_0
          0e08: istore 17
          0e0a: iload 17
          0e0c: iload 16
          0e0e: if_icmpge 3680
          0e11: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0e14: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0e17: ifeq 3680
          0e1a: new #1049 // class java.util.concurrent.CountDownLatch
          0e1d: dup
          0e1e: iconst_1
          0e1f: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0e22: astore 18
          0e24: aload_1
          0e25: aload 15
          0e27: aload_1
          0e28: aload 18
          0e2a: invokedynamic #1088 // invokedynamic(bsm=40) run(Lcom.example.addon.util.macro.UseItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0e2f: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0e32: aload 18
          0e34: ldc2_w #1061 // 200
          0e37: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0e3a: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0e3d: pop
          0e3e: iload 17
          0e40: iload 16
          0e42: iconst_1
          0e43: isub
          0e44: if_icmpge 3674
          0e47: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0e4a: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0e4d: ifeq 3674
          0e50: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          0e53: astore 19
          0e55: aload 19
          0e57: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0e5a: iinc 17 1
          0e5d: goto 3594
          0e60: goto 4529
          0e63: aload 8
          0e65: instanceof #1090 // class com.example.addon.util.macro.ItemAction
          0e68: ifeq 3795
          0e6b: aload 8
          0e6d: checkcast #1090 // class com.example.addon.util.macro.ItemAction
          0e70: astore 15
          0e72: aload 15
          0e74: getfield #1093 // com.example.addon.util.macro.ItemAction.waitForItem:Z
          0e77: ifeq 3717
          0e7a: aload_1
          0e7b: aload 15
          0e7d: invokestatic #1097 // com.example.addon.util.macro.MacroExecutor.waitForItemActionTargets(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.ItemAction;)V
          0e80: goto 3717
          0e83: astore 16
          0e85: aload 5
          0e87: ifnull 3780
          0e8a: aload 5
          0e8c: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          0e8f: ifeq 3780
          0e92: new #1049 // class java.util.concurrent.CountDownLatch
          0e95: dup
          0e96: iconst_1
          0e97: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0e9a: astore 16
          0e9c: aload_1
          0e9d: aload 8
          0e9f: aload_1
          0ea0: aload 16
          0ea2: invokedynamic #1108 // invokedynamic(bsm=41) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0ea7: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0eaa: aload 16
          0eac: ldc2_w #1109 // 100
          0eaf: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0eb2: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0eb5: pop
          0eb6: goto 3777
          0eb9: astore 17
          0ebb: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0ebe: invokevirtual #1117 // java.lang.Thread.interrupt()V
          0ec1: goto 3792
          0ec4: aload_1
          0ec5: aload 8
          0ec7: aload_1
          0ec8: invokedynamic #1122 // invokedynamic(bsm=42) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0ecd: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0ed0: goto 4529
          0ed3: aload 8
          0ed5: instanceof #65 // class com.example.addon.util.macro.CraftAction
          0ed8: ifeq 3819
          0edb: aload 8
          0edd: checkcast #65 // class com.example.addon.util.macro.CraftAction
          0ee0: astore 12
          0ee2: aload_1
          0ee3: aload 12
          0ee5: invokestatic #1126 // com.example.addon.util.macro.MacroExecutor.runCraftAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.CraftAction;)V
          0ee8: goto 4529
          0eeb: aload 8
          0eed: instanceof #374 // class com.example.addon.util.macro.SendPacketAction
          0ef0: ifeq 3884
          0ef3: aload 5
          0ef5: ifnull 3869
          0ef8: aload 5
          0efa: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          0efd: ifeq 3869
          0f00: aload 8
          0f02: aload_1
          0f03: invokeinterface #1127 count=2 // com.example.addon.util.macro.MacroAction.execute(Lnet.minecraft.class_310;)V
          0f08: goto 4529
          0f0b: astore 15
          0f0d: aload 15
          0f0f: invokevirtual #1130 // java.lang.Exception.getMessage()Ljava.lang.String;
          0f12: invokedynamic #1133 // invokedynamic(bsm=43) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0f17: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0f1a: goto 4529
          0f1d: aload_1
          0f1e: aload 8
          0f20: aload_1
          0f21: invokedynamic #1138 // invokedynamic(bsm=44) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0f26: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0f29: goto 4529
          0f2c: aload 8
          0f2e: instanceof #40 // class com.example.addon.util.macro.StoreItemAction
          0f31: ifeq 4074
          0f34: aload 8
          0f36: checkcast #40 // class com.example.addon.util.macro.StoreItemAction
          0f39: astore 15
          0f3b: aload 15
          0f3d: getfield #1141 // com.example.addon.util.macro.StoreItemAction.mode:Lcom.example.addon.util.macro.StoreItemAction$Mode;
          0f40: getstatic #1144 // com.example.addon.util.macro.StoreItemAction$Mode.LOOT:Lcom.example.addon.util.macro.StoreItemAction$Mode;
          0f43: if_acmpne 3916
          0f46: ldc_w #1146 // "Looting"
          0f49: goto 3919
          0f4c: ldc_w #1148 // "Storing"
          0f4f: aload 15
          0f51: getfield #1149 // com.example.addon.util.macro.StoreItemAction.persistent:Z
          0f54: ifeq 3933
          0f57: ldc_w #1151 // " ∞"
          0f5a: goto 3936
          0f5d: ldc_w #310 // ""
          0f60: invokedynamic #1156 // invokedynamic(bsm=45) makeConcatWithConstants(Ljava.lang.String;Ljava.lang.String;)Ljava.lang.String;
          0f65: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0f68: aload 15
          0f6a: getfield #1149 // com.example.addon.util.macro.StoreItemAction.persistent:Z
          0f6d: ifeq 4024
          0f70: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0f73: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0f76: ifeq 4071
          0f79: new #1049 // class java.util.concurrent.CountDownLatch
          0f7c: dup
          0f7d: iconst_1
          0f7e: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0f81: astore 16
          0f83: aload_1
          0f84: aload 15
          0f86: aload_1
          0f87: aload 16
          0f89: invokedynamic #1164 // invokedynamic(bsm=46) run(Lcom.example.addon.util.macro.StoreItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0f8e: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0f91: aload 16
          0f93: ldc2_w #1165 // 2000
          0f96: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0f99: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0f9c: pop
          0f9d: goto 4011
          0fa0: astore 17
          0fa2: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0fa5: invokevirtual #1117 // java.lang.Thread.interrupt()V
          0fa8: goto 4071
          0fab: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          0fae: astore 17
          0fb0: aload 17
          0fb2: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0fb5: goto 3952
          0fb8: new #1049 // class java.util.concurrent.CountDownLatch
          0fbb: dup
          0fbc: iconst_1
          0fbd: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0fc0: astore 16
          0fc2: aload_1
          0fc3: aload 15
          0fc5: aload_1
          0fc6: aload 16
          0fc8: invokedynamic #1171 // invokedynamic(bsm=47) run(Lcom.example.addon.util.macro.StoreItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0fcd: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0fd0: aload 16
          0fd2: ldc2_w #1165 // 2000
          0fd5: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0fd8: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0fdb: pop
          0fdc: goto 4071
          0fdf: astore 17
          0fe1: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0fe4: invokevirtual #1117 // java.lang.Thread.interrupt()V
          0fe7: goto 4529
          0fea: aload 8
          0fec: instanceof #1173 // class com.example.addon.util.macro.ClickAction
          0fef: ifeq 4203
          0ff2: aload 8
          0ff4: checkcast #1173 // class com.example.addon.util.macro.ClickAction
          0ff7: astore 15
          0ff9: iconst_1
          0ffa: aload 15
          0ffc: getfield #1176 // com.example.addon.util.macro.ClickAction.clickCount:I
          0fff: invokestatic #710 // java.lang.Math.max(II)I
          1002: istore 16
          1004: iconst_0
          1005: istore 17
          1007: iload 17
          1009: iload 16
          100b: if_icmpge 4200
          100e: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          1011: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          1014: ifeq 4200
          1017: new #1049 // class java.util.concurrent.CountDownLatch
          101a: dup
          101b: iconst_1
          101c: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          101f: astore 18
          1021: aload_1
          1022: aload 15
          1024: aload_1
          1025: aload 18
          1027: invokedynamic #1184 // invokedynamic(bsm=48) run(Lcom.example.addon.util.macro.ClickAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          102c: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          102f: aload 18
          1031: ldc2_w #1061 // 200
          1034: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          1037: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          103a: pop
          103b: goto 4166
          103e: astore 19
          1040: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          1043: invokevirtual #1117 // java.lang.Thread.interrupt()V
          1046: iload 17
          1048: iload 16
          104a: iconst_1
          104b: isub
          104c: if_icmpge 4194
          104f: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          1052: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          1055: ifeq 4194
          1058: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          105b: astore 19
          105d: aload 19
          105f: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          1062: iinc 17 1
          1065: goto 4103
          1068: goto 4529
          106b: aload 8
          106d: instanceof #1186 // class com.example.addon.util.macro.PayAction
          1070: ifeq 4223
          1073: aload_1
          1074: aload 8
          1076: checkcast #1186 // class com.example.addon.util.macro.PayAction
          1079: invokestatic #1190 // com.example.addon.util.macro.MacroExecutor.runPayAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.PayAction;)V
          107c: goto 4529
          107f: aload 8
          1081: instanceof #45 // class com.example.addon.util.macro.XCarryAction
          1084: ifeq 4355
          1087: aload 8
          1089: checkcast #45 // class com.example.addon.util.macro.XCarryAction
          108c: astore 13
          108e: aload 13
          1090: getfield #1193 // com.example.addon.util.macro.XCarryAction.mode:Lcom.example.addon.util.macro.XCarryAction$Mode;
          1093: getstatic #1196 // com.example.addon.util.macro.XCarryAction$Mode.PUT_IN:Lcom.example.addon.util.macro.XCarryAction$Mode;
          1096: if_acmpne 4275
          1099: aload 13
          109b: getfield #1200 // com.example.addon.util.macro.XCarryAction.transferMode:Lcom.example.addon.util.macro.XCarryAction$TransferMode;
          109e: getstatic #1203 // com.example.addon.util.macro.XCarryAction$TransferMode.CLICK:Lcom.example.addon.util.macro.XCarryAction$TransferMode;
          10a1: if_acmpne 4275
          10a4: ldc_w #1205 // "XCarry Click"
          10a7: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          10aa: aload_1
          10ab: aload 13
          10ad: invokestatic #1209 // com.example.addon.util.macro.MacroExecutor.runXCarryClickPutIn(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.XCarryAction;)V
          10b0: goto 4529
          10b3: getstatic #1213 // com.example.addon.util.macro.MacroExecutor$1.$SwitchMap$com$example$addon$util$macro$XCarryAction$Mode:[I
          10b6: aload 13
          10b8: getfield #1193 // com.example.addon.util.macro.XCarryAction.mode:Lcom.example.addon.util.macro.XCarryAction$Mode;
          10bb: invokevirtual #1216 // com.example.addon.util.macro.XCarryAction$Mode.ordinal()I
          10be: iaload
          10bf: tableswitch low=1 high=3 default=4312 1:4322 2:4328 3:4334
          10d8: new #1218 // class java.lang.MatchException
          10db: dup
          10dc: aconst_null
          10dd: aconst_null
          10de: invokespecial #1221 // java.lang.MatchException.<init>(Ljava.lang.String;Ljava.lang.Throwable;)V
          10e1: athrow
          10e2: ldc_w #1223 // "XCarry"
          10e5: goto 4337
          10e8: ldc_w #1225 // "XCarry Out"
          10eb: goto 4337
          10ee: ldc_w #1227 // "XCarry Drop"
          10f1: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          10f4: aload_1
          10f5: aload 13
          10f7: aload_1
          10f8: invokedynamic #1235 // invokedynamic(bsm=49) run(Lcom.example.addon.util.macro.XCarryAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          10fd: invokestatic #1239 // com.example.addon.util.macro.MacroExecutor.runOnClientThread(Lnet.minecraft.class_310;Ljava.lang.Runnable;)V
          1100: goto 4529
          1103: aload 8
          1105: instanceof #52 // class com.example.addon.util.macro.InventoryAuditAction
          1108: ifeq 4454
          110b: aload 8
          110d: checkcast #52 // class com.example.addon.util.macro.InventoryAuditAction
          1110: astore 14
          1112: aload 14
          1114: getfield #1242 // com.example.addon.util.macro.InventoryAuditAction.mode:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          1117: getstatic #1245 // com.example.addon.util.macro.InventoryAuditAction$Mode.DUPE:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          111a: if_acmpeq 4392
          111d: aload 14
          111f: getfield #1242 // com.example.addon.util.macro.InventoryAuditAction.mode:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          1122: getstatic #1248 // com.example.addon.util.macro.InventoryAuditAction$Mode.DUPE_SPAM:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          1125: if_acmpne 4454
          1128: aload 14
          112a: getfield #1252 // com.example.addon.util.macro.InventoryAuditAction.dupeVector:Lcom.example.addon.util.macro.InventoryAuditAction$DupeVector;
          112d: invokevirtual #1253 // com.example.addon.util.macro.InventoryAuditAction$DupeVector.name()Ljava.lang.String;
          1130: aload 14
          1132: getfield #1257 // com.example.addon.util.macro.InventoryAuditAction.openMode:Lcom.example.addon.util.macro.InventoryAuditAction$OpenMode;
          1135: invokevirtual #1258 // com.example.addon.util.macro.InventoryAuditAction$OpenMode.name()Ljava.lang.String;
          1138: invokedynamic #1261 // invokedynamic(bsm=50) makeConcatWithConstants(Ljava.lang.String;Ljava.lang.String;)Ljava.lang.String;
          113d: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          1140: aload 14
          1142: aload_1
          1143: invokevirtual #1264 // com.example.addon.util.macro.InventoryAuditAction.executeDupe(Lnet.minecraft.class_310;)V
          1146: goto 4529
          1149: astore 15
          114b: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          114e: invokevirtual #1117 // java.lang.Thread.interrupt()V
          1151: goto 4529
          1154: astore 15
          1156: aload 15
          1158: invokevirtual #1130 // java.lang.Exception.getMessage()Ljava.lang.String;
          115b: invokedynamic #1267 // invokedynamic(bsm=51) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          1160: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          1163: goto 4529
          1166: aload 5
          1168: ifnull 4517
          116b: aload 5
          116d: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          1170: ifeq 4517
          1173: new #1049 // class java.util.concurrent.CountDownLatch
          1176: dup
          1177: iconst_1
          1178: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          117b: astore 15
          117d: aload_1
          117e: aload 8
          1180: aload_1
          1181: aload 15
          1183: invokedynamic #1272 // invokedynamic(bsm=52) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          1188: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          118b: aload 15
          118d: ldc2_w #1109 // 100
          1190: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          1193: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          1196: pop
          1197: goto 4514
          119a: astore 16
          119c: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          119f: invokevirtual #1117 // java.lang.Thread.interrupt()V
          11a2: goto 4529
          11a5: aload_1
          11a6: aload 8
          11a8: aload_1
          11a9: invokedynamic #1277 // invokedynamic(bsm=53) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          11ae: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          11b1: aload 9
          11b3: ifnull 4553
          11b6: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          11b9: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          11bc: ifeq 4553
          11bf: aload 9
          11c1: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          11c4: goto 4553
          11c7: astore 10
          11c9: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          11cc: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          11cf: ifeq 4602
          11d2: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          11d5: astore 10
          11d7: aload 10
          11d9: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          11dc: ifeq 4597
          11df: aload 10
          11e1: iload 7
          11e3: iconst_1
          11e4: iadd
          11e5: aload_0
          11e6: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          11e9: invokeinterface #229 count=1 // java.util.List.size()I
          11ee: aload_0
          11ef: getfield #204 // com.example.addon.util.PackUtilMacro.name:Ljava.lang.String;
          11f2: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          11f5: goto 4602
          11f8: astore 10
          11fa: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          11fd: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          1200: ifeq 4652
          1203: aload 5
          1205: ifnull 4652
          1208: aload 5
          120a: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          120d: ifeq 4652
          1210: aload 5
          1212: invokevirtual #1280 // com.example.addon.modules.PackUtilModule.getActionDelayUs()I
          1215: istore 10
          1217: iload 10
          1219: ifle 4649
          121c: iload 10
          121e: i2l
          121f: ldc2_w #1281 // 1000
          1222: lmul
          1223: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          1226: goto 4652
          1229: invokestatic #1015 // java.lang.Thread.onSpinWait()V
          122c: iinc 7 1
          122f: goto 169
          1232: aload_0
          1233: getfield #188 // com.example.addon.util.PackUtilMacro.actions:Ljava.util.List;
          1236: invokeinterface #193 count=1 // java.util.List.isEmpty()Z
          123b: ifeq 4679
          123e: ldc_w #308 // "Â§cMacro stopped: no actions left."
          1241: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          1244: goto 4796
          1247: aload_0
          1248: getfield #277 // com.example.addon.util.PackUtilMacro.loop:Z
          124b: ifeq 4790
          124e: iload_2
          124f: iload_3
          1250: iconst_1
          1251: isub
          1252: if_icmpge 4790
          1255: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          1258: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          125b: ifeq 4790
          125e: aload 5
          1260: ifnull 4746
          1263: aload 5
          1265: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          1268: ifeq 4746
          126b: aload 5
          126d: invokevirtual #1280 // com.example.addon.modules.PackUtilModule.getActionDelayUs()I
          1270: istore 7
          1272: iload 7
          1274: ifle 4740
          1277: iload 7
          1279: i2l
          127a: ldc2_w #1281 // 1000
          127d: lmul
          127e: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          1281: goto 4743
          1284: invokestatic #1015 // java.lang.Thread.onSpinWait()V
          1287: goto 4790
          128a: aload 5
          128c: ifnull 4775
          128f: aload 5
          1291: invokevirtual #1285 // com.example.addon.modules.PackUtilModule.useMsSleepMode()Z
          1294: ifeq 4775
          1297: aload 5
          1299: invokevirtual #1288 // com.example.addon.modules.PackUtilModule.getMsSleepInterval()I
          129c: istore 7
          129e: iload 7
          12a0: i2l
          12a1: invokestatic #408 // java.lang.Thread.sleep(J)V
          12a4: goto 4790
          12a7: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          12aa: astore 7
          12ac: aload 7
          12ae: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          12b1: goto 4790
          12b4: astore 7
          12b6: iinc 2 1
          12b9: goto 77
          12bc: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          12bf: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          12c2: ifeq 4817
          12c5: aload_0
          12c6: getfield #204 // com.example.addon.util.PackUtilMacro.name:Ljava.lang.String;
          12c9: invokedynamic #1291 // invokedynamic(bsm=54) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          12ce: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          12d1: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          12d4: iconst_0
          12d5: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          12d8: aconst_null
          12d9: putstatic #197 // com.example.addon.util.macro.MacroExecutor.currentMacro:Lcom.example.addon.util.PackUtilMacro;
          12dc: ldc_w #310 // ""
          12df: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          12e2: iconst_m1
          12e3: putstatic #336 // com.example.addon.util.macro.MacroExecutor.currentStepIndex:I
          12e6: iconst_0
          12e7: putstatic #334 // com.example.addon.util.macro.MacroExecutor.totalSteps:I
          12ea: getstatic #1293 // com.example.addon.util.macro.MacroExecutor.isRotating:Ljava.util.concurrent.atomic.AtomicBoolean;
          12ed: iconst_0
          12ee: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          12f1: iconst_0
          12f2: putstatic #1295 // com.example.addon.util.macro.MacroExecutor.rotationAlignedFrames:I
          12f5: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          12f8: invokevirtual #288 // java.util.concurrent.CopyOnWriteArrayList.clear()V
          12fb: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          12fe: invokevirtual #293 // java.util.concurrent.ConcurrentHashMap.clear()V
          1301: invokestatic #1298 // com.example.addon.util.macro.MacroConditionRegistry.cancelAll()V
          1304: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          1307: astore 5
          1309: aload 5
          130b: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          130e: ifeq 4891
          1311: aload 5
          1313: iconst_m1
          1314: iconst_0
          1315: ldc_w #310 // ""
          1318: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          131b: goto 5169
          131e: astore 5
          1320: goto 5169
          1323: astore 5
          1325: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          1328: iconst_0
          1329: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          132c: aconst_null
          132d: putstatic #197 // com.example.addon.util.macro.MacroExecutor.currentMacro:Lcom.example.addon.util.PackUtilMacro;
          1330: ldc_w #310 // ""
          1333: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          1336: iconst_m1
          1337: putstatic #336 // com.example.addon.util.macro.MacroExecutor.currentStepIndex:I
          133a: iconst_0
          133b: putstatic #334 // com.example.addon.util.macro.MacroExecutor.totalSteps:I
          133e: getstatic #1293 // com.example.addon.util.macro.MacroExecutor.isRotating:Ljava.util.concurrent.atomic.AtomicBoolean;
          1341: iconst_0
          1342: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          1345: iconst_0
          1346: putstatic #1295 // com.example.addon.util.macro.MacroExecutor.rotationAlignedFrames:I
          1349: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          134c: invokevirtual #288 // java.util.concurrent.CopyOnWriteArrayList.clear()V
          134f: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          1352: invokevirtual #293 // java.util.concurrent.ConcurrentHashMap.clear()V
          1355: invokestatic #1298 // com.example.addon.util.macro.MacroConditionRegistry.cancelAll()V
          1358: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          135b: astore 5
          135d: aload 5
          135f: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          1362: ifeq 4975
          1365: aload 5
          1367: iconst_m1
          1368: iconst_0
          1369: ldc_w #310 // ""
          136c: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          136f: goto 5169
          1372: astore 5
          1374: goto 5169
          1377: astore 5
          1379: aload 5
          137b: invokevirtual #1130 // java.lang.Exception.getMessage()Ljava.lang.String;
          137e: invokedynamic #1301 // invokedynamic(bsm=55) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          1383: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          1386: aload 5
          1388: invokevirtual #1304 // java.lang.Exception.printStackTrace()V
          138b: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          138e: iconst_0
          138f: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          1392: aconst_null
          1393: putstatic #197 // com.example.addon.util.macro.MacroExecutor.currentMacro:Lcom.example.addon.util.PackUtilMacro;
          1396: ldc_w #310 // ""
          1399: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          139c: iconst_m1
          139d: putstatic #336 // com.example.addon.util.macro.MacroExecutor.currentStepIndex:I
          13a0: iconst_0
          13a1: putstatic #334 // com.example.addon.util.macro.MacroExecutor.totalSteps:I
          13a4: getstatic #1293 // com.example.addon.util.macro.MacroExecutor.isRotating:Ljava.util.concurrent.atomic.AtomicBoolean;
          13a7: iconst_0
          13a8: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          13ab: iconst_0
          13ac: putstatic #1295 // com.example.addon.util.macro.MacroExecutor.rotationAlignedFrames:I
          13af: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          13b2: invokevirtual #288 // java.util.concurrent.CopyOnWriteArrayList.clear()V
          13b5: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          13b8: invokevirtual #293 // java.util.concurrent.ConcurrentHashMap.clear()V
          13bb: invokestatic #1298 // com.example.addon.util.macro.MacroConditionRegistry.cancelAll()V
          13be: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          13c1: astore 5
          13c3: aload 5
          13c5: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          13c8: ifeq 5077
          13cb: aload 5
          13cd: iconst_m1
          13ce: iconst_0
          13cf: ldc_w #310 // ""
          13d2: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          13d5: goto 5169
          13d8: astore 5
          13da: goto 5169
          13dd: astore 32
          13df: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          13e2: iconst_0
          13e3: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          13e6: aconst_null
          13e7: putstatic #197 // com.example.addon.util.macro.MacroExecutor.currentMacro:Lcom.example.addon.util.PackUtilMacro;
          13ea: ldc_w #310 // ""
          13ed: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          13f0: iconst_m1
          13f1: putstatic #336 // com.example.addon.util.macro.MacroExecutor.currentStepIndex:I
          13f4: iconst_0
          13f5: putstatic #334 // com.example.addon.util.macro.MacroExecutor.totalSteps:I
          13f8: getstatic #1293 // com.example.addon.util.macro.MacroExecutor.isRotating:Ljava.util.concurrent.atomic.AtomicBoolean;
          13fb: iconst_0
          13fc: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          13ff: iconst_0
          1400: putstatic #1295 // com.example.addon.util.macro.MacroExecutor.rotationAlignedFrames:I
          1403: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          1406: invokevirtual #288 // java.util.concurrent.CopyOnWriteArrayList.clear()V
          1409: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          140c: invokevirtual #293 // java.util.concurrent.ConcurrentHashMap.clear()V
          140f: invokestatic #1298 // com.example.addon.util.macro.MacroConditionRegistry.cancelAll()V
          1412: invokestatic #222 // com.example.addon.util.PackUtilLANSync.getInstance()Lcom.example.addon.util.PackUtilLANSync;
          1415: astore 33
          1417: aload 33
          1419: invokevirtual #225 // com.example.addon.util.PackUtilLANSync.isInSession()Z
          141c: ifeq 5161
          141f: aload 33
          1421: iconst_m1
          1422: iconst_0
          1423: ldc_w #310 // ""
          1426: invokevirtual #233 // com.example.addon.util.PackUtilLANSync.broadcastStepProgress(IILjava.lang.String;)V
          1429: goto 5166
          142c: astore 33
          142e: aload 32
          1430: athrow
          1431: return
        */
    }

    private static String normalizePacketKey(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static boolean packetNameMatches(String expected, String candidate) {
        if (expected == null || expected.isEmpty() || candidate == null || candidate.isEmpty()) {
            return false;
        }
        String normalizedExpected = MacroExecutor.normalizePacketKey(expected);
        String normalizedCandidate = MacroExecutor.normalizePacketKey(candidate);
        if (normalizedExpected.isEmpty() || normalizedCandidate.isEmpty()) {
            return false;
        }
        if (normalizedExpected.equals(normalizedCandidate)) {
            return true;
        }
        if (normalizedCandidate.endsWith("packet")) {
            String strippedCandidate = normalizedCandidate.substring(0, normalizedCandidate.length() - "packet".length());
            if (normalizedExpected.equals(strippedCandidate)) {
                return true;
            }
        }
        return normalizedExpected.endsWith(normalizedCandidate) || normalizedCandidate.endsWith(normalizedExpected);
    }

    private static boolean matchesPacketTarget(String target, class_2596<?> packet, String direction) {
        if (packet == null) {
            return false;
        }
        String expectedDirection = WaitForPacketAction.getDirection(target);
        if (!expectedDirection.isEmpty() && !expectedDirection.equalsIgnoreCase(direction)) {
            return false;
        }
        String expectedName = WaitForPacketAction.getPacketName(target);
        if (expectedName.isEmpty()) {
            return true;
        }
        String friendlyDirectional = PackUtilPacketNamer.getFriendlyName(packet, direction);
        if (MacroExecutor.packetNameMatches(expectedName, friendlyDirectional)) {
            return true;
        }
        String friendlyGeneric = PackUtilPacketNamer.getFriendlyName(packet);
        if (MacroExecutor.packetNameMatches(expectedName, friendlyGeneric)) {
            return true;
        }
        String simpleName = packet.getClass().getSimpleName();
        if (MacroExecutor.packetNameMatches(expectedName, simpleName)) {
            return true;
        }
        String fullName = PackUtilPacketRegistry.getName(packet.getClass());
        return MacroExecutor.packetNameMatches(expectedName, fullName);
    }

    private static void awaitPacket(String target) {
        CompletableFuture<Void> future = new CompletableFuture();
        String normalizedTarget = WaitForPacketAction.normalizeTarget(target);
        var var3 = packetWaitLock;
        synchronized (packetWaitLock) {
        waitingPacketName.set(normalizedTarget);
        lastReceivedPacket.set("");
        activePacketFuture = future;
        isWaitingForPacket.set(true);
        }
        try {
            currentStatus = normalizedTarget.isEmpty() ? "Waiting for packet: Any" : "Waiting for packet: " + WaitForPacketAction.getDisplayLabel(normalizedTarget);
            MacroExecutor.waitForCondition(future);
        }
        finally {
            var var7 = packetWaitLock;
            synchronized (packetWaitLock) {
            if (activePacketFuture == future) {
                isWaitingForPacket.set(false);
                waitingPacketName.set("");
                activePacketFuture = null;
            }
            }
            /* goto L185; */
            var var8 = null;
            throw var8;
            L185: ;
            throw var6;
        }
        if (activePacketFuture == future) {
            isWaitingForPacket.set(false);
            waitingPacketName.set("");
            activePacketFuture = null;
        }
        /* goto @188; */
        var6 = null;
        var7 = packetWaitLock;
        synchronized (packetWaitLock) {
        if (activePacketFuture == future) {
            isWaitingForPacket.set(false);
            waitingPacketName.set("");
            activePacketFuture = null;
        }
        }
        throw var6;
        L188: ;
    }

    private static void awaitChat(WaitForChatAction wca) {
        CompletableFuture<Void> future = new CompletableFuture();
        activeChatFuture = future;
        isWaitingForChat.set(true);
        waitingChatPattern.set(wca.pattern);
        waitingChatPatternJson.set(wca.patternJson == null ? "" : wca.patternJson);
        waitingChatIsRegex.set(wca.useRegex);
        waitingChatFuzzyPercent.set(WaitForChatAction.clampFuzzyPercent(wca.fuzzyPercent));
        waitingChatServerOnly.set(wca.serverMessageOnly);
        lastMatchedChat.set("");
        try {
            if (wca.timeoutMs > 0) {
                future.completeOnTimeout(null, (long)wca.timeoutMs, TimeUnit.MILLISECONDS);
            }
            MacroExecutor.waitForCondition(future);
        }
        finally {
            isWaitingForChat.set(false);
            waitingChatPattern.set("");
            waitingChatPatternJson.set("");
            waitingChatIsRegex.set(false);
            waitingChatFuzzyPercent.set(100);
            waitingChatServerOnly.set(false);
            activeChatFuture = null;
            throw var2;
        }
    }

    private static void waitForCondition(CompletableFuture<Void> future) {
        Thread t = Thread.currentThread();
        future.whenComplete(MacroExecutor::lambda$waitForCondition$33 /* captured: t */);
        L15: ;
        if (future.isDone()) { /* goto L46; */ }
        if (!isRunning.get()) { /* goto L46; */ }
        LockSupport.parkNanos(5000000L);
        if (!Thread.interrupted()) { /* goto L15; */ }
        /* goto L46; */
        L46: ;
        if (!isRunning.get()) {
            future.cancel(true);
        }
    }

    private static void executeSingleActionWithWaits(class_310 mc, MacroAction action, PackUtilModule module) throws InterruptedException {
        /* decompile fallback: stack underflow while reading putstatic value @ offset 2301 opcode putstatic (stack_before=0) */
        /* decompile technical detail:
         * category: other
         * stage: operand_stack_simulation
         * detail: stack underflow while reading putstatic value @ offset 2301 opcode putstatic (stack_before=0)
         * explanation: the simulated JVM operand stack became inconsistent at the reported bytecode offset and opcode, so structured Java emission was aborted
         * emitted_body: raw bytecode disassembly follows
         */
        /* @obfuscation score:2/10 signals:fallback_stack_underflow hint:complex but likely not obfuscated — LLM should do well */
        /* bytecode:
          0000: aconst_null
          0001: astore_3
          0002: aload_1
          0003: instanceof #346 // class com.example.addon.util.macro.WaitsForGui
          0006: ifeq 57
          0009: aload_1
          000a: checkcast #346 // class com.example.addon.util.macro.WaitsForGui
          000d: astore 4
          000f: aload 4
          0011: invokeinterface #349 count=1 // com.example.addon.util.macro.WaitsForGui.isWaitForGui()Z
          0016: ifeq 57
          0019: aload 4
          001b: invokeinterface #352 count=1 // com.example.addon.util.macro.WaitsForGui.isWaitForGuiChange()Z
          0020: ifeq 46
          0023: aload_0
          0024: getfield #356 // net.minecraft.class_310.field_1755:Lnet.minecraft.class_437;
          0027: invokestatic #362 // com.example.addon.util.macro.MacroConditionRegistry.waitForGuiChange(Lnet.minecraft.class_437;)Ljava.util.concurrent.CompletableFuture;
          002a: astore_3
          002b: goto 57
          002e: aload 4
          0030: invokeinterface #368 count=1 // com.example.addon.util.macro.WaitsForGui.getWaitGuiName()Ljava.lang.String;
          0035: invokestatic #372 // com.example.addon.util.macro.MacroConditionRegistry.waitForGui(Ljava.lang.String;)Ljava.util.concurrent.CompletableFuture;
          0038: astore_3
          0039: aload_1
          003a: instanceof #387 // class com.example.addon.util.macro.DelayAction
          003d: ifeq 131
          0040: aload_1
          0041: checkcast #387 // class com.example.addon.util.macro.DelayAction
          0044: astore 10
          0046: aload 10
          0048: getfield #390 // com.example.addon.util.macro.DelayAction.useTicks:Z
          004b: ifeq 119
          004e: iconst_0
          004f: istore 11
          0051: iload 11
          0053: aload 10
          0055: getfield #393 // com.example.addon.util.macro.DelayAction.delayTicks:I
          0058: if_icmpge 116
          005b: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          005e: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0061: ifeq 116
          0064: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          0067: astore 12
          0069: aload 12
          006b: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          006e: iinc 11 1
          0071: goto 81
          0074: goto 128
          0077: aload 10
          0079: getfield #404 // com.example.addon.util.macro.DelayAction.delayMs:I
          007c: i2l
          007d: invokestatic #408 // java.lang.Thread.sleep(J)V
          0080: goto 3371
          0083: aload_1
          0084: instanceof #410 // class com.example.addon.util.macro.WaitForPacketAction
          0087: ifeq 220
          008a: aload_1
          008b: checkcast #410 // class com.example.addon.util.macro.WaitForPacketAction
          008e: invokevirtual #414 // com.example.addon.util.macro.WaitForPacketAction.effectiveList()Ljava.util.List;
          0091: astore 10
          0093: aload 10
          0095: invokeinterface #193 count=1 // java.util.List.isEmpty()Z
          009a: ifeq 166
          009d: ldc_w #310 // ""
          00a0: invokestatic #417 // com.example.addon.util.macro.MacroExecutor.awaitPacket(Ljava.lang.String;)V
          00a3: goto 217
          00a6: aload 10
          00a8: invokeinterface #421 count=1 // java.util.List.iterator()Ljava.util.Iterator;
          00ad: astore 11
          00af: aload 11
          00b1: invokeinterface #426 count=1 // java.util.Iterator.hasNext()Z
          00b6: ifeq 217
          00b9: aload 11
          00bb: invokeinterface #430 count=1 // java.util.Iterator.next()Ljava.lang.Object;
          00c0: checkcast #317 // class java.lang.String
          00c3: astore 12
          00c5: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          00c8: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          00cb: ifne 209
          00ce: goto 217
          00d1: aload 12
          00d3: invokestatic #417 // com.example.addon.util.macro.MacroExecutor.awaitPacket(Ljava.lang.String;)V
          00d6: goto 175
          00d9: goto 3371
          00dc: aload_1
          00dd: instanceof #432 // class com.example.addon.util.macro.WaitForHealthAction
          00e0: ifeq 269
          00e3: aload_1
          00e4: checkcast #432 // class com.example.addon.util.macro.WaitForHealthAction
          00e7: astore 10
          00e9: aload 10
          00eb: invokevirtual #435 // com.example.addon.util.macro.WaitForHealthAction.waitingStatusText()Ljava.lang.String;
          00ee: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          00f1: aload 10
          00f3: getfield #438 // com.example.addon.util.macro.WaitForHealthAction.healthThreshold:F
          00f6: aload 10
          00f8: getfield #441 // com.example.addon.util.macro.WaitForHealthAction.below:Z
          00fb: invokestatic #445 // com.example.addon.util.macro.MacroConditionRegistry.waitForHealth(FZ)Ljava.util.concurrent.CompletableFuture;
          00fe: astore 11
          0100: aload 11
          0102: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0105: goto 266
          0108: astore 11
          010a: goto 3371
          010d: aload_1
          010e: instanceof #447 // class com.example.addon.util.macro.WaitForBlockAction
          0111: ifeq 310
          0114: aload_1
          0115: checkcast #447 // class com.example.addon.util.macro.WaitForBlockAction
          0118: astore 10
          011a: aload 10
          011c: invokevirtual #450 // com.example.addon.util.macro.WaitForBlockAction.getDisplayName()Ljava.lang.String;
          011f: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0122: aload 10
          0124: invokestatic #454 // com.example.addon.util.macro.MacroConditionRegistry.waitForBlock(Lcom.example.addon.util.macro.WaitForBlockAction;)Ljava.util.concurrent.CompletableFuture;
          0127: astore 11
          0129: aload 11
          012b: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          012e: goto 307
          0131: astore 11
          0133: goto 3371
          0136: aload_1
          0137: instanceof #17 // class com.example.addon.util.macro.WaitForGuiAction
          013a: ifeq 406
          013d: aload_1
          013e: checkcast #17 // class com.example.addon.util.macro.WaitForGuiAction
          0141: astore 10
          0143: aload 10
          0145: getfield #458 // com.example.addon.util.macro.WaitForGuiAction.waitMode:Lcom.example.addon.util.macro.WaitForGuiAction$WaitMode;
          0148: getstatic #461 // com.example.addon.util.macro.WaitForGuiAction$WaitMode.CLOSE:Lcom.example.addon.util.macro.WaitForGuiAction$WaitMode;
          014b: if_acmpne 370
          014e: aload 10
          0150: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          0153: invokedynamic #467 // invokedynamic(bsm=5) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0158: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          015b: aload 10
          015d: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          0160: invokestatic #470 // com.example.addon.util.macro.MacroConditionRegistry.waitForGuiClose(Ljava.lang.String;)Ljava.util.concurrent.CompletableFuture;
          0163: astore 11
          0165: aload 11
          0167: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          016a: goto 403
          016d: astore 11
          016f: goto 403
          0172: aload 10
          0174: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          0177: invokedynamic #473 // invokedynamic(bsm=6) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          017c: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          017f: aload 10
          0181: getfield #464 // com.example.addon.util.macro.WaitForGuiAction.guiTitle:Ljava.lang.String;
          0184: invokestatic #372 // com.example.addon.util.macro.MacroConditionRegistry.waitForGui(Ljava.lang.String;)Ljava.util.concurrent.CompletableFuture;
          0187: astore 11
          0189: aload 11
          018b: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          018e: goto 403
          0191: astore 11
          0193: goto 3371
          0196: aload_1
          0197: instanceof #475 // class com.example.addon.util.macro.WaitForCooldownAction
          019a: ifeq 504
          019d: aload_1
          019e: checkcast #475 // class com.example.addon.util.macro.WaitForCooldownAction
          01a1: astore 10
          01a3: aload 10
          01a5: getfield #479 // com.example.addon.util.macro.WaitForCooldownAction.itemTarget:Lcom.example.addon.util.macro.ItemTarget;
          01a8: aload 10
          01aa: getfield #482 // com.example.addon.util.macro.WaitForCooldownAction.itemName:Ljava.lang.String;
          01ad: invokestatic #486 // com.example.addon.util.macro.MacroExecutor.resolveItemTarget(Lcom.example.addon.util.macro.ItemTarget;Ljava.lang.String;)Lcom.example.addon.util.macro.ItemTarget;
          01b0: astore 11
          01b2: aload 11
          01b4: invokestatic #490 // com.example.addon.util.macro.MacroExecutor.describeItemTarget(Lcom.example.addon.util.macro.ItemTarget;)Ljava.lang.String;
          01b7: astore 12
          01b9: aload 12
          01bb: invokevirtual #491 // java.lang.String.isEmpty()Z
          01be: ifne 454
          01c1: aload 12
          01c3: goto 471
          01c6: aload 10
          01c8: getfield #496 // com.example.addon.util.macro.WaitForCooldownAction.checkMainHand:Z
          01cb: ifeq 468
          01ce: ldc_w #498 // "Main Hand"
          01d1: goto 471
          01d4: ldc_w #500 // "Off Hand"
          01d7: invokedynamic #503 // invokedynamic(bsm=7) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          01dc: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          01df: aload 11
          01e1: aload 10
          01e3: getfield #496 // com.example.addon.util.macro.WaitForCooldownAction.checkMainHand:Z
          01e6: invokestatic #507 // com.example.addon.util.macro.MacroConditionRegistry.waitForCooldown(Lcom.example.addon.util.macro.ItemTarget;Z)Ljava.util.concurrent.CompletableFuture;
          01e9: astore 13
          01eb: aload 13
          01ed: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          01f0: goto 501
          01f3: astore 13
          01f5: goto 3371
          01f8: aload_1
          01f9: instanceof #509 // class com.example.addon.util.macro.WaitPosAction
          01fc: ifeq 626
          01ff: aload_1
          0200: checkcast #509 // class com.example.addon.util.macro.WaitPosAction
          0203: astore 10
          0205: ldc_w #511 // "%.0f, %.0f, %.0f"
          0208: iconst_3
          0209: anewarray #4 // class java.lang.Object
          020c: dup
          020d: iconst_0
          020e: aload 10
          0210: getfield #514 // com.example.addon.util.macro.WaitPosAction.x:D
          0213: invokestatic #520 // java.lang.Double.valueOf(D)Ljava.lang.Double;
          0216: aastore
          0217: dup
          0218: iconst_1
          0219: aload 10
          021b: getfield #523 // com.example.addon.util.macro.WaitPosAction.y:D
          021e: invokestatic #520 // java.lang.Double.valueOf(D)Ljava.lang.Double;
          0221: aastore
          0222: dup
          0223: iconst_2
          0224: aload 10
          0226: getfield #526 // com.example.addon.util.macro.WaitPosAction.z:D
          0229: invokestatic #520 // java.lang.Double.valueOf(D)Ljava.lang.Double;
          022c: aastore
          022d: invokestatic #530 // java.lang.String.format(Ljava.lang.String;[Ljava.lang.Object;)Ljava.lang.String;
          0230: invokedynamic #533 // invokedynamic(bsm=8) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0235: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0238: aload 10
          023a: getfield #514 // com.example.addon.util.macro.WaitPosAction.x:D
          023d: aload 10
          023f: getfield #523 // com.example.addon.util.macro.WaitPosAction.y:D
          0242: aload 10
          0244: getfield #526 // com.example.addon.util.macro.WaitPosAction.z:D
          0247: aload 10
          0249: getfield #536 // com.example.addon.util.macro.WaitPosAction.leeway:D
          024c: aload 10
          024e: getfield #539 // com.example.addon.util.macro.WaitPosAction.checkRotation:Z
          0251: aload 10
          0253: getfield #542 // com.example.addon.util.macro.WaitPosAction.yaw:F
          0256: aload 10
          0258: getfield #545 // com.example.addon.util.macro.WaitPosAction.pitch:F
          025b: aload 10
          025d: getfield #548 // com.example.addon.util.macro.WaitPosAction.rotLeeway:F
          0260: invokestatic #552 // com.example.addon.util.macro.MacroConditionRegistry.waitForPos(DDDDZFFF)Ljava.util.concurrent.CompletableFuture;
          0263: astore 11
          0265: aload 11
          0267: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          026a: goto 623
          026d: astore 11
          026f: goto 3371
          0272: aload_1
          0273: instanceof #683 // class com.example.addon.util.macro.WaitForChatAction
          0276: ifeq 660
          0279: aload_1
          027a: checkcast #683 // class com.example.addon.util.macro.WaitForChatAction
          027d: astore 10
          027f: aload 10
          0281: getfield #818 // com.example.addon.util.macro.WaitForChatAction.pattern:Ljava.lang.String;
          0284: invokedynamic #821 // invokedynamic(bsm=27) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0289: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          028c: aload 10
          028e: invokestatic #825 // com.example.addon.util.macro.MacroExecutor.awaitChat(Lcom.example.addon.util.macro.WaitForChatAction;)V
          0291: goto 3371
          0294: aload_1
          0295: instanceof #677 // class com.example.addon.util.macro.WaitForEntityAction
          0298: ifeq 701
          029b: aload_1
          029c: checkcast #677 // class com.example.addon.util.macro.WaitForEntityAction
          029f: astore 10
          02a1: aload 10
          02a3: invokevirtual #826 // com.example.addon.util.macro.WaitForEntityAction.getDisplayName()Ljava.lang.String;
          02a6: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          02a9: aload 10
          02ab: invokestatic #830 // com.example.addon.util.macro.MacroConditionRegistry.waitForEntity(Lcom.example.addon.util.macro.WaitForEntityAction;)Ljava.util.concurrent.CompletableFuture;
          02ae: astore 11
          02b0: aload 11
          02b2: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          02b5: goto 698
          02b8: astore 11
          02ba: goto 3371
          02bd: aload_1
          02be: instanceof #679 // class com.example.addon.util.macro.WaitForSoundAction
          02c1: ifeq 779
          02c4: aload_1
          02c5: checkcast #679 // class com.example.addon.util.macro.WaitForSoundAction
          02c8: astore 10
          02ca: aload 10
          02cc: getfield #833 // com.example.addon.util.macro.WaitForSoundAction.soundIds:Ljava.util.List;
          02cf: invokeinterface #193 count=1 // java.util.List.isEmpty()Z
          02d4: ifeq 733
          02d7: ldc_w #835 // "any"
          02da: goto 747
          02dd: aload 10
          02df: getfield #833 // com.example.addon.util.macro.WaitForSoundAction.soundIds:Ljava.util.List;
          02e2: iconst_0
          02e3: invokeinterface #339 count=2 // java.util.List.get(I)Ljava.lang.Object;
          02e8: checkcast #317 // class java.lang.String
          02eb: astore 11
          02ed: aload 11
          02ef: invokedynamic #838 // invokedynamic(bsm=28) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          02f4: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          02f7: aload 10
          02f9: invokestatic #842 // com.example.addon.util.macro.MacroConditionRegistry.waitForSound(Lcom.example.addon.util.macro.WaitForSoundAction;)Ljava.util.concurrent.CompletableFuture;
          02fc: astore 12
          02fe: aload 12
          0300: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0303: goto 776
          0306: astore 12
          0308: goto 3371
          030b: aload_1
          030c: instanceof #681 // class com.example.addon.util.macro.WaitForSlotChangeAction
          030f: ifeq 820
          0312: aload_1
          0313: checkcast #681 // class com.example.addon.util.macro.WaitForSlotChangeAction
          0316: astore 10
          0318: aload 10
          031a: invokevirtual #849 // com.example.addon.util.macro.WaitForSlotChangeAction.getDisplayName()Ljava.lang.String;
          031d: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0320: aload 10
          0322: invokestatic #853 // com.example.addon.util.macro.MacroConditionRegistry.waitForSlotChange(Lcom.example.addon.util.macro.WaitForSlotChangeAction;)Ljava.util.concurrent.CompletableFuture;
          0325: astore 11
          0327: aload 11
          0329: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          032c: goto 817
          032f: astore 11
          0331: goto 3371
          0334: aload_1
          0335: instanceof #855 // class com.example.addon.util.macro.WaitForLanStepAction
          0338: ifeq 861
          033b: aload_1
          033c: checkcast #855 // class com.example.addon.util.macro.WaitForLanStepAction
          033f: astore 10
          0341: aload 10
          0343: invokevirtual #856 // com.example.addon.util.macro.WaitForLanStepAction.getDisplayName()Ljava.lang.String;
          0346: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0349: aload 10
          034b: invokestatic #860 // com.example.addon.util.macro.MacroConditionRegistry.waitForLanStep(Lcom.example.addon.util.macro.WaitForLanStepAction;)Ljava.util.concurrent.CompletableFuture;
          034e: astore 11
          0350: aload 11
          0352: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0355: goto 858
          0358: astore 11
          035a: goto 3371
          035d: aload_1
          035e: instanceof #685 // class com.example.addon.util.macro.GoToAction
          0361: ifeq 883
          0364: aload_1
          0365: checkcast #685 // class com.example.addon.util.macro.GoToAction
          0368: astore 10
          036a: aload_0
          036b: aload 10
          036d: invokestatic #733 // com.example.addon.util.macro.MacroExecutor.runGoToAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.GoToAction;)V
          0370: goto 3371
          0373: aload_1
          0374: instanceof #735 // class com.example.addon.util.macro.MoveAction
          0377: ifeq 1006
          037a: aload_1
          037b: checkcast #735 // class com.example.addon.util.macro.MoveAction
          037e: astore 10
          0380: aload 10
          0382: getfield #738 // com.example.addon.util.macro.MoveAction.nonBlocking:Z
          0385: ifeq 941
          0388: aload_0
          0389: aload 10
          038b: aload_0
          038c: invokedynamic #1642 // invokedynamic(bsm=58) run(Lcom.example.addon.util.macro.MoveAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0391: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0394: getstatic #290 // com.example.addon.util.macro.MacroExecutor.backgroundMoves:Ljava.util.concurrent.ConcurrentHashMap;
          0397: aload 10
          0399: iconst_1
          039a: newarray int
          039c: dup
          039d: iconst_0
          039e: aload 10
          03a0: getfield #747 // com.example.addon.util.macro.MoveAction.durationTicks:I
          03a3: iconst_1
          03a4: isub
          03a5: iastore
          03a6: invokevirtual #751 // java.util.concurrent.ConcurrentHashMap.put(Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;
          03a9: pop
          03aa: goto 1003
          03ad: iconst_0
          03ae: istore 11
          03b0: iload 11
          03b2: aload 10
          03b4: getfield #747 // com.example.addon.util.macro.MoveAction.durationTicks:I
          03b7: if_icmpge 991
          03ba: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          03bd: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          03c0: ifeq 991
          03c3: aload_0
          03c4: aload 10
          03c6: aload_0
          03c7: invokedynamic #1647 // invokedynamic(bsm=59) run(Lcom.example.addon.util.macro.MoveAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          03cc: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          03cf: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          03d2: astore 12
          03d4: aload 12
          03d6: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          03d9: iinc 11 1
          03dc: goto 944
          03df: aload_0
          03e0: aload 10
          03e2: aload_0
          03e3: invokedynamic #1652 // invokedynamic(bsm=60) run(Lcom.example.addon.util.macro.MoveAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          03e8: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          03eb: goto 3371
          03ee: aload_1
          03ef: instanceof #30 // class com.example.addon.util.macro.LookAtBlockAction
          03f2: ifeq 1088
          03f5: aload_1
          03f6: checkcast #30 // class com.example.addon.util.macro.LookAtBlockAction
          03f9: astore 10
          03fb: aload_0
          03fc: aload 10
          03fe: invokestatic #765 // com.example.addon.util.macro.MacroExecutor.resolveLookAtTargetOnClient(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.LookAtBlockAction;)Lcom.example.addon.util.macro.LookAtBlockAction$RotationTarget;
          0401: astore 11
          0403: aload 11
          0405: ifnonnull 1033
          0408: return
          0409: aload 10
          040b: getfield #768 // com.example.addon.util.macro.LookAtBlockAction.smooth:Z
          040e: ifeq 1073
          0411: aload 11
          0413: invokevirtual #771 // com.example.addon.util.macro.LookAtBlockAction$RotationTarget.yaw()F
          0416: aload 11
          0418: invokevirtual #773 // com.example.addon.util.macro.LookAtBlockAction$RotationTarget.pitch()F
          041b: aload 10
          041d: invokevirtual #777 // com.example.addon.util.macro.LookAtBlockAction.getRotationStep()D
          0420: invokestatic #781 // com.example.addon.util.macro.MacroExecutor.startSmoothRotation(FFD)V
          0423: aload 10
          0425: getfield #784 // com.example.addon.util.macro.LookAtBlockAction.waitForCompletion:Z
          0428: ifeq 1085
          042b: invokestatic #787 // com.example.addon.util.macro.MacroExecutor.waitForSmoothRotationCompletion()V
          042e: goto 1085
          0431: aload_0
          0432: aload_0
          0433: aload 11
          0435: invokedynamic #1657 // invokedynamic(bsm=61) run(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.LookAtBlockAction$RotationTarget;)Ljava.lang.Runnable;
          043a: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          043d: goto 3371
          0440: aload_1
          0441: instanceof #1022 // class com.example.addon.util.macro.RotateAction
          0444: ifeq 1155
          0447: aload_1
          0448: checkcast #1022 // class com.example.addon.util.macro.RotateAction
          044b: astore 10
          044d: aload 10
          044f: getfield #1023 // com.example.addon.util.macro.RotateAction.smooth:Z
          0452: ifeq 1141
          0455: aload 10
          0457: getfield #1024 // com.example.addon.util.macro.RotateAction.yaw:F
          045a: aload 10
          045c: getfield #1025 // com.example.addon.util.macro.RotateAction.pitch:F
          045f: aload 10
          0461: invokevirtual #1026 // com.example.addon.util.macro.RotateAction.getRotationStep()D
          0464: invokestatic #781 // com.example.addon.util.macro.MacroExecutor.startSmoothRotation(FFD)V
          0467: aload 10
          0469: getfield #1027 // com.example.addon.util.macro.RotateAction.waitForCompletion:Z
          046c: ifeq 1152
          046f: invokestatic #787 // com.example.addon.util.macro.MacroExecutor.waitForSmoothRotationCompletion()V
          0472: goto 1152
          0475: aload_0
          0476: aload_1
          0477: aload_0
          0478: invokedynamic #1662 // invokedynamic(bsm=62) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          047d: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0480: goto 3371
          0483: aload_1
          0484: instanceof #844 // class com.example.addon.util.macro.MineAction
          0487: ifeq 1177
          048a: aload_1
          048b: checkcast #844 // class com.example.addon.util.macro.MineAction
          048e: astore 10
          0490: aload_0
          0491: aload 10
          0493: invokestatic #848 // com.example.addon.util.macro.MacroExecutor.runMineAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.MineAction;)V
          0496: goto 3371
          0499: aload_1
          049a: instanceof #35 // class com.example.addon.util.macro.UseItemAction
          049d: ifeq 1458
          04a0: aload_1
          04a1: checkcast #35 // class com.example.addon.util.macro.UseItemAction
          04a4: astore 10
          04a6: aload 10
          04a8: getfield #1044 // com.example.addon.util.macro.UseItemAction.useMode:Lcom.example.addon.util.macro.UseItemAction$UseMode;
          04ab: getstatic #1047 // com.example.addon.util.macro.UseItemAction$UseMode.CUSTOM_HOLD:Lcom.example.addon.util.macro.UseItemAction$UseMode;
          04ae: if_acmpne 1344
          04b1: new #1049 // class java.util.concurrent.CountDownLatch
          04b4: dup
          04b5: iconst_1
          04b6: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          04b9: astore 11
          04bb: aload_0
          04bc: aload 10
          04be: aload_0
          04bf: aload 11
          04c1: invokedynamic #1667 // invokedynamic(bsm=63) run(Lcom.example.addon.util.macro.UseItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          04c6: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          04c9: aload 11
          04cb: ldc2_w #1061 // 200
          04ce: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          04d1: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          04d4: pop
          04d5: goto 1248
          04d8: astore 12
          04da: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          04dd: invokevirtual #1117 // java.lang.Thread.interrupt()V
          04e0: aload 10
          04e2: getfield #1075 // com.example.addon.util.macro.UseItemAction.holdTicks:I
          04e5: ifle 1341
          04e8: iconst_0
          04e9: istore 12
          04eb: iload 12
          04ed: aload 10
          04ef: getfield #1075 // com.example.addon.util.macro.UseItemAction.holdTicks:I
          04f2: if_icmpge 1294
          04f5: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          04f8: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          04fb: ifeq 1294
          04fe: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          0501: astore 13
          0503: aload 13
          0505: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0508: iinc 12 1
          050b: goto 1259
          050e: new #1049 // class java.util.concurrent.CountDownLatch
          0511: dup
          0512: iconst_1
          0513: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0516: astore 12
          0518: aload_0
          0519: aload 10
          051b: aload_0
          051c: aload 12
          051e: invokedynamic #1672 // invokedynamic(bsm=64) run(Lcom.example.addon.util.macro.UseItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0523: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0526: aload 12
          0528: ldc2_w #1061 // 200
          052b: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          052e: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0531: pop
          0532: goto 1341
          0535: astore 13
          0537: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          053a: invokevirtual #1117 // java.lang.Thread.interrupt()V
          053d: goto 1455
          0540: iconst_1
          0541: aload 10
          0543: getfield #1083 // com.example.addon.util.macro.UseItemAction.useCount:I
          0546: invokestatic #710 // java.lang.Math.max(II)I
          0549: istore 11
          054b: iconst_0
          054c: istore 12
          054e: iload 12
          0550: iload 11
          0552: if_icmpge 1455
          0555: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0558: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          055b: ifeq 1455
          055e: new #1049 // class java.util.concurrent.CountDownLatch
          0561: dup
          0562: iconst_1
          0563: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0566: astore 13
          0568: aload_0
          0569: aload 10
          056b: aload_0
          056c: aload 13
          056e: invokedynamic #1677 // invokedynamic(bsm=65) run(Lcom.example.addon.util.macro.UseItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0573: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0576: aload 13
          0578: ldc2_w #1061 // 200
          057b: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          057e: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0581: pop
          0582: goto 1421
          0585: astore 14
          0587: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          058a: invokevirtual #1117 // java.lang.Thread.interrupt()V
          058d: iload 12
          058f: iload 11
          0591: iconst_1
          0592: isub
          0593: if_icmpge 1449
          0596: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0599: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          059c: ifeq 1449
          059f: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          05a2: astore 14
          05a4: aload 14
          05a6: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          05a9: iinc 12 1
          05ac: goto 1358
          05af: goto 3371
          05b2: aload_1
          05b3: instanceof #554 // class com.example.addon.util.macro.JumpAction
          05b6: ifeq 1557
          05b9: aload_1
          05ba: checkcast #554 // class com.example.addon.util.macro.JumpAction
          05bd: astore 10
          05bf: aload_0
          05c0: aload 10
          05c2: aload_0
          05c3: invokedynamic #1682 // invokedynamic(bsm=66) run(Lcom.example.addon.util.macro.JumpAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          05c8: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          05cb: aload 10
          05cd: getfield #568 // com.example.addon.util.macro.JumpAction.tap:Z
          05d0: ifeq 1504
          05d3: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          05d6: astore 11
          05d8: aload 11
          05da: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          05dd: goto 1542
          05e0: iconst_0
          05e1: istore 11
          05e3: iload 11
          05e5: aload 10
          05e7: getfield #571 // com.example.addon.util.macro.JumpAction.durationTicks:I
          05ea: if_icmpge 1542
          05ed: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          05f0: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          05f3: ifeq 1542
          05f6: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          05f9: astore 12
          05fb: aload 12
          05fd: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0600: iinc 11 1
          0603: goto 1507
          0606: aload_0
          0607: aload 10
          0609: aload_0
          060a: invokedynamic #1687 // invokedynamic(bsm=67) run(Lcom.example.addon.util.macro.JumpAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          060f: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0612: goto 3371
          0615: aload_1
          0616: instanceof #578 // class com.example.addon.util.macro.SneakAction
          0619: ifeq 1645
          061c: aload_1
          061d: checkcast #578 // class com.example.addon.util.macro.SneakAction
          0620: astore 10
          0622: aload_0
          0623: aload 10
          0625: aload_0
          0626: invokedynamic #1692 // invokedynamic(bsm=68) run(Lcom.example.addon.util.macro.SneakAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          062b: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          062e: aload 10
          0630: getfield #589 // com.example.addon.util.macro.SneakAction.persistent:Z
          0633: ifeq 1622
          0636: aload 10
          0638: getfield #592 // com.example.addon.util.macro.SneakAction.sneak:Z
          063b: ifeq 1622
          063e: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0641: invokedynamic #1697 // invokedynamic(bsm=69) test()Ljava.util.function.Predicate;
          0646: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          0649: pop
          064a: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          064d: aload 10
          064f: invokevirtual #608 // java.util.concurrent.CopyOnWriteArrayList.add(Ljava.lang.Object;)Z
          0652: pop
          0653: goto 1642
          0656: aload 10
          0658: getfield #592 // com.example.addon.util.macro.SneakAction.sneak:Z
          065b: ifne 1642
          065e: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0661: invokedynamic #1702 // invokedynamic(bsm=70) test()Ljava.util.function.Predicate;
          0666: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          0669: pop
          066a: goto 3371
          066d: aload_1
          066e: instanceof #615 // class com.example.addon.util.macro.SprintAction
          0671: ifeq 1733
          0674: aload_1
          0675: checkcast #615 // class com.example.addon.util.macro.SprintAction
          0678: astore 10
          067a: aload_0
          067b: aload 10
          067d: aload_0
          067e: invokedynamic #1707 // invokedynamic(bsm=71) run(Lcom.example.addon.util.macro.SprintAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0683: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0686: aload 10
          0688: getfield #624 // com.example.addon.util.macro.SprintAction.persistent:Z
          068b: ifeq 1710
          068e: aload 10
          0690: getfield #627 // com.example.addon.util.macro.SprintAction.sprint:Z
          0693: ifeq 1710
          0696: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          0699: invokedynamic #1712 // invokedynamic(bsm=72) test()Ljava.util.function.Predicate;
          069e: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          06a1: pop
          06a2: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          06a5: aload 10
          06a7: invokevirtual #608 // java.util.concurrent.CopyOnWriteArrayList.add(Ljava.lang.Object;)Z
          06aa: pop
          06ab: goto 1730
          06ae: aload 10
          06b0: getfield #627 // com.example.addon.util.macro.SprintAction.sprint:Z
          06b3: ifne 1730
          06b6: getstatic #283 // com.example.addon.util.macro.MacroExecutor.persistentActions:Ljava.util.concurrent.CopyOnWriteArrayList;
          06b9: invokedynamic #1717 // invokedynamic(bsm=73) test()Ljava.util.function.Predicate;
          06be: invokevirtual #607 // java.util.concurrent.CopyOnWriteArrayList.removeIf(Ljava.util.function.Predicate;)Z
          06c1: pop
          06c2: goto 3371
          06c5: aload_1
          06c6: instanceof #701 // class com.example.addon.util.macro.NbtBookAction
          06c9: ifeq 1878
          06cc: aload_1
          06cd: checkcast #701 // class com.example.addon.util.macro.NbtBookAction
          06d0: astore 4
          06d2: iconst_1
          06d3: aload 4
          06d5: getfield #704 // com.example.addon.util.macro.NbtBookAction.bookCount:I
          06d8: invokestatic #710 // java.lang.Math.max(II)I
          06db: istore 10
          06dd: iconst_1
          06de: aload 4
          06e0: getfield #711 // com.example.addon.util.macro.NbtBookAction.delayTicks:I
          06e3: invokestatic #710 // java.lang.Math.max(II)I
          06e6: i2l
          06e7: ldc2_w #712 // 50
          06ea: lmul
          06eb: lstore 11
          06ed: iconst_0
          06ee: istore 13
          06f0: iload 13
          06f2: iload 10
          06f4: if_icmpge 1875
          06f7: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          06fa: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          06fd: ifne 1795
          0700: goto 1875
          0703: iload 13
          0705: istore 14
          0707: new #364 // class java.util.concurrent.CompletableFuture
          070a: dup
          070b: invokespecial #714 // java.util.concurrent.CompletableFuture.<init>()V
          070e: astore 15
          0710: aload_0
          0711: aload 15
          0713: aload 4
          0715: aload_0
          0716: iload 14
          0718: iload 10
          071a: invokedynamic #1722 // invokedynamic(bsm=74) run(Ljava.util.concurrent.CompletableFuture;Lcom.example.addon.util.macro.NbtBookAction;Lnet.minecraft.class_310;II)Ljava.lang.Runnable;
          071f: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0722: aload 15
          0724: invokevirtual #724 // java.util.concurrent.CompletableFuture.get()Ljava.lang.Object;
          0727: checkcast #726 // class java.lang.Boolean
          072a: astore 16
          072c: aload 16
          072e: invokevirtual #729 // java.lang.Boolean.booleanValue()Z
          0731: ifne 1847
          0734: goto 1875
          0737: goto 1855
          073a: astore 16
          073c: goto 1875
          073f: iload 13
          0741: iload 10
          0743: iconst_1
          0744: isub
          0745: if_icmpge 1869
          0748: lload 11
          074a: invokestatic #408 // java.lang.Thread.sleep(J)V
          074d: iinc 13 1
          0750: goto 1776
          0753: goto 3371
          0756: aload_1
          0757: instanceof #1090 // class com.example.addon.util.macro.ItemAction
          075a: ifeq 1984
          075d: aload_1
          075e: checkcast #1090 // class com.example.addon.util.macro.ItemAction
          0761: astore 10
          0763: aload 10
          0765: getfield #1093 // com.example.addon.util.macro.ItemAction.waitForItem:Z
          0768: ifeq 1910
          076b: aload_0
          076c: aload 10
          076e: invokestatic #1097 // com.example.addon.util.macro.MacroExecutor.waitForItemActionTargets(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.ItemAction;)V
          0771: goto 1910
          0774: astore 11
          0776: aload_2
          0777: ifnull 1970
          077a: aload_2
          077b: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          077e: ifeq 1970
          0781: new #1049 // class java.util.concurrent.CountDownLatch
          0784: dup
          0785: iconst_1
          0786: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0789: astore 11
          078b: aload_0
          078c: aload_1
          078d: aload_0
          078e: aload 11
          0790: invokedynamic #1727 // invokedynamic(bsm=75) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0795: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0798: aload 11
          079a: ldc2_w #1109 // 100
          079d: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          07a0: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          07a3: pop
          07a4: goto 1967
          07a7: astore 12
          07a9: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          07ac: invokevirtual #1117 // java.lang.Thread.interrupt()V
          07af: goto 1981
          07b2: aload_0
          07b3: aload_1
          07b4: aload_0
          07b5: invokedynamic #1732 // invokedynamic(bsm=76) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          07ba: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          07bd: goto 3371
          07c0: aload_1
          07c1: instanceof #374 // class com.example.addon.util.macro.SendPacketAction
          07c4: ifeq 2044
          07c7: aload_2
          07c8: ifnull 2030
          07cb: aload_2
          07cc: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          07cf: ifeq 2030
          07d2: aload_1
          07d3: aload_0
          07d4: invokeinterface #1127 count=2 // com.example.addon.util.macro.MacroAction.execute(Lnet.minecraft.class_310;)V
          07d9: goto 3371
          07dc: astore 10
          07de: aload 10
          07e0: invokevirtual #1130 // java.lang.Exception.getMessage()Ljava.lang.String;
          07e3: invokedynamic #1735 // invokedynamic(bsm=77) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          07e8: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          07eb: goto 3371
          07ee: aload_0
          07ef: aload_1
          07f0: aload_0
          07f1: invokedynamic #1740 // invokedynamic(bsm=78) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          07f6: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          07f9: goto 3371
          07fc: aload_1
          07fd: instanceof #1173 // class com.example.addon.util.macro.ClickAction
          0800: ifeq 2171
          0803: aload_1
          0804: checkcast #1173 // class com.example.addon.util.macro.ClickAction
          0807: astore 10
          0809: iconst_1
          080a: aload 10
          080c: getfield #1176 // com.example.addon.util.macro.ClickAction.clickCount:I
          080f: invokestatic #710 // java.lang.Math.max(II)I
          0812: istore 11
          0814: iconst_0
          0815: istore 12
          0817: iload 12
          0819: iload 11
          081b: if_icmpge 2168
          081e: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0821: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0824: ifeq 2168
          0827: new #1049 // class java.util.concurrent.CountDownLatch
          082a: dup
          082b: iconst_1
          082c: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          082f: astore 13
          0831: aload_0
          0832: aload 10
          0834: aload_0
          0835: aload 13
          0837: invokedynamic #1745 // invokedynamic(bsm=79) run(Lcom.example.addon.util.macro.ClickAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          083c: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          083f: aload 13
          0841: ldc2_w #1061 // 200
          0844: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0847: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          084a: pop
          084b: goto 2134
          084e: astore 14
          0850: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0853: invokevirtual #1117 // java.lang.Thread.interrupt()V
          0856: iload 12
          0858: iload 11
          085a: iconst_1
          085b: isub
          085c: if_icmpge 2162
          085f: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0862: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0865: ifeq 2162
          0868: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          086b: astore 14
          086d: aload 14
          086f: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0872: iinc 12 1
          0875: goto 2071
          0878: goto 3371
          087b: aload_1
          087c: instanceof #1186 // class com.example.addon.util.macro.PayAction
          087f: ifeq 2189
          0882: aload_0
          0883: aload_1
          0884: checkcast #1186 // class com.example.addon.util.macro.PayAction
          0887: invokestatic #1190 // com.example.addon.util.macro.MacroExecutor.runPayAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.PayAction;)V
          088a: goto 3371
          088d: aload_1
          088e: instanceof #45 // class com.example.addon.util.macro.XCarryAction
          0891: ifeq 2319
          0894: aload_1
          0895: checkcast #45 // class com.example.addon.util.macro.XCarryAction
          0898: astore 5
          089a: aload 5
          089c: getfield #1193 // com.example.addon.util.macro.XCarryAction.mode:Lcom.example.addon.util.macro.XCarryAction$Mode;
          089f: getstatic #1196 // com.example.addon.util.macro.XCarryAction$Mode.PUT_IN:Lcom.example.addon.util.macro.XCarryAction$Mode;
          08a2: if_acmpne 2239
          08a5: aload 5
          08a7: getfield #1200 // com.example.addon.util.macro.XCarryAction.transferMode:Lcom.example.addon.util.macro.XCarryAction$TransferMode;
          08aa: getstatic #1203 // com.example.addon.util.macro.XCarryAction$TransferMode.CLICK:Lcom.example.addon.util.macro.XCarryAction$TransferMode;
          08ad: if_acmpne 2239
          08b0: ldc_w #1205 // "XCarry Click"
          08b3: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          08b6: aload_0
          08b7: aload 5
          08b9: invokestatic #1209 // com.example.addon.util.macro.MacroExecutor.runXCarryClickPutIn(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.XCarryAction;)V
          08bc: goto 3371
          08bf: getstatic #1213 // com.example.addon.util.macro.MacroExecutor$1.$SwitchMap$com$example$addon$util$macro$XCarryAction$Mode:[I
          08c2: aload 5
          08c4: getfield #1193 // com.example.addon.util.macro.XCarryAction.mode:Lcom.example.addon.util.macro.XCarryAction$Mode;
          08c7: invokevirtual #1216 // com.example.addon.util.macro.XCarryAction$Mode.ordinal()I
          08ca: iaload
          08cb: tableswitch low=1 high=3 default=2276 1:2286 2:2292 3:2298
          08e4: new #1218 // class java.lang.MatchException
          08e7: dup
          08e8: aconst_null
          08e9: aconst_null
          08ea: invokespecial #1221 // java.lang.MatchException.<init>(Ljava.lang.String;Ljava.lang.Throwable;)V
          08ed: athrow
          08ee: ldc_w #1223 // "XCarry"
          08f1: goto 2301
          08f4: ldc_w #1225 // "XCarry Out"
          08f7: goto 2301
          08fa: ldc_w #1227 // "XCarry Drop"
          08fd: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0900: aload_0
          0901: aload 5
          0903: aload_0
          0904: invokedynamic #1750 // invokedynamic(bsm=80) run(Lcom.example.addon.util.macro.XCarryAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0909: invokestatic #1239 // com.example.addon.util.macro.MacroExecutor.runOnClientThread(Lnet.minecraft.class_310;Ljava.lang.Runnable;)V
          090c: goto 3371
          090f: aload_1
          0910: instanceof #65 // class com.example.addon.util.macro.CraftAction
          0913: ifeq 2337
          0916: aload_0
          0917: aload_1
          0918: checkcast #65 // class com.example.addon.util.macro.CraftAction
          091b: invokestatic #1126 // com.example.addon.util.macro.MacroExecutor.runCraftAction(Lnet.minecraft.class_310;Lcom.example.addon.util.macro.CraftAction;)V
          091e: goto 3371
          0921: aload_1
          0922: instanceof #40 // class com.example.addon.util.macro.StoreItemAction
          0925: ifeq 2525
          0928: aload_1
          0929: checkcast #40 // class com.example.addon.util.macro.StoreItemAction
          092c: astore 10
          092e: aload 10
          0930: getfield #1141 // com.example.addon.util.macro.StoreItemAction.mode:Lcom.example.addon.util.macro.StoreItemAction$Mode;
          0933: getstatic #1144 // com.example.addon.util.macro.StoreItemAction$Mode.LOOT:Lcom.example.addon.util.macro.StoreItemAction$Mode;
          0936: if_acmpne 2367
          0939: ldc_w #1146 // "Looting"
          093c: goto 2370
          093f: ldc_w #1148 // "Storing"
          0942: aload 10
          0944: getfield #1149 // com.example.addon.util.macro.StoreItemAction.persistent:Z
          0947: ifeq 2384
          094a: ldc_w #1151 // " ∞"
          094d: goto 2387
          0950: ldc_w #310 // ""
          0953: invokedynamic #1156 // invokedynamic(bsm=45) makeConcatWithConstants(Ljava.lang.String;Ljava.lang.String;)Ljava.lang.String;
          0958: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          095b: aload 10
          095d: getfield #1149 // com.example.addon.util.macro.StoreItemAction.persistent:Z
          0960: ifeq 2475
          0963: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0966: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0969: ifeq 2522
          096c: new #1049 // class java.util.concurrent.CountDownLatch
          096f: dup
          0970: iconst_1
          0971: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0974: astore 11
          0976: aload_0
          0977: aload 10
          0979: aload_0
          097a: aload 11
          097c: invokedynamic #1755 // invokedynamic(bsm=81) run(Lcom.example.addon.util.macro.StoreItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0981: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0984: aload 11
          0986: ldc2_w #1165 // 2000
          0989: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          098c: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          098f: pop
          0990: goto 2462
          0993: astore 12
          0995: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0998: invokevirtual #1117 // java.lang.Thread.interrupt()V
          099b: goto 2522
          099e: invokestatic #397 // com.example.addon.util.macro.MacroConditionRegistry.waitForNextTick()Ljava.util.concurrent.CompletableFuture;
          09a1: astore 12
          09a3: aload 12
          09a5: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          09a8: goto 2403
          09ab: new #1049 // class java.util.concurrent.CountDownLatch
          09ae: dup
          09af: iconst_1
          09b0: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          09b3: astore 11
          09b5: aload_0
          09b6: aload 10
          09b8: aload_0
          09b9: aload 11
          09bb: invokedynamic #1760 // invokedynamic(bsm=82) run(Lcom.example.addon.util.macro.StoreItemAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          09c0: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          09c3: aload 11
          09c5: ldc2_w #1165 // 2000
          09c8: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          09cb: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          09ce: pop
          09cf: goto 2522
          09d2: astore 12
          09d4: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          09d7: invokevirtual #1117 // java.lang.Thread.interrupt()V
          09da: goto 3371
          09dd: aload_1
          09de: instanceof #52 // class com.example.addon.util.macro.InventoryAuditAction
          09e1: ifeq 2622
          09e4: aload_1
          09e5: checkcast #52 // class com.example.addon.util.macro.InventoryAuditAction
          09e8: astore 6
          09ea: aload 6
          09ec: getfield #1242 // com.example.addon.util.macro.InventoryAuditAction.mode:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          09ef: getstatic #1245 // com.example.addon.util.macro.InventoryAuditAction$Mode.DUPE:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          09f2: if_acmpeq 2560
          09f5: aload 6
          09f7: getfield #1242 // com.example.addon.util.macro.InventoryAuditAction.mode:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          09fa: getstatic #1248 // com.example.addon.util.macro.InventoryAuditAction$Mode.DUPE_SPAM:Lcom.example.addon.util.macro.InventoryAuditAction$Mode;
          09fd: if_acmpne 2622
          0a00: aload 6
          0a02: getfield #1252 // com.example.addon.util.macro.InventoryAuditAction.dupeVector:Lcom.example.addon.util.macro.InventoryAuditAction$DupeVector;
          0a05: invokevirtual #1253 // com.example.addon.util.macro.InventoryAuditAction$DupeVector.name()Ljava.lang.String;
          0a08: aload 6
          0a0a: getfield #1257 // com.example.addon.util.macro.InventoryAuditAction.openMode:Lcom.example.addon.util.macro.InventoryAuditAction$OpenMode;
          0a0d: invokevirtual #1258 // com.example.addon.util.macro.InventoryAuditAction$OpenMode.name()Ljava.lang.String;
          0a10: invokedynamic #1261 // invokedynamic(bsm=50) makeConcatWithConstants(Ljava.lang.String;Ljava.lang.String;)Ljava.lang.String;
          0a15: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0a18: aload 6
          0a1a: aload_0
          0a1b: invokevirtual #1264 // com.example.addon.util.macro.InventoryAuditAction.executeDupe(Lnet.minecraft.class_310;)V
          0a1e: goto 3371
          0a21: astore 10
          0a23: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0a26: invokevirtual #1117 // java.lang.Thread.interrupt()V
          0a29: goto 3371
          0a2c: astore 10
          0a2e: aload 10
          0a30: invokevirtual #1130 // java.lang.Exception.getMessage()Ljava.lang.String;
          0a33: invokedynamic #1763 // invokedynamic(bsm=83) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0a38: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0a3b: goto 3371
          0a3e: aload_1
          0a3f: instanceof #866 // class com.example.addon.util.macro.TickSyncAction
          0a42: ifeq 2751
          0a45: aload_1
          0a46: checkcast #866 // class com.example.addon.util.macro.TickSyncAction
          0a49: astore 7
          0a4b: aload_0
          0a4c: getfield #870 // net.minecraft.class_310.field_1687:Lnet.minecraft.class_638;
          0a4f: ifnonnull 2643
          0a52: return
          0a53: aload 7
          0a55: getfield #873 // com.example.addon.util.macro.TickSyncAction.preGenCount:I
          0a58: aload_0
          0a59: invokestatic #1767 // com.example.addon.util.macro.MacroExecutor.preGeneratePacketsForRepeat(ILnet.minecraft.class_310;)Ljava.util.List;
          0a5c: astore 10
          0a5e: aload_0
          0a5f: getfield #870 // net.minecraft.class_310.field_1687:Lnet.minecraft.class_638;
          0a62: invokevirtual #883 // net.minecraft.class_638.method_75260()J
          0a65: aload 7
          0a67: getfield #886 // com.example.addon.util.macro.TickSyncAction.tickOffset:I
          0a6a: i2l
          0a6b: ladd
          0a6c: lstore 11
          0a6e: lload 11
          0a70: aload 10
          0a72: invokeinterface #229 count=1 // java.util.List.size()I
          0a77: invokedynamic #891 // invokedynamic(bsm=29) makeConcatWithConstants(JI)Ljava.lang.String;
          0a7c: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0a7f: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0a82: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0a85: ifeq 2718
          0a88: aload_0
          0a89: getfield #870 // net.minecraft.class_310.field_1687:Lnet.minecraft.class_638;
          0a8c: invokevirtual #883 // net.minecraft.class_638.method_75260()J
          0a8f: lload 11
          0a91: lcmp
          0a92: ifge 2718
          0a95: ldc2_w #892 // 1000000
          0a98: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0a9b: goto 2687
          0a9e: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0aa1: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0aa4: ifeq 2748
          0aa7: aload_0
          0aa8: aload 10
          0aaa: invokestatic #901 // com.example.addon.util.macro.MacroExecutor.executePreGeneratedBurst(Lnet.minecraft.class_310;Ljava.util.List;)V
          0aad: aload 10
          0aaf: invokeinterface #229 count=1 // java.util.List.size()I
          0ab4: invokedynamic #908 // invokedynamic(bsm=30) makeConcatWithConstants(I)Ljava.lang.String;
          0ab9: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0abc: goto 3371
          0abf: aload_1
          0ac0: instanceof #910 // class com.example.addon.util.macro.RevisionSyncAction
          0ac3: ifeq 2938
          0ac6: aload_1
          0ac7: checkcast #910 // class com.example.addon.util.macro.RevisionSyncAction
          0aca: astore 8
          0acc: aload_0
          0acd: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0ad0: ifnull 2781
          0ad3: aload_0
          0ad4: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0ad7: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0ada: ifnonnull 2782
          0add: return
          0ade: aload 8
          0ae0: getfield #921 // com.example.addon.util.macro.RevisionSyncAction.preGenCount:I
          0ae3: aload_0
          0ae4: invokestatic #1767 // com.example.addon.util.macro.MacroExecutor.preGeneratePacketsForRepeat(ILnet.minecraft.class_310;)Ljava.util.List;
          0ae7: astore 10
          0ae9: aload_0
          0aea: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0aed: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0af0: invokevirtual #926 // net.minecraft.class_1703.method_37421()I
          0af3: istore 11
          0af5: iload 11
          0af7: aload 8
          0af9: getfield #929 // com.example.addon.util.macro.RevisionSyncAction.revisionOffset:I
          0afc: iadd
          0afd: istore 12
          0aff: iload 12
          0b01: aload 10
          0b03: invokeinterface #229 count=1 // java.util.List.size()I
          0b08: invokedynamic #932 // invokedynamic(bsm=31) makeConcatWithConstants(II)Ljava.lang.String;
          0b0d: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0b10: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0b13: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0b16: ifeq 2888
          0b19: aload_0
          0b1a: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b1d: ifnull 2888
          0b20: aload_0
          0b21: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b24: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0b27: ifnonnull 2861
          0b2a: goto 2888
          0b2d: aload_0
          0b2e: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b31: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0b34: invokevirtual #926 // net.minecraft.class_1703.method_37421()I
          0b37: iload 12
          0b39: if_icmplt 2879
          0b3c: goto 2888
          0b3f: ldc2_w #933 // 500000
          0b42: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0b45: goto 2832
          0b48: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0b4b: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0b4e: ifeq 2935
          0b51: aload_0
          0b52: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b55: ifnull 2935
          0b58: aload_0
          0b59: getfield #914 // net.minecraft.class_310.field_1724:Lnet.minecraft.class_746;
          0b5c: getfield #920 // net.minecraft.class_746.field_7512:Lnet.minecraft.class_1703;
          0b5f: ifnull 2935
          0b62: aload_0
          0b63: aload 10
          0b65: invokestatic #901 // com.example.addon.util.macro.MacroExecutor.executePreGeneratedBurst(Lnet.minecraft.class_310;Ljava.util.List;)V
          0b68: aload 10
          0b6a: invokeinterface #229 count=1 // java.util.List.size()I
          0b6f: invokedynamic #937 // invokedynamic(bsm=32) makeConcatWithConstants(I)Ljava.lang.String;
          0b74: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0b77: goto 3371
          0b7a: aload_1
          0b7b: instanceof #939 // class com.example.addon.util.macro.ServerTickSyncAction
          0b7e: ifeq 3283
          0b81: aload_1
          0b82: checkcast #939 // class com.example.addon.util.macro.ServerTickSyncAction
          0b85: astore 9
          0b87: aload_0
          0b88: invokevirtual #943 // net.minecraft.class_310.method_1562()Lnet.minecraft.class_634;
          0b8b: ifnonnull 2959
          0b8e: return
          0b8f: aload 9
          0b91: getfield #944 // com.example.addon.util.macro.ServerTickSyncAction.preGenCount:I
          0b94: aload_0
          0b95: invokestatic #1767 // com.example.addon.util.macro.MacroExecutor.preGeneratePacketsForRepeat(ILnet.minecraft.class_310;)Ljava.util.List;
          0b98: astore 10
          0b9a: iconst_0
          0b9b: istore 11
          0b9d: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0ba0: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0ba3: ifeq 3058
          0ba6: invokestatic #949 // com.example.addon.util.macro.ServerTickTracker.isReady()Z
          0ba9: ifne 3058
          0bac: iload 11
          0bae: aload 9
          0bb0: getfield #952 // com.example.addon.util.macro.ServerTickSyncAction.maxWaitMs:I
          0bb3: if_icmpge 3058
          0bb6: invokestatic #955 // com.example.addon.util.macro.ServerTickTracker.getWarmupProgress()F
          0bb9: fstore 12
          0bbb: ldc_w #957 // "ServerSync warmup %.0f%% (%d samples, %dms)"
          0bbe: iconst_3
          0bbf: anewarray #4 // class java.lang.Object
          0bc2: dup
          0bc3: iconst_0
          0bc4: fload 12
          0bc6: ldc_w #958 // 100
          0bc9: fmul
          0bca: invokestatic #963 // java.lang.Float.valueOf(F)Ljava.lang.Float;
          0bcd: aastore
          0bce: dup
          0bcf: iconst_1
          0bd0: invokestatic #966 // com.example.addon.util.macro.ServerTickTracker.getSampleCount()I
          0bd3: invokestatic #971 // java.lang.Integer.valueOf(I)Ljava.lang.Integer;
          0bd6: aastore
          0bd7: dup
          0bd8: iconst_2
          0bd9: invokestatic #974 // com.example.addon.util.macro.ServerTickTracker.getTrackingTimeMs()J
          0bdc: invokestatic #979 // java.lang.Long.valueOf(J)Ljava.lang.Long;
          0bdf: aastore
          0be0: invokestatic #530 // java.lang.String.format(Ljava.lang.String;[Ljava.lang.Object;)Ljava.lang.String;
          0be3: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0be6: ldc2_w #712 // 50
          0be9: invokestatic #408 // java.lang.Thread.sleep(J)V
          0bec: iinc 11 50
          0bef: goto 2973
          0bf2: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0bf5: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0bf8: ifne 3068
          0bfb: return
          0bfc: aload 9
          0bfe: getfield #982 // com.example.addon.util.macro.ServerTickSyncAction.bufferMs:I
          0c01: aload 9
          0c03: getfield #985 // com.example.addon.util.macro.ServerTickSyncAction.ignorePing:Z
          0c06: invokestatic #989 // com.example.addon.util.macro.ServerTickTracker.getOptimalSendTime(IZ)J
          0c09: lstore 12
          0c0b: lload 12
          0c0d: invokestatic #994 // java.lang.System.nanoTime()J
          0c10: lsub
          0c11: ldc2_w #892 // 1000000
          0c14: ldiv
          0c15: lstore 14
          0c17: invokestatic #997 // com.example.addon.util.macro.ServerTickTracker.getPingMs()I
          0c1a: istore 16
          0c1c: aload 9
          0c1e: getfield #985 // com.example.addon.util.macro.ServerTickSyncAction.ignorePing:Z
          0c21: ifeq 3114
          0c24: ldc_w #999 // " (no ping)"
          0c27: goto 3121
          0c2a: iload 16
          0c2c: invokedynamic #1002 // invokedynamic(bsm=33) makeConcatWithConstants(I)Ljava.lang.String;
          0c31: astore 17
          0c33: lconst_0
          0c34: lload 14
          0c36: invokestatic #1005 // java.lang.Math.max(JJ)J
          0c39: aload 17
          0c3b: aload 10
          0c3d: invokeinterface #229 count=1 // java.util.List.size()I
          0c42: invokedynamic #1010 // invokedynamic(bsm=34) makeConcatWithConstants(JLjava.lang.String;I)Ljava.lang.String;
          0c47: putstatic #324 // com.example.addon.util.macro.MacroExecutor.currentStatus:Ljava.lang.String;
          0c4a: invokestatic #994 // java.lang.System.nanoTime()J
          0c4d: lstore 18
          0c4f: aload 9
          0c51: getfield #952 // com.example.addon.util.macro.ServerTickSyncAction.maxWaitMs:I
          0c54: i2l
          0c55: ldc2_w #892 // 1000000
          0c58: lmul
          0c59: lstore 20
          0c5b: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0c5e: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0c61: ifeq 3236
          0c64: invokestatic #994 // java.lang.System.nanoTime()J
          0c67: lstore 22
          0c69: lload 22
          0c6b: lload 18
          0c6d: lsub
          0c6e: lload 20
          0c70: lcmp
          0c71: iflt 3191
          0c74: goto 3236
          0c77: lload 22
          0c79: lload 12
          0c7b: lcmp
          0c7c: iflt 3202
          0c7f: goto 3236
          0c82: lload 12
          0c84: lload 22
          0c86: lsub
          0c87: lstore 24
          0c89: lload 24
          0c8b: ldc2_w #1011 // 2000000
          0c8e: lcmp
          0c8f: ifle 3230
          0c92: lload 24
          0c94: ldc2_w #1011 // 2000000
          0c97: lsub
          0c98: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0c9b: goto 3233
          0c9e: invokestatic #1015 // java.lang.Thread.onSpinWait()V
          0ca1: goto 3163
          0ca4: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0ca7: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0caa: ifeq 3280
          0cad: aload_0
          0cae: aload 10
          0cb0: invokestatic #901 // com.example.addon.util.macro.MacroExecutor.executePreGeneratedBurst(Lnet.minecraft.class_310;Ljava.util.List;)V
          0cb3: invokestatic #994 // java.lang.System.nanoTime()J
          0cb6: lload 12
          0cb8: lsub
          0cb9: ldc2_w #892 // 1000000
          0cbc: ldiv
          0cbd: lstore 22
          0cbf: aload 10
          0cc1: invokeinterface #229 count=1 // java.util.List.size()I
          0cc6: lload 22
          0cc8: invokedynamic #1020 // invokedynamic(bsm=35) makeConcatWithConstants(IJ)Ljava.lang.String;
          0ccd: invokestatic #182 // com.example.addon.util.PackUtilClientMessaging.sendPrefixed(Ljava.lang.String;)V
          0cd0: goto 3371
          0cd3: aload_1
          0cd4: instanceof #862 // class com.example.addon.util.macro.StopMacroAction
          0cd7: ifeq 3300
          0cda: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0cdd: iconst_0
          0cde: invokevirtual #201 // java.util.concurrent.atomic.AtomicBoolean.set(Z)V
          0ce1: goto 3371
          0ce4: aload_2
          0ce5: ifnull 3360
          0ce8: aload_2
          0ce9: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          0cec: ifeq 3360
          0cef: new #1049 // class java.util.concurrent.CountDownLatch
          0cf2: dup
          0cf3: iconst_1
          0cf4: invokespecial #1052 // java.util.concurrent.CountDownLatch.<init>(I)V
          0cf7: astore 10
          0cf9: aload_0
          0cfa: aload_1
          0cfb: aload_0
          0cfc: aload 10
          0cfe: invokedynamic #1772 // invokedynamic(bsm=84) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;Ljava.util.concurrent.CountDownLatch;)Ljava.lang.Runnable;
          0d03: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0d06: aload 10
          0d08: ldc2_w #1109 // 100
          0d0b: getstatic #1068 // java.util.concurrent.TimeUnit.MILLISECONDS:Ljava.util.concurrent.TimeUnit;
          0d0e: invokevirtual #1072 // java.util.concurrent.CountDownLatch.await(JLjava.util.concurrent.TimeUnit;)Z
          0d11: pop
          0d12: goto 3357
          0d15: astore 11
          0d17: invokestatic #1114 // java.lang.Thread.currentThread()Ljava.lang.Thread;
          0d1a: invokevirtual #1117 // java.lang.Thread.interrupt()V
          0d1d: goto 3371
          0d20: aload_0
          0d21: aload_1
          0d22: aload_0
          0d23: invokedynamic #1777 // invokedynamic(bsm=85) run(Lcom.example.addon.util.macro.MacroAction;Lnet.minecraft.class_310;)Ljava.lang.Runnable;
          0d28: invokevirtual #565 // net.minecraft.class_310.execute(Ljava.lang.Runnable;)V
          0d2b: aload_3
          0d2c: ifnull 3393
          0d2f: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0d32: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0d35: ifeq 3393
          0d38: aload_3
          0d39: invokestatic #401 // com.example.addon.util.macro.MacroExecutor.waitForCondition(Ljava.util.concurrent.CompletableFuture;)V
          0d3c: goto 3393
          0d3f: astore 4
          0d41: getstatic #168 // com.example.addon.util.macro.MacroExecutor.isRunning:Ljava.util.concurrent.atomic.AtomicBoolean;
          0d44: invokevirtual #174 // java.util.concurrent.atomic.AtomicBoolean.get()Z
          0d47: ifeq 3440
          0d4a: aload_2
          0d4b: ifnull 3440
          0d4e: aload_2
          0d4f: invokevirtual #1100 // com.example.addon.modules.PackUtilModule.useInstantExecutionMode()Z
          0d52: ifeq 3440
          0d55: aload_2
          0d56: invokevirtual #1280 // com.example.addon.modules.PackUtilModule.getActionDelayUs()I
          0d59: istore 4
          0d5b: iload 4
          0d5d: ifle 3437
          0d60: iload 4
          0d62: i2l
          0d63: ldc2_w #1281 // 1000
          0d66: lmul
          0d67: invokestatic #898 // java.util.concurrent.locks.LockSupport.parkNanos(J)V
          0d6a: goto 3440
          0d6d: invokestatic #1015 // java.lang.Thread.onSpinWait()V
          0d70: return
        */
    }

    private static List<class_2596<?>> preGeneratePacketsForRepeat(int count, class_310 mc) {
        List<class_2596<?>> packets = new ArrayList();
        return packets;
    }

    private static void runXCarryClickPutIn(class_310 mc, XCarryAction xsa) throws InterruptedException {
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        AtomicReference<class_1703> containerHandlerRef = new AtomicReference();
        AtomicReference<PackUtilContainerTarget> containerTargetRef = new AtomicReference();
        AtomicReference<List<Integer>> containerSlotIdsRef = new AtomicReference(List.of());
        AtomicBoolean usingContainer = new AtomicBoolean(false);
        MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$60 /* captured: mc, usingContainer, containerHandlerRef, containerTargetRef, containerSlotIdsRef, xsa */);
        PackUtilClientMessaging.sendPrefixed("XCarry click mode: missing container target, using fast mode.");
        if (usingContainer.get() && containerTargetRef.get() == null) {
            MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$61 /* captured: xsa, mc */);
            return;
        }
        if (!usingContainer.get()) { /* goto L217; */ }
        PutInMove move = ((List)containerSlotIdsRef.get()).iterator();
        while (move.hasNext()) {
            int slotId = ((Integer)move.next()).intValue();
            if (isRunning.get()) continue;
            return;
            currentStatus = "XCarry Click: collect";
            MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$62 /* captured: mc, containerHandlerRef, slotId */);
            MacroExecutor.waitOneTick();
        }
        MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$63 /* captured: mc, containerHandlerRef */);
        MacroExecutor.waitOneTick();
        MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$64 /* captured: mc */);
        MacroExecutor.waitOneTick();
        while (isRunning.get()) {
            move = (XCarryAction.PutInMove)MacroExecutor.callOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$65 /* captured: mc, xsa */, null);
            if (move == null) {
            } else {
                currentStatus = "XCarry Click -> " + move.targetSlotId;
                MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$66 /* captured: mc, move */);
                pickedUp = MacroExecutor.waitForXCarryCondition(mc, 400L, MacroExecutor::lambda$runXCarryClickPutIn$67 /* captured: mc, move */);
                if (!pickedUp) {
                    MacroExecutor.rollbackXCarryCursor(mc, move.sourceSlotId);
                } else {
                    MacroExecutor.waitOneTick();
                    MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$68 /* captured: mc, move */);
                    boolean placed = MacroExecutor.waitForXCarryCondition(mc, 500L, MacroExecutor::lambda$runXCarryClickPutIn$69 /* captured: mc, move */);
                    if (!placed) {
                        MacroExecutor.rollbackXCarryCursor(mc, move.sourceSlotId);
                    } else {
                        MacroExecutor.waitOneTick();
                    }
                }
            }
        }
        MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$70 /* captured: mc */);
        if (usingContainer.get()) {
            MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$runXCarryClickPutIn$71 /* captured: mc, containerHandlerRef, containerTargetRef */);
            MacroExecutor.waitOneTick();
        }
    }

    private static void rollbackXCarryCursor(class_310 mc, int sourceSlotId) throws InterruptedException {
        MacroExecutor.runOnClientThread(mc, MacroExecutor::lambda$rollbackXCarryCursor$72 /* captured: mc, sourceSlotId */);
        MacroExecutor.waitForXCarryCondition(mc, 300L, MacroExecutor::lambda$rollbackXCarryCursor$73 /* captured: mc */);
    }

    private static boolean waitForXCarryCondition(class_310 mc, long timeoutMs, Supplier<Boolean> condition) throws InterruptedException {
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs);
        while (isRunning.get()) {
            if (!Boolean.TRUE.equals(MacroExecutor.callOnClientThread(mc, condition, Boolean.FALSE))) continue;
            return true;
            if (System.nanoTime() >= deadline) {
            } else {
                MacroExecutor.waitOneTick();
            }
        }
        return Boolean.TRUE.equals(MacroExecutor.callOnClientThread(mc, condition, Boolean.FALSE));
    }

    private static void waitOneTick() {
        CompletableFuture<Void> tickFuture = MacroConditionRegistry.waitForNextTick();
        MacroExecutor.waitForCondition(tickFuture);
    }

    private static void runOnClientThread(class_310 mc, Runnable runnable) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(MacroExecutor::lambda$runOnClientThread$74 /* captured: runnable, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
    }

    private static <T> T callOnClientThread(class_310 mc, Supplier<T> supplier, T fallback) throws InterruptedException {
        AtomicReference<T> result = new AtomicReference(fallback);
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(MacroExecutor::lambda$callOnClientThread$75 /* captured: result, supplier, latch */);
        latch.await(2000L, TimeUnit.MILLISECONDS);
        return result.get();
    }

    private static void waitForItemInSpecificHandlerSlot(class_310 mc, int slotId, ItemTarget target) throws InterruptedException {
        while (isRunning.get()) {
            AtomicBoolean matched = new AtomicBoolean(false);
            CountDownLatch latch = new CountDownLatch(1);
            mc.execute(MacroExecutor::lambda$waitForItemInSpecificHandlerSlot$76 /* captured: matched, mc, slotId, target, latch */);
            latch.await(200L, TimeUnit.MILLISECONDS);
            if (!matched.get()) continue;
            return;
            CompletableFuture<Void> tickFuture = MacroConditionRegistry.waitForNextTick();
            MacroExecutor.waitForCondition(tickFuture);
        }
    }

    private static void waitForAnyItemInSpecificHandlerSlot(class_310 mc, int slotId) throws InterruptedException {
        while (isRunning.get()) {
            AtomicBoolean matched = new AtomicBoolean(false);
            CountDownLatch latch = new CountDownLatch(1);
            mc.execute(MacroExecutor::lambda$waitForAnyItemInSpecificHandlerSlot$77 /* captured: matched, mc, slotId, latch */);
            latch.await(200L, TimeUnit.MILLISECONDS);
            if (!matched.get()) continue;
            return;
            CompletableFuture<Void> tickFuture = MacroConditionRegistry.waitForNextTick();
            MacroExecutor.waitForCondition(tickFuture);
        }
    }

    private static boolean handlerSlotMatchesItem(class_310 mc, int slotId, ItemTarget target) {
        if (mc.field_1724 == null || mc.field_1724.field_7512 == null) {
            return false;
        }
        int handlerSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, slotId);
        if (handlerSlot < 0 || handlerSlot >= mc.field_1724.field_7512.field_7761.size()) {
            return false;
        }
        class_1735 slot = (class_1735)mc.field_1724.field_7512.field_7761.get(handlerSlot);
        if (slot == null || slot.method_7677().method_7960()) {
            return false;
        }
        ItemTarget resolvedTarget = target == null ? ItemTarget.slotOnly(slotId) : target.copy();
        if (!resolvedTarget.hasSlot()) {
            resolvedTarget.slot = slotId;
        }
        return resolvedTarget.matches(slot.method_7677(), slotId);
    }

    private static boolean handlerSlotHasAnyItem(class_310 mc, int slotId) {
        if (mc.field_1724 == null || mc.field_1724.field_7512 == null) {
            return false;
        }
        int handlerSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, slotId);
        if (handlerSlot < 0 || handlerSlot >= mc.field_1724.field_7512.field_7761.size()) {
            return false;
        }
        class_1735 slot = (class_1735)mc.field_1724.field_7512.field_7761.get(handlerSlot);
        return slot != null && !slot.method_7677().method_7960();
    }

    private static void waitForItemActionTargets(class_310 mc, ItemAction ia) throws InterruptedException {
        if (ia == null) {
            return;
        }
        List<ItemTarget> targets = MacroExecutor.resolveItemTargets(ia.itemTargets, ia.itemNames);
        if (targets.isEmpty()) { /* goto L63; */ }
        var var3 = targets.iterator();
        while (var3.hasNext()) {
            ItemTarget target = (ItemTarget)var3.next();
            MacroExecutor.waitForItemActionEntry(mc, target);
        }
        return;
        L63: ;
        currentStatus = "Waiting for slot " + ia.targetSlot;
        if (ia.useSlot && ia.targetSlot >= 0) {
            MacroExecutor.waitForAnyItemInSpecificHandlerSlot(mc, ia.targetSlot);
        }
    }

    private static void waitForItemActionEntry(class_310 mc, ItemTarget target) throws InterruptedException {
        ItemTarget resolvedTarget = target == null ? new ItemTarget() : target.copy();
        String itemLabel = MacroExecutor.describeItemTarget(resolvedTarget);
        int slot = resolvedTarget.hasSlot() ? resolvedTarget.slot : -1;
        currentStatus = "Waiting for " + itemLabel;
        if (slot >= 0 && resolvedTarget.hasIdentity()) {
            MacroExecutor.waitForItemInSpecificHandlerSlot(mc, slot, resolvedTarget);
            return;
        }
        if (slot >= 0) {
            currentStatus = "Waiting for slot " + slot;
            MacroExecutor.waitForAnyItemInSpecificHandlerSlot(mc, slot);
            return;
        }
        if (resolvedTarget.hasIdentity()) {
            currentStatus = "Waiting for item in GUI: " + itemLabel;
            CompletableFuture<Void> waitFuture = MacroConditionRegistry.waitForItemInHandler(resolvedTarget);
            MacroExecutor.waitForCondition(waitFuture);
        }
    }

    private static ItemTarget resolveItemTarget(ItemTarget target, String legacyEntry) {
        if (target != null) {
            if (target.hasSlot() || target.hasIdentity()) {
                return target.copy();
            }
        }
        return ItemTarget.fromLegacyEntry(legacyEntry);
    }

    private static List<ItemTarget> resolveItemTargets(List<ItemTarget> targets, List<String> legacyEntries) {
        List<ItemTarget> resolved = new ArrayList();
        if (targets == null) { /* goto L78; */ }
        var var3 = targets.iterator();
        while (var3.hasNext()) {
            ItemTarget target = (ItemTarget)var3.next();
            if (target == null) continue;
            while (!target.hasSlot()) {
                if (target.hasIdentity()) break;
            }
            resolved.add(target.copy());
        }
        if (!resolved.isEmpty()) {
            return resolved;
        }
        if (legacyEntries == null) {
            return resolved;
        }
        var3 = legacyEntries.iterator();
        while (var3.hasNext()) {
            entry = (String)var3.next();
            ItemTarget parsed = ItemTarget.fromLegacyEntry(entry);
            if (!parsed.hasSlot() || parsed.hasIdentity()) continue;
            resolved.add(parsed);
        }
        return resolved;
    }

    private static String describeItemTarget(ItemTarget target) {
        if (target == null) {
            return "";
        }
        String summary = target.summaryText();
        if (summary != null && !summary.isBlank()) {
            return summary;
        }
        String legacy = target.toLegacyEntry();
        return legacy == null ? "" : legacy;
    }

    private static void runCraftAction(class_310 mc, CraftAction craftAction) throws InterruptedException {
        if (craftAction == null || !craftAction.hasEntries()) {
            currentStatus = "Crafting";
            PackUtilClientMessaging.sendPrefixed("Â§cNo craft recipes selected.");
            return;
        }
        for (int index = 0; index < craftAction.entries.size(); index++) {
            CraftEntry entry = (CraftAction.CraftEntry)craftAction.entries.get(index);
            if (entry == null) { /* goto L306; */ }
            if (!entry.hasRecipe()) {
            } else {
                currentStatus = entry.useMaxAmount ? "Crafting " + entry.resultName + " [Max] (" + index + 1 + "/" + craftAction.entries.size() + ")" : "Crafting " + entry.resultName + " x" + Math.max(1, entry.amount) + " (" + index + 1 + "/" + craftAction.entries.size() + ")";
                CraftableRecipeOption option = PackUtilCraftingHelper.findCraftableRecipe(mc, entry.recipeKey);
                if (option == null) {
                    option = PackUtilCraftingHelper.findCraftableRecipe(mc, entry.recipeId);
                }
                if (option != null) { /* goto L202; */ }
                currentStatus = "Recipe not found";
                PackUtilClientMessaging.sendPrefixed("Â§cRecipe not found: " + entry.resultName == null || entry.resultName.isBlank() ? "unknown" : entry.resultName);
                return;
                int desiredAmount = PackUtilCraftingHelper.getEffectiveRequestedOutput(option, entry.amount, entry.useMaxAmount);
                if (desiredAmount <= 0) {
                    currentStatus = "No space or materials";
                    PackUtilClientMessaging.sendPrefixed("Â§cNo space or materials for " + entry.resultName + ".");
                    return;
                }
                CraftExecutionResult result = PackUtilCraftingHelper.executeCraftImmediately(mc, entry.recipeKey, entry.recipeId, desiredAmount);
                currentStatus = result.message;
                if (!result.success) {
                    PackUtilClientMessaging.sendPrefixed("Â§c" + result.message);
                    return;
                }
                if (isRunning.get()) {
                    CompletableFuture<Void> tickFuture = MacroConditionRegistry.waitForNextTick();
                    MacroExecutor.waitForCondition(tickFuture);
                }
            }
        }
    }

    private static void runGoToAction(class_310 mc, GoToAction goToAction) throws InterruptedException {
        currentStatus = String.format("Going to %.0f,%.0f,%.0f", goToAction.x, goToAction.y, goToAction.z);
        if (!PackUtilCompatManager.isBaritoneAvailable()) {
            PackUtilClientMessaging.sendPrefixed("Baritone not installed; skipping goto action.");
            return;
        }
        int goalX = (int)Math.floor(goToAction.x);
        int goalY = (int)Math.floor(goToAction.y);
        int goalZ = (int)Math.floor(goToAction.z);
        if (!MacroExecutor.runBaritoneStart(mc, MacroExecutor::lambda$runGoToAction$78 /* captured: mc, goalX, goalY, goalZ */)) {
            PackUtilClientMessaging.sendPrefixed("Failed to start Baritone goto.");
            return;
        }
        if (!goToAction.waitForArrival) {
            currentStatus = "Goto started";
            return;
        }
        long startMs = System.currentTimeMillis();
        boolean sawBaritoneActivity = false;
        while (isRunning.get()) {
            boolean goalActive = PackUtilCompatManager.isBaritoneGoalActive();
            boolean baritoneBusy = PackUtilCompatManager.isBaritoneBusy();
            if (!goalActive || baritoneBusy) continue;
            sawBaritoneActivity = true;
            currentStatus = "Goto finished";
            if (!sawBaritoneActivity && !goalActive && !baritoneBusy) continue;
            return;
            currentStatus = "Goto finished";
            if (sawBaritoneActivity && System.currentTimeMillis() - startMs >= 1500L && !goalActive && !baritoneBusy) continue;
            return;
            CompletableFuture<Void> tickFuture = MacroConditionRegistry.waitForNextTick();
            MacroExecutor.waitForCondition(tickFuture);
        }
    }

    private static void runMineAction(class_310 mc, MineAction mineAction) throws InterruptedException {
        String mineDesc = mineAction.targetBlocks.isEmpty() ? "none" : (String)mineAction.targetBlocks.get(0);
        currentStatus = "Mining: " + mineDesc;
        if (mineAction.targetBlocks.isEmpty()) {
            return;
        }
        if (!PackUtilCompatManager.isBaritoneAvailable()) {
            PackUtilClientMessaging.sendPrefixed("Baritone not installed; skipping mine action.");
            return;
        }
        List<String> blockNames = new ArrayList();
        int startItemCount = mineAction.targetBlocks.iterator();
        while (startItemCount.hasNext()) {
            String id = (String)startItemCount.next();
            if (id == null) continue;
            while (id.isBlank()) {
            }
            blockNames.add(id.startsWith("minecraft:") ? id.substring(10) : id);
        }
        if (blockNames.isEmpty()) {
            return;
        }
        startItemCount = mineAction.stopMinedCount ? MacroExecutor.countMineTargetItems(mc, mineAction) : 0;
        if (!MacroExecutor.runBaritoneStart(mc, MacroExecutor::lambda$runMineAction$79 /* captured: mc, blockNames */)) {
            PackUtilClientMessaging.sendPrefixed("Failed to start Baritone mine.");
            return;
        }
        mineStartMs = System.currentTimeMillis();
        boolean sawBaritoneActivity = false;
        while (isRunning.get()) {
            boolean mineActive = PackUtilCompatManager.isBaritoneMineActive();
            boolean baritoneBusy = PackUtilCompatManager.isBaritoneBusy();
            if (!mineActive || baritoneBusy) continue;
            sawBaritoneActivity = true;
            String stopReason = null;
            int minedDelta = 0;
            if (mineAction.stopMinedCount) {
                minedDelta = Math.max(0, MacroExecutor.countMineTargetItems(mc, mineAction) - startItemCount);
                currentStatus = "Mining: " + mineDesc + " (" + minedDelta + "/" + mineAction.minedCountTarget + ")";
                if (!minedDelta >= mineAction.minedCountTarget) continue;
                stopReason = "Mine target reached";
            }
            if (stopReason == null) {
                if (mineAction.stopInventoryFull) {
                    if (!MacroExecutor.isInventoryFull(mc)) continue;
                    stopReason = "Mine stop: inventory full";
                }
            }
            if (stopReason == null) {
                if (mineAction.stopSlotsUsed) {
                    int used = MacroExecutor.countUsedMainInventorySlots(mc);
                    if (!used >= mineAction.slotsUsedThreshold) continue;
                    stopReason = "Mine stop: slots used";
                }
            }
            if (stopReason == null) {
                if (mineAction.stopAfterTime) {
                    if (!System.currentTimeMillis() - mineStartMs >= (long)mineAction.timeoutSeconds * 1000L) continue;
                    stopReason = "Mine timeout";
                }
            }
            if (stopReason != null) {
                currentStatus = stopReason;
                MacroExecutor.requestBaritoneStop(mc);
                MacroExecutor.waitForBaritoneIdle();
                return;
            }
            currentStatus = "Mine finished";
            if (!sawBaritoneActivity && !mineActive && !baritoneBusy) continue;
            return;
            currentStatus = "Mine finished";
            if (sawBaritoneActivity && System.currentTimeMillis() - mineStartMs >= 1500L && !mineActive && !baritoneBusy) continue;
            return;
            tickFuture = MacroConditionRegistry.waitForNextTick();
            MacroExecutor.waitForCondition(tickFuture);
        }
    }

    private static boolean runBaritoneStart(class_310 mc, BooleanSupplier starter) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean started = new AtomicBoolean(false);
        mc.execute(MacroExecutor::lambda$runBaritoneStart$80 /* captured: started, starter, latch */);
        latch.await(2L, TimeUnit.SECONDS);
        return started.get();
    }

    private static void requestBaritoneStop(class_310 mc) {
        mc.execute(MacroExecutor::lambda$requestBaritoneStop$81 /* captured: mc */);
    }

    private static void waitForBaritoneIdle() {
        long waitStartMs = System.currentTimeMillis();
        while (isRunning.get()) {
            if (!PackUtilCompatManager.isBaritoneBusy()) break;
            if (System.currentTimeMillis() - waitStartMs >= 3000L) break;
            CompletableFuture<Void> tickFuture = MacroConditionRegistry.waitForNextTick();
            MacroExecutor.waitForCondition(tickFuture);
        }
    }

    private static boolean isInventoryFull(class_310 mc) {
        if (mc.field_1724 == null) {
            return false;
        }
        for (int slot = 9; slot < 36; slot++) {
            if (!mc.field_1724.method_31548().method_5438(slot).method_7960()) continue;
            return false;
        }
        return true;
    }

    private static int countUsedMainInventorySlots(class_310 mc) {
        if (mc.field_1724 == null) {
            return 0;
        }
        int used = 0;
        for (int slot = 9; slot < 36; slot++) {
            if (mc.field_1724.method_31548().method_5438(slot).method_7960()) continue;
            used++;
        }
        return used;
    }

    private static int countMineTargetItems(class_310 mc, MineAction mineAction) {
        if (mc.field_1724 == null) {
            return 0;
        }
        Set<class_1792> targetItems = new LinkedHashSet();
        int total = mineAction.targetBlocks.iterator();
        L27: ;
        if (!total.hasNext()) { /* goto @159; */ }
        String rawId = (String)total.next();
        if (rawId == null) { /* goto L27; */ }
        while (rawId.isBlank()) {
        }
        try {
            class_2960 id = class_2960.method_60654(rawId);
            if (class_7923.field_41178.method_10250(id)) {
                targetItems.add((class_1792)class_7923.field_41178.method_63535(id));
            }
            if (class_7923.field_41175.method_10250(id)) {
                class_1792 blockItem = ((class_2248)class_7923.field_41175.method_63535(id)).method_8389();
                if (blockItem != class_1802.field_8162) {
                    targetItems.add(blockItem);
                }
            }
        }
        catch (Exception stack) {
            /* goto @27; */
            L159: ;
            if (targetItems.isEmpty()) {
                return 0;
            }
        }
        /* goto @27; */
        L159: ;
        if (targetItems.isEmpty()) {
            return 0;
        }
        total = 0;
        for (slot = 0; slot < mc.field_1724.method_31548().method_5439(); slot++) {
            stack = mc.field_1724.method_31548().method_5438(slot);
            if (!stack.method_7960()) {
                if (!targetItems.contains(stack.method_7909())) continue;
                total = total + stack.method_7947();
            }
        }
        return total;
    }

    private static void runPayAction(class_310 mc, PayAction payAction) throws InterruptedException {
        payAction.delayMs = PayAction.normalizeDelay(payAction.delayMs);
        List<String> targets = new ArrayList();
        long resolvedAmount = payAction.players.iterator();
        while (resolvedAmount.hasNext()) {
            String player = (String)resolvedAmount.next();
            while (player == null) {
            }
            String trimmed = player.trim();
            if (!trimmed.isEmpty()) {
                if (targets.contains(trimmed)) continue;
                targets.add(trimmed);
            }
        }
        if (targets.isEmpty() || mc.method_1562() == null) {
            return;
        }
        resolvedAmount = Math.max(0L, payAction.resolvedAmount());
        amountValue = String.valueOf(resolvedAmount);
        String amountLabel = PayAction.formatAmount(resolvedAmount);
        int sent = 0;
        var var8 = targets.iterator();
        while (var8.hasNext()) {
            String player = (String)var8.next();
            if (!isRunning.get()) {
            } else {
                String template = payAction.commandTemplate == null || payAction.commandTemplate.isBlank() ? "/pay <player> <amount>" : payAction.commandTemplate;
                String command = template.replace("<player>", player).replace("{player}", player).replace("<amount>", amountValue).replace("{amount}", amountValue).trim();
                while (command.isEmpty()) {
                }
                currentStatus = "Paying " + player + " " + amountLabel + " (" + sent + 1 + "/" + targets.size() + ")";
                CountDownLatch latch = new CountDownLatch(1);
                mc.execute(MacroExecutor::lambda$runPayAction$82 /* captured: mc, command, latch */);
            }
            try {
                latch.await(250L, TimeUnit.MILLISECONDS);
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw e;
            }
            sent++;
            if (sent < targets.size()) {
                if (payAction.delayEnabled) {
                    if (payAction.delayMs > 0) {
                        Thread.sleep((long)payAction.delayMs);
                    }
                }
            }
        }
    }

    public static void stop() {
        String macroName = currentMacro != null && currentMacro.name != null ? currentMacro.name : "";
        isRunning.set(false);
        persistentActions.clear();
        backgroundMoves.clear();
        MacroConditionRegistry.cancelAll();
        isWaitingForChat.set(false);
        isWaitingForPacket.set(false);
        CompletableFuture<Void> cf = packetWaitLock;
        synchronized (packetWaitLock) {
        waitingPacketName.set("");
        CompletableFuture<Void> pf = activePacketFuture;
        if (pf != null) {
            pf.cancel(true);
            activePacketFuture = null;
        }
        }
        cf = activeChatFuture;
        if (cf != null) {
            cf.cancel(true);
            activeChatFuture = null;
        }
        bf = activeBaritoneGoalFuture;
        if (bf != null) {
            bf.cancel(true);
            activeBaritoneGoalFuture = null;
        }
        PackUtilCompatManager.stopBaritone(class_310.method_1551());
        try {
            PackUtilLANSync sync = PackUtilLANSync.getInstance();
            if (sync.isInSession()) {
                sync.broadcastStepProgress(-1, 0, "");
            }
        }
        catch (Exception sync) {
            macroThread = null;
            currentMacro = null;
            currentStatus = "";
            isRotating.set(false);
            rotationAlignedFrames = 0;
            if (!macroName.isEmpty()) {
                PackUtilClientMessaging.sendPrefixed("Â§cMacro stopped: " + macroName);
            } else {
                PackUtilClientMessaging.sendPrefixed("Â§cMacro stopped.");
            }
            return;
        }
        macroThread = null;
        currentMacro = null;
        currentStatus = "";
        isRotating.set(false);
        rotationAlignedFrames = 0;
        if (!macroName.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("Â§cMacro stopped: " + macroName);
        } else {
            PackUtilClientMessaging.sendPrefixed("Â§cMacro stopped.");
        }
    }

    public static boolean isRunning() {
        return isRunning.get();
    }

    public static String getCurrentMacroName() {
        PackUtilMacro m = currentMacro;
        return m != null && m.name != null ? m.name : "";
    }

    public static PackUtilMacro getCurrentMacro() {
        return currentMacro;
    }

    public static String getCurrentStatus() {
        return currentStatus;
    }

    public static int getCurrentStepIndex() {
        return currentStepIndex;
    }

    public static int getTotalSteps() {
        return totalSteps;
    }

    public static List<MacroExecutor.RecentChatMessage> getRecentChatMessages() {
        var var0 = recentChatLock;
        synchronized (recentChatLock) {
        }
        return new ArrayList(recentChatMessages);
    }

    public static void onPacketSent(class_2596<?> packet) {
        MacroExecutor.onPacketObserved(packet, "C2S");
    }

    public static void onPacketReceived(class_2596<?> packet) {
        MacroExecutor.onPacketObserved(packet, "S2C");
    }

    public static void onPacketObserved(class_2596<?> packet, String direction) {
        MacroExecutor.syncRecentChatServerContext();
        if ("S2C".equals(direction)) {
            ChatCapture capture = MacroExecutor.extractIncomingChat(packet);
            if (capture != null) {
                if (capture.message() != null) {
                    if (!capture.message().isBlank()) {
                        MacroExecutor.recordRecentChat(capture);
                        if (isRunning.get()) {
                            if (isWaitingForChat.get()) {
                                if (MacroExecutor.matchesWaitingChat(capture)) {
                                    lastMatchedChat.set(capture.displayText());
                                    CompletableFuture<Void> f = activeChatFuture;
                                    if (f != null) {
                                        f.complete(null);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!isRunning.get()) {
            return;
        }
        if (isWaitingForPacket.get()) {
            f = null;
            f = packetWaitLock;
            synchronized (packetWaitLock) {
        }
        if (!isWaitingForPacket.get()) {
            }
            return;
        }
        if (f != null) {
            f.complete(null);
        }
    }

    private static void recordRecentChat(MacroExecutor.ChatCapture capture) {
        RecentChatMessage message = new MacroExecutor.RecentChatMessage(capture.sender() == null ? "" : capture.sender(), capture.message(), capture.displayText(), capture.displayComponent(), capture.source(), System.currentTimeMillis());
        var var2 = recentChatLock;
        synchronized (recentChatLock) {
        recentChatMessages.removeIf(MacroExecutor::lambda$recordRecentChat$83 /* captured: message */);
        recentChatMessages.addFirst(message);
        while (recentChatMessages.size() > 60) {
            recentChatMessages.removeLast();
        }
        }
    }

    private static void syncRecentChatServerContext() {
        String currentServerKey = MacroExecutor.getCurrentMultiplayerServerKey();
        if (currentServerKey.isEmpty()) {
            return;
        }
        var var1 = recentChatLock;
        synchronized (recentChatLock) {
        if (recentChatServerKey.isEmpty()) {
            recentChatServerKey = currentServerKey;
            }
            return;
        }
    }

    private static String getCurrentMultiplayerServerKey() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_1542()) {
            return "";
        }
        class_642 entry = mc.method_1558();
        if (entry != null && entry.field_3761 != null && !entry.field_3761.isBlank()) {
            return MacroExecutor.normalizeServerKey(entry.field_3761);
        }
        if (mc.method_1562() == null) { /* goto L188; */ }
        if (mc.method_1562().method_48296() == null) { /* goto L188; */ }
        SocketAddress address = mc.method_1562().method_48296().method_10755();
        if (address instanceof InetSocketAddress) {
            InetSocketAddress inet = (InetSocketAddress)address;
            String host = inet.getHostString();
            if (host == null || host.isBlank()) {
                if (inet.getAddress() != null) {
                    host = inet.getAddress().getHostAddress();
                }
            }
            if (host != null) {
                if (!host.isBlank()) {
                    return MacroExecutor.normalizeServerKey(host + ":" + inet.getPort());
                }
            }
        } else {
            if (address != null) {
                String raw = address.toString();
                if (raw != null) {
                    if (!raw.isBlank()) {
                        return MacroExecutor.normalizeServerKey(raw);
                    }
                }
            }
        }
        return "";
    }

    private static String normalizeServerKey(String address) {
        if (address == null) {
            return "";
        }
        String trimmed = address.replaceFirst("^/", "").trim().toLowerCase(Locale.ROOT);
        return trimmed;
    }

    private static boolean matchesWaitingChat(MacroExecutor.ChatCapture capture) {
        if (waitingChatServerOnly.get() && capture.source() != MacroExecutor.ChatSource.SERVER) {
            return false;
        }
        String patternJson = (String)waitingChatPatternJson.get();
        if (!waitingChatIsRegex.get()) {
            if (patternJson != null) {
                if (!patternJson.isBlank()) {
                    if (capture.displayComponent() != null) {
                        String captureJson = MacroExecutor.serializeTextComponent(capture.displayComponent());
                        if (patternJson.equals(captureJson)) {
                            return true;
                        }
                    }
                }
            }
        }
        pattern = (String)waitingChatPattern.get();
        if (pattern == null || pattern.isBlank()) {
            return true;
        }
        try {
            return capture.message().matches(pattern) || capture.displayText().matches(pattern);
        }
        catch (Exception ignored) {
            return false;
        }
        threshold = waitingChatFuzzyPercent.get();
        return MacroExecutor.fuzzyChatMatch(pattern, capture.message(), threshold) || MacroExecutor.fuzzyChatMatch(pattern, capture.displayText(), threshold);
    }

    private static MacroExecutor.ChatCapture extractIncomingChat(class_2596<?> packet) {
        if (packet instanceof class_7439) {
            class_7439 gameMessagePacket = (class_7439)packet;
            String raw = gameMessagePacket.comp_763().getString();
            if (raw == null || raw.isBlank()) {
                return null;
            }
            String sender = MacroExecutor.parseSenderFromRawLine(raw);
            String message = MacroExecutor.parseMessageFromRawLine(raw, false);
            ChatSource source = MacroExecutor.inferChatSourceFromRawLine(raw, sender);
            return MacroExecutor.buildChatCapture(sender, message, raw, gameMessagePacket.comp_763(), source);
        }
        if (packet instanceof class_7827) {
            profilelessChatMessagePacket = (class_7827)packet;
            message = MacroExecutor.invokeFirstNoArg(profilelessChatMessagePacket, "message", "getMessage");
            chatType = MacroExecutor.invokeFirstNoArg(profilelessChatMessagePacket, "chatType", "getChatType");
            text = MacroExecutor.extractTextValue(message);
            if (text == null || text.isBlank()) {
                return null;
            }
            sender = MacroExecutor.extractChatName(chatType);
            ChatSource source = MacroExecutor.inferChatSource(sender, text, text);
            return MacroExecutor.buildChatCapture(sender, text, null, MacroExecutor.extractTextComponent(message), source);
        }
        if (!packet instanceof class_7438) { /* goto L625; */ }
        chatMessagePacket = (class_7438)packet;
        Object[] tmp2 = new Object[3];
        tmp2[0] = MacroExecutor.invokeFirstNoArg(chatMessagePacket, "body", "getBody");
        tmp2[1] = MacroExecutor.getRecordComponentValue(chatMessagePacket, 4);
        tmp2[2] = MacroExecutor.findRecordComponentByMethodNames(chatMessagePacket, 2, "content", "timestamp", "salt");
        body = MacroExecutor.firstNonNull(tmp2);
        Object[] tmp5 = new Object[3];
        tmp5[0] = MacroExecutor.invokeFirstNoArg(chatMessagePacket, "serializedParameters", "getSerializedParameters");
        tmp5[1] = MacroExecutor.getRecordComponentValue(chatMessagePacket, 7);
        tmp5[2] = MacroExecutor.findRecordComponentByMethodNames(chatMessagePacket, 2, "name", "targetName", "type");
        serializedParameters = MacroExecutor.firstNonNull(tmp5);
        Object[] tmp8 = new Object[3];
        tmp8[0] = MacroExecutor.invokeFirstNoArg(chatMessagePacket, "sender", "getSender");
        tmp8[1] = MacroExecutor.getRecordComponentValue(chatMessagePacket, 1);
        tmp8[2] = MacroExecutor.findRecordComponentByValueType(chatMessagePacket, UUID.class);
        senderValue = MacroExecutor.firstNonNull(tmp8);
        Object[] tmp10 = new Object[3];
        tmp10[0] = MacroExecutor.invokeFirstNoArg(chatMessagePacket, "unsignedContent", "getUnsignedContent");
        tmp10[1] = MacroExecutor.getRecordComponentValue(chatMessagePacket, 5);
        tmp10[2] = MacroExecutor.findRecordTextComponent(chatMessagePacket, body, serializedParameters, senderValue);
        unsignedContent = MacroExecutor.firstNonNull(tmp10);
        message = MacroExecutor.extractTextValue(unsignedContent);
        class_2561 messageComponent = MacroExecutor.extractTextComponent(unsignedContent);
        if (message == null || message.isBlank()) {
            if (body != null) {
                Object[] tmp13 = new Object[3];
                tmp13[0] = MacroExecutor.invokeFirstNoArg(body, "content", "getContent");
                tmp13[1] = MacroExecutor.getRecordComponentValue(body, 0);
                tmp13[2] = MacroExecutor.findRecordTextComponent(body, new Object[0]);
                Object bodyContent = MacroExecutor.firstNonNull(tmp13);
                message = MacroExecutor.extractTextValue(bodyContent);
                if (messageComponent == null) {
                    messageComponent = MacroExecutor.extractTextComponent(bodyContent);
                }
            }
        }
        if (message == null || message.isBlank()) {
            return null;
        }
        UUID uuid = (UUID)senderValue;
        sender = senderValue instanceof UUID ? MacroExecutor.resolvePlayerName(uuid) : null;
        if (sender == null || sender.isBlank()) {
            sender = MacroExecutor.extractChatName(serializedParameters);
        }
        ChatSource source = MacroExecutor.inferChatSource(sender, message, message);
        return MacroExecutor.buildChatCapture(sender, message, null, messageComponent, source);
        L625: ;
        return null;
    }

    private static MacroExecutor.ChatCapture buildChatCapture(String sender, String message, String displayText, class_2561 displayComponent, MacroExecutor.ChatSource source) {
        String cleanMessage = MacroExecutor.sanitizeChatText(message);
        if (cleanMessage.isBlank()) {
            return null;
        }
        String cleanSender = MacroExecutor.sanitizeChatText(sender);
        String cleanDisplay = MacroExecutor.sanitizeChatText(displayText);
        if (MacroExecutor.startsWithServerPrefix(cleanMessage)) {
            cleanMessage = MacroExecutor.trimServerPrefix(cleanMessage);
        }
        if (MacroExecutor.startsWithServerPrefix(cleanDisplay)) {
            cleanDisplay = "[Server] " + MacroExecutor.trimServerPrefix(cleanDisplay);
        }
        if (MacroExecutor.isServerSenderLabel(cleanSender)) {
            cleanSender = "[Server]";
        }
        if (MacroExecutor.isServerMarked(cleanSender, cleanMessage, cleanDisplay)) {
            cleanSender = "[Server]";
        }
        class_2561 rendered = MacroExecutor.literalizeTextComponent(displayComponent);
        String display = cleanDisplay;
        if (rendered == null) { /* goto L121; */ }
        if (!rendered.getString().isBlank()) { /* goto L170; */ }
        L121: ;
        rendered = cleanSender.isBlank() || MacroExecutor.isServerSenderLabel(cleanSender) ? class_2561.method_43470("[Server] " + cleanMessage) : class_2561.method_43470("<" + cleanSender + "> ").method_10852(class_2561.method_43470(cleanMessage));
        if (display == null || display.isBlank()) {
            display = MacroExecutor.sanitizeChatText(rendered.getString());
        }
        ChatSource resolvedSource = source != null ? source : MacroExecutor.inferChatSource(cleanSender, cleanMessage, display);
        return new MacroExecutor.ChatCapture(cleanSender, cleanMessage, MacroExecutor.sanitizeChatText(display), rendered, resolvedSource);
    }

    private static String sanitizeChatText(String text) {
        if (text == null) {
            return "";
        }
        String stripped = MacroExecutor.stripLegacyFormatting(text).replace(10, 32).replace(13, 32);
        StringBuilder out = new StringBuilder(stripped.length());
        int offset = 0;
        while (offset < stripped.length()) {
            int cp = stripped.codePointAt(offset);
            offset = offset + Character.charCount(cp);
            int type = Character.getType(cp);
            if (type == 16) continue;
            if (type == 15) continue;
            if (cp == 8203) continue;
            if (cp == 8204) continue;
            if (cp == 8205) continue;
            if (cp == 8288) continue;
            if (cp == 65038) continue;
            while (cp == 65039) {
            }
            out.appendCodePoint(cp);
        }
        return out.toString().trim();
    }

    private static String stripLegacyFormatting(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == 167 || ch == 38) {
                if (i + 1 < text.length()) {
                    char next = Character.toLowerCase(text.charAt(i + 1));
                    if (next < 48 || next > 57) {
                        if (next < 97 || next > 102) {
                            if (next < 107 || next > 111) {
                                if (next == 114) { /* goto @134; */ }
                            }
                        }
                    }
                    i++;
                }
            } else {
                out.append(ch);
            }
        }
        return out.toString();
    }

    private static String parseSenderFromRawLine(String raw) {
        if (raw == null) {
            return "";
        }
        String text = raw.trim();
        if (MacroExecutor.startsWithServerPrefix(text)) {
            return "[Server]";
        }
        if (text.startsWith("<")) {
            int end = text.indexOf("> ");
            if (end > 1) {
                return text.substring(1, end).trim();
            }
        }
        colon = text.indexOf(": ");
        if (colon > 0 && colon <= 48) {
            return text.substring(0, colon).trim();
        }
        return "";
    }

    private static String parseMessageFromRawLine(String raw, boolean keepWholeIfUnknown) {
        if (raw == null) {
            return "";
        }
        String text = raw.trim();
        if (MacroExecutor.startsWithServerPrefix(text)) {
            String trimmed = text.substring("[server]".length()).trim();
            if (!trimmed.isEmpty()) {
                return trimmed;
            }
        }
        if (text.startsWith("<")) {
            end = text.indexOf("> ");
            if (end > 1) {
                if (end + 2 < text.length()) {
                    return text.substring(end + 2).trim();
                }
            }
        }
        colon = text.indexOf(": ");
        if (colon > 0 && colon <= 48 && colon + 2 < text.length()) {
            return text.substring(colon + 2).trim();
        }
        return keepWholeIfUnknown ? text : text;
    }

    private static MacroExecutor.ChatSource inferChatSourceFromRawLine(String raw, String parsedSender) {
        if (raw == null || raw.isBlank()) {
            return MacroExecutor.ChatSource.SERVER;
        }
        String text = raw.trim();
        if (MacroExecutor.startsWithServerPrefix(text) || MacroExecutor.isServerSenderLabel(parsedSender)) {
            return MacroExecutor.ChatSource.SERVER;
        }
        if (text.startsWith("<")) {
            int end = text.indexOf("> ");
            if (end > 1) {
                return MacroExecutor.ChatSource.PLAYER;
            }
        }
        return parsedSender == null || MacroExecutor.sanitizeChatText(parsedSender).isBlank() ? MacroExecutor.ChatSource.SERVER : MacroExecutor.ChatSource.PLAYER;
    }

    private static boolean startsWithServerPrefix(String text) {
        String normalized = MacroExecutor.normalizeChatText(MacroExecutor.sanitizeChatText(text));
        return normalized.equals("server") || normalized.startsWith("server ") || normalized.startsWith("server:");
    }

    private static String trimServerPrefix(String text) {
        if (!MacroExecutor.startsWithServerPrefix(text)) {
            return MacroExecutor.sanitizeChatText(text);
        }
        return MacroExecutor.sanitizeChatText(text.substring("[server]".length()).trim());
    }

    private static boolean isServerSenderLabel(String sender) {
        String normalized = MacroExecutor.normalizeChatText(MacroExecutor.sanitizeChatText(sender));
        return normalized.equals("server");
    }

    private static boolean isServerMarked(String sender, String message, String displayText) {
        return MacroExecutor.isServerSenderLabel(sender) || MacroExecutor.startsWithServerPrefix(message) || MacroExecutor.startsWithServerPrefix(displayText);
    }

    private static MacroExecutor.ChatSource inferChatSource(String sender, String message, String displayText) {
        String cleanSender = MacroExecutor.sanitizeChatText(sender);
        if (MacroExecutor.isServerMarked(cleanSender, message, displayText)) {
            return MacroExecutor.ChatSource.SERVER;
        }
        if (cleanSender.isBlank()) {
            return MacroExecutor.ChatSource.SERVER;
        }
        return MacroExecutor.ChatSource.PLAYER;
    }

    private static boolean isLikelyPlayerSender(String sender) {
        String cleanSender = MacroExecutor.sanitizeChatText(sender);
        if (cleanSender.isBlank()) {
            return false;
        }
        try {
            class_310 mc = class_310.method_1551();
            if (mc.method_1562() == null) { /* goto @104; */ }
            var var3 = mc.method_1562().method_2880().iterator();
            L38: ;
            if (!var3.hasNext()) { /* goto @104; */ }
            class_640 entry = (class_640)var3.next();
            String playerName = entry != null && entry.method_2966() != null ? MacroExecutor.extractTextValue(entry.method_2966()) : null;
            if (playerName != null) {
                if (cleanSender.equalsIgnoreCase(playerName)) {
                    return true;
                }
            }
        }
        catch (Throwable mc) {
            mc = class_310.method_1551();
            if (mc.field_1687 == null) { /* goto @198; */ }
            var3 = mc.field_1687.method_18456().iterator();
            L132: ;
            if (!var3.hasNext()) { /* goto @198; */ }
            player = (class_742)var3.next();
            if (player == null) { /* goto @176; */ }
            if (player.method_7334() == null) { /* goto @176; */ }
            /* note: clearing non-empty stack before goto */
            /* goto @177; */
        }
        try {
            /* goto @38; */
        }
        catch (Throwable mc) {
            mc = class_310.method_1551();
            if (mc.field_1687 == null) { /* goto @198; */ }
            var3 = mc.field_1687.method_18456().iterator();
            L132: ;
            if (!var3.hasNext()) { /* goto @198; */ }
            player = (class_742)var3.next();
            if (player == null) { /* goto @176; */ }
            if (player.method_7334() == null) { /* goto @176; */ }
            /* note: clearing non-empty stack before goto */
            /* goto @177; */
        }
        try {
            mc = class_310.method_1551();
            if (mc.field_1687 == null) { /* goto @198; */ }
            var3 = mc.field_1687.method_18456().iterator();
            L132: ;
            if (!var3.hasNext()) { /* goto @198; */ }
            player = (class_742)var3.next();
            playerName = player != null && player.method_7334() != null ? MacroExecutor.extractTextValue(player.method_7334()) : null;
            if (playerName != null) {
                if (cleanSender.equalsIgnoreCase(playerName)) {
                    return true;
                }
            }
        }
        catch (Throwable mc) {
            return false;
        }
        try {
            /* goto @132; */
        }
        catch (Throwable mc) {
            return false;
        }
        return false;
    }

    private static boolean fuzzyChatMatch(String pattern, String candidate, int thresholdPercent) {
        String normalizedPattern = MacroExecutor.normalizeChatText(pattern);
        String normalizedCandidate = MacroExecutor.normalizeChatText(candidate);
        if (normalizedPattern.isBlank()) {
            return true;
        }
        if (normalizedCandidate.isBlank()) {
            return false;
        }
        if (normalizedCandidate.contains(normalizedPattern)) {
            return true;
        }
        List<String> patternTokens = MacroExecutor.tokenizeChat(normalizedPattern);
        List<String> candidateTokens = MacroExecutor.tokenizeChat(normalizedCandidate);
        if (patternTokens.isEmpty()) {
            return true;
        }
        if (thresholdPercent >= 100) {
            return MacroExecutor.allPatternTokensPresent(patternTokens, normalizedCandidate);
        }
        double tokenScore = MacroExecutor.computeTokenCoverage(patternTokens, candidateTokens);
        double charScore = MacroExecutor.similarityRatio(normalizedPattern.replace(" ", ""), normalizedCandidate.replace(" ", ""));
        double score = Math.max(tokenScore, tokenScore * 0.7 + charScore * 0.3);
        return score + 0.000000001 >= (double)Math.max(40, Math.min(100, thresholdPercent)) / 100;
    }

    private static String normalizeChatForCompare(String text) {
        if (text == null) {
            return "";
        }
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder(normalized.length());
        for (int i = 0; i < normalized.length(); i++) {
            char ch = normalized.charAt(i);
            if (Character.isLetterOrDigit(ch)) {
                out.append(ch);
            } else {
                if (Character.isWhitespace(ch)) {
                    out.append(32);
                } else {
                    if (ch == 39) { /* goto @140; */ }
                    if (ch == 34) { /* goto @140; */ }
                    if (ch == 96) { /* goto @140; */ }
                    if (ch == 45) { /* goto @140; */ }
                    if (ch == 95) { /* goto @140; */ }
                    if (ch == 8217) {
                    } else {
                        out.append(32);
                    }
                }
            }
        }
        return out.toString().trim().replaceAll("\\s+", " ");
    }

    public static String normalizeChatText(String text) {
        if (text == null) {
            return "";
        }
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFKD).toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder(normalized.length());
        boolean lastWasSpace = true;
        int offset = 0;
        while (offset < normalized.length()) {
            int cp = normalized.codePointAt(offset);
            offset = offset + Character.charCount(cp);
            cp = MacroExecutor.foldStyledLatinCodePoint(cp);
            int type = Character.getType(cp);
            if (type == 6) continue;
            if (type == 8) continue;
            if (type == 7) continue;
            if (type == 16) continue;
            if (type == 15) continue;
            if (type == 18) continue;
            while (type == 19) {
            }
            if (Character.isLetterOrDigit(cp)) {
                out.appendCodePoint(cp);
                lastWasSpace = false;
            } else {
                if (Character.isWhitespace(cp)) {
                    if (lastWasSpace) continue;
                    out.append(32);
                    lastWasSpace = true;
                } else {
                    if (MacroExecutor.isJoinerPunctuation(cp)) {
                    } else {
                        if (lastWasSpace) continue;
                        out.append(32);
                        lastWasSpace = true;
                    }
                }
            }
        }
        len = out.length();
        if (len > 0) {
            if (out.charAt(len - 1) == 32) {
                out.setLength(len - 1);
            }
        }
        return out.toString();
    }

    private static boolean isJoinerPunctuation(int cp) {
        switch (cp) {
            case 34::
            case 39::
            case 45::
            case 95::
            case 96::
            case 700::
            case 8208::
            case 8209::
            case 8210::
            case 8211::
            case 8212::
            case 8213::
            case 8216::
            case 8217::
            case 8219::
            case 8242::
            case 8722::
            case 65287::
                return true;
            default:
                return false;
        }
    }

    private static int foldStyledLatinCodePoint(int cp) {
        switch (cp) {
            case 7424::
                return 97;
            case 665::
                return 98;
            case 7428::
                return 99;
            case 7429::
                return 100;
            case 7431::
                return 101;
            case 42800::
                return 102;
            case 610::
                return 103;
            case 668::
                return 104;
            case 618::
                return 105;
            case 7434::
                return 106;
            case 7435::
                return 107;
            case 671::
                return 108;
            case 7437::
                return 109;
            case 628::
                return 110;
            case 7439::
                return 111;
            case 7448::
                return 112;
            case 491::
                return 113;
            case 640::
                return 114;
            case 42801::
                return 115;
            case 7451::
                return 116;
            case 7452::
                return 117;
            case 7456::
                return 118;
            case 7457::
                return 119;
            case 739::
                return 120;
            case 655::
                return 121;
            case 7458::
                return 122;
            case 223::
                return 115;
            case 230::
                return 97;
            case 339::
                return 111;
            default:
                return cp;
        }
    }

    private static List<String> tokenizeChat(String normalized) {
        if (normalized == null || normalized.isBlank()) {
            return List.of();
        }
        return List.of(normalized.split(" "));
    }

    private static boolean allPatternTokensPresent(List<String> patternTokens, String normalizedCandidate) {
        var var2 = patternTokens.iterator();
        while (var2.hasNext()) {
            String token = (String)var2.next();
            if (normalizedCandidate.contains(token)) continue;
            return false;
        }
        return true;
    }

    private static double computeTokenCoverage(List<String> patternTokens, List<String> candidateTokens) {
        if (patternTokens.isEmpty()) {
            return 1;
        }
        if (candidateTokens.isEmpty()) {
            return 0;
        }
        double total = 0;
        var var4 = patternTokens.iterator();
        while (var4.hasNext()) {
            String patternToken = (String)var4.next();
            double best = 0;
            var var8 = candidateTokens.iterator();
            while (var8.hasNext()) {
                String candidateToken = (String)var8.next();
                best = Math.max(best, MacroExecutor.tokenSimilarity(patternToken, candidateToken));
                if (best < 1) { /* goto @111; */ }
                break;
            }
            total = total + best;
        }
        return total / (double)patternTokens.size();
    }

    private static double tokenSimilarity(String left, String right) {
        if (left.equals(right)) {
            return 1;
        }
        if (left.isBlank() || right.isBlank()) {
            return 0;
        }
        if (left.contains(right) || right.contains(left)) {
            return (double)Math.min(left.length(), right.length()) / (double)Math.max(left.length(), right.length());
        }
        return MacroExecutor.similarityRatio(left, right);
    }

    private static double similarityRatio(String left, String right) {
        if (left.equals(right)) {
            return 1;
        }
        int maxLen = Math.max(left.length(), right.length());
        if (maxLen == 0) {
            return 1;
        }
        int distance = MacroExecutor.levenshteinDistance(left, right);
        return Math.max(0, 1 - (double)distance / (double)maxLen);
    }

    private static int levenshteinDistance(String left, String right) {
        int[] previous = new int[right.length() + 1];
        int[] current = new int[right.length() + 1];
        for (int j = 0; j <= right.length(); j++) {
            previous[j] = j;
        }
        for (i = 1; i <= left.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= right.length(); j++) {
                int cost = left.charAt(i - 1) == right.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            temp = previous;
            previous = current;
            current = temp;
        }
        return previous[right.length()];
    }

    private static String extractChatName(Object value) {
        Object[] tmp0 = new Object[3];
        tmp0[0] = MacroExecutor.invokeFirstNoArg(value, "name", "getName", "targetName", "getTargetName");
        tmp0[1] = MacroExecutor.getRecordComponentValue(value, 0);
        tmp0[2] = MacroExecutor.findRecordComponentByMethodNames(value, 2, "name", "targetName", "type");
        Object direct = MacroExecutor.firstNonNull(tmp0);
        return MacroExecutor.sanitizeChatText(MacroExecutor.extractTextValue(direct));
    }

    private static String resolvePlayerName(UUID uuid) {
        if (uuid == null) {
            return "";
        }
        try {
            if (class_310.method_1551().method_1562() != null) {
                class_640 entry = class_310.method_1551().method_1562().method_2871(uuid);
                if (entry != null) {
                    if (entry.method_2966() != null) {
                        String profileName = MacroExecutor.extractTextValue(entry.method_2966());
                        if (profileName != null) {
                            if (!profileName.isBlank()) {
                                return profileName;
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable entry) {
            if (class_310.method_1551().field_1687 != null) {
                entry = class_310.method_1551().field_1687.method_18456().iterator();
                L88: ;
                if (entry.hasNext()) {
                    player = (class_742)entry.next();
                    if (uuid.equals(player.method_5667())) {
                        if (player.method_7334() != null) {
                            String profileName = MacroExecutor.extractTextValue(player.method_7334());
                            if (profileName != null) {
                                if (!profileName.isBlank()) {
                                    return profileName;
                                }
                            }
                        }
                    }
                }
            }
        }
        try {
            if (class_310.method_1551().field_1687 != null) {
                entry = class_310.method_1551().field_1687.method_18456().iterator();
                L88: ;
                if (entry.hasNext()) {
                    player = (class_742)entry.next();
                    if (uuid.equals(player.method_5667())) {
                        if (player.method_7334() != null) {
                            profileName = MacroExecutor.extractTextValue(player.method_7334());
                            if (profileName != null) {
                                if (!profileName.isBlank()) {
                                    return profileName;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable entry) {
            return "";
        }
        try {
            /* goto @88; */
        }
        catch (Throwable entry) {
            return "";
        }
        return "";
    }

    private static Object firstNonNull(Object ... values) {
        if (values == null) {
            return null;
        }
        var var1 = values;
        var var2 = var1.length;
        for (int var3 = 0; var3 < var2; var3++) {
            Object value = var1[var3];
            if (value == null) continue;
            return value;
        }
        return null;
    }

    private static Object invokeFirstNoArg(Object target, String ... names) {
        if (target == null || names == null) {
            return null;
        }
        Class<?> type = target.getClass();
        var var3 = names;
        var var4 = var3.length;
        int var5 = 0;
        while (var5 < var4) {
            String name = var3[var5];
            try {
                Method method = type.getMethod(name, new Class[0]);
                method.setAccessible(true);
                return method.invoke(target, new Object[0]);
            }
            catch (Throwable method) {
                var5++;
            }
        }
        return null;
    }

    private static Object getRecordComponentValue(Object target, int index) {
        if (target == null) {
            return null;
        }
        try {
            RecordComponent[] components = target.getClass().getRecordComponents();
            if (components == null || index < 0 || index >= components.length) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            Method accessor = components[index].getAccessor();
            accessor.setAccessible(true);
            return accessor.invoke(target, new Object[0]);
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static Object findRecordComponentByValueType(Object target, Class<?> type) {
        if (target == null || type == null) {
            return null;
        }
        try {
            RecordComponent[] components = target.getClass().getRecordComponents();
            if (components == null) {
                return null;
            }
        }
        catch (Throwable components) {
            return null;
        }
        try {
            var var3 = components;
            var var4 = var3.length;
            int var5 = 0;
            L33: ;
            if (var5 < var4) {
                RecordComponent component = var3[var5];
                if (type.isAssignableFrom(component.getType())) {
                    Method accessor = component.getAccessor();
                    accessor.setAccessible(true);
                    return accessor.invoke(target, new Object[0]);
                }
            }
        }
        catch (Throwable components) {
            return null;
        }
        try {
            var5++;
            /* goto @33; */
        }
        catch (Throwable components) {
            return null;
        }
        return null;
    }

    private static Object findRecordComponentByMethodNames(Object target, int fallbackIndex, String ... names) {
        Object direct = MacroExecutor.invokeFirstNoArg(target, names);
        return direct != null ? direct : MacroExecutor.getRecordComponentValue(target, fallbackIndex);
    }

    private static Object findRecordTextComponent(Object target, Object ... excludedValues) {
        if (target == null) {
            return null;
        }
        try {
            RecordComponent[] components = target.getClass().getRecordComponents();
            if (components == null) {
                return null;
            }
        }
        catch (Throwable components) {
            return null;
        }
        try {
            var var3 = components;
            var var4 = var3.length;
            int var5 = 0;
            L29: ;
            if (var5 >= var4) { /* goto @149; */ }
            RecordComponent component = var3[var5];
            Method accessor = component.getAccessor();
            accessor.setAccessible(true);
            Object value = accessor.invoke(target, new Object[0]);
            if (value == null) {
            } else {
                var var9 = excludedValues;
                var var10 = var9.length;
                int var11 = 0;
                while (var11 < var10) {
                    Object excluded = var9[var11];
                    if (excluded == value) {
                    } else {
                        var11++;
                    }
                }
                if (value instanceof class_2561 || value instanceof CharSequence || value instanceof Optional) {
                    return value;
                }
            }
        }
        catch (Throwable components) {
            return null;
        }
        try {
            var5++;
            /* goto @29; */
        }
        catch (Throwable components) {
            return null;
        }
        return null;
    }

    private static class_2561 extractTextComponent(Object value) {
        if (value == null) {
            return null;
        }
        if (!value instanceof Optional) { /* goto L37; */ }
        Optional<?> optional = (Optional)value;
        return optional.isPresent() ? MacroExecutor.extractTextComponent(optional.get()) : null;
        if (value instanceof class_2561) {
            text = (class_2561)value;
            return MacroExecutor.literalizeTextComponent(text);
        }
        if (value instanceof CharSequence) {
            chars = (CharSequence)value;
            return class_2561.method_43470(chars.toString());
        }
        if (value instanceof UUID) {
            uuid = (UUID)value;
            return class_2561.method_43470(MacroExecutor.resolvePlayerName(uuid));
        }
        try {
            getText = value.getClass().getMethod("getText", new Class[0]);
            getText.setAccessible(true);
            Object result = getText.invoke(value, new Object[0]);
            class_2561 text = MacroExecutor.extractTextComponent(result);
            if (text != null) {
                return text;
            }
        }
        catch (Throwable getString) {
            getString = value.getClass().getMethod("getString", new Class[0]);
            getString.setAccessible(true);
            result = getString.invoke(value, new Object[0]);
            if (result != null) {
                return class_2561.method_43470(String.valueOf(result));
            }
        }
        try {
            getString = value.getClass().getMethod("getString", new Class[0]);
            getString.setAccessible(true);
            result = getString.invoke(value, new Object[0]);
            if (result != null) {
                return class_2561.method_43470(String.valueOf(result));
            }
        }
        catch (Throwable getString) {
            return null;
        }
    }

    public static class_2561 literalizeTextComponent(class_2561 text) {
        if (text == null) {
            return null;
        }
        class_5250 literalized = class_2561.method_43473();
        try {
            text.method_27658(MacroExecutor::lambda$literalizeTextComponent$84 /* captured: literalized */, class_2583.field_24360);
        }
        catch (Throwable e2) {
            if (!literalized.getString().isEmpty()) {
                return literalized;
            }
        }
        if (!literalized.getString().isEmpty()) {
            return literalized;
        }
        return class_2561.method_43470(text.getString());
    }

    private static class_2583 copyVisualStyle(class_2583 style) {
        if (style == null || style.method_10967()) {
            return class_2583.field_24360;
        }
        class_2583 safe = class_2583.field_24360;
        if (style.method_27708() != null) {
            safe = safe.method_27704(style.method_27708());
        }
        if (style.method_10973() != null) {
            safe = safe.method_27703(style.method_10973());
        }
        if (style.method_10984()) {
            safe = safe.method_10982(true);
        }
        if (style.method_10966()) {
            safe = safe.method_10978(true);
        }
        if (style.method_10965()) {
            safe = safe.method_30938(true);
        }
        if (style.method_10986()) {
            safe = safe.method_36140(true);
        }
        if (style.method_10987()) {
            safe = safe.method_36141(true);
        }
        return safe;
    }

    public static String serializeTextComponent(class_2561 text) {
        if (text == null) {
            return "";
        }
        try {
            class_2561 safeText = MacroExecutor.literalizeTextComponent(text);
            return safeText == null ? "" : GSON.toJson((JsonElement)class_8824.field_46597.encodeStart(JsonOps.INSTANCE, safeText).getOrThrow());
        }
        catch (Throwable ignored) {
            return "";
        }
    }

    public static class_2561 deserializeTextComponent(String json) {
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            return MacroExecutor.literalizeTextComponent(((class_2561)class_8824.field_46597.parse(JsonOps.INSTANCE, JsonParser.parseString(json)).getOrThrow()).method_27661());
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static String extractTextValue(Object value) {
        if (value == null) {
            return null;
        }
        if (!value instanceof Optional) { /* goto L37; */ }
        Optional<?> optional = (Optional)value;
        return optional.isPresent() ? MacroExecutor.extractTextValue(optional.get()) : null;
        if (value instanceof class_2561) {
            text = (class_2561)value;
            return text.getString();
        }
        if (value instanceof CharSequence) {
            chars = (CharSequence)value;
            return chars.toString();
        }
        if (value instanceof UUID) {
            uuid = (UUID)value;
            return MacroExecutor.resolvePlayerName(uuid);
        }
        try {
            getString = value.getClass().getMethod("getString", new Class[0]);
            getString.setAccessible(true);
            Object result = getString.invoke(value, new Object[0]);
            if (result != null) {
                return String.valueOf(result);
            }
        }
        catch (Throwable getName) {
            getName = value.getClass().getMethod("getName", new Class[0]);
            getName.setAccessible(true);
            result = getName.invoke(value, new Object[0]);
            if (result instanceof CharSequence) {
                CharSequence chars = (CharSequence)result;
                return chars.toString();
            }
        }
        try {
            getName = value.getClass().getMethod("getName", new Class[0]);
            getName.setAccessible(true);
            result = getName.invoke(value, new Object[0]);
            if (result instanceof CharSequence) {
                chars = (CharSequence)result;
                return chars.toString();
            }
        }
        catch (Throwable getName) {
            return null;
        }
    }

    public static void onRender(float tickDelta) {
        if (isRunning.get()) {
            if (isRotating.get()) {
                class_310 mc = class_310.method_1551();
                if (mc.field_1724 == null) {
                    return;
                }
                float currentYaw = mc.field_1724.method_36454();
                float currentPitch = mc.field_1724.method_36455();
                double deltaYaw = (double)class_3532.method_15393(targetYaw - currentYaw);
                double deltaPitch = (double)(targetPitch - currentPitch);
                double diagonalDistance = Math.hypot(deltaYaw, deltaPitch);
                if (diagonalDistance <= 0.35) {
                    mc.field_1724.method_36456(targetYaw);
                    mc.field_1724.method_36457(targetPitch);
                    rotationAlignedFrames = rotationAlignedFrames + 1;
                    if (rotationAlignedFrames >= 2) {
                        isRotating.set(false);
                    }
                    return;
                }
                rotationAlignedFrames = 0;
                double frameStep = Math.min(diagonalDistance, rotationSpeed * (double)Math.max(tickDelta, 1f));
                double stepYaw = deltaYaw / diagonalDistance * frameStep;
                double stepPitch = deltaPitch / diagonalDistance * frameStep;
                mc.field_1724.method_36456(currentYaw + (float)stepYaw);
                mc.field_1724.method_36457(currentPitch + (float)stepPitch);
            }
        }
    }

    private static void startSmoothRotation(float yaw, float pitch, double speed) {
        targetYaw = yaw;
        targetPitch = pitch;
        rotationSpeed = speed;
        rotationAlignedFrames = 0;
        isRotating.set(true);
    }

    private static void waitForSmoothRotationCompletion() {
        while (isRunning.get()) {
            if (!isRotating.get()) break;
            LockSupport.parkNanos(1000000L);
        }
    }

    private static LookAtBlockAction.RotationTarget resolveLookAtTargetOnClient(class_310 mc, LookAtBlockAction action) {
        if (mc == null || action == null) {
            return null;
        }
        AtomicReference<LookAtBlockAction.RotationTarget> targetRef = new AtomicReference();
        CountDownLatch latch = new CountDownLatch(1);
        mc.execute(MacroExecutor::lambda$resolveLookAtTargetOnClient$85 /* captured: targetRef, action, mc, latch */);
        while (isRunning.get()) {
            try {
            }
            catch (InterruptedException e) {
            }
        }
        return (LookAtBlockAction.RotationTarget)targetRef.get();
    }

    public static void stopAll() {
        MacroExecutor.stop();
    }

    private static void executeBurstPackets(class_310 mc, List<SendPacketAction> batch) {
        if (mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("Â§cNo network connection for burst!");
            return;
        }
        List<PackUtilSharedState.QueuedPacket> allQueuedPackets = new ArrayList();
        List<class_2596<?>> regeneratedPackets = batch.iterator();
        while (regeneratedPackets.hasNext()) {
            SendPacketAction action = (SendPacketAction)regeneratedPackets.next();
            allQueuedPackets.addAll(action.getPackets());
        }
        if (allQueuedPackets.isEmpty()) {
            return;
        }
        regeneratedPackets = new ArrayList(allQueuedPackets.size());
        handler = allQueuedPackets.iterator();
        while (handler.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)handler.next();
            while (qp.packet == null) {
            }
            regeneratedPackets.add(qp.packet);
        }
        if (regeneratedPackets.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("Â§cBurst: All packets failed to regenerate!");
            return;
        }
        handler = mc.method_1562();
        qp = regeneratedPackets.iterator();
        while (qp.hasNext()) {
            class_2596<?> packet = (class_2596)qp.next();
            class_2596<?> toSend = packet;
            while (packet instanceof class_2813) {
                toSend = PacketRegenerator.regenerate(packet);
                if (toSend != null) break;
            }
            handler.method_52787(toSend);
        }
        if (regeneratedPackets.size() > 1) {
            PackUtilClientMessaging.sendPrefixed("Â§aâš¡ Burst sent " + regeneratedPackets.size() + " packets");
        }
    }

    private static List<class_2596<?>> preGeneratePackets(PackUtilMacro macro, int startIdx, int count) {
        List<class_2596<?>> result = new ArrayList();
        int maxIdx = count < 0 ? macro.actions.size() : Math.min(startIdx + count, macro.actions.size());
        class_310 mc = class_310.method_1551();
        int j = startIdx;
        while (j < maxIdx) {
            MacroAction act = (MacroAction)macro.actions.get(j);
            if (!(act instanceof SendPacketAction)) {
            } else {
                SendPacketAction spa = (SendPacketAction)act;
                var var9 = spa.getPackets().iterator();
                while (var9.hasNext()) {
                    QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var9.next();
                    while (qp.packet == null) {
                    }
                    result.add(qp.packet);
                }
                j++;
            }
        }
        return result;
    }

    private static void executePreGeneratedBurst(class_310 mc, List<class_2596<?>> packets) {
        if (packets.isEmpty() || mc.method_1562() == null) {
            return;
        }
        class_634 handler = mc.method_1562();
        PackUtilModule module = packets.iterator();
        while (module.hasNext()) {
            class_2596<?> p = (class_2596)module.next();
            class_2596<?> toSend = p;
            while (p instanceof class_2813) {
                toSend = PacketRegenerator.regenerate(p);
                if (toSend != null) break;
            }
            handler.method_52787(toSend);
        }
        module = PackUtilModule.get();
        try {
            connection = handler.method_48296();
            if (connection != null) {
                ((PackUtilClientConnectionAccessor)connection).getChannel().flush();
            }
        }
        catch (Exception connection) {
            return;
        }
    }

    private static int countPreGeneratedActions(PackUtilMacro macro, int startIdx, int packetCount) {
        int actionsToSkip = 0;
        int packetsRemaining = packetCount;
        int j = startIdx;
        while (j < macro.actions.size()) {
            if (packetsRemaining <= 0) break;
            MacroAction act = (MacroAction)macro.actions.get(j);
            if (!(act instanceof SendPacketAction)) {
            } else {
                SendPacketAction spa = (SendPacketAction)act;
                int actionPackets = spa.getPackets().size();
                packetsRemaining = packetsRemaining - actionPackets;
                actionsToSkip++;
                j++;
            }
        }
        return actionsToSkip;
    }
}
