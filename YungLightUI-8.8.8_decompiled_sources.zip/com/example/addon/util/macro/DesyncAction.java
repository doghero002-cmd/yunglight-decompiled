/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_2815;
import net.minecraft.class_310;

public class DesyncAction
implements MacroAction {
    private boolean enabled = true;

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            return;
        }
        if (mc.field_1724.field_7512 == null) {
            return;
        }
        mc.method_1562().method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
    }

    public MacroActionType getType() {
        return MacroActionType.DESYNC;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "DESYNC");
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        return "Desync";
    }

    public String getIcon() {
        return "~";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
