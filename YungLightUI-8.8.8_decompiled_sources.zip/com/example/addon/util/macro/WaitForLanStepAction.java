/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class WaitForLanStepAction
implements MacroAction {
    public boolean filterByUser = false;
    public int defaultStep = 1;
    public List<WaitForLanStepAction.LanStepEntry> entries = new ArrayList();
    private boolean enabled = true;

    public MacroActionType getType() {
        return MacroActionType.WAIT_LAN_STEP;
    }

    public void execute(class_310 mc) {
    }

    public String getDisplayName() {
        if (!this.filterByUser) {
            return "Wait LAN: any @ step " + this.defaultStep;
        }
        if (this.entries.isEmpty()) {
            return "Wait LAN: any @ step " + this.defaultStep;
        }
        if (this.entries.size() != 1) { /* goto L95; */ }
        LanStepEntry e = (WaitForLanStepAction.LanStepEntry)this.entries.get(0);
        return "Wait LAN: " + e.username.isEmpty() ? "any" : e.username + " @ " + e.step;
        return "Wait LAN: " + this.entries.size() + " peers";
    }

    public String getIcon() {
        return "LAN";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10556("filterByUser", this.filterByUser);
        tag.method_10569("defaultStep", this.defaultStep);
        tag.method_10556("enabled", this.enabled);
        class_2499 list = new class_2499();
        var var3 = this.entries.iterator();
        while (var3.hasNext()) {
            LanStepEntry entry = (WaitForLanStepAction.LanStepEntry)var3.next();
            list.add(entry.toTag());
        }
        tag.method_10566("entries", list);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.filterByUser = tag.method_68566("filterByUser", false);
        this.defaultStep = tag.method_68083("defaultStep", 1);
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
        this.entries.clear();
        if (!tag.method_10545("entries")) { /* goto L138; */ }
        class_2499 list = (class_2499)tag.method_10554("entries").orElse(new class_2499());
        var var3 = list.iterator();
        while (var3.hasNext()) {
            class_2520 el = (class_2520)var3.next();
            if (el instanceof class_2487) {
                class_2487 c = (class_2487)el;
                this.entries.add(WaitForLanStepAction.LanStepEntry.fromTag(c));
            }
        }
    }
}
