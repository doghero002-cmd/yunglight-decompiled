/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class JumpAction
implements MacroAction {
    public int durationTicks = 1;
    public boolean tap = true;
    private boolean enabled = true;

    public JumpAction() {
    }

    public JumpAction(int durationTicks, boolean tap) {
        this.durationTicks = durationTicks;
        this.tap = tap;
    }

    public void execute(class_310 mc) {
        if (mc.field_1690 != null) {
            if (mc.field_1690.field_1903 != null) {
                mc.field_1690.field_1903.method_23481(true);
            }
        }
    }

    public void release(class_310 mc) {
        if (mc.field_1690 != null) {
            if (mc.field_1690.field_1903 != null) {
                mc.field_1690.field_1903.method_23481(false);
            }
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("durationTicks", this.durationTicks);
        tag.method_10556("tap", this.tap);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("durationTicks")) {
            this.durationTicks = tag.method_68083("durationTicks", 1);
        }
        if (tag.method_10545("tap")) {
            this.tap = tag.method_68566("tap", true);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.JUMP;
    }

    public String getDisplayName() {
        return this.tap ? "Jump (tap)" : "Jump (hold " + this.durationTicks + "t)";
    }

    public String getIcon() {
        return "J";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
