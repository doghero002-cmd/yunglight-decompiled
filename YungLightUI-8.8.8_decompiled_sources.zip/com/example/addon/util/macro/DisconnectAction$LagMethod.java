/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum DisconnectAction.LagMethod {
    public static final DisconnectAction.LagMethod CLICK_SLOT = new DisconnectAction.LagMethod("CLICK_SLOT", 0);
    public static final DisconnectAction.LagMethod BOAT_NBT = new DisconnectAction.LagMethod("BOAT_NBT", 1);
    public static final DisconnectAction.LagMethod ENTITY_NBT = new DisconnectAction.LagMethod("ENTITY_NBT", 2);
    private static final /* synthetic */ DisconnectAction.LagMethod[] $VALUES;

    public static DisconnectAction.LagMethod[] values() {
        return (DisconnectAction.LagMethod[])$VALUES.clone();
    }

    public static DisconnectAction.LagMethod valueOf(String name) {
        return (DisconnectAction.LagMethod)Enum.valueOf(DisconnectAction.LagMethod.class, name);
    }

    private DisconnectAction.LagMethod() {
        super(var1, var2);
    }

    static {
        $VALUES = DisconnectAction.LagMethod.$values();
    }
}
