/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class WaitPosAction
implements MacroAction {
    public double x = 0;
    public double y = 0;
    public double z = 0;
    public double leeway = 1;
    public boolean checkRotation = false;
    public float yaw = 0f;
    public float pitch = 0f;
    public float rotLeeway = 5f;
    private boolean enabled = true;

    public WaitPosAction() {
    }

    public WaitPosAction(double x, double y, double z, double leeway) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.leeway = leeway;
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10549("x", this.x);
        tag.method_10549("y", this.y);
        tag.method_10549("z", this.z);
        tag.method_10549("leeway", this.leeway);
        tag.method_10556("checkRotation", this.checkRotation);
        tag.method_10548("yaw", this.yaw);
        tag.method_10548("pitch", this.pitch);
        tag.method_10548("rotLeeway", this.rotLeeway);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("x")) {
            this.x = tag.method_68563("x", 0);
        }
        if (tag.method_10545("y")) {
            this.y = tag.method_68563("y", 0);
        }
        if (tag.method_10545("z")) {
            this.z = tag.method_68563("z", 0);
        }
        if (tag.method_10545("leeway")) {
            this.leeway = tag.method_68563("leeway", 1);
        }
        if (tag.method_10545("checkRotation")) {
            this.checkRotation = tag.method_68566("checkRotation", false);
        }
        if (tag.method_10545("yaw")) {
            this.yaw = tag.method_66563("yaw", 0f);
        }
        if (tag.method_10545("pitch")) {
            this.pitch = tag.method_66563("pitch", 0f);
        }
        if (tag.method_10545("rotLeeway")) {
            this.rotLeeway = tag.method_66563("rotLeeway", 5f);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_POS;
    }

    public String getDisplayName() {
        if (this.checkRotation) {
            return String.format("Wait Pos & Rot (%.0f, %.0f, %.0f)", this.x, this.y, this.z);
        }
        return String.format("Wait Pos (%.0f, %.0f, %.0f) +/-%.1f", this.x, this.y, this.z, this.leeway);
    }

    public String getIcon() {
        return "LOC";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
