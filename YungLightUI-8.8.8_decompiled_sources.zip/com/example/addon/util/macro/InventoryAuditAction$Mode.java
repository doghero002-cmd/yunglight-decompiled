/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum InventoryAuditAction.Mode {
    public static final InventoryAuditAction.Mode DUPE = new InventoryAuditAction.Mode("DUPE", 0);
    public static final InventoryAuditAction.Mode DUPE_SPAM = new InventoryAuditAction.Mode("DUPE_SPAM", 1);
    private static final /* synthetic */ InventoryAuditAction.Mode[] $VALUES;

    public static InventoryAuditAction.Mode[] values() {
        return (InventoryAuditAction.Mode[])$VALUES.clone();
    }

    public static InventoryAuditAction.Mode valueOf(String name) {
        return (InventoryAuditAction.Mode)Enum.valueOf(InventoryAuditAction.Mode.class, name);
    }

    private InventoryAuditAction.Mode() {
        super(var1, var2);
    }

    static {
        $VALUES = InventoryAuditAction.Mode.$values();
    }
}
