/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class GoToAction
implements MacroAction {
    public double x = 0;
    public double y = 0;
    public double z = 0;
    private boolean enabled = true;
    public boolean waitForArrival = false;
    public double arrivalRadius = 2;
    public int timeoutMs = 60000;

    public GoToAction() {
    }

    public GoToAction(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void execute(class_310 mc) {
        if (mc.field_1724 == null) {
            return;
        }
        String command = String.format("#goto %.1f %.1f %.1f", this.x, this.y, this.z);
        if (!PackUtilCompatManager.sendBaritoneCommand(mc, command)) {
            PackUtilClientMessaging.sendPrefixed("Â§cBaritone is not available, cannot send goto command.");
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10549("x", this.x);
        tag.method_10549("y", this.y);
        tag.method_10549("z", this.z);
        tag.method_10556("waitForArrival", this.waitForArrival);
        tag.method_10549("arrivalRadius", this.arrivalRadius);
        tag.method_10569("timeoutMs", this.timeoutMs);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("x")) {
            this.x = tag.method_68563("x", 0);
        }
        if (tag.method_10545("y")) {
            this.y = tag.method_68563("y", 0);
        }
        if (tag.method_10545("z")) {
            this.z = tag.method_68563("z", 0);
        }
        if (tag.method_10545("waitForArrival")) {
            this.waitForArrival = tag.method_68566("waitForArrival", false);
        }
        if (tag.method_10545("arrivalRadius")) {
            this.arrivalRadius = tag.method_68563("arrivalRadius", 2);
        }
        if (tag.method_10545("timeoutMs")) {
            this.timeoutMs = tag.method_68083("timeoutMs", 60000);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.GO_TO;
    }

    public String getDisplayName() {
        return String.format("Go To (%.0f, %.0f, %.0f)%s", this.x, this.y, this.z, this.waitForArrival ? " [W]" : "");
    }

    public String getIcon() {
        return "GO";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
