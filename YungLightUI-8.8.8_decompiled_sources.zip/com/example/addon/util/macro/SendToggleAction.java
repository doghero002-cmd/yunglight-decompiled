/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SendToggleAction
implements MacroAction {
    public SendToggleAction.ToggleMode mode = SendToggleAction.ToggleMode.ENABLE;
    private boolean enabled = true;

    public void cycleMode() {
        this.mode = SendToggleAction.ToggleMode.values()[(this.mode.ordinal() + 1) % SendToggleAction.ToggleMode.values().length];
    }

    public void cycleModeBackwards() {
        this.mode = SendToggleAction.ToggleMode.values()[(this.mode.ordinal() - 1 + SendToggleAction.ToggleMode.values().length) % SendToggleAction.ToggleMode.values().length];
    }

    public void execute(class_310 mc) {
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setSendGuiPackets(this.mode == SendToggleAction.ToggleMode.ENABLE);
    }

    public MacroActionType getType() {
        return MacroActionType.SEND_TOGGLE;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "SEND_TOGGLE");
        tag.method_10582("mode", this.mode.name());
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.mode = SendToggleAction.ToggleMode.valueOf(tag.method_68564("mode", "ENABLE"));
        }
        catch (IllegalArgumentException ignored) {
            this.mode = SendToggleAction.ToggleMode.ENABLE;
            L35: ;
            if (tag.method_10545("enabled")) {
                this.enabled = tag.method_68566("enabled", true);
            }
            return;
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        return this.mode == SendToggleAction.ToggleMode.ENABLE ? "Send Pkts: ON" : "Send Pkts: OFF";
    }

    public String getIcon() {
        return "T";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
