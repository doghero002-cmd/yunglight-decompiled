/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum MoveAction.Direction {
    public static final MoveAction.Direction FORWARD = new MoveAction.Direction("FORWARD", 0);
    public static final MoveAction.Direction BACKWARD = new MoveAction.Direction("BACKWARD", 1);
    public static final MoveAction.Direction LEFT = new MoveAction.Direction("LEFT", 2);
    public static final MoveAction.Direction RIGHT = new MoveAction.Direction("RIGHT", 3);
    private static final /* synthetic */ MoveAction.Direction[] $VALUES;

    public static MoveAction.Direction[] values() {
        return (MoveAction.Direction[])$VALUES.clone();
    }

    public static MoveAction.Direction valueOf(String name) {
        return (MoveAction.Direction)Enum.valueOf(MoveAction.Direction.class, name);
    }

    private MoveAction.Direction() {
        super(var1, var2);
    }

    public String displayName() {
        return this.name().charAt(0) + this.name().substring(1).toLowerCase();
    }

    public MoveAction.Direction next() {
        Direction[] vals = MoveAction.Direction.values();
        return vals[(this.ordinal() + 1) % vals.length];
    }

    static {
        $VALUES = MoveAction.Direction.$values();
    }
}
