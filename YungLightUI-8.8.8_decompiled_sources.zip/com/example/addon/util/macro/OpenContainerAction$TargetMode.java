/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum OpenContainerAction.TargetMode {
    public static final OpenContainerAction.TargetMode BLOCK = new OpenContainerAction.TargetMode("BLOCK", 0);
    public static final OpenContainerAction.TargetMode ENTITY = new OpenContainerAction.TargetMode("ENTITY", 1);
    public static final OpenContainerAction.TargetMode LAST_TARGET = new OpenContainerAction.TargetMode("LAST_TARGET", 2);
    private static final /* synthetic */ OpenContainerAction.TargetMode[] $VALUES;

    public static OpenContainerAction.TargetMode[] values() {
        return (OpenContainerAction.TargetMode[])$VALUES.clone();
    }

    public static OpenContainerAction.TargetMode valueOf(String name) {
        return (OpenContainerAction.TargetMode)Enum.valueOf(OpenContainerAction.TargetMode.class, name);
    }

    private OpenContainerAction.TargetMode() {
        super(var1, var2);
    }

    static {
        $VALUES = OpenContainerAction.TargetMode.$values();
    }
}
