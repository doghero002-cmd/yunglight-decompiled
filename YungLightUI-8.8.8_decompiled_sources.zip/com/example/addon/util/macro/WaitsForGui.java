/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public interface WaitsForGui {
    public boolean isWaitForGui();

    public void setWaitForGui(boolean var1);

    public String getWaitGuiName();

    public void setWaitGuiName(String var1);

    public boolean isWaitForGuiChange() {
        return false;
    }
}
