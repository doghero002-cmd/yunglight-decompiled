/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_437;

static class MacroConditionRegistry.GuiCondition
implements MacroConditionRegistry.PendingCondition {
    final String title;
    final String titleLower;
    final String[] titleWords;
    final class_437 prevScreen;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.GuiCondition(String title, class_437 prevScreen, CompletableFuture<Void> future) {
        this.title = title;
        this.titleLower = title.toLowerCase();
        this.titleWords = this.titleLower.isEmpty() ? new String[0] : this.titleLower.split("\\s+");
        this.prevScreen = prevScreen;
        this.future = future;
    }

    public boolean check(class_310 mc) {
        return this.checkScreen(mc.field_1755);
    }

    public boolean checkScreen(class_437 screen) {
        if (screen == null) {
            return false;
        }
        if (screen == this.prevScreen) {
            return false;
        }
        if (!this.titleLower.isEmpty() && !MacroConditionRegistry.matchesLower(this.titleLower, this.titleWords, screen.method_25440().getString())) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) { /* goto L108; */ }
        if (mc.field_1724.field_7512 == null) { /* goto L108; */ }
        if (mc.field_1724.field_7512 == mc.field_1724.field_7498) { /* goto L108; */ }
        return mc.field_1724.field_7512.method_37421() > 0;
        return true;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
