/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum UseItemAction.UseMode {
    public static final UseItemAction.UseMode AUTOMATIC = new UseItemAction.UseMode("AUTOMATIC", 0);
    public static final UseItemAction.UseMode CUSTOM_HOLD = new UseItemAction.UseMode("CUSTOM_HOLD", 1);
    private static final /* synthetic */ UseItemAction.UseMode[] $VALUES;

    public static UseItemAction.UseMode[] values() {
        return (UseItemAction.UseMode[])$VALUES.clone();
    }

    public static UseItemAction.UseMode valueOf(String name) {
        return (UseItemAction.UseMode)Enum.valueOf(UseItemAction.UseMode.class, name);
    }

    private UseItemAction.UseMode() {
        super(var1, var2);
    }

    static {
        $VALUES = UseItemAction.UseMode.$values();
    }
}
