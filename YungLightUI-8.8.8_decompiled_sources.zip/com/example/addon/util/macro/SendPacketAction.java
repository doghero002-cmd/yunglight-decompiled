/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilClipboardHelper;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketSender;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PacketRegenerator;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2596;
import net.minecraft.class_310;

public class SendPacketAction
implements MacroAction,
WaitsForGui {
    public List<PackUtilSharedState.QueuedPacket> packets = new ArrayList();
    public String customName = "";
    public boolean waitForGui = false;
    public String guiName = "";

    public List<PackUtilSharedState.QueuedPacket> getPackets() {
        return this.packets;
    }

    public void regeneratePackets() {
        List<PackUtilSharedState.QueuedPacket> newPackets = new ArrayList(this.packets.size());
        var var2 = this.packets.iterator();
        while (var2.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var2.next();
            if (qp.packet != null) {
                class_2596<?> regenerated = PacketRegenerator.regenerate(qp.packet);
                if (regenerated == null) continue;
                newPackets.add(new PackUtilSharedState.QueuedPacket(regenerated, qp.getDelay(), qp.getId()));
            }
        }
        this.packets.clear();
        this.packets.addAll(newPackets);
    }

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo network connection!");
            return;
        }
        int successCount = 0;
        int failCount = 0;
        var var4 = this.packets.iterator();
        L35: ;
        if (!var4.hasNext()) { /* goto @106; */ }
        QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var4.next();
        while (qp.packet == null) {
            failCount++;
        }
        try {
            PackUtilPacketSender.sendPacket(qp.packet);
            successCount++;
        }
        catch (Exception e) {
            PackUtilClientMessaging.sendPrefixed("§cSend failed: " + e.getMessage());
            failCount++;
            L103: ;
            /* goto @35; */
            L106: ;
            if (failCount > 0) {
                PackUtilClientMessaging.sendPrefixed(String.format("§eSent %d/%d packets (%d failed)", successCount, this.packets.size(), failCount));
            }
            return;
        }
        /* goto @35; */
        L106: ;
        if (failCount > 0) {
            PackUtilClientMessaging.sendPrefixed(String.format("§eSent %d/%d packets (%d failed)", successCount, this.packets.size(), failCount));
        }
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.guiName;
    }

    public void setWaitGuiName(String name) {
        this.guiName = name;
    }

    public MacroActionType getType() {
        return MacroActionType.SEND_PACKET;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "SEND_PACKET");
        tag.method_10582("customName", this.customName);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        class_2499 packetList = new class_2499();
        var var3 = this.packets.iterator();
        while (var3.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var3.next();
            class_2487 packetTag = PackUtilClipboardHelper.serializeQueuedPacket(qp);
            if (packetTag == null) continue;
            packetList.add(packetTag);
        }
        tag.method_10566("packets", packetList);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.packets.clear();
        this.customName = tag.method_68564("customName", "");
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", false);
        }
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
        if (!tag.method_10545("packets")) { /* goto L146; */ }
        class_2499 packetList = (class_2499)tag.method_10580("packets");
        if (packetList == null) { /* goto L146; */ }
        for (int i = 0; i < packetList.size(); i++) {
            class_2520 element = (class_2520)packetList.get(i);
            if (element instanceof class_2487) {
                QueuedPacket qp = PackUtilClipboardHelper.deserializeQueuedPacket((class_2487)element);
                if (qp == null) continue;
                this.packets.add(qp);
            }
        }
    }

    public String getDisplayName() {
        if (this.customName != null && !this.customName.trim().isEmpty()) {
            return "Send " + this.customName.trim();
        }
        if (this.packets.isEmpty()) {
            return "Send (empty)";
        }
        Map<String, Integer> nameCounts = new LinkedHashMap();
        Map.Entry<String, Integer> entry = this.packets.iterator();
        while (entry.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)entry.next();
            if (qp.packet != null) {
                String name = PackUtilPacketNamer.getFriendlyName(qp.packet);
                nameCounts.merge(name, 1, Integer::sum);
            }
        }
        if (nameCounts.isEmpty()) {
            return "Send (empty)";
        }
        if (nameCounts.size() == 1) {
            entry = (Map.Entry)nameCounts.entrySet().iterator().next();
            pktName = (String)entry.getKey();
            count = ((Integer)entry.getValue()).intValue();
            if (count == 1) {
                return "Send " + pktName;
            }
            return "Send " + pktName + " x" + count;
        }
        return "Send Group (" + this.packets.size() + ")";
    }

    public String getIcon() {
        return "P";
    }
}
