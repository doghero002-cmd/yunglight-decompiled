/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_437;

public class WaitForGuiAction
implements MacroAction {
    public WaitForGuiAction.WaitMode waitMode = WaitForGuiAction.WaitMode.OPEN;
    public String guiTitle = "";
    private boolean enabled = true;

    public MacroActionType getType() {
        return MacroActionType.WAIT_GUI;
    }

    public void execute(class_310 mc) {
    }

    public String getDisplayName() {
        String prefix = this.waitMode == WaitForGuiAction.WaitMode.CLOSE ? "Wait GUI Close: " : "Wait GUI Open: ";
        return prefix + this.guiTitle.isEmpty() ? "(none)" : this.guiTitle;
    }

    public String getIcon() {
        return "GUI";
    }

    public boolean matchesText(String search, String target) {
        if (search.isEmpty() || target.isEmpty()) {
            return false;
        }
        if (search.equals(target)) {
            return true;
        }
        if (target.toLowerCase().contains(search.toLowerCase())) {
            return true;
        }
        String[] searchWords = search.toLowerCase().split("\\s+");
        String[] targetWords = target.toLowerCase().split("\\s+");
        boolean allFound = true;
        var var6 = searchWords;
        var var7 = var6.length;
        int var8 = 0;
        while (var8 < var7) {
            String word = var6[var8];
            boolean found = false;
            var var11 = targetWords;
            var var12 = var11.length;
            int var13 = 0;
            while (var13 < var12) {
                String tWord = var11[var13];
                if (tWord.contains(word)) { /* goto L140; */ }
                if (word.contains(tWord)) {
                    found = true;
                } else {
                    var13++;
                }
            }
            if (!found) {
                allFound = false;
            } else {
                var8++;
            }
        }
        return allFound;
    }

    public boolean checkGui(class_310 mc) {
        if (this.guiTitle.isEmpty()) {
            return false;
        }
        class_437 screen = mc.field_1755;
        if (screen == null) {
            return false;
        }
        String title = screen.method_25440().getString();
        return this.matchesText(this.guiTitle, title);
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("waitMode", this.waitMode.name());
        tag.method_10582("guiTitle", this.guiTitle);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.waitMode = WaitForGuiAction.WaitMode.valueOf(tag.method_68564("waitMode", "OPEN"));
        }
        catch (IllegalArgumentException ignored) {
            this.waitMode = WaitForGuiAction.WaitMode.OPEN;
            L35: ;
            if (tag.method_10545("guiTitle")) {
                this.guiTitle = tag.method_68564("guiTitle", "");
            }
            if (tag.method_10545("enabled")) {
                this.enabled = tag.method_68566("enabled", true);
            }
            return;
        }
        if (tag.method_10545("guiTitle")) {
            this.guiTitle = tag.method_68564("guiTitle", "");
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
