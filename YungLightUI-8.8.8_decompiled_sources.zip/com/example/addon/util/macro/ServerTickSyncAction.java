/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class ServerTickSyncAction
implements MacroAction {
    public int bufferMs = 5;
    public int maxWaitMs = 3000;
    public boolean ignorePing = false;
    public int preGenCount = -1;

    public void execute(class_310 mc) {
    }

    public MacroActionType getType() {
        return MacroActionType.SERVER_TICK_SYNC;
    }

    public String getIcon() {
        return "Srv";
    }

    public String getDisplayName() {
        StringBuilder sb = new StringBuilder("ServerSync");
        sb.append(" buf:").append(this.bufferMs).append("ms");
        if (this.ignorePing) {
            sb.append(" (no ping)");
        }
        if (this.preGenCount > 0) {
            sb.append(" (").append(this.preGenCount).append(" pkts)");
        } else {
            if (this.preGenCount == -1) {
                sb.append(" (all)");
            }
        }
        return sb.toString();
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("bufferMs", this.bufferMs);
        tag.method_10569("maxWaitMs", this.maxWaitMs);
        tag.method_10556("ignorePing", this.ignorePing);
        tag.method_10569("preGenCount", this.preGenCount);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.bufferMs = tag.method_68083("bufferMs", 5);
        this.maxWaitMs = tag.method_68083("maxWaitMs", 3000);
        this.ignorePing = tag.method_68566("ignorePing", false);
        this.preGenCount = tag.method_68083("preGenCount", -1);
    }
}
