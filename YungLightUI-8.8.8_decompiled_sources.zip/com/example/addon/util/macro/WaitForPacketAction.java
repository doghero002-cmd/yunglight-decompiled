/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_310;

public class WaitForPacketAction
implements MacroAction {
    public static final String C2S_PREFIX = "C2S:";
    public static final String S2C_PREFIX = "S2C:";
    public String packetName = "";
    public List<String> packetNames = new ArrayList();
    private boolean enabled = true;

    public WaitForPacketAction() {
    }

    public WaitForPacketAction(String packetName) {
        this.packetName = packetName;
    }

    public static String getDirection(String target) {
        if (target == null) {
            return "";
        }
        String trimmed = target.trim();
        if (trimmed.regionMatches(true, 0, "C2S:", 0, "C2S:".length())) {
            return "C2S";
        }
        if (trimmed.regionMatches(true, 0, "S2C:", 0, "S2C:".length())) {
            return "S2C";
        }
        return "";
    }

    public static String getPacketName(String target) {
        if (target == null) {
            return "";
        }
        String trimmed = target.trim();
        if (trimmed.regionMatches(true, 0, "C2S:", 0, "C2S:".length())) {
            return trimmed.substring("C2S:".length()).trim();
        }
        if (trimmed.regionMatches(true, 0, "S2C:", 0, "S2C:".length())) {
            return trimmed.substring("S2C:".length()).trim();
        }
        return trimmed;
    }

    public static String normalizeTarget(String target) {
        String direction = WaitForPacketAction.getDirection(target);
        String packet = WaitForPacketAction.getPacketName(target);
        if (packet.isEmpty()) {
            return "";
        }
        return direction.isEmpty() ? packet : direction + ":" + packet;
    }

    public static String withDirection(String direction, String packetName) {
        String packet = WaitForPacketAction.getPacketName(packetName);
        if (packet.isEmpty()) {
            return "";
        }
        if ("C2S".equalsIgnoreCase(direction)) {
            return "C2S:" + packet;
        }
        if ("S2C".equalsIgnoreCase(direction)) {
            return "S2C:" + packet;
        }
        return packet;
    }

    public static String getDisplayLabel(String target) {
        String packet = WaitForPacketAction.getPacketName(target);
        String friendly = PackUtilPacketNamer.getFriendlyName(packet);
        String direction = WaitForPacketAction.getDirection(target);
        return direction.isEmpty() ? friendly : direction + " " + friendly;
    }

    public List<String> effectiveList() {
        if (this.packetNames.isEmpty()) { /* goto L86; */ }
        List<String> normalized = new ArrayList();
        var var2 = this.packetNames.iterator();
        while (var2.hasNext()) {
            String target = (String)var2.next();
            String safe = WaitForPacketAction.normalizeTarget(target);
            if (safe.isEmpty()) continue;
            normalized.add(safe);
        }
        if (!normalized.isEmpty()) {
            return normalized;
        }
        legacy = WaitForPacketAction.normalizeTarget(this.packetName);
        if (!legacy.isEmpty()) {
            return Collections.singletonList(legacy);
        }
        return Collections.emptyList();
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("packetName", this.packetName);
        tag.method_10556("enabled", this.enabled);
        class_2499 list = new class_2499();
        var var3 = this.packetNames.iterator();
        while (var3.hasNext()) {
            String n = (String)var3.next();
            list.add(class_2519.method_23256(n));
        }
        tag.method_10566("packetNames", list);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("packetName")) {
            this.packetName = tag.method_68564("packetName", "");
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
        this.packetNames.clear();
        if (!tag.method_10545("packetNames")) { /* goto L112; */ }
        class_2499 list = (class_2499)tag.method_10580("packetNames");
        if (list == null) { /* goto L112; */ }
        for (int i = 0; i < list.size(); i++) {
            this.packetNames.add((String)list.method_10608(i).orElse(""));
        }
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_PACKET;
    }

    public String getDisplayName() {
        List<String> eff = this.effectiveList();
        if (eff.isEmpty()) {
            return "Wait Pkt: Any";
        }
        if (eff.size() == 1) {
            return "Wait Pkt: " + WaitForPacketAction.getDisplayLabel((String)eff.get(0));
        }
        Map<String, Integer> counts = new LinkedHashMap();
        String n = eff.iterator();
        while (n.hasNext()) {
            String n = (String)n.next();
            counts.merge(n, 1, Integer::sum);
        }
        if (counts.size() == 1) {
            n = (String)counts.keySet().iterator().next();
            c = ((Integer)counts.get(n)).intValue();
            return "Wait Pkt: " + WaitForPacketAction.getDisplayLabel(n) + " x" + c;
        }
        return "Wait Pkts (" + eff.size() + ")";
    }

    public String getIcon() {
        return "Ptk";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
