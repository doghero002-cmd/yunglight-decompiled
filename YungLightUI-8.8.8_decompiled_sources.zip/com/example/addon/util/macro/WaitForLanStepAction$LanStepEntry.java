/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import net.minecraft.class_2487;

public static class WaitForLanStepAction.LanStepEntry {
    public String username = "";
    public int step = 1;

    public WaitForLanStepAction.LanStepEntry() {
    }

    public WaitForLanStepAction.LanStepEntry(String username, int step) {
        this.username = username != null ? username : "";
        this.step = Math.max(1, step);
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("username", this.username);
        tag.method_10569("step", this.step);
        return tag;
    }

    public static WaitForLanStepAction.LanStepEntry fromTag(class_2487 tag) {
        LanStepEntry e = new WaitForLanStepAction.LanStepEntry();
        e.username = tag.method_68564("username", "");
        e.step = tag.method_68083("step", 1);
        return e;
    }

    public String getDisplayName() {
        return this.username.isEmpty() ? "Any" : this.username + " @ step " + this.step;
    }
}
