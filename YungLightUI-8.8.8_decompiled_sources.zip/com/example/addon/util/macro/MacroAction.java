/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public interface MacroAction {
    public void execute(class_310 var1);

    public class_2487 toTag();

    public void fromTag(class_2487 var1);

    public MacroActionType getType();

    public String getDisplayName();

    public String getIcon();

    public boolean isEnabled() {
        return true;
    }

    public void setEnabled(boolean enabled) {
    }
}
