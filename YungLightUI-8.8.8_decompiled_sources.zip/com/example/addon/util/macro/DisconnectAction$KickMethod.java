/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum DisconnectAction.KickMethod {
    public static final DisconnectAction.KickMethod HURT = new DisconnectAction.KickMethod("HURT", 0);
    public static final DisconnectAction.KickMethod CLIENT_SETTINGS = new DisconnectAction.KickMethod("CLIENT_SETTINGS", 1);
    public static final DisconnectAction.KickMethod INVALID_SLOT = new DisconnectAction.KickMethod("INVALID_SLOT", 2);
    private static final /* synthetic */ DisconnectAction.KickMethod[] $VALUES;

    public static DisconnectAction.KickMethod[] values() {
        return (DisconnectAction.KickMethod[])$VALUES.clone();
    }

    public static DisconnectAction.KickMethod valueOf(String name) {
        return (DisconnectAction.KickMethod)Enum.valueOf(DisconnectAction.KickMethod.class, name);
    }

    private DisconnectAction.KickMethod() {
        super(var1, var2);
    }

    static {
        $VALUES = DisconnectAction.KickMethod.$values();
    }
}
