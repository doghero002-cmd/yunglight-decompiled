/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroExecutor;
import net.minecraft.class_2561;

public static final record MacroExecutor.RecentChatMessage {
    private final String sender;
    private final String message;
    private final String displayText;
    private final class_2561 displayComponent;
    private final MacroExecutor.ChatSource source;
    private final long timestampMs;

    public MacroExecutor.RecentChatMessage(String sender, String message, String displayText, class_2561 displayComponent, MacroExecutor.ChatSource source, long timestampMs) {
        this.sender = sender;
        this.message = message;
        this.displayText = displayText;
        this.displayComponent = displayComponent;
        this.source = source;
        this.timestampMs = timestampMs;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String sender() {
        return this.sender;
    }

    public String message() {
        return this.message;
    }

    public String displayText() {
        return this.displayText;
    }

    public class_2561 displayComponent() {
        return this.displayComponent;
    }

    public MacroExecutor.ChatSource source() {
        return this.source;
    }

    public long timestampMs() {
        return this.timestampMs;
    }
}
