/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1799;
import net.minecraft.class_310;

static class MacroConditionRegistry.ItemCondition
implements MacroConditionRegistry.PendingCondition {
    final ItemTarget target;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.ItemCondition(ItemTarget target, CompletableFuture<Void> future) {
        this.target = target == null ? new ItemTarget() : target.copy();
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1724 == null || !this.target.hasIdentity()) {
            return false;
        }
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() && this.target.matches(stack, i)) continue;
            return true;
        }
        return false;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
