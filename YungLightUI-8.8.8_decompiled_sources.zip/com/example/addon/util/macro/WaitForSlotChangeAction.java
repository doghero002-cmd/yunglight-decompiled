/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.StoreItemAction;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class WaitForSlotChangeAction
implements MacroAction {
    public List<WaitForSlotChangeAction.WaitEntry> entries = new ArrayList();
    private boolean enabled = true;

    public WaitForSlotChangeAction() {
    }

    public WaitForSlotChangeAction(int slotNumber) {
        WaitEntry entry = new WaitForSlotChangeAction.WaitEntry();
        entry.target = slotNumber >= 0 ? "#" + slotNumber : "";
        entry.itemTarget = ItemTarget.fromLegacyEntry(entry.target);
        this.entries.add(entry);
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        class_2499 list = new class_2499();
        var var3 = this.entries.iterator();
        while (var3.hasNext()) {
            WaitEntry entry = (WaitForSlotChangeAction.WaitEntry)var3.next();
            class_2487 entryTag = new class_2487();
            ItemTarget target = entry.resolvedTarget();
            if (!target.hasSlot() || target.hasIdentity()) continue;
            entryTag.method_10566("target", target.toTag());
            entryTag.method_10582("mode", entry.waitMode.name());
            entryTag.method_10569("count", entry.targetCount);
            list.add(entryTag);
        }
        tag.method_10566("entries", list);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.entries.clear();
        if (tag.method_10545("entries")) {
            class_2499 list = (class_2499)tag.method_10554("entries").orElse(new class_2499());
            int globalCount = list.iterator();
            L43: ;
            if (globalCount.hasNext()) {
                class_2520 element = (class_2520)globalCount.next();
                if (!element instanceof class_2487) { /* goto @43; */ }
                class_2487 entryTag = (class_2487)element;
                WaitEntry entry = new WaitForSlotChangeAction.WaitEntry();
                entry.itemTarget = (ItemTarget)entryTag.method_10562("target").map(ItemTarget::fromTag).orElseGet(WaitForSlotChangeAction::lambda$fromTag$0 /* captured: entryTag */);
                entry.target = entry.itemTarget.toLegacyEntry();
                entry.targetCount = entryTag.method_68083("count", 1);
            }
        }
        try {
            entry.waitMode = WaitForSlotChangeAction.WaitMode.valueOf(entryTag.method_68564("mode", "NOT_EMPTY"));
        }
        catch (IllegalArgumentException ignored) {
            entry.waitMode = WaitForSlotChangeAction.WaitMode.NOT_EMPTY;
            L176: ;
            this.entries.add(entry);
            /* goto @43; */
            L191: ;
            /* goto @541; */
        }
        this.entries.add(entry);
        /* goto @43; */
        L191: ;
        /* goto @541; */
        L194: ;
        globalMode = WaitForSlotChangeAction.WaitMode.NOT_EMPTY;
        globalCount = 1;
        try {
            mode = tag.method_68564("waitMode", "NOT_EMPTY");
            if ("HAS_ITEM".equals(mode)) {
                mode = "NOT_EMPTY";
            }
            globalMode = WaitForSlotChangeAction.WaitMode.valueOf(mode);
        }
        catch (IllegalArgumentException list) {
            if (tag.method_10545("targetCount")) {
                globalCount = tag.method_68083("targetCount", 1);
            }
            if (!tag.method_10545("targetEntries")) { /* goto @378; */ }
            list = (class_2499)tag.method_10554("targetEntries").orElse(new class_2499());
            scope = list.iterator();
            L298: ;
            if (!scope.hasNext()) { /* goto @375; */ }
            element = (class_2520)scope.next();
            value = ((String)element.method_68658().orElse("")).strip();
            while (value.isBlank()) {
            }
        }
        if (tag.method_10545("targetCount")) {
            globalCount = tag.method_68083("targetCount", 1);
        }
        if (tag.method_10545("targetEntries")) {
            list = (class_2499)tag.method_10554("targetEntries").orElse(new class_2499());
            scope = list.iterator();
            while (scope.hasNext()) {
                element = (class_2520)scope.next();
                value = ((String)element.method_68658().orElse("")).strip();
                while (value.isBlank()) {
                }
                this.entries.add(new WaitForSlotChangeAction.WaitEntry(value, globalMode, globalCount));
            }
        } else {
            slotSpecific = true;
            if (!tag.method_10545("scope")) { /* goto L432; */ }
            scope = tag.method_68564("scope", "HANDLER_SLOT");
            slotSpecific = "SLOT".equals(scope) || "HANDLER_SLOT".equals(scope);
            slotNumber = tag.method_10545("slotNumber") && slotSpecific ? tag.method_68083("slotNumber", -1) : -1;
            itemName = tag.method_68564("itemName", "");
            if (slotNumber >= 0) {
                if (!itemName.isEmpty()) {
                    target = "#" + slotNumber + "|" + itemName;
                }
            } else {
                if (slotNumber >= 0) {
                    target = "#" + slotNumber;
                } else {
                    target = itemName;
                }
            }
            this.entries.add(new WaitForSlotChangeAction.WaitEntry(target, globalMode, globalCount));
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public void fromTagLegacyItem(class_2487 tag) {
        this.entries.clear();
        String itemName = tag.method_68564("itemName", "");
        boolean useSlot = tag.method_10545("useSlot") && tag.method_68566("useSlot", false);
        int targetSlot = tag.method_10545("targetSlot") ? tag.method_68083("targetSlot", -1) : -1;
        int slotNumber = useSlot && targetSlot >= 0 ? targetSlot : -1;
        if (slotNumber >= 0) {
            if (!itemName.isEmpty()) {
                String target = "#" + slotNumber + "|" + itemName;
            }
        } else {
            if (slotNumber >= 0) {
                String target = "#" + slotNumber;
            } else {
                String target = itemName;
            }
        }
        this.entries.add(new WaitForSlotChangeAction.WaitEntry(target, WaitForSlotChangeAction.WaitMode.NOT_EMPTY, 1));
        this.enabled = true;
    }

    public void execute(class_310 mc) {
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_SLOT_CHANGE;
    }

    public String getDisplayName() {
        if (this.entries.isEmpty()) {
            return "Wait Slot (empty)";
        }
        if (this.entries.size() != 1) { /* goto L88; */ }
        WaitEntry entry = (WaitForSlotChangeAction.WaitEntry)this.entries.get(0);
        String display = StoreItemAction.formatTargetEntry(entry.target.isEmpty() ? "" : entry.target);
        if (display.isEmpty()) {
            display = "any slot";
        }
        return "Wait " + display + " " + entry.modeLabel();
        L88: ;
        return "Wait all(" + this.entries.size() + ")";
    }

    public String getIcon() {
        return "WSL";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
