/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

static final class XCarryAction.PutInMove {
    final int sourceSlotId;
    final int targetSlotId;

    XCarryAction.PutInMove(int sourceSlotId, int targetSlotId) {
        this.sourceSlotId = sourceSlotId;
        this.targetSlotId = targetSlotId;
    }
}
