/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum DisconnectAction.AutoTrigger {
    public static final DisconnectAction.AutoTrigger TELEPORT = new DisconnectAction.AutoTrigger("TELEPORT", 0);
    public static final DisconnectAction.AutoTrigger POSITION = new DisconnectAction.AutoTrigger("POSITION", 1);
    public static final DisconnectAction.AutoTrigger WORLD_CHANGE = new DisconnectAction.AutoTrigger("WORLD_CHANGE", 2);
    public static final DisconnectAction.AutoTrigger GUI_CLOSE = new DisconnectAction.AutoTrigger("GUI_CLOSE", 3);
    public static final DisconnectAction.AutoTrigger INVENTORY_CLEAR = new DisconnectAction.AutoTrigger("INVENTORY_CLEAR", 4);
    private static final /* synthetic */ DisconnectAction.AutoTrigger[] $VALUES;

    public static DisconnectAction.AutoTrigger[] values() {
        return (DisconnectAction.AutoTrigger[])$VALUES.clone();
    }

    public static DisconnectAction.AutoTrigger valueOf(String name) {
        return (DisconnectAction.AutoTrigger)Enum.valueOf(DisconnectAction.AutoTrigger.class, name);
    }

    private DisconnectAction.AutoTrigger() {
        super(var1, var2);
    }

    static {
        $VALUES = DisconnectAction.AutoTrigger.$values();
    }
}
