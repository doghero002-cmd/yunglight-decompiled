/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum StoreItemAction.Mode {
    public static final StoreItemAction.Mode LOOT = new StoreItemAction.Mode("LOOT", 0);
    public static final StoreItemAction.Mode STORE = new StoreItemAction.Mode("STORE", 1);
    private static final /* synthetic */ StoreItemAction.Mode[] $VALUES;

    public static StoreItemAction.Mode[] values() {
        return (StoreItemAction.Mode[])$VALUES.clone();
    }

    public static StoreItemAction.Mode valueOf(String name) {
        return (StoreItemAction.Mode)Enum.valueOf(StoreItemAction.Mode.class, name);
    }

    private StoreItemAction.Mode() {
        super(var1, var2);
    }

    static {
        $VALUES = StoreItemAction.Mode.$values();
    }
}
