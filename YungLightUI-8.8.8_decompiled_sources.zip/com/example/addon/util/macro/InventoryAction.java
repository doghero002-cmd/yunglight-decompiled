/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class InventoryAction
implements MacroAction,
WaitsForGui {
    public InventoryAction.InvMode mode = InventoryAction.InvMode.OPEN;
    public boolean waitForGui = true;
    public String guiName = "";
    public boolean sendPacket = true;

    public void execute(class_310 mc) {
        if (mc.field_1724 == null) {
            return;
        }
        if (this.mode == InventoryAction.InvMode.OPEN) {
            mc.execute(InventoryAction::lambda$execute$0 /* captured: mc */);
        } else {
            mc.execute(this::lambda$execute$1 /* captured: mc */);
        }
    }

    public boolean isWaitForGui() {
        return this.mode == InventoryAction.InvMode.OPEN && this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return "";
    }

    public void setWaitGuiName(String name) {
        this.guiName = "";
    }

    public MacroActionType getType() {
        return MacroActionType.INVENTORY;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "INVENTORY");
        tag.method_10582("mode", this.mode.name());
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        tag.method_10556("sendPacket", this.sendPacket);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.mode = InventoryAction.InvMode.valueOf(tag.method_68564("mode", "OPEN"));
        }
        catch (IllegalArgumentException ignored) {
            this.mode = InventoryAction.InvMode.OPEN;
            L35: ;
            if (tag.method_10545("waitForGui")) {
                this.waitForGui = tag.method_68566("waitForGui", true);
            }
            if (tag.method_10545("guiName")) {
                this.guiName = tag.method_68564("guiName", "");
            }
            if (tag.method_10545("sendPacket")) {
                this.sendPacket = tag.method_68566("sendPacket", true);
            }
            return;
        }
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", true);
        }
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
        if (tag.method_10545("sendPacket")) {
            this.sendPacket = tag.method_68566("sendPacket", true);
        }
    }

    public String getDisplayName() {
        if (this.mode == InventoryAction.InvMode.OPEN) {
            return "Inv Open";
        }
        return this.sendPacket ? "Inv Close" : "Inv Close (no pkt)";
    }

    public String getIcon() {
        return "I";
    }
}
