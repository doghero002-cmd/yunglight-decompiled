/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class RotateAction
implements MacroAction {
    public float yaw;
    public float pitch;
    public boolean smooth;
    public int smoothness = 6;
    public boolean waitForCompletion = true;

    public RotateAction() {
    }

    public RotateAction(float yaw, float pitch, boolean smooth, int smoothness) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.smooth = smooth;
        this.smoothness = RotateAction.clampSmoothness(smoothness);
    }

    public static int clampSmoothness(int value) {
        return Math.max(1, Math.min(10, value));
    }

    public static double smoothnessToRotationStep(int smoothness) {
        double minStep = 0.5;
        double maxStep = 9.05;
        double normalized = (10 - (double)RotateAction.clampSmoothness(smoothness)) / 9;
        return minStep * Math.pow(maxStep / minStep, normalized);
    }

    public double getRotationStep() {
        return RotateAction.smoothnessToRotationStep(this.smoothness);
    }

    public void execute(class_310 mc) {
        mc.field_1724.method_36456(this.yaw);
        if (mc.field_1724 != null && !this.smooth) {
            mc.field_1724.method_36457(this.pitch);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.ROTATE;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10548("yaw", this.yaw);
        tag.method_10548("pitch", this.pitch);
        tag.method_10556("smooth", this.smooth);
        tag.method_10569("smoothness", RotateAction.clampSmoothness(this.smoothness));
        tag.method_10556("waitForCompletion", this.waitForCompletion);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("yaw")) {
            this.yaw = tag.method_66563("yaw", 0f);
        }
        if (tag.method_10545("pitch")) {
            this.pitch = tag.method_66563("pitch", 0f);
        }
        if (tag.method_10545("smooth")) {
            this.smooth = tag.method_68566("smooth", false);
        }
        if (tag.method_10545("smoothness")) {
            this.smoothness = RotateAction.clampSmoothness(tag.method_68083("smoothness", 6));
        } else {
            this.smoothness = 6;
        }
        if (tag.method_10545("waitForCompletion")) {
            this.waitForCompletion = tag.method_68566("waitForCompletion", true);
        } else {
            this.waitForCompletion = true;
        }
    }

    public String getDisplayName() {
        String suffix = this.smooth ? " (Smooth)" : "";
        if (!this.waitForCompletion) {
            suffix = suffix + " [NoWait]";
        }
        return String.format("Rot %.1f / %.1f%s", this.yaw, this.pitch, suffix);
    }

    public String getIcon() {
        return "R";
    }
}
