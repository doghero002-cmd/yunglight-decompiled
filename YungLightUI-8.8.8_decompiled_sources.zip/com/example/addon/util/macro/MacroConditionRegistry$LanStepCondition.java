/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.WaitForLanStepAction;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;

static class MacroConditionRegistry.LanStepCondition
implements MacroConditionRegistry.PendingCondition {
    final WaitForLanStepAction action;
    final CompletableFuture<Void> future;
    private volatile boolean cancelled = false;

    MacroConditionRegistry.LanStepCondition(WaitForLanStepAction action, CompletableFuture<Void> future) {
        this.action = action;
        this.future = future;
    }

    boolean checkNow() {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        if (!sync.isInSession()) {
            return true;
        }
        String myUsername = sync.getMyUsername();
        Map<String, Integer> steps = sync.getAllPeerSteps();
        if (!this.action.filterByUser) {
            return this.anyOtherPeerReached(steps, myUsername, this.action.defaultStep);
        }
        if (this.action.entries.isEmpty()) {
            return this.anyOtherPeerReached(steps, myUsername, this.action.defaultStep);
        }
        int peerCount = sync.getConnectedCount();
        var var5 = this.action.entries.iterator();
        while (var5.hasNext()) {
            LanStepEntry req = (WaitForLanStepAction.LanStepEntry)var5.next();
            String targetUser = req.username;
            if (peerCount > 2) { /* goto L214; */ }
            if (targetUser.isEmpty()) { /* goto L214; */ }
            boolean nameExists = false;
            int peerStep = steps.keySet().iterator();
            while (peerStep.hasNext()) {
                String name = (String)peerStep.next();
                if (!name.equals(targetUser)) { /* goto @202; */ }
                if (name.equals(myUsername)) { /* goto @202; */ }
                nameExists = true;
                break;
            }
            if (!nameExists) {
                targetUser = "";
            }
            if (targetUser.isEmpty()) {
                anyReached = false;
                peerStep = steps.entrySet().iterator();
                while (peerStep.hasNext()) {
                    entry = (Map.Entry)peerStep.next();
                    while (((String)entry.getKey()).equals(myUsername)) {
                    }
                    if (((Integer)entry.getValue()).intValue() < req.step) { /* goto @307; */ }
                    anyReached = true;
                    break;
                }
                if (!anyReached) {
                    return false;
                }
            } else {
                clients = sync.getConnectedClients();
                while (!clients.containsKey(targetUser)) {
                }
                peerStep = ((Integer)steps.getOrDefault(targetUser, 0)).intValue();
                if (peerStep < req.step) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean anyOtherPeerReached(Map<String, Integer> steps, String myUsername, int targetStep) {
        var var4 = steps.entrySet().iterator();
        while (var4.hasNext()) {
            Map.Entry<String, Integer> entry = (Map.Entry)var4.next();
            while (((String)entry.getKey()).equals(myUsername)) {
            }
            if (!((Integer)entry.getValue()).intValue() >= targetStep) continue;
            return true;
        }
        return false;
    }

    public boolean check(class_310 mc) {
        return this.checkNow();
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.cancelled = true;
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.cancelled || this.future.isCancelled();
    }
}
