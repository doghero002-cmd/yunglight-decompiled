/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SneakAction
implements MacroAction {
    public boolean sneak = true;
    private boolean enabled = true;
    public boolean persistent = false;

    public SneakAction() {
    }

    public SneakAction(boolean sneak) {
        this.sneak = sneak;
    }

    public void execute(class_310 mc) {
        if (mc.field_1690 != null) {
            if (mc.field_1690.field_1832 != null) {
                mc.field_1690.field_1832.method_23481(this.sneak);
            }
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10556("sneak", this.sneak);
        tag.method_10556("persistent", this.persistent);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("sneak")) {
            this.sneak = tag.method_68566("sneak", true);
        }
        if (tag.method_10545("persistent")) {
            this.persistent = tag.method_68566("persistent", false);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.SNEAK;
    }

    public String getDisplayName() {
        return "Sneak: " + this.sneak ? "ON" : "OFF" + this.persistent ? " [P]" : "";
    }

    public String getIcon() {
        return "SNK";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
