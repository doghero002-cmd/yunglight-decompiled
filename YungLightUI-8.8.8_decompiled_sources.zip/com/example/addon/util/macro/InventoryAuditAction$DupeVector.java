/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum InventoryAuditAction.DupeVector {
    public static final InventoryAuditAction.DupeVector DESYNC_REOPEN = new InventoryAuditAction.DupeVector("DESYNC_REOPEN", 0);
    public static final InventoryAuditAction.DupeVector CLOSE_NO_PACKET = new InventoryAuditAction.DupeVector("CLOSE_NO_PACKET", 1);
    public static final InventoryAuditAction.DupeVector SHIFT_CLICK_REOPEN = new InventoryAuditAction.DupeVector("SHIFT_CLICK_REOPEN", 2);
    public static final InventoryAuditAction.DupeVector DELAYED_PACKETS = new InventoryAuditAction.DupeVector("DELAYED_PACKETS", 3);
    public static final InventoryAuditAction.DupeVector SWAP_HOTBAR = new InventoryAuditAction.DupeVector("SWAP_HOTBAR", 4);
    public static final InventoryAuditAction.DupeVector DROP_EXPLOIT = new InventoryAuditAction.DupeVector("DROP_EXPLOIT", 5);
    public static final InventoryAuditAction.DupeVector DELAYED_DESYNC_REOPEN = new InventoryAuditAction.DupeVector("DELAYED_DESYNC_REOPEN", 6);
    public static final InventoryAuditAction.DupeVector SWAP_DESYNC_REOPEN = new InventoryAuditAction.DupeVector("SWAP_DESYNC_REOPEN", 7);
    public static final InventoryAuditAction.DupeVector DROP_DELAYED_PACKETS = new InventoryAuditAction.DupeVector("DROP_DELAYED_PACKETS", 8);
    private static final /* synthetic */ InventoryAuditAction.DupeVector[] $VALUES;

    public static InventoryAuditAction.DupeVector[] values() {
        return (InventoryAuditAction.DupeVector[])$VALUES.clone();
    }

    public static InventoryAuditAction.DupeVector valueOf(String name) {
        return (InventoryAuditAction.DupeVector)Enum.valueOf(InventoryAuditAction.DupeVector.class, name);
    }

    private InventoryAuditAction.DupeVector() {
        super(var1, var2);
    }

    static {
        $VALUES = InventoryAuditAction.DupeVector.$values();
    }
}
