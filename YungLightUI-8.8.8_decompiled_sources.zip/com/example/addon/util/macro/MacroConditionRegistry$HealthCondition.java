/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;

static class MacroConditionRegistry.HealthCondition
implements MacroConditionRegistry.PendingCondition {
    final float threshold;
    final boolean below;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.HealthCondition(float threshold, boolean below, CompletableFuture<Void> future) {
        this.threshold = threshold;
        this.below = below;
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1724 == null) {
            return false;
        }
        float health = mc.field_1724.method_6032();
        return this.below ? health < this.threshold : health > this.threshold;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
