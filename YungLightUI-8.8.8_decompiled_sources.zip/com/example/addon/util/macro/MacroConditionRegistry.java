/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroExecutor;
import com.example.addon.util.macro.WaitForBlockAction;
import com.example.addon.util.macro.WaitForEntityAction;
import com.example.addon.util.macro.WaitForLanStepAction;
import com.example.addon.util.macro.WaitForSlotChangeAction;
import com.example.addon.util.macro.WaitForSoundAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_437;

public class MacroConditionRegistry {
    private static final CopyOnWriteArrayList<MacroConditionRegistry.PendingCondition> pendingConditions = new CopyOnWriteArrayList();

    public static CompletableFuture<Void> waitForGui(String guiTitle) {
        class_310 mc = class_310.method_1551();
        CompletableFuture<Void> future = new CompletableFuture();
        GuiCondition condition = new MacroConditionRegistry.GuiCondition(guiTitle, mc.field_1755, future);
        pendingConditions.add(condition);
        return future;
    }

    public static CompletableFuture<Void> waitForGuiClose(String guiTitle) {
        CompletableFuture<Void> future = new CompletableFuture();
        pendingConditions.add(new MacroConditionRegistry.GuiCloseCondition(guiTitle, future));
        return future;
    }

    public static CompletableFuture<Void> waitForGuiChange(class_437 prevScreen) {
        CompletableFuture<Void> future = new CompletableFuture();
        pendingConditions.add(new MacroConditionRegistry.GuiChangeCondition(prevScreen, future));
        return future;
    }

    public static CompletableFuture<Void> waitForItem(String itemName) {
        return MacroConditionRegistry.waitForItem(ItemTarget.fromLegacyEntry(itemName));
    }

    public static CompletableFuture<Void> waitForItem(ItemTarget target) {
        CompletableFuture<Void> future = new CompletableFuture();
        ItemCondition condition = new MacroConditionRegistry.ItemCondition(target, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForHealth(float threshold, boolean below) {
        CompletableFuture<Void> future = new CompletableFuture();
        HealthCondition condition = new MacroConditionRegistry.HealthCondition(threshold, below, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForBlock(WaitForBlockAction action) {
        CompletableFuture<Void> future = new CompletableFuture();
        BlockCondition condition = new MacroConditionRegistry.BlockCondition(action, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForCooldown(String itemName, boolean checkMainHand) {
        return MacroConditionRegistry.waitForCooldown(ItemTarget.fromLegacyEntry(itemName), checkMainHand);
    }

    public static CompletableFuture<Void> waitForCooldown(ItemTarget target, boolean checkMainHand) {
        CompletableFuture<Void> future = new CompletableFuture();
        CooldownCondition condition = new MacroConditionRegistry.CooldownCondition(target, checkMainHand, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForPos(double x, double y, double z, double leeway, boolean checkRotation, float yaw, float pitch, float rotLeeway) {
        CompletableFuture<Void> future = new CompletableFuture();
        WaitPosCondition condition = new MacroConditionRegistry.WaitPosCondition(x, y, z, leeway, checkRotation, yaw, pitch, rotLeeway, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForNextTick() {
        CompletableFuture<Void> future = new CompletableFuture();
        TickSyncCondition condition = new MacroConditionRegistry.TickSyncCondition(future);
        pendingConditions.add(condition);
        return future;
    }

    public static void onInventorySync(class_310 mc) {
        if (pendingConditions.isEmpty()) {
            return;
        }
        class_437 current = mc.field_1755;
        List<MacroConditionRegistry.PendingCondition> toRemove = new ArrayList();
        var var3 = pendingConditions.iterator();
        while (var3.hasNext()) {
            PendingCondition cond = (MacroConditionRegistry.PendingCondition)var3.next();
            while (cond.isCancelled()) {
                toRemove.add(cond);
            }
            if (cond instanceof MacroConditionRegistry.GuiCondition) {
                GuiCondition gc = (MacroConditionRegistry.GuiCondition)cond;
                if (current != null) {
                    if (gc.checkScreen(current)) {
                        gc.complete();
                        toRemove.add(gc);
                    }
                }
            } else {
                if (cond instanceof MacroConditionRegistry.HandlerItemCondition) {
                    HandlerItemCondition hic = (MacroConditionRegistry.HandlerItemCondition)cond;
                    if (hic.check(mc)) {
                        hic.complete();
                        toRemove.add(hic);
                    }
                } else {
                    if (cond instanceof MacroConditionRegistry.SlotChangeCondition) {
                        SlotChangeCondition scc = (MacroConditionRegistry.SlotChangeCondition)cond;
                        if (scc.check(mc)) {
                            scc.complete();
                            toRemove.add(scc);
                        }
                    }
                }
            }
        }
        pendingConditions.removeAll(toRemove);
    }

    public static void onSlotUpdate(int slot) {
        if (pendingConditions.isEmpty()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        List<MacroConditionRegistry.PendingCondition> toRemove = new ArrayList();
        var var3 = pendingConditions.iterator();
        while (var3.hasNext()) {
            PendingCondition cond = (MacroConditionRegistry.PendingCondition)var3.next();
            while (cond.isCancelled()) {
                toRemove.add(cond);
            }
            if (cond instanceof MacroConditionRegistry.SlotChangeCondition) {
                SlotChangeCondition scc = (MacroConditionRegistry.SlotChangeCondition)cond;
                if (scc.check(mc)) {
                    scc.complete();
                    toRemove.add(scc);
                }
            } else {
                if (cond instanceof MacroConditionRegistry.HandlerItemCondition) {
                    HandlerItemCondition hic = (MacroConditionRegistry.HandlerItemCondition)cond;
                    if (hic.check(mc)) {
                        hic.complete();
                        toRemove.add(hic);
                    }
                }
            }
        }
        pendingConditions.removeAll(toRemove);
    }

    public static void onTick(class_310 mc) {
        if (pendingConditions.isEmpty()) {
            return;
        }
        List<MacroConditionRegistry.PendingCondition> toRemove = new ArrayList();
        var var2 = pendingConditions.iterator();
        L25: ;
        if (!var2.hasNext()) { /* goto @110; */ }
        PendingCondition cond = (MacroConditionRegistry.PendingCondition)var2.next();
        while (cond.isCancelled()) {
            toRemove.add(cond);
        }
        try {
            if (cond.check(mc)) {
                cond.complete();
                toRemove.add(cond);
            }
        }
        catch (Exception e) {
            cond.cancel();
            toRemove.add(cond);
            L107: ;
            /* goto @25; */
            L110: ;
            pendingConditions.removeAll(toRemove);
            return;
        }
        /* goto @25; */
        L110: ;
        pendingConditions.removeAll(toRemove);
    }

    public static void onScreenChange(class_437 screen) {
        if (pendingConditions.isEmpty()) {
            return;
        }
        List<MacroConditionRegistry.PendingCondition> toRemove = new ArrayList();
        var var2 = pendingConditions.iterator();
        while (var2.hasNext()) {
            PendingCondition cond = (MacroConditionRegistry.PendingCondition)var2.next();
            if (cond instanceof MacroConditionRegistry.GuiCondition) {
                GuiCondition gc = (MacroConditionRegistry.GuiCondition)cond;
                if (gc.checkScreen(screen)) {
                    gc.complete();
                    toRemove.add(gc);
                }
            }
        }
        pendingConditions.removeAll(toRemove);
    }

    public static void cancelAll() {
        var var0 = pendingConditions.iterator();
        while (var0.hasNext()) {
            PendingCondition cond = (MacroConditionRegistry.PendingCondition)var0.next();
            cond.cancel();
        }
        pendingConditions.clear();
    }

    public static boolean hasPendingConditions() {
        return !pendingConditions.isEmpty();
    }

    public static CompletableFuture<Void> waitForServerTick(int bufferMs, int maxWaitMs, boolean ignorePing) {
        CompletableFuture<Void> future = new CompletableFuture();
        ServerTickSyncCondition condition = new MacroConditionRegistry.ServerTickSyncCondition(future, bufferMs, maxWaitMs, ignorePing);
        pendingConditions.add(condition);
        return future;
    }

    public static CompletableFuture<Void> waitForEntity(WaitForEntityAction action) {
        CompletableFuture<Void> future = new CompletableFuture();
        EntityCondition condition = new MacroConditionRegistry.EntityCondition(action, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForItemInHandler(String itemName) {
        return MacroConditionRegistry.waitForItemInHandler(ItemTarget.fromLegacyEntry(itemName));
    }

    public static CompletableFuture<Void> waitForItemInHandler(ItemTarget target) {
        CompletableFuture<Void> future = new CompletableFuture();
        HandlerItemCondition condition = new MacroConditionRegistry.HandlerItemCondition(target, future);
        pendingConditions.add(condition);
        class_310 mc = class_310.method_1551();
        if (condition.check(mc)) {
            condition.complete();
            pendingConditions.remove(condition);
        }
        return future;
    }

    public static CompletableFuture<Void> waitForSlotChange(int slotNumber) {
        return MacroConditionRegistry.waitForSlotChange(new WaitForSlotChangeAction(slotNumber));
    }

    public static CompletableFuture<Void> waitForSound(WaitForSoundAction action) {
        CompletableFuture<Void> future = new CompletableFuture();
        pendingConditions.add(new MacroConditionRegistry.SoundCondition(action, future));
        return future;
    }

    public static void onSoundPacket(String soundId, double x, double y, double z) {
        if (pendingConditions.isEmpty()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        List<MacroConditionRegistry.PendingCondition> toRemove = new ArrayList();
        var var9 = pendingConditions.iterator();
        while (var9.hasNext()) {
            PendingCondition cond = (MacroConditionRegistry.PendingCondition)var9.next();
            while (cond.isCancelled()) {
                toRemove.add(cond);
            }
            if (cond instanceof MacroConditionRegistry.SoundCondition) {
                SoundCondition sc = (MacroConditionRegistry.SoundCondition)cond;
                if (sc.matches(mc, soundId, x, y, z)) {
                    sc.complete();
                    toRemove.add(sc);
                }
            }
        }
        pendingConditions.removeAll(toRemove);
    }

    public static CompletableFuture<Void> waitForSlotChange(WaitForSlotChangeAction action) {
        class_310 mc = class_310.method_1551();
        Map<Integer, String> initialNames = new HashMap();
        Map<Integer, Integer> initialCounts = new HashMap();
        if (mc.field_1724 == null) { /* goto L217; */ }
        class_1703 handler = mc.field_1724.field_7512;
        for (int i = 0; i < action.entries.size(); i++) {
            WaitEntry e = (WaitForSlotChangeAction.WaitEntry)action.entries.get(i);
            ItemTarget entryTarget = e.resolvedTarget();
            if (e.waitMode != WaitForSlotChangeAction.WaitMode.ANY_CHANGE) {
            } else {
                if (entryTarget == null) { /* goto @211; */ }
                if (!entryTarget.hasSlot()) {
                } else {
                    int slotNum = entryTarget.slot;
                    int handlerSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, slotNum);
                    if (handler == null) { /* goto @211; */ }
                    if (handlerSlot < 0) { /* goto @211; */ }
                    if (handlerSlot >= handler.field_7761.size()) { /* goto @211; */ }
                    class_1799 s = ((class_1735)handler.field_7761.get(handlerSlot)).method_7677();
                    initialNames.put(i, MacroConditionRegistry.snapshotStackIdentity(s));
                    initialCounts.put(i, s.method_7960() ? 0 : s.method_7947());
                }
            }
        }
        future = new CompletableFuture();
        condition = new MacroConditionRegistry.SlotChangeCondition(action, initialNames, initialCounts, future);
        pendingConditions.add(condition);
        hasAnyChange = action.entries.stream().anyMatch(MacroConditionRegistry::lambda$waitForSlotChange$0);
        condition.complete();
        if (!hasAnyChange && condition.check(mc)) {
            pendingConditions.remove(condition);
        }
        return future;
    }

    private static String snapshotStackIdentity(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return "";
        }
        String rich = MacroExecutor.serializeTextComponent(stack.method_7964());
        return rich == null ? "" : rich;
    }

    public static CompletableFuture<Void> waitForLanStep(WaitForLanStepAction action) {
        CompletableFuture<Void> future = new CompletableFuture();
        LanStepCondition cond = new MacroConditionRegistry.LanStepCondition(action, future);
        if (cond.checkNow()) {
            future.complete(null);
        } else {
            pendingConditions.add(cond);
        }
        return future;
    }

    public static void onLanStepProgress() {
        if (pendingConditions.isEmpty()) {
            return;
        }
        List<MacroConditionRegistry.PendingCondition> toRemove = new ArrayList();
        var var1 = pendingConditions.iterator();
        while (var1.hasNext()) {
            PendingCondition cond = (MacroConditionRegistry.PendingCondition)var1.next();
            while (cond.isCancelled()) {
                toRemove.add(cond);
            }
            if (cond instanceof MacroConditionRegistry.LanStepCondition) {
                LanStepCondition lsc = (MacroConditionRegistry.LanStepCondition)cond;
                if (lsc.checkNow()) {
                    lsc.complete();
                    toRemove.add(lsc);
                }
            }
        }
        pendingConditions.removeAll(toRemove);
    }

    private static boolean matchesLower(String searchLower, String[] searchWords, String target) {
        if (searchLower.isEmpty() || target.isEmpty()) {
            return false;
        }
        String tl = target.toLowerCase();
        if (searchLower.equals(tl)) {
            return true;
        }
        if (tl.contains(searchLower)) {
            return true;
        }
        if (searchWords.length == 0) {
            return false;
        }
        String[] targetWords = tl.split("\\s+");
        var var5 = searchWords;
        var var6 = var5.length;
        for (int var7 = 0; var7 < var6; var7++) {
            String word = var5[var7];
            boolean found = false;
            var var10 = targetWords;
            var var11 = var10.length;
            int var12 = 0;
            while (var12 < var11) {
                String tWord = var10[var12];
                if (tWord.contains(word)) { /* goto L131; */ }
                if (word.contains(tWord)) {
                    found = true;
                } else {
                    var12++;
                }
            }
            if (found) continue;
            return false;
        }
        return true;
    }

    private static boolean matchesText(String search, String target) {
        if (search.isEmpty() || target.isEmpty()) {
            return false;
        }
        if (search.equals(target)) {
            return true;
        }
        if (target.toLowerCase().contains(search.toLowerCase())) {
            return true;
        }
        String[] searchWords = search.toLowerCase().split("\\s+");
        String[] targetWords = target.toLowerCase().split("\\s+");
        var var4 = searchWords;
        var var5 = var4.length;
        for (int var6 = 0; var6 < var5; var6++) {
            String word = var4[var6];
            boolean found = false;
            var var9 = targetWords;
            var var10 = var9.length;
            int var11 = 0;
            while (var11 < var10) {
                String tWord = var9[var11];
                if (tWord.contains(word)) { /* goto L137; */ }
                if (word.contains(tWord)) {
                    found = true;
                } else {
                    var11++;
                }
            }
            if (found) continue;
            return false;
        }
        return true;
    }
}
