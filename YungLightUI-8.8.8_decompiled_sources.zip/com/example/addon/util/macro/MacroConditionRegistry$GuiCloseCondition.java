/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_437;

static class MacroConditionRegistry.GuiCloseCondition
implements MacroConditionRegistry.PendingCondition {
    final String titleLower;
    final String[] titleWords;
    final CompletableFuture<Void> future;
    private volatile boolean cancelled = false;
    private boolean sawMatchingGui = false;

    MacroConditionRegistry.GuiCloseCondition(String title, CompletableFuture<Void> future) {
        this.titleLower = title.toLowerCase();
        this.titleWords = this.titleLower.isEmpty() ? new String[0] : this.titleLower.split("\\s+");
        this.future = future;
    }

    public boolean check(class_310 mc) {
        class_437 screen = mc.field_1755;
        this.sawMatchingGui = true;
        if (screen != null && !this.titleLower.isEmpty() && MacroConditionRegistry.matchesLower(this.titleLower, this.titleWords, screen.method_25440().getString())) {
            return false;
        }
        if (this.titleLower.isEmpty()) {
            if (screen != null) {
                this.sawMatchingGui = true;
                return false;
            }
            return this.sawMatchingGui;
        }
        return this.sawMatchingGui || screen == null;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.cancelled = true;
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.cancelled || this.future.isCancelled();
    }
}
