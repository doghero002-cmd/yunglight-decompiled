/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilContainerTarget;
import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class OpenContainerAction
implements MacroAction,
WaitsForGui {
    public OpenContainerAction.TargetMode targetMode = OpenContainerAction.TargetMode.BLOCK;
    public class_2338 blockPos;
    public String entityTarget;
    public boolean waitForGui;
    public String guiName;
    private boolean enabled;

    public OpenContainerAction() {
        this.blockPos = class_2338.field_10980;
        this.entityTarget = "";
        this.waitForGui = true;
        this.guiName = "";
        this.enabled = true;
    }

    public void execute(class_310 mc) {
        if (mc == null || mc.field_1724 == null) {
            return;
        }
        switch (this.targetMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                PackUtilContainerTarget target = PackUtilContainerTarget.forBlock(this.blockPos);
                break;
            case 1::
                target = PackUtilContainerTarget.forEntityRef(this.entityTarget);
                break;
            case 2::
                target = PackUtilSharedState.get().getLastContainerTarget();
                break;
        }
        if (target != null) {
            target.interact(mc);
        }
    }

    public void captureCurrentLookTarget(class_310 mc) {
        if (mc == null) {
            return;
        }
        var var4 = mc.field_1765;
        if (var4 instanceof class_3966) {
            class_3966 entityHit = (class_3966)var4;
            if (entityHit.method_17782() != null) {
                this.targetMode = OpenContainerAction.TargetMode.ENTITY;
                this.entityTarget = PackUtilContainerTarget.toSpecificEntityRef(entityHit.method_17782());
            }
        } else {
            var4 = mc.field_1765;
            if (var4 instanceof class_3965) {
                class_3965 blockHit = (class_3965)var4;
                this.targetMode = OpenContainerAction.TargetMode.BLOCK;
                this.blockPos = blockHit.method_17777();
                this.entityTarget = "";
            }
        }
    }

    public String entityTargetLabel() {
        if (this.entityTarget == null || this.entityTarget.isBlank()) {
            return "(none)";
        }
        if (!this.entityTarget.startsWith("~")) { /* goto L95; */ }
        String[] parts = this.entityTarget.split("~", 4);
        String name = parts.length >= 4 ? parts[3] : "?";
        String type = parts.length >= 3 ? PackUtilRegistryLabels.entity(parts[2]) : "?";
        return name.isBlank() ? type : name + " (" + type + ")";
        return PackUtilRegistryLabels.entity(this.entityTarget);
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return "";
    }

    public void setWaitGuiName(String name) {
        this.guiName = "";
    }

    public MacroActionType getType() {
        return MacroActionType.OPEN_CONTAINER;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    public String getIcon() {
        return "OC";
    }

    public String getDisplayName() {
        switch (this.targetMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                String targetLabel = this.blockPos.method_10263() + "," + this.blockPos.method_10264() + "," + this.blockPos.method_10260();
                break;
            case 1::
                targetLabel = this.entityTargetLabel();
                break;
            case 2::
                targetLabel = "Last Target";
                break;
        }
        String base = "Open Container " + targetLabel;
        return this.waitForGui ? base + " (wait)" : base;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "OPEN_CONTAINER");
        tag.method_10582("targetMode", this.targetMode.name());
        tag.method_10569("x", this.blockPos.method_10263());
        tag.method_10569("y", this.blockPos.method_10264());
        tag.method_10569("z", this.blockPos.method_10260());
        tag.method_10582("entityTarget", this.entityTarget);
        class_2499 entityTargets = new class_2499();
        if (this.entityTarget != null) {
            if (!this.entityTarget.isBlank()) {
                entityTargets.add(class_2519.method_23256(this.entityTarget));
            }
        }
        tag.method_10566("entityTargets", entityTargets);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        int x = tag.method_68083("x", 0);
        int y = tag.method_68083("y", 0);
        int z = tag.method_68083("z", 0);
        this.blockPos = new class_2338(x, y, z);
        try {
            this.targetMode = OpenContainerAction.TargetMode.valueOf(tag.method_68564("targetMode", "BLOCK"));
        }
        catch (IllegalArgumentException ignored) {
            this.targetMode = OpenContainerAction.TargetMode.BLOCK;
            L68: ;
            this.entityTarget = tag.method_68564("entityTarget", "");
            if (this.entityTarget == null) { /* goto L97; */ }
            if (!this.entityTarget.isBlank()) { /* goto L200; */ }
            L97: ;
            if (!tag.method_10545("entityTargets")) { /* goto L200; */ }
            entityTargets = (class_2499)tag.method_10554("entityTargets").orElse(new class_2499());
            var var6 = entityTargets.iterator();
            while (var6.hasNext()) {
                class_2520 element = (class_2520)var6.next();
                String value = (String)element.method_68658().orElse("");
                if (value == null) { /* goto @197; */ }
                if (value.isBlank()) { /* goto @197; */ }
                this.entityTarget = value;
                break;
            }
            this.waitForGui = tag.method_68566("waitForGui", true);
            this.guiName = tag.method_68564("guiName", "");
            this.enabled = tag.method_68566("enabled", true);
            return;
        }
        this.entityTarget = tag.method_68564("entityTarget", "");
        if (this.entityTarget == null) { /* goto L97; */ }
        if (!this.entityTarget.isBlank()) { /* goto L200; */ }
        L97: ;
        if (!tag.method_10545("entityTargets")) { /* goto L200; */ }
        entityTargets = (class_2499)tag.method_10554("entityTargets").orElse(new class_2499());
        var6 = entityTargets.iterator();
        while (var6.hasNext()) {
            element = (class_2520)var6.next();
            value = (String)element.method_68658().orElse("");
            if (value == null) { /* goto @197; */ }
            if (value.isBlank()) { /* goto @197; */ }
            this.entityTarget = value;
            break;
        }
        this.waitForGui = tag.method_68566("waitForGui", true);
        this.guiName = tag.method_68564("guiName", "");
        this.enabled = tag.method_68566("enabled", true);
    }
}
