/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.InventoryAuditAction;
import java.util.Map;

private static final record InventoryAuditAction.InventorySnapshot {
    private final String title;
    private final long capturedAtMs;
    private final Map<Integer, InventoryAuditAction.SlotSnapshot> slots;

    private InventoryAuditAction.InventorySnapshot(String title, long capturedAtMs, Map<Integer, InventoryAuditAction.SlotSnapshot> slots) {
        this.title = title;
        this.capturedAtMs = capturedAtMs;
        this.slots = slots;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String title() {
        return this.title;
    }

    public long capturedAtMs() {
        return this.capturedAtMs;
    }

    public Map<Integer, InventoryAuditAction.SlotSnapshot> slots() {
        return this.slots;
    }
}
