/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class RestoreGuiAction
implements MacroAction,
WaitsForGui {
    public boolean waitForGui = true;
    private boolean enabled = true;

    public void execute(class_310 mc) {
        PackUtilSharedState shared = PackUtilSharedState.get();
        if (shared.getStoredScreen() == null || shared.getStoredScreenHandler() == null) {
            return;
        }
        mc.method_1507(shared.getStoredScreen());
        if (mc.field_1724 != null) {
            mc.field_1724.field_7512 = shared.getStoredScreenHandler();
        }
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return "";
    }

    public void setWaitGuiName(String n) {
    }

    public MacroActionType getType() {
        return MacroActionType.RESTORE_GUI;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "RESTORE_GUI");
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", true);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        return this.waitForGui ? "Restore GUI (wait)" : "Restore GUI";
    }

    public String getIcon() {
        return "R";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
