/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum XCarryAction.Mode {
    public static final XCarryAction.Mode PUT_IN = new XCarryAction.Mode("PUT_IN", 0);
    public static final XCarryAction.Mode TAKE_OUT = new XCarryAction.Mode("TAKE_OUT", 1);
    public static final XCarryAction.Mode DROP = new XCarryAction.Mode("DROP", 2);
    private static final /* synthetic */ XCarryAction.Mode[] $VALUES;

    public static XCarryAction.Mode[] values() {
        return (XCarryAction.Mode[])$VALUES.clone();
    }

    public static XCarryAction.Mode valueOf(String name) {
        return (XCarryAction.Mode)Enum.valueOf(XCarryAction.Mode.class, name);
    }

    private XCarryAction.Mode() {
        super(var1, var2);
    }

    static {
        $VALUES = XCarryAction.Mode.$values();
    }
}
