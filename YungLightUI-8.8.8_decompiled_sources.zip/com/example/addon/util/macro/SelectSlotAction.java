/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SelectSlotAction
implements MacroAction {
    public int slot = 0;
    public String itemName = "";
    public ItemTarget itemTarget = new ItemTarget();

    public void execute(class_310 mc) {
        if (mc.field_1724 == null) {
            return;
        }
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            int selectedSlot = PackUtilInventoryHelper.selectHotbarItem(mc, target, this.slot);
            if (selectedSlot >= 0) {
                return;
            }
        }
        actualSlot = Math.max(0, Math.min(8, this.slot));
        PackUtilInventoryHelper.selectHotbarSlot(mc, actualSlot);
    }

    public MacroActionType getType() {
        return MacroActionType.SELECT_SLOT;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "SELECT_SLOT");
        tag.method_10569("slot", this.slot);
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            tag.method_10566("itemName", target.toTag());
        }
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.slot = tag.method_68083("slot", 0);
        this.itemTarget = (ItemTarget)tag.method_10562("itemName").map(ItemTarget::fromTag).orElseGet(SelectSlotAction::lambda$fromTag$0 /* captured: tag */);
        this.itemName = this.itemTarget.toLegacyEntry();
    }

    public String getDisplayName() {
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            return "Select \"" + target.summaryText() + "\" -> " + Math.max(0, Math.min(8, this.slot)) + 1;
        }
        return "Select Slot " + this.slot + 1;
    }

    public String getIcon() {
        return "S";
    }

    private ItemTarget resolvedItemTarget() {
        if (this.itemTarget != null) {
            if (this.itemTarget.hasSlot() || this.itemTarget.hasIdentity()) {
                return this.itemTarget;
            }
        }
        this.itemTarget = ItemTarget.fromLegacyEntry(this.itemName);
        return this.itemTarget;
    }
}
