/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum WaitForEntityAction.CheckMode {
    public static final WaitForEntityAction.CheckMode RADIUS = new WaitForEntityAction.CheckMode("RADIUS", 0);
    public static final WaitForEntityAction.CheckMode LOOKING_AT = new WaitForEntityAction.CheckMode("LOOKING_AT", 1);
    public static final WaitForEntityAction.CheckMode WITHIN_REACH = new WaitForEntityAction.CheckMode("WITHIN_REACH", 2);
    private static final /* synthetic */ WaitForEntityAction.CheckMode[] $VALUES;

    public static WaitForEntityAction.CheckMode[] values() {
        return (WaitForEntityAction.CheckMode[])$VALUES.clone();
    }

    public static WaitForEntityAction.CheckMode valueOf(String name) {
        return (WaitForEntityAction.CheckMode)Enum.valueOf(WaitForEntityAction.CheckMode.class, name);
    }

    private WaitForEntityAction.CheckMode() {
        super(var1, var2);
    }

    static {
        $VALUES = WaitForEntityAction.CheckMode.$values();
    }
}
