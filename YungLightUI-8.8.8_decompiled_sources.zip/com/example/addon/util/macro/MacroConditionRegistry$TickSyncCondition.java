/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;

static class MacroConditionRegistry.TickSyncCondition
implements MacroConditionRegistry.PendingCondition {
    final CompletableFuture<Void> future;

    MacroConditionRegistry.TickSyncCondition(CompletableFuture<Void> future) {
        this.future = future;
    }

    public boolean check(class_310 mc) {
        return true;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
