/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.WaitForBlockAction;
import com.example.addon.util.macro.WaitForEntityAction;
import com.example.addon.util.macro.WaitForSlotChangeAction;

static class MacroConditionRegistry.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode;
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode;
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode;

    static {
        $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode = new int[WaitForSlotChangeAction.WaitMode.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.NOT_EMPTY.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.IS_EMPTY.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.IS_EMPTY.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.COUNT_AT_LEAST.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.COUNT_AT_LEAST.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.COUNT_BELOW.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.COUNT_BELOW.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.ANY_CHANGE.ordinal()] = 5;
            /* goto @84; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[WaitForSlotChangeAction.WaitMode.ANY_CHANGE.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode = new int[WaitForEntityAction.CheckMode.values().length];
            $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode[WaitForEntityAction.CheckMode.LOOKING_AT.ordinal()] = 1;
            /* goto @108; */
        }
        $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode = new int[WaitForEntityAction.CheckMode.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode[WaitForEntityAction.CheckMode.LOOKING_AT.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode[WaitForEntityAction.CheckMode.WITHIN_REACH.ordinal()] = 2;
            /* goto @123; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForEntityAction$CheckMode[WaitForEntityAction.CheckMode.WITHIN_REACH.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode = new int[WaitForBlockAction.CheckMode.values().length];
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[WaitForBlockAction.CheckMode.AT_POSITION.ordinal()] = 1;
            /* goto @147; */
        }
        $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode = new int[WaitForBlockAction.CheckMode.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[WaitForBlockAction.CheckMode.AT_POSITION.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[WaitForBlockAction.CheckMode.IN_REACH.ordinal()] = 2;
            /* goto @162; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[WaitForBlockAction.CheckMode.IN_REACH.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[WaitForBlockAction.CheckMode.LOOKING_AT.ordinal()] = 3;
            /* goto L177; */
            var0 = null;
            L177: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$macro$WaitForBlockAction$CheckMode[WaitForBlockAction.CheckMode.LOOKING_AT.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
