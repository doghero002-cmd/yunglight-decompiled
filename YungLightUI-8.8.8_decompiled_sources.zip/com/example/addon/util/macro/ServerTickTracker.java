/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2761;
import net.minecraft.class_2777;
import net.minecraft.class_310;
import net.minecraft.class_640;

public class ServerTickTracker {
    private static final long TICK_DURATION_NANOS = 50000000L;
    private static final class_310 MC = class_310.method_1551();
    private static final long MIN_WARMUP_MS = 2000L;
    private static final int MIN_SAMPLES = 40;
    private static final int WORLD_TIME_SAMPLE_COUNT = 60;
    private static final long[] worldTimeSamples = new long[60];
    private static int worldTimeSampleIndex = 0;
    private static int worldTimeSamplesFilled = 0;
    private static volatile long trackingStartTime = 0L;
    private static volatile long lastWorldTimePacket = 0L;
    private static volatile long averagedTickPhase = 0L;
    private static volatile long baseTickTime = 0L;
    private static volatile long lastEntityPacketTime = 0L;
    private static volatile int entityPacketBurstCount = 0;
    private static final long BURST_THRESHOLD_NANOS = 5000000L;

    public static void onWorldTimePacket(class_2761 packet) {
        long now = System.nanoTime();
        if (trackingStartTime == 0L) {
            trackingStartTime = now;
        }
        lastWorldTimePacket = now;
        int pingMs = ServerTickTracker.getPingMs();
        long halfPingNanos = (long)pingMs * 1000000L / 2L;
        long serverSendTime = now - halfPingNanos;
        worldTimeSamples[worldTimeSampleIndex] = serverSendTime;
        worldTimeSampleIndex = (worldTimeSampleIndex + 1) % 60;
        if (worldTimeSamplesFilled < 60) {
            worldTimeSamplesFilled = worldTimeSamplesFilled + 1;
        }
        ServerTickTracker.updateAveragedPhase();
    }

    public static void onEntityPacket() {
        long now = System.nanoTime();
        if (now - lastEntityPacketTime < 5000000L) {
            entityPacketBurstCount = entityPacketBurstCount + 1;
        } else {
            entityPacketBurstCount = 1;
        }
        lastEntityPacketTime = now;
    }

    public static void onS2CPacket(class_2596<?> packet) {
        if (packet instanceof class_2761) {
            class_2761 worldTimePacket = (class_2761)packet;
            ServerTickTracker.onWorldTimePacket(worldTimePacket);
        } else {
            if (packet instanceof class_2777 || packet instanceof class_2743 || packet instanceof class_2708) {
                ServerTickTracker.onEntityPacket();
            }
        }
    }

    private static void updateAveragedPhase() {
        if (worldTimeSamplesFilled < 3) {
            return;
        }
        long sumPhase = 0L;
        int validSamples = Math.min(worldTimeSamplesFilled, 60);
        for (int i = 0; i < validSamples; i++) {
            long phase = worldTimeSamples[i] % 50000000L;
            sumPhase = sumPhase + phase;
        }
        averagedTickPhase = sumPhase / (long)validSamples;
        mostRecent = worldTimeSamples[(worldTimeSampleIndex - 1 + 60) % 60];
        long tickNumber = mostRecent / 50000000L;
        baseTickTime = tickNumber * 50000000L + averagedTickPhase;
        long now = System.nanoTime();
        if (baseTickTime > now) {
            baseTickTime = baseTickTime - 50000000L;
        }
    }

    public static int getPingMs() {
        if (MC.method_1562() == null || MC.field_1724 == null) {
            return 0;
        }
        class_640 entry = MC.method_1562().method_2871(MC.field_1724.method_5667());
        if (entry == null) {
            return 0;
        }
        return entry.method_2959();
    }

    public static long getNextServerTickNanos() {
        if (baseTickTime == 0L) {
            return System.nanoTime() + 50000000L;
        }
        long now = System.nanoTime();
        long elapsed = now - baseTickTime;
        long ticksElapsed = elapsed / 50000000L;
        return baseTickTime + (ticksElapsed + 1L) * 50000000L;
    }

    public static long getOptimalSendTime(int bufferMs, boolean ignorePing) {
        long nextTick = ServerTickTracker.getNextServerTickNanos();
        int pingMs = ignorePing ? 0 : ServerTickTracker.getPingMs();
        long halfPingNanos = (long)pingMs * 1000000L / 2L;
        long bufferNanos = (long)bufferMs * 1000000L;
        long optimalTime = nextTick - bufferNanos - halfPingNanos;
        long now = System.nanoTime();
        while (optimalTime <= now) {
            optimalTime = optimalTime + 50000000L;
        }
        return optimalTime;
    }

    public static boolean isReady() {
        if (trackingStartTime == 0L || worldTimeSamplesFilled < 40) {
            return false;
        }
        long elapsedMs = (System.nanoTime() - trackingStartTime) / 1000000L;
        return elapsedMs >= 2000L && baseTickTime > 0L;
    }

    public static float getWarmupProgress() {
        if (trackingStartTime == 0L) {
            return 0f;
        }
        long elapsedMs = (System.nanoTime() - trackingStartTime) / 1000000L;
        float timeProgress = Math.min(1f, (float)elapsedMs / 2000f);
        float sampleProgress = Math.min(1f, (float)worldTimeSamplesFilled / 40f);
        return Math.min(timeProgress, sampleProgress);
    }

    public static float getConfidence() {
        if (!ServerTickTracker.isReady()) {
            return 0f;
        }
        float sampleConfidence = Math.min(1f, (float)worldTimeSamplesFilled / 60f);
        long timeSinceLast = System.nanoTime() - lastWorldTimePacket;
        float freshnessConfidence = timeSinceLast < 100000000L ? 1f : Math.max(0f, 1f - (float)timeSinceLast / 500000000f);
        return sampleConfidence * freshnessConfidence;
    }

    public static long getMsUntilOptimal(int bufferMs, boolean ignorePing) {
        long optimalTime = ServerTickTracker.getOptimalSendTime(bufferMs, ignorePing);
        return Math.max(0L, (optimalTime - System.nanoTime()) / 1000000L);
    }

    public static long getMsUntilNextTick() {
        long nextTick = ServerTickTracker.getNextServerTickNanos();
        return Math.max(0L, (nextTick - System.nanoTime()) / 1000000L);
    }

    public static int getSampleCount() {
        return worldTimeSamplesFilled;
    }

    public static long getTrackingTimeMs() {
        if (trackingStartTime == 0L) {
            return 0L;
        }
        return (System.nanoTime() - trackingStartTime) / 1000000L;
    }

    public static long getAveragedPhaseMs() {
        return averagedTickPhase / 1000000L;
    }

    public static void reset() {
        worldTimeSamplesFilled = 0;
        worldTimeSampleIndex = 0;
        trackingStartTime = 0L;
        lastWorldTimePacket = 0L;
        averagedTickPhase = 0L;
        baseTickTime = 0L;
        lastEntityPacketTime = 0L;
        entityPacketBurstCount = 0;
    }

    public static String getDebugInfo() {
        return String.format("Ping: %dms | Samples: %d/%d | Phase: %dms | Confidence: %.0f%%", ServerTickTracker.getPingMs(), worldTimeSamplesFilled, 40, ServerTickTracker.getAveragedPhaseMs(), ServerTickTracker.getConfidence() * 100f);
    }
}
