/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1799;
import net.minecraft.class_310;

static class MacroConditionRegistry.CooldownCondition
implements MacroConditionRegistry.PendingCondition {
    final ItemTarget target;
    final boolean checkMainHand;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.CooldownCondition(ItemTarget target, boolean checkMainHand, CompletableFuture<Void> future) {
        this.target = target == null ? new ItemTarget() : target.copy();
        this.checkMainHand = checkMainHand;
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1724 == null) {
            return false;
        }
        if (!this.target.hasIdentity()) { /* goto L98; */ }
        boolean foundAny = false;
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                if (this.target.matches(stack, i)) {
                    foundAny = true;
                    if (!mc.field_1724.method_7357().method_7904(stack)) continue;
                    return false;
                }
            }
        }
        return foundAny;
        L98: ;
        stack = this.checkMainHand ? mc.field_1724.method_6047() : mc.field_1724.method_6079();
        if (stack.method_7960()) {
            return true;
        }
        return !mc.field_1724.method_7357().method_7904(stack);
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
