/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum MacroExecutor.ChatSource {
    public static final MacroExecutor.ChatSource PLAYER = new MacroExecutor.ChatSource("PLAYER", 0);
    public static final MacroExecutor.ChatSource SERVER = new MacroExecutor.ChatSource("SERVER", 1);
    private static final /* synthetic */ MacroExecutor.ChatSource[] $VALUES;

    public static MacroExecutor.ChatSource[] values() {
        return (MacroExecutor.ChatSource[])$VALUES.clone();
    }

    public static MacroExecutor.ChatSource valueOf(String name) {
        return (MacroExecutor.ChatSource)Enum.valueOf(MacroExecutor.ChatSource.class, name);
    }

    private MacroExecutor.ChatSource() {
        super(var1, var2);
    }

    static {
        $VALUES = MacroExecutor.ChatSource.$values();
    }
}
