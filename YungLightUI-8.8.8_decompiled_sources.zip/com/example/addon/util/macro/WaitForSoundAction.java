/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class WaitForSoundAction
implements MacroAction,
WaitsForGui {
    public List<String> soundIds = new ArrayList();
    public boolean waitForGui = false;
    public String waitGuiName = "";
    public boolean checkDistance = false;
    public double maxDistance = 16;
    private boolean enabled = true;

    public MacroActionType getType() {
        return MacroActionType.WAIT_SOUND;
    }

    public void execute(class_310 mc) {
    }

    public String getDisplayName() {
        if (this.soundIds.isEmpty()) {
            return "Wait Sound: Any";
        }
        String first = PackUtilRegistryLabels.sound((String)this.soundIds.get(0));
        String s = this.soundIds.size() == 1 ? first : first + " (+" + this.soundIds.size() - 1 + ")";
        return "Wait Sound: " + s;
    }

    public String getIcon() {
        return "SND";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.waitGuiName;
    }

    public void setWaitGuiName(String name) {
        this.waitGuiName = name;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        class_2499 list = new class_2499();
        var var3 = this.soundIds.iterator();
        while (var3.hasNext()) {
            String id = (String)var3.next();
            list.add(class_2519.method_23256(id));
        }
        tag.method_10566("soundIds", list);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("waitGuiName", this.waitGuiName);
        tag.method_10556("checkDistance", this.checkDistance);
        tag.method_10549("maxDistance", this.maxDistance);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.soundIds.clear();
        if (!tag.method_10545("soundIds")) { /* goto L103; */ }
        class_2499 list = (class_2499)tag.method_10554("soundIds").orElse(new class_2499());
        var var3 = list.iterator();
        while (var3.hasNext()) {
            class_2520 el = (class_2520)var3.next();
            String s = (String)el.method_68658().orElse("");
            if (s.isEmpty()) continue;
            this.soundIds.add(s);
        }
        this.waitForGui = tag.method_68566("waitForGui", false);
        this.waitGuiName = tag.method_68564("waitGuiName", "");
        this.checkDistance = tag.method_68566("checkDistance", false);
        this.maxDistance = tag.method_68563("maxDistance", 16);
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }
}
