/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum SendToggleAction.ToggleMode {
    public static final SendToggleAction.ToggleMode ENABLE = new SendToggleAction.ToggleMode("ENABLE", 0);
    public static final SendToggleAction.ToggleMode DISABLE = new SendToggleAction.ToggleMode("DISABLE", 1);
    private static final /* synthetic */ SendToggleAction.ToggleMode[] $VALUES;

    public static SendToggleAction.ToggleMode[] values() {
        return (SendToggleAction.ToggleMode[])$VALUES.clone();
    }

    public static SendToggleAction.ToggleMode valueOf(String name) {
        return (SendToggleAction.ToggleMode)Enum.valueOf(SendToggleAction.ToggleMode.class, name);
    }

    private SendToggleAction.ToggleMode() {
        super(var1, var2);
    }

    static {
        $VALUES = SendToggleAction.ToggleMode.$values();
    }
}
