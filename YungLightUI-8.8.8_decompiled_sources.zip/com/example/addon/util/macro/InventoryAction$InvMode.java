/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum InventoryAction.InvMode {
    public static final InventoryAction.InvMode OPEN = new InventoryAction.InvMode("OPEN", 0);
    public static final InventoryAction.InvMode CLOSE = new InventoryAction.InvMode("CLOSE", 1);
    private static final /* synthetic */ InventoryAction.InvMode[] $VALUES;

    public static InventoryAction.InvMode[] values() {
        return (InventoryAction.InvMode[])$VALUES.clone();
    }

    public static InventoryAction.InvMode valueOf(String name) {
        return (InventoryAction.InvMode)Enum.valueOf(InventoryAction.InvMode.class, name);
    }

    private InventoryAction.InvMode() {
        super(var1, var2);
    }

    static {
        $VALUES = InventoryAction.InvMode.$values();
    }
}
