/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SaveGuiAction
implements MacroAction {
    private boolean enabled = true;
    public boolean closeAfter = false;
    public boolean sendPacket = true;

    public void execute(class_310 mc) {
        if (mc.field_1755 == null || mc.field_1724 == null) {
            return;
        }
        PackUtilSharedState.get().storeScreen(mc.field_1755, mc.field_1724.field_7512);
        if (this.closeAfter) {
            if (!this.sendPacket) {
                PackUtilSharedState.get().setSuppressNextClosePacket(true);
            }
            mc.field_1724.method_7346();
        }
    }

    public MacroActionType getType() {
        return MacroActionType.SAVE_GUI;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "SAVE_GUI");
        tag.method_10556("enabled", this.enabled);
        tag.method_10556("closeAfter", this.closeAfter);
        tag.method_10556("sendPacket", this.sendPacket);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
        if (tag.method_10545("closeAfter")) {
            this.closeAfter = tag.method_68566("closeAfter", false);
        }
        if (tag.method_10545("sendPacket")) {
            this.sendPacket = tag.method_68566("sendPacket", true);
        }
    }

    public String getDisplayName() {
        if (!this.closeAfter) {
            return "Save GUI";
        }
        return this.sendPacket ? "Save GUI (close)" : "Save GUI (close, desync)";
    }

    public String getIcon() {
        return "S";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
