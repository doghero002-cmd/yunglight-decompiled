/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.WaitForSlotChangeAction;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;

static class MacroConditionRegistry.SlotChangeCondition
implements MacroConditionRegistry.PendingCondition {
    final WaitForSlotChangeAction action;
    final Map<Integer, String> initialNames;
    final Map<Integer, Integer> initialCounts;
    final CompletableFuture<Void> future;

    MacroConditionRegistry.SlotChangeCondition(WaitForSlotChangeAction action, Map<Integer, String> initialNames, Map<Integer, Integer> initialCounts, CompletableFuture<Void> future) {
        this.action = action;
        this.initialNames = initialNames;
        this.initialCounts = initialCounts;
        this.future = future;
    }

    MacroConditionRegistry.SlotChangeCondition(int slotNumber, String initialItemName, int initialCount, CompletableFuture<Void> future) {
        WaitForSlotChangeAction a = new WaitForSlotChangeAction(slotNumber);
        this.action = a;
        this.initialNames = new HashMap();
        this.initialCounts = new HashMap();
        if (slotNumber >= 0) {
            this.initialNames.put(0, initialItemName);
            this.initialCounts.put(0, initialCount);
        }
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1724 == null) {
            return false;
        }
        if (this.action.entries.isEmpty()) {
            return true;
        }
        class_1703 handler = mc.field_1724.field_7512;
        for (int i = 0; i < this.action.entries.size(); i++) {
            if (this.checkEntry(mc, handler, (WaitForSlotChangeAction.WaitEntry)this.action.entries.get(i), i)) continue;
            return false;
        }
        return true;
    }

    private boolean checkEntry(class_310 mc, class_1703 handler, WaitForSlotChangeAction.WaitEntry e, int entryIdx) {
        ItemTarget entryTarget = e.resolvedTarget();
        if (entryTarget == null) {
            entryTarget = new ItemTarget();
        }
        if (!entryTarget.hasSlot()) { /* goto L127; */ }
        int slotNum = entryTarget.slot;
        if (handler != null) { /* goto L55; */ }
        return e.waitMode == WaitForSlotChangeAction.WaitMode.IS_EMPTY;
        int handlerSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, slotNum);
        if (handlerSlot < 0) { /* goto L80; */ }
        if (handlerSlot < handler.field_7761.size()) { /* goto L96; */ }
        L80: ;
        return e.waitMode == WaitForSlotChangeAction.WaitMode.IS_EMPTY;
        class_1799 stack = ((class_1735)handler.field_7761.get(handlerSlot)).method_7677();
        return this.checkStack(stack, entryTarget, slotNum, e, entryIdx);
        L127: ;
        if (e.waitMode != WaitForSlotChangeAction.WaitMode.IS_EMPTY) { /* goto L306; */ }
        if (handler != null) {
            i = handler.field_7761.iterator();
            while (i.hasNext()) {
                s = (class_1735)i.next();
                if (s == null) continue;
                while (s.method_7677().method_7960()) {
                }
                visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, s.field_7874);
                if (entryTarget.hasIdentity() || entryTarget.matches(s.method_7677(), visibleSlot)) continue;
                return false;
            }
        } else {
            for (i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
                stack = mc.field_1724.method_31548().method_5438(i);
                if (stack.method_7960()) {
                } else {
                    if (entryTarget.hasIdentity() || entryTarget.matches(stack, i)) continue;
                    return false;
                }
            }
        }
        return true;
        L306: ;
        if (handler != null) {
            i = handler.field_7761.iterator();
            while (i.hasNext()) {
                s = (class_1735)i.next();
                if (s == null) continue;
                while (s.method_7677().method_7960()) {
                }
                stack = s.method_7677();
                int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, s.field_7874);
                while (entryTarget.hasIdentity()) {
                    if (entryTarget.matches(stack, visibleSlot)) break;
                }
                if (!this.checkStack(stack, entryTarget, visibleSlot, e, entryIdx)) continue;
                return true;
            }
        } else {
            for (i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
                stack = mc.field_1724.method_31548().method_5438(i);
                if (stack.method_7960()) {
                } else {
                    if (entryTarget.hasIdentity()) {
                    } else {
                        if (!this.checkStack(stack, entryTarget, i, e, entryIdx)) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean checkStack(class_1799 stack, ItemTarget target, int visibleSlot, WaitForSlotChangeAction.WaitEntry e, int entryIdx) {
        if (target != null) {
            if (target.hasIdentity()) {
                if (stack.method_7960()) { /* goto @31; */ }
            }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L32; */
        L31: ;
        L32: ;
        boolean nameMatches = false;
        switch (MacroConditionRegistry.1.$SwitchMap$com$example$addon$util$macro$WaitForSlotChangeAction$WaitMode[e.waitMode.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                if (!nameMatches) { /* goto @106; */ }
                return !stack.method_7960();
            case 2::
                return stack.method_7960();
            case 3::
                if (!nameMatches) { /* goto @145; */ }
                if (stack.method_7947() < e.targetCount) { /* goto @145; */ }
                return !stack.method_7960();
            case 4::
                if (!stack.method_7960()) {
                    if (!nameMatches) { /* goto @177; */ }
                }
                /* note: clearing non-empty stack before goto */
                /* goto @276; */
                L177: ;
                return false;
            case 5::
                String initName = (String)this.initialNames.getOrDefault(entryIdx, "");
                int initCount = ((Integer)this.initialCounts.getOrDefault(entryIdx, 0)).intValue();
                String curName = MacroConditionRegistry.snapshotStackIdentity(stack);
                int curCount = stack.method_7960() ? 0 : stack.method_7947();
                if (!curName.equals(initName)) { /* goto L268; */ }
                return curCount != initCount;
        }
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
