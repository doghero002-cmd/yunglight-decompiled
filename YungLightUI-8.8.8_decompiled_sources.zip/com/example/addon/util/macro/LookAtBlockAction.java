/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.RotateAction;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_7923;

public class LookAtBlockAction
implements MacroAction {
    public int blockX = 0;
    public int blockY = 0;
    public int blockZ = 0;
    public LookAtBlockAction.TargetMode targetMode = LookAtBlockAction.TargetMode.SPECIFIC;
    public List<String> blockIds = new ArrayList();
    public List<String> entityIds = new ArrayList();
    public double searchRadius = 16;
    public boolean smooth;
    public int smoothness = 6;
    public boolean waitForCompletion = true;
    private boolean enabled = true;

    public LookAtBlockAction() {
    }

    public LookAtBlockAction(int x, int y, int z) {
        this.blockX = x;
        this.blockY = y;
        this.blockZ = z;
        this.targetMode = LookAtBlockAction.TargetMode.SPECIFIC;
    }

    public static String toSpecificEntityEntry(class_1297 entity) {
        if (entity == null) {
            return "";
        }
        String typeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
        String displayName = entity.method_5476().getString().replaceAll("§.", "").trim();
        return "~" + entity.method_5845() + "~" + typeId + "~" + displayName;
    }

    public double getRotationStep() {
        return RotateAction.smoothnessToRotationStep(this.smoothness);
    }

    public LookAtBlockAction.RotationTarget resolveRotationTarget(class_310 mc) {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
            return null;
        }
        switch (this.targetMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return LookAtBlockAction.rotationTo(mc.field_1724.method_33571(), new class_243((double)this.blockX + 0.5, (double)this.blockY + 0.5, (double)this.blockZ + 0.5));
            case 1::
                return this.resolveNearestBlockTarget(mc);
            case 2::
                return this.resolveNearestEntityTarget(mc);
        }
    }

    public void execute(class_310 mc) {
        if (mc == null || mc.field_1724 == null) {
            return;
        }
        RotationTarget target = this.resolveRotationTarget(mc);
        if (target == null || this.smooth) {
            return;
        }
        mc.field_1724.method_36456(target.yaw());
        mc.field_1724.method_36457(target.pitch());
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("blockX", this.blockX);
        tag.method_10569("blockY", this.blockY);
        tag.method_10569("blockZ", this.blockZ);
        tag.method_10582("targetMode", this.targetMode.name());
        class_2499 blocks = new class_2499();
        class_2499 entities = this.blockIds.iterator();
        while (entities.hasNext()) {
            String id = (String)entities.next();
            blocks.add(class_2519.method_23256(id));
        }
        tag.method_10566("blockIds", blocks);
        entities = new class_2499();
        id = this.entityIds.iterator();
        while (id.hasNext()) {
            String id = (String)id.next();
            entities.add(class_2519.method_23256(id));
        }
        tag.method_10566("entityIds", entities);
        tag.method_10549("searchRadius", this.searchRadius);
        tag.method_10556("smooth", this.smooth);
        tag.method_10569("smoothness", RotateAction.clampSmoothness(this.smoothness));
        tag.method_10556("waitForCompletion", this.waitForCompletion);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("blockX")) {
            this.blockX = tag.method_68083("blockX", 0);
        }
        if (tag.method_10545("blockY")) {
            this.blockY = tag.method_68083("blockY", 0);
        }
        if (tag.method_10545("blockZ")) {
            this.blockZ = tag.method_68083("blockZ", 0);
        }
        try {
            this.targetMode = LookAtBlockAction.TargetMode.valueOf(tag.method_68564("targetMode", LookAtBlockAction.TargetMode.SPECIFIC.name()));
        }
        catch (Exception ignored) {
            this.targetMode = LookAtBlockAction.TargetMode.SPECIFIC;
            /* goto @109; */
        }
        this.blockIds.clear();
        if (!tag.method_10545("blockIds")) { /* goto L214; */ }
        blocks = (class_2499)tag.method_10554("blockIds").orElse(new class_2499());
        var var3 = blocks.iterator();
        while (var3.hasNext()) {
            class_2520 el = (class_2520)var3.next();
            String value = (String)el.method_68658().orElse("");
            if (value.isEmpty()) continue;
            this.blockIds.add(value);
        }
        this.entityIds.clear();
        if (!tag.method_10545("entityIds")) { /* goto L319; */ }
        entities = (class_2499)tag.method_10554("entityIds").orElse(new class_2499());
        var3 = entities.iterator();
        while (var3.hasNext()) {
            el = (class_2520)var3.next();
            value = (String)el.method_68658().orElse("");
            if (value.isEmpty()) continue;
            this.entityIds.add(value);
        }
        this.searchRadius = Math.max(1, tag.method_68563("searchRadius", 16));
        this.smooth = tag.method_68566("smooth", false);
        this.smoothness = RotateAction.clampSmoothness(tag.method_68083("smoothness", 6));
        this.waitForCompletion = tag.method_68566("waitForCompletion", true);
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.LOOK_AT_BLOCK;
    }

    public String getDisplayName() {
        switch (this.targetMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                String targetLabel = "(" + this.blockX + ", " + this.blockY + ", " + this.blockZ + ")";
                break;
            case 1::
                targetLabel = this.formatBlockTargets();
                break;
            case 2::
                targetLabel = this.formatEntityTargets();
                break;
        }
        String suffix = this.smooth ? " (Smooth)" : "";
        if (!this.waitForCompletion) {
            suffix = suffix + " [NoWait]";
        }
        return "Look At " + targetLabel + suffix;
    }

    public String getIcon() {
        return "LAB";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private LookAtBlockAction.RotationTarget resolveNearestBlockTarget(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || this.blockIds.isEmpty()) {
            return null;
        }
        class_243 eyePos = mc.field_1724.method_33571();
        class_2338 center = mc.field_1724.method_24515();
        int radius = Math.max(1, class_3532.method_15384(this.searchRadius));
        double bestSq = this.searchRadius * this.searchRadius;
        class_2338 bestPos = null;
        Set<String> wanted = new HashSet(this.blockIds);
        class_2339 mutable = new class_2338.class_2339();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    mutable.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    class_243 targetPos = class_243.method_24953(mutable);
                    double distSq = eyePos.method_1025(targetPos);
                    if (distSq > bestSq) {
                    } else {
                        class_2248 block = mc.field_1687.method_8320(mutable).method_26204();
                        String id = class_7923.field_41175.method_10221(block).toString();
                        if (!wanted.contains(id)) {
                        } else {
                            bestSq = distSq;
                            bestPos = mutable.method_10062();
                        }
                    }
                }
            }
        }
        return bestPos == null ? null : LookAtBlockAction.rotationTo(eyePos, class_243.method_24953(bestPos));
    }

    private LookAtBlockAction.RotationTarget resolveNearestEntityTarget(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || this.entityIds.isEmpty()) {
            return null;
        }
        Set<String> typeIds = new HashSet();
        Set<String> specificUuids = new HashSet();
        double maxSq = this.entityIds.iterator();
        while (maxSq.hasNext()) {
            String entry = (String)maxSq.next();
            if (entry == null) continue;
            while (entry.isBlank()) {
            }
            if (entry.startsWith("~")) {
                String[] parts = entry.split("~", 4);
                if (parts.length >= 2) {
                    if (parts[1].isBlank()) continue;
                    specificUuids.add(parts[1]);
                }
            } else {
                typeIds.add(entry);
            }
        }
        maxSq = this.searchRadius * this.searchRadius;
        double bestSq = maxSq;
        class_1297 bestEntity = null;
        class_243 targetPos = mc.field_1687.method_18112().iterator();
        while (targetPos.hasNext()) {
            class_1297 entity = (class_1297)targetPos.next();
            if (entity == null) continue;
            if (entity == mc.field_1724) continue;
            while (!entity.method_5805()) {
            }
            double distSq = mc.field_1724.method_5858(entity);
            while (distSq > bestSq) {
            }
            while (!this.matchesEntity(entity, typeIds, specificUuids)) {
            }
            bestSq = distSq;
            bestEntity = entity;
        }
        if (bestEntity == null) {
            return null;
        }
        targetPos = bestEntity.method_5829().method_1005();
        return LookAtBlockAction.rotationTo(mc.field_1724.method_33571(), targetPos);
    }

    private boolean matchesEntity(class_1297 entity, Set<String> typeIds, Set<String> specificUuids) {
        if (specificUuids.contains(entity.method_5845())) {
            return true;
        }
        String typeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
        return typeIds.contains(typeId);
    }

    private String formatBlockTargets() {
        if (this.blockIds.isEmpty()) {
            return "Block (none)";
        }
        String first = PackUtilRegistryLabels.block((String)this.blockIds.get(0));
        return this.blockIds.size() == 1 ? "Nearest " + first : "Nearest " + first + " (+" + this.blockIds.size() - 1 + ")";
    }

    private String formatEntityTargets() {
        if (this.entityIds.isEmpty()) {
            return "Entity (none)";
        }
        String firstEntry = (String)this.entityIds.get(0);
        if (firstEntry.startsWith("~")) {
            String[] parts = firstEntry.split("~", 4);
            String rawName = parts.length >= 4 ? parts[3] : "";
            String type = parts.length >= 3 ? PackUtilRegistryLabels.entity(parts[2]) : "?";
            String first = rawName == null || rawName.isBlank() ? type : rawName + " (" + type + ")";
        } else {
            String first = PackUtilRegistryLabels.entity(firstEntry);
        }
        return this.entityIds.size() == 1 ? "Nearest " + first : "Nearest " + first + " (+" + this.entityIds.size() - 1 + ")";
    }

    private static LookAtBlockAction.RotationTarget rotationTo(class_243 from, class_243 to) {
        class_243 diff = to.method_1020(from);
        double dist = Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350);
        float yaw = (float)Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
        float pitch = (float)-Math.toDegrees(Math.atan2(diff.field_1351, dist));
        return new LookAtBlockAction.RotationTarget(yaw, pitch);
    }
}
