/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static final record LookAtBlockAction.RotationTarget {
    private final float yaw;
    private final float pitch;

    public LookAtBlockAction.RotationTarget(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public float yaw() {
        return this.yaw;
    }

    public float pitch() {
        return this.pitch;
    }
}
