/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class RepeatAction
implements MacroAction {
    public int stepCount = 1;
    public int repeatCount = 2;
    private boolean enabled = true;

    public RepeatAction() {
    }

    public RepeatAction(int stepCount, int repeatCount) {
        this.stepCount = stepCount;
        this.repeatCount = repeatCount;
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("stepCount", this.stepCount);
        tag.method_10569("repeatCount", this.repeatCount);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("stepCount")) {
            this.stepCount = tag.method_68083("stepCount", 1);
        }
        if (tag.method_10545("repeatCount")) {
            this.repeatCount = tag.method_68083("repeatCount", 2);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.REPEAT;
    }

    public String getDisplayName() {
        return "Repeat next " + this.stepCount + " step" + this.stepCount != 1 ? "s" : "" + " x" + this.repeatCount;
    }

    public String getIcon() {
        return "RPT";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
