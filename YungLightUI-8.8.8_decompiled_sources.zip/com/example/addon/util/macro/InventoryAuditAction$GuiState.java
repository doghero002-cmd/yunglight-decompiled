/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

private static final record InventoryAuditAction.GuiState {
    private final boolean open;
    private final int syncId;
    private final int slotCount;
    private final int filledSlots;
    private final int totalItems;

    private InventoryAuditAction.GuiState(boolean open, int syncId, int slotCount, int filledSlots, int totalItems) {
        this.open = open;
        this.syncId = syncId;
        this.slotCount = slotCount;
        this.filledSlots = filledSlots;
        this.totalItems = totalItems;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public boolean open() {
        return this.open;
    }

    public int syncId() {
        return this.syncId;
    }

    public int slotCount() {
        return this.slotCount;
    }

    public int filledSlots() {
        return this.filledSlots;
    }

    public int totalItems() {
        return this.totalItems;
    }
}
