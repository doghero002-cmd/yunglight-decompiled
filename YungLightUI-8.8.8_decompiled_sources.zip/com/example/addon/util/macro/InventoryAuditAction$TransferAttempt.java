/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import java.util.Map;

private static final record InventoryAuditAction.TransferAttempt {
    private final int slotCount;
    private final Map<String, Integer> itemCounts;

    private InventoryAuditAction.TransferAttempt(int slotCount, Map<String, Integer> itemCounts) {
        this.slotCount = slotCount;
        this.itemCounts = itemCounts;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int slotCount() {
        return this.slotCount;
    }

    public Map<String, Integer> itemCounts() {
        return this.itemCounts;
    }
}
