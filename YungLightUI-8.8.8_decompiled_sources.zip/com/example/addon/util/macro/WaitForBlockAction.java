/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class WaitForBlockAction
implements MacroAction {
    public WaitForBlockAction.CheckMode checkMode = WaitForBlockAction.CheckMode.AT_POSITION;
    public WaitForBlockAction.WaitBehavior waitBehavior = WaitForBlockAction.WaitBehavior.PLACED;
    public boolean anyBlock = true;
    public List<String> blockIds = new ArrayList();
    public class_2338 blockPos;
    public boolean mustBeInReach;
    public double searchRadius;
    private boolean enabled;

    public WaitForBlockAction() {
        this.blockPos = class_2338.field_10980;
        this.mustBeInReach = false;
        this.searchRadius = 8;
        this.enabled = true;
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_BLOCK;
    }

    public void execute(class_310 mc) {
    }

    public String getDisplayName() {
        if (this.anyBlock) {
            String blockDesc = this.waitBehavior == WaitForBlockAction.WaitBehavior.DESTROYED ? "any block gone" : "any block";
        } else {
            if (this.blockIds.isEmpty()) {
                String blockDesc = "no blocks set";
            } else {
                String blockDesc = PackUtilRegistryLabels.block((String)this.blockIds.get(0));
                if (this.blockIds.size() > 1) {
                    blockDesc = blockDesc + " (+" + this.blockIds.size() - 1 + ")";
                }
            }
        }
        String verb = this.waitBehavior == WaitForBlockAction.WaitBehavior.DESTROYED ? "Destroyed" : "Placed";
        switch (this.checkMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return "Wait " + verb + " @ " + this.blockPos.method_10263() + "," + this.blockPos.method_10264() + "," + this.blockPos.method_10260();
            case 1::
                return "Wait " + verb + ": " + blockDesc + " nearby";
            case 2::
                return "Wait " + verb + ": look at " + blockDesc;
        }
    }

    public String getIcon() {
        return "Blk";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("checkMode", this.checkMode.name());
        tag.method_10582("waitBehavior", this.waitBehavior.name());
        tag.method_10556("anyBlock", this.anyBlock);
        tag.method_10569("x", this.blockPos.method_10263());
        tag.method_10569("y", this.blockPos.method_10264());
        tag.method_10569("z", this.blockPos.method_10260());
        tag.method_10556("mustBeInReach", this.mustBeInReach);
        tag.method_10549("searchRadius", this.searchRadius);
        class_2499 list = new class_2499();
        var var3 = this.blockIds.iterator();
        while (var3.hasNext()) {
            String id = (String)var3.next();
            list.add(class_2519.method_23256(id));
        }
        tag.method_10566("blockIds", list);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.checkMode = WaitForBlockAction.CheckMode.valueOf(tag.method_68564("checkMode", "AT_POSITION"));
        }
        catch (IllegalArgumentException ignored) {
            this.checkMode = WaitForBlockAction.CheckMode.AT_POSITION;
            L36: ;
            if (!tag.method_10545("waitBehavior")) { /* goto @72; */ }
            this.waitBehavior = WaitForBlockAction.WaitBehavior.valueOf(tag.method_68564("waitBehavior", "PLACED"));
            /* goto @72; */
        }
        try {
            this.waitBehavior = WaitForBlockAction.WaitBehavior.valueOf(tag.method_68564("waitBehavior", "PLACED"));
        }
        catch (IllegalArgumentException ignored) {
            this.waitBehavior = WaitForBlockAction.WaitBehavior.PLACED;
            L72: ;
            if (tag.method_10545("anyBlock")) {
                this.anyBlock = tag.method_68566("anyBlock", true);
            }
            if (tag.method_10545("x")) {
                if (tag.method_10545("y")) {
                    if (tag.method_10545("z")) {
                        this.blockPos = new class_2338(tag.method_68083("x", 0), tag.method_68083("y", 0), tag.method_68083("z", 0));
                    }
                }
            }
            this.mustBeInReach = tag.method_68566("mustBeInReach", false);
            this.searchRadius = tag.method_68563("searchRadius", 8);
            this.blockIds.clear();
            if (!tag.method_10545("blockIds")) { /* goto @282; */ }
            list = (class_2499)tag.method_10554("blockIds").orElse(new class_2499());
            var var3 = list.iterator();
            while (var3.hasNext()) {
                class_2520 el = (class_2520)var3.next();
                String s = (String)el.method_68658().orElse("");
                if (s.isEmpty()) continue;
                this.blockIds.add(s);
            }
        }
        if (tag.method_10545("anyBlock")) {
            this.anyBlock = tag.method_68566("anyBlock", true);
        }
        if (tag.method_10545("x")) {
            if (tag.method_10545("y")) {
                if (tag.method_10545("z")) {
                    this.blockPos = new class_2338(tag.method_68083("x", 0), tag.method_68083("y", 0), tag.method_68083("z", 0));
                }
            }
        }
        this.mustBeInReach = tag.method_68566("mustBeInReach", false);
        this.searchRadius = tag.method_68563("searchRadius", 8);
        this.blockIds.clear();
        if (tag.method_10545("blockIds")) {
            list = (class_2499)tag.method_10554("blockIds").orElse(new class_2499());
            var3 = list.iterator();
            while (var3.hasNext()) {
                el = (class_2520)var3.next();
                s = (String)el.method_68658().orElse("");
                if (s.isEmpty()) continue;
                this.blockIds.add(s);
            }
        } else {
            if (!tag.method_10545("blocks")) { /* goto @379; */ }
            list = (class_2499)tag.method_10554("blocks").orElse(new class_2499());
            var3 = list.iterator();
            while (var3.hasNext()) {
                el = (class_2520)var3.next();
                s = (String)el.method_68658().orElse("");
                if (s.isEmpty()) continue;
                this.blockIds.add(s);
            }
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }
}
