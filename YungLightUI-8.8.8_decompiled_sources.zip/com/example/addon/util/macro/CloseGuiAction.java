/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class CloseGuiAction
implements MacroAction {
    public String guiName = "";
    public String itemName = "";
    public ItemTarget itemTarget = new ItemTarget();
    public int targetSlot = -1;
    public boolean useItemFilter = false;
    public boolean sendPacket = true;
    private boolean enabled = true;

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1755 == null) {
            return;
        }
        boolean matchGui = true;
        if (!this.guiName.isEmpty()) {
            matchGui = mc.field_1755.method_25440().getString().toLowerCase().contains(this.guiName.toLowerCase());
        }
        boolean matchItem = true;
        ItemTarget target = this.resolvedItemTarget();
        if (!this.useItemFilter) { /* goto L294; */ }
        if (target.hasSlot()) { /* goto L84; */ }
        if (!target.hasIdentity()) { /* goto L294; */ }
        L84: ;
        matchItem = false;
        if (mc.field_1724.field_7512 == null) { /* goto L294; */ }
        int effectiveSlot = target.hasSlot() ? target.slot : this.targetSlot;
        int resolvedTargetSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, effectiveSlot);
        if (resolvedTargetSlot >= 0) {
            if (resolvedTargetSlot < mc.field_1724.field_7512.field_7761.size()) {
                class_1799 stack = ((class_1735)mc.field_1724.field_7512.field_7761.get(resolvedTargetSlot)).method_7677();
                int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, resolvedTargetSlot);
                if (!stack.method_7960()) {
                    if (target.matches(stack, visibleSlot)) {
                        matchItem = true;
                    }
                }
            }
        } else {
            if (effectiveSlot != -1) { /* goto @294; */ }
            var stack = mc.field_1724.field_7512.field_7761.iterator();
            while (stack.hasNext()) {
                class_1735 slot = (class_1735)stack.next();
                class_1799 stack = slot.method_7677();
                int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, slot.field_7874);
                if (stack.method_7960()) { /* goto @291; */ }
                if (!target.matches(stack, visibleSlot)) { /* goto @291; */ }
                matchItem = true;
                break;
            }
        }
        if (matchGui) {
            if (matchItem) {
                if (!this.sendPacket) {
                    PackUtilSharedState.get().setSuppressNextClosePacket(true);
                }
                mc.field_1724.method_7346();
            }
        }
    }

    public MacroActionType getType() {
        return MacroActionType.CLOSE_GUI;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "CLOSE_GUI");
        tag.method_10582("guiName", this.guiName);
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            tag.method_10566("itemName", target.toTag());
        }
        tag.method_10556("useItemFilter", this.useItemFilter);
        tag.method_10556("sendPacket", this.sendPacket);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
        this.itemTarget = (ItemTarget)tag.method_10562("itemName").map(ItemTarget::fromTag).orElseGet(CloseGuiAction::lambda$fromTag$0 /* captured: tag */);
        this.itemName = this.itemTarget.toLegacyEntry();
        this.targetSlot = this.itemTarget.hasSlot() ? this.itemTarget.slot : -1;
        if (tag.method_10545("useItemFilter")) {
            this.useItemFilter = tag.method_68566("useItemFilter", false);
        } else {
            if (this.itemTarget.hasSlot()) { /* goto L131; */ }
            this.useItemFilter = this.itemTarget.hasIdentity();
        }
        if (tag.method_10545("sendPacket")) {
            this.sendPacket = tag.method_68566("sendPacket", true);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        String base = !this.guiName.isEmpty() ? "Close GUI: " + this.guiName : "Close GUI";
        return this.sendPacket ? base : base + " (desync)";
    }

    public String getIcon() {
        return "X";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }

    private ItemTarget resolvedItemTarget() {
        if (this.itemTarget != null) {
            if (this.itemTarget.hasSlot() || this.itemTarget.hasIdentity()) {
                return this.itemTarget;
            }
        }
        if (this.targetSlot >= 0) {
            if (!this.itemName.isBlank()) {
                this.itemTarget = ItemTarget.fromLegacyEntry("#" + this.targetSlot + "|" + this.itemName);
            }
        } else {
            if (this.targetSlot >= 0) {
                this.itemTarget = ItemTarget.slotOnly(this.targetSlot);
            } else {
                this.itemTarget = ItemTarget.fromLegacyEntry(this.itemName);
            }
        }
        return this.itemTarget;
    }
}
