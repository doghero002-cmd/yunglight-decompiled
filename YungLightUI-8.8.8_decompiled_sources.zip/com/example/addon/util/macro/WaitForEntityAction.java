/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class WaitForEntityAction
implements MacroAction {
    public List<String> entityIds = new ArrayList();
    public boolean mustBeLookingAt = false;
    public WaitForEntityAction.CheckMode checkMode = WaitForEntityAction.CheckMode.RADIUS;
    public boolean centerOnPlayer = true;
    public double radius = 6;
    public double x = 0;
    public double y = 0;
    public double z = 0;
    private boolean enabled = true;

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        class_2499 list = new class_2499();
        var var3 = this.entityIds.iterator();
        while (var3.hasNext()) {
            String id = (String)var3.next();
            list.add(class_2519.method_23256(id));
        }
        tag.method_10566("entityIds", list);
        tag.method_10556("mustBeLookingAt", this.mustBeLookingAt);
        tag.method_10556("centerOnPlayer", this.centerOnPlayer);
        tag.method_10549("radius", this.radius);
        tag.method_10549("x", this.x);
        tag.method_10549("y", this.y);
        tag.method_10549("z", this.z);
        tag.method_10556("enabled", this.enabled);
        tag.method_10582("checkMode", this.checkMode.name());
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.entityIds.clear();
        if (tag.method_10545("entityIds")) {
            class_2499 list = (class_2499)tag.method_10554("entityIds").orElse(new class_2499());
            String tryId = list.iterator();
            while (tryId.hasNext()) {
                class_2520 el = (class_2520)tryId.next();
                String s = (String)el.method_68658().orElse("");
                if (s.isEmpty()) continue;
                this.entityIds.add(s);
            }
        } else {
            if (tag.method_10545("entityName")) {
                String oldName = tag.method_68564("entityName", "");
                if (!oldName.isEmpty()) {
                    String tryId = "minecraft:" + oldName.toLowerCase().replace(" ", "_");
                }
            }
        }
        try {
            class_2960 id = class_2960.method_60654(tryId);
            if (class_7923.field_41177.method_10250(id)) {
                this.entityIds.add(tryId);
            }
        }
        catch (Exception id) {
            this.mustBeLookingAt = tag.method_68566("mustBeLookingAt", false);
            if (!tag.method_10545("checkMode")) { /* goto @232; */ }
            this.checkMode = WaitForEntityAction.CheckMode.valueOf(tag.method_68564("checkMode", "RADIUS"));
            /* goto @252; */
        }
        this.mustBeLookingAt = tag.method_68566("mustBeLookingAt", false);
        try {
            this.checkMode = WaitForEntityAction.CheckMode.valueOf(tag.method_68564("checkMode", "RADIUS"));
        }
        catch (Exception e) {
            this.checkMode = WaitForEntityAction.CheckMode.RADIUS;
            /* goto @252; */
        }
        this.centerOnPlayer = tag.method_68566("centerOnPlayer", true);
        this.radius = tag.method_68563("radius", 6);
        this.x = tag.method_68563("x", 0);
        this.y = tag.method_68563("y", 0);
        this.z = tag.method_68563("z", 0);
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_ENTITY;
    }

    public String getDisplayName() {
        if (this.entityIds.isEmpty()) {
            String first = "any";
        } else {
            String e0 = (String)this.entityIds.get(0);
            if (e0.startsWith("~")) {
                String[] p = e0.split("~", 4);
                String display = p.length >= 4 ? p[3] : "";
                String type = p.length >= 3 ? PackUtilRegistryLabels.entity(p[2]) : "?";
                String first = "SPEC " + display == null || display.isBlank() ? type : display;
            } else {
                String first = PackUtilRegistryLabels.entity(e0);
            }
            if (this.entityIds.size() > 1) {
                first = first + " (+" + this.entityIds.size() - 1 + ")";
            }
        }
        switch (this.checkMode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                modeStr = "r=" + (int)this.radius;
                break;
            case 1::
                modeStr = "look";
                break;
            case 2::
                modeStr = "reach";
                break;
        }
        return "Wait Entity: " + first + " (" + modeStr + ")";
    }

    public String getIcon() {
        return "ENT";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
