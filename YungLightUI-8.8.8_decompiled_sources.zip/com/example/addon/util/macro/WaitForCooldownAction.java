/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class WaitForCooldownAction
implements MacroAction {
    public String itemName = "";
    public ItemTarget itemTarget = new ItemTarget();
    public boolean checkMainHand = true;

    public WaitForCooldownAction() {
    }

    public WaitForCooldownAction(String itemName, boolean checkMainHand) {
        this.itemName = itemName;
        this.itemTarget = ItemTarget.fromLegacyEntry(itemName);
        this.checkMainHand = checkMainHand;
    }

    public void execute(class_310 mc) {
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        ItemTarget target = this.resolvedItemTarget();
        if (target.hasSlot() || target.hasIdentity()) {
            tag.method_10566("itemName", target.toTag());
        }
        tag.method_10556("checkMainHand", this.checkMainHand);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.itemTarget = (ItemTarget)tag.method_10562("itemName").map(ItemTarget::fromTag).orElseGet(WaitForCooldownAction::lambda$fromTag$0 /* captured: tag */);
        this.itemName = this.itemTarget.toLegacyEntry();
        if (tag.method_10545("checkMainHand")) {
            this.checkMainHand = tag.method_68566("checkMainHand", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.WAIT_COOLDOWN;
    }

    public String getDisplayName() {
        ItemTarget target = this.resolvedItemTarget();
        String base = target.hasSlot() || target.hasIdentity() ? target.summaryText() : this.checkMainHand ? "Main Hand" : "Off Hand";
        if (base.length() > 10) {
            base = base.substring(0, 8) + "..";
        }
        return "Wait Cooldown (" + base + ")";
    }

    public String getIcon() {
        return "CD";
    }

    private ItemTarget resolvedItemTarget() {
        if (this.itemTarget != null) {
            if (this.itemTarget.hasSlot() || this.itemTarget.hasIdentity()) {
                return this.itemTarget;
            }
        }
        this.itemTarget = ItemTarget.fromLegacyEntry(this.itemName);
        return this.itemTarget;
    }
}
