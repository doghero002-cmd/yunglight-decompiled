/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilCraftingHelper;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_310;

public class CraftAction
implements MacroAction {
    public final List<CraftAction.CraftEntry> entries = new ArrayList();

    public void clearEntries() {
        this.entries.clear();
    }

    public boolean hasEntries() {
        return this.entries.stream().anyMatch(CraftAction.CraftEntry::hasRecipe);
    }

    public List<CraftAction.CraftEntry> copyEntries() {
        List<CraftAction.CraftEntry> copies = new ArrayList(this.entries.size());
        var var2 = this.entries.iterator();
        while (var2.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var2.next();
            if (entry == null) continue;
            copies.add(entry.copy());
        }
        return copies;
    }

    public void setEntries(List<CraftAction.CraftEntry> values) {
        this.entries.clear();
        if (values == null) {
            return;
        }
        var var2 = values.iterator();
        while (var2.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var2.next();
            if (entry == null) continue;
            this.entries.add(entry.copy());
        }
    }

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("No network connection!");
            return;
        }
        if (!this.hasEntries()) {
            PackUtilClientMessaging.sendPrefixed("No craft recipe selected!");
            return;
        }
        var var2 = this.entries.iterator();
        while (var2.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var2.next();
            if (entry == null) continue;
            while (!entry.hasRecipe()) {
            }
            CraftableRecipeOption option = PackUtilCraftingHelper.findCraftableRecipe(mc, entry.recipeKey);
            if (option != null) continue;
            option = PackUtilCraftingHelper.findCraftableRecipe(mc, entry.recipeId);
            if (option == null) {
                PackUtilClientMessaging.sendPrefixed("§cRecipe not found: " + entry.resultName);
                return;
            }
            int desiredAmount = PackUtilCraftingHelper.getEffectiveRequestedOutput(option, entry.amount, entry.useMaxAmount);
            if (desiredAmount <= 0) {
                PackUtilClientMessaging.sendPrefixed("§cNo space or materials for " + entry.resultName + ".");
                return;
            }
            CraftExecutionResult result = PackUtilCraftingHelper.executeCraftImmediately(mc, entry.recipeKey, entry.recipeId, desiredAmount);
            if (!result.success) {
                PackUtilClientMessaging.sendPrefixed("§c" + result.message);
                return;
            }
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "CRAFT");
        class_2499 entryTags = new class_2499();
        var var3 = this.entries.iterator();
        while (var3.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var3.next();
            if (entry != null) {
                if (!entry.hasRecipe()) continue;
                entryTags.add(entry.toTag());
            }
        }
        tag.method_10566("entries", entryTags);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.entries.clear();
        if (tag == null) {
            return;
        }
        if (!tag.method_10545("entries")) { /* goto L113; */ }
        class_2499 entryTags = (class_2499)tag.method_10554("entries").orElse(new class_2499());
        var var3 = entryTags.iterator();
        while (var3.hasNext()) {
            class_2520 element = (class_2520)var3.next();
            if (element instanceof class_2487) {
                class_2487 entryTag = (class_2487)element;
                CraftEntry entry = CraftAction.CraftEntry.fromTag(entryTag);
                if (!entry.hasRecipe()) continue;
                this.entries.add(entry);
            }
        }
        if (this.entries.isEmpty()) {
            legacyEntry = CraftAction.CraftEntry.fromTag(tag);
            if (legacyEntry.hasRecipe()) {
                this.entries.add(legacyEntry);
            }
        }
    }

    public MacroActionType getType() {
        return MacroActionType.CRAFT;
    }

    public String getDisplayName() {
        if (!this.hasEntries()) {
            return "Craft (empty)";
        }
        CraftEntry first = (CraftAction.CraftEntry)this.entries.get(0);
        if (this.entries.size() == 1) {
            return "Craft " + first.getDisplayName();
        }
        String firstName = first.resultName == null || first.resultName.isBlank() ? "item" : first.resultName;
        return "Craft " + firstName + " (+" + this.entries.size() - 1 + ")";
    }

    public String getIcon() {
        return "C";
    }
}
