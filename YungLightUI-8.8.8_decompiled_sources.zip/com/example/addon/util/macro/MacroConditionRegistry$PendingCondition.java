/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import net.minecraft.class_310;

static interface MacroConditionRegistry.PendingCondition {
    public boolean check(class_310 var1);

    public void complete();

    public void cancel();

    public boolean isCancelled();
}
