/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.ToggleModuleAction;
import net.minecraft.class_2487;

public static class ToggleModuleAction.ModuleEntry {
    public String moduleName = "";
    public ToggleModuleAction.ToggleMode toggleMode = ToggleModuleAction.ToggleMode.TOGGLE;

    public ToggleModuleAction.ModuleEntry() {
    }

    public ToggleModuleAction.ModuleEntry(String moduleName, ToggleModuleAction.ToggleMode toggleMode) {
        this.moduleName = moduleName == null ? "" : moduleName.trim();
        this.toggleMode = toggleMode == null ? ToggleModuleAction.ToggleMode.TOGGLE : toggleMode;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("moduleName", this.moduleName);
        tag.method_10582("toggleMode", this.toggleMode.name());
        return tag;
    }

    public static ToggleModuleAction.ModuleEntry fromTag(class_2487 tag) {
        ModuleEntry entry = new ToggleModuleAction.ModuleEntry();
        if (tag.method_10545("moduleName")) {
            entry.moduleName = tag.method_68564("moduleName", "");
        }
        try {
            entry.toggleMode = ToggleModuleAction.ToggleMode.valueOf(tag.method_68564("toggleMode", "TOGGLE"));
        }
        catch (IllegalArgumentException ignored) {
            entry.toggleMode = ToggleModuleAction.ToggleMode.TOGGLE;
            L64: ;
            return entry;
        }
        return entry;
    }
}
