/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class SprintAction
implements MacroAction {
    public boolean sprint = true;
    private boolean enabled = true;
    public boolean persistent = false;

    public SprintAction() {
    }

    public SprintAction(boolean sprint) {
        this.sprint = sprint;
    }

    public void execute(class_310 mc) {
        if (mc.field_1690 != null) {
            if (mc.field_1690.field_1867 != null) {
                mc.field_1690.field_1867.method_23481(this.sprint);
            }
        }
        if (mc.field_1724 != null) {
            mc.field_1724.method_5728(this.sprint);
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10556("sprint", this.sprint);
        tag.method_10556("persistent", this.persistent);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("sprint")) {
            this.sprint = tag.method_68566("sprint", true);
        }
        if (tag.method_10545("persistent")) {
            this.persistent = tag.method_68566("persistent", false);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.SPRINT;
    }

    public String getDisplayName() {
        return "Sprint: " + this.sprint ? "ON" : "OFF" + this.persistent ? " [P]" : "";
    }

    public String getIcon() {
        return "SPR";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
