/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.macro.MacroExecutor;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ItemTarget {
    public static final String TAG_SLOT = "slot";
    public static final String TAG_REGISTRY_ID = "registryId";
    public static final String TAG_DISPLAY = "display";
    public static final String TAG_TEXT_JSON = "textJson";
    public static final String TAG_MANUAL = "manual";
    public int slot = -1;
    public String registryId = "";
    public String display = "";
    public String textJson = "";
    public boolean manual = false;

    public ItemTarget copy() {
        ItemTarget copy = new ItemTarget();
        copy.slot = this.slot;
        copy.registryId = this.registryId;
        copy.display = this.display;
        copy.textJson = this.textJson;
        copy.manual = this.manual;
        return copy;
    }

    public boolean hasSlot() {
        return this.slot >= 0;
    }

    public boolean hasRegistryId() {
        return this.registryId != null && !this.registryId.isBlank();
    }

    public boolean hasDisplay() {
        return this.display != null && !this.display.isBlank();
    }

    public boolean hasRichText() {
        return this.textJson != null && !this.textJson.isBlank();
    }

    public boolean hasIdentity() {
        return this.hasRegistryId() || this.hasDisplay() || this.hasRichText();
    }

    public class_2561 displayComponent() {
        class_2561 rich = MacroExecutor.deserializeTextComponent(this.textJson);
        if (rich != null) {
            return rich.method_27661();
        }
        return class_2561.method_43470(this.editorText());
    }

    public String editorText() {
        if (this.hasDisplay()) {
            return this.display;
        }
        if (this.hasRegistryId()) {
            return this.registryId;
        }
        return "";
    }

    public String summaryText() {
        String name = this.displayLabel();
        if (this.hasSlot() && !name.isBlank()) {
            return "Slot " + this.slot + ": " + name;
        }
        if (this.hasSlot()) {
            return "Slot " + this.slot;
        }
        return name;
    }

    public String displayLabel() {
        if (this.hasRichText()) {
            class_2561 rich = MacroExecutor.deserializeTextComponent(this.textJson);
            if (rich != null) {
                if (!rich.getString().isBlank()) {
                    return rich.getString();
                }
            }
        }
        if (this.hasDisplay()) {
            if (!this.hasRegistryId()) {
                return this.display;
            }
            registryLabel = PackUtilRegistryLabels.item(this.registryId);
            if (!PackUtilRegistryLabels.looksLikeRawIdentifierLabel(this.display, this.registryId) && !this.display.equalsIgnoreCase(registryLabel)) {
                return this.display;
            }
            return registryLabel;
        }
        if (this.hasRegistryId()) {
            return PackUtilRegistryLabels.item(this.registryId);
        }
        return "";
    }

    public class_2561 listComponent() {
        if (this.hasRichText()) {
            class_2561 rich = MacroExecutor.deserializeTextComponent(this.textJson);
            if (rich != null) {
                return rich.method_27661();
            }
        }
        return class_2561.method_43470(this.displayLabel());
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        if (this.hasSlot()) {
            tag.method_10569("slot", this.slot);
        }
        if (this.hasRegistryId()) {
            tag.method_10582("registryId", this.registryId);
        }
        if (this.hasDisplay()) {
            tag.method_10582("display", this.display);
        }
        if (this.hasRichText()) {
            tag.method_10582("textJson", this.textJson);
        }
        tag.method_10556("manual", this.manual);
        return tag;
    }

    public static ItemTarget fromTag(class_2487 tag) {
        ItemTarget target = new ItemTarget();
        if (tag == null) {
            return target;
        }
        if (tag.method_10545("slot")) {
            target.slot = tag.method_68083("slot", -1);
        }
        if (tag.method_10545("registryId")) {
            target.registryId = tag.method_68564("registryId", "");
        }
        if (tag.method_10545("display")) {
            target.display = tag.method_68564("display", "");
        }
        if (tag.method_10545("textJson")) {
            target.textJson = tag.method_68564("textJson", "");
        }
        if (tag.method_10545("manual")) {
            target.manual = tag.method_68566("manual", false);
        }
        return target;
    }

    public static ItemTarget fromElement(class_2520 element) {
        if (element instanceof class_2487) {
            class_2487 compound = (class_2487)element;
            return ItemTarget.fromTag(compound);
        }
        return ItemTarget.fromLegacyEntry(element == null ? "" : (String)element.method_68658().orElse(""));
    }

    public static List<ItemTarget> fromElementList(class_2499 list) {
        List<ItemTarget> targets = new ArrayList();
        if (list == null) {
            return targets;
        }
        var var2 = list.iterator();
        while (var2.hasNext()) {
            class_2520 element = (class_2520)var2.next();
            ItemTarget target = ItemTarget.fromElement(element);
            if (!target.hasSlot() || target.hasIdentity()) continue;
            targets.add(target);
        }
        return targets;
    }

    public static class_2499 toTagList(List<ItemTarget> targets) {
        class_2499 list = new class_2499();
        if (targets == null) {
            return list;
        }
        var var2 = targets.iterator();
        while (var2.hasNext()) {
            ItemTarget target = (ItemTarget)var2.next();
            while (target == null) {
            }
            while (!target.hasSlot()) {
                if (target.hasIdentity()) break;
            }
            list.add(target.toTag());
        }
        return list;
    }

    public static List<ItemTarget> copyList(List<ItemTarget> targets) {
        List<ItemTarget> copies = new ArrayList();
        if (targets == null) {
            return copies;
        }
        var var2 = targets.iterator();
        while (var2.hasNext()) {
            ItemTarget target = (ItemTarget)var2.next();
            if (target == null) continue;
            copies.add(target.copy());
        }
        return copies;
    }

    public static ItemTarget manualText(String text) {
        ItemTarget target = new ItemTarget();
        target.display = text == null ? "" : text.trim();
        target.manual = true;
        return target;
    }

    public static ItemTarget registry(String registryId) {
        ItemTarget target = new ItemTarget();
        target.registryId = registryId == null ? "" : registryId.trim();
        target.display = target.registryId;
        target.manual = false;
        return target;
    }

    public static ItemTarget slotOnly(int slot) {
        ItemTarget target = new ItemTarget();
        target.slot = slot;
        return target;
    }

    public static ItemTarget capture(class_1799 stack, int visibleSlot) {
        ItemTarget target = new ItemTarget();
        target.slot = visibleSlot;
        if (stack == null || stack.method_7960()) {
            return target;
        }
        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        target.registryId = id == null ? "" : id.toString();
        target.display = stack.method_7964().getString();
        target.manual = false;
        if (ItemTarget.shouldCaptureRichText(stack)) {
            target.textJson = MacroExecutor.serializeTextComponent(stack.method_7964());
        }
        return target;
    }

    public static ItemTarget fromLegacyEntry(String raw) {
        if (raw == null) {
            return new ItemTarget();
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return new ItemTarget();
        }
        ItemTarget target = new ItemTarget();
        String body = trimmed;
        if (!trimmed.startsWith("#")) { /* goto @149; */ }
        int separator = trimmed.indexOf(124);
        String slotPart = separator >= 0 ? trimmed.substring(1, separator).trim() : trimmed.substring(1).trim();
        try {
            int parsedSlot = Integer.parseInt(slotPart);
            if (parsedSlot >= 0) {
                target.slot = parsedSlot;
            }
        }
        catch (NumberFormatException ignored) {
            return ItemTarget.classifyFreeform(trimmed);
        }
        body = separator >= 0 && separator + 1 < trimmed.length() ? trimmed.substring(separator + 1).trim() : "";
        if (!body.isBlank()) {
            bodyTarget = ItemTarget.classifyFreeform(body);
            target.registryId = bodyTarget.registryId;
            target.display = bodyTarget.display;
            target.textJson = bodyTarget.textJson;
            target.manual = bodyTarget.manual;
        }
        return target;
    }

    public String toLegacyEntry() {
        String body = this.editorText();
        if (this.hasSlot() && body.isBlank()) {
            return "#" + this.slot;
        }
        if (this.hasSlot()) {
            return "#" + this.slot + "|" + body;
        }
        return body;
    }

    public int score(class_1799 stack, int visibleSlot) {
        if (stack == null || stack.method_7960()) {
            return -1;
        }
        if (this.hasSlot() && this.slot != visibleSlot) {
            return -1;
        }
        if (this.hasRichText()) {
            String stackJson = MacroExecutor.serializeTextComponent(stack.method_7964());
            if (this.textJson.equals(stackJson)) {
                return 400;
            }
            if (this.hasDisplay() && this.display.equals(stack.method_7964().getString())) {
                return 350;
            }
            return -1;
        }
        if (this.hasRegistryId()) {
            id = class_7923.field_41178.method_10221(stack.method_7909());
            if (id == null) {
                return -1;
            }
            String fullId = id.toString();
            String rawPath = id.method_12832();
            String spacedPath = rawPath.replace(95, 32);
            if (this.registryId.equalsIgnoreCase(fullId)) {
                return 320;
            }
            if (this.registryId.equalsIgnoreCase(rawPath)) {
                return 315;
            }
            if (this.registryId.equalsIgnoreCase(spacedPath)) {
                return 310;
            }
            if (this.hasDisplay()) {
                String normalizedDisplay = ItemTarget.normalize(this.display);
                if (normalizedDisplay.equals(ItemTarget.normalize(fullId))) {
                    return 305;
                }
                if (normalizedDisplay.equals(ItemTarget.normalize(rawPath))) {
                    return 304;
                }
                if (normalizedDisplay.equals(ItemTarget.normalize(spacedPath))) {
                    return 303;
                }
            }
            return -1;
        }
        if (!this.hasDisplay()) { /* goto L470; */ }
        normalizedTarget = ItemTarget.normalize(this.display);
        if (!normalizedTarget.isBlank()) { /* goto L294; */ }
        return this.hasSlot() ? 100 : -1;
        normalizedDisplay = ItemTarget.normalize(stack.method_7964().getString());
        if (!normalizedTarget.equals(normalizedDisplay)) { /* goto L334; */ }
        return this.manual ? 220 : 240;
        id = class_7923.field_41178.method_10221(stack.method_7909());
        if (id == null) { /* goto L468; */ }
        fullId = ItemTarget.normalize(id.toString());
        rawPath = ItemTarget.normalize(id.method_12832());
        String spacedPath = ItemTarget.normalize(id.method_12832().replace(95, 32));
        if (!normalizedTarget.equals(fullId)) { /* goto L416; */ }
        return this.manual ? 210 : 230;
        if (!normalizedTarget.equals(rawPath)) { /* goto L442; */ }
        return this.manual ? 205 : 225;
        if (!normalizedTarget.equals(spacedPath)) { /* goto L468; */ }
        return this.manual ? 200 : 220;
        return -1;
        L470: ;
        return this.hasSlot() ? 100 : -1;
    }

    public boolean matches(class_1799 stack, int visibleSlot) {
        return this.score(stack, visibleSlot) >= 0;
    }

    public static String normalize(String text) {
        if (text == null || text.isBlank()) {
            return "";
        }
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder(normalized.length());
        for (int i = 0; i < normalized.length(); i++) {
            char ch = normalized.charAt(i);
            if (Character.isLetterOrDigit(ch)) {
                out.append(ch);
            } else {
                if (!Character.isWhitespace(ch)) {
                    if (ch != 95) {
                        if (ch != 45) {
                            if (ch != 58) {
                                if (ch == 47) { /* goto @118; */ }
                            }
                        }
                    }
                }
                out.append(32);
                /* goto @167; */
                L128: ;
                if (ch == 39) { /* goto @167; */ }
                if (ch == 34) { /* goto @167; */ }
                if (ch == 96) { /* goto @167; */ }
                if (ch == 8217) {
                } else {
                    out.append(32);
                }
            }
        }
        return out.toString().trim().replaceAll("\\s+", " ");
    }

    private static ItemTarget classifyFreeform(String raw) {
        String trimmed = raw == null ? "" : raw.trim();
        if (trimmed.isEmpty()) {
            return new ItemTarget();
        }
        ItemTarget target = new ItemTarget();
        if (ItemTarget.looksLikeRegistryId(trimmed)) {
            target.registryId = trimmed;
            target.display = trimmed;
            target.manual = false;
            return target;
        }
        target.display = trimmed;
        target.manual = true;
        return target;
    }

    private static boolean looksLikeRegistryId(String text) {
        if (text == null || text.isBlank()) {
            return false;
        }
        if (text.contains(" ")) {
            return false;
        }
        return text.matches("[a-z0-9_.-]+(:[a-z0-9_./-]+)?");
    }

    private static int wholeWordScore(String normalizedTarget, String normalizedCandidate, int baseScore) {
        if (normalizedTarget.isBlank() || normalizedCandidate.isBlank()) {
            return -1;
        }
        String[] queryWords = normalizedTarget.split(" ");
        String[] candidateWords = normalizedCandidate.split(" ");
        int matches = 0;
        var var6 = queryWords;
        var var7 = var6.length;
        for (int var8 = 0; var8 < var7; var8++) {
            String queryWord = var6[var8];
            boolean found = false;
            var var11 = candidateWords;
            var var12 = var11.length;
            int var13 = 0;
            while (var13 < var12) {
                String candidateWord = var11[var13];
                if (queryWord.equals(candidateWord)) {
                    found = true;
                    matches++;
                } else {
                    var13++;
                }
            }
            if (found) continue;
            return -1;
        }
        return baseScore + matches;
    }

    private static boolean shouldCaptureRichText(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        class_2561 stackName = stack.method_7964();
        class_2561 defaultName = stack.method_7909().method_63680();
        if (stackName != null && defaultName != null && !stackName.getString().equals(defaultName.getString())) {
            return true;
        }
        String json = MacroExecutor.serializeTextComponent(stackName);
        return json.contains("\"color\"") || json.contains("\"bold\"") || json.contains("\"italic\"") || json.contains("\"underlined\"") || json.contains("\"strikethrough\"") || json.contains("\"obfuscated\"");
    }
}
