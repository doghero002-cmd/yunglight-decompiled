/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2596;
import net.minecraft.class_310;

public class DelayPacketsAction
implements MacroAction {
    public DelayPacketsAction.DelayMode mode = DelayPacketsAction.DelayMode.ENABLE;
    public boolean flushOnDisable = true;
    public List<String> c2sPacketNames = new ArrayList();
    public List<String> s2cPacketNames = new ArrayList();
    private boolean enabled = true;

    public void cycleMode() {
        this.mode = DelayPacketsAction.DelayMode.values()[(this.mode.ordinal() + 1) % DelayPacketsAction.DelayMode.values().length];
    }

    public void cycleModeBackwards() {
        this.mode = DelayPacketsAction.DelayMode.values()[(this.mode.ordinal() - 1 + DelayPacketsAction.DelayMode.values().length) % DelayPacketsAction.DelayMode.values().length];
    }

    public void applyDefaultPreset() {
        this.c2sPacketNames.clear();
        this.s2cPacketNames.clear();
        String[] tmp0 = new String[5];
        tmp0[0] = "ClickSlotC2SPacket";
        tmp0[1] = "ButtonClickC2SPacket";
        tmp0[2] = "CreativeInventoryActionC2SPacket";
        tmp0[3] = "PlayerActionC2SPacket";
        tmp0[4] = "PlayerInteractItemC2SPacket";
        String[] defaultNames = tmp0;
        var var2 = defaultNames;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            String target = var2[var4];
            String targetNoSuffix = target.endsWith("Packet") ? target.substring(0, target.length() - 6) : target;
            var var7 = PackUtilPacketRegistry.getC2SPackets().iterator();
            while (var7.hasNext()) {
                Class<?> clz = (Class)var7.next();
                String registryName = PackUtilPacketRegistry.getName(clz);
                if (registryName == null) { /* goto @181; */ }
                if (registryName.equals(target)) { /* goto L163; */ }
                if (!registryName.equals(targetNoSuffix)) { /* goto @181; */ }
                L163: ;
                this.c2sPacketNames.add(PackUtilPacketNamer.getFriendlyName(clz));
                break;
            }
        }
    }

    public void applyModulePreset() {
        this.c2sPacketNames.clear();
        this.s2cPacketNames.clear();
        PackUtilSharedState shared = PackUtilSharedState.get();
        var var2 = shared.getC2SPackets().iterator();
        while (var2.hasNext()) {
            Class<?> clz = (Class)var2.next();
            this.c2sPacketNames.add(PackUtilPacketNamer.getFriendlyName(clz));
        }
        var2 = shared.getS2CPackets().iterator();
        while (var2.hasNext()) {
            clz = (Class)var2.next();
            this.s2cPacketNames.add(PackUtilPacketNamer.getFriendlyName(clz));
        }
    }

    public void execute(class_310 mc) {
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean shouldEnable = this.mode == DelayPacketsAction.DelayMode.ENABLE;
        if (!shouldEnable) {
            if (this.flushOnDisable) {
                if (mc.method_1562() != null) {
                    shared.flushDelayedPackets(mc.method_1562());
                }
            }
        }
        shared.setC2SPackets(Set.of());
        if (this.c2sPacketNames.isEmpty() && this.s2cPacketNames.isEmpty()) {
            shared.setS2CPackets(Set.of());
            shared.setUseCustomPackets(false);
            shared.setDelayGuiPackets(false);
            return;
        }
        Set<Class<? extends class_2596<?>>> resolvedC2S = this.resolvePackets(this.c2sPacketNames, true);
        Set<Class<? extends class_2596<?>>> resolvedS2C = this.resolvePackets(this.s2cPacketNames, false);
        shared.setC2SPackets(resolvedC2S);
        shared.setS2CPackets(resolvedS2C);
        shared.setUseCustomPackets(true);
        shared.setDelayGuiPackets(shouldEnable);
    }

    private Set<Class<? extends class_2596<?>>> resolvePackets(List<String> names, boolean isC2S) {
        Set<Class<? extends class_2596<?>>> result = new HashSet();
        Set<Class<? extends class_2596<?>>> pool = isC2S ? PackUtilPacketRegistry.getC2SPackets() : PackUtilPacketRegistry.getS2CPackets();
        var var5 = names.iterator();
        while (var5.hasNext()) {
            String name = (String)var5.next();
            String trimmed = name.trim();
            while (trimmed.isEmpty()) {
            }
            String withSuffix = trimmed.endsWith("Packet") ? trimmed : trimmed + "Packet";
            var var9 = pool.iterator();
            while (var9.hasNext()) {
                Class<? extends class_2596<?>> clazz = (Class)var9.next();
                String friendlyName = PackUtilPacketNamer.getFriendlyName(clazz);
                if (!friendlyName.equalsIgnoreCase(trimmed)) {
                    if (!friendlyName.equalsIgnoreCase(withSuffix)) {
                        if (clazz.getSimpleName().equalsIgnoreCase(trimmed)) { /* goto @179; */ }
                    }
                }
                result.add(clazz);
                break;
            }
        }
        return result;
    }

    public MacroActionType getType() {
        return MacroActionType.DELAY_PACKETS;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "DELAY_PACKETS");
        tag.method_10582("mode", this.mode.name());
        tag.method_10556("flushOnDisable", this.flushOnDisable);
        class_2499 c2sList = new class_2499();
        class_2499 s2cList = this.c2sPacketNames.iterator();
        while (s2cList.hasNext()) {
            String n = (String)s2cList.next();
            c2sList.add(class_2519.method_23256(n));
        }
        tag.method_10566("c2sPackets", c2sList);
        s2cList = new class_2499();
        n = this.s2cPacketNames.iterator();
        while (n.hasNext()) {
            String n = (String)n.next();
            s2cList.add(class_2519.method_23256(n));
        }
        tag.method_10566("s2cPackets", s2cList);
        tag.method_10556("enabled", this.enabled);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        try {
            this.mode = DelayPacketsAction.DelayMode.valueOf(tag.method_68564("mode", "ENABLE"));
        }
        catch (IllegalArgumentException ignored) {
            this.mode = DelayPacketsAction.DelayMode.ENABLE;
            L36: ;
            this.flushOnDisable = tag.method_68566("flushOnDisable", true);
            this.c2sPacketNames.clear();
            if (!tag.method_10545("c2sPackets")) { /* goto @122; */ }
            c2sList = (class_2499)tag.method_10580("c2sPackets");
            if (c2sList == null) { /* goto @122; */ }
            for (int i = 0; i < c2sList.size(); i++) {
                this.c2sPacketNames.add((String)c2sList.method_10608(i).orElse(""));
            }
        }
        this.flushOnDisable = tag.method_68566("flushOnDisable", true);
        this.c2sPacketNames.clear();
        if (!tag.method_10545("c2sPackets")) { /* goto L122; */ }
        c2sList = (class_2499)tag.method_10580("c2sPackets");
        if (c2sList == null) { /* goto L122; */ }
        for (i = 0; i < c2sList.size(); i++) {
            this.c2sPacketNames.add((String)c2sList.method_10608(i).orElse(""));
        }
        this.s2cPacketNames.clear();
        if (!tag.method_10545("s2cPackets")) { /* goto L196; */ }
        s2cList = (class_2499)tag.method_10580("s2cPackets");
        if (s2cList == null) { /* goto L196; */ }
        for (i = 0; i < s2cList.size(); i++) {
            this.s2cPacketNames.add((String)s2cList.method_10608(i).orElse(""));
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
    }

    public String getDisplayName() {
        String base = this.mode == DelayPacketsAction.DelayMode.ENABLE ? "Delay Pkts: ON" : "Delay Pkts: OFF";
        int total = this.c2sPacketNames.size() + this.s2cPacketNames.size();
        if (this.mode == DelayPacketsAction.DelayMode.ENABLE) {
            if (total > 0) {
                base = base + " (" + total + " pkts)";
            }
        }
        return base;
    }

    public String getIcon() {
        return "D";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
