/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum ClickAction.ClickType {
    public static final ClickAction.ClickType LEFT = new ClickAction.ClickType("LEFT", 0);
    public static final ClickAction.ClickType RIGHT = new ClickAction.ClickType("RIGHT", 1);
    private static final /* synthetic */ ClickAction.ClickType[] $VALUES;

    public static ClickAction.ClickType[] values() {
        return (ClickAction.ClickType[])$VALUES.clone();
    }

    public static ClickAction.ClickType valueOf(String name) {
        return (ClickAction.ClickType)Enum.valueOf(ClickAction.ClickType.class, name);
    }

    private ClickAction.ClickType() {
        super(var1, var2);
    }

    static {
        $VALUES = ClickAction.ClickType.$values();
    }
}
