/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum ToggleModuleAction.ToggleMode {
    public static final ToggleModuleAction.ToggleMode TOGGLE = new ToggleModuleAction.ToggleMode("TOGGLE", 0);
    public static final ToggleModuleAction.ToggleMode ENABLE = new ToggleModuleAction.ToggleMode("ENABLE", 1);
    public static final ToggleModuleAction.ToggleMode DISABLE = new ToggleModuleAction.ToggleMode("DISABLE", 2);
    private static final /* synthetic */ ToggleModuleAction.ToggleMode[] $VALUES;

    public static ToggleModuleAction.ToggleMode[] values() {
        return (ToggleModuleAction.ToggleMode[])$VALUES.clone();
    }

    public static ToggleModuleAction.ToggleMode valueOf(String name) {
        return (ToggleModuleAction.ToggleMode)Enum.valueOf(ToggleModuleAction.ToggleMode.class, name);
    }

    private ToggleModuleAction.ToggleMode() {
        super(var1, var2);
    }

    static {
        $VALUES = ToggleModuleAction.ToggleMode.$values();
    }
}
