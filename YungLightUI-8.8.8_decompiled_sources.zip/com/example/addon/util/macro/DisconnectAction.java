/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.MacroExecutor;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import java.util.List;
import net.minecraft.class_10938;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1306;
import net.minecraft.class_1659;
import net.minecraft.class_1693;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2803;
import net.minecraft.class_2813;
import net.minecraft.class_2824;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_4066;
import net.minecraft.class_437;
import net.minecraft.class_7264;
import net.minecraft.class_7923;
import net.minecraft.class_8791;

public class DisconnectAction
implements MacroAction {
    private boolean enabled = true;
    public int delayMs = 0;
    public DisconnectAction.DisconnectMode mode = DisconnectAction.DisconnectMode.DISCONNECT;
    public DisconnectAction.LagMethod lagMethod = DisconnectAction.LagMethod.CLICK_SLOT;
    public DisconnectAction.KickMethod kickMethod = DisconnectAction.KickMethod.HURT;
    public int packetCount = 200;
    public boolean useNextAction = false;
    private transient List<MacroAction> nextActions = null;
    public DisconnectAction.AutoTrigger trigger = DisconnectAction.AutoTrigger.TELEPORT;
    public double targetX = 0;
    public double targetY = 0;
    public double targetZ = 0;
    public double tolerance = 10;
    public int bufferMs = 50;
    public int timeoutSec = 60;
    public boolean useExactPosition = false;

    public void execute(class_310 mc) {
        switch (this.mode.ordinal()) {
            case 0::
                this.executeDisconnect(mc);
                /* goto @65; */
            case 1::
                this.executeKick(mc);
                /* goto @65; */
            case 2::
                this.executeKickDupe(mc);
                /* goto @65; */
            case 3::
                this.executeAutoDisconnect(mc);
            default:
                return;
        }
    }

    private void executeDisconnect(class_310 mc) {
        if (mc.field_1687 != null) {
            if (mc.method_1562() != null) {
                mc.method_1562().method_48296().method_10747(class_2561.method_43470("Disconnected by Macro"));
            }
        }
    }

    private void executeAutoDisconnect(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo player or network connection!");
            return;
        }
        PackUtilClientMessaging.sendPrefixed("§eAuto Disconnect: Monitoring for " + this.trigger.name() + "...");
        String initialWorld = mc.field_1687 != null ? mc.field_1687.method_27983().method_29177().toString() : "";
        double initialX = mc.field_1724.method_23317();
        double initialY = mc.field_1724.method_23318();
        double initialZ = mc.field_1724.method_23321();
        class_437 initialScreen = mc.field_1755;
        boolean initialScreenOpen = mc.field_1755 != null;
        boolean initialInventoryEmpty = this.isMainInventoryEmpty(mc);
        long startTime = System.currentTimeMillis();
        boolean triggered = false;
        long lastPositionCheck = startTime;
        class_437 prevScreen = initialScreen;
        L130: ;
        if (triggered) { /* goto @694; */ }
        if (!MacroExecutor.isRunning()) { /* goto @694; */ }
        if (System.currentTimeMillis() - startTime >= (long)this.timeoutSec * 1000L) { /* goto @694; */ }
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cConnection lost during wait!");
            return;
        }
        switch (this.trigger.ordinal()) {
            case 0::
                long now = System.currentTimeMillis();
                if (now - lastPositionCheck >= 50L) {
                    double dist = Math.sqrt(Math.pow(mc.field_1724.method_23317() - initialX, 2) + Math.pow(mc.field_1724.method_23318() - initialY, 2) + Math.pow(mc.field_1724.method_23321() - initialZ, 2));
                    if (dist > 5) {
                        PackUtilClientMessaging.sendPrefixed(String.format("§aTeleport detected! Jumped %.1f blocks.", dist));
                        triggered = true;
                    }
                    if (!triggered) {
                        if (mc.field_1687 != null) {
                            String cw = mc.field_1687.method_27983().method_29177().toString();
                            if (!cw.isEmpty()) {
                                if (!cw.equals(initialWorld)) {
                                    PackUtilClientMessaging.sendPrefixed("§aWorld change detected during teleport!");
                                    triggered = true;
                                }
                            }
                        }
                    }
                    initialX = mc.field_1724.method_23317();
                    initialY = mc.field_1724.method_23318();
                    initialZ = mc.field_1724.method_23321();
                    lastPositionCheck = now;
                }
                /* goto @671; */
            case 1::
                dx = mc.field_1724.method_23317() - initialX;
                dy = mc.field_1724.method_23318() - initialY;
                dz = mc.field_1724.method_23321() - initialZ;
                double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (dist > this.tolerance) {
                    PackUtilClientMessaging.sendPrefixed(String.format("§aPosition jump detected! Moved %.1f blocks (tolerance: %.0f)", dist, this.tolerance));
                    triggered = true;
                }
                long now = System.currentTimeMillis();
                if (now - lastPositionCheck >= 500L) {
                    initialX = mc.field_1724.method_23317();
                    initialY = mc.field_1724.method_23318();
                    initialZ = mc.field_1724.method_23321();
                    lastPositionCheck = now;
                }
                /* goto @671; */
            case 2::
                currentWorld = mc.field_1687 != null ? mc.field_1687.method_27983().method_29177().toString() : "";
                PackUtilClientMessaging.sendPrefixed("§aWorld change detected!");
                if (!currentWorld.equals(initialWorld) && !currentWorld.isEmpty()) {
                    triggered = true;
                }
                /* goto @671; */
            case 3::
                curScreen = mc.field_1755;
                PackUtilClientMessaging.sendPrefixed("§aGUI close detected!");
                if (prevScreen != null && curScreen == null) {
                    triggered = true;
                }
                prevScreen = curScreen;
                /* goto @671; */
            case 4::
                if (!initialInventoryEmpty) {
                    if (this.isMainInventoryEmpty(mc)) {
                        PackUtilClientMessaging.sendPrefixed("§aInventory clear detected!");
                        triggered = true;
                    }
                }
            default:
                if (triggered) { /* goto @130; */ }
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        if (!triggered) {
            PackUtilClientMessaging.sendPrefixed("§cAuto Disconnect: Timeout after " + this.timeoutSec + "s");
            return;
        }
        if (this.bufferMs > 0) {
            PackUtilClientMessaging.sendPrefixed("§eBuffer delay: " + this.bufferMs + "ms");
        }
        try {
            Thread.sleep((long)this.bufferMs);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        PackUtilClientMessaging.sendPrefixed("§cExecuting disconnect!");
        this.executeDisconnect(mc);
    }

    private boolean isMainInventoryEmpty(class_310 mc) {
        if (mc.field_1724 == null) {
            return true;
        }
        for (int i = 0; i < 36; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960()) continue;
            return false;
        }
        return true;
    }

    private void executeKick(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo player or network connection!");
            return;
        }
        if (!this.validateLagMethod(mc)) {
            return;
        }
        this.sendLagPackets(mc);
        this.sendKickPacket(mc);
        this.sendLagPackets(mc);
        PackUtilClientMessaging.sendPrefixed("§aKick executed!");
    }

    public void setNextActions(List<MacroAction> actions) {
        this.nextActions = actions;
    }

    private void executeKickDupe(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo player or network connection!");
            return;
        }
        if (!this.validateLagMethod(mc)) {
            return;
        }
        if (this.useNextAction) {
            List<MacroAction> actions = this.nextActions;
            this.nextActions = null;
            if (actions == null || actions.isEmpty()) {
                PackUtilClientMessaging.sendPrefixed("§cKick Dupe: no next action in macro! Add action(s) after this one.");
                return;
            }
            this.sendLagPackets(mc);
            String actNames = actions.iterator();
        }
        while (actNames.hasNext()) {
            MacroAction act = (MacroAction)actNames.next();
            try {
                act.execute(mc);
            }
            catch (Exception e) {
                PackUtilClientMessaging.sendPrefixed("§cError in dupe action '" + act.getDisplayName() + "': " + e.getMessage());
            }
        }
        this.sendKickPacket(mc);
        this.sendLagPackets(mc);
        actNames = actions.size() == 1 ? ((MacroAction)actions.get(0)).getDisplayName() : actions.size() + " actions";
        PackUtilClientMessaging.sendPrefixed("§aKick Dupe executed! (" + actNames + ")");
        /* goto L226; */
        L196: ;
        this.sendLagPackets(mc);
        if (!this.findAndUseBundle(mc)) {
            return;
        }
        this.sendKickPacket(mc);
        this.sendLagPackets(mc);
        PackUtilClientMessaging.sendPrefixed("§aKick Dupe executed! (bundle)");
        L226: ;
    }

    private boolean findAndUseBundle(class_310 mc) {
        class_1268 activeHand = null;
        if (!mc.field_1724.method_6047().method_7960()) {
            if (class_7923.field_41178.method_10221(mc.field_1724.method_6047().method_7909()).method_12832().endsWith("bundle")) {
                activeHand = class_1268.field_5808;
            }
        } else {
            if (!mc.field_1724.method_6079().method_7960()) {
                if (class_7923.field_41178.method_10221(mc.field_1724.method_6079().method_7909()).method_12832().endsWith("bundle")) {
                    activeHand = class_1268.field_5810;
                }
            }
        }
        if (activeHand != null) {
            mc.method_1562().method_52787(new class_2886(activeHand, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
            return true;
        }
        int bundleSlot = -1;
        int i = 0;
        while (i < mc.field_1724.method_31548().method_5439()) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                if (!class_7923.field_41178.method_10221(stack.method_7909()).method_12832().endsWith("bundle")) continue;
                bundleSlot = i;
            } else {
                i++;
            }
        }
        if (bundleSlot < 0) {
            PackUtilClientMessaging.sendPrefixed("§cNo bundle found in inventory or hands!");
            return false;
        }
        hotbarSlot = bundleSlot;
        if (bundleSlot <= 8) { /* goto L291; */ }
        target = 0;
        int i = 0;
        while (i <= 8) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960()) {
                target = i;
            } else {
                i++;
            }
        }
        PackUtilInventoryHelper.swapInventorySlots(mc, bundleSlot, target);
        hotbarSlot = target;
        L291: ;
        PackUtilInventoryHelper.selectHotbarSlot(mc, hotbarSlot);
        mc.method_1562().method_52787(new class_2886(class_1268.field_5808, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
        return true;
    }

    private boolean validateLagMethod(class_310 mc) {
        switch (this.lagMethod.ordinal()) {
            case 1::
                class_1297 vehicle = mc.field_1724.method_5854();
                PackUtilClientMessaging.sendPrefixed("§cYou must be in a Chest Boat or Minecart with Chest for BoatNBT!");
                if (!(vehicle instanceof class_7264) && !(vehicle instanceof class_1693)) {
                    return false;
                }
                /* goto @129; */
            case 2::
                if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1331) {
                    PackUtilClientMessaging.sendPrefixed("§cYou must be looking at an entity for EntityNBT!");
                    return false;
                }
                target = ((class_3966)mc.field_1765).method_17782();
                PackUtilClientMessaging.sendPrefixed("§cTarget must be a Chest Boat or Minecart with Chest!");
                if (!(target instanceof class_7264) && !(target instanceof class_1693)) {
                    return false;
                }
                /* goto @129; */
            default:
                return true;
        }
    }

    private void sendLagPackets(class_310 mc) {
        switch (this.lagMethod.ordinal()) {
            case 0::
                for (int i = 0; i < this.packetCount; i++) {
                    mc.method_1562().method_52787(new class_2813(0, 0, 0, 0, class_1713.field_7790, new Int2ObjectArrayMap(), class_10938.field_58176));
                }
                /* goto @196; */
            case 1::
                for (i = 0; i < this.packetCount; i++) {
                    mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12988));
                }
                /* goto @196; */
            case 2::
                class_1297 target = mc.field_1765;
                if (!target instanceof class_3966) { /* goto @196; */ }
                ehr = (class_3966)target;
                target = ehr.method_17782();
                for (int i = 0; i < this.packetCount; i++) {
                    mc.method_1562().method_52787(class_2824.method_34208(target, true, class_1268.field_5808, new class_243(target.method_23317(), target.method_23318(), target.method_23321())));
                }
            default:
                return;
        }
    }

    private void sendKickPacket(class_310 mc) {
        switch (this.kickMethod.ordinal()) {
            case 0::
                mc.method_1562().method_52787(class_2824.method_34206(mc.field_1724, false));
                /* goto @149; */
            case 1::
                class_8791 opts = new class_8791(mc.field_1690.field_1883, -2, class_1659.field_7538, ((Boolean)mc.field_1690.method_42427().method_41753()).booleanValue(), 127, (class_1306)mc.field_1690.method_42552().method_41753(), false, false, (class_4066)mc.field_1690.method_42475().method_41753());
                mc.method_1562().method_52787(new class_2803(opts));
                /* goto @149; */
            case 2::
                mc.method_1562().method_52787(new class_2868(-1));
            default:
                return;
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10569("delayMs", this.delayMs);
        tag.method_10582("mode", this.mode.name());
        tag.method_10582("lagMethod", this.lagMethod.name());
        tag.method_10582("kickMethod", this.kickMethod.name());
        tag.method_10569("packetCount", this.packetCount);
        tag.method_10556("useNextAction", this.useNextAction);
        tag.method_10556("enabled", this.enabled);
        tag.method_10582("trigger", this.trigger.name());
        tag.method_10549("targetX", this.targetX);
        tag.method_10549("targetY", this.targetY);
        tag.method_10549("targetZ", this.targetZ);
        tag.method_10549("tolerance", this.tolerance);
        tag.method_10569("bufferMs", this.bufferMs);
        tag.method_10569("timeoutSec", this.timeoutSec);
        tag.method_10556("useExactPosition", this.useExactPosition);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("delayMs")) {
            this.delayMs = tag.method_68083("delayMs", 0);
        }
        if (tag.method_10545("enabled")) {
            this.enabled = tag.method_68566("enabled", true);
        }
        try {
            this.mode = DisconnectAction.DisconnectMode.valueOf(tag.method_68564("mode", "DISCONNECT"));
        }
        catch (IllegalArgumentException ignored) {
            this.mode = DisconnectAction.DisconnectMode.DISCONNECT;
            L82: ;
            if (!tag.method_10545("lagMethod")) { /* goto @120; */ }
            this.lagMethod = DisconnectAction.LagMethod.valueOf(tag.method_68564("lagMethod", "CLICK_SLOT"));
            /* goto @120; */
        }
        try {
            this.lagMethod = DisconnectAction.LagMethod.valueOf(tag.method_68564("lagMethod", "CLICK_SLOT"));
        }
        catch (IllegalArgumentException ignored) {
            this.lagMethod = DisconnectAction.LagMethod.CLICK_SLOT;
            L120: ;
            if (!tag.method_10545("kickMethod")) { /* goto @158; */ }
            this.kickMethod = DisconnectAction.KickMethod.valueOf(tag.method_68564("kickMethod", "HURT"));
            /* goto @158; */
        }
        try {
            this.kickMethod = DisconnectAction.KickMethod.valueOf(tag.method_68564("kickMethod", "HURT"));
        }
        catch (IllegalArgumentException ignored) {
            this.kickMethod = DisconnectAction.KickMethod.HURT;
            L158: ;
            if (tag.method_10545("packetCount")) {
                this.packetCount = tag.method_68083("packetCount", 200);
            }
            if (tag.method_10545("useNextAction")) {
                this.useNextAction = tag.method_68566("useNextAction", false);
            }
            if (!tag.method_10545("trigger")) { /* goto @242; */ }
            this.trigger = DisconnectAction.AutoTrigger.valueOf(tag.method_68564("trigger", "TELEPORT"));
            /* goto @242; */
        }
        if (tag.method_10545("packetCount")) {
            this.packetCount = tag.method_68083("packetCount", 200);
        }
        if (tag.method_10545("useNextAction")) {
            this.useNextAction = tag.method_68566("useNextAction", false);
        }
        try {
            this.trigger = DisconnectAction.AutoTrigger.valueOf(tag.method_68564("trigger", "TELEPORT"));
        }
        catch (IllegalArgumentException ignored) {
            this.trigger = DisconnectAction.AutoTrigger.TELEPORT;
            L242: ;
            if (tag.method_10545("targetX")) {
                this.targetX = tag.method_68563("targetX", 0);
            }
            if (tag.method_10545("targetY")) {
                this.targetY = tag.method_68563("targetY", 0);
            }
            if (tag.method_10545("targetZ")) {
                this.targetZ = tag.method_68563("targetZ", 0);
            }
            if (tag.method_10545("tolerance")) {
                this.tolerance = tag.method_68563("tolerance", 2);
            }
            if (tag.method_10545("bufferMs")) {
                this.bufferMs = tag.method_68083("bufferMs", 50);
            }
            if (tag.method_10545("timeoutSec")) {
                this.timeoutSec = tag.method_68083("timeoutSec", 60);
            }
            if (tag.method_10545("useExactPosition")) {
                this.useExactPosition = tag.method_68566("useExactPosition", false);
            }
            return;
        }
        if (tag.method_10545("targetX")) {
            this.targetX = tag.method_68563("targetX", 0);
        }
        if (tag.method_10545("targetY")) {
            this.targetY = tag.method_68563("targetY", 0);
        }
        if (tag.method_10545("targetZ")) {
            this.targetZ = tag.method_68563("targetZ", 0);
        }
        if (tag.method_10545("tolerance")) {
            this.tolerance = tag.method_68563("tolerance", 2);
        }
        if (tag.method_10545("bufferMs")) {
            this.bufferMs = tag.method_68083("bufferMs", 50);
        }
        if (tag.method_10545("timeoutSec")) {
            this.timeoutSec = tag.method_68083("timeoutSec", 60);
        }
        if (tag.method_10545("useExactPosition")) {
            this.useExactPosition = tag.method_68566("useExactPosition", false);
        }
    }

    public MacroActionType getType() {
        return MacroActionType.DISCONNECT;
    }

    public String getDisplayName() {
        switch (this.mode.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return this.delayMs > 0 ? "Disconnect (" + this.delayMs + "ms)" : "Disconnect";
            case 1::
                return "Kick (" + this.lagMethod.name() + ", " + this.kickMethod.name() + ", " + this.packetCount + ")";
            case 2::
                String action = this.useNextAction ? "Next Actions" : "Bundle";
                return "Kick Dupe (" + this.lagMethod.name() + ", " + this.kickMethod.name() + ", " + this.packetCount + ", " + action + ")";
            case 3::
                switch (this.trigger.ordinal()) {
                    default:
                        throw new MatchException(null, null);
                    case 0::
                        triggerInfo = "Loading Screen";
                        break;
                    case 1::
                        triggerInfo = String.format("Pos Jump > %.0f blocks", this.tolerance);
                        break;
                    case 2::
                        triggerInfo = "World Change";
                        break;
                    case 3::
                        triggerInfo = "GUI Close";
                        break;
                    case 4::
                        triggerInfo = "Inv Clear";
                        break;
                }
                return "Auto DC (" + triggerInfo + ", +" + this.bufferMs + "ms)";
        }
    }

    public String getIcon() {
        return this.mode == DisconnectAction.DisconnectMode.AUTO_DISCONNECT ? "ADC" : "DC";
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean e) {
        this.enabled = e;
    }
}
