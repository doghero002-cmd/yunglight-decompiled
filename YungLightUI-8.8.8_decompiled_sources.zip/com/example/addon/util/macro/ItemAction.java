/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilPacketSender;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.WaitsForGui;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10938;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2813;
import net.minecraft.class_310;

public class ItemAction
implements MacroAction,
WaitsForGui {
    public List<String> itemNames = new ArrayList();
    public List<ItemTarget> itemTargets = new ArrayList();
    public List<Integer> itemTimes = new ArrayList();
    public List<Integer> itemActionIdx = new ArrayList();
    public List<Integer> itemButtons = new ArrayList();
    public int targetSlot = -1;
    public boolean useSlot = false;
    public int actionIndex = 0;
    public int button = 0;
    public int times = 1;
    public boolean waitForGui = false;
    public String guiName = "";
    public boolean waitForItem = false;
    private static final class_310 MC = class_310.method_1551();
    private static final PackUtilDropAction[] ACTIONS = PackUtilDropAction.values();
    private static final int[] ITEM_CLICK_ACTIONS;

    public int getItemTime(int index) {
        return index < this.itemTimes.size() && ((Integer)this.itemTimes.get(index)).intValue() > 0 ? (Integer)this.itemTimes.get(index) : 1;
    }

    public int getItemActionIdx(int index) {
        int stored = index < this.itemActionIdx.size() ? ((Integer)this.itemActionIdx.get(index)).intValue() : this.actionIndex;
        return ItemAction.normalizeItemClickActionIndex(stored);
    }

    public int getItemButton(int index) {
        return index < this.itemButtons.size() ? ((Integer)this.itemButtons.get(index)).intValue() : this.button;
    }

    public PackUtilDropAction getItemAction(int index) {
        return ACTIONS[this.getItemActionIdx(index)];
    }

    public String getItemButtonName(int index) {
        if (this.getItemAction(index) == PackUtilDropAction.SWAP) {
            int hotbarSlot = Math.max(0, Math.min(8, this.getItemButton(index))) + 1;
            return "Hotbar " + hotbarSlot;
        }
        switch (this.getItemButton(index)) {
            case 0::
                return "Left";
            case 1::
                return "Right";
            case 2::
                return "Middle";
            default:
                return "?";
        }
    }

    public void cycleItemAction(int index) {
        while (this.itemActionIdx.size() <= index) {
            this.itemActionIdx.add(this.actionIndex);
        }
        this.itemActionIdx.set(index, ItemAction.cycleItemClickActionIndex(((Integer)this.itemActionIdx.get(index)).intValue(), 1));
    }

    public void cycleItemActionBackwards(int index) {
        while (this.itemActionIdx.size() <= index) {
            this.itemActionIdx.add(this.actionIndex);
        }
        this.itemActionIdx.set(index, ItemAction.cycleItemClickActionIndex(((Integer)this.itemActionIdx.get(index)).intValue(), -1));
    }

    public void cycleItemButton(int index) {
        while (this.itemButtons.size() <= index) {
            this.itemButtons.add(this.button);
        }
        int limit = this.getItemAction(index) == PackUtilDropAction.SWAP ? 9 : 3;
        int current = Math.max(0, ((Integer)this.itemButtons.get(index)).intValue());
        this.itemButtons.set(index, (current + 1) % limit);
    }

    public void cycleItemButtonBackwards(int index) {
        while (this.itemButtons.size() <= index) {
            this.itemButtons.add(this.button);
        }
        int limit = this.getItemAction(index) == PackUtilDropAction.SWAP ? 9 : 3;
        int current = Math.max(0, ((Integer)this.itemButtons.get(index)).intValue());
        this.itemButtons.set(index, (current - 1 + limit) % limit);
    }

    public void execute(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo network connection!");
            return;
        }
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo screen handler available!");
            return;
        }
        if (!this.itemNames.isEmpty()) {
            for (int ei = 0; ei < this.itemNames.size(); ei++) {
                String entry = (String)this.itemNames.get(ei);
                int clickCount = this.getItemTime(ei);
                PackUtilDropAction eiAction = this.getItemAction(ei);
                int eiButton = this.getItemButton(ei);
                if (!eiAction.usesFixedButton()) continue;
                eiButton = eiAction.getButton();
                ItemTarget entryTarget = this.getItemTarget(ei);
                String entryName = ItemAction.parseEntryName(entryTarget.toLegacyEntry());
                int configuredEntrySlot = entryTarget.hasSlot() ? entryTarget.slot : -1;
                if (configuredEntrySlot >= 0) {
                    if (entryName.isEmpty()) { /* goto @195; */ }
                    int resolvedSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, configuredEntrySlot);
                    if (resolvedSlot < 0) {
                    } else {
                        int slotToUse = this.findExactMatchingSlot(handler, entryName, resolvedSlot);
                    }
                } else {
                    if (configuredEntrySlot >= 0) {
                        int slotToUse = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, configuredEntrySlot);
                    } else {
                        if (this.useSlot) {
                            if (this.targetSlot < 0) { /* goto @257; */ }
                            int configuredSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, this.targetSlot);
                            if (configuredSlot < 0) {
                            } else {
                                int slotToUse = this.findExactMatchingSlot(handler, entryName, configuredSlot);
                            }
                        } else {
                            int slotToUse = this.findSlotByItemName(handler, entryName);
                        }
                    }
                }
                if (slotToUse < 0) {
                } else {
                    int fs = slotToUse;
                    int fb = eiButton;
                    PackUtilDropAction fa = eiAction;
                    for (int j = 0; j < clickCount; j++) {
                        class_2813 packet = new class_2813(handler.field_7763, handler.method_37421(), (short)fs, (byte)fb, fa.toSlotActionType(), new Int2ObjectArrayMap(), class_10938.field_58176);
                        PackUtilPacketSender.sendPacket(packet);
                    }
                }
            }
        } else {
            if (this.useSlot) {
                if (this.targetSlot < 0) { /* goto @483; */ }
                PackUtilDropAction action = this.getAction();
                int effectiveButton = this.button;
                if (action.usesFixedButton()) {
                    effectiveButton = action.getButton();
                }
                int resolvedTargetSlot = PackUtilInventoryHelper.resolveConfiguredHandlerSlot(mc, this.targetSlot);
                if (resolvedTargetSlot < 0) {
                    PackUtilClientMessaging.sendPrefixed("Â§cConfigured slot " + this.targetSlot + " is not available in this screen!");
                    return;
                }
                for (int i = 0; i < this.times; i++) {
                    class_2813 packet = new class_2813(handler.field_7763, handler.method_37421(), (short)resolvedTargetSlot, (byte)effectiveButton, action.toSlotActionType(), new Int2ObjectArrayMap(), class_10938.field_58176);
                    PackUtilPacketSender.sendPacket(packet);
                }
            } else {
                PackUtilClientMessaging.sendPrefixed("§cNo item name or slot specified!");
            }
        }
    }

    private int findSlotByItemName(class_1703 handler, String name) {
        int bestSlot = -1;
        int bestScore = -1;
        ItemTarget target = ItemTarget.fromLegacyEntry(name);
        if (!target.hasIdentity()) {
            return -1;
        }
        var var6 = handler.field_7761.iterator();
        while (var6.hasNext()) {
            class_1735 slot = (class_1735)var6.next();
            if (slot == null) continue;
            while (slot.method_7677().method_7960()) {
            }
            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(MC, slot.field_7874);
            int score = target.score(slot.method_7677(), visibleSlot);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot.field_7874;
            }
        }
        return bestScore >= 0 ? bestSlot : -1;
    }

    private int findExactMatchingSlot(class_1703 handler, String name, int requiredSlot) {
        if (requiredSlot < 0 || requiredSlot >= handler.field_7761.size()) {
            return -1;
        }
        class_1735 slot = (class_1735)handler.field_7761.get(requiredSlot);
        if (slot == null || slot.method_7677().method_7960()) {
            return -1;
        }
        ItemTarget target = ItemTarget.fromLegacyEntry(name);
        if (!target.hasIdentity()) {
            return requiredSlot;
        }
        int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(MC, requiredSlot);
        return target.matches(slot.method_7677(), visibleSlot) ? requiredSlot : -1;
    }

    public boolean isWaitForGui() {
        return this.waitForGui;
    }

    public void setWaitForGui(boolean v) {
        this.waitForGui = v;
    }

    public String getWaitGuiName() {
        return this.guiName;
    }

    public void setWaitGuiName(String name) {
        this.guiName = name;
    }

    public boolean isWaitForGuiChange() {
        return true;
    }

    public MacroActionType getType() {
        return MacroActionType.ITEM;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", "ITEM");
        tag.method_10566("itemNames", ItemTarget.toTagList(this.resolvedItemTargets()));
        class_2499 times2 = new class_2499();
        class_2499 aidx = this.itemTimes.iterator();
        while (aidx.hasNext()) {
            int t = ((Integer)aidx.next()).intValue();
            times2.add(class_2519.method_23256(String.valueOf(t)));
        }
        tag.method_10566("itemTimes", times2);
        aidx = new class_2499();
        btns = this.itemActionIdx.iterator();
        while (btns.hasNext()) {
            int a = ((Integer)btns.next()).intValue();
            aidx.add(class_2519.method_23256(String.valueOf(a)));
        }
        tag.method_10566("itemActionIdx", aidx);
        btns = new class_2499();
        a = this.itemButtons.iterator();
        while (a.hasNext()) {
            int b = ((Integer)a.next()).intValue();
            btns.add(class_2519.method_23256(String.valueOf(b)));
        }
        tag.method_10566("itemButtons", btns);
        tag.method_10569("targetSlot", this.targetSlot);
        tag.method_10556("useSlot", this.useSlot);
        tag.method_10569("actionIndex", this.actionIndex);
        tag.method_10569("button", this.button);
        tag.method_10569("times", this.times);
        tag.method_10556("waitForGui", this.waitForGui);
        tag.method_10582("guiName", this.guiName);
        tag.method_10556("waitForItem", this.waitForItem);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        this.itemTargets.clear();
        this.itemNames.clear();
        if (tag.method_10545("itemNames")) {
            class_2499 nl = (class_2499)tag.method_10554("itemNames").orElse(new class_2499());
            this.itemTargets.addAll(ItemTarget.fromElementList(nl));
        } else {
            if (tag.method_10545("itemName")) {
                String old = tag.method_68564("itemName", "");
                if (!old.isEmpty()) {
                    this.itemTargets.add(ItemTarget.fromLegacyEntry(old));
                }
            }
        }
        this.syncLegacyItemNames();
        this.itemTimes.clear();
        if (tag.method_10545("itemTimes")) {
            tl = (class_2499)tag.method_10554("itemTimes").orElse(new class_2499());
            var var3 = tl.iterator();
            L156: ;
            if (var3.hasNext()) {
                class_2520 el = (class_2520)var3.next();
            }
        }
        try {
            this.itemTimes.add(Integer.parseInt((String)el.method_68658().orElse("1")));
        }
        catch (NumberFormatException e) {
            this.itemTimes.add(1);
            L227: ;
            /* goto @156; */
            while (this.itemTimes.size() < this.itemNames.size()) {
                this.itemTimes.add(1);
            }
        }
        /* goto @156; */
        while (this.itemTimes.size() < this.itemNames.size()) {
            this.itemTimes.add(1);
        }
        this.itemActionIdx.clear();
        if (tag.method_10545("itemActionIdx")) {
            al = (class_2499)tag.method_10554("itemActionIdx").orElse(new class_2499());
            var3 = al.iterator();
            L313: ;
            if (var3.hasNext()) {
                el = (class_2520)var3.next();
            }
        }
        try {
            this.itemActionIdx.add(Integer.parseInt((String)el.method_68658().orElse("0")));
        }
        catch (NumberFormatException e) {
            this.itemActionIdx.add(0);
            L384: ;
            /* goto @313; */
            while (this.itemActionIdx.size() < this.itemNames.size()) {
                this.itemActionIdx.add(0);
            }
        }
        /* goto @313; */
        while (this.itemActionIdx.size() < this.itemNames.size()) {
            this.itemActionIdx.add(0);
        }
        for (i = 0; i < this.itemActionIdx.size(); i++) {
            this.itemActionIdx.set(i, ItemAction.normalizeItemClickActionIndex(((Integer)this.itemActionIdx.get(i)).intValue()));
        }
        this.itemButtons.clear();
        if (tag.method_10545("itemButtons")) {
            bl = (class_2499)tag.method_10554("itemButtons").orElse(new class_2499());
            var3 = bl.iterator();
            L524: ;
            if (var3.hasNext()) {
                el = (class_2520)var3.next();
            }
        }
        try {
            this.itemButtons.add(Integer.parseInt((String)el.method_68658().orElse("0")));
        }
        catch (NumberFormatException e) {
            this.itemButtons.add(0);
            L595: ;
            /* goto @524; */
            while (this.itemButtons.size() < this.itemNames.size()) {
                this.itemButtons.add(0);
            }
        }
        /* goto @524; */
        while (this.itemButtons.size() < this.itemNames.size()) {
            this.itemButtons.add(0);
        }
        this.targetSlot = tag.method_68083("targetSlot", -1);
        this.useSlot = tag.method_68566("useSlot", false);
        this.actionIndex = ItemAction.normalizeItemClickActionIndex(tag.method_68083("actionIndex", 0));
        this.button = tag.method_68083("button", 0);
        this.times = tag.method_68083("times", 1);
        if (tag.method_10545("waitForGui")) {
            this.waitForGui = tag.method_68566("waitForGui", false);
        }
        if (tag.method_10545("guiName")) {
            this.guiName = tag.method_68564("guiName", "");
        }
        if (tag.method_10545("waitForItem")) {
            this.waitForItem = tag.method_68566("waitForItem", false);
        }
    }

    public String getDisplayName() {
        PackUtilDropAction action = ACTIONS[Math.min(this.actionIndex, ACTIONS.length - 1)];
        String actionName = action.displayName;
        List<ItemTarget> targets = this.resolvedItemTargets();
        if (targets.isEmpty()) { /* goto L212; */ }
        String e0 = ((ItemTarget)targets.get(0)).toLegacyEntry();
        int slotNumber = ItemAction.parseEntrySlot(e0);
        String itemName = ItemAction.parseEntryName(e0);
        if (slotNumber >= 0) {
            if (!itemName.isEmpty()) {
                String first = itemName + " @ " + slotNumber;
            }
        } else {
            if (slotNumber >= 0) {
                String first = "Slot " + slotNumber;
            } else {
                String first = itemName;
            }
        }
        String shortName = first.length() > 12 ? first.substring(0, 10) + ".." : first;
        String suffix = this.itemNames.size() > 1 ? " (+" + this.itemNames.size() - 1 + ")" : "";
        String base = "Item " + shortName + suffix + " (" + actionName + ")";
        return this.waitForItem ? base + " [wait]" : base;
        if (this.useSlot && this.targetSlot >= 0) {
            return "Item Slot " + this.targetSlot + " (" + actionName + ")";
        }
        return "Item (empty)";
    }

    public String getIcon() {
        return "I";
    }

    public PackUtilDropAction getAction() {
        return ACTIONS[ItemAction.normalizeItemClickActionIndex(this.actionIndex)];
    }

    public void cycleAction() {
        this.actionIndex = ItemAction.cycleItemClickActionIndex(this.actionIndex, 1);
    }

    public void cycleActionBackwards() {
        this.actionIndex = ItemAction.cycleItemClickActionIndex(this.actionIndex, -1);
    }

    public String getButtonName() {
        if (this.getAction() == PackUtilDropAction.SWAP) {
            int hotbarSlot = Math.max(0, Math.min(8, this.button)) + 1;
            return "Hotbar " + hotbarSlot;
        }
        switch (this.button) {
            case 0::
                return "Left";
            case 1::
                return "Right";
            case 2::
                return "Middle";
            default:
                return "?";
        }
    }

    public void cycleButton() {
        int limit = this.getAction() == PackUtilDropAction.SWAP ? 9 : 3;
        this.button = (Math.max(0, this.button) + 1) % limit;
    }

    public void cycleButtonBackwards() {
        int limit = this.getAction() == PackUtilDropAction.SWAP ? 9 : 3;
        this.button = (Math.max(0, this.button) - 1 + limit) % limit;
    }

    private static int normalizeItemClickActionIndex(int rawIndex) {
        var var1 = ITEM_CLICK_ACTIONS;
        var var2 = var1.length;
        for (int var3 = 0; var3 < var2; var3++) {
            int allowed = var1[var3];
            if (rawIndex != allowed) continue;
            return rawIndex;
        }
        return PackUtilDropAction.PICKUP.ordinal();
    }

    private static int cycleItemClickActionIndex(int current, int direction) {
        int currentOrdinal = ItemAction.normalizeItemClickActionIndex(current);
        int selected = 0;
        int i = 0;
        while (i < ITEM_CLICK_ACTIONS.length) {
            if (ITEM_CLICK_ACTIONS[i] == currentOrdinal) {
                selected = i;
            } else {
                i++;
            }
        }
        next = (selected + direction) % ITEM_CLICK_ACTIONS.length;
        if (next < 0) {
            next = next + ITEM_CLICK_ACTIONS.length;
        }
        return ITEM_CLICK_ACTIONS[next];
    }

    private static int parseEntrySlot(String entry) {
        if (entry == null || !entry.startsWith("#")) {
            return -1;
        }
        int separator = entry.indexOf(124);
        String raw = separator >= 0 ? entry.substring(1, separator) : entry.substring(1);
        try {
            return Integer.parseInt(raw);
        }
        catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private static String parseEntryName(String entry) {
        if (entry == null || entry.isBlank()) {
            return "";
        }
        if (!entry.startsWith("#")) {
            return entry;
        }
        int separator = entry.indexOf(124);
        return separator >= 0 && separator + 1 < entry.length() ? entry.substring(separator + 1).trim() : "";
    }

    private List<ItemTarget> resolvedItemTargets() {
        if (!this.itemTargets.isEmpty()) {
            return this.itemTargets;
        }
        var var1 = this.itemNames.iterator();
        while (var1.hasNext()) {
            String itemName = (String)var1.next();
            ItemTarget target = ItemTarget.fromLegacyEntry(itemName);
            if (!target.hasSlot() || target.hasIdentity()) continue;
            this.itemTargets.add(target);
        }
        return this.itemTargets;
    }

    private ItemTarget getItemTarget(int index) {
        List<ItemTarget> targets = this.resolvedItemTargets();
        if (index >= 0 && index < targets.size()) {
            return (ItemTarget)targets.get(index);
        }
        return new ItemTarget();
    }

    private void syncLegacyItemNames() {
        this.itemNames.clear();
        var var1 = this.itemTargets.iterator();
        while (var1.hasNext()) {
            ItemTarget target = (ItemTarget)var1.next();
            while (target == null) {
            }
            String entry = target.toLegacyEntry();
            if (entry.isBlank()) continue;
            this.itemNames.add(entry);
        }
    }

    static {
        int[] tmp0 = new int[6];
        tmp0[0] = PackUtilDropAction.PICKUP.ordinal();
        tmp0[1] = PackUtilDropAction.QUICK_MOVE.ordinal();
        tmp0[2] = PackUtilDropAction.SWAP.ordinal();
        tmp0[3] = PackUtilDropAction.CLONE.ordinal();
        tmp0[4] = PackUtilDropAction.DROP_ITEM.ordinal();
        tmp0[5] = PackUtilDropAction.DROP_STACK.ordinal();
        ITEM_CLICK_ACTIONS = tmp0;
    }
}
