/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.XCarryAction;

static class MacroExecutor.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode;

    static {
        $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode = new int[XCarryAction.Mode.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode[XCarryAction.Mode.PUT_IN.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode[XCarryAction.Mode.TAKE_OUT.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode[XCarryAction.Mode.TAKE_OUT.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode[XCarryAction.Mode.DROP.ordinal()] = 3;
            /* goto L54; */
            var0 = null;
            L54: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$macro$XCarryAction$Mode[XCarryAction.Mode.DROP.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
