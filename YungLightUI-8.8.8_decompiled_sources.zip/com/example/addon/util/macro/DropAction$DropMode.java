/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum DropAction.DropMode {
    public static final DropAction.DropMode ALL = new DropAction.DropMode("ALL", 0);
    public static final DropAction.DropMode TIMES = new DropAction.DropMode("TIMES", 1);
    private static final /* synthetic */ DropAction.DropMode[] $VALUES;

    public static DropAction.DropMode[] values() {
        return (DropAction.DropMode[])$VALUES.clone();
    }

    public static DropAction.DropMode valueOf(String name) {
        return (DropAction.DropMode)Enum.valueOf(DropAction.DropMode.class, name);
    }

    private DropAction.DropMode() {
        super(var1, var2);
    }

    static {
        $VALUES = DropAction.DropMode.$values();
    }
}
