/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.YungLightAddon;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilClipboardHelper;
import com.example.addon.util.PacketRegenerator;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_310;

public class PacketAction
implements MacroAction {
    public String packetData = "";
    public boolean regenerate = true;
    public String description = "Packet";

    public PacketAction() {
    }

    public PacketAction(String packetData, boolean regenerate, String description) {
        this.packetData = packetData;
        this.regenerate = regenerate;
        this.description = description;
    }

    public void execute(class_310 mc) {
        if (mc.method_1562() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo network connection!");
            return;
        }
        if (this.packetData.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("§cPacket data is empty!");
            return;
        }
        try {
            class_2596<?> packet = PackUtilClipboardHelper.deserializePacketFromBase64(this.packetData);
            if (packet == null) {
                PackUtilClientMessaging.sendPrefixed("§cFailed to deserialize packet! Invalid data.");
                return;
            }
        }
        catch (Exception e) {
            PackUtilClientMessaging.sendPrefixed("§cPacket send error: " + e.getMessage());
            YungLightAddon.LOG.error("[MacroExecutor] Packet action failed", e);
            L118: ;
            return;
        }
        try {
            if (this.regenerate) {
                class_2596<?> regenerated = PacketRegenerator.regenerate(packet);
                if (regenerated == null) {
                    PackUtilClientMessaging.sendPrefixed("§cFailed to regenerate packet: " + packet.getClass().getSimpleName());
                    return;
                }
            }
        }
        catch (Exception e) {
            PackUtilClientMessaging.sendPrefixed("§cPacket send error: " + e.getMessage());
            YungLightAddon.LOG.error("[MacroExecutor] Packet action failed", e);
            L118: ;
            return;
        }
        try {
            packet = regenerated;
            L83: ;
            mc.method_1562().method_52787(packet);
        }
        catch (Exception e) {
            PackUtilClientMessaging.sendPrefixed("§cPacket send error: " + e.getMessage());
            YungLightAddon.LOG.error("[MacroExecutor] Packet action failed", e);
            L118: ;
            return;
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("type", this.getType().name());
        tag.method_10582("packetData", this.packetData);
        tag.method_10556("regenerate", this.regenerate);
        tag.method_10582("description", this.description);
        return tag;
    }

    public void fromTag(class_2487 tag) {
        if (tag.method_10545("packetData")) {
            this.packetData = tag.method_68564("packetData", "");
        }
        if (tag.method_10545("regenerate")) {
            this.regenerate = tag.method_68566("regenerate", true);
        }
        if (tag.method_10545("description")) {
            this.description = tag.method_68564("description", "");
        }
    }

    public MacroActionType getType() {
        return MacroActionType.PACKET;
    }

    public String getDisplayName() {
        return this.description.isEmpty() ? "Unknown Packet" : this.description;
    }

    public String getIcon() {
        return "Pkt";
    }
}
