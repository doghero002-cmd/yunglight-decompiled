/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.MacroConditionRegistry;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_310;

static class MacroConditionRegistry.HandlerItemCondition
implements MacroConditionRegistry.PendingCondition {
    final ItemTarget target;
    final CompletableFuture<Void> future;
    private volatile boolean cancelled = false;

    MacroConditionRegistry.HandlerItemCondition(ItemTarget target, CompletableFuture<Void> future) {
        this.target = target == null ? new ItemTarget() : target.copy();
        this.future = future;
    }

    public boolean check(class_310 mc) {
        if (mc.field_1724 == null || !this.target.hasIdentity()) {
            return false;
        }
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null) {
            return false;
        }
        var var3 = handler.field_7761.iterator();
        while (var3.hasNext()) {
            class_1735 slot = (class_1735)var3.next();
            if (slot == null) continue;
            while (slot.method_7677().method_7960()) {
            }
            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, slot.field_7874);
            if (!this.target.matches(slot.method_7677(), visibleSlot)) continue;
            return true;
        }
        return false;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.cancelled = true;
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.cancelled || this.future.isCancelled();
    }
}
