/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import net.minecraft.class_1799;

private static final record InventoryAuditAction.SlotSnapshot {
    private final int visibleSlot;
    private final String label;
    private final class_1799 stack;

    private InventoryAuditAction.SlotSnapshot(int visibleSlot, String label, class_1799 stack) {
        this.visibleSlot = visibleSlot;
        this.label = label;
        this.stack = stack;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int visibleSlot() {
        return this.visibleSlot;
    }

    public String label() {
        return this.label;
    }

    public class_1799 stack() {
        return this.stack;
    }
}
