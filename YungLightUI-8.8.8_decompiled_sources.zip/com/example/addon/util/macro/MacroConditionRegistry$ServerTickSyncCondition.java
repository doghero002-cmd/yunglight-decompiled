/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.ServerTickTracker;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;

static class MacroConditionRegistry.ServerTickSyncCondition
implements MacroConditionRegistry.PendingCondition {
    final CompletableFuture<Void> future;
    final int bufferMs;
    final int maxWaitMs;
    final boolean ignorePing;
    final long startTimeNanos;

    MacroConditionRegistry.ServerTickSyncCondition(CompletableFuture<Void> future, int bufferMs, int maxWaitMs, boolean ignorePing) {
        this.future = future;
        this.bufferMs = bufferMs;
        this.maxWaitMs = maxWaitMs;
        this.ignorePing = ignorePing;
        this.startTimeNanos = System.nanoTime();
    }

    public boolean check(class_310 mc) {
        long now = System.nanoTime();
        long elapsedMs = (now - this.startTimeNanos) / 1000000L;
        if (elapsedMs >= (long)this.maxWaitMs) {
            return true;
        }
        if (!ServerTickTracker.isReady()) {
            return false;
        }
        long optimalTime = ServerTickTracker.getOptimalSendTime(this.bufferMs, this.ignorePing);
        return now >= optimalTime;
    }

    public void complete() {
        this.future.complete(null);
    }

    public void cancel() {
        this.future.cancel(true);
    }

    public boolean isCancelled() {
        return this.future.isCancelled();
    }
}
