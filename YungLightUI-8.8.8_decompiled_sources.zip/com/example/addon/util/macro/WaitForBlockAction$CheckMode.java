/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.macro;

public static enum WaitForBlockAction.CheckMode {
    public static final WaitForBlockAction.CheckMode AT_POSITION = new WaitForBlockAction.CheckMode("AT_POSITION", 0);
    public static final WaitForBlockAction.CheckMode IN_REACH = new WaitForBlockAction.CheckMode("IN_REACH", 1);
    public static final WaitForBlockAction.CheckMode LOOKING_AT = new WaitForBlockAction.CheckMode("LOOKING_AT", 2);
    private static final /* synthetic */ WaitForBlockAction.CheckMode[] $VALUES;

    public static WaitForBlockAction.CheckMode[] values() {
        return (WaitForBlockAction.CheckMode[])$VALUES.clone();
    }

    public static WaitForBlockAction.CheckMode valueOf(String name) {
        return (WaitForBlockAction.CheckMode)Enum.valueOf(WaitForBlockAction.CheckMode.class, name);
    }

    private WaitForBlockAction.CheckMode() {
        super(var1, var2);
    }

    static {
        $VALUES = WaitForBlockAction.CheckMode.$values();
    }
}
