/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

final class PackUtilLocalCraftingRegistry {
    private static final Object LOCK = new Object();
    private static class_3300 cachedResourceManager;
    private static int cachedModCount = -1;
    private static List<PackUtilLocalCraftingRegistry.LocalCraftingRecipe> cachedRecipes = List.of();

    private PackUtilLocalCraftingRegistry() {
    }

    static List<PackUtilLocalCraftingRegistry.LocalCraftingRecipe> getRecipes(class_310 mc) {
        if (mc == null) {
            return List.of();
        }
        class_3300 resourceManager = mc.method_1478();
        int modCount = FabricLoader.getInstance().getAllMods().size();
        var var3 = LOCK;
        synchronized (LOCK) {
        if (cachedResourceManager == resourceManager) {
            if (cachedModCount == modCount) {
                if (!cachedRecipes.isEmpty()) {
                    }
                    return cachedRecipes;
                }
            }
        }
    }

    private static List<PackUtilLocalCraftingRegistry.LocalCraftingRecipe> loadRecipes(class_3300 resourceManager, class_7699 enabledFeatures) {
        LinkedHashMap<String, PackUtilLocalCraftingRegistry.LocalCraftingRecipe> byKey = new LinkedHashMap();
        PackUtilLocalCraftingRegistry.loadRecipesFromModRoots(byKey, enabledFeatures);
        PackUtilLocalCraftingRegistry.mergeResourceManagerRecipes(byKey, resourceManager, enabledFeatures);
        List<PackUtilLocalCraftingRegistry.LocalCraftingRecipe> recipes = new ArrayList(byKey.values());
        recipes.sort(Comparator.comparing(PackUtilLocalCraftingRegistry::lambda$loadRecipes$0, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(recipes);
    }

    private static void loadRecipesFromModRoots(Map<String, PackUtilLocalCraftingRegistry.LocalCraftingRecipe> byKey, class_7699 enabledFeatures) {
        var var2 = FabricLoader.getInstance().getAllMods().iterator();
        while (var2.hasNext()) {
            ModContainer modContainer = (ModContainer)var2.next();
            var var4 = modContainer.getRootPaths().iterator();
            while (var4.hasNext()) {
                Path rootPath = (Path)var4.next();
                Path dataRoot = rootPath.resolve("data");
                while (!Files.exists(dataRoot, new LinkOption[0])) {
                }
                Stream<Path> paths = Files.walk(dataRoot, new FileVisitOption[0]);
                var var8 = paths.filter(PackUtilLocalCraftingRegistry::lambda$loadRecipesFromModRoots$1).filter(PackUtilLocalCraftingRegistry::lambda$loadRecipesFromModRoots$2).toList().iterator();
                while (var8.hasNext()) {
                    Path recipePath = (Path)var8.next();
                    LocalCraftingRecipe recipe = PackUtilLocalCraftingRegistry.parseRecipePath(dataRoot, recipePath, enabledFeatures);
                    if (recipe == null) continue;
                    byKey.put(recipe.recipeKey, recipe);
                }
                if (paths == null) { /* goto L237; */ }
                paths.close();
                /* goto L237; */
                var8 = null;
                if (paths == null) { /* goto L234; */ }
                paths.close();
                /* goto L234; */
                recipePath = null;
                var8.addSuppressed(recipePath);
                L234: ;
                throw var8;
                L237: ;
                /* goto @242; */
                paths = null;
            }
        }
    }

    private static void mergeResourceManagerRecipes(Map<String, PackUtilLocalCraftingRegistry.LocalCraftingRecipe> byKey, class_3300 resourceManager, class_7699 enabledFeatures) {
        if (resourceManager == null) {
            return;
        }
        Map<class_2960, class_3298> resources = resourceManager.method_14488("recipe", PackUtilLocalCraftingRegistry::lambda$mergeResourceManagerRecipes$3);
        if (resources.isEmpty()) {
            return;
        }
        List<Map.Entry<class_2960, class_3298>> ordered = new ArrayList(resources.entrySet());
        ordered.sort(Comparator.comparing(PackUtilLocalCraftingRegistry::lambda$mergeResourceManagerRecipes$4, String.CASE_INSENSITIVE_ORDER));
        var var5 = ordered.iterator();
        while (var5.hasNext()) {
            Map.Entry<class_2960, class_3298> entry = (Map.Entry)var5.next();
            LocalCraftingRecipe recipe = PackUtilLocalCraftingRegistry.parseRecipe((class_2960)entry.getKey(), (class_3298)entry.getValue(), enabledFeatures);
            if (recipe == null) continue;
            byKey.put(recipe.recipeKey, recipe);
        }
    }

    private static PackUtilLocalCraftingRegistry.LocalCraftingRecipe parseRecipePath(Path dataRoot, Path recipePath, class_7699 enabledFeatures) {
        Path relative = dataRoot.relativize(recipePath);
        if (relative.getNameCount() < 3) {
            return null;
        }
        String namespace = relative.getName(0).toString();
        String folder = relative.getName(1).toString();
        if (!"recipe".equals(folder)) {
            return null;
        }
        String path = relative.subpath(1, relative.getNameCount()).toString().replace(92, 47);
        class_2960 resourceId = class_2960.method_60655(namespace, path);
        BufferedReader reader = Files.newBufferedReader(recipePath);
        var var9 = PackUtilLocalCraftingRegistry.parseRecipe(resourceId, reader, enabledFeatures);
        if (reader != null) {
            reader.close();
        }
        return var9;
        L150: ;
        throw var9;
    }

    private static PackUtilLocalCraftingRegistry.LocalCraftingRecipe parseRecipe(class_2960 resourceId, class_3298 resource, class_7699 enabledFeatures) {
        BufferedReader reader = resource.method_43039();
        var var4 = PackUtilLocalCraftingRegistry.parseRecipe(resourceId, reader, enabledFeatures);
        if (reader != null) {
            reader.close();
        }
        return var4;
        L46: ;
        throw var4;
    }

    private static PackUtilLocalCraftingRegistry.LocalCraftingRecipe parseRecipe(class_2960 resourceId, BufferedReader reader, class_7699 enabledFeatures) {
        try {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            String type = PackUtilLocalCraftingRegistry.getString(root, "type");
            if (!"minecraft:crafting_shaped".equals(type)) {
                if (!"minecraft:crafting_shapeless".equals(type)) {
                    return null;
                }
            }
        }
        catch (IllegalStateException ignored) {
        }
        catch (JsonParseException ignored) {
            return null;
        }
        try {
            class_1799 result = PackUtilLocalCraftingRegistry.parseResult(root.getAsJsonObject("result"));
            if (result == null || result.method_7960() || !result.method_45435(enabledFeatures)) {
                return null;
            }
        }
        catch (IllegalStateException ignored) {
        }
        catch (JsonParseException ignored) {
            return null;
        }
        try {
            String recipeKey = PackUtilLocalCraftingRegistry.normalizeRecipeKey(resourceId);
            return "minecraft:crafting_shaped".equals(type) ? PackUtilLocalCraftingRegistry.parseShaped(recipeKey, result, root) : PackUtilLocalCraftingRegistry.parseShapeless(recipeKey, result, root);
        }
        catch (IllegalStateException ignored) {
        }
        catch (JsonParseException ignored) {
            return null;
        }
    }

    private static PackUtilLocalCraftingRegistry.LocalCraftingRecipe parseShaped(String recipeKey, class_1799 result, JsonObject root) {
        JsonArray pattern = root.getAsJsonArray("pattern");
        JsonObject key = root.getAsJsonObject("key");
        if (pattern == null || key == null || pattern.isEmpty()) {
            return null;
        }
        int height = pattern.size();
        int width = 0;
        List<class_1856> gridIngredients = pattern.iterator();
        while (gridIngredients.hasNext()) {
            JsonElement rowElement = (JsonElement)gridIngredients.next();
            if (rowElement.isJsonPrimitive()) continue;
            return null;
            width = Math.max(width, rowElement.getAsString().length());
        }
        if (width <= 0) {
            return null;
        }
        gridIngredients = new ArrayList(width * height);
        requirements = new ArrayList();
        List<String> signatureParts = new ArrayList();
        String signature = pattern.iterator();
        while (signature.hasNext()) {
            JsonElement rowElement = (JsonElement)signature.next();
            String row = rowElement.getAsString();
            for (int col = 0; col < width; col++) {
                char symbol = col < row.length() ? row.charAt(col) : 32;
                if (symbol == 32) {
                    gridIngredients.add(null);
                    signatureParts.add("_");
                } else {
                    JsonElement ingredientElement = key.get(String.valueOf(symbol));
                    ParsedIngredient parsed = PackUtilLocalCraftingRegistry.parseIngredient(ingredientElement);
                    if (!parsed == null || parsed.ingredient.method_65799()) continue;
                    return null;
                    gridIngredients.add(parsed.ingredient);
                    requirements.add(parsed.ingredient);
                    signatureParts.add(parsed.signature);
                }
            }
        }
        signature = PackUtilLocalCraftingRegistry.buildSignature(result, true, width, height, signatureParts);
        return new PackUtilLocalCraftingRegistry.LocalCraftingRecipe(recipeKey, result, width, height, true, gridIngredients, requirements, signature);
    }

    private static PackUtilLocalCraftingRegistry.LocalCraftingRecipe parseShapeless(String recipeKey, class_1799 result, JsonObject root) {
        JsonArray ingredients = root.getAsJsonArray("ingredients");
        if (ingredients == null || ingredients.isEmpty()) {
            return null;
        }
        List<class_1856> gridIngredients = new ArrayList(ingredients.size());
        List<class_1856> requirements = new ArrayList(ingredients.size());
        List<String> signatureParts = new ArrayList(ingredients.size());
        String signature = ingredients.iterator();
        while (signature.hasNext()) {
            JsonElement ingredientElement = (JsonElement)signature.next();
            ParsedIngredient parsed = PackUtilLocalCraftingRegistry.parseIngredient(ingredientElement);
            if (!parsed == null || parsed.ingredient.method_65799()) continue;
            return null;
            gridIngredients.add(parsed.ingredient);
            requirements.add(parsed.ingredient);
            signatureParts.add(parsed.signature);
        }
        signatureParts.sort(String.CASE_INSENSITIVE_ORDER);
        signature = PackUtilLocalCraftingRegistry.buildSignature(result, false, ingredients.size(), 1, signatureParts);
        return new PackUtilLocalCraftingRegistry.LocalCraftingRecipe(recipeKey, result, ingredients.size(), 1, false, gridIngredients, requirements, signature);
    }

    private static class_1799 parseResult(JsonObject resultObject) {
        if (resultObject == null) {
            return class_1799.field_8037;
        }
        class_2960 itemId = PackUtilLocalCraftingRegistry.parseIdentifier(resultObject, "id", "item");
        if (itemId == null || !class_7923.field_41178.method_10250(itemId)) {
            return class_1799.field_8037;
        }
        class_1792 item = (class_1792)class_7923.field_41178.method_63535(itemId);
        if (item == null) {
            return class_1799.field_8037;
        }
        int count = Math.max(1, PackUtilLocalCraftingRegistry.rootInt(resultObject, "count", 1));
        return new class_1799(item, count);
    }

    private static PackUtilLocalCraftingRegistry.ParsedIngredient parseIngredient(JsonElement element) {
        if (element == null || element.isJsonNull()) {
            return null;
        }
        LinkedHashMap<class_2960, class_1792> resolvedItems = new LinkedHashMap();
        PackUtilLocalCraftingRegistry.collectItems(element, resolvedItems);
        if (resolvedItems.isEmpty()) {
            return null;
        }
        class_1856 ingredient = class_1856.method_26964(resolvedItems.values().stream());
        if (ingredient.method_65799()) {
            return null;
        }
        TreeSet<String> orderedIds = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        var var4 = resolvedItems.keySet().iterator();
        while (var4.hasNext()) {
            class_2960 id = (class_2960)var4.next();
            orderedIds.add(id.toString());
        }
        return new PackUtilLocalCraftingRegistry.ParsedIngredient(ingredient, String.join(",", orderedIds));
    }

    private static void collectItems(JsonElement element, Map<class_2960, class_1792> resolvedItems) {
        if (element == null || element.isJsonNull()) {
            return;
        }
        if (!element.isJsonArray()) { /* goto L55; */ }
        String raw = element.getAsJsonArray().iterator();
        while (raw.hasNext()) {
            JsonElement child = (JsonElement)raw.next();
            PackUtilLocalCraftingRegistry.collectItems(child, resolvedItems);
        }
        return;
        L55: ;
        if (!element.isJsonPrimitive()) { /* goto L106; */ }
        raw = element.getAsString().trim();
        if (raw.isEmpty()) {
            return;
        }
        if (raw.startsWith("#")) {
            PackUtilLocalCraftingRegistry.addTagItems(raw.substring(1), resolvedItems);
        } else {
            PackUtilLocalCraftingRegistry.addItem(raw, resolvedItems);
        }
        return;
        L106: ;
        if (!element.isJsonObject()) {
            return;
        }
        object = element.getAsJsonObject();
        itemId = PackUtilLocalCraftingRegistry.parseIdentifier(object, "id", "item");
        if (itemId != null) {
            PackUtilLocalCraftingRegistry.addItem(itemId.toString(), resolvedItems);
        }
        class_2960 tagId = PackUtilLocalCraftingRegistry.parseIdentifier(object, "tag");
        if (tagId != null) {
            PackUtilLocalCraftingRegistry.addTagItems(tagId.toString(), resolvedItems);
        }
    }

    private static void addItem(String rawId, Map<class_2960, class_1792> resolvedItems) {
        class_2960 id = class_2960.method_12829(rawId);
        if (id == null || !class_7923.field_41178.method_10250(id)) {
            return;
        }
        class_1792 item = (class_1792)class_7923.field_41178.method_63535(id);
        if (item != null) {
            resolvedItems.put(id, item);
        }
    }

    private static void addTagItems(String rawTagId, Map<class_2960, class_1792> resolvedItems) {
        class_2960 tagId = class_2960.method_12829(rawTagId);
        if (tagId == null) {
            return;
        }
        class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, tagId);
        var var4 = class_7923.field_41178.method_40286(key).iterator();
        while (var4.hasNext()) {
            class_6880<class_1792> entry = (class_6880)var4.next();
            class_1792 item = (class_1792)entry.comp_349();
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            if (itemId == null) continue;
            resolvedItems.put(itemId, item);
        }
    }

    private static String buildSignature(class_1799 result, boolean shaped, int width, int height, Collection<String> parts) {
        class_2960 resultId = class_7923.field_41178.method_10221(result.method_7909());
        String resultKey = resultId == null ? result.method_7964().getString() : resultId.toString();
        return resultKey + "|" + result.method_7947() + "|" + shaped ? "shaped" : "shapeless" + "|" + width + "x" + height + "|" + String.join(";", parts);
    }

    private static String normalizeRecipeKey(class_2960 resourceId) {
        String path = resourceId.method_12832();
        if (path.startsWith("recipe/")) {
            path = path.substring("recipe/".length());
        }
        if (path.endsWith(".json")) {
            path = path.substring(0, path.length() - ".json".length());
        }
        return class_2960.method_60655(resourceId.method_12836(), path).toString();
    }

    private static class_2960 parseIdentifier(JsonObject object, String ... keys) {
        if (object == null || keys == null) {
            return null;
        }
        var var2 = keys;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            String key = var2[var4];
            if (key == null) { /* goto L77; */ }
            if (!object.has(key)) {
            } else {
                JsonElement element = object.get(key);
                if (element != null) {
                    if (element.isJsonPrimitive()) {
                        return class_2960.method_12829(element.getAsString());
                    }
                }
            }
        }
        return null;
    }

    private static String getString(JsonObject object, String key) {
        if (object == null || key == null || !object.has(key)) {
            return "";
        }
        JsonElement element = object.get(key);
        return element != null && element.isJsonPrimitive() ? element.getAsString() : "";
    }

    private static int rootInt(JsonObject object, String key, int fallback) {
        if (object == null || key == null || !object.has(key)) {
            return fallback;
        }
        JsonElement element = object.get(key);
        if (element == null || !element.isJsonPrimitive()) {
            return fallback;
        }
        try {
            return element.getAsInt();
        }
        catch (NumberFormatException ignored) {
            return fallback;
        }
    }
}
