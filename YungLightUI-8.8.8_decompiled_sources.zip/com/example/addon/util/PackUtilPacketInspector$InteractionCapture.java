/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_1268;
import net.minecraft.class_243;

private static final class PackUtilPacketInspector.InteractionCapture {
    private String kind;
    private class_1268 hand;
    private class_243 hitPos;

    private PackUtilPacketInspector.InteractionCapture() {
    }
}
