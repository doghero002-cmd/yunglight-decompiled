/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.List;
import java.util.Map;

private static class PackUtilLANSyncOverlay.MacroSyncStatus {
    final List<String> missingPeers;
    final Map<String, Integer> differentPeers;

    PackUtilLANSyncOverlay.MacroSyncStatus(List<String> missingPeers, Map<String, Integer> differentPeers) {
        this.missingPeers = missingPeers;
        this.differentPeers = differentPeers;
    }

    boolean canExecute() {
        return this.missingPeers.isEmpty();
    }
}
