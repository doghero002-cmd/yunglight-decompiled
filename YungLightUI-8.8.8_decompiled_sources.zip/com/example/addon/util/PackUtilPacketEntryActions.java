/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroEditorOverlay;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PacketRegenerator;
import com.example.addon.util.macro.SendPacketAction;
import com.example.addon.util.macro.WaitForPacketAction;
import net.minecraft.class_2596;

public final class PackUtilPacketEntryActions {
    private PackUtilPacketEntryActions() {
    }

    public static boolean canQueue(PackUtilPacketLoggerOverlay.LogEntry entry) {
        return entry != null && "C2S".equalsIgnoreCase(entry.direction) && entry.packetRef != null;
    }

    public static boolean canAddSendAction(PackUtilPacketLoggerOverlay.LogEntry entry) {
        return PackUtilPacketEntryActions.canQueue(entry);
    }

    public static boolean canAddWaitAction(PackUtilPacketLoggerOverlay.LogEntry entry) {
        return entry != null && entry.shortName != null && !entry.shortName.isBlank() && entry.direction != null && !entry.direction.isBlank();
    }

    public static boolean queue(PackUtilPacketLoggerOverlay.LogEntry entry) {
        if (!PackUtilPacketEntryActions.canQueue(entry)) {
            PackUtilClientMessaging.sendPrefixed("§cOnly C2S packets can be queued.");
            return false;
        }
        PackUtilSharedState.get().enqueuePacket(entry.packetRef);
        PackUtilClientMessaging.sendPrefixed("Queued: " + entry.shortName);
        return true;
    }

    public static boolean addSendActionToVisibleMacro(PackUtilPacketLoggerOverlay.LogEntry entry) {
        if (!PackUtilPacketEntryActions.canAddSendAction(entry)) {
            PackUtilClientMessaging.sendPrefixed("§cOnly C2S packets can be added as send actions.");
            return false;
        }
        PackUtilMacroEditorOverlay macroEditor = PackUtilPacketEntryActions.getOrOpenMacroEditor();
        if (macroEditor == null) {
            PackUtilClientMessaging.sendPrefixed("§cCannot open the macro editor.");
            return false;
        }
        class_2596<?> regenerated = PacketRegenerator.regenerate(entry.packetRef);
        if (regenerated == null) {
            PackUtilClientMessaging.sendPrefixed("§cCannot regenerate: " + entry.shortName);
            return false;
        }
        SendPacketAction action = new SendPacketAction();
        action.waitForGui = false;
        action.guiName = "";
        action.packets.add(new PackUtilSharedState.QueuedPacket(regenerated, 0));
        macroEditor.addAction(action);
        PackUtilOverlayManager.get().bringToFront(macroEditor);
        PackUtilClientMessaging.sendPrefixed("Added send action: " + entry.shortName);
        return true;
    }

    public static boolean addWaitActionToVisibleMacro(PackUtilPacketLoggerOverlay.LogEntry entry) {
        if (!PackUtilPacketEntryActions.canAddWaitAction(entry)) {
            PackUtilClientMessaging.sendPrefixed("§cCannot add this packet as a wait condition.");
            return false;
        }
        PackUtilMacroEditorOverlay macroEditor = PackUtilPacketEntryActions.getOrOpenMacroEditor();
        if (macroEditor == null) {
            PackUtilClientMessaging.sendPrefixed("§cCannot open the macro editor.");
            return false;
        }
        String target = WaitForPacketAction.withDirection(entry.direction, entry.shortName);
        if (target.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("§cCannot add this packet as a wait condition.");
            return false;
        }
        WaitForPacketAction action = new WaitForPacketAction(target);
        action.packetNames.add(target);
        macroEditor.addAction(action);
        PackUtilOverlayManager.get().bringToFront(macroEditor);
        PackUtilClientMessaging.sendPrefixed("Added wait condition: " + WaitForPacketAction.getDisplayLabel(target));
        return true;
    }

    public static boolean hasVisibleMacroEditor() {
        return PackUtilPacketEntryActions.findVisibleMacroEditor() != null;
    }

    private static PackUtilMacroEditorOverlay getOrOpenMacroEditor() {
        PackUtilMacroEditorOverlay macroEditor = PackUtilPacketEntryActions.findVisibleMacroEditor();
        if (macroEditor != null) {
            PackUtilOverlayManager.get().bringToFront(macroEditor);
            return macroEditor;
        }
        macroEditor = PackUtilMacroEditorOverlay.getSharedOverlay();
        if (macroEditor == null) {
            return null;
        }
        PackUtilMacro existingMacro = PackUtilSharedState.get().getEditingMacro();
        macroEditor.open(existingMacro);
        PackUtilOverlayManager.get().bringToFront(macroEditor);
        return macroEditor;
    }

    private static PackUtilMacroEditorOverlay findVisibleMacroEditor() {
        var var0 = PackUtilOverlayManager.get().getOverlays().iterator();
        while (var0.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var0.next();
            if (overlay instanceof PackUtilMacroEditorOverlay) {
                PackUtilMacroEditorOverlay macroEditor = (PackUtilMacroEditorOverlay)overlay;
                if (!macroEditor.isVisible()) continue;
                return macroEditor;
            }
        }
        return null;
    }
}
