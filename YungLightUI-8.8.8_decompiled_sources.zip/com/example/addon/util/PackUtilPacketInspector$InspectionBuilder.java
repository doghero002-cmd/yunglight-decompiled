/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilPacketInspector;
import java.util.ArrayList;
import java.util.List;

private static final class PackUtilPacketInspector.InspectionBuilder {
    private final String title;
    private final List<PackUtilPacketInspector.InspectionLine> lines = new ArrayList();
    private final StringBuilder plain = new StringBuilder();
    private boolean truncated;

    private PackUtilPacketInspector.InspectionBuilder(String title) {
        this.title = title;
    }

    void section(String title, int color) {
        this.line("[" + title + "]", color);
    }

    void line(String text, int color) {
        if (this.truncated) {
            return;
        }
        if (this.lines.size() >= 900) {
            this.truncated = true;
            this.lines.add(new PackUtilPacketInspector.InspectionLine("... output truncated ...", PackUtilColors.dangerText()));
            this.plain.append("... output truncated ...\n");
            return;
        }
        this.lines.add(new PackUtilPacketInspector.InspectionLine(text, color));
        this.plain.append(text).append(10);
    }

    void blank() {
        this.line("", PackUtilColors.textPrimary());
    }

    void appendFrom(PackUtilPacketInspector.InspectionBuilder other) {
        if (other == null) {
            return;
        }
        var var2 = other.lines.iterator();
        while (var2.hasNext()) {
            InspectionLine line = (PackUtilPacketInspector.InspectionLine)var2.next();
            this.line(line.getText(), line.getColor());
        }
    }

    boolean isFull() {
        return this.truncated;
    }

    PackUtilPacketInspector.PacketInspection build() {
        return new PackUtilPacketInspector.PacketInspection(this.title, this.lines, this.plain.toString());
    }
}
