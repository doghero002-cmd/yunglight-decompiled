/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_1856;

private static final class PackUtilCraftingHelper.ExpectedGridSlot {
    private final int slotId;
    private final class_1856 ingredient;
    private final int expectedCount;

    private PackUtilCraftingHelper.ExpectedGridSlot(int slotId, class_1856 ingredient, int expectedCount) {
        this.slotId = slotId;
        this.ingredient = ingredient;
        this.expectedCount = expectedCount;
    }
}
