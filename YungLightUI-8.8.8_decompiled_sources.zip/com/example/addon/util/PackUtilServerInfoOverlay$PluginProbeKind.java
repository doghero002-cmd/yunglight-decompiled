/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilServerInfoOverlay.PluginProbeKind {
    public static final PackUtilServerInfoOverlay.PluginProbeKind ROOT = new PackUtilServerInfoOverlay.PluginProbeKind("ROOT", 0);
    public static final PackUtilServerInfoOverlay.PluginProbeKind HELP = new PackUtilServerInfoOverlay.PluginProbeKind("HELP", 1);
    public static final PackUtilServerInfoOverlay.PluginProbeKind PLUGIN_LIST = new PackUtilServerInfoOverlay.PluginProbeKind("PLUGIN_LIST", 2);
    public static final PackUtilServerInfoOverlay.PluginProbeKind VERSION = new PackUtilServerInfoOverlay.PluginProbeKind("VERSION", 3);
    public static final PackUtilServerInfoOverlay.PluginProbeKind NAMESPACE = new PackUtilServerInfoOverlay.PluginProbeKind("NAMESPACE", 4);
    private static final /* synthetic */ PackUtilServerInfoOverlay.PluginProbeKind[] $VALUES;

    public static PackUtilServerInfoOverlay.PluginProbeKind[] values() {
        return (PackUtilServerInfoOverlay.PluginProbeKind[])$VALUES.clone();
    }

    public static PackUtilServerInfoOverlay.PluginProbeKind valueOf(String name) {
        return (PackUtilServerInfoOverlay.PluginProbeKind)Enum.valueOf(PackUtilServerInfoOverlay.PluginProbeKind.class, name);
    }

    private PackUtilServerInfoOverlay.PluginProbeKind() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilServerInfoOverlay.PluginProbeKind.$values();
    }
}
