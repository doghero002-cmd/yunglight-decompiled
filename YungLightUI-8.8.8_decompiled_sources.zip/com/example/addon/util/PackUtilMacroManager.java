/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroEditorOverlay;
import com.example.addon.util.macro.MacroExecutor;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;

public class PackUtilMacroManager {
    private static PackUtilMacroManager INSTANCE;
    private List<PackUtilMacro> macros = new ArrayList();
    private final File saveFile = new File(YungLightAddon.FOLDER, "packutil_macros.nbt");
    private volatile long revision;

    private PackUtilMacroManager() {
        this.load();
    }

    public static synchronized PackUtilMacroManager get() {
        if (INSTANCE == null) {
            INSTANCE = new PackUtilMacroManager();
        }
        return INSTANCE;
    }

    public synchronized String createUniqueName(String preferredName) {
        String baseName = preferredName == null || preferredName.isBlank() ? "New Macro" : preferredName.trim();
        String candidate = baseName;
        int suffix = 1;
        while (this.get(candidate) != null) {
            candidate = baseName + " (" + suffix++ + ")";
        }
        return candidate;
    }

    public synchronized PackUtilMacro addImportedCopy(PackUtilMacro source, String preferredName) {
        if (source == null) {
            return null;
        }
        PackUtilMacro copy = source.deepCopy();
        copy.name = this.createUniqueName(preferredName != null && !preferredName.isBlank() ? preferredName : source.name);
        this.add(copy);
        return copy;
    }

    public synchronized void add(PackUtilMacro macro) {
        this.macros.add(macro);
        this.save();
    }

    public synchronized PackUtilMacro get(String name) {
        var var2 = this.macros.iterator();
        while (var2.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var2.next();
            if (!macro.name.equalsIgnoreCase(name)) continue;
            return macro;
        }
        return null;
    }

    public synchronized List<PackUtilMacro> getAll() {
        return new ArrayList(this.macros);
    }

    public long getRevision() {
        return this.revision;
    }

    public synchronized void remove(PackUtilMacro macro) {
        if (MacroExecutor.isRunning()) {
            String currentMacroName = MacroExecutor.getCurrentMacroName();
            if (currentMacroName != null) {
                if (currentMacroName.equals(macro.name)) {
                    MacroExecutor.stop();
                    PackUtilClientMessaging.sendPrefixed("§eStopped running macro before deletion: " + macro.name);
                }
            }
        }
        if (this.macros.remove(macro)) {
            this.save();
            PackUtilClientMessaging.sendPrefixed("§aDeleted macro: " + macro.name);
            editor = PackUtilMacroEditorOverlay.getSharedOverlay();
            if (editor != null) {
                if (editor.isEditingMacro(macro)) {
                    editor.close();
                }
            }
            if (PackUtilLANSync.getInstance().isInSession()) {
                PackUtilLANSync.getInstance().broadcastMacroDeletion(macro.name);
            }
        }
    }

    public void delete(PackUtilMacro macro) {
        this.remove(macro);
    }

    public void executeMacro(String name) {
        PackUtilMacro macro = this.get(name);
        if (macro != null) {
            macro.execute();
            PackUtilClientMessaging.sendPrefixed("§aExecuting macro: " + macro.name);
        } else {
            PackUtilClientMessaging.sendPrefixed("§cMacro not found: " + name);
        }
    }

    public void stopMacro() {
        if (MacroExecutor.isRunning()) {
            MacroExecutor.stop();
        } else {
            PackUtilClientMessaging.sendPrefixed("§eNo macro is currently running.");
        }
    }

    public synchronized void save() {
        this.revision = this.revision + 1L;
        try {
            class_2487 tag = new class_2487();
            class_2499 list = new class_2499();
            var var3 = this.macros.iterator();
            while (var3.hasNext()) {
                PackUtilMacro macro = (PackUtilMacro)var3.next();
                list.add(macro.toTag());
            }
            tag.method_10566("macros", list);
            class_2507.method_10630(tag, this.saveFile.toPath());
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("Failed to save PackUtil macros", e);
            L103: ;
            if (PackUtilLANSync.getInstance().isInSession()) {
                PackUtilLANSync.getInstance().broadcastMacroList();
            }
            return;
        }
        if (PackUtilLANSync.getInstance().isInSession()) {
            PackUtilLANSync.getInstance().broadcastMacroList();
        }
    }

    public synchronized void load() {
        if (!this.saveFile.exists()) {
            return;
        }
        try {
            class_2487 tag = class_2507.method_10633(this.saveFile.toPath());
            if (tag == null) { /* goto L116; */ }
            if (!tag.method_10545("macros")) { /* goto L116; */ }
            this.macros.clear();
            class_2499 list = (class_2499)tag.method_10580("macros");
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i) instanceof class_2487) {
                    PackUtilMacro macro = new PackUtilMacro();
                    macro.fromTag((class_2487)list.get(i));
                    this.macros.add(macro);
                }
            }
            this.revision = this.revision + 1L;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("Failed to load PackUtil macros", e);
            L142: ;
            return;
        }
    }
}
