/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilContainerTarget;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilPacketSender;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.PacketRegenerator;
import com.example.addon.util.macro.CraftAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_437;
import net.minecraft.class_634;

public final class PackUtilSharedState {
    private static final PackUtilSharedState INSTANCE = new PackUtilSharedState();
    private volatile boolean sendGuiPackets = true;
    private volatile boolean delayGuiPackets;
    private volatile boolean allowSignEditing = true;
    private volatile boolean allowBookUpdate = true;
    private volatile boolean bypassResourcePack;
    private volatile boolean resourcePackForceDeny;
    private volatile boolean xCarryActive;
    private volatile boolean xCarryForced;
    private volatile class_2338 lastInteractedBlockPos = null;
    private volatile PackUtilContainerTarget lastContainerTarget = null;
    private volatile boolean useCustomPackets = false;
    private Set<Class<? extends class_2596<?>>> c2sPackets = new HashSet();
    private Set<Class<? extends class_2596<?>>> s2cPackets = new HashSet();
    private final List<PackUtilSharedState.QueuedPacket> delayedPackets = new CopyOnWriteArrayList();
    private volatile boolean staggeredPacketSend = false;
    private volatile int staggeredSendDelay = 1;
    private final List<PackUtilSharedState.QueuedPacket> staggeredQueue = new CopyOnWriteArrayList();
    private final List<PackUtilSharedState.QueuedPacket> staggeredDisplayQueue = new CopyOnWriteArrayList();
    private final List<PackUtilSharedState.QueuedPacket> lastFlushedQueue = new CopyOnWriteArrayList();
    private final AtomicInteger queueRenderRevision = new AtomicInteger();
    private int staggeredTickCounter = 0;
    private class_634 staggeredNetworkHandler = null;
    private int staggeredTotal = 0;
    private boolean activeSendUsesExplicitDelays = false;
    private volatile PackUtilSharedState.DelayMode delayMode = PackUtilSharedState.DelayMode.TICKS;
    private PackUtilSharedState.DelayMode staggeredDelayMode = PackUtilSharedState.DelayMode.TICKS;
    private long flushStartNanos = 0L;
    private int flushStartClientTick = 0;
    private long activeCaptureLastNanos = -1L;
    private int activeCaptureLastClientTick = -1;
    private int activeCaptureTailDelay = 0;
    private String pendingQueueCompletionMessage = null;
    private class_437 storedScreen;
    private class_1703 storedScreenHandler;
    private boolean isFlushing = false;
    private boolean fabricatorOverlayVisible = false;
    private int fabricatorOverlayX = 500;
    private int fabricatorOverlayY = 5;
    private String fabricatorSlotValue = "0";
    private String fabricatorItemNameValue = "";
    private String fabricatorTimesValue = "1";
    private int fabricatorActionIndex = 0;
    private int fabricatorButtonIndex = 0;
    private boolean fabricatorDropWholeStack = false;
    private boolean fabricatorCraftUseMaxAmount = false;
    private String fabricatorCraftSearchValue = "";
    private int fabricatorCraftSelectedRecipeId = -1;
    private String fabricatorCraftSelectedRecipeKey = "";
    private int fabricatorCraftScrollOffset = 0;
    private final List<CraftAction.CraftEntry> fabricatorCraftPlanEntries = new ArrayList();
    private int fabricatorCraftPlanSelectedIndex = -1;
    private int fabricatorCraftPlanScrollOffset = 0;
    private boolean lanSyncOverlayVisible = false;
    private int lanSyncOverlayX = 500;
    private int lanSyncOverlayY = 5;
    private int lanSyncOverlayActiveTab = 0;
    private int lanSyncOverlayScrollOffset = 0;
    private boolean lanSyncOverlayPerUserMode = false;
    private String lanSyncOverlaySelectedMacroName = "";
    private String lanSyncOverlayExpandedExecutePeer = "";
    private String lanSyncOverlaySelectedPeer = "";
    private boolean macroListOverlayVisible = false;
    private int macroListOverlayX = 500;
    private int macroListOverlayY = 250;
    private int macroListOverlayScrollOffset = 0;
    private String macroListOverlaySearch = "";
    private boolean queueEditorOverlayVisible = false;
    private int queueEditorOverlayX = 100;
    private int queueEditorOverlayY = 100;
    private int serverInfoOverlayActiveTab = 0;
    private int serverInfoOverlayPluginScrollOffset = 0;
    private String serverInfoOverlaySelectedPlugin = "";
    private String serverInfoOverlayStateAddress = "";
    private int serverInfoOverlayProbeDelayMs = 50;
    private int serverInfoOverlayInfoWidth = 252;
    private int serverInfoOverlayInfoHeight = 258;
    private int serverInfoOverlayPluginWidth = 280;
    private int serverInfoOverlayPluginHeight = 280;
    private boolean macroEditorVisible = false;
    private PackUtilMacro editingMacro = null;
    private int macroEditorPanelX = 400;
    private int macroEditorPanelY = 100;
    private boolean blockSelectorVisible = false;
    private volatile boolean gbreakCaptureMode = false;
    private volatile int gbreakPacketCount = 0;
    private Runnable gbreakCallback = null;
    private final List<PackUtilSharedState.QueuedPacket> gbreakCapturedPackets = new ArrayList();
    private volatile boolean captureMode = false;
    private volatile long lastCaptureNanos = -1L;
    private volatile int lastCaptureClientTick = -1;
    private volatile int clientTickCounter = 0;
    private volatile double serverMsPerTick = 50;
    private volatile long lastTimeSyncMs = -1L;
    private final Map<String, PackUtilWindowLayout> windowLayouts = new HashMap();
    private final Map<String, PackUtilSharedState.ServerPluginScan> serverPluginScans = new HashMap();
    private final List<String> overlayOrder = new ArrayList();
    private String focusedOverlayId = "";
    private volatile boolean suppressNextClosePacket = false;
    private volatile Consumer<class_2338> blockCaptureCallback = null;
    private volatile Runnable attackCaptureCallback = null;
    private volatile Runnable captureCancelCallback = null;
    private volatile Consumer<String> entityCaptureCallback = null;
    private volatile boolean entityCaptureSpecific = false;

    private PackUtilSharedState() {
    }

    public static synchronized PackUtilSharedState get() {
        return INSTANCE;
    }

    public boolean isMacroEditorVisible() {
        return this.macroEditorVisible;
    }

    public void setMacroEditorVisible(boolean visible) {
        this.macroEditorVisible = visible;
    }

    public PackUtilMacro getEditingMacro() {
        return this.editingMacro;
    }

    public void setEditingMacro(PackUtilMacro macro) {
        this.editingMacro = macro;
    }

    public int getMacroEditorPanelX() {
        return this.macroEditorPanelX;
    }

    public void setMacroEditorPanelX(int x) {
        this.macroEditorPanelX = x;
    }

    public int getMacroEditorPanelY() {
        return this.macroEditorPanelY;
    }

    public void setMacroEditorPanelY(int y) {
        this.macroEditorPanelY = y;
    }

    public synchronized PackUtilWindowLayout getWindowLayout(String id) {
        PackUtilWindowLayout layout = (PackUtilWindowLayout)this.windowLayouts.get(id);
        if (layout == null) {
            return null;
        }
        return new PackUtilWindowLayout(layout.x, layout.y, layout.width, layout.height, layout.visible, layout.collapsed);
    }

    public synchronized void setWindowLayout(String id, PackUtilWindowLayout layout) {
        if (id == null || id.isEmpty() || layout == null) {
            return;
        }
        this.windowLayouts.put(id, new PackUtilWindowLayout(layout.x, layout.y, layout.width, layout.height, layout.visible, layout.collapsed));
    }

    public synchronized List<String> getOverlayOrder() {
        return new ArrayList(this.overlayOrder);
    }

    public synchronized void setOverlayOrder(List<String> order) {
        this.overlayOrder.clear();
        if (order == null) {
            return;
        }
        var var2 = order.iterator();
        while (var2.hasNext()) {
            String id = (String)var2.next();
            if (id == null) continue;
            if (id.isEmpty()) continue;
            while (this.overlayOrder.contains(id)) {
            }
            this.overlayOrder.add(id);
        }
    }

    public synchronized String getFocusedOverlayId() {
        return this.focusedOverlayId == null ? "" : this.focusedOverlayId;
    }

    public synchronized void setFocusedOverlayId(String overlayId) {
        this.focusedOverlayId = overlayId == null ? "" : overlayId.trim();
    }

    public synchronized PackUtilSharedState.ServerPluginScan getServerPluginScan(String address) {
        return this.getServerPluginScan(address, "");
    }

    public synchronized PackUtilSharedState.ServerPluginScan getServerPluginScan(String address, String contextSignature) {
        String key = PackUtilSharedState.buildServerPluginScanKey(address, contextSignature);
        if (key.isEmpty()) {
            return null;
        }
        ServerPluginScan scan = (PackUtilSharedState.ServerPluginScan)this.serverPluginScans.get(key);
        return scan == null ? null : scan.copy();
    }

    public synchronized void setServerPluginScan(String address, List<String> plugins, Map<String, List<String>> pluginCommands) {
        this.setServerPluginScan(address, "", plugins, pluginCommands, Map.of());
    }

    public synchronized void setServerPluginScan(String address, String contextSignature, List<String> plugins, Map<String, List<String>> pluginCommands) {
        this.setServerPluginScan(address, contextSignature, plugins, pluginCommands, Map.of());
    }

    public synchronized void setServerPluginScan(String address, String contextSignature, List<String> plugins, Map<String, List<String>> pluginCommands, Map<String, String> pluginEvidence) {
        String normalizedAddress = PackUtilSharedState.normalizeServerAddress(address);
        String normalizedContext = PackUtilSharedState.normalizeServerPluginContext(contextSignature);
        String key = PackUtilSharedState.buildServerPluginScanKey(normalizedAddress, normalizedContext);
        if (key.isEmpty()) {
            return;
        }
        this.serverPluginScans.put(key, new PackUtilSharedState.ServerPluginScan(normalizedAddress, normalizedContext, plugins, pluginCommands, pluginEvidence));
    }

    public synchronized void clearServerPluginScan(String address) {
        String normalized = PackUtilSharedState.normalizeServerAddress(address);
        if (normalized.isEmpty()) {
            return;
        }
        this.serverPluginScans.keySet().removeIf(PackUtilSharedState::lambda$clearServerPluginScan$0 /* captured: normalized */);
    }

    private static String normalizeServerAddress(String address) {
        return address == null ? "" : address.trim().toLowerCase(Locale.ROOT);
    }

    private static String normalizeServerPluginContext(String contextSignature) {
        return contextSignature == null ? "" : contextSignature.trim().toLowerCase(Locale.ROOT);
    }

    private static String buildServerPluginScanKey(String address, String contextSignature) {
        String normalizedAddress = PackUtilSharedState.normalizeServerAddress(address);
        if (normalizedAddress.isEmpty()) {
            return "";
        }
        String normalizedContext = PackUtilSharedState.normalizeServerPluginContext(contextSignature);
        return normalizedContext.isEmpty() ? normalizedAddress + "|default" : normalizedAddress + "|" + normalizedContext;
    }

    public boolean isBlockSelectorVisible() {
        return this.blockSelectorVisible;
    }

    public void setBlockSelectorVisible(boolean visible) {
        this.blockSelectorVisible = visible;
    }

    public boolean shouldSendGuiPackets() {
        return this.sendGuiPackets;
    }

    public void setSendGuiPackets(boolean value) {
        this.sendGuiPackets = value;
    }

    public boolean shouldDelayGuiPackets() {
        return this.delayGuiPackets;
    }

    public void setDelayGuiPackets(boolean value) {
        this.delayGuiPackets = value;
    }

    public boolean isXCarryActive() {
        return this.xCarryActive;
    }

    public void setXCarryActive(boolean value) {
        this.xCarryActive = value;
    }

    public boolean isXCarryForced() {
        return this.xCarryForced;
    }

    public void setXCarryForced(boolean value) {
        this.xCarryForced = value;
    }

    public class_2338 getLastInteractedBlockPos() {
        return this.lastInteractedBlockPos;
    }

    public void setLastInteractedBlockPos(class_2338 pos) {
        this.lastInteractedBlockPos = pos;
    }

    public PackUtilContainerTarget getLastContainerTarget() {
        return this.lastContainerTarget;
    }

    public void setLastContainerTarget(PackUtilContainerTarget target) {
        this.lastContainerTarget = target;
        if (target != null) {
            if (target.isBlock()) {
                this.lastInteractedBlockPos = target.blockPos();
            }
        }
    }

    public synchronized List<PackUtilSharedState.QueuedPacket> getDelayedPackets() {
        return new ArrayList(this.delayedPackets);
    }

    public int getQueueRenderRevision() {
        return this.queueRenderRevision.get();
    }

    public synchronized PackUtilSharedState.QueueRenderSnapshot getQueueRenderSnapshot(boolean sending, int maxLines) {
        List<PackUtilSharedState.QueuedPacket> source = sending ? this.staggeredQueue : this.delayedPackets;
        int totalCount = source.size();
        if (totalCount == 0 || maxLines <= 0) {
            return new PackUtilSharedState.QueueRenderSnapshot(List.of(), totalCount);
        }
        int limit = Math.min(totalCount, maxLines);
        ArrayList<PackUtilSharedState.QueuedPacket> visiblePackets = new ArrayList(limit);
        var var7 = source.iterator();
        while (var7.hasNext()) {
            QueuedPacket packet = (PackUtilSharedState.QueuedPacket)var7.next();
            if (packet == null) continue;
            while (packet.packet == null) {
            }
            int insertAt = visiblePackets.size();
            for (int i = 0; i < visiblePackets.size(); i++) {
                QueuedPacket existing = (PackUtilSharedState.QueuedPacket)visiblePackets.get(i);
                int byDelay = Integer.compare(existing.getDelay(), packet.getDelay());
                if (byDelay <= 0) {
                    if (byDelay != 0) { /* goto @188; */ }
                }
                insertAt = i;
                break;
                L188: ;
            }
            if (insertAt < limit) {
                visiblePackets.add(insertAt, packet);
                if (!visiblePackets.size() > limit) continue;
                visiblePackets.remove(limit);
            } else {
                if (!visiblePackets.size() < limit) continue;
                visiblePackets.add(packet);
            }
        }
        return new PackUtilSharedState.QueueRenderSnapshot(visiblePackets, totalCount);
    }

    public synchronized boolean hasDelayedPackets() {
        return !this.delayedPackets.isEmpty();
    }

    public synchronized void setDelayedPackets(List<PackUtilSharedState.QueuedPacket> packets) {
        this.delayedPackets.clear();
        if (packets != null) {
            if (!packets.isEmpty()) {
                this.delayedPackets.addAll(this.rebuildQueueWithSequentialIds(packets));
            }
        }
        this.checkAndResetIdCounter();
        this.markQueueRenderDirty();
    }

    public synchronized void clearDelayedPackets() {
        if (!this.delayedPackets.isEmpty()) {
            this.saveToHistory();
        }
        this.delayedPackets.clear();
        this.checkAndResetIdCounter();
        this.markQueueRenderDirty();
    }

    private void checkAndResetIdCounter() {
        this.resetCaptureTiming();
        if (this.delayedPackets.isEmpty() && this.staggeredQueue.isEmpty()) {
            PackUtilSharedState.QueuedPacket.resetIdCounter();
        }
    }

    private void resetCaptureTiming() {
        this.lastCaptureNanos = -1L;
        this.lastCaptureClientTick = -1;
    }

    private void saveToHistory() {
        this.lastFlushedQueue.clear();
        if (!this.delayedPackets.isEmpty()) {
            this.lastFlushedQueue.addAll(this.rebuildQueueWithSequentialIds(this.delayedPackets));
        }
    }

    private void saveQueueToHistory(List<PackUtilSharedState.QueuedPacket> queue) {
        this.lastFlushedQueue.clear();
        if (queue == null || queue.isEmpty()) {
            return;
        }
        this.lastFlushedQueue.addAll(this.rebuildQueueWithSequentialIds(queue));
    }

    private void stopStaggeredSendLocked() {
        this.staggeredQueue.clear();
        this.staggeredDisplayQueue.clear();
        this.staggeredNetworkHandler = null;
        this.staggeredTickCounter = 0;
        this.flushStartNanos = 0L;
        this.flushStartClientTick = 0;
        this.staggeredTotal = 0;
        this.activeSendUsesExplicitDelays = false;
        this.activeCaptureLastNanos = -1L;
        this.activeCaptureLastClientTick = -1;
        this.activeCaptureTailDelay = 0;
        this.staggeredDelayMode = this.delayMode;
        this.markQueueRenderDirty();
    }

    private void markQueueRenderDirty() {
        this.queueRenderRevision.incrementAndGet();
    }

    private boolean isActiveStaggerSendLocked() {
        return this.staggeredNetworkHandler != null && !this.staggeredQueue.isEmpty();
    }

    private int getElapsedForDelayModeLocked(PackUtilSharedState.DelayMode mode) {
        if (mode == PackUtilSharedState.DelayMode.MS) {
            if (this.flushStartNanos <= 0L) {
                return 0;
            }
            return (int)Math.max(0L, (System.nanoTime() - this.flushStartNanos) / 1000000L);
        }
        return Math.max(0, this.clientTickCounter - this.flushStartClientTick);
    }

    private int getQueueTailDelayLocked(List<PackUtilSharedState.QueuedPacket> queue) {
        int maxDelay = 0;
        if (queue == null || queue.isEmpty()) {
            return maxDelay;
        }
        var var3 = queue.iterator();
        while (var3.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var3.next();
            if (qp == null) continue;
            while (qp.isSent()) {
            }
            maxDelay = Math.max(maxDelay, qp.getDelay());
        }
        return maxDelay;
    }

    private void insertQueuedPacketSorted(List<PackUtilSharedState.QueuedPacket> queue, PackUtilSharedState.QueuedPacket packet) {
        if (queue == null || packet == null) {
            return;
        }
        int insertAt = queue.size();
        for (int i = 0; i < queue.size(); i++) {
            QueuedPacket existing = (PackUtilSharedState.QueuedPacket)queue.get(i);
            if (existing == null) {
            } else {
                int byDelay = Integer.compare(existing.getDelay(), packet.getDelay());
                if (byDelay <= 0) {
                    if (byDelay != 0) { /* goto @93; */ }
                }
                insertAt = i;
                /* goto @99; */
            }
        }
        queue.add(insertAt, packet);
    }

    private int computeActiveQueueDelayLocked() {
        int elapsed = this.getElapsedForDelayModeLocked(this.staggeredDelayMode);
        if (this.activeSendUsesExplicitDelays || this.captureMode) {
            return elapsed;
        }
        if (this.staggeredPacketSend) {
            int tailDelay = this.getQueueTailDelayLocked(this.staggeredQueue);
            return Math.max(elapsed, tailDelay) + this.staggeredSendDelay;
        }
        return elapsed;
    }

    private int computeActiveCapturedQueueDelayLocked() {
        if (this.staggeredDelayMode != PackUtilSharedState.DelayMode.MS) { /* goto L88; */ }
        long now = System.nanoTime();
        long reference = this.activeCaptureLastNanos > 0L ? this.activeCaptureLastNanos : this.flushStartNanos;
        int delta = reference > 0L ? (int)Math.max(0L, (now - reference) / 1000000L) : 0;
        this.activeCaptureLastNanos = now;
        this.activeCaptureLastClientTick = this.clientTickCounter;
        this.activeCaptureTailDelay = this.activeCaptureTailDelay + delta;
        return this.activeCaptureTailDelay;
        tick = this.clientTickCounter;
        int reference = this.activeCaptureLastClientTick >= 0 ? this.activeCaptureLastClientTick : this.flushStartClientTick;
        delta = Math.max(0, tick - reference);
        this.activeCaptureLastClientTick = tick;
        this.activeCaptureLastNanos = System.nanoTime();
        this.activeCaptureTailDelay = this.activeCaptureTailDelay + delta;
        return this.activeCaptureTailDelay;
    }

    public synchronized boolean restoreLastFlushedQueue() {
        if (this.lastFlushedQueue.isEmpty()) {
            return false;
        }
        this.delayedPackets.clear();
        this.resetCaptureTiming();
        if (!this.lastFlushedQueue.isEmpty()) {
            this.delayedPackets.addAll(this.rebuildQueueWithSequentialIds(this.lastFlushedQueue));
        }
        this.markQueueRenderDirty();
        return true;
    }

    public synchronized void enqueuePacket(class_2596<?> packet) {
        if (packet == null) { /* goto L235; */ }
        if (!this.isActiveStaggerSendLocked()) { /* goto L73; */ }
        int activeDelay = this.captureMode ? this.computeActiveCapturedQueueDelayLocked() : this.computeActiveQueueDelayLocked();
        QueuedPacket queuedPacket = new PackUtilSharedState.QueuedPacket(packet, activeDelay);
        this.insertQueuedPacketSorted(this.staggeredQueue, queuedPacket);
        this.insertQueuedPacketSorted(this.staggeredDisplayQueue, queuedPacket);
        this.staggeredTotal = this.staggeredTotal + 1;
        this.markQueueRenderDirty();
        return;
        delay = 0;
        if (this.captureMode) {
            if (this.delayedPackets.isEmpty()) {
                if (this.staggeredQueue.isEmpty()) {
                    this.resetCaptureTiming();
                }
            }
            if (this.delayMode == PackUtilSharedState.DelayMode.TICKS) {
                tick = this.clientTickCounter;
                if (this.lastCaptureClientTick < 0) {
                    this.lastCaptureClientTick = tick;
                    delay = 0;
                } else {
                    delay = tick - this.lastCaptureClientTick;
                }
            } else {
                now = System.nanoTime();
                if (this.lastCaptureNanos < 0L) {
                    this.lastCaptureNanos = now;
                    delay = 0;
                } else {
                    delay = (int)((now - this.lastCaptureNanos) / 1000000L);
                }
            }
        } else {
            if (this.staggeredPacketSend) {
                delay = this.delayedPackets.size() * this.staggeredSendDelay;
            }
        }
        this.delayedPackets.add(new PackUtilSharedState.QueuedPacket(packet, delay));
        this.markQueueRenderDirty();
        L235: ;
    }

    public void storeScreen(class_437 screen, class_1703 handler) {
        this.storedScreen = screen;
        this.storedScreenHandler = handler;
    }

    public class_437 getStoredScreen() {
        return this.storedScreen;
    }

    public class_1703 getStoredScreenHandler() {
        return this.storedScreenHandler;
    }

    public synchronized int flushDelayedPackets(class_634 networkHandler) {
        if (!this.staggeredQueue.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("§cAlready sending — wait for current queue to finish");
            return 0;
        }
        this.pendingQueueCompletionMessage = null;
        int count = this.delayedPackets.size();
        if (count == 0) {
            return 0;
        }
        this.resetCaptureTiming();
        PackUtilModule module = PackUtilModule.get();
        boolean hasDelays = this.delayedPackets.stream().anyMatch(PackUtilSharedState::lambda$flushDelayedPackets$1);
        if (module.shouldUseDirectFlush() && !hasDelays) {
            return this.flushDelayedPacketsDirect(networkHandler);
        }
        this.saveToHistory();
        if (networkHandler == null) { /* goto @365; */ }
        boolean shouldStagger = this.staggeredPacketSend || hasDelays;
        if (shouldStagger) {
            this.staggeredDisplayQueue.clear();
            this.staggeredQueue.addAll(this.delayedPackets);
            this.staggeredDisplayQueue.addAll(this.delayedPackets);
            this.staggeredNetworkHandler = networkHandler;
            this.staggeredTickCounter = 0;
            this.staggeredTotal = count;
            this.activeSendUsesExplicitDelays = hasDelays;
            this.staggeredDelayMode = this.delayMode;
            this.flushStartNanos = System.nanoTime();
            this.flushStartClientTick = this.clientTickCounter;
            this.activeCaptureLastNanos = this.flushStartNanos;
            this.activeCaptureLastClientTick = this.flushStartClientTick;
            this.activeCaptureTailDelay = this.getQueueTailDelayLocked(this.staggeredQueue);
        } else {
            this.isFlushing = true;
        }
        try {
            var var6 = this.delayedPackets.iterator();
            while (var6.hasNext()) {
                QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var6.next();
                if (PackUtilPacketRegistry.getC2SPackets().contains(qp.packet.getClass())) {
                    class_2596<?> packetToSend = PacketRegenerator.regenerate(qp.packet);
                    while (packetToSend == null) {
                    }
                    PackUtilPacketSender.sendPacket(packetToSend);
                } else {
                    YungLightAddon.LOG.warn("[PackUtil] Skipped sending invalid C2S packet during flush: {}", qp.packet.getClass().getName());
                }
            }
        }
        finally {
            this.isFlushing = false;
            throw var9;
        }
        PackUtilSharedState.QueuedPacket.resetIdCounter();
        L365: ;
        this.delayedPackets.clear();
        this.markQueueRenderDirty();
        return count;
    }

    private int flushDelayedPacketsDirect(class_634 networkHandler) {
        int count = this.delayedPackets.size();
        if (count == 0) {
            return 0;
        }
        this.saveToHistory();
        if (networkHandler != null) {
            this.isFlushing = true;
        }
        try {
            var var3 = this.delayedPackets.iterator();
            while (var3.hasNext()) {
                QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var3.next();
                if (PackUtilPacketRegistry.getC2SPackets().contains(qp.packet.getClass())) {
                    class_2596<?> packetToSend = PacketRegenerator.regenerate(qp.packet);
                    while (packetToSend == null) {
                    }
                    networkHandler.method_48296().method_10752(packetToSend, null);
                } else {
                    YungLightAddon.LOG.warn("[PackUtil] Skipped invalid C2S packet during bypass flush: {}", qp.packet.getClass().getName());
                }
            }
        }
        finally {
            this.isFlushing = false;
            throw var6;
        }
        this.delayedPackets.clear();
        this.checkAndResetIdCounter();
        this.markQueueRenderDirty();
        return count;
    }

    public synchronized void regenerateQueue() {
        if (this.delayedPackets.isEmpty()) {
            return;
        }
        List<PackUtilSharedState.QueuedPacket> newPackets = new ArrayList(this.delayedPackets.size());
        int skipped = 0;
        int deferredClickSlot = 0;
        var var4 = this.delayedPackets.iterator();
        while (var4.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var4.next();
            while (qp.packet instanceof class_2813) {
                newPackets.add(new PackUtilSharedState.QueuedPacket(qp.packet, qp.delay, qp.id));
                deferredClickSlot++;
            }
            class_2596<?> regenerated = PacketRegenerator.regenerate(qp.packet);
            if (regenerated != null) {
                newPackets.add(new PackUtilSharedState.QueuedPacket(regenerated, qp.delay, qp.id));
            } else {
                skipped++;
            }
        }
        this.delayedPackets.clear();
        this.delayedPackets.addAll(this.rebuildQueueWithSequentialIds(newPackets));
        this.markQueueRenderDirty();
        if (skipped > 0 || deferredClickSlot > 0) {
            YungLightAddon.LOG.warn("[PackUtil] Regenerated {} packets, skipped {}, deferred {} ClickSlot (IDs preserved).", newPackets.size() - deferredClickSlot, skipped, deferredClickSlot);
        } else {
            YungLightAddon.LOG.info("[PackUtil] Regenerated {} queued packets (IDs preserved).", newPackets.size());
        }
    }

    public synchronized void tickStaggeredSend() {
        if (this.staggeredQueue.isEmpty() || this.staggeredNetworkHandler == null) {
            return;
        }
        List<PackUtilSharedState.QueuedPacket> toRemove = new ArrayList();
        int total = this.staggeredQueue.iterator();
        while (total.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)total.next();
            if (this.staggeredDelayMode == PackUtilSharedState.DelayMode.MS) {
                long elapsedMs = (System.nanoTime() - this.flushStartNanos) / 1000000L;
                boolean shouldSend = elapsedMs >= (long)qp.getDelay() && !qp.isSent();
            } else {
                int elapsedTicks = this.clientTickCounter - this.flushStartClientTick;
                boolean shouldSend = elapsedTicks >= qp.getDelay() && !qp.isSent();
            }
            if (!shouldSend) continue;
            this.isFlushing = true;
            try {
                if (PackUtilPacketRegistry.getC2SPackets().contains(qp.packet.getClass())) {
                    packetToSend = PacketRegenerator.regenerate(qp.packet);
                    if (packetToSend == null) {
                        qp.markAsSent();
                        toRemove.add(qp);
                    }
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                this.isFlushing = false;
                /* goto @303; */
            }
            finally {
                this.isFlushing = false;
                throw var7;
            }
            try {
                this.staggeredNetworkHandler.method_48296().method_10752(packetToSend, null);
                qp.markAsSent();
                toRemove.add(qp);
                /* goto @270; */
                L235: ;
                YungLightAddon.LOG.warn("[PackUtil] Skipped sending invalid C2S packet: {}", qp.packet.getClass().getName());
                qp.markAsSent();
                toRemove.add(qp);
            }
            catch (Exception e) {
                e.printStackTrace();
                this.isFlushing = false;
                /* goto @303; */
            }
            var7 = null;
            this.isFlushing = false;
            throw var7;
        }
        this.staggeredQueue.removeAll(toRemove);
        if (!toRemove.isEmpty()) {
            this.markQueueRenderDirty();
        }
        this.staggeredTickCounter = this.staggeredTickCounter + 1;
        if (this.staggeredQueue.isEmpty()) {
            total = this.staggeredTotal;
            completionMessage = this.consumePendingQueueCompletionMessageLocked();
            this.stopStaggeredSendLocked();
            if (this.delayedPackets.isEmpty()) {
                this.resetCaptureTiming();
                PackUtilSharedState.QueuedPacket.resetIdCounter();
            }
            if (completionMessage == null || completionMessage.isBlank()) {
                completionMessage = "Finished sending " + total + " packets.";
            }
            PackUtilClientMessaging.sendPrefixed(completionMessage);
        }
    }

    public synchronized boolean isStaggering() {
        return !this.staggeredQueue.isEmpty() && this.staggeredNetworkHandler != null;
    }

    public synchronized void setPendingQueueCompletionMessage(String message) {
        if (message == null) { /* goto L12; */ }
        this.pendingQueueCompletionMessage = message.isBlank() ? null : message;
    }

    private String consumePendingQueueCompletionMessageLocked() {
        String message = this.pendingQueueCompletionMessage;
        this.pendingQueueCompletionMessage = null;
        return message;
    }

    public synchronized List<PackUtilSharedState.QueuedPacket> getStaggeredQueue() {
        return new ArrayList(this.staggeredQueue);
    }

    public synchronized boolean hasStaggeredPackets() {
        return !this.staggeredQueue.isEmpty();
    }

    public synchronized List<PackUtilSharedState.QueuedPacket> getStaggeredDisplayQueue() {
        return new ArrayList(this.staggeredDisplayQueue);
    }

    public synchronized int clearQueuedPackets() {
        if (!this.staggeredQueue.isEmpty()) {
            int count = this.staggeredQueue.size() + this.delayedPackets.size();
            List<PackUtilSharedState.QueuedPacket> combined = new ArrayList(this.staggeredQueue.size() + this.delayedPackets.size());
            combined.addAll(this.staggeredQueue);
            combined.addAll(this.delayedPackets);
            this.saveQueueToHistory(combined);
            this.pendingQueueCompletionMessage = null;
            this.stopStaggeredSendLocked();
            this.delayedPackets.clear();
            this.checkAndResetIdCounter();
            return count;
        }
        count = this.delayedPackets.size();
        this.clearDelayedPackets();
        return count;
    }

    public synchronized void removeQueuedPacket(PackUtilSharedState.QueuedPacket packet) {
        if (packet == null) {
            return;
        }
        this.staggeredDisplayQueue.remove(packet);
        boolean removedFromStaggered = this.staggeredQueue.remove(packet);
        if (removedFromStaggered) {
            if (this.staggeredQueue.isEmpty()) {
                this.stopStaggeredSendLocked();
            }
        }
        if (!removedFromStaggered) {
            this.delayedPackets.remove(packet);
            if (!this.delayedPackets.isEmpty()) {
                List<PackUtilSharedState.QueuedPacket> rebuilt = this.rebuildQueueWithSequentialIds(this.delayedPackets);
                this.delayedPackets.clear();
                this.delayedPackets.addAll(rebuilt);
            }
        }
        this.checkAndResetIdCounter();
        this.markQueueRenderDirty();
    }

    public synchronized void updatePacketDelay(PackUtilSharedState.QueuedPacket packet, int newDelay) {
        if (packet != null) {
            packet.setDelay(newDelay);
            this.markQueueRenderDirty();
        }
    }

    public synchronized void sortDelayedPacketsByDelayPreservingIds() {
        if (this.delayedPackets.size() < 2) {
            return;
        }
        List<PackUtilSharedState.QueuedPacket> ordered = new ArrayList(this.delayedPackets);
        ordered.sort(PackUtilSharedState::lambda$sortDelayedPacketsByDelayPreservingIds$2);
        this.delayedPackets.clear();
        this.delayedPackets.addAll(ordered);
        this.markQueueRenderDirty();
    }

    private List<PackUtilSharedState.QueuedPacket> rebuildQueueWithSequentialIds(List<PackUtilSharedState.QueuedPacket> source) {
        List<PackUtilSharedState.QueuedPacket> rebuilt = new ArrayList();
        if (source == null || source.isEmpty()) {
            return rebuilt;
        }
        List<PackUtilSharedState.QueuedPacket> ordered = new ArrayList();
        var var4 = source.iterator();
        while (var4.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var4.next();
            if (qp != null) {
                if (qp.packet == null) continue;
                ordered.add(qp);
            }
        }
        ordered.sort(PackUtilSharedState::lambda$rebuildQueueWithSequentialIds$3);
        PackUtilSharedState.QueuedPacket.resetIdCounter();
        var4 = ordered.iterator();
        while (var4.hasNext()) {
            qp = (PackUtilSharedState.QueuedPacket)var4.next();
            rebuilt.add(new PackUtilSharedState.QueuedPacket(qp.packet, qp.getDelay()));
        }
        return rebuilt;
    }

    public boolean isFlushing() {
        return this.isFlushing;
    }

    public void setFlushing(boolean value) {
        this.isFlushing = value;
    }

    public void clearStoredScreen() {
        this.storedScreen = null;
        this.storedScreenHandler = null;
    }

    public synchronized void resetAll() {
        this.sendGuiPackets = true;
        this.delayGuiPackets = false;
        this.allowSignEditing = true;
        this.allowBookUpdate = true;
        this.bypassResourcePack = false;
        this.resourcePackForceDeny = false;
        this.xCarryActive = false;
        this.xCarryForced = false;
        this.lastInteractedBlockPos = null;
        this.lastContainerTarget = null;
        this.delayedPackets.clear();
        this.staggeredQueue.clear();
        this.staggeredDisplayQueue.clear();
        this.staggeredNetworkHandler = null;
        this.staggeredTickCounter = 0;
        this.staggeredTotal = 0;
        PackUtilSharedState.QueuedPacket.resetIdCounter();
        this.activeSendUsesExplicitDelays = false;
        this.flushStartNanos = 0L;
        this.flushStartClientTick = 0;
        this.activeCaptureLastNanos = -1L;
        this.activeCaptureLastClientTick = -1;
        this.activeCaptureTailDelay = 0;
        this.staggeredDelayMode = PackUtilSharedState.DelayMode.TICKS;
        this.lastCaptureNanos = -1L;
        this.lastCaptureClientTick = -1;
        this.markQueueRenderDirty();
        this.storedScreen = null;
        this.storedScreenHandler = null;
        this.serverPluginScans.clear();
        this.serverInfoOverlayActiveTab = 0;
        this.serverInfoOverlayPluginScrollOffset = 0;
        this.serverInfoOverlaySelectedPlugin = "";
        this.serverInfoOverlayStateAddress = "";
        this.serverInfoOverlayProbeDelayMs = 50;
    }

    public boolean shouldEditSigns() {
        return this.allowSignEditing;
    }

    public void setAllowSignEditing(boolean value) {
        this.allowSignEditing = value;
    }

    public boolean shouldUpdateBook() {
        return this.allowBookUpdate;
    }

    public void setAllowBookUpdate(boolean value) {
        this.allowBookUpdate = value;
    }

    public boolean shouldBypassResourcePack() {
        return this.bypassResourcePack;
    }

    public void setBypassResourcePack(boolean value) {
        this.bypassResourcePack = value;
    }

    public boolean shouldForceDenyResourcePack() {
        return this.resourcePackForceDeny;
    }

    public void setResourcePackForceDeny(boolean value) {
        this.resourcePackForceDeny = value;
    }

    public boolean shouldUseCustomPackets() {
        return this.useCustomPackets;
    }

    public void setUseCustomPackets(boolean value) {
        this.useCustomPackets = value;
    }

    public Set<Class<? extends class_2596<?>>> getC2SPackets() {
        return this.c2sPackets;
    }

    public void setC2SPackets(Set<Class<? extends class_2596<?>>> packets) {
        this.c2sPackets = new HashSet(packets);
    }

    public Set<Class<? extends class_2596<?>>> getS2CPackets() {
        return this.s2cPackets;
    }

    public void setS2CPackets(Set<Class<? extends class_2596<?>>> packets) {
        this.s2cPackets = new HashSet(packets);
    }

    public boolean isStaggeredPacketSend() {
        return this.staggeredPacketSend;
    }

    public void setStaggeredPacketSend(boolean value) {
        this.staggeredPacketSend = value;
    }

    public int getStaggeredSendDelay() {
        return this.staggeredSendDelay;
    }

    public void setStaggeredSendDelay(int delay) {
        this.staggeredSendDelay = Math.max(1, Math.min(40, delay));
    }

    public PackUtilSharedState.DelayMode getDelayMode() {
        return this.delayMode;
    }

    public synchronized PackUtilSharedState.DelayMode getQueueDisplayDelayMode() {
        return this.isActiveStaggerSendLocked() ? this.staggeredDelayMode : this.delayMode;
    }

    public void setDelayMode(PackUtilSharedState.DelayMode mode) {
        this.delayMode = mode;
    }

    public void toggleDelayMode() {
        this.delayMode = this.delayMode == PackUtilSharedState.DelayMode.TICKS ? PackUtilSharedState.DelayMode.MS : PackUtilSharedState.DelayMode.TICKS;
    }

    public boolean isFabricatorOverlayVisible() {
        return this.fabricatorOverlayVisible;
    }

    public void setFabricatorOverlayVisible(boolean visible) {
        this.fabricatorOverlayVisible = visible;
    }

    public int getFabricatorOverlayX() {
        return this.fabricatorOverlayX;
    }

    public void setFabricatorOverlayX(int x) {
        this.fabricatorOverlayX = x;
    }

    public int getFabricatorOverlayY() {
        return this.fabricatorOverlayY;
    }

    public void setFabricatorOverlayY(int y) {
        this.fabricatorOverlayY = y;
    }

    public String getFabricatorSlotValue() {
        return this.fabricatorSlotValue;
    }

    public void setFabricatorSlotValue(String value) {
        this.fabricatorSlotValue = value != null ? value : "0";
    }

    public String getFabricatorItemNameValue() {
        return this.fabricatorItemNameValue;
    }

    public void setFabricatorItemNameValue(String value) {
        this.fabricatorItemNameValue = value != null ? value : "";
    }

    public String getFabricatorTimesValue() {
        return this.fabricatorTimesValue;
    }

    public void setFabricatorTimesValue(String value) {
        this.fabricatorTimesValue = value != null ? value : "1";
    }

    public int getFabricatorActionIndex() {
        return this.fabricatorActionIndex;
    }

    public void setFabricatorActionIndex(int index) {
        this.fabricatorActionIndex = Math.max(0, index);
    }

    public boolean isFabricatorCraftUseMaxAmount() {
        return this.fabricatorCraftUseMaxAmount;
    }

    public void setFabricatorCraftUseMaxAmount(boolean useMaxAmount) {
        this.fabricatorCraftUseMaxAmount = useMaxAmount;
    }

    public int getFabricatorButtonIndex() {
        return this.fabricatorButtonIndex;
    }

    public void setFabricatorButtonIndex(int index) {
        this.fabricatorButtonIndex = Math.max(0, index);
    }

    public boolean isFabricatorDropWholeStack() {
        return this.fabricatorDropWholeStack;
    }

    public void setFabricatorDropWholeStack(boolean value) {
        this.fabricatorDropWholeStack = value;
    }

    public String getFabricatorCraftSearchValue() {
        return this.fabricatorCraftSearchValue;
    }

    public void setFabricatorCraftSearchValue(String value) {
        this.fabricatorCraftSearchValue = value != null ? value : "";
    }

    public int getFabricatorCraftSelectedRecipeId() {
        return this.fabricatorCraftSelectedRecipeId;
    }

    public void setFabricatorCraftSelectedRecipeId(int recipeId) {
        this.fabricatorCraftSelectedRecipeId = recipeId;
    }

    public String getFabricatorCraftSelectedRecipeKey() {
        return this.fabricatorCraftSelectedRecipeKey;
    }

    public void setFabricatorCraftSelectedRecipeKey(String recipeKey) {
        this.fabricatorCraftSelectedRecipeKey = recipeKey != null ? recipeKey : "";
    }

    public int getFabricatorCraftScrollOffset() {
        return this.fabricatorCraftScrollOffset;
    }

    public void setFabricatorCraftScrollOffset(int offset) {
        this.fabricatorCraftScrollOffset = Math.max(0, offset);
    }

    public synchronized List<CraftAction.CraftEntry> getFabricatorCraftPlanEntries() {
        List<CraftAction.CraftEntry> copies = new ArrayList(this.fabricatorCraftPlanEntries.size());
        var var2 = this.fabricatorCraftPlanEntries.iterator();
        while (var2.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var2.next();
            if (entry == null) continue;
            copies.add(entry.copy());
        }
        return copies;
    }

    public synchronized void setFabricatorCraftPlanEntries(List<CraftAction.CraftEntry> entries) {
        this.fabricatorCraftPlanEntries.clear();
        if (entries == null) {
            return;
        }
        var var2 = entries.iterator();
        while (var2.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var2.next();
            if (entry == null) continue;
            this.fabricatorCraftPlanEntries.add(entry.copy());
        }
    }

    public int getFabricatorCraftPlanSelectedIndex() {
        return this.fabricatorCraftPlanSelectedIndex;
    }

    public void setFabricatorCraftPlanSelectedIndex(int index) {
        this.fabricatorCraftPlanSelectedIndex = index;
    }

    public int getFabricatorCraftPlanScrollOffset() {
        return this.fabricatorCraftPlanScrollOffset;
    }

    public void setFabricatorCraftPlanScrollOffset(int offset) {
        this.fabricatorCraftPlanScrollOffset = Math.max(0, offset);
    }

    public boolean isLanSyncOverlayVisible() {
        return this.lanSyncOverlayVisible;
    }

    public void setLanSyncOverlayVisible(boolean visible) {
        this.lanSyncOverlayVisible = visible;
    }

    public int getLanSyncOverlayX() {
        return this.lanSyncOverlayX;
    }

    public void setLanSyncOverlayX(int x) {
        this.lanSyncOverlayX = x;
    }

    public int getLanSyncOverlayY() {
        return this.lanSyncOverlayY;
    }

    public void setLanSyncOverlayY(int y) {
        this.lanSyncOverlayY = y;
    }

    public int getLanSyncOverlayActiveTab() {
        return this.lanSyncOverlayActiveTab;
    }

    public void setLanSyncOverlayActiveTab(int activeTab) {
        this.lanSyncOverlayActiveTab = Math.max(0, activeTab);
    }

    public int getLanSyncOverlayScrollOffset() {
        return this.lanSyncOverlayScrollOffset;
    }

    public void setLanSyncOverlayScrollOffset(int scrollOffset) {
        this.lanSyncOverlayScrollOffset = Math.max(0, scrollOffset);
    }

    public boolean isLanSyncOverlayPerUserMode() {
        return this.lanSyncOverlayPerUserMode;
    }

    public void setLanSyncOverlayPerUserMode(boolean perUserMode) {
        this.lanSyncOverlayPerUserMode = perUserMode;
    }

    public String getLanSyncOverlaySelectedMacroName() {
        return this.lanSyncOverlaySelectedMacroName;
    }

    public void setLanSyncOverlaySelectedMacroName(String selectedMacroName) {
        this.lanSyncOverlaySelectedMacroName = selectedMacroName == null ? "" : selectedMacroName;
    }

    public String getLanSyncOverlayExpandedExecutePeer() {
        return this.lanSyncOverlayExpandedExecutePeer;
    }

    public void setLanSyncOverlayExpandedExecutePeer(String expandedExecutePeer) {
        this.lanSyncOverlayExpandedExecutePeer = expandedExecutePeer == null ? "" : expandedExecutePeer;
    }

    public String getLanSyncOverlaySelectedPeer() {
        return this.lanSyncOverlaySelectedPeer;
    }

    public void setLanSyncOverlaySelectedPeer(String selectedPeer) {
        this.lanSyncOverlaySelectedPeer = selectedPeer == null ? "" : selectedPeer;
    }

    public boolean isMacroListOverlayVisible() {
        return this.macroListOverlayVisible;
    }

    public void setMacroListOverlayVisible(boolean visible) {
        this.macroListOverlayVisible = visible;
    }

    public int getMacroListOverlayX() {
        return this.macroListOverlayX;
    }

    public void setMacroListOverlayX(int x) {
        this.macroListOverlayX = x;
    }

    public int getMacroListOverlayY() {
        return this.macroListOverlayY;
    }

    public void setMacroListOverlayY(int y) {
        this.macroListOverlayY = y;
    }

    public int getMacroListOverlayScrollOffset() {
        return this.macroListOverlayScrollOffset;
    }

    public void setMacroListOverlayScrollOffset(int scrollOffset) {
        this.macroListOverlayScrollOffset = Math.max(0, scrollOffset);
    }

    public String getMacroListOverlaySearch() {
        return this.macroListOverlaySearch;
    }

    public void setMacroListOverlaySearch(String search) {
        this.macroListOverlaySearch = search == null ? "" : search;
    }

    public boolean isQueueEditorOverlayVisible() {
        return this.queueEditorOverlayVisible;
    }

    public void setQueueEditorOverlayVisible(boolean visible) {
        this.queueEditorOverlayVisible = visible;
    }

    public int getQueueEditorOverlayX() {
        return this.queueEditorOverlayX;
    }

    public void setQueueEditorOverlayX(int x) {
        this.queueEditorOverlayX = x;
    }

    public int getQueueEditorOverlayY() {
        return this.queueEditorOverlayY;
    }

    public void setQueueEditorOverlayY(int y) {
        this.queueEditorOverlayY = y;
    }

    public int getServerInfoOverlayActiveTab() {
        return this.serverInfoOverlayActiveTab;
    }

    public void setServerInfoOverlayActiveTab(int tab) {
        this.serverInfoOverlayActiveTab = Math.max(0, tab);
    }

    public int getServerInfoOverlayPluginScrollOffset() {
        return this.serverInfoOverlayPluginScrollOffset;
    }

    public void setServerInfoOverlayPluginScrollOffset(int offset) {
        this.serverInfoOverlayPluginScrollOffset = Math.max(0, offset);
    }

    public String getServerInfoOverlaySelectedPlugin() {
        return this.serverInfoOverlaySelectedPlugin;
    }

    public void setServerInfoOverlaySelectedPlugin(String plugin) {
        this.serverInfoOverlaySelectedPlugin = plugin == null ? "" : plugin;
    }

    public String getServerInfoOverlayStateAddress() {
        return this.serverInfoOverlayStateAddress;
    }

    public void setServerInfoOverlayStateAddress(String address) {
        this.serverInfoOverlayStateAddress = PackUtilSharedState.normalizeServerAddress(address);
    }

    public int getServerInfoOverlayProbeDelayMs() {
        return this.serverInfoOverlayProbeDelayMs;
    }

    public void setServerInfoOverlayProbeDelayMs(int delayMs) {
        this.serverInfoOverlayProbeDelayMs = Math.max(10, Math.min(500, delayMs));
    }

    public int getServerInfoOverlayInfoWidth() {
        return this.serverInfoOverlayInfoWidth;
    }

    public void setServerInfoOverlayInfoWidth(int width) {
        this.serverInfoOverlayInfoWidth = Math.max(252, width);
    }

    public int getServerInfoOverlayInfoHeight() {
        return this.serverInfoOverlayInfoHeight;
    }

    public void setServerInfoOverlayInfoHeight(int height) {
        this.serverInfoOverlayInfoHeight = Math.max(258, height);
    }

    public int getServerInfoOverlayPluginWidth() {
        return this.serverInfoOverlayPluginWidth;
    }

    public void setServerInfoOverlayPluginWidth(int width) {
        this.serverInfoOverlayPluginWidth = Math.max(280, width);
    }

    public int getServerInfoOverlayPluginHeight() {
        return this.serverInfoOverlayPluginHeight;
    }

    public void setServerInfoOverlayPluginHeight(int height) {
        this.serverInfoOverlayPluginHeight = Math.max(280, height);
    }

    public void startGBreakCapture(Runnable onCaptureComplete) {
        this.gbreakCaptureMode = true;
        this.gbreakPacketCount = 0;
        this.gbreakCapturedPackets.clear();
        this.gbreakCallback = onCaptureComplete;
    }

    public boolean isGBreakCapturing() {
        return this.gbreakCaptureMode;
    }

    public void onGBreakPacket(class_2596<?> packet) {
        if (!this.gbreakCaptureMode) {
            return;
        }
        this.gbreakPacketCount = this.gbreakPacketCount + 1;
        YungLightAddon.LOG.info("[GBreak] Packet #{}: {}", this.gbreakPacketCount, packet.getClass().getSimpleName());
        if (this.gbreakPacketCount == 2) {
            this.gbreakCapturedPackets.clear();
            this.gbreakCapturedPackets.add(new PackUtilSharedState.QueuedPacket(packet, 0));
            this.finishGBreakCapture();
        }
    }

    public List<PackUtilSharedState.QueuedPacket> getGBreakCapturedPackets() {
        return new ArrayList(this.gbreakCapturedPackets);
    }

    private void finishGBreakCapture() {
        this.gbreakCaptureMode = false;
        if (this.gbreakCallback != null) {
            this.gbreakCallback.run();
            this.gbreakCallback = null;
        }
    }

    public void cancelGBreakCapture() {
        this.gbreakCaptureMode = false;
        this.gbreakPacketCount = 0;
        this.gbreakCapturedPackets.clear();
        this.gbreakCallback = null;
    }

    public void setSuppressNextClosePacket(boolean v) {
        this.suppressNextClosePacket = v;
    }

    public boolean consumeSuppressNextClosePacket() {
        boolean v = this.suppressNextClosePacket;
        this.suppressNextClosePacket = false;
        return v;
    }

    public void setBlockCaptureCallback(Consumer<class_2338> cb) {
        this.blockCaptureCallback = cb;
    }

    public boolean consumeBlockCaptureCallback(class_2338 pos) {
        Consumer<class_2338> cb = this.blockCaptureCallback;
        if (cb != null) {
            this.blockCaptureCallback = null;
            cb.accept(pos);
            return true;
        }
        return false;
    }

    public boolean hasBlockCaptureCallback() {
        return this.blockCaptureCallback != null;
    }

    public void setAttackCaptureCallback(Runnable cb) {
        this.attackCaptureCallback = cb;
    }

    public boolean consumeAttackCaptureCallback() {
        Runnable cb = this.attackCaptureCallback;
        if (cb != null) {
            this.attackCaptureCallback = null;
            cb.run();
            return true;
        }
        return false;
    }

    public boolean hasAttackCaptureCallback() {
        return this.attackCaptureCallback != null;
    }

    public void setCaptureCancelCallback(Runnable cb) {
        this.captureCancelCallback = cb;
    }

    public boolean consumeCaptureCancelCallback() {
        Runnable cb = this.captureCancelCallback;
        if (cb != null) {
            this.captureCancelCallback = null;
            cb.run();
            return true;
        }
        return false;
    }

    public boolean hasCaptureCancelCallback() {
        return this.captureCancelCallback != null;
    }

    public void setEntityCaptureCallback(Consumer<String> cb) {
        this.entityCaptureCallback = cb;
    }

    public boolean consumeEntityCaptureCallback(String payload) {
        Consumer<String> cb = this.entityCaptureCallback;
        if (cb != null) {
            this.entityCaptureCallback = null;
            cb.accept(payload);
            return true;
        }
        return false;
    }

    public boolean hasEntityCaptureCallback() {
        return this.entityCaptureCallback != null;
    }

    public void setEntityCaptureSpecific(boolean v) {
        this.entityCaptureSpecific = v;
    }

    public boolean isEntityCaptureSpecific() {
        return this.entityCaptureSpecific;
    }

    public boolean isCaptureMode() {
        return this.captureMode;
    }

    public void setCaptureMode(boolean v) {
        this.captureMode = v;
        if (v) {
            this.lastCaptureNanos = -1L;
            this.lastCaptureClientTick = -1;
        }
    }

    public void onServerTimeSyncReceived() {
        long now = System.currentTimeMillis();
        if (this.lastTimeSyncMs > 0L) {
            long wallDeltaMs = now - this.lastTimeSyncMs;
            if (wallDeltaMs > 0L) {
                double measured = (double)wallDeltaMs / 20;
                measured = Math.max(50, Math.min(200, measured));
                this.serverMsPerTick = this.serverMsPerTick * 0.3 + measured * 0.7;
            }
        }
        this.lastTimeSyncMs = now;
    }

    public double getServerMsPerTick() {
        return this.serverMsPerTick;
    }

    public double getEstimatedTps() {
        if (this.lastTimeSyncMs <= 0L) {
            return -1;
        }
        return 1000 / this.serverMsPerTick;
    }

    public void onClientTickStart() {
        this.clientTickCounter = this.clientTickCounter + 1;
    }
}
