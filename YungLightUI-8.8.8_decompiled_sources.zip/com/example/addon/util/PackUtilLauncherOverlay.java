/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiAccordionSection;
import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiColumn;
import com.example.addon.gui.packui.PackUiCompactRow;
import com.example.addon.gui.packui.PackUiIconLabel;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiMetricLabel;
import com.example.addon.gui.packui.PackUiPanelNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSpacer;
import com.example.addon.gui.packui.PackUiSurface;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.mixin.accessor.PackUtilHandledScreenAccessor;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilCustomFilterOverlay;
import com.example.addon.util.PackUtilFabricatorOverlay;
import com.example.addon.util.PackUtilGuiClipboardUtil;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilKeybindOverlay;
import com.example.addon.util.PackUtilLANSyncOverlay;
import com.example.addon.util.PackUtilMacroListOverlay;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilQueueEditorOverlay;
import com.example.addon.util.PackUtilServerInfoOverlay;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2815;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class PackUtilLauncherOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final int DEFAULT_X = 0;
    private static final int DEFAULT_Y = 0;
    private static final int PANEL_PAD = 0;
    private static final int SECTION_PAD = 4;
    private static final int SECTION_GAP = 3;
    private static final int ROW_GAP = 2;
    private static final int BUTTON_HEIGHT = 20;
    private static final int CHAT_HEIGHT = 20;
    private static final int CHAT_MIN_WIDTH = 136;
    private static final int TEXT_PAD = 8;
    private static final int ICON_SIZE = 14;
    private static final int ICON_GAP = 4;
    private static final int LABEL_ICON_SIZE = 13;
    private static final int MIN_PAIR_WIDTH = 58;
    private static final int MIN_PANEL_WIDTH = 164;
    private static final float HEADER_CLICK_DRAG_THRESHOLD = 3f;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiPanelNode panelNode = new PackUiPanelNode();
    private final PackUiSurface surface = new PackUiSurface(this.theme, this.panelNode);
    private final PackUtilMacroListOverlay macroListOverlay;
    private final PackUtilFabricatorOverlay fabricatorOverlay;
    private final PackUtilLANSyncOverlay lanSyncOverlay;
    private final PackUtilQueueEditorOverlay queueEditorOverlay;
    private final PackUtilPacketLoggerOverlay packetLoggerOverlay;
    private final PackUtilCustomFilterOverlay customFilterOverlay;
    private Runnable closeWithoutPacketAction;
    private PackUtilKeybindOverlay keybindOverlay;
    private PackUtilServerInfoOverlay serverInfoOverlay;
    private PackUiButton sendButton;
    private PackUiButton delayButton;
    private PackUiTextField chatField;
    private PackUiMetricLabel revMetric;
    private PackUiMetricLabel syncMetric;
    private PackUiMetricLabel slotMetric;
    private PackUiAccordionSection mainMenuSection;
    private int panelX = 0;
    private int panelY = 0;
    private int panelWidth = 164;
    private int panelHeight = 220;
    private boolean visible = true;
    private boolean dragging = false;
    private float dragOffsetX;
    private float dragOffsetY;
    private float pressStartUiX;
    private float pressStartUiY;
    private int pressStartPanelX;
    private int pressStartPanelY;
    private boolean dragMoved = false;

    public PackUtilLauncherOverlay(PackUtilMacroListOverlay macroListOverlay, PackUtilFabricatorOverlay fabricatorOverlay, PackUtilLANSyncOverlay lanSyncOverlay, PackUtilQueueEditorOverlay queueEditorOverlay, PackUtilPacketLoggerOverlay packetLoggerOverlay, PackUtilCustomFilterOverlay customFilterOverlay) {
        this.macroListOverlay = macroListOverlay;
        this.fabricatorOverlay = fabricatorOverlay;
        this.lanSyncOverlay = lanSyncOverlay;
        this.queueEditorOverlay = queueEditorOverlay;
        this.packetLoggerOverlay = packetLoggerOverlay;
        this.customFilterOverlay = customFilterOverlay;
        this.buildUi();
        this.restoreLayout();
        if (this.mainMenuSection != null) {
            this.mainMenuSection.syncExpanded(this.mainMenuSection.isExpanded());
        }
    }

    public void setCloseWithoutPacketAction(Runnable action) {
        this.closeWithoutPacketAction = action;
        this.buildUi();
    }

    public void setKeybindOverlay(PackUtilKeybindOverlay overlay) {
        this.keybindOverlay = overlay;
    }

    public void setServerInfoOverlay(PackUtilServerInfoOverlay overlay) {
        this.serverInfoOverlay = overlay;
    }

    private void buildUi() {
        this.panelNode.setPadding(PackUiInsets.all(0)).setDrawBorder(false).setDrawFill(false);
        this.panelNode.content().clearChildren();
        this.panelNode.content().setPadding(PackUiInsets.NONE).setGap(0);
        this.mainMenuSection = new PackUiAccordionSection("MAIN MENU").setHeaderHeight(this.sectionHeaderHeight()).setContentTopGap(this.sectionContentTopGap()).setExpanded(true);
        this.mainMenuSection.content().setPadding(new PackUiInsets(0, this.sectionPadding(), 0, this.sectionPadding())).setGap(this.rowGap());
        this.panelNode.content().add(this.mainMenuSection);
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Macros", PackUiAssets.ICON_MACROS, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$0).setGrowX(true), this.actionButton("Fabricator", PackUiAssets.ICON_FABRICATOR, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$1).setGrowX(true));
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("LAN Sync", PackUiAssets.ICON_LANSYNC, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$2).setGrowX(true), this.actionButton("Queue", PackUiAssets.ICON_PACKET_Q_EDITOR, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$3).setGrowX(true));
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Logger", PackUiAssets.ICON_PACKET_LOGGER, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$4).setGrowX(true), this.actionButton("Filter", PackUiAssets.ICON_FILTER, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$5).setGrowX(true));
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Server Info", PackUiAssets.ICON_SERVER_INFO, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$6).setGrowX(true), this.actionButton("Settings", PackUiAssets.ICON_KEYBINDS, PackUiButton.Variant.SECONDARY, this::lambda$buildUi$7).setGrowX(true));
        this.addSubCategory("PACKET", PackUiAssets.ICON_PACKET_CATEGORY);
        this.sendButton = this.actionButton("Send Off", null, PackUiButton.Variant.SECONDARY, this::toggleSendPackets).setGrowX(true);
        this.delayButton = this.actionButton("Delay Off", null, PackUiButton.Variant.SECONDARY, this::toggleDelayPackets).setGrowX(true);
        this.addPairRow(this.mainMenuSection.content(), this.sendButton, this.delayButton);
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Flush", null, PackUiButton.Variant.SECONDARY, this::flushQueue).setGrowX(true), this.actionButton("Clear", null, PackUiButton.Variant.DANGER, this::clearQueue).setGrowX(true));
        this.addSubCategory("SCREEN", PackUiAssets.ICON_SCREEN_CATEGORY);
        if (this.closeWithoutPacketAction != null) {
            this.addFullButton(this.mainMenuSection.content(), "Close w/o PKT", null, this.closeWithoutPacketAction);
        }
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Close", null, PackUiButton.Variant.SECONDARY, PackUtilLauncherOverlay::lambda$buildUi$8).setGrowX(true), this.actionButton("De-sync", null, PackUiButton.Variant.DANGER, this::sendDesync).setGrowX(true));
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Save", null, PackUiButton.Variant.SECONDARY, this::saveGui).setGrowX(true), this.actionButton("Load", null, PackUiButton.Variant.SECONDARY, this::loadGui).setGrowX(true));
        this.addPairRow(this.mainMenuSection.content(), this.actionButton("Title", null, PackUiButton.Variant.SECONDARY, PackUtilGuiClipboardUtil::copyGuiTitleJson).setGrowX(true), this.actionButton("Disc+Send", null, PackUiButton.Variant.DANGER, this::disconnectAndSend).setGrowX(true));
        this.addSubCategory("CHAT", PackUiAssets.ICON_CHAT_CATEGORY);
        this.chatField = new PackUiTextField().setGrowX(true).setFieldHeight(this.chatHeight()).setPreferredWidth((float)this.chatMinWidth()).setMinWidth((float)this.chatMinWidth()).setHorizontalPadding(6).setPlaceholder("Type message or /command...").setOnSubmit(this::submitChat);
        this.mainMenuSection.content().add(this.chatField);
        PackUiCompactRow syncRow = new PackUiCompactRow().setGap(this.syncRowGap()).setPadding(PackUiInsets.NONE).setUnderlineOnHover(false);
        syncRow.setGrowX(true);
        this.revMetric = (PackUiMetricLabel)syncRow.add(new PackUiMetricLabel("Rev: ", "--").setKeyColor(-4743522).setValueColor(-46518).setGrowX(true));
        this.syncMetric = (PackUiMetricLabel)syncRow.add(new PackUiMetricLabel("SyncID: ", "--").setKeyColor(-4743522).setValueColor(-791321).setGrowX(true));
        this.slotMetric = (PackUiMetricLabel)syncRow.add(new PackUiMetricLabel("Slot: ", "--").setKeyColor(-4743522).setValueColor(-7350273).setGrowX(true));
        this.mainMenuSection.content().add(syncRow);
    }

    private void addSubCategory(String label, class_2960 icon) {
        if (!this.mainMenuSection.content().children().isEmpty()) {
            this.mainMenuSection.content().add(new PackUiSpacer(0f, (float)this.sectionGap()));
        }
        this.mainMenuSection.content().add(new PackUiIconLabel(label, icon).setTone(PackUiTone.LABEL).setIconSize(this.labelIconSize()));
    }

    private PackUiButton addFullButton(PackUiColumn parent, String label, class_2960 icon, Runnable action) {
        PackUiButton button = this.actionButton(label, icon, PackUiButton.Variant.SECONDARY, action).setGrowX(true);
        parent.add(button);
        return button;
    }

    private void addPairRow(PackUiColumn parent, PackUiButton left, PackUiButton right) {
        PackUiCompactRow row = new PackUiCompactRow().setGap(this.rowGap()).setPadding(PackUiInsets.NONE).setUnderlineOnHover(false);
        row.add(left);
        row.add(right);
        row.setGrowX(true);
        parent.add(row);
    }

    private PackUiButton actionButton(String label, class_2960 icon, PackUiButton.Variant variant, Runnable action) {
        PackUiButton button = new PackUiButton(label, variant, action).setGrowX(false).setButtonHeight(this.buttonHeight()).setHorizontalPadding(this.buttonPadding()).setMinWidth((float)this.requiredButtonWidth(label, icon)).setTextYOffset(0);
        if (icon != null) {
            button.setLeadingIcon(icon).setContentAlignment(PackUiButton.ContentAlignment.START).setIconSize(this.buttonIconSize()).setIconGap(this.buttonIconGap());
        }
        return button;
    }

    public String getOverlayId() {
        return "packutil-launcher";
    }

    public int getMinWidth() {
        return this.computePanelWidth();
    }

    public int getMinHeight() {
        return this.minimumPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, !this.mainMenuSection.isExpanded());
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToViewport(bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.visible = clamped.visible;
        if (this.mainMenuSection == null) { /* goto L78; */ }
        this.mainMenuSection.syncExpanded(!clamped.collapsed);
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        if (this.sendButton == null) { /* goto L76; */ }
        boolean sending = shared.shouldSendGuiPackets();
        this.sendButton.setText("Send " + sending ? "On" : "Off");
        this.sendButton.setVariant(sending ? PackUiButton.Variant.SUCCESS : PackUiButton.Variant.SECONDARY);
        L76: ;
        if (this.delayButton == null) { /* goto L139; */ }
        delaying = shared.shouldDelayGuiPackets();
        this.delayButton.setText("Delay " + delaying ? "On" : "Off");
        this.delayButton.setVariant(delaying ? PackUiButton.Variant.PRIMARY : PackUiButton.Variant.SECONDARY);
        L139: ;
        this.updateSyncMetrics();
        this.panelWidth = this.computePanelWidth();
        viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX((double)mouseX);
        float uiMouseY = viewport.toUiY((double)mouseY);
        PackUiRenderContext metrics = new PackUiRenderContext(context, MC.field_1772, viewport, this.theme, uiMouseX, uiMouseY, delta);
        this.panelHeight = Math.max(this.getMinHeight(), Math.round(this.panelNode.preferredHeight(metrics, (float)this.panelWidth)));
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.mainMenuSection != null && !this.mainMenuSection.isExpanded()));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.panelNode.setActive(true);
        this.panelNode.setBounds((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight);
        this.surface.render(context, mouseX, mouseY, delta);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        this.dragging = true;
        if (button == 0 && this.isOverMainMenuHeader(uiMouseX, uiMouseY) && this.mainMenuSection != null) {
            this.dragMoved = false;
            this.dragOffsetX = uiMouseX - (float)this.panelX;
            this.dragOffsetY = uiMouseY - (float)this.panelY;
            this.pressStartUiX = uiMouseX;
            this.pressStartUiY = uiMouseY;
            this.pressStartPanelX = this.panelX;
            this.pressStartPanelY = this.panelY;
            return true;
        }
        if (this.surface.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (this.dragging) {
            this.dragging = false;
            this.saveLayout();
            return true;
        }
        return this.surface.mouseReleased(mouseX, mouseY, button);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!this.dragging) { /* goto L189; */ }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(Math.round(uiMouseX - this.dragOffsetX), Math.round(uiMouseY - this.dragOffsetY), this.panelWidth, this.panelHeight, this.visible, this.mainMenuSection != null && !this.mainMenuSection.isExpanded()));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        if (this.dragMoved) { /* goto L179; */ }
        if (Math.abs(uiMouseX - this.pressStartUiX) >= 3f) { /* goto L179; */ }
        if (Math.abs(uiMouseY - this.pressStartUiY) >= 3f) { /* goto L179; */ }
        if (this.panelX != this.pressStartPanelX) { /* goto L179; */ }
        this.dragMoved = this.panelY != this.pressStartPanelY;
        return true;
        return this.surface.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return this.surface.mouseScrolled(mouseX, mouseY, amount);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return this.surface.keyPressed(keyCode, scanCode, modifiers);
    }

    public boolean charTyped(char chr, int modifiers) {
        return this.surface.charTyped(chr, modifiers);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (!visible) {
            this.surface.clearFocusedTextInputs();
            this.dragging = false;
            this.dragMoved = false;
        } else {
            if (this.mainMenuSection != null) {
                this.mainMenuSection.syncExpanded(this.mainMenuSection.isExpanded());
            }
        }
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiX = viewport.toUiX(mouseX);
        float uiY = viewport.toUiY(mouseY);
        return uiX >= (float)this.panelX && uiX < (float)(this.panelX + this.panelWidth) && uiY >= (float)this.panelY && uiY < (float)(this.panelY + this.panelHeight);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        return this.isOverMainMenuHeader(viewport.toUiX(mouseX), viewport.toUiY(mouseY));
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean isCollapsed() {
        return this.mainMenuSection != null && !this.mainMenuSection.isExpanded();
    }

    public void setCollapsed(boolean collapsed) {
        if (this.mainMenuSection == null) { /* goto L24; */ }
        this.mainMenuSection.syncExpanded(!collapsed);
    }

    public boolean hasTextFieldFocused() {
        return this.surface.hasFocusedTextInput();
    }

    public void clearTextFieldFocus() {
        this.surface.clearFocusedTextInputs();
    }

    private boolean isOverMainMenuHeader(float uiMouseX, float uiMouseY) {
        return this.mainMenuSection != null && uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.panelWidth) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.sectionHeaderHeight());
    }

    private PackUtilWindowLayout clampToViewport(PackUtilWindowLayout bounds) {
        PackUiViewport viewport = this.surface.viewport();
        int width = Math.max(this.getMinWidth(), Math.min(bounds.width, Math.round(viewport.uiWidth())));
        int minHeight = bounds.collapsed ? this.sectionHeaderHeight() : this.getMinHeight();
        int height = Math.max(minHeight, Math.min(bounds.height, Math.round(viewport.uiHeight())));
        int x = Math.max(0, Math.min(bounds.x, Math.max(0, Math.round(viewport.uiWidth()) - width)));
        int y = Math.max(0, Math.min(bounds.y, Math.max(0, Math.round(viewport.uiHeight()) - this.sectionHeaderHeight())));
        return new PackUtilWindowLayout(x, y, width, height, bounds.visible, bounds.collapsed);
    }

    private int computePanelWidth() {
        if (MC.field_1772 == null) {
            return this.minPanelWidth();
        }
        int pairWidth = this.minPairWidth();
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Macros", PackUiAssets.ICON_MACROS));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Fabricator", PackUiAssets.ICON_FABRICATOR));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("LAN Sync", PackUiAssets.ICON_LANSYNC));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Queue", PackUiAssets.ICON_PACKET_Q_EDITOR));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Logger", PackUiAssets.ICON_PACKET_LOGGER));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Filter", PackUiAssets.ICON_FILTER));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Server Info", PackUiAssets.ICON_SERVER_INFO));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Settings", PackUiAssets.ICON_KEYBINDS));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Send Off", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Delay Off", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Flush", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Clear", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Close", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("De-sync", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Save", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Load", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Title", null));
        pairWidth = Math.max(pairWidth, this.requiredButtonWidth("Disc+Send", null));
        int fullWidth = this.closeWithoutPacketAction != null ? this.requiredButtonWidth("Close w/o PKT", null) : 0;
        int chatWidth = Math.max(this.chatMinWidth(), this.requiredTextFieldWidth("Type message or /command..."));
        int headerWidth = PackUiText.width(MC.field_1772, "MAIN MENU", this.theme.fontFor(PackUiTone.LABEL), this.theme.color(PackUiTone.LABEL)) + this.labelIconSize() + this.buttonIconGap() + this.headerReserveWidth();
        int subLabelWidth = Math.max(this.requiredIconLabelWidth("PACKET"), Math.max(this.requiredIconLabelWidth("SCREEN"), this.requiredIconLabelWidth("CHAT")));
        int contentWidth = Math.max(headerWidth, Math.max(subLabelWidth, Math.max(fullWidth, Math.max(pairWidth * 2 + this.rowGap(), chatWidth))));
        return Math.max(this.minPanelWidth(), contentWidth + this.sectionPadding() * 2 + this.panelWidthReserve());
    }

    private int requiredButtonWidth(String label, class_2960 icon) {
        if (MC.field_1772 == null) {
            return this.minPairWidth();
        }
        int width = PackUiText.width(MC.field_1772, label, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY)) + this.buttonPadding() * 2 + this.buttonOutlineReserve();
        if (icon != null) {
            width = width + (this.buttonIconSize() + this.buttonIconGap());
        }
        return width;
    }

    private int requiredIconLabelWidth(String label) {
        return PackUiText.width(MC.field_1772, label, this.theme.fontFor(PackUiTone.LABEL), this.theme.color(PackUiTone.LABEL)) + this.labelIconSize() + this.buttonIconGap() + this.buttonOutlineReserve();
    }

    private int requiredTextFieldWidth(String placeholder) {
        return PackUiText.width(MC.field_1772, placeholder, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.MUTED)) + this.textFieldExtraWidth() + this.buttonOutlineReserve();
    }

    private int sectionPadding() {
        return 3;
    }

    private int sectionGap() {
        return 2;
    }

    private int rowGap() {
        return 2;
    }

    private int buttonHeight() {
        return 15;
    }

    private int buttonPadding() {
        return 6;
    }

    private int buttonIconSize() {
        return 12;
    }

    private int buttonIconGap() {
        return 3;
    }

    private int labelIconSize() {
        return 11;
    }

    private int minPairWidth() {
        return 54;
    }

    private int minPanelWidth() {
        return 152;
    }

    private int minimumPanelHeight() {
        return 56;
    }

    private int sectionHeaderHeight() {
        return 20;
    }

    private int sectionContentTopGap() {
        return 2;
    }

    private int chatHeight() {
        return 16;
    }

    private int chatMinWidth() {
        return 124;
    }

    private int syncRowGap() {
        return 4;
    }

    private int headerReserveWidth() {
        return 16;
    }

    private int textFieldExtraWidth() {
        return 10;
    }

    private int buttonOutlineReserve() {
        return 2;
    }

    private int panelWidthReserve() {
        return 2;
    }

    private void toggleSendPackets() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean newValue = !shared.shouldSendGuiPackets();
        PackUtilModule.get().applySendGuiPacketsUiBehavior(newValue);
        PackUtilClientMessaging.sendPrefixed("Packets: " + newValue ? "enabled" : "disabled");
    }

    private void toggleDelayPackets() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean newValue = !shared.shouldDelayGuiPackets();
        PackUtilModule module = PackUtilModule.get();
        int sent = module.applyDelayGuiPacketsUiBehavior(newValue);
        if (newValue) {
            PackUtilClientMessaging.sendPrefixed("Packet delay: enabled");
        } else {
            if (sent > 0) {
                String completionMessage = "Packet delay: disabled. Sent " + sent + " queued packets.";
                if (shared.isStaggering()) {
                    shared.setPendingQueueCompletionMessage(completionMessage);
                } else {
                    PackUtilClientMessaging.sendPrefixed(completionMessage);
                }
            } else {
                if (!module.shouldFlushQueueOnDelayDisable()) {
                    if (!shared.getDelayedPackets().isEmpty()) { /* goto L110; */ }
                    if (!shared.getStaggeredQueue().isEmpty()) {
                        PackUtilClientMessaging.sendPrefixed("Packet delay: disabled. Queue kept.");
                    }
                } else {
                    PackUtilClientMessaging.sendPrefixed("Packet delay: disabled. Queue empty.");
                }
            }
        }
    }

    private void flushQueue() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        int count = PackUtilModule.get().flushQueuedPacketsUiBehavior();
        if (count > 0) {
            if (shared.isStaggering()) {
                shared.setPendingQueueCompletionMessage("Sent " + count + " packets.");
            } else {
                PackUtilClientMessaging.sendPrefixed("Sent " + count + " packets.");
            }
        } else {
            PackUtilClientMessaging.sendPrefixed("Queue empty.");
        }
    }

    private void clearQueue() {
        int count = PackUtilModule.get().clearQueuedPacketsUiBehavior();
        PackUtilClientMessaging.sendPrefixed(count > 0 ? "Cleared " + count + " packets." : "Queue empty.");
    }

    private void sendDesync() {
        if (MC.method_1562() != null) {
            if (MC.field_1724 != null) {
                MC.method_1562().method_52787(new class_2815(MC.field_1724.field_7512.field_7763));
            }
        }
    }

    private void saveGui() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        if (MC.field_1724 != null) {
            shared.storeScreen(MC.field_1755, MC.field_1724.field_7512);
            PackUtilClientMessaging.sendPrefixed("GUI stored.");
        }
    }

    private void loadGui() {
        if (PackUtilModule.get().restoreSavedScreenUiBehavior()) {
            PackUtilClientMessaging.sendPrefixed("GUI restored.");
        } else {
            PackUtilClientMessaging.sendPrefixed("No stored GUI.");
        }
    }

    private void disconnectAndSend() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        PackUtilModule.get().setDelayGuiPackets(false);
        if (MC.method_1562() != null) {
            shared.flushDelayedPackets(MC.method_1562());
            MC.method_1562().method_48296().method_10747(class_2561.method_43470("Disconnecting (PackUtil)"));
        }
    }

    private void submitChat(String raw) {
        if (raw == null) {
            return;
        }
        String message = raw.trim();
        if (message.isEmpty() || MC.method_1562() == null) {
            return;
        }
        MC.method_1562().method_45730(message.substring(1));
        if (message.startsWith("/") && message.length() > 1) {
        } else {
            MC.method_1562().method_45729(message);
        }
        if (MC.field_1705 != null) {
            MC.field_1705.method_1743().method_1803(message);
        }
        if (this.chatField != null) {
            this.chatField.setText("");
            this.chatField.setFocused(false);
        }
    }

    private void updateSyncMetrics() {
        String revisionText = "--";
        String syncIdText = "--";
        String slotText = "--";
        if (MC.field_1724 != null) {
            if (MC.field_1724.field_7512 != null) {
                revisionText = Integer.toString(MC.field_1724.field_7512.method_37421());
                syncIdText = Integer.toString(MC.field_1724.field_7512.field_7763);
                class_1735 focusedSlot = MC.field_1755;
                if (focusedSlot instanceof class_465) {
                    class_465<?> handledScreen = (class_465)focusedSlot;
                    focusedSlot = ((PackUtilHandledScreenAccessor)handledScreen).getFocusedSlot();
                    if (focusedSlot != null) {
                        slotText = Integer.toString(PackUtilInventoryHelper.toUserVisibleSlot(MC, focusedSlot.field_7874));
                    }
                }
            }
        }
        if (this.revMetric != null) {
            this.revMetric.setValue(revisionText);
        }
        if (this.syncMetric != null) {
            this.syncMetric.setValue(syncIdText);
        }
        if (this.slotMetric != null) {
            this.slotMetric.setValue(slotText);
        }
    }
}
