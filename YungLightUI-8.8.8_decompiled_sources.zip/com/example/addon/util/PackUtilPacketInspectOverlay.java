/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiLegacyLayout;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiScrollViewport;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketEntryActions;
import com.example.addon.util.PackUtilPacketInspector;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilPacketInspectOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final int CONTENT_RESERVE = 0;
    private static final int AUTO_WIDTH_STEP = 8;
    private static final int SOFT_BREAK_MAX_SLACK_PX = 8;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private boolean visible;
    private boolean collapsed;
    private boolean dragging;
    private double dragOffsetX;
    private double dragOffsetY;
    private int panelX = 120;
    private int panelY = 50;
    private int panelWidth = 220;
    private int panelHeight = 173;
    private PackUtilPacketInspector.PacketInspection inspection;
    private PackUtilPacketLoggerOverlay.LogEntry sourceEntry;
    private List<PackUtilPacketInspectOverlay.WrappedInspectionLine> wrappedLines = Collections.emptyList();
    private boolean wrapDirty = true;
    private PackUiScrollViewport listViewport = null;
    private static final int INSPECT_SCROLLBAR_WIDTH = 8;

    public PackUtilPacketInspectOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.panelWidth = this.defaultPanelWidth();
        this.panelHeight = this.defaultPanelHeight();
    }

    public void open(PackUtilPacketInspector.PacketInspection inspection, PackUtilPacketLoggerOverlay.LogEntry sourceEntry, int anchorX, int anchorY) {
        if (inspection == null) {
            return;
        }
        PackUtilOverlayManager manager = PackUtilOverlayManager.get();
        manager.register(this);
        this.inspection = inspection;
        this.sourceEntry = sourceEntry;
        this.visible = true;
        this.collapsed = false;
        this.wrapDirty = true;
        this.fitWindowToInspection(anchorX, anchorY);
        manager.bringToFront(this);
    }

    public void close() {
        this.visible = false;
        this.dragging = false;
        this.sourceEntry = null;
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        /* decompile fallback: stack underflow while reading invoke object @ offset 669 opcode invokevirtual (stack_before=1) */
        /* decompile technical detail:
         * category: other
         * stage: operand_stack_simulation
         * detail: stack underflow while reading invoke object @ offset 669 opcode invokevirtual (stack_before=1)
         * explanation: the simulated JVM operand stack became inconsistent at the reported bytecode offset and opcode, so structured Java emission was aborted
         * emitted_body: raw bytecode disassembly follows
         */
        /* @obfuscation score:2/10 signals:fallback_stack_underflow hint:complex but likely not obfuscated — LLM should do well */
        /* bytecode:
          0000: aload_0
          0001: getfield #145 // com.example.addon.util.PackUtilPacketInspectOverlay.visible:Z
          0004: ifne 8
          0007: return
          0008: aload_0
          0009: invokevirtual #169 // com.example.addon.util.PackUtilPacketInspectOverlay.getBounds()Lcom.example.addon.util.PackUtilWindowLayout;
          000c: astore 5
          000e: aload_0
          000f: getfield #141 // com.example.addon.util.PackUtilPacketInspectOverlay.inspection:Lcom.example.addon.util.PackUtilPacketInspector$PacketInspection;
          0012: ifnonnull 26
          0015: ldc #171 // "Packet Inspect"
          0017: goto 33
          001a: aload_0
          001b: getfield #141 // com.example.addon.util.PackUtilPacketInspectOverlay.inspection:Lcom.example.addon.util.PackUtilPacketInspector$PacketInspection;
          001e: invokevirtual #177 // com.example.addon.util.PackUtilPacketInspector$PacketInspection.getTitle()Ljava.lang.String;
          0021: astore 6
          0023: aload_0
          0024: aload_1
          0025: iload_2
          0026: iload_3
          0027: aload 5
          0029: aload 6
          002b: aload_0
          002c: getfield #147 // com.example.addon.util.PackUtilPacketInspectOverlay.collapsed:Z
          002f: aload_0
          0030: getfield #159 // com.example.addon.util.PackUtilPacketInspectOverlay.dragging:Z
          0033: invokevirtual #183 // com.example.addon.util.PackUtilPacketInspectOverlay.renderWindowFrame(Lnet.minecraft.class_332;IILcom.example.addon.util.PackUtilWindowLayout;Ljava.lang.String;ZZ)V
          0036: aload_0
          0037: aload_1
          0038: aload 5
          003a: aload_0
          003b: getfield #147 // com.example.addon.util.PackUtilPacketInspectOverlay.collapsed:Z
          003e: invokevirtual #187 // com.example.addon.util.PackUtilPacketInspectOverlay.beginWindowBodyClip(Lnet.minecraft.class_332;Lcom.example.addon.util.PackUtilWindowLayout;Z)Z
          0041: istore 7
          0043: iload 7
          0045: ifne 88
          0048: aload_0
          0049: aload_1
          004a: aload 5
          004c: aload_0
          004d: getfield #147 // com.example.addon.util.PackUtilPacketInspectOverlay.collapsed:Z
          0050: aload_0
          0051: getfield #159 // com.example.addon.util.PackUtilPacketInspectOverlay.dragging:Z
          0054: invokevirtual #191 // com.example.addon.util.PackUtilPacketInspectOverlay.renderWindowInactiveOverlay(Lnet.minecraft.class_332;Lcom.example.addon.util.PackUtilWindowLayout;ZZ)V
          0057: return
          0058: aload_0
          0059: getfield #96 // com.example.addon.util.PackUtilPacketInspectOverlay.panelX:I
          005c: aload_0
          005d: invokevirtual #194 // com.example.addon.util.PackUtilPacketInspectOverlay.outerPad()I
          0060: iadd
          0061: istore 8
          0063: aload_0
          0064: getfield #98 // com.example.addon.util.PackUtilPacketInspectOverlay.panelY:I
          0067: bipush 16
          0069: iadd
          006a: aload_0
          006b: invokevirtual #197 // com.example.addon.util.PackUtilPacketInspectOverlay.bodyTopGap()I
          006e: iadd
          006f: istore 9
          0071: aload_0
          0072: getfield #100 // com.example.addon.util.PackUtilPacketInspectOverlay.panelWidth:I
          0075: aload_0
          0076: invokevirtual #194 // com.example.addon.util.PackUtilPacketInspectOverlay.outerPad()I
          0079: iconst_2
          007a: imul
          007b: isub
          007c: istore 10
          007e: aload_0
          007f: invokevirtual #200 // com.example.addon.util.PackUtilPacketInspectOverlay.listMinimumHeight()I
          0082: aload_0
          0083: getfield #102 // com.example.addon.util.PackUtilPacketInspectOverlay.panelHeight:I
          0086: bipush 16
          0088: isub
          0089: aload_0
          008a: invokevirtual #203 // com.example.addon.util.PackUtilPacketInspectOverlay.footerHeight()I
          008d: isub
          008e: aload_0
          008f: invokevirtual #206 // com.example.addon.util.PackUtilPacketInspectOverlay.bodyVerticalGap()I
          0092: isub
          0093: invokestatic #212 // java.lang.Math.max(II)I
          0096: istore 11
          0098: iload 8
          009a: aload_0
          009b: invokevirtual #215 // com.example.addon.util.PackUtilPacketInspectOverlay.innerPad()I
          009e: iadd
          009f: istore 12
          00a1: iload 9
          00a3: aload_0
          00a4: invokevirtual #215 // com.example.addon.util.PackUtilPacketInspectOverlay.innerPad()I
          00a7: iadd
          00a8: istore 13
          00aa: iload 10
          00ac: aload_0
          00ad: invokevirtual #215 // com.example.addon.util.PackUtilPacketInspectOverlay.innerPad()I
          00b0: iconst_2
          00b1: imul
          00b2: isub
          00b3: bipush 8
          00b5: isub
          00b6: istore 14
          00b8: iload 11
          00ba: aload_0
          00bb: invokevirtual #215 // com.example.addon.util.PackUtilPacketInspectOverlay.innerPad()I
          00be: iconst_2
          00bf: imul
          00c0: isub
          00c1: istore 15
          00c3: aload_0
          00c4: invokevirtual #218 // com.example.addon.util.PackUtilPacketInspectOverlay.lineHeight()I
          00c7: istore 16
          00c9: invokestatic #135 // com.example.addon.util.PackUtilOverlayManager.get()Lcom.example.addon.util.PackUtilOverlayManager;
          00cc: aload_0
          00cd: invokevirtual #222 // com.example.addon.util.PackUtilOverlayManager.isFocusedOverlay(Lcom.example.addon.util.IPackUtilOverlay;)Z
          00d0: ifne 221
          00d3: invokestatic #135 // com.example.addon.util.PackUtilOverlayManager.get()Lcom.example.addon.util.PackUtilOverlayManager;
          00d6: aload_0
          00d7: invokevirtual #225 // com.example.addon.util.PackUtilOverlayManager.isTopOverlay(Lcom.example.addon.util.IPackUtilOverlay;)Z
          00da: ifeq 225
          00dd: iconst_1
          00de: goto 226
          00e1: iconst_0
          00e2: istore 17
          00e4: aload_0
          00e5: iload 14
          00e7: invokevirtual #231 // com.example.addon.util.PackUtilPacketInspectOverlay.ensureWrappedLines(I)V
          00ea: aload_0
          00eb: getfield #110 // com.example.addon.util.PackUtilPacketInspectOverlay.wrappedLines:Ljava.util.List;
          00ee: invokeinterface #237 count=1 // java.util.List.isEmpty()Z
          00f3: ifeq 265
          00f6: aload_1
          00f7: aload_0
          00f8: getfield #116 // com.example.addon.util.PackUtilPacketInspectOverlay.textRenderer:Lnet.minecraft.class_327;
          00fb: ldc #239 // "No inspection data."
          00fd: iload 8
          00ff: iload 9
          0101: iload 10
          0103: invokestatic #245 // com.example.addon.gui.packui.PackUiListRenderer.drawEmptyState(Lnet.minecraft.class_332;Lnet.minecraft.class_327;Ljava.lang.String;III)V
          0106: goto 448
          0109: aload_0
          010a: getfield #110 // com.example.addon.util.PackUtilPacketInspectOverlay.wrappedLines:Ljava.util.List;
          010d: invokeinterface #248 count=1 // java.util.List.size()I
          0112: iload 16
          0114: imul
          0115: istore 18
          0117: aload_0
          0118: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          011b: ifnull 334
          011e: aload_0
          011f: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          0122: invokevirtual #251 // com.example.addon.gui.packui.PackUiScrollViewport.getX()I
          0125: iload 8
          0127: if_icmpne 334
          012a: aload_0
          012b: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          012e: invokevirtual #254 // com.example.addon.gui.packui.PackUiScrollViewport.getY()I
          0131: iload 9
          0133: if_icmpne 334
          0136: aload_0
          0137: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          013a: invokevirtual #257 // com.example.addon.gui.packui.PackUiScrollViewport.getWidth()I
          013d: iload 10
          013f: if_icmpne 334
          0142: aload_0
          0143: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          0146: invokevirtual #260 // com.example.addon.gui.packui.PackUiScrollViewport.getHeight()I
          0149: iload 11
          014b: if_icmpeq 357
          014e: aload_0
          014f: new #44 // class com.example.addon.gui.packui.PackUiScrollViewport
          0152: dup
          0153: iload 8
          0155: iload 9
          0157: iload 10
          0159: iload 11
          015b: iload 16
          015d: bipush 8
          015f: invokespecial #263 // com.example.addon.gui.packui.PackUiScrollViewport.<init>(IIIIII)V
          0162: putfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          0165: aload_0
          0166: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          0169: iload 18
          016b: invokevirtual #266 // com.example.addon.gui.packui.PackUiScrollViewport.setContentHeight(I)V
          016e: aload_0
          016f: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          0172: aload_1
          0173: aload_0
          0174: getfield #94 // com.example.addon.util.PackUtilPacketInspectOverlay.theme:Lcom.example.addon.gui.packui.PackUiTheme;
          0177: invokevirtual #269 // com.example.addon.gui.packui.PackUiTheme.borderSoft()I
          017a: ldc_w #270 // 905969664
          017d: invokevirtual #274 // com.example.addon.gui.packui.PackUiScrollViewport.beginRender(Lnet.minecraft.class_332;II)V
          0180: aload_0
          0181: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          0184: aload_1
          0185: aload_0
          0186: getfield #110 // com.example.addon.util.PackUtilPacketInspectOverlay.wrappedLines:Ljava.util.List;
          0189: invokeinterface #248 count=1 // java.util.List.size()I
          018e: aload_0
          018f: aload_1
          0190: iload 12
          0192: iload 16
          0194: invokedynamic #294 // invokedynamic(bsm=0) accept(Lcom.example.addon.util.PackUtilPacketInspectOverlay;Lnet.minecraft.class_332;II)Ljava.util.function.BiConsumer;
          0199: invokevirtual #298 // com.example.addon.gui.packui.PackUiScrollViewport.renderSimple(Lnet.minecraft.class_332;ILjava.util.function.BiConsumer;)V
          019c: aload_0
          019d: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          01a0: aload_1
          01a1: invokevirtual #302 // com.example.addon.gui.packui.PackUiScrollViewport.endRender(Lnet.minecraft.class_332;)V
          01a4: goto 436
          01a7: astore 19
          01a9: aload_0
          01aa: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          01ad: aload_1
          01ae: invokevirtual #302 // com.example.addon.gui.packui.PackUiScrollViewport.endRender(Lnet.minecraft.class_332;)V
          01b1: aload 19
          01b3: athrow
          01b4: aload_0
          01b5: getfield #114 // com.example.addon.util.PackUtilPacketInspectOverlay.listViewport:Lcom.example.addon.gui.packui.PackUiScrollViewport;
          01b8: aload_1
          01b9: iload_2
          01ba: i2d
          01bb: iload_3
          01bc: i2d
          01bd: invokevirtual #308 // com.example.addon.gui.packui.PackUiScrollViewport.renderScrollbar(Lnet.minecraft.class_332;DD)V
          01c0: aload_0
          01c1: getfield #98 // com.example.addon.util.PackUtilPacketInspectOverlay.panelY:I
          01c4: aload_0
          01c5: getfield #102 // com.example.addon.util.PackUtilPacketInspectOverlay.panelHeight:I
          01c8: iadd
          01c9: aload_0
          01ca: invokevirtual #203 // com.example.addon.util.PackUtilPacketInspectOverlay.footerHeight()I
          01cd: isub
          01ce: aload_0
          01cf: invokevirtual #311 // com.example.addon.util.PackUtilPacketInspectOverlay.footerTopInset()I
          01d2: iadd
          01d3: istore 18
          01d5: aload_1
          01d6: aload_0
          01d7: getfield #116 // com.example.addon.util.PackUtilPacketInspectOverlay.textRenderer:Lnet.minecraft.class_327;
          01da: aload_0
          01db: getfield #110 // com.example.addon.util.PackUtilPacketInspectOverlay.wrappedLines:Ljava.util.List;
          01de: invokeinterface #248 count=1 // java.util.List.size()I
          01e3: invokedynamic #323 // invokedynamic(bsm=1) makeConcatWithConstants(I)Ljava.lang.String;
          01e8: aload_0
          01e9: getfield #94 // com.example.addon.util.PackUtilPacketInspectOverlay.theme:Lcom.example.addon.gui.packui.PackUiTheme;
          01ec: getstatic #329 // com.example.addon.gui.packui.PackUiTone.MUTED:Lcom.example.addon.gui.packui.PackUiTone;
          01ef: invokevirtual #333 // com.example.addon.gui.packui.PackUiTheme.fontFor(Lcom.example.addon.gui.packui.PackUiTone;)Lnet.minecraft.class_2960;
          01f2: aload_0
          01f3: getfield #94 // com.example.addon.util.PackUtilPacketInspectOverlay.theme:Lcom.example.addon.gui.packui.PackUiTheme;
          01f6: getstatic #329 // com.example.addon.gui.packui.PackUiTone.MUTED:Lcom.example.addon.gui.packui.PackUiTone;
          01f9: invokevirtual #337 // com.example.addon.gui.packui.PackUiTheme.color(Lcom.example.addon.gui.packui.PackUiTone;)I
          01fc: aload_0
          01fd: getfield #96 // com.example.addon.util.PackUtilPacketInspectOverlay.panelX:I
          0200: aload_0
          0201: invokevirtual #194 // com.example.addon.util.PackUtilPacketInspectOverlay.outerPad()I
          0204: iadd
          0205: iconst_5
          0206: iadd
          0207: iload 18
          0209: aload_0
          020a: invokevirtual #340 // com.example.addon.util.PackUtilPacketInspectOverlay.footerLabelInset()I
          020d: iadd
          020e: iconst_0
          020f: invokestatic #346 // com.example.addon.gui.packui.PackUiText.draw(Lnet.minecraft.class_332;Lnet.minecraft.class_327;Ljava.lang.String;Lnet.minecraft.class_2960;IIIZ)V
          0212: aload_0
          0213: iload 18
          0215: invokevirtual #350 // com.example.addon.util.PackUtilPacketInspectOverlay.buildFooterButtons(I)Ljava.util.List;
          0218: invokeinterface #354 count=1 // java.util.List.iterator()Ljava.util.Iterator;
          021d: astore 19
          021f: aload 19
          0221: invokeinterface #359 count=1 // java.util.Iterator.hasNext()Z
          0226: ifeq 688
          0229: aload 19
          022b: invokeinterface #363 count=1 // java.util.Iterator.next()Ljava.lang.Object;
          0230: checkcast #13 // class com.example.addon.util.PackUtilPacketInspectOverlay$FooterButton
          0233: astore 20
          0235: aload 20
          0237: invokevirtual #366 // com.example.addon.util.PackUtilPacketInspectOverlay$FooterButton.x()I
          023a: aload 20
          023c: invokevirtual #369 // com.example.addon.util.PackUtilPacketInspectOverlay$FooterButton.y()I
          023f: aload 20
          0241: invokevirtual #372 // com.example.addon.util.PackUtilPacketInspectOverlay$FooterButton.width()I
          0244: aload_0
          0245: invokevirtual #375 // com.example.addon.util.PackUtilPacketInspectOverlay.buttonHeight()I
          0248: aload 20
          024a: invokevirtual #378 // com.example.addon.util.PackUtilPacketInspectOverlay$FooterButton.label()Ljava.lang.String;
          024d: invokestatic #384 // net.minecraft.class_2561.method_43470(Ljava.lang.String;)Lnet.minecraft.class_5250;
          0250: invokedynamic #394 // invokedynamic(bsm=2) onPress()Lcom.example.addon.gui.packui.PackUiOverlayButton$PressAction;
          0255: invokestatic #398 // com.example.addon.gui.packui.PackUiOverlayButton.create(IIIILnet.minecraft.class_2561;Lcom.example.addon.gui.packui.PackUiOverlayButton$PressAction;)Lcom.example.addon.gui.packui.PackUiOverlayButton;
          0258: astore 21
          025a: aload 21
          025c: aload 20
          025e: invokevirtual #402 // com.example.addon.util.PackUtilPacketInspectOverlay$FooterButton.action()Lcom.example.addon.util.PackUtilPacketInspectOverlay$FooterAction;
          0261: invokevirtual #405 // com.example.addon.util.PackUtilPacketInspectOverlay$FooterAction.ordinal()I
          0264: tableswitch low=0 high=3 default=644 0:666 1:660 2:666 3:654
          0284: new #407 // class java.lang.MatchException
          0287: dup
          0288: aconst_null
          0289: aconst_null
          028a: invokespecial #410 // java.lang.MatchException.<init>(Ljava.lang.String;Ljava.lang.Throwable;)V
          028d: athrow
          028e: getstatic #414 // com.example.addon.gui.packui.PackUiOverlayButton$Variant.GHOST:Lcom.example.addon.gui.packui.PackUiOverlayButton$Variant;
          0291: goto 669
          0294: getstatic #417 // com.example.addon.gui.packui.PackUiOverlayButton$Variant.SUCCESS:Lcom.example.addon.gui.packui.PackUiOverlayButton$Variant;
          0297: goto 669
          029a: getstatic #420 // com.example.addon.gui.packui.PackUiOverlayButton$Variant.SECONDARY:Lcom.example.addon.gui.packui.PackUiOverlayButton$Variant;
          029d: invokevirtual #424 // com.example.addon.gui.packui.PackUiOverlayButton.setVariant(Lcom.example.addon.gui.packui.PackUiOverlayButton$Variant;)Lcom.example.addon.gui.packui.PackUiOverlayButton;
          02a0: pop
          02a1: aload_1
          02a2: aload_0
          02a3: getfield #116 // com.example.addon.util.PackUtilPacketInspectOverlay.textRenderer:Lnet.minecraft.class_327;
          02a6: aload 21
          02a8: iload_2
          02a9: iload_3
          02aa: invokestatic #428 // com.example.addon.gui.packui.PackUiOverlayButton.renderStyled(Lnet.minecraft.class_332;Lnet.minecraft.class_327;Lcom.example.addon.gui.packui.PackUiOverlayButton;II)V
          02ad: goto 543
          02b0: aload_0
          02b1: aload_1
          02b2: iload 7
          02b4: invokevirtual #432 // com.example.addon.util.PackUtilPacketInspectOverlay.endWindowBodyClip(Lnet.minecraft.class_332;Z)V
          02b7: aload_0
          02b8: aload_1
          02b9: aload 5
          02bb: aload_0
          02bc: getfield #147 // com.example.addon.util.PackUtilPacketInspectOverlay.collapsed:Z
          02bf: aload_0
          02c0: getfield #159 // com.example.addon.util.PackUtilPacketInspectOverlay.dragging:Z
          02c3: invokevirtual #191 // com.example.addon.util.PackUtilPacketInspectOverlay.renderWindowInactiveOverlay(Lnet.minecraft.class_332;Lcom.example.addon.util.PackUtilWindowLayout;ZZ)V
          02c6: goto 740
          02c9: astore 22
          02cb: aload_0
          02cc: aload_1
          02cd: iload 7
          02cf: invokevirtual #432 // com.example.addon.util.PackUtilPacketInspectOverlay.endWindowBodyClip(Lnet.minecraft.class_332;Z)V
          02d2: aload_0
          02d3: aload_1
          02d4: aload 5
          02d6: aload_0
          02d7: getfield #147 // com.example.addon.util.PackUtilPacketInspectOverlay.collapsed:Z
          02da: aload_0
          02db: getfield #159 // com.example.addon.util.PackUtilPacketInspectOverlay.dragging:Z
          02de: invokevirtual #191 // com.example.addon.util.PackUtilPacketInspectOverlay.renderWindowInactiveOverlay(Lnet.minecraft.class_332;Lcom.example.addon.util.PackUtilWindowLayout;ZZ)V
          02e1: aload 22
          02e3: athrow
          02e4: return
        */
    }

    private void ensureWrappedLines(int innerWidth) {
        if (!this.wrapDirty) {
            return;
        }
        if (this.inspection == null) {
            this.wrappedLines = Collections.emptyList();
            this.wrapDirty = false;
            return;
        }
        List<PackUtilPacketInspectOverlay.WrappedInspectionLine> wrapped = new ArrayList();
        var var3 = this.inspection.getLines().iterator();
        while (var3.hasNext()) {
            InspectionLine line = (PackUtilPacketInspector.InspectionLine)var3.next();
            this.wrapLine(line, innerWidth, wrapped);
        }
        this.wrappedLines = wrapped;
        this.wrapDirty = false;
    }

    private void wrapLine(PackUtilPacketInspector.InspectionLine line, int maxWidth, List<PackUtilPacketInspectOverlay.WrappedInspectionLine> target) {
        String text = line.getText();
        if (text == null || text.isEmpty()) {
            target.add(PackUtilPacketInspectOverlay.WrappedInspectionLine.plain("", 0, line.getColor()));
            return;
        }
        if (this.isSectionLine(text)) {
            this.wrapPlainText(text, 0, line.getColor(), maxWidth, target);
            return;
        }
        int leadingSpaces = this.countLeadingSpaces(text);
        String indentText = " ".repeat(leadingSpaces);
        int indentWidth = this.styledWidth(indentText);
        int colonIndex = text.indexOf(58, leadingSpaces);
        String label = text.substring(leadingSpaces, colonIndex + 1).trim();
        if (colonIndex > leadingSpaces && colonIndex < text.length() - 1) {
            String value = text.substring(colonIndex + 1).stripLeading();
            String prefix = indentText + label + " ";
            int prefixWidth = this.styledWidth(prefix);
            int continuationOffset = Math.min(prefixWidth, indentWidth + this.continuationIndent());
            this.wrapKeyValue(prefix, value, line.getColor(), prefixWidth, continuationOffset, maxWidth, target);
            return;
        }
        this.wrapPlainText(text.substring(leadingSpaces), indentWidth, line.getColor(), maxWidth, target);
    }

    private void wrapKeyValue(String prefix, String value, int valueColor, int prefixWidth, int continuationOffset, int maxWidth, List<PackUtilPacketInspectOverlay.WrappedInspectionLine> target) {
        if (value == null || value.isEmpty()) {
            target.add(new PackUtilPacketInspectOverlay.WrappedInspectionLine(prefix, PackUtilColors.packetGray(), "", valueColor, prefixWidth));
            return;
        }
        String remaining = value;
        boolean firstLine = true;
        while (!remaining.isEmpty()) {
            int offset = firstLine ? prefixWidth : continuationOffset;
            int availableWidth = Math.max(22, maxWidth - offset);
            String chunk = this.trimStyledToWidth(remaining, availableWidth);
            if (chunk.isEmpty()) { /* goto L108; */ }
            if (chunk.length() < remaining.length()) { /* goto L142; */ }
            L108: ;
            target.add(new PackUtilPacketInspectOverlay.WrappedInspectionLine(firstLine ? prefix : null, PackUtilColors.packetGray(), remaining, valueColor, offset));
            return;
            int split = this.findWrapPoint(remaining, chunk, 1, availableWidth);
            String part = remaining.substring(0, split).stripTrailing();
            target.add(new PackUtilPacketInspectOverlay.WrappedInspectionLine(firstLine ? prefix : null, PackUtilColors.packetGray(), part, valueColor, offset));
            remaining = remaining.substring(split).stripLeading();
            firstLine = false;
        }
    }

    private void wrapPlainText(String text, int offset, int color, int maxWidth, List<PackUtilPacketInspectOverlay.WrappedInspectionLine> target) {
        if (text == null) {
            return;
        }
        if (text.isEmpty()) {
            target.add(PackUtilPacketInspectOverlay.WrappedInspectionLine.plain("", offset, color));
            return;
        }
        String remaining = text;
        while (!remaining.isEmpty()) {
            int availableWidth = Math.max(22, maxWidth - offset);
            String chunk = this.trimStyledToWidth(remaining, availableWidth);
            if (chunk.isEmpty() || chunk.length() >= remaining.length()) {
                target.add(PackUtilPacketInspectOverlay.WrappedInspectionLine.plain(remaining, offset, color));
                return;
            }
            int split = this.findWrapPoint(remaining, chunk, 1, availableWidth);
            String part = remaining.substring(0, split).stripTrailing();
            target.add(PackUtilPacketInspectOverlay.WrappedInspectionLine.plain(part, offset, color));
            remaining = remaining.substring(split).stripLeading();
        }
    }

    private void drawInspectionLine(class_332 context, PackUtilPacketInspectOverlay.WrappedInspectionLine line, int x, int y) {
        if (line == null || line.valueText() == null) {
            return;
        }
        if (line.prefixText() != null) {
            if (!line.prefixText().isEmpty()) {
                PackUiText.draw(context, this.textRenderer, line.prefixText(), this.theme.fontFor(PackUiTone.BODY), line.prefixColor(), x, y, false);
            }
        }
        int valueX = x + line.valueOffset();
        PackUiText.draw(context, this.textRenderer, line.valueText(), this.theme.fontFor(PackUiTone.BODY), line.valueColor(), valueX, y, false);
    }

    private boolean isSectionLine(String text) {
        String trimmed = text == null ? "" : text.trim();
        return trimmed.startsWith("[") && trimmed.endsWith("]");
    }

    private int findWrapPoint(String text, String chunk, int minimum, int availableWidth) {
        int hardSplit = Math.max(1, chunk.length());
        int preferredSplit = this.findPreferredBreakPoint(text, hardSplit, minimum, availableWidth);
        return preferredSplit > 0 ? preferredSplit : hardSplit;
    }

    private int findPreferredBreakPoint(String text, int hardSplit, int minimum, int availableWidth) {
        int minimumAcceptedWidth = Math.max(0, availableWidth - 8);
        for (int idx = hardSplit - 1; idx >= minimum; idx--) {
            if (!this.isPreferredBreakChar(text.charAt(idx))) {
            } else {
                String candidate = text.substring(0, idx + 1).stripTrailing();
                if (candidate.isEmpty()) {
                } else {
                    if (!this.styledWidth(candidate) >= minimumAcceptedWidth) continue;
                    return idx + 1;
                }
            }
        }
        return -1;
    }

    private boolean isPreferredBreakChar(char ch) {
        return ch == 32 || ch == 44 || ch == 59 || ch == 41 || ch == 93 || ch == 125;
    }

    private int countLeadingSpaces(String text) {
        for (int count = 0; count < text.length(); count++) {
            if (text.charAt(count) != 32) break;
        }
        return count;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        if (button != 0) { /* goto L143; */ }
        if (mouseY < (double)this.panelY) { /* goto L143; */ }
        if (mouseY > (double)(this.panelY + 16)) { /* goto L143; */ }
        if (mouseX < (double)this.panelX) { /* goto L143; */ }
        if (mouseX > (double)(this.panelX + this.panelWidth)) { /* goto L143; */ }
        if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
            this.close();
            return true;
        }
        if (!this.isOverCollapseButton(mouseX, mouseY, bounds)) { /* goto L114; */ }
        this.collapsed = !this.collapsed;
        return true;
        this.dragging = true;
        this.dragOffsetX = mouseX - (double)this.panelX;
        this.dragOffsetY = mouseY - (double)this.panelY;
        return true;
        L143: ;
        if (this.collapsed) {
            return true;
        }
        int listY = this.panelY + 16 + this.bodyTopGap();
        int listHeight = Math.max(this.listMinimumHeight(), this.panelHeight - 16 - this.footerHeight() - this.bodyVerticalGap());
        int listX = this.panelX + this.outerPad();
        int listWidth = this.panelWidth - this.outerPad() * 2;
        if (button == 0 && this.listViewport != null && this.listViewport.contains(mouseX, mouseY) && this.listViewport.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        int footerY = this.panelY + this.panelHeight - this.footerHeight() + this.footerTopInset();
        if (button != 0) { /* goto L386; */ }
        var var12 = this.buildFooterButtons(footerY).iterator();
        while (var12.hasNext()) {
            FooterButton footerButton = (PackUtilPacketInspectOverlay.FooterButton)var12.next();
            if (mouseX >= (double)footerButton.x()) {
                if (mouseX < (double)(footerButton.x() + footerButton.width())) {
                    if (mouseY >= (double)footerButton.y()) {
                        if (mouseY < (double)(footerButton.y() + this.buttonHeight())) {
                            this.handleFooterAction(footerButton.action());
                            return true;
                        }
                    }
                }
            }
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.dragging = false;
        if (button == 0 && this.dragging) {
            this.saveLayout();
            return true;
        }
        this.listViewport.mouseReleased();
        if (button == 0 && this.listViewport != null) {
            return true;
        }
        this.dragging = false;
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.listViewport != null) {
            this.listViewport.mouseDragged(mouseX, mouseY);
        }
        if (!this.visible || button != 0 || !this.dragging) {
            return false;
        }
        this.setBounds(new PackUtilWindowLayout((int)Math.round(mouseX - this.dragOffsetX), (int)Math.round(mouseY - this.dragOffsetY), this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        return true;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible || this.collapsed) {
            return false;
        }
        int listY = this.panelY + 16 + this.bodyTopGap();
        int listHeight = Math.max(this.listMinimumHeight(), this.panelHeight - 16 - this.footerHeight() - this.bodyVerticalGap());
        int listX = this.panelX + this.outerPad();
        int listWidth = this.panelWidth - this.outerPad() * 2;
        if (mouseX < (double)listX || mouseX > (double)(listX + listWidth) || mouseY < (double)listY || mouseY > (double)(listY + listHeight)) {
            return false;
        }
        if (this.listViewport != null) {
            this.listViewport.mouseScrolled(mouseX, mouseY, amount);
            return true;
        }
        return false;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (keyCode == 256) {
            this.close();
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        return false;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (!visible) {
            this.close();
        }
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        int height = this.collapsed ? 16 : this.panelHeight;
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.panelWidth) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + height);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.panelWidth) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + 16) && !this.isOverWindowControl(mouseX, mouseY, this.getBounds());
    }

    public int getZLevel() {
        return 12;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
        this.wrapDirty = true;
    }

    public int getMinWidth() {
        return this.minimumWidth();
    }

    public int getMinHeight() {
        return this.minimumHeight();
    }

    private void handleFooterAction(PackUtilPacketInspectOverlay.FooterAction action) {
        if (action == null) {
            return;
        }
        switch (action.ordinal()) {
            case 3::
                if (this.inspection == null) { /* goto @102; */ }
                MC.field_1774.method_1455(this.inspection.getCopyText());
                PackUtilClientMessaging.sendPrefixed("Copied packet inspection.");
                /* goto @102; */
            case 2::
                PackUtilPacketEntryActions.queue(this.sourceEntry);
                /* goto @102; */
            case 0::
                PackUtilPacketEntryActions.addWaitActionToVisibleMacro(this.sourceEntry);
                /* goto @102; */
            case 1::
                PackUtilPacketEntryActions.addSendActionToVisibleMacro(this.sourceEntry);
            default:
                return;
        }
    }

    private void fitWindowToInspection(int anchorX, int anchorY) {
        int screenWidth = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenWidth() : 600;
        int screenHeight = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenHeight() : 400;
        int lineHeight = this.lineHeight();
        int lineCount = this.inspection == null ? 0 : this.inspection.getLines().size();
        int footerInfoWidth = this.styledWidth(lineCount + " lines") + this.outerPad() + 15;
        int footerButtonsWidth = this.computeFooterButtonsWidth();
        int titleWidth = this.styledWidth(this.inspection == null ? "Packet Inspect" : this.inspection.getTitle()) + this.titleWidthPadding();
        int minWidth = Math.max(this.minimumWidth(), Math.max(titleWidth, footerInfoWidth + footerButtonsWidth + this.footerContentPadding()));
        int maxWidth = Math.max(minWidth, Math.min(this.maxAutoWidth(), screenWidth - 12));
        int maxHeight = Math.max(this.minimumHeight(), Math.min(this.maxAutoHeight(), screenHeight - 12));
        int desiredWidth = this.chooseBestAutoWidth(minWidth, maxWidth);
        FitMetrics fit = this.measureFitForPanelWidth(desiredWidth);
        int desiredVisibleLines = Math.max(3, Math.min(fit.lineCount(), this.maxVisibleLines()));
        int desiredListHeight = Math.max(this.listMinimumHeight(), desiredVisibleLines * lineHeight + this.innerPad() * 2 + 2);
        int desiredHeight = 16 + this.bodyTopGap() + desiredListHeight + this.footerHeight() + this.footerBottomGap();
        desiredHeight = Math.min(maxHeight, Math.max(this.minimumHeight(), desiredHeight));
        this.setBounds(new PackUtilWindowLayout(anchorX, anchorY, desiredWidth, desiredHeight, true, false));
    }

    private int chooseBestAutoWidth(int minPanelWidth, int maxPanelWidth) {
        int rawLineCount = this.inspection == null ? 0 : this.inspection.getLines().size();
        int bestWidth = minPanelWidth;
        long bestScore = 9223372036854775807L;
        for (int width = minPanelWidth; width <= maxPanelWidth; width += 8) {
            long score = this.scoreAutoWidth(width, rawLineCount);
            if (score >= bestScore) {
                if (score != bestScore) { /* goto @81; */ }
            }
            bestScore = score;
            bestWidth = width;
            L81: ;
        }
        if (bestWidth != maxPanelWidth) {
            score = this.scoreAutoWidth(maxPanelWidth, rawLineCount);
            if (score >= bestScore) {
                if (score != bestScore) { /* goto @126; */ }
            }
            bestWidth = maxPanelWidth;
        }
        return bestWidth;
    }

    private long scoreAutoWidth(int panelWidthCandidate, int rawLineCount) {
        FitMetrics fit = this.measureFitForPanelWidth(panelWidthCandidate);
        int extraLines = Math.max(0, fit.lineCount() - rawLineCount);
        int wastedPixels = Math.max(0, fit.contentWidth() - fit.longestWrappedLineWidth());
        return (long)panelWidthCandidate / 6L + (long)extraLines * 52L + (long)wastedPixels * 4L;
    }

    private PackUtilPacketInspectOverlay.FitMetrics measureFitForPanelWidth(int panelWidthCandidate) {
        int listWidth = Math.max(32, panelWidthCandidate - this.outerPad() * 2);
        int contentWidth = Math.max(32, listWidth - this.innerPad() * 2 - 0);
        List<PackUtilPacketInspectOverlay.WrappedInspectionLine> measured = new ArrayList();
        if (this.inspection == null) { /* goto L94; */ }
        int longestWrappedLineWidth = this.inspection.getLines().iterator();
        while (longestWrappedLineWidth.hasNext()) {
            InspectionLine line = (PackUtilPacketInspector.InspectionLine)longestWrappedLineWidth.next();
            this.wrapLine(line, contentWidth, measured);
        }
        longestWrappedLineWidth = 0;
        line = measured.iterator();
        while (line.hasNext()) {
            WrappedInspectionLine line = (PackUtilPacketInspectOverlay.WrappedInspectionLine)line.next();
            longestWrappedLineWidth = Math.max(longestWrappedLineWidth, line.renderedWidth(this.textRenderer));
        }
        return new PackUtilPacketInspectOverlay.FitMetrics(contentWidth, measured.size(), longestWrappedLineWidth);
    }

    private List<PackUtilPacketInspectOverlay.FooterButton> buildFooterButtons(int footerY) {
        List<PackUtilPacketInspectOverlay.FooterButton> buttons = new ArrayList();
        int cursorX = this.panelX + this.panelWidth - this.outerPad();
        var var4 = this.getVisibleFooterActions().iterator();
        while (var4.hasNext()) {
            FooterAction action = (PackUtilPacketInspectOverlay.FooterAction)var4.next();
            cursorX = this.addFooterButton(buttons, cursorX, footerY, action);
        }
        return buttons;
    }

    private List<PackUtilPacketInspectOverlay.FooterAction> getVisibleFooterActions() {
        List<PackUtilPacketInspectOverlay.FooterAction> actions = new ArrayList();
        actions.add(PackUtilPacketInspectOverlay.FooterAction.COPY);
        if (PackUtilPacketEntryActions.canQueue(this.sourceEntry)) {
            actions.add(PackUtilPacketInspectOverlay.FooterAction.QUEUE);
        }
        if (PackUtilPacketEntryActions.canAddSendAction(this.sourceEntry)) {
            actions.add(PackUtilPacketInspectOverlay.FooterAction.SEND);
        }
        if (PackUtilPacketEntryActions.canAddWaitAction(this.sourceEntry)) {
            actions.add(PackUtilPacketInspectOverlay.FooterAction.WAIT);
        }
        return actions;
    }

    private int computeFooterButtonsWidth() {
        int width = 0;
        var var2 = this.getVisibleFooterActions().iterator();
        while (var2.hasNext()) {
            FooterAction action = (PackUtilPacketInspectOverlay.FooterAction)var2.next();
            if (!width > 0) continue;
            width = width + this.buttonGap();
            width = width + this.footerButtonWidth(action);
        }
        return width;
    }

    private int addFooterButton(List<PackUtilPacketInspectOverlay.FooterButton> buttons, int cursorX, int footerY, PackUtilPacketInspectOverlay.FooterAction action) {
        int width = this.footerButtonWidth(action);
        int x = cursorX - width;
        buttons.add(new PackUtilPacketInspectOverlay.FooterButton(action, x, footerY, width));
        return x - this.buttonGap();
    }

    private int footerButtonWidth(PackUtilPacketInspectOverlay.FooterAction action) {
        return PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, action.label, 5, 36, 68);
    }

    private String trimStyledToWidth(String value, int maxWidth) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        if (this.styledWidth(value) <= maxWidth) {
            return value;
        }
        int low = 0;
        int high = value.length();
        while (low < high) {
            int mid = low + high + 1 >>> 1;
            String candidate = value.substring(0, mid);
            if (this.styledWidth(candidate) <= maxWidth) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        return low <= 0 ? "" : value.substring(0, low);
    }

    private int styledWidth(String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        return PackUiText.width(this.textRenderer, text, this.theme.fontFor(PackUiTone.BODY), PackUtilColors.packetWhite());
    }

    private int minimumWidth() {
        return 176;
    }

    private int minimumHeight() {
        return 132;
    }

    private int defaultPanelWidth() {
        return 220;
    }

    private int defaultPanelHeight() {
        return 173;
    }

    private int footerHeight() {
        return 26;
    }

    private int outerPad() {
        return 5;
    }

    private int innerPad() {
        return 3;
    }

    private int buttonGap() {
        return 4;
    }

    private int buttonHeight() {
        return 16;
    }

    private int continuationIndent() {
        return 32;
    }

    private int maxAutoWidth() {
        return 392;
    }

    private int maxAutoHeight() {
        return 300;
    }

    private int maxVisibleLines() {
        return 13;
    }

    private int lineHeight() {
        return this.theme.lineHeight(PackUiTone.BODY, 2);
    }

    private int bodyTopGap() {
        return 4;
    }

    private int bodyVerticalGap() {
        return this.bodyTopGap() + this.footerBottomGap();
    }

    private int footerTopInset() {
        return 3;
    }

    private int footerBottomGap() {
        return 3;
    }

    private int footerLabelInset() {
        return 5;
    }

    private int titleWidthPadding() {
        return 54;
    }

    private int footerContentPadding() {
        return 16;
    }

    private int listMinimumHeight() {
        return 32;
    }
}
