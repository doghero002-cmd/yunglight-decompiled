/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilLANSync.PeerStatus {
    public static final PackUtilLANSync.PeerStatus HEALTHY = new PackUtilLANSync.PeerStatus("HEALTHY", 0);
    public static final PackUtilLANSync.PeerStatus STALE = new PackUtilLANSync.PeerStatus("STALE", 1);
    public static final PackUtilLANSync.PeerStatus UNKNOWN = new PackUtilLANSync.PeerStatus("UNKNOWN", 2);
    private static final /* synthetic */ PackUtilLANSync.PeerStatus[] $VALUES;

    public static PackUtilLANSync.PeerStatus[] values() {
        return (PackUtilLANSync.PeerStatus[])$VALUES.clone();
    }

    public static PackUtilLANSync.PeerStatus valueOf(String name) {
        return (PackUtilLANSync.PeerStatus)Enum.valueOf(PackUtilLANSync.PeerStatus.class, name);
    }

    private PackUtilLANSync.PeerStatus() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilLANSync.PeerStatus.$values();
    }
}
