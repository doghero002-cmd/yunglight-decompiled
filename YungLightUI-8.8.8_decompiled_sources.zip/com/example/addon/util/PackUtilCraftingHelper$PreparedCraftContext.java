/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_437;
import net.minecraft.class_9884;

private static final class PackUtilCraftingHelper.PreparedCraftContext {
    private final class_9884 handler;
    private final boolean closeAfter;
    private final class_437 restoreScreen;

    private PackUtilCraftingHelper.PreparedCraftContext(class_9884 handler, boolean closeAfter, class_437 restoreScreen) {
        this.handler = handler;
        this.closeAfter = closeAfter;
        this.restoreScreen = restoreScreen;
    }
}
