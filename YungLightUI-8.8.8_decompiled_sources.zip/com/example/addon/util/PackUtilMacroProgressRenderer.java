/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiHudPanelRenderer;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroExecutor;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUtilMacroProgressRenderer {
    private static final PackUiTheme THEME = new PackUiTheme();
    private static final long CACHE_REFRESH_NANOS = 50000000L;
    private static final int STEP_DONE_COLOR = -11184811;
    private static final int STEP_NOW_COLOR = -9448565;
    private static final int STEP_WAIT_COLOR = -3750202;
    private static final class_2960 MUTED_FONT = THEME.fontFor(PackUiTone.MUTED);
    private static final class_2960 BODY_FONT = THEME.fontFor(PackUiTone.BODY);
    private static final class_2960 LABEL_FONT = THEME.fontFor(PackUiTone.LABEL);
    private static final int MUTED_COLOR = THEME.color(PackUiTone.MUTED);
    private static final int HEADER_COLOR = THEME.color(PackUiTone.BODY);
    private static PackUtilMacro cachedMacro;
    private static int cachedCurrent = -2147483648;
    private static int cachedTotal = -2147483648;
    private static int cachedScroll = -2147483648;
    private static int cachedVisibleRows = -2147483648;
    private static int cachedPanelWidth = -2147483648;
    private static String cachedMacroName = null;
    private static String cachedTitle = "";
    private static List<PackUiHudPanelRenderer.Row> cachedRows = List.of();
    private static long lastCacheBuildNanos;

    private PackUtilMacroProgressRenderer() {
    }

    public static void render(class_332 context, class_327 textRenderer, int x, int y, int width, int maxLines) {
        if (textRenderer == null || !MacroExecutor.isRunning()) {
            return;
        }
        PackUtilMacro macro = MacroExecutor.getCurrentMacro();
        if (macro == null || macro.actions == null || macro.actions.isEmpty()) {
            PackUtilMacroProgressRenderer.clearCache();
            return;
        }
        List<MacroAction> actions = macro.actions;
        int total = actions.size();
        int current = Math.max(0, MacroExecutor.getCurrentStepIndex());
        int visibleRows = Math.min(maxLines, total);
        int scroll = 0;
        if (total > maxLines) {
            scroll = Math.max(0, Math.min(current - maxLines / 2, total - maxLines));
        }
        int panelWidth = width + 12;
        long now = System.nanoTime();
        if (PackUtilMacroProgressRenderer.shouldRebuildCache(macro, current, total, scroll, visibleRows, panelWidth, now)) {
            PackUtilMacroProgressRenderer.rebuildCache(textRenderer, macro, actions, current, total, scroll, visibleRows, panelWidth, now);
        }
        PackUiHudPanelRenderer.renderPreTrimmed(context, textRenderer, x - 6, y - 8, panelWidth, cachedTitle, cachedRows, THEME.headerAccent());
    }

    private static boolean shouldRebuildCache(PackUtilMacro macro, int current, int total, int scroll, int visibleRows, int panelWidth, long now) {
        boolean layoutChanged = cachedMacro != macro || cachedTotal != total || cachedVisibleRows != visibleRows || cachedPanelWidth != panelWidth || !Objects.equals(cachedMacroName, macro.name);
        if (layoutChanged) {
            return true;
        }
        if (cachedRows.isEmpty()) {
            return true;
        }
        if (cachedCurrent == current && cachedScroll == scroll) {
            return false;
        }
        return now - lastCacheBuildNanos >= 50000000L;
    }

    private static void rebuildCache(class_327 textRenderer, PackUtilMacro macro, List<MacroAction> actions, int current, int total, int scroll, int visibleRows, int panelWidth, long now) {
        int contentWidth = panelWidth - 12;
        ArrayList<PackUiHudPanelRenderer.Row> rows = new ArrayList(visibleRows + 1);
        rows.add(new PackUiHudPanelRenderer.Row(PackUiText.trimToWidth(textRenderer, "Step " + Math.min(current + 1, total) + " / " + total, contentWidth, MUTED_FONT, MUTED_COLOR), MUTED_FONT, MUTED_COLOR));
        for (int i = scroll; i < scroll + visibleRows; i++) {
            if (i >= total) break;
            MacroAction action = (MacroAction)actions.get(i);
            int color = i < current ? -11184811 : i == current ? -9448565 : -3750202;
            rows.add(new PackUiHudPanelRenderer.Row(PackUiText.trimToWidth(textRenderer, i + 1 + ". " + action.getDisplayName(), contentWidth, BODY_FONT, color), BODY_FONT, color));
        }
        cachedMacro = macro;
        cachedCurrent = current;
        cachedTotal = total;
        cachedScroll = scroll;
        cachedVisibleRows = visibleRows;
        cachedPanelWidth = panelWidth;
        cachedMacroName = macro.name;
        cachedTitle = PackUiText.trimToWidth(textRenderer, "MACRO: " + macro.name, contentWidth, LABEL_FONT, HEADER_COLOR);
        cachedRows = rows;
        lastCacheBuildNanos = now;
    }

    private static void clearCache() {
        cachedMacro = null;
        cachedCurrent = -2147483648;
        cachedTotal = -2147483648;
        cachedScroll = -2147483648;
        cachedVisibleRows = -2147483648;
        cachedPanelWidth = -2147483648;
        cachedMacroName = null;
        cachedTitle = "";
        cachedRows = List.of();
        lastCacheBuildNanos = 0L;
    }
}
