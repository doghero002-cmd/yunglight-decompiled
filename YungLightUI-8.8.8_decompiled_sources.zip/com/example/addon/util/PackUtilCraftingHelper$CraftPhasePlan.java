/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final class PackUtilCraftingHelper.CraftPhasePlan {
    private final int totalCraftsAvailable;
    private final int maxCraftsPerPhase;

    private PackUtilCraftingHelper.CraftPhasePlan(int totalCraftsAvailable, int maxCraftsPerPhase) {
        this.totalCraftsAvailable = Math.max(0, totalCraftsAvailable);
        this.maxCraftsPerPhase = Math.max(0, maxCraftsPerPhase);
    }
}
