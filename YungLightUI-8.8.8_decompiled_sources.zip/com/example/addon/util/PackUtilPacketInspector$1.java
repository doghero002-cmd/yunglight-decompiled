/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketInspector;
import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2824;

class PackUtilPacketInspector.1
implements class_2824.class_5908 {
    final /* synthetic */ PackUtilPacketInspector.InteractionCapture val$capture;

    PackUtilPacketInspector.1() {
        this.val$capture = interactionCapture;
    }

    public void method_34219(class_1268 hand) {
        this.val$capture.kind = "Interact";
        this.val$capture.hand = hand;
    }

    public void method_34220(class_1268 hand, class_243 pos) {
        this.val$capture.kind = "Interact At";
        this.val$capture.hand = hand;
        this.val$capture.hitPos = pos;
    }

    public void method_34218() {
        this.val$capture.kind = "Attack";
    }
}
