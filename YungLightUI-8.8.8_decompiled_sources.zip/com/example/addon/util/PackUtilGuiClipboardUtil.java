/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.macro.MacroExecutor;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_8824;

public final class PackUtilGuiClipboardUtil {
    private static final class_310 MC = class_310.method_1551();
    private static final Gson GSON = new Gson();

    private PackUtilGuiClipboardUtil() {
    }

    public static void copyGuiTitleJson() {
        if (MC.field_1755 == null || MC.field_1774 == null) {
            PackUtilClientMessaging.sendPrefixed("Copy failed: No screen/keyboard.");
            return;
        }
        try {
            class_437 screen = MC.field_1755;
            String json = GSON.toJson((JsonElement)class_8824.field_46597.encodeStart(JsonOps.INSTANCE, MacroExecutor.literalizeTextComponent(screen.method_25440())).getOrThrow());
            MC.field_1774.method_1455(json);
            PackUtilClientMessaging.sendPrefixed("GUI title copied.");
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("Failed to copy GUI title JSON", e);
            PackUtilClientMessaging.sendPrefixed("Copy failed.");
            L99: ;
            return;
        }
    }
}
