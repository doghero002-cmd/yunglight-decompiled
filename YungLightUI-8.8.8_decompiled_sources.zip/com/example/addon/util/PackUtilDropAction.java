/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_1713;

public enum PackUtilDropAction {
    public static final PackUtilDropAction PICKUP = new PackUtilDropAction("PICKUP", 0, "Pickup", "Pick", false);
    public static final PackUtilDropAction QUICK_MOVE = new PackUtilDropAction("QUICK_MOVE", 1, "Quick Move", "QMove", false);
    public static final PackUtilDropAction SWAP = new PackUtilDropAction("SWAP", 2, "Swap", "Swap", false);
    public static final PackUtilDropAction CLONE = new PackUtilDropAction("CLONE", 3, "Clone", "Clone", false);
    public static final PackUtilDropAction THROW = new PackUtilDropAction("THROW", 4, "Throw (2x)", "Throw", false);
    public static final PackUtilDropAction QUICK_CRAFT = new PackUtilDropAction("QUICK_CRAFT", 5, "Quick Craft", "QCraft", false);
    public static final PackUtilDropAction PICKUP_ALL = new PackUtilDropAction("PICKUP_ALL", 6, "Pickup All", "PickAll", false);
    public static final PackUtilDropAction DROP_ITEM = new PackUtilDropAction("DROP_ITEM", 7, "Drop Item (1x)", "Drop1", false);
    public static final PackUtilDropAction DROP_STACK = new PackUtilDropAction("DROP_STACK", 8, "Drop Stack", "DropStk", false);
    public final String displayName;
    public final String shortName;
    public final boolean isPlayerAction;
    private static final /* synthetic */ PackUtilDropAction[] $VALUES;

    public static PackUtilDropAction[] values() {
        return (PackUtilDropAction[])$VALUES.clone();
    }

    public static PackUtilDropAction valueOf(String name) {
        return (PackUtilDropAction)Enum.valueOf(PackUtilDropAction.class, name);
    }

    private PackUtilDropAction(String var1, String var2, boolean displayName) {
        super(var1, var2);
        this.displayName = displayName;
        this.shortName = shortName;
        this.isPlayerAction = isPlayerAction;
    }

    public boolean isSlotAction() {
        return !this.isPlayerAction;
    }

    public boolean usesFixedButton() {
        return this.getButton() >= 0;
    }

    public int getButton() {
        switch (this.ordinal()) {
            case 1::
                return 0;
            case 3::
                return 2;
            case 6::
                return 0;
            case 7::
                return 0;
            case 8::
                return 1;
            case 2::
            case 4::
            case 5::
            default:
                return -1;
        }
    }

    public class_1713 toSlotActionType() {
        if (this.isPlayerAction) {
            throw new IllegalStateException("Cannot convert PlayerAction to SlotActionType: " + String.valueOf(this));
        }
        switch (this.ordinal()) {
            case 0::
                return class_1713.field_7790;
            case 1::
                return class_1713.field_7794;
            case 2::
                return class_1713.field_7791;
            case 3::
                return class_1713.field_7796;
            case 4::
            case 7::
            case 8::
                return class_1713.field_7795;
            case 5::
                return class_1713.field_7789;
            case 6::
                return class_1713.field_7793;
            default:
                throw new IllegalStateException("Unknown action: " + String.valueOf(this));
        }
    }

    static {
        $VALUES = PackUtilDropAction.$values();
    }
}
