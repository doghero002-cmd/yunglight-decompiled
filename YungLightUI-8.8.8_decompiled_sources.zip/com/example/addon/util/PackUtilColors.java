/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiTheme;
import net.minecraft.class_332;

public class PackUtilColors {
    private static final PackUiTheme PACK_UI_THEME = new PackUiTheme();
    private static final int ACCENT = -5093304;
    private static final int ACCENT_SOFT = 1437747272;
    private static final int SURFACE = -284225260;
    private static final int SURFACE_ALT = -300541667;
    private static final int SURFACE_HOVER = -299886051;
    private static final int HEADER = -266792685;
    private static final int HEADER_ACTIVE = -266071017;
    private static final int DIVIDER = 1144726567;
    private static final int OUTER = -1308293624;
    private static final int BORDER = 1716663865;
    private static final int TEXT_PRIMARY = -791058;
    private static final int TEXT_SECONDARY = -3361096;
    private static final int TEXT_MUTED = -6388344;
    private static final int DANGER = -1938838;
    private static final int DANGER_BG = 1428819986;
    private static final int SUCCESS = -9448565;
    private static final int SUCCESS_BG = 1428173866;
    private static final int TOOLTIP = -267382508;
    private static final int PACKET_GREEN = -8592483;
    private static final int PACKET_PINK = -27948;
    private static final int PACKET_ORANGE = -19091;
    private static final int PACKET_BLUE = -8340993;
    private static final int PACKET_YELLOW = -10134;
    private static final int PACKET_CYAN = -9115393;
    private static final int PACKET_WHITE = -461586;
    private static final int PACKET_GRAY = -5195582;
    private static final int PACKET_LIGHT_YELLOW = -3921;

    public static int accent() {
        return -5093304;
    }

    public static int accentSoft() {
        return 1437747272;
    }

    public static int primary() {
        return -5093304;
    }

    public static int primaryDark() {
        return -7522248;
    }

    public static int secondary() {
        return -300541667;
    }

    public static int background() {
        return -284225260;
    }

    public static int border() {
        return 1716663865;
    }

    public static int windowOuter() {
        return -1308293624;
    }

    public static int windowGlass() {
        return -284225260;
    }

    public static int header() {
        return -266792685;
    }

    public static int headerActive() {
        return -266071017;
    }

    public static int divider() {
        return 1144726567;
    }

    public static int buttonBg() {
        return -300541667;
    }

    public static int buttonHoverBg() {
        return -299886051;
    }

    public static int buttonBorder() {
        return 1716663865;
    }

    public static int buttonHover() {
        return PackUtilColors.buttonHoverBg();
    }

    public static int closeHover() {
        return -5093304;
    }

    public static int closeNormal() {
        return -6388344;
    }

    public static int sectionHeaderBg() {
        return 857679146;
    }

    public static int sectionHeaderText() {
        return -3361096;
    }

    public static int actionBg() {
        return -300541667;
    }

    public static int actionBorder() {
        return 1716663865;
    }

    public static int dangerBg() {
        return 1428819986;
    }

    public static int dangerBorder() {
        return -1938838;
    }

    public static int dangerText() {
        return -1938838;
    }

    public static int successBg() {
        return 1428173866;
    }

    public static int successBorder() {
        return -9448565;
    }

    public static int successText() {
        return -9448565;
    }

    public static int packetGreen() {
        return -8592483;
    }

    public static int packetPink() {
        return -27948;
    }

    public static int packetOrange() {
        return -19091;
    }

    public static int packetBlue() {
        return -8340993;
    }

    public static int packetYellow() {
        return -10134;
    }

    public static int packetCyan() {
        return -9115393;
    }

    public static int packetWhite() {
        return -461586;
    }

    public static int packetGray() {
        return -5195582;
    }

    public static int packetLightYellow() {
        return -3921;
    }

    public static int listBg() {
        return -300541667;
    }

    public static int rowNormal() {
        return 572203301;
    }

    public static int rowHover() {
        return 1143352627;
    }

    public static int rowSelected() {
        return -1440597973;
    }

    public static int rowSelectedBorder() {
        return -10035062;
    }

    public static int rowSelectedAccent() {
        return -12531347;
    }

    public static int rowSelectedText() {
        return -2828;
    }

    public static int packetRowBg(boolean c2s, int rowIndex, boolean hovered) {
        if (!hovered) { /* goto L16; */ }
        return c2s ? 1145068152 : 1146173989;
        if (!c2s) { /* goto L34; */ }
        return rowIndex & 1 == 0 ? 539243587 : 405355858;
        return rowIndex & 1 == 0 ? 539632411 : 405939741;
    }

    public static int packetRowText(boolean c2s, int rowIndex) {
        if (!c2s) { /* goto L18; */ }
        return rowIndex & 1 == 0 ? -6496513 : -8861448;
        return rowIndex & 1 == 0 ? -14193 : -20889;
    }

    public static int packetRowSelectedBg(boolean hovered) {
        return hovered ? 1716689763 : 1145075792;
    }

    public static int packetRowSelectedText() {
        return -4787259;
    }

    public static int packetRowSelectedAccent() {
        return -9184882;
    }

    public static int packetRowDivider() {
        return 822083583;
    }

    public static int textPrimary() {
        return -791058;
    }

    public static int textSecondary() {
        return -3361096;
    }

    public static int textDim() {
        return -6388344;
    }

    public static int textMuted() {
        return -6388344;
    }

    public static int textLight() {
        return -791058;
    }

    public static int subPanelBorder() {
        return 1716663865;
    }

    public static int tooltipBg() {
        return -267382508;
    }

    public static int slotNormal() {
        return -4668985;
    }

    public static int slotHover() {
        return -1511694;
    }

    public static int slotSelectedA() {
        return -5093304;
    }

    public static int slotSelectedB() {
        return -7522248;
    }

    public static int slotBorder() {
        return -9997443;
    }

    public static void drawBorder(class_332 ctx, int x, int y, int w, int h, int c) {
        ctx.method_25294(x, y, x + w, y + 1, c);
        ctx.method_25294(x, y + h - 1, x + w, y + h, c);
        ctx.method_25294(x, y, x + 1, y + h, c);
        ctx.method_25294(x + w - 1, y, x + w, y + h, c);
    }

    public static void drawDivider(class_332 ctx, int x, int y, int width, int color) {
        ctx.method_25294(x, y, x + width, y + 1, color);
    }

    public static void drawResizeHandle(class_332 ctx, int x, int y, int size, int color) {
        for (int i = 0; i < 3; i++) {
            int start = x + size - 3 - i * 4;
            ctx.method_25294(start, y + size - 2, start + 2, y + size, color);
            ctx.method_25294(x + size - 2, y + size - 3 - i * 4, x + size, y + size - 1 - i * 4, color);
        }
    }

    public static void drawInsetPanel(class_332 ctx, int x, int y, int w, int h, boolean focused) {
        ctx.method_25294(x, y, x + w, y + h, PackUtilColors.listBg());
        PackUtilColors.drawBorder(ctx, x, y, w, h, focused ? PackUtilColors.accent() : PackUtilColors.subPanelBorder());
    }
}
