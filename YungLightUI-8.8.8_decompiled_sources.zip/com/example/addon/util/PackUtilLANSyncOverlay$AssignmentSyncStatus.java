/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.Map;

private static class PackUtilLANSyncOverlay.AssignmentSyncStatus {
    final Map<String, String> assignments;
    final Map<String, String> missingAssignments;

    PackUtilLANSyncOverlay.AssignmentSyncStatus(Map<String, String> assignments, Map<String, String> missingAssignments) {
        this.assignments = assignments;
        this.missingAssignments = missingAssignments;
    }

    boolean hasAssignments() {
        return !this.assignments.isEmpty();
    }

    boolean canExecute() {
        return this.hasAssignments() && this.missingAssignments.isEmpty();
    }
}
