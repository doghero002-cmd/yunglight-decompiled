/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.macro.DelayAction;
import com.example.addon.util.macro.SendChatAction;
import com.example.addon.util.macro.ToggleModuleAction;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;

public final class PackUtilCompatManager {
    private static final String METEOR_MACROS_CLASS = "meteordevelopment.meteorclient.systems.macros.Macros";
    private static final String METEOR_MACRO_CLASS = "meteordevelopment.meteorclient.systems.macros.Macro";
    private static final String METEOR_MODULES_CLASS = "meteordevelopment.meteorclient.systems.modules.Modules";
    private static final String BARITONE_API_CLASS = "baritone.api.BaritoneAPI";
    private static final String BARITONE_GOAL_CLASS = "baritone.api.pathing.goals.Goal";
    private static final String BARITONE_GOAL_BLOCK_CLASS = "baritone.api.pathing.goals.GoalBlock";

    private PackUtilCompatManager() {
    }

    public static boolean isMeteorAvailable() {
        return FabricLoader.getInstance().isModLoaded("meteor-client") && PackUtilCompatManager.classExists("meteordevelopment.meteorclient.systems.macros.Macros");
    }

    public static boolean isBaritoneAvailable() {
        return FabricLoader.getInstance().isModLoaded("baritone") || PackUtilCompatManager.classExists("baritone.api.BaritoneAPI");
    }

    public static List<PackUtilMacro> getMeteorMacros() {
        if (!PackUtilCompatManager.isMeteorAvailable()) {
            return Collections.emptyList();
        }
        List<PackUtilMacro> macros = new ArrayList();
        try {
            Object meteorMacros = PackUtilCompatManager.getMeteorMacrosSystem();
            Method getAllMethod = meteorMacros.getClass().getMethod("getAll", new Class[0]);
            Object allMacros = getAllMethod.invoke(meteorMacros, new Object[0]);
            if (allMacros instanceof Iterable) {
                Iterable<?> iterable = (Iterable)allMacros;
            } else {
                return macros;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to read Meteor macros reflectively.", e);
            L131: ;
            return macros;
        }
        try {
            var var5 = iterable.iterator();
            while (var5.hasNext()) {
                Object meteorMacro = var5.next();
                PackUtilMacro converted = PackUtilCompatManager.convertMeteorMacro(meteorMacro);
                if (converted == null) continue;
                macros.add(converted);
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to read Meteor macros reflectively.", e);
            L131: ;
            return macros;
        }
        return macros;
    }

    public static List<String> getMeteorMacroNames() {
        List<String> names = new ArrayList();
        var var1 = PackUtilCompatManager.getMeteorMacros().iterator();
        while (var1.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var1.next();
            if (macro != null) {
                if (macro.name != null) {
                    if (macro.name.isBlank()) continue;
                    names.add(macro.name);
                }
            }
        }
        return names;
    }

    public static PackUtilMacro getMeteorMacro(String macroName) {
        if (macroName == null || macroName.isBlank()) {
            return null;
        }
        var var1 = PackUtilCompatManager.getMeteorMacros().iterator();
        while (var1.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var1.next();
            if (!macroName.equalsIgnoreCase(macro.name)) continue;
            return macro;
        }
        return null;
    }

    public static boolean importToMeteor(PackUtilMacro packUtilMacro) {
        return false;
    }

    public static List<String> getMeteorModuleNames() {
        if (!PackUtilCompatManager.isMeteorAvailable()) {
            return Collections.emptyList();
        }
        List<String> names = new ArrayList();
        try {
            Object modulesSystem = PackUtilCompatManager.getMeteorModulesSystem();
            Method getAllMethod = modulesSystem.getClass().getMethod("getAll", new Class[0]);
            Object allModules = getAllMethod.invoke(modulesSystem, new Object[0]);
            if (!allModules instanceof Iterable) { /* goto L131; */ }
            Iterable<?> iterable = (Iterable)allModules;
            var var5 = iterable.iterator();
            while (var5.hasNext()) {
                Object module = var5.next();
                Object name = PackUtilCompatManager.getFieldValue(module, "name");
                if (name instanceof String) {
                    String s = (String)name;
                    if (s.isBlank()) continue;
                    names.add(s);
                }
            }
            names.sort(String::compareToIgnoreCase);
        }
        catch (Exception e) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to read Meteor modules reflectively.", e);
            L157: ;
            return names;
        }
        return names;
    }

    public static boolean toggleMeteorModule(String moduleName, ToggleModuleAction.ToggleMode toggleMode) {
        if (!PackUtilCompatManager.isMeteorAvailable() || moduleName == null || moduleName.isBlank()) {
            return false;
        }
        try {
            Object modulesSystem = PackUtilCompatManager.getMeteorModulesSystem();
            Method getAllMethod = modulesSystem.getClass().getMethod("getAll", new Class[0]);
            Object allModules = getAllMethod.invoke(modulesSystem, new Object[0]);
            Object targetModule = null;
            if (!allModules instanceof Iterable) { /* goto L137; */ }
            Iterable<?> iterable = (Iterable)allModules;
            Method toggleMethod = iterable.iterator();
            while (toggleMethod.hasNext()) {
                Object module = toggleMethod.next();
                Object name = PackUtilCompatManager.getFieldValue(module, "name");
                if (!name instanceof String) { /* goto @134; */ }
                String s = (String)name;
                if (!moduleName.equalsIgnoreCase(s)) { /* goto @134; */ }
                targetModule = module;
                break;
            }
            if (targetModule == null) {
                return false;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to toggle Meteor module '{}' reflectively.", moduleName, e);
            return false;
        }
        try {
            isActiveMethod = targetModule.getClass().getMethod("isActive", new Class[0]);
            toggleMethod = targetModule.getClass().getMethod("toggle", new Class[0]);
            isActive = ((Boolean)isActiveMethod.invoke(targetModule, new Object[0])).booleanValue();
            switch (PackUtilCompatManager.1.$SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[toggleMode.ordinal()]) {
                case 1::
                    if (!isActive) {
                        toggleMethod.invoke(targetModule, new Object[0]);
                    }
                    return true;
                    break;
                case 2::
                    if (isActive) {
                        toggleMethod.invoke(targetModule, new Object[0]);
                    }
                    return true;
                    break;
                default:
                    toggleMethod.invoke(targetModule, new Object[0]);
                    return true;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to toggle Meteor module '{}' reflectively.", moduleName, e);
            return false;
        }
    }

    public static boolean sendBaritoneCommand(class_310 mc, String command) {
        if (!PackUtilCompatManager.isBaritoneAvailable() || mc == null || mc.method_1562() == null || command == null || command.isBlank()) {
            return false;
        }
        mc.method_1562().method_45729(command);
        return true;
    }

    public static boolean startBaritoneGoTo(class_310 mc, int x, int y, int z) {
        if (!PackUtilCompatManager.isBaritoneAvailable()) {
            return false;
        }
        try {
            Object baritone = PackUtilCompatManager.getPrimaryBaritone();
            Object process = PackUtilCompatManager.invokeMethod(baritone, "getCustomGoalProcess");
            Class<?> goalType = Class.forName("baritone.api.pathing.goals.Goal");
            Class<?> goalBlockClass = Class.forName("baritone.api.pathing.goals.GoalBlock");
            Class[] tmp0 = new Class[3];
            tmp0[0] = Integer.TYPE;
            tmp0[1] = Integer.TYPE;
            tmp0[2] = Integer.TYPE;
            Object[] tmp1 = new Object[3];
            tmp1[0] = x;
            tmp1[1] = y;
            tmp1[2] = z;
            Object goal = goalBlockClass.getConstructor(tmp0).newInstance(tmp1);
            PackUtilCompatManager.invokeMethod(process, "setGoalAndPath", goalType, goal);
            return true;
        }
        catch (Throwable t) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to start Baritone goto reflectively, falling back to chat command.", t);
            return PackUtilCompatManager.sendBaritoneCommand(mc, String.format("#goto %d %d %d", x, y, z));
        }
    }

    public static boolean startBaritoneMine(class_310 mc, List<String> blockNames) {
        if (!PackUtilCompatManager.isBaritoneAvailable() || blockNames == null || blockNames.isEmpty()) {
            return false;
        }
        List<String> sanitized = new ArrayList();
        Object baritone = blockNames.iterator();
        while (baritone.hasNext()) {
            String blockName = (String)baritone.next();
            while (blockName == null) {
            }
            String trimmed = blockName.trim();
            while (trimmed.isEmpty()) {
            }
            sanitized.add(trimmed.startsWith("minecraft:") ? trimmed.substring(10) : trimmed);
        }
        if (sanitized.isEmpty()) {
            return false;
        }
        try {
            baritone = PackUtilCompatManager.getPrimaryBaritone();
            process = PackUtilCompatManager.invokeMethod(baritone, "getMineProcess");
            PackUtilCompatManager.invokeMethod(process, "mineByName", String[].class, sanitized.toArray(PackUtilCompatManager::lambda$startBaritoneMine$0));
            return true;
        }
        catch (Throwable t) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to start Baritone mine reflectively, falling back to chat command.", t);
            return PackUtilCompatManager.sendBaritoneCommand(mc, "#mine " + String.join(" ", sanitized));
        }
    }

    public static boolean isBaritoneGoalActive() {
        return PackUtilCompatManager.queryBaritoneProcessActive("getCustomGoalProcess");
    }

    public static boolean isBaritoneMineActive() {
        return PackUtilCompatManager.queryBaritoneProcessActive("getMineProcess");
    }

    public static boolean isBaritonePathing() {
        try {
            Object pathing = PackUtilCompatManager.invokeMethod(PackUtilCompatManager.getPrimaryBaritone(), "getPathingBehavior");
            return PackUtilCompatManager.invokeBoolean(pathing, "isPathing");
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean isBaritoneBusy() {
        if (!PackUtilCompatManager.isBaritoneAvailable()) {
            return false;
        }
        try {
            Object baritone = PackUtilCompatManager.getPrimaryBaritone();
            Object pathing = PackUtilCompatManager.invokeMethod(baritone, "getPathingBehavior");
            boolean pathingNow = PackUtilCompatManager.invokeBoolean(pathing, "isPathing");
            boolean hasPath = PackUtilCompatManager.invokeBoolean(pathing, "hasPath");
            Object inProgress = PackUtilCompatManager.invokeMethod(pathing, "getInProgress");
            Optional<?> optional = (Optional)inProgress;
            if (!optional.isPresent()) { /* goto @72; */ }
            boolean calculating = inProgress instanceof Optional;
            return pathingNow || hasPath || calculating || PackUtilCompatManager.queryProcessActive(baritone, "getCustomGoalProcess") || PackUtilCompatManager.queryProcessActive(baritone, "getMineProcess");
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    public static void stopBaritone(class_310 mc) {
        boolean stoppedReflectively = false;
        try {
            Object baritone = PackUtilCompatManager.getPrimaryBaritone();
            Object pathing = PackUtilCompatManager.invokeMethod(baritone, "getPathingBehavior");
            PackUtilCompatManager.invokeMethod(pathing, "cancelEverything");
            stoppedReflectively = true;
        }
        catch (Throwable t) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to stop Baritone reflectively, falling back to chat command.", t);
            L40: ;
            if (!stoppedReflectively) {
                PackUtilCompatManager.sendBaritoneCommand(mc, "#stop");
            }
            return;
        }
        if (!stoppedReflectively) {
            PackUtilCompatManager.sendBaritoneCommand(mc, "#stop");
        }
    }

    private static PackUtilMacro convertMeteorMacro(Object meteorMacro) {
        if (meteorMacro == null) {
            return null;
        }
        PackUtilMacro macro = new PackUtilMacro();
        String name = null;
        List<String> messages = null;
        Object keybindObj = null;
        Object nameVal = PackUtilCompatManager.getSettingValue(meteorMacro, "name");
        if (nameVal instanceof String) {
            String s = (String)nameVal;
            name = s;
        }
        /* goto L52; */
        msgVal = null;
        L52: ;
        msgVal = PackUtilCompatManager.getSettingValue(meteorMacro, "messages");
        if (msgVal instanceof List) {
            list = (List)msgVal;
            messages = new ArrayList();
            Object group = list.iterator();
            while (group.hasNext()) {
                Object o = group.next();
                if (o instanceof String) {
                    String s = (String)o;
                    messages.add(s);
                }
            }
        } else {
            if (!msgVal instanceof Iterable) { /* goto @220; */ }
            Iterable<?> iter = (Iterable)msgVal;
            messages = new ArrayList();
            Object group = iter.iterator();
            while (group.hasNext()) {
                Object o = group.next();
                if (o instanceof String) {
                    String s = (String)o;
                    messages.add(s);
                }
            }
        }
        /* goto L225; */
        settings = null;
        L225: ;
        keybindObj = PackUtilCompatManager.getSettingValue(meteorMacro, "keybind");
        /* goto L239; */
        settings = null;
        L239: ;
        if (name == null) { /* goto L247; */ }
        if (messages != null) { /* goto L572; */ }
        L247: ;
        settings = PackUtilCompatManager.getFieldValue(meteorMacro, "settings");
        if (!settings instanceof Iterable) { /* goto L554; */ }
        groups = (Iterable)settings;
        trimmed = groups.iterator();
        while (trimmed.hasNext()) {
            group = trimmed.next();
            if (!group instanceof Iterable) { /* goto @551; */ }
            settingIter = (Iterable)group;
            s = settingIter.iterator();
            while (s.hasNext()) {
                Object setting = s.next();
                String sName = (String)setting.getClass().getField("name").get(setting);
                Method getM = setting.getClass().getMethod("get", new Class[0]);
                Object val = getM.invoke(setting, new Object[0]);
                if ("name".equals(sName)) {
                    if (name == null) {
                        if (val instanceof String) {
                            String s = (String)val;
                            name = s;
                        }
                    }
                } else {
                    if ("messages".equals(sName)) {
                        if (messages != null) { /* goto @523; */ }
                        if (!val instanceof List) { /* goto @520; */ }
                        List<?> list = (List)val;
                        messages = new ArrayList();
                        var var17 = list.iterator();
                        while (var17.hasNext()) {
                            Object o = var17.next();
                            if (o instanceof String) {
                                String s = (String)o;
                                messages.add(s);
                            }
                        }
                    } else {
                        if ("keybind".equals(sName)) {
                            if (keybindObj != null) continue;
                            keybindObj = val;
                        }
                    }
                }
                /* goto @548; */
                sName = null;
            }
        }
        /* goto L572; */
        e = null;
        YungLightAddon.LOG.warn("[PackUtil] Settings iteration fallback failed.", e);
        L572: ;
        if (name == null || name.isBlank()) {
            return null;
        }
        macro.name = name;
        if (messages == null) { /* goto L826; */ }
        for (mi = 0; mi < messages.size(); mi++) {
            msg = (String)messages.get(mi);
            if (msg == null) {
            } else {
                trimmed = msg.trim();
                if (trimmed.isEmpty()) {
                } else {
                    if (trimmed.startsWith(".toggle ")) {
                        modName = trimmed.substring(".toggle ".length()).trim();
                        if (modName.isEmpty()) continue;
                        macro.actions.add(new ToggleModuleAction(modName));
                    } else {
                        if (!trimmed.startsWith(".")) { /* goto L769; */ }
                        if (trimmed.startsWith("./")) { /* goto L769; */ }
                        if (trimmed.length() <= 1) { /* goto L769; */ }
                        macro.description = macro.description + macro.description.isEmpty() ? "" : "; " + "Warning: '" + trimmed + "' is a Meteor command, may not work as chat";
                        L769: ;
                        macro.actions.add(new SendChatAction(msg));
                    }
                    if (!mi < messages.size() - 1) continue;
                    macro.actions.add(new DelayAction(50));
                }
            }
        }
        if (keybindObj == null) { /* goto L907; */ }
        getValue = keybindObj.getClass().getMethod("getValue", new Class[0]);
        val = getValue.invoke(keybindObj, new Object[0]);
        if (val instanceof Integer) {
            k = (Integer)val;
            if (k.intValue() != -1) {
                if (k.intValue() != 0) {
                    macro.keyCode = k.intValue();
                }
            }
        }
        /* goto L907; */
        getValue = null;
        L907: ;
        return macro;
    }

    private static Object getMeteorMacrosSystem() throws Exception {
        Class<?> macrosClass = Class.forName("meteordevelopment.meteorclient.systems.macros.Macros");
        Method getMethod = macrosClass.getMethod("get", new Class[0]);
        return getMethod.invoke(null, new Object[0]);
    }

    private static Object getMeteorModulesSystem() throws Exception {
        Class<?> modulesClass = Class.forName("meteordevelopment.meteorclient.systems.modules.Modules");
        Method getMethod = modulesClass.getMethod("get", new Class[0]);
        return getMethod.invoke(null, new Object[0]);
    }

    private static Object getPrimaryBaritone() throws Exception {
        Class<?> apiClass = Class.forName("baritone.api.BaritoneAPI");
        Object provider = apiClass.getMethod("getProvider", new Class[0]).invoke(null, new Object[0]);
        return provider.getClass().getMethod("getPrimaryBaritone", new Class[0]).invoke(provider, new Object[0]);
    }

    private static Object getSettingValue(Object owner, String fieldName) throws Exception {
        Object setting = PackUtilCompatManager.getFieldValue(owner, fieldName);
        if (setting == null) {
            return null;
        }
        Method getMethod = setting.getClass().getMethod("get", new Class[0]);
        return getMethod.invoke(setting, new Object[0]);
    }

    private static void setSettingValue(Object owner, String fieldName, Object value) throws Exception {
        Object setting = PackUtilCompatManager.getFieldValue(owner, fieldName);
        if (setting == null) {
            return;
        }
        Method setMethod = setting.getClass().getMethod("set", Object.class);
        setMethod.invoke(setting, value);
    }

    private static Object getFieldValue(Object owner, String fieldName) throws Exception {
        Field field = owner.getClass().getField(fieldName);
        return field.get(owner);
    }

    private static boolean queryBaritoneProcessActive(String getterName) {
        if (!PackUtilCompatManager.isBaritoneAvailable()) {
            return false;
        }
        try {
            return PackUtilCompatManager.queryProcessActive(PackUtilCompatManager.getPrimaryBaritone(), getterName);
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean queryProcessActive(Object baritone, String getterName) throws Exception {
        Object process = PackUtilCompatManager.invokeMethod(baritone, getterName);
        return PackUtilCompatManager.invokeBoolean(process, "isActive");
    }

    private static boolean invokeBoolean(Object target, String methodName) throws Exception {
        Object value = PackUtilCompatManager.invokeMethod(target, methodName);
        Boolean b = (Boolean)value;
        if (!b.booleanValue()) { /* goto @29; */ }
        return value instanceof Boolean;
    }

    private static Object invokeMethod(Object target, String methodName) throws Exception {
        return target.getClass().getMethod(methodName, new Class[0]).invoke(target, new Object[0]);
    }

    private static Object invokeMethod(Object target, String methodName, Class<?>[] parameterTypes, Object[] args) throws Exception {
        return target.getClass().getMethod(methodName, parameterTypes).invoke(target, args);
    }

    private static boolean classExists(String className) {
        try {
            Class.forName(className);
            return true;
        }
        catch (Throwable ignored) {
            return false;
        }
    }
}
