/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.util.PackUtilCustomFilterPresetOverlay;
import java.util.List;

private final class PackUtilCustomFilterPresetOverlay.PresetListState {
    private int x;
    private int y;
    private int width;
    private int height;
    private final PackUiSmoothScroll scroll = new PackUiSmoothScroll();
    private PackUiScrollbar.Metrics scrollbarMetrics = null;
    private List<PackUtilCustomFilterPresetOverlay.PresetRow> rows = List.of();

    private PackUtilCustomFilterPresetOverlay.PresetListState() {
    }

    private void setBounds(int x, int y, int width, int height, PackUiScrollbar.Metrics scrollbarMetrics) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scrollbarMetrics = scrollbarMetrics;
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
    }

    private PackUtilCustomFilterPresetOverlay.PresetRow getRowAt(double mouseY) {
        int idx = (int)((mouseY - (double)this.y - 2 + (double)this.scroll.visualOffsetInt()) / (double)PackUtilCustomFilterPresetOverlay.this.presetRowStep());
        if (idx < 0 || idx >= this.rows.size()) {
            return null;
        }
        return (PackUtilCustomFilterPresetOverlay.PresetRow)this.rows.get(idx);
    }
}
