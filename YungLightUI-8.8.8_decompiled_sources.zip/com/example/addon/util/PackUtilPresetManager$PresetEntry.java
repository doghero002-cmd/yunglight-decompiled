/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketPreset;

public static final record PackUtilPresetManager.PresetEntry {
    private final PackUtilPacketPreset preset;
    private final boolean builtIn;

    public PackUtilPresetManager.PresetEntry(PackUtilPacketPreset preset, boolean builtIn) {
        this.preset = preset;
        this.builtIn = builtIn;
    }

    public String name() {
        return this.preset != null && this.preset.name != null ? this.preset.name : "";
    }

    public int c2sCount() {
        return this.preset != null && this.preset.c2sPackets != null ? this.preset.c2sPackets.size() : 0;
    }

    public int s2cCount() {
        return this.preset != null && this.preset.s2cPackets != null ? this.preset.s2cPackets.size() : 0;
    }

    public boolean deletable() {
        return !this.builtIn;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public PackUtilPacketPreset preset() {
        return this.preset;
    }

    public boolean builtIn() {
        return this.builtIn;
    }
}
