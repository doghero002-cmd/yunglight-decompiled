/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSurface;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.gui.packui.PackUiWindowNode;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilConfig;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.lwjgl.glfw.GLFW;

public class PackUtilKeybindOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final String WINDOW_TITLE = "Settings";
    private static final String INSIDE_GUI_TOOLTIP = "Fire keybinds while a container screen is open. Blocked when any text field is focused.";
    private static final String INVENTORY_MOVE_TOOLTIP = "Allows movement keys while normal container screens are open. Disabled on text-entry screens and while macros are running.";
    private static final String XCARRY_TOOLTIP = "Keeps crafting-grid items by cancelling the close packet for your inventory screen. Macro XCarry actions still work even when this is off.";
    private static final int MIN_PANEL_WIDTH = 196;
    private static final int ROW_HEIGHT = 18;
    private static final int PAD = 5;
    private static final int HEADER_CONTROL = 12;
    private static final int HEADER_ARROW_WIDTH = 10;
    private static final int HEADER_ARROW_GAP = 3;
    private static final int ROW_LABEL_GAP = 4;
    private static final int BUTTON_GAP = 2;
    private static final int BIND_BTN_W = 36;
    private static final int CLEAR_BTN_W = 12;
    private static final float HEADER_CLICK_DRAG_THRESHOLD = 3f;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiWindowNode windowNode = new PackUiWindowNode("Settings");
    private final PackUiSurface surface = new PackUiSurface(this.theme, this.windowNode);
    private final List<PackUtilKeybindOverlay.KeybindEntry> entries = new ArrayList();
    private final List<PackUtilKeybindOverlay.KeybindRowNode> rowNodes = new ArrayList();
    private int panelX = 160;
    private int panelY = 46;
    private int panelWidth = 196;
    private int panelHeight = 142;
    private boolean visible = false;
    private boolean collapsed = false;
    private boolean dragging = false;
    private float dragOffsetX;
    private float dragOffsetY;
    private float pressStartUiX;
    private float pressStartUiY;
    private int pressStartPanelX;
    private int pressStartPanelY;
    private boolean dragMoved = false;
    private int capturingIndex = -1;
    private float closeHover = 0f;
    private float closeVisibility = 1f;
    private String hoveredTooltip = null;
    private float tooltipUiX;
    private float tooltipUiY;

    public PackUtilKeybindOverlay() {
        this.entries.add(new PackUtilKeybindOverlay.KeybindEntry("Load GUI", "Restores the last saved GUI screen and handler", this::lambda$new$0, this::lambda$new$1));
        this.entries.add(new PackUtilKeybindOverlay.KeybindEntry("Flush Queue", "Sends all queued packets to the server", this::lambda$new$2, this::lambda$new$3));
        this.entries.add(new PackUtilKeybindOverlay.KeybindEntry("Clear Queue", "Discards all queued packets", this::lambda$new$4, this::lambda$new$5));
        this.entries.add(new PackUtilKeybindOverlay.KeybindEntry("Toggle Logger", "Shows or hides the packet logger overlay", this::lambda$new$6, this::lambda$new$7));
        this.entries.add(new PackUtilKeybindOverlay.KeybindEntry("Toggle Send", "Turns packet sending on or off", this::lambda$new$8, this::lambda$new$9));
        this.entries.add(new PackUtilKeybindOverlay.KeybindEntry("Toggle Delay", "Turns packet delay on or off", this::lambda$new$10, this::lambda$new$11));
        this.buildUi();
    }

    private void buildUi() {
        this.windowNode.setCenterTitle(false);
        this.windowNode.setTitleTone(PackUiTone.LABEL);
        this.windowNode.setTitleAreaInsets(this.panelPadding() + 2, this.panelPadding() + this.headerControlSize() + this.headerArrowWidth() + this.headerArrowGap() + 10);
        this.windowNode.content().clearChildren();
        this.windowNode.content().setGap(this.windowContentGap()).setPadding(PackUiInsets.all(this.panelPadding()));
        this.windowNode.content().add(new PackUtilKeybindOverlay.ToggleRowNode(this, "Inside GUI", "Fire keybinds while a container screen is open. Blocked when any text field is focused.", this::lambda$buildUi$12, this::lambda$buildUi$13));
        this.windowNode.content().add(new PackUtilKeybindOverlay.ToggleRowNode(this, "Inv Move", "Allows movement keys while normal container screens are open. Disabled on text-entry screens and while macros are running.", PackUtilKeybindOverlay::lambda$buildUi$14, PackUtilKeybindOverlay::lambda$buildUi$15));
        this.windowNode.content().add(new PackUtilKeybindOverlay.ToggleRowNode(this, "XCarry", "Keeps crafting-grid items by cancelling the close packet for your inventory screen. Macro XCarry actions still work even when this is off.", PackUtilKeybindOverlay::lambda$buildUi$16, PackUtilKeybindOverlay::lambda$buildUi$17));
        this.rowNodes.clear();
        for (int i = 0; i < this.entries.size(); i++) {
            KeybindRowNode row = new PackUtilKeybindOverlay.KeybindRowNode(this, i, (PackUtilKeybindOverlay.KeybindEntry)this.entries.get(i));
            this.rowNodes.add(row);
            this.windowNode.content().add(row);
        }
    }

    private PackUtilConfig getConfig() {
        return PackUtilConfig.getGlobal();
    }

    public String getOverlayId() {
        return "packutil-keybinds";
    }

    public int getMinWidth() {
        return this.computePanelWidth();
    }

    public int getMinHeight() {
        return this.theme.headerHeight() + this.bodyMinimumHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        PackUtilWindowLayout clamped = this.clampToViewport(bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
        this.windowNode.syncShowBody(!this.collapsed);
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        this.hoveredTooltip = null;
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX((double)mouseX);
        float uiMouseY = viewport.toUiY((double)mouseY);
        this.panelWidth = this.computePanelWidth();
        boolean active = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        boolean headerHovered = uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.panelWidth) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
        PackUiRenderContext metrics = new PackUiRenderContext(context, MC.field_1772, viewport, this.theme, uiMouseX, uiMouseY, delta);
        this.windowNode.setShowBody(!this.collapsed);
        this.windowNode.setActive(active);
        this.windowNode.setHeaderHovered(headerHovered);
        this.panelHeight = Math.round(this.windowNode.preferredHeight(metrics, (float)this.panelWidth));
        this.panelHeight = Math.max(this.theme.headerHeight(), this.panelHeight);
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.windowNode.setBounds((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight);
        this.surface.render(context, mouseX, mouseY, delta);
        this.renderHeaderControls(context, viewport, uiMouseX, uiMouseY, delta, active);
        PackUiText.interOverlayFlush(context);
        if (!this.collapsed && this.hoveredTooltip != null) {
            this.renderTooltip(context, viewport, this.hoveredTooltip, this.tooltipUiX, this.tooltipUiY);
        }
    }

    private void renderHeaderControls(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta, boolean active) {
        this.closeVisibility = this.animate(this.closeVisibility, 1f, delta);
        this.closeHover = this.animate(this.closeHover, this.isOverCloseButton(uiMouseX, uiMouseY) ? 1f : 0f, delta);
        viewport.push(context);
        try {
            int arrowX = this.collapseArrowX();
            int closeX = this.closeButtonX();
            int controlY = this.controlButtonY();
            this.drawCollapseArrow(context, arrowX, controlY, active);
            int scaledControlSize = this.headerControlSize();
            this.drawCloseButton(context, closeX, controlY, scaledControlSize, scaledControlSize, this.closeHover, active, this.closeVisibility);
        }
        finally {
            viewport.pop(context);
            throw var11;
        }
    }

    private void drawCollapseArrow(class_332 context, int x, int y, boolean active) {
        PackUiHeaderControls.drawAnimatedArrow(context, x, y + this.iconYOffset(), this.headerArrowWidth(), this.collapsed ? 0f : 1f, active ? 1f : 0.56f);
    }

    private void drawCloseButton(class_332 context, int x, int y, int width, int height, float hover, boolean active, float visibility) {
        PackUiHeaderControls.drawCloseButton(context, x, y, width, height, hover, active, visibility);
    }

    private void renderTooltip(class_332 context, PackUiViewport viewport, String text, float uiX, float uiY) {
        List<String> lines = this.wrapTooltipText(text, this.tooltipMaxWidth());
        int lineH = this.theme.lineHeight(PackUiTone.BODY, 0);
        int maxW = 0;
        int width = lines.iterator();
        while (width.hasNext()) {
            String line = (String)width.next();
            maxW = Math.max(maxW, PackUiText.width(MC.field_1772, line, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY)));
        }
        width = maxW + this.tooltipPadding() * 2;
        height = lines.size() * lineH + this.tooltipPadding() * 2;
        int drawX = Math.round(Math.min(uiX, viewport.uiWidth() - (float)width - (float)(this.tooltipPadding() * 2)));
        int drawY = Math.round(Math.min(uiY, viewport.uiHeight() - (float)height - (float)(this.tooltipPadding() * 2)));
        viewport.push(context);
        try {
            context.method_25294(drawX, drawY, drawX + width, drawY + height, -535818992);
            context.method_25294(drawX, drawY, drawX + width, drawY + 1, -46518);
            context.method_25294(drawX, drawY + height - 1, drawX + width, drawY + height, -46518);
            context.method_25294(drawX, drawY, drawX + 1, drawY + height, -46518);
            context.method_25294(drawX + width - 1, drawY, drawX + width, drawY + height, -46518);
            for (int i = 0; i < lines.size(); i++) {
                PackUiText.draw(context, MC.field_1772, (String)lines.get(i), this.theme.fontFor(PackUiTone.BODY), -987929, drawX + this.tooltipPadding(), drawY + this.tooltipPadding() + i * lineH, false);
            }
        }
        finally {
            viewport.pop(context);
            throw var14;
        }
    }

    private List<String> wrapTooltipText(String text, int maxWidth) {
        List<String> lines = new ArrayList();
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        var var6 = words;
        var var7 = var6.length;
        for (int var8 = 0; var8 < var7; var8++) {
            String word = var6[var8];
            String candidate = line.isEmpty() ? word : String.valueOf(line) + " " + word;
            lines.add(line.toString());
            if (PackUiText.width(MC.field_1772, candidate, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY)) > maxWidth && !line.isEmpty()) {
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (!line.isEmpty()) {
            lines.add(line.toString());
        }
        return lines;
    }

    public static String getKeyName(int keyCode) {
        if (keyCode == -1) {
            return "None";
        }
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null) {
            return name.toUpperCase();
        }
        switch (keyCode) {
            case 290::
                return "F1";
            case 291::
                return "F2";
            case 292::
                return "F3";
            case 293::
                return "F4";
            case 294::
                return "F5";
            case 295::
                return "F6";
            case 296::
                return "F7";
            case 297::
                return "F8";
            case 298::
                return "F9";
            case 299::
                return "F10";
            case 300::
                return "F11";
            case 301::
                return "F12";
            case 340::
                return "L.Shift";
            case 344::
                return "R.Shift";
            case 341::
                return "L.Ctrl";
            case 345::
                return "R.Ctrl";
            case 342::
                return "L.Alt";
            case 346::
                return "R.Alt";
            case 258::
                return "Tab";
            case 280::
                return "CapsLk";
            case 32::
                return "Space";
            case 257::
                return "Enter";
            case 259::
                return "Backsp";
            case 261::
                return "Delete";
            case 260::
                return "Insert";
            case 268::
                return "Home";
            case 269::
                return "End";
            case 266::
                return "PgUp";
            case 267::
                return "PgDn";
            case 265::
                return "Up";
            case 264::
                return "Down";
            case 263::
                return "Left";
            case 262::
                return "Right";
            case 335::
                return "Num Enter";
            case 282::
                return "NumLk";
            case 283::
                return "PrtSc";
            case 281::
                return "ScrLk";
            case 284::
                return "Pause";
            default:
                return "Key " + keyCode;
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        if (this.isOverCloseButton(uiMouseX, uiMouseY)) {
            this.visible = false;
            this.capturingIndex = -1;
            this.dragging = false;
            this.dragMoved = false;
            return true;
        }
        this.dragging = true;
        if (button == 0 && this.isOverHeaderUi(uiMouseX, uiMouseY)) {
            this.dragMoved = false;
            this.dragOffsetX = uiMouseX - (float)this.panelX;
            this.dragOffsetY = uiMouseY - (float)this.panelY;
            this.pressStartUiX = uiMouseX;
            this.pressStartUiY = uiMouseY;
            this.pressStartPanelX = this.panelX;
            this.pressStartPanelY = this.panelY;
            return true;
        }
        if (this.collapsed) {
            return this.isMouseOver(mouseX, mouseY);
        }
        if (this.surface.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.surface.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (!this.visible || this.capturingIndex < 0) {
            return false;
        }
        if (keyCode == 256) {
            this.capturingIndex = -1;
            return true;
        }
        for (int i = 0; i < this.entries.size(); i++) {
            if (i != this.capturingIndex) {
                if (((PackUtilKeybindOverlay.KeybindEntry)this.entries.get(i)).getter.getAsInt() != keyCode) continue;
                ((PackUtilKeybindOverlay.KeybindEntry)this.entries.get(i)).setter.accept(-1);
            }
        }
        ((PackUtilKeybindOverlay.KeybindEntry)this.entries.get(this.capturingIndex)).setter.accept(keyCode);
        this.getConfig().save();
        this.capturingIndex = -1;
        return true;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (!this.dragging) { /* goto L53; */ }
        boolean shouldCollapse = !this.dragMoved;
        this.dragging = false;
        if (!shouldCollapse) { /* goto L47; */ }
        this.collapsed = !this.collapsed;
        this.saveLayout();
        return true;
        if (this.collapsed) {
            return false;
        }
        return this.surface.mouseReleased(mouseX, mouseY, button);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!this.dragging) { /* goto L171; */ }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(Math.round(uiMouseX - this.dragOffsetX), Math.round(uiMouseY - this.dragOffsetY), this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        if (this.dragMoved) { /* goto L161; */ }
        if (Math.abs(uiMouseX - this.pressStartUiX) >= 3f) { /* goto L161; */ }
        if (Math.abs(uiMouseY - this.pressStartUiY) >= 3f) { /* goto L161; */ }
        if (this.panelX != this.pressStartPanelX) { /* goto L161; */ }
        this.dragMoved = this.panelY != this.pressStartPanelY;
        return true;
        if (this.collapsed) {
            return false;
        }
        return this.surface.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (this.collapsed) {
            return false;
        }
        return this.surface.mouseScrolled(mouseX, mouseY, amount);
    }

    public boolean charTyped(char chr, int modifiers) {
        return this.surface.charTyped(chr, modifiers);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean v) {
        this.visible = v;
        if (!v) {
            this.capturingIndex = -1;
            this.dragging = false;
            this.dragMoved = false;
        } else {
            this.windowNode.syncShowBody(!this.collapsed);
            PackUtilOverlayManager.get().bringToFront(this);
        }
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiX = viewport.toUiX(mouseX);
        float uiY = viewport.toUiY(mouseY);
        return uiX >= (float)this.panelX && uiX < (float)(this.panelX + this.panelWidth) && uiY >= (float)this.panelY && uiY < (float)(this.panelY + this.panelHeight);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        return this.isOverDragBarUi(viewport.toUiX(mouseX), viewport.toUiY(mouseY));
    }

    private boolean isOverDragBarUi(float uiMouseX, float uiMouseY) {
        return uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.closeButtonX() - this.headerControlInset()) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
    }

    private boolean isOverHeaderUi(float uiMouseX, float uiMouseY) {
        return uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.panelWidth) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean c) {
        this.collapsed = c;
        this.windowNode.syncShowBody(!this.collapsed);
    }

    public boolean hasTextFieldFocused() {
        return this.surface.hasFocusedTextInput();
    }

    public boolean wantsKeyboardCapture() {
        return this.visible && this.capturingIndex >= 0;
    }

    public void clearTextFieldFocus() {
        this.surface.clearFocusedTextInputs();
    }

    private boolean isOverCloseButton(float uiMouseX, float uiMouseY) {
        return PackUiHeaderControls.isCloseHit(this.closeVisibility, (double)uiMouseX, (double)uiMouseY, this.closeButtonX(), this.controlButtonY(), this.headerControlSize());
    }

    private int controlButtonY() {
        return PackUiHeaderControls.controlY(this.panelY, this.theme.headerHeight(), this.headerControlSize());
    }

    private int closeButtonX() {
        return PackUiHeaderControls.closeX(this.panelX, this.panelWidth, this.headerControlSize(), this.headerControlInset());
    }

    private int collapseArrowX() {
        return PackUiHeaderControls.expandedArrowX(this.closeButtonX(), this.headerArrowGap(), this.headerArrowWidth());
    }

    private PackUtilWindowLayout clampToViewport(PackUtilWindowLayout bounds) {
        PackUiViewport viewport = this.surface.viewport();
        int width = Math.max(this.getMinWidth(), Math.min(bounds.width, Math.round(viewport.uiWidth())));
        int minHeight = bounds.collapsed ? this.theme.headerHeight() : this.getMinHeight();
        int height = Math.max(minHeight, Math.min(bounds.height, Math.round(viewport.uiHeight())));
        int x = Math.max(0, Math.min(bounds.x, Math.max(0, Math.round(viewport.uiWidth()) - width)));
        int y = Math.max(0, Math.min(bounds.y, Math.max(0, Math.round(viewport.uiHeight()) - this.theme.headerHeight())));
        return new PackUtilWindowLayout(x, y, width, height, bounds.visible, bounds.collapsed);
    }

    private int computeLabelColumnWidth() {
        if (MC.field_1772 == null) {
            return this.labelColumnFallbackWidth();
        }
        List<String> labels = new ArrayList(this.entries.size());
        var var2 = this.entries.iterator();
        while (var2.hasNext()) {
            KeybindEntry entry = (PackUtilKeybindOverlay.KeybindEntry)var2.next();
            labels.add(entry.label);
        }
        return Math.max(this.labelColumnMinimumWidth(), PackUiSizing.measureWidestText(MC.field_1772, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY), labels) + this.labelColumnExtraWidth());
    }

    private int computeBodyWidth() {
        if (MC.field_1772 == null) {
            return 186;
        }
        int keybindWidth = this.computeLabelColumnWidth() + this.rowLabelGap() + this.bindButtonWidth() + this.buttonGap() + this.clearButtonWidth();
        return keybindWidth;
    }

    private int computePanelWidth() {
        if (MC.field_1772 == null) {
            return 196;
        }
        int headerReserve = this.headerControlSize() + this.headerArrowWidth() + this.headerArrowGap() + this.panelPadding() * 2 + 14;
        int titleWidth = PackUiText.width(MC.field_1772, "Settings", this.theme.fontFor(PackUiTone.TITLE), this.theme.color(PackUiTone.TITLE));
        return Math.max(this.panelMinimumWidth(), Math.max(this.computeBodyWidth() + this.panelPadding() * 2, titleWidth + headerReserve + this.panelPadding()));
    }

    private String bindButtonText(int index, PackUtilKeybindOverlay.KeybindEntry entry) {
        if (this.capturingIndex == index) {
            return "PRESS";
        }
        int keyCode = entry.getter.getAsInt();
        return keyCode == -1 ? "NONE" : PackUtilKeybindOverlay.getKeyName(keyCode);
    }

    private float animate(float current, float target, float delta) {
        return PackUiHeaderControls.animate(current, target, delta);
    }

    private int panelMinimumWidth() {
        return 196;
    }

    private int panelPadding() {
        return 5;
    }

    private int windowContentGap() {
        return 2;
    }

    private int bodyMinimumHeight() {
        return 20;
    }

    private int headerControlSize() {
        return 11;
    }

    private int headerControlInset() {
        return 2;
    }

    private int headerArrowWidth() {
        return 10;
    }

    private int headerArrowGap() {
        return 3;
    }

    private int iconYOffset() {
        return 1;
    }

    private int tooltipMaxWidth() {
        return 180;
    }

    private int tooltipPadding() {
        return 3;
    }

    private int tooltipOffsetX() {
        return 8;
    }

    private int tooltipOffsetY() {
        return 2;
    }

    private int labelColumnFallbackWidth() {
        return 90;
    }

    private int labelColumnMinimumWidth() {
        return 74;
    }

    private int labelColumnExtraWidth() {
        return 2;
    }

    private int rowLabelGap() {
        return 4;
    }

    private int buttonGap() {
        return 2;
    }

    private int bindButtonWidth() {
        return 36;
    }

    private int clearButtonWidth() {
        return 12;
    }

    private int bindButtonPadding() {
        return 3;
    }

    private int chooserButtonHeight() {
        return 16;
    }

    private int rowHeight() {
        return 19;
    }
}
