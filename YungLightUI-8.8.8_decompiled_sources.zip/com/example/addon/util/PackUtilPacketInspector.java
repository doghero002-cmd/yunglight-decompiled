/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilYarnMappings;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_10264;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2620;
import net.minecraft.class_2649;
import net.minecraft.class_2651;
import net.minecraft.class_2653;
import net.minecraft.class_2661;
import net.minecraft.class_2663;
import net.minecraft.class_2668;
import net.minecraft.class_2672;
import net.minecraft.class_2680;
import net.minecraft.class_2739;
import net.minecraft.class_2743;
import net.minecraft.class_2744;
import net.minecraft.class_2767;
import net.minecraft.class_2797;
import net.minecraft.class_2811;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2820;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2840;
import net.minecraft.class_2846;
import net.minecraft.class_2855;
import net.minecraft.class_2863;
import net.minecraft.class_2868;
import net.minecraft.class_2873;
import net.minecraft.class_2877;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3895;
import net.minecraft.class_3944;
import net.minecraft.class_3965;
import net.minecraft.class_4463;
import net.minecraft.class_5894;
import net.minecraft.class_640;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_7438;
import net.minecraft.class_7439;
import net.minecraft.class_7827;
import net.minecraft.class_7923;

public final class PackUtilPacketInspector {
    private static final class_310 MC = class_310.method_1551();
    private static final Object INACCESSIBLE = new Object();
    private static final Pattern SIMPLE_CLASS_ALIAS_PATTERN = Pattern.compile("(?<![\\w$.])(class_\\d+)(?=[\\[{(:\\s]|$)");
    private static final Pattern QUALIFIED_CLASS_ALIAS_PATTERN = Pattern.compile("(net\\.minecraft(?:\\.[\\w$]+)*\\.class_\\d+)(?=[\\[{(:\\s]|$)");
    private static final int MAX_DEPTH = 7;
    private static final int MAX_LINES = 900;
    private static final int MAX_COLLECTION_ITEMS = 64;
    private static final int MAX_ARRAY_ITEMS = 64;
    private static final int MAX_STRING_LENGTH = 320;
    private static final int MAX_GENERIC_SUMMARY_LINES = 8;
    private static final Set<String> IGNORED_PROPERTY_METHODS;
    private static final Set<String> IGNORED_PROPERTY_NORMALIZED;
    private static final Set<String> EXTRA_ACCESSOR_NAMES;

    private PackUtilPacketInspector() {
    }

    public static PackUtilPacketInspector.PacketInspection inspectSafe(PackUtilPacketLoggerOverlay.LogEntry entry) {
        /* decompile fallback: stack underflow while reading invokedynamic args: need 2, have 1 @ offset 183 opcode invokedynamic (stack_before=1) */
        /* decompile technical detail:
         * category: other
         * stage: operand_stack_simulation
         * detail: stack underflow while reading invokedynamic args: need 2, have 1 @ offset 183 opcode invokedynamic (stack_before=1)
         * explanation: the simulated JVM operand stack became inconsistent at the reported bytecode offset and opcode, so structured Java emission was aborted
         * emitted_body: raw bytecode disassembly follows
         */
        /* @obfuscation score:2/10 signals:fallback_stack_underflow hint:complex but likely not obfuscated — LLM should do well */
        /* bytecode:
          0000: aload_0
          0001: invokestatic #109 // com.example.addon.util.PackUtilPacketInspector.inspect(Lcom.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry;)Lcom.example.addon.util.PackUtilPacketInspector$PacketInspection;
          0004: areturn
          0005: astore_1
          0006: new #9 // class com.example.addon.util.PackUtilPacketInspector$InspectionBuilder
          0009: dup
          000a: aload_0
          000b: getfield #113 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.shortName:Ljava.lang.String;
          000e: aload_0
          000f: getfield #116 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.direction:Ljava.lang.String;
          0012: invokedynamic #128 // invokedynamic(bsm=0) makeConcatWithConstants(Ljava.lang.String;Ljava.lang.String;)Ljava.lang.String;
          0017: invokespecial #131 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.<init>(Ljava.lang.String;)V
          001a: astore_2
          001b: aload_2
          001c: ldc #133 // "Meta"
          001e: invokestatic #139 // com.example.addon.util.PackUtilColors.packetLightYellow()I
          0021: invokevirtual #143 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.section(Ljava.lang.String;I)V
          0024: aload_2
          0025: aload_0
          0026: getfield #113 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.shortName:Ljava.lang.String;
          0029: invokedynamic #148 // invokedynamic(bsm=1) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          002e: invokestatic #151 // com.example.addon.util.PackUtilColors.packetWhite()I
          0031: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          0034: aload_2
          0035: aload_0
          0036: getfield #116 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.direction:Ljava.lang.String;
          0039: invokedynamic #157 // invokedynamic(bsm=2) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          003e: aload_0
          003f: getfield #116 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.direction:Ljava.lang.String;
          0042: invokestatic #161 // com.example.addon.util.PackUtilPacketInspector.directionColor(Ljava.lang.String;)I
          0045: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          0048: aload_2
          0049: aload_0
          004a: getfield #165 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.packetClass:Ljava.lang.Class;
          004d: invokevirtual #171 // java.lang.Class.getName()Ljava.lang.String;
          0050: invokedynamic #174 // invokedynamic(bsm=3) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          0055: invokestatic #177 // com.example.addon.util.PackUtilColors.textSecondary()I
          0058: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          005b: aload_2
          005c: aload_0
          005d: getfield #180 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.gameTick:I
          0060: invokedynamic #185 // invokedynamic(bsm=4) makeConcatWithConstants(I)Ljava.lang.String;
          0065: invokestatic #177 // com.example.addon.util.PackUtilColors.textSecondary()I
          0068: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          006b: aload_2
          006c: aload_0
          006d: getfield #189 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.timestampMs:J
          0070: invokestatic #195 // java.time.Instant.ofEpochMilli(J)Ljava.time.Instant;
          0073: invokestatic #201 // java.lang.String.valueOf(Ljava.lang.Object;)Ljava.lang.String;
          0076: invokedynamic #204 // invokedynamic(bsm=5) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          007b: invokestatic #177 // com.example.addon.util.PackUtilColors.textSecondary()I
          007e: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          0081: aload_2
          0082: invokevirtual #207 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.blank()V
          0085: aload_2
          0086: ldc #209 // "Inspect Error"
          0088: invokestatic #212 // com.example.addon.util.PackUtilColors.dangerText()I
          008b: invokevirtual #143 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.section(Ljava.lang.String;I)V
          008e: aload_2
          008f: ldc #214 // "The detailed inspector failed on this packet, so this fallback view was opened instead."
          0091: invokestatic #212 // com.example.addon.util.PackUtilColors.dangerText()I
          0094: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          0097: aload_2
          0098: aload_1
          0099: invokevirtual #218 // java.lang.Object.getClass()Ljava.lang.Class;
          009c: invokevirtual #221 // java.lang.Class.getSimpleName()Ljava.lang.String;
          009f: aload_1
          00a0: invokevirtual #224 // java.lang.Throwable.getMessage()Ljava.lang.String;
          00a3: ifnonnull 171
          00a6: ldc #226 // ""
          00a8: goto 183
          00ab: aload_1
          00ac: invokevirtual #224 // java.lang.Throwable.getMessage()Ljava.lang.String;
          00af: invokestatic #229 // com.example.addon.util.PackUtilPacketInspector.shorten(Ljava.lang.String;)Ljava.lang.String;
          00b2: invokedynamic #232 // invokedynamic(bsm=6) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          00b7: invokedynamic #235 // invokedynamic(bsm=7) makeConcatWithConstants(Ljava.lang.String;Ljava.lang.String;)Ljava.lang.String;
          00bc: invokestatic #212 // com.example.addon.util.PackUtilColors.dangerText()I
          00bf: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          00c2: aload_0
          00c3: getfield #239 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.packetRef:Lnet.minecraft.class_2596;
          00c6: ifnull 260
          00c9: aload_2
          00ca: invokevirtual #207 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.blank()V
          00cd: aload_2
          00ce: ldc #241 // "Fallback"
          00d0: invokestatic #244 // com.example.addon.util.PackUtilColors.packetYellow()I
          00d3: invokevirtual #143 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.section(Ljava.lang.String;I)V
          00d6: aload_2
          00d7: aload_0
          00d8: getfield #239 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.packetRef:Lnet.minecraft.class_2596;
          00db: ldc #246 // "getPacketType"
          00dd: invokestatic #250 // com.example.addon.util.PackUtilPacketInspector.invokeNoArg(Ljava.lang.Object;Ljava.lang.String;)Ljava.lang.Object;
          00e0: invokestatic #253 // com.example.addon.util.PackUtilPacketInspector.safeLeafString(Ljava.lang.Object;)Ljava.lang.String;
          00e3: invokedynamic #256 // invokedynamic(bsm=8) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          00e8: invokestatic #177 // com.example.addon.util.PackUtilColors.textSecondary()I
          00eb: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          00ee: aload_2
          00ef: aload_0
          00f0: getfield #239 // com.example.addon.util.PackUtilPacketLoggerOverlay$LogEntry.packetRef:Lnet.minecraft.class_2596;
          00f3: invokestatic #201 // java.lang.String.valueOf(Ljava.lang.Object;)Ljava.lang.String;
          00f6: invokestatic #229 // com.example.addon.util.PackUtilPacketInspector.shorten(Ljava.lang.String;)Ljava.lang.String;
          00f9: invokedynamic #259 // invokedynamic(bsm=9) makeConcatWithConstants(Ljava.lang.String;)Ljava.lang.String;
          00fe: invokestatic #262 // com.example.addon.util.PackUtilColors.textMuted()I
          0101: invokevirtual #154 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.line(Ljava.lang.String;I)V
          0104: aload_2
          0105: invokevirtual #266 // com.example.addon.util.PackUtilPacketInspector$InspectionBuilder.build()Lcom.example.addon.util.PackUtilPacketInspector$PacketInspection;
          0108: areturn
        */
    }

    public static PackUtilPacketInspector.PacketInspection inspect(PackUtilPacketLoggerOverlay.LogEntry entry) {
        String title = entry.shortName + " [" + entry.direction + "]";
        InspectionBuilder builder = new PackUtilPacketInspector.InspectionBuilder(title);
        builder.section("Meta", PackUtilColors.packetLightYellow());
        builder.line("Name: " + entry.shortName, PackUtilColors.packetWhite());
        builder.line("Direction: " + entry.direction, PackUtilPacketInspector.directionColor(entry.direction));
        builder.line("Class: " + entry.packetClass.getName(), PackUtilColors.textSecondary());
        Object packetType = PackUtilPacketInspector.invokeNoArg(entry.packetRef, "getPacketType");
        if (packetType != null) {
            builder.line("Packet Type: " + PackUtilPacketInspector.safeLeafString(packetType), PackUtilColors.textSecondary());
        }
        builder.line("Tick: " + entry.gameTick, PackUtilColors.textSecondary());
        builder.line("Time: " + String.valueOf(Instant.ofEpochMilli(entry.timestampMs)), PackUtilColors.textSecondary());
        builder.line("Inventory: " + entry.isInventory + " | Movement: " + entry.isMovement, PackUtilColors.textMuted());
        if (entry.packetRef == null) {
            builder.blank();
            builder.section("Summary", PackUtilColors.packetCyan());
            builder.line("Packet instance is missing, so only metadata is available.", PackUtilColors.dangerText());
            return builder.build();
        }
        InspectionBuilder summaryBuilder = new PackUtilPacketInspector.InspectionBuilder(title);
        SummaryResult summary = PackUtilPacketInspector.appendSummary(entry.packetRef, entry.shortName, entry, summaryBuilder);
        if (summary.wroteAny()) {
            builder.blank();
            builder.section("Summary", PackUtilColors.packetCyan());
            builder.appendFrom(summaryBuilder);
        }
        if (!summary.complete()) {
            builder.blank();
            builder.section("Details", PackUtilColors.packetBlue());
            PackUtilPacketInspector.dumpRootFields(entry.packetRef, builder, new IdentityHashMap());
        }
        return builder.build();
    }

    private static PackUtilPacketInspector.SummaryResult appendSummary(class_2596<?> packet, String packetNameHint, PackUtilPacketLoggerOverlay.LogEntry entry, PackUtilPacketInspector.InspectionBuilder builder) {
        SummaryResult packetSpecific = PackUtilPacketInspector.appendPacketSpecificSummary(packet, packetNameHint, entry, builder);
        if (packetSpecific.wroteAny()) {
            return packetSpecific;
        }
        return PackUtilPacketInspector.appendGenericSummary(packet, builder);
    }

    private static PackUtilPacketInspector.SummaryResult appendPacketSpecificSummary(class_2596<?> packet, String packetNameHint, PackUtilPacketLoggerOverlay.LogEntry entry, PackUtilPacketInspector.InspectionBuilder builder) {
        boolean wrote = false;
        boolean complete = false;
        if (!packet instanceof class_2846) { /* goto L264; */ }
        class_2846 playerAction = (class_2846)packet;
        wrote = true;
        complete = true;
        builder.line("Action: " + String.valueOf(playerAction.method_12363()), PackUtilColors.textPrimary());
        builder.line("Meaning: " + PackUtilPacketInspector.describePlayerAction(playerAction.method_12363()), PackUtilColors.textPrimary());
        builder.line("Block Pos: " + PackUtilPacketInspector.formatBlockPos(playerAction.method_12362()), PackUtilColors.textPrimary());
        builder.line("Face: " + String.valueOf(playerAction.method_12360()), PackUtilColors.textPrimary());
        builder.line("Sequence: " + playerAction.method_42079(), PackUtilColors.textSecondary());
        String capturedBlockState = entry == null ? null : entry.capturedBlockState;
        if (capturedBlockState != null) {
            if (!capturedBlockState.isBlank()) {
                builder.line("Block: " + capturedBlockState, PackUtilColors.successText());
            }
        } else {
            class_2680 state = PackUtilPacketInspector.getWorldBlockState(playerAction.method_12362());
            if (state != null) {
                builder.line("Block: " + PackUtilPacketInspector.formatBlockState(state), PackUtilColors.successText());
            }
        }
        if (MC.field_1724 != null) {
            if (playerAction.method_12363() == class_2846.class_2847.field_12975 || playerAction.method_12363() == class_2846.class_2847.field_12970 || playerAction.method_12363() == class_2846.class_2847.field_12974) {
                builder.line("Held Item: " + PackUtilPacketInspector.formatItemStack(MC.field_1724.method_6047()), PackUtilColors.successText());
            }
        }
        if (!packet instanceof class_2885) { /* goto L528; */ }
        interactBlock = (class_2885)packet;
        hit = interactBlock.method_12543();
        wrote = true;
        complete = true;
        builder.line("Interaction: Use Block (right click targeted block)", PackUtilColors.textPrimary());
        builder.line("Hand: " + String.valueOf(interactBlock.method_12546()), PackUtilColors.textPrimary());
        builder.line("Block Pos: " + PackUtilPacketInspector.formatBlockPos(hit.method_17777()), PackUtilColors.textPrimary());
        builder.line("Side: " + String.valueOf(hit.method_17780()), PackUtilColors.textPrimary());
        builder.line("Hit Pos: " + PackUtilPacketInspector.formatVec3(hit.method_17784()), PackUtilColors.textPrimary());
        builder.line("Inside Block: " + hit.method_17781(), PackUtilColors.textPrimary());
        builder.line("Sequence: " + interactBlock.method_42080(), PackUtilColors.textSecondary());
        if (MC.field_1724 != null) {
            builder.line("Held Item: " + PackUtilPacketInspector.formatItemStack(MC.field_1724.method_5998(interactBlock.method_12546())), PackUtilColors.successText());
        }
        capturedBlockState = entry == null ? null : entry.capturedBlockState;
        if (capturedBlockState != null) {
            if (!capturedBlockState.isBlank()) {
                builder.line("Block: " + capturedBlockState, PackUtilColors.successText());
            }
        } else {
            class_2680 state = PackUtilPacketInspector.getWorldBlockState(hit.method_17777());
            if (state != null) {
                builder.line("Block: " + PackUtilPacketInspector.formatBlockState(state), PackUtilColors.successText());
            }
        }
        if (packet instanceof class_2886) {
            interactItem = (class_2886)packet;
            wrote = true;
            complete = true;
            builder.line("Interaction: Use Item (right click without a targeted block)", PackUtilColors.textPrimary());
            builder.line("Hand: " + String.valueOf(interactItem.method_12551()), PackUtilColors.textPrimary());
            builder.line("Sequence: " + interactItem.method_42081(), PackUtilColors.textSecondary());
            builder.line("Yaw: " + interactItem.method_60586(), PackUtilColors.textSecondary());
            builder.line("Pitch: " + interactItem.method_60587(), PackUtilColors.textSecondary());
            if (MC.field_1724 != null) {
                selectedSlot = PackUtilPacketInspector.invokeFirstNoArg(MC.field_1724.method_31548(), "getSelectedSlot", "selectedSlot");
                if (selectedSlot instanceof Number) {
                    number = (Number)selectedSlot;
                    builder.line("Selected Slot: " + PackUtilPacketInspector.formatHotbarSlot(number.intValue()), PackUtilColors.textPrimary());
                }
                builder.line("Held Item: " + PackUtilPacketInspector.formatItemStack(MC.field_1724.method_5998(interactItem.method_12551())), PackUtilColors.successText());
            }
        }
        if (!packet instanceof class_2824) { /* goto L973; */ }
        interactEntity = (class_2824)packet;
        wrote = true;
        complete = true;
        entityId = PackUtilPacketInspector.getIntField(interactEntity, "entityId");
        if (entityId == null) { /* goto L830; */ }
        builder.line("Entity Id: " + entityId, PackUtilColors.textPrimary());
        entity = MC.field_1687 != null ? MC.field_1687.method_8469(entityId.intValue()) : null;
        if (entity != null) {
            builder.line("Entity: " + PackUtilPacketInspector.formatEntity(entity), PackUtilColors.successText());
        }
        builder.line("Player Sneaking: " + interactEntity.method_30007(), PackUtilColors.textPrimary());
        capture = PackUtilPacketInspector.captureInteraction(interactEntity);
        if (capture.kind != null) {
            builder.line("Interaction: " + capture.kind, PackUtilColors.textPrimary());
        }
        if (capture.hand != null) {
            builder.line("Hand: " + String.valueOf(capture.hand), PackUtilColors.textPrimary());
            if (MC.field_1724 != null) {
                builder.line("Held Item: " + PackUtilPacketInspector.formatItemStack(MC.field_1724.method_5998(capture.hand)), PackUtilColors.successText());
            }
        }
        if (capture.hitPos != null) {
            builder.line("Hit Pos: " + PackUtilPacketInspector.formatVec3(capture.hitPos), PackUtilColors.textPrimary());
        }
        if (packet instanceof class_3944) {
            openScreen = (class_3944)packet;
            wrote = true;
            complete = true;
            builder.line("Sync Id: " + openScreen.method_17592(), PackUtilColors.textPrimary());
            builder.line("Screen Type: " + PackUtilPacketInspector.safeLeafString(openScreen.method_17593()), PackUtilColors.textPrimary());
            builder.line("Title: " + PackUtilPacketInspector.formatSimpleValue(openScreen.method_17594()), PackUtilColors.successText());
        }
        if (packet instanceof class_2653) {
            slotUpdate = (class_2653)packet;
            wrote = true;
            complete = true;
            builder.line("Sync Id: " + slotUpdate.method_11452(), PackUtilColors.textPrimary());
            builder.line("Revision: " + slotUpdate.method_37439(), PackUtilColors.textSecondary());
            builder.line("Slot: " + slotUpdate.method_11450(), PackUtilColors.textPrimary());
            builder.line("Stack: " + PackUtilPacketInspector.formatItemStack(slotUpdate.method_11449()), PackUtilColors.successText());
        }
        if (packet instanceof class_2649) {
            inventory = (class_2649)packet;
            wrote = true;
            builder.line("Sync Id: " + inventory.comp_3837(), PackUtilColors.textPrimary());
            builder.line("Revision: " + inventory.comp_3838(), PackUtilColors.textSecondary());
            builder.line("Items: " + inventory.comp_3839().size() + " slots (" + PackUtilPacketInspector.countNonEmpty(inventory.comp_3839()) + " non-empty)", PackUtilColors.textPrimary());
            builder.line("Cursor: " + PackUtilPacketInspector.formatItemStack(inventory.comp_3840()), PackUtilColors.successText());
        }
        if (packet instanceof class_2672) {
            chunkData = (class_2672)packet;
            wrote = true;
            builder.line("Chunk: " + chunkData.method_11523() + ", " + chunkData.method_11524(), PackUtilColors.textPrimary());
            builder.line("Chunk Data: " + PackUtilPacketInspector.safeLeafString(chunkData.method_38598()), PackUtilColors.textSecondary());
            builder.line("Light Data: " + PackUtilPacketInspector.safeLeafString(chunkData.method_38599()), PackUtilColors.textSecondary());
        }
        if (packet instanceof class_10264) {
            positionSync = (class_10264)packet;
            wrote = true;
            builder.line("Entity Id: " + positionSync.comp_3223(), PackUtilColors.textPrimary());
            builder.line("Values: " + PackUtilPacketInspector.safeLeafString(positionSync.comp_3224()), PackUtilColors.textPrimary());
            builder.line("On Ground: " + positionSync.comp_3225(), PackUtilColors.textPrimary());
        }
        if (!packet instanceof class_2739) { /* goto L1455; */ }
        trackerUpdate = (class_2739)packet;
        wrote = true;
        builder.line("Entity Id: " + trackerUpdate.comp_1127(), PackUtilColors.textPrimary());
        trackedValues = trackerUpdate.comp_1128();
        builder.line("Tracked Values: " + trackedValues == null ? 0 : trackedValues.size(), PackUtilColors.textPrimary());
        L1455: ;
        if (packet instanceof class_2767) {
            soundPacket = (class_2767)packet;
            wrote = true;
            complete = true;
            builder.line("Sound: " + PackUtilPacketInspector.formatRegistryEntry(soundPacket.method_11894()), PackUtilColors.successText());
            builder.line("Category: " + String.valueOf(soundPacket.method_11888()), PackUtilColors.textPrimary());
            builder.line("Pos: " + PackUtilPacketInspector.formatVec3(new class_243(soundPacket.method_11890(), soundPacket.method_11889(), soundPacket.method_11893())), PackUtilColors.textPrimary());
            builder.line("Volume: " + soundPacket.method_11891(), PackUtilColors.textSecondary());
            builder.line("Pitch: " + soundPacket.method_11892(), PackUtilColors.textSecondary());
            builder.line("Seed: " + soundPacket.method_43236(), PackUtilColors.textMuted());
        }
        if (packet instanceof class_2668) {
            gameState = (class_2668)packet;
            wrote = true;
            complete = true;
            builder.line("Reason: " + PackUtilPacketInspector.safeLeafString(gameState.method_11491()), PackUtilColors.textPrimary());
            builder.line("Value: " + gameState.method_11492(), PackUtilColors.textPrimary());
        }
        reflective = PackUtilPacketInspector.appendReflectivePacketSummary(packet, packetNameHint, entry, builder);
        if (!wrote && reflective.wroteAny()) {
            return reflective;
        }
        return new PackUtilPacketInspector.SummaryResult(wrote, complete);
    }

    private static PackUtilPacketInspector.SummaryResult appendGenericSummary(class_2596<?> packet, PackUtilPacketInspector.InspectionBuilder builder) {
        List<PackUtilPacketInspector.PropertyValue> properties = PackUtilPacketInspector.getInspectableProperties(packet);
        if (properties.isEmpty()) {
            String rawFallback = PackUtilPacketInspector.rawFallbackString(packet);
            if (rawFallback != null) {
                builder.line("Raw: " + rawFallback, PackUtilColors.textMuted());
                return new PackUtilPacketInspector.SummaryResult(true, false);
            }
            return PackUtilPacketInspector.SummaryResult.NONE;
        }
        lines = 0;
        var var4 = properties.iterator();
        while (var4.hasNext()) {
            PropertyValue property = (PackUtilPacketInspector.PropertyValue)var4.next();
            if (lines >= 8) {
            } else {
                Object value = property.value();
                if (value == null) { /* goto @60; */ }
                while (value == INACCESSIBLE) {
                }
                String summary = PackUtilPacketInspector.summarizeValue(value);
                if (summary == null) { /* goto @60; */ }
                while (summary.isBlank()) {
                }
                builder.line(property.label() + ": " + summary, PackUtilPacketInspector.colorForSummary(property.label(), value));
                lines++;
            }
        }
        return new PackUtilPacketInspector.SummaryResult(lines > 0, false);
    }

    private static PackUtilPacketInspector.SummaryResult appendReflectivePacketSummary(class_2596<?> packet, String packetNameHint, PackUtilPacketLoggerOverlay.LogEntry entry, PackUtilPacketInspector.InspectionBuilder builder) {
        if (packet instanceof class_2879 || PackUtilPacketInspector.packetMatchesHint(packet, packetNameHint, "HandSwingC2S", "HandSwingC2SPacket")) {
            Object[] tmp1 = new Object[3];
            tmp1[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "getHand", "hand");
            tmp1[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 0);
            tmp1[2] = PackUtilPacketInspector.findInspectablePropertyValue(packet, "Hand");
            Object hand = PackUtilPacketInspector.firstNonNull(tmp1);
            if (hand != null) {
                builder.line("Interaction: Swing Hand (attack / use animation)", PackUtilColors.textPrimary());
                builder.line("Hand: " + PackUtilPacketInspector.safeLeafString(hand), PackUtilColors.textPrimary());
                class_1268 playerHand = (class_1268)hand;
                if (MC.field_1724 != null && hand instanceof class_1268) {
                    builder.line("Held Item: " + PackUtilPacketInspector.formatItemStack(MC.field_1724.method_5998(playerHand)), PackUtilColors.successText());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (!packet instanceof class_2868) { /* goto L298; */ }
        updateSelectedSlotPacket = (class_2868)packet;
        slot = PackUtilPacketInspector.invokeFirstNoArg(updateSelectedSlotPacket, "getSelectedSlot", "getSlot", "selectedSlot", "slot");
        if (slot == null) { /* goto L298; */ }
        if (slot instanceof Number) {
            Number number = (Number)slot;
            builder.line("Selected Slot: " + PackUtilPacketInspector.formatHotbarSlot(number.intValue()), PackUtilColors.textPrimary());
        } else {
            builder.line("Selected Slot: " + PackUtilPacketInspector.safeLeafString(slot), PackUtilColors.textPrimary());
        }
        return new PackUtilPacketInspector.SummaryResult(true, true);
        L298: ;
        if (packet instanceof class_2797) {
            chatMessagePacket = (class_2797)packet;
        } else {
            String[] tmp5 = new String[2];
            tmp5[0] = "ChatMessageC2S";
            tmp5[1] = "ChatMessageC2SPacket";
        }
        Object[] tmp6 = new Object[2];
        tmp6[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "chatMessage", "getChatMessage");
        tmp6[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 0);
        message = PackUtilPacketInspector.firstNonNull(tmp6);
        Object[] tmp8 = new Object[2];
        tmp8[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "timestamp", "getTimestamp");
        tmp8[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 1);
        Object timestamp = PackUtilPacketInspector.firstNonNull(tmp8);
        Object[] tmp10 = new Object[2];
        tmp10[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "salt", "getSalt");
        tmp10[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 2);
        Object salt = PackUtilPacketInspector.firstNonNull(tmp10);
        Object[] tmp12 = new Object[2];
        tmp12[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "signature", "getSignature");
        tmp12[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 3);
        Object signature = PackUtilPacketInspector.firstNonNull(tmp12);
        Object[] tmp14 = new Object[2];
        tmp14[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "acknowledgment", "getAcknowledgment");
        tmp14[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 4);
        Object acknowledgment = PackUtilPacketInspector.firstNonNull(tmp14);
        if (message == null) {
            if (timestamp != null) { /* goto @553; */ }
        }
        builder.line("Kind: Outgoing Signed Chat Message", PackUtilColors.textPrimary());
        if (MC.field_1724 == null) { /* goto L631; */ }
        String senderName = MC.field_1724.method_5477() == null ? null : MC.field_1724.method_5477().getString();
        if (senderName != null) {
            if (!senderName.isBlank()) {
                builder.line("Sender: " + senderName, PackUtilColors.textPrimary());
            }
        }
        text = PackUtilPacketInspector.extractTextValue(message);
        if (text != null) {
            if (!text.isBlank()) {
                builder.line("Message: " + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(text)), PackUtilColors.successText());
            }
        }
        if (timestamp != null) {
            builder.line("Timestamp: " + PackUtilPacketInspector.safeLeafString(timestamp), PackUtilColors.textSecondary());
        }
        if (salt != null) {
            builder.line("Salt: " + PackUtilPacketInspector.safeLeafString(salt), PackUtilColors.textSecondary());
        }
        if (signature != null) {
            builder.line("Signature: Present", PackUtilColors.textSecondary());
        }
        if (acknowledgment != null) {
            builder.line("Acknowledgment: " + PackUtilPacketInspector.summarizeValue(acknowledgment), PackUtilPacketInspector.colorForSummary(acknowledgment));
        }
        return new PackUtilPacketInspector.SummaryResult(true, true);
        L764: ;
        if (packet instanceof class_4463 || PackUtilPacketInspector.packetMatchesHint(packet, packetNameHint, "PlayerActionResponseS2C", "PlayerActionResponseS2CPacket")) {
            Object[] tmp17 = new Object[4];
            tmp17[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "sequence", "getSequence");
            tmp17[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 0);
            tmp17[2] = PackUtilPacketInspector.getField(packet, "comp_633");
            tmp17[3] = PackUtilPacketInspector.findInspectablePropertyValue(packet, "Sequence");
            sequence = PackUtilPacketInspector.firstNonNull(tmp17);
            if (sequence != null) {
                builder.line("Meaning: Server acknowledged a sequence-based player action", PackUtilColors.textPrimary());
                builder.line("Sequence: " + PackUtilPacketInspector.safeLeafString(sequence), PackUtilColors.textPrimary());
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2815 || PackUtilPacketInspector.packetMatchesHint(packet, packetNameHint, "CloseHandledScreenC2S", "CloseHandledScreenC2SPacket")) {
            Object[] tmp21 = new Object[4];
            tmp21[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "getSyncId", "syncId");
            tmp21[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 0);
            tmp21[2] = PackUtilPacketInspector.getField(packet, "field_12827");
            tmp21[3] = PackUtilPacketInspector.findInspectablePropertyValue(packet, "Sync Id", "SyncId");
            syncId = PackUtilPacketInspector.firstNonNull(tmp21);
            if (syncId != null) {
                builder.line("Interaction: Close Handled Screen", PackUtilColors.textPrimary());
                builder.line("Sync Id: " + PackUtilPacketInspector.safeLeafString(syncId), PackUtilColors.textPrimary());
                if (entry != null) {
                    if (entry.capturedScreen != null) {
                        if (!entry.capturedScreen.isBlank()) {
                            builder.line("Closed Screen: " + entry.capturedScreen, PackUtilColors.successText());
                        }
                    }
                }
                if (syncId instanceof Number) {
                    number = (Number)syncId;
                    if (number.intValue() == 0) {
                        builder.line("Likely Screen: Player Inventory / Survival Crafting", PackUtilColors.successText());
                    }
                }
                builder.line("Note: This packet only sends the sync id, not the closed screen title/type", PackUtilColors.textSecondary());
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (!(packet instanceof class_2744)) {
            String[] tmp24 = new String[2];
            tmp24[0] = "EntityEquipmentUpdateS2C";
            tmp24[1] = "EntityEquipmentUpdateS2CPacket";
        }
        Object[] tmp25 = new Object[4];
        tmp25[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "getEntityId", "entityId", "id");
        tmp25[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 0);
        tmp25[2] = PackUtilPacketInspector.getField(packet, "field_12565");
        tmp25[3] = PackUtilPacketInspector.findInspectablePropertyValue(packet, "Entity Id", "EntityId");
        entityIdValue = PackUtilPacketInspector.firstNonNull(tmp25);
        Object[] tmp28 = new Object[4];
        tmp28[0] = PackUtilPacketInspector.invokeFirstNoArg(packet, "getEquipmentList", "equipmentList");
        tmp28[1] = PackUtilPacketInspector.getRecordComponentValue(packet, 1);
        tmp28[2] = PackUtilPacketInspector.getField(packet, "field_25721");
        tmp28[3] = PackUtilPacketInspector.findInspectablePropertyValue(packet, "Equipment List", "EquipmentList");
        equipmentListValue = PackUtilPacketInspector.firstNonNull(tmp28);
        if (entityIdValue != null) { /* goto L1323; */ }
        if (equipmentListValue == null) { /* goto L1547; */ }
        L1323: ;
        builder.line("Meaning: Server updated an entity's visible equipment", PackUtilColors.textPrimary());
        if (entityIdValue instanceof Number) {
            entityIdNumber = (Number)entityIdValue;
            entityId = entityIdNumber.intValue();
            builder.line("Entity Id: " + entityId, PackUtilColors.textPrimary());
            entity = MC.field_1687 != null ? MC.field_1687.method_8469(entityId) : null;
            if (entity != null) {
                builder.line("Entity: " + PackUtilPacketInspector.formatEntity(entity), PackUtilColors.successText());
            }
        } else {
            if (entityIdValue != null) {
                builder.line("Entity Id: " + PackUtilPacketInspector.safeLeafString(entityIdValue), PackUtilColors.textPrimary());
            }
        }
        if (equipmentListValue instanceof Collection) {
            equipmentEntries = (Collection)equipmentListValue;
            builder.line("Changed Slots: " + equipmentEntries.size(), PackUtilColors.textPrimary());
            equipmentSummary = PackUtilPacketInspector.summarizeEquipmentEntries(equipmentEntries);
            if (equipmentSummary != null) {
                if (!equipmentSummary.isBlank()) {
                    builder.line("Equipment: " + equipmentSummary, PackUtilColors.successText());
                }
            }
        } else {
            if (equipmentListValue != null) {
                builder.line("Equipment: " + PackUtilPacketInspector.summarizeValue(equipmentListValue), PackUtilPacketInspector.colorForSummary(equipmentListValue));
            }
        }
        return new PackUtilPacketInspector.SummaryResult(true, true);
        L1547: ;
        if (packet instanceof class_2811) {
            buttonClickPacket = (class_2811)packet;
            syncId = PackUtilPacketInspector.invokeFirstNoArg(buttonClickPacket, "getSyncId", "syncId");
            buttonId = PackUtilPacketInspector.invokeFirstNoArg(buttonClickPacket, "getButtonId", "buttonId");
            if (syncId != null || buttonId != null) {
                builder.line("Interaction: Click handled-screen button", PackUtilColors.textPrimary());
                if (syncId != null) {
                    builder.line("Sync Id: " + PackUtilPacketInspector.safeLeafString(syncId), PackUtilColors.textPrimary());
                }
                if (buttonId != null) {
                    builder.line("Button Id: " + PackUtilPacketInspector.safeLeafString(buttonId), PackUtilColors.textPrimary());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2873) {
            creativeInventoryActionPacket = (class_2873)packet;
            slot = PackUtilPacketInspector.invokeFirstNoArg(creativeInventoryActionPacket, "getSlot", "slot");
            stack = PackUtilPacketInspector.invokeFirstNoArg(creativeInventoryActionPacket, "getStack", "stack");
            if (slot != null || stack != null) {
                if (slot != null) {
                    builder.line("Slot: " + PackUtilPacketInspector.safeLeafString(slot), PackUtilColors.textPrimary());
                }
                if (stack != null) {
                    builder.line("Stack: " + PackUtilPacketInspector.summarizeValue(stack), PackUtilPacketInspector.colorForSummary(stack));
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (!packet instanceof class_2813) { /* goto L2228; */ }
        clickSlotPacket = (class_2813)packet;
        syncId = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "getSyncId", "syncId");
        revision = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "getRevision", "revision");
        slot = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "getSlot", "slot");
        button = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "getButton", "button");
        actionType = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "getActionType", "actionType");
        modifiedStacks = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "getModifiedStacks", "modifiedStacks");
        Object cursorStack = PackUtilPacketInspector.invokeFirstNoArg(clickSlotPacket, "cursor", "getStack", "getCursorStack", "cursorStack");
        if (syncId == null) {
            if (slot != null) { /* goto @2006; */ }
        }
        builder.line("Interaction: " + PackUtilPacketInspector.describeSlotActionType(actionType), PackUtilColors.textPrimary());
        if (syncId != null) {
            builder.line("Sync Id: " + PackUtilPacketInspector.safeLeafString(syncId), PackUtilColors.textPrimary());
        }
        if (revision != null) {
            builder.line("Revision: " + PackUtilPacketInspector.safeLeafString(revision), PackUtilColors.textSecondary());
        }
        if (slot != null) {
            builder.line("Slot: " + PackUtilPacketInspector.safeLeafString(slot), PackUtilColors.textPrimary());
        }
        if (button != null) {
            builder.line("Button: " + PackUtilPacketInspector.safeLeafString(button), PackUtilColors.textPrimary());
        }
        if (actionType != null) {
            builder.line("Action Type: " + PackUtilPacketInspector.safeLeafString(actionType), PackUtilColors.textPrimary());
        }
        if (cursorStack != null) {
            builder.line("Cursor: " + PackUtilPacketInspector.summarizeValue(cursorStack), PackUtilPacketInspector.colorForSummary(cursorStack));
        }
        if (modifiedStacks instanceof Map) {
            Map<?, ?> map = (Map)modifiedStacks;
            builder.line("Changed Slots: " + map.size(), PackUtilColors.textSecondary());
        } else {
            if (modifiedStacks != null) {
                builder.line("Changed Slots: " + PackUtilPacketInspector.summarizeValue(modifiedStacks), PackUtilPacketInspector.colorForSummary(modifiedStacks));
            }
        }
        return new PackUtilPacketInspector.SummaryResult(true, false);
        L2228: ;
        if (!packet instanceof class_2820) { /* goto L2556; */ }
        bookUpdatePacket = (class_2820)packet;
        slot = PackUtilPacketInspector.invokeFirstNoArg(bookUpdatePacket, "slot", "getSlot");
        pages = PackUtilPacketInspector.invokeFirstNoArg(bookUpdatePacket, "pages", "getPages");
        title = PackUtilPacketInspector.invokeFirstNoArg(bookUpdatePacket, "title", "getTitle");
        if (slot == null) {
            if (pages != null) { /* goto @2325; */ }
        }
        optional = (Optional)title;
        if (!optional.isPresent()) { /* goto @2352; */ }
        signing = title instanceof Optional;
        builder.line("Interaction: " + signing ? "Sign Book" : "Edit Book", PackUtilColors.textPrimary());
        if (slot instanceof Number) {
            number = (Number)slot;
            builder.line("Slot: " + PackUtilPacketInspector.formatHotbarSlot(number.intValue()), PackUtilColors.textPrimary());
        } else {
            if (slot != null) {
                builder.line("Slot: " + PackUtilPacketInspector.safeLeafString(slot), PackUtilColors.textPrimary());
            }
        }
        if (title != null) {
            titleText = PackUtilPacketInspector.extractTextValue(title);
            if (titleText != null) {
                if (!titleText.isBlank()) {
                    builder.line("Title: " + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(titleText)), PackUtilColors.successText());
                }
            }
        }
        if (pages instanceof Collection) {
            collection = (Collection)pages;
            builder.line("Pages: " + collection.size(), PackUtilColors.textPrimary());
            preview = PackUtilPacketInspector.summarizeBookPages(collection);
            if (preview != null) {
                builder.line("Preview: " + preview, PackUtilColors.textSecondary());
            }
        }
        return new PackUtilPacketInspector.SummaryResult(true, true);
        L2556: ;
        if (!packet instanceof class_2877) { /* goto L2793; */ }
        updateSignPacket = (class_2877)packet;
        pos = PackUtilPacketInspector.invokeFirstNoArg(updateSignPacket, "getPos", "pos");
        lines = PackUtilPacketInspector.invokeFirstNoArg(updateSignPacket, "getText", "text");
        front = PackUtilPacketInspector.invokeFirstNoArg(updateSignPacket, "isFront", "front");
        if (pos == null) {
            if (lines != null) { /* goto @2653; */ }
        }
        builder.line("Interaction: Update Sign Text", PackUtilColors.textPrimary());
        if (pos != null) {
            builder.line("Block Pos: " + PackUtilPacketInspector.summarizeValue(pos), PackUtilPacketInspector.colorForSummary(pos));
        }
        if (front == null) { /* goto L2724; */ }
        builder.line("Side: " + Boolean.TRUE.equals(front) ? "Front" : "Back", PackUtilColors.textPrimary());
        L2724: ;
        if (lines instanceof String[]) {
            stringLines = (String[])lines;
            builder.line("Text: " + PackUtilPacketInspector.summarizeSignLines(stringLines), PackUtilColors.successText());
        } else {
            if (lines != null) {
                builder.line("Text: " + PackUtilPacketInspector.summarizeValue(lines), PackUtilPacketInspector.colorForSummary(lines));
            }
        }
        return new PackUtilPacketInspector.SummaryResult(true, true);
        L2793: ;
        if (packet instanceof class_2855) {
            renameItemPacket = (class_2855)packet;
            name = PackUtilPacketInspector.invokeFirstNoArg(renameItemPacket, "getName", "name");
            if (name != null) {
                builder.line("Interaction: Rename Item in Anvil", PackUtilColors.textPrimary());
                builder.line("Name: " + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(String.valueOf(name))), PackUtilColors.successText());
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2840) {
            craftRequestPacket = (class_2840)packet;
            syncId = PackUtilPacketInspector.invokeFirstNoArg(craftRequestPacket, "syncId", "getSyncId");
            recipeId = PackUtilPacketInspector.invokeFirstNoArg(craftRequestPacket, "recipeId", "getRecipeId");
            craftAll = PackUtilPacketInspector.invokeFirstNoArg(craftRequestPacket, "craftAll", "isCraftAll", "getCraftAll");
            if (syncId != null || recipeId != null || craftAll != null) {
                builder.line("Interaction: Craft Recipe", PackUtilColors.textPrimary());
                if (syncId != null) {
                    builder.line("Sync Id: " + PackUtilPacketInspector.safeLeafString(syncId), PackUtilColors.textPrimary());
                }
                if (recipeId != null) {
                    builder.line("Recipe: " + PackUtilPacketInspector.safeLeafString(recipeId), PackUtilColors.successText());
                }
                if (craftAll != null) {
                    builder.line("Craft All: " + PackUtilPacketInspector.safeLeafString(craftAll), PackUtilColors.textPrimary());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2863) {
            selectMerchantTradePacket = (class_2863)packet;
            tradeId = PackUtilPacketInspector.invokeFirstNoArg(selectMerchantTradePacket, "getTradeId", "tradeId");
            if (tradeId != null) {
                builder.line("Interaction: Select Merchant Trade", PackUtilColors.textPrimary());
                builder.line("Trade Index: " + PackUtilPacketInspector.safeLeafString(tradeId), PackUtilColors.textPrimary());
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2651) {
            screenHandlerPropertyUpdatePacket = (class_2651)packet;
            syncId = PackUtilPacketInspector.invokeFirstNoArg(screenHandlerPropertyUpdatePacket, "getSyncId", "syncId");
            property = PackUtilPacketInspector.invokeFirstNoArg(screenHandlerPropertyUpdatePacket, "getPropertyId", "propertyId", "getProperty", "property");
            value = PackUtilPacketInspector.invokeFirstNoArg(screenHandlerPropertyUpdatePacket, "getValue", "value");
            if (syncId != null || property != null || value != null) {
                if (syncId != null) {
                    builder.line("Sync Id: " + PackUtilPacketInspector.safeLeafString(syncId), PackUtilColors.textPrimary());
                }
                if (property != null) {
                    builder.line("Property: " + PackUtilPacketInspector.safeLeafString(property), PackUtilColors.textPrimary());
                }
                if (value != null) {
                    builder.line("Value: " + PackUtilPacketInspector.safeLeafString(value), PackUtilColors.textPrimary());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2620) {
            blockBreakingProgressPacket = (class_2620)packet;
            entityId = PackUtilPacketInspector.invokeFirstNoArg(blockBreakingProgressPacket, "getEntityId", "entityId");
            pos = PackUtilPacketInspector.invokeFirstNoArg(blockBreakingProgressPacket, "getPos", "pos");
            progress = PackUtilPacketInspector.invokeFirstNoArg(blockBreakingProgressPacket, "getProgress", "progress");
            if (entityId != null || pos != null || progress != null) {
                if (entityId != null) {
                    builder.line("Entity Id: " + PackUtilPacketInspector.safeLeafString(entityId), PackUtilColors.textPrimary());
                }
                if (pos != null) {
                    builder.line("Block Pos: " + PackUtilPacketInspector.summarizeValue(pos), PackUtilPacketInspector.colorForSummary(pos));
                }
                if (progress != null) {
                    builder.line("Progress: " + PackUtilPacketInspector.safeLeafString(progress), PackUtilColors.textPrimary());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2663) {
            entityStatusPacket = (class_2663)packet;
            entityId = PackUtilPacketInspector.invokeFirstNoArg(entityStatusPacket, "getEntityId", "entityId");
            status = PackUtilPacketInspector.invokeFirstNoArg(entityStatusPacket, "getStatus", "status");
            if (entityId != null || status != null) {
                if (entityId != null) {
                    builder.line("Entity Id: " + PackUtilPacketInspector.safeLeafString(entityId), PackUtilColors.textPrimary());
                }
                if (status != null) {
                    builder.line("Status: " + PackUtilPacketInspector.safeLeafString(status), PackUtilColors.textPrimary());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2743) {
            entityVelocityUpdatePacket = (class_2743)packet;
            entityId = PackUtilPacketInspector.invokeFirstNoArg(entityVelocityUpdatePacket, "getEntityId", "entityId", "id");
            velocity = PackUtilPacketInspector.invokeFirstNoArg(entityVelocityUpdatePacket, "getVelocity", "velocity");
            if (entityId != null || velocity != null) {
                if (entityId != null) {
                    builder.line("Entity Id: " + PackUtilPacketInspector.safeLeafString(entityId), PackUtilColors.textPrimary());
                }
                if (velocity != null) {
                    builder.line("Velocity: " + PackUtilPacketInspector.summarizeValue(velocity), PackUtilPacketInspector.colorForSummary(velocity));
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (!packet instanceof class_7439) { /* goto L4019; */ }
        gameMessagePacket = (class_7439)packet;
        content = PackUtilPacketInspector.invokeFirstNoArg(gameMessagePacket, "content", "getContent");
        overlay = PackUtilPacketInspector.invokeFirstNoArg(gameMessagePacket, "overlay", "isOverlay", "getOverlay");
        if (content != null) { /* goto L3833; */ }
        if (overlay == null) { /* goto L4019; */ }
        L3833: ;
        message = PackUtilPacketInspector.extractTextValue(content);
        builder.line("Kind: " + Boolean.TRUE.equals(overlay) ? "Overlay / HUD message" : "Game / system message", PackUtilColors.textPrimary());
        parsed = PackUtilPacketInspector.parseChatLine(message);
        if (parsed != null) {
            builder.line("Possible Sender: " + parsed.sender(), PackUtilColors.textPrimary());
            builder.line("Message: " + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(parsed.message())), PackUtilColors.successText());
        } else {
            if (message != null) {
                if (!message.isBlank()) {
                    builder.line("Message: " + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(message)), PackUtilColors.successText());
                }
            } else {
                if (content != null) {
                    builder.line("Message: " + PackUtilPacketInspector.summarizeValue(content), PackUtilPacketInspector.colorForSummary(content));
                }
            }
        }
        if (overlay != null) {
            builder.line("Overlay: " + PackUtilPacketInspector.safeLeafString(overlay), PackUtilColors.textPrimary());
        }
        return new PackUtilPacketInspector.SummaryResult(true, true);
        L4019: ;
        if (packet instanceof class_7827) {
            profilelessChatMessagePacket = (class_7827)packet;
            message = PackUtilPacketInspector.invokeFirstNoArg(profilelessChatMessagePacket, "message", "getMessage");
            chatType = PackUtilPacketInspector.invokeFirstNoArg(profilelessChatMessagePacket, "chatType", "getChatType");
            chatSummary = PackUtilPacketInspector.appendChatSummary(message, chatType, null, null, null, "Incoming Chat Message", builder);
            if (chatSummary.wroteAny()) {
                return new PackUtilPacketInspector.SummaryResult(true, chatSummary.complete());
            }
        }
        if (!packet instanceof class_7438) { /* goto L4682; */ }
        chatMessageS2CPacket = (class_7438)packet;
        Object[] tmp67 = new Object[3];
        tmp67[0] = PackUtilPacketInspector.invokeFirstNoArg(chatMessageS2CPacket, "body", "getBody");
        tmp67[1] = PackUtilPacketInspector.getRecordComponentValue(chatMessageS2CPacket, 4);
        tmp67[2] = PackUtilPacketInspector.findRecordComponentByMethodNames(chatMessageS2CPacket, 2, "content", "timestamp", "salt");
        body = PackUtilPacketInspector.firstNonNull(tmp67);
        Object[] tmp70 = new Object[3];
        tmp70[0] = PackUtilPacketInspector.invokeFirstNoArg(chatMessageS2CPacket, "serializedParameters", "getSerializedParameters");
        tmp70[1] = PackUtilPacketInspector.getRecordComponentValue(chatMessageS2CPacket, 7);
        tmp70[2] = PackUtilPacketInspector.findRecordComponentByMethodNames(chatMessageS2CPacket, 2, "name", "targetName", "type");
        serializedParameters = PackUtilPacketInspector.firstNonNull(tmp70);
        Object[] tmp73 = new Object[3];
        tmp73[0] = PackUtilPacketInspector.invokeFirstNoArg(chatMessageS2CPacket, "sender", "getSender");
        tmp73[1] = PackUtilPacketInspector.getRecordComponentValue(chatMessageS2CPacket, 1);
        tmp73[2] = PackUtilPacketInspector.findRecordComponentByValueType(chatMessageS2CPacket, UUID.class);
        sender = PackUtilPacketInspector.firstNonNull(tmp73);
        Object[] tmp75 = new Object[3];
        tmp75[0] = PackUtilPacketInspector.invokeFirstNoArg(chatMessageS2CPacket, "filterMask", "getFilterMask");
        tmp75[1] = PackUtilPacketInspector.getRecordComponentValue(chatMessageS2CPacket, 6);
        tmp75[2] = PackUtilPacketInspector.findRecordComponentByMethodNames(chatMessageS2CPacket, 1, "isFullyFiltered", "isPassThrough");
        filterMask = PackUtilPacketInspector.firstNonNull(tmp75);
        Object[] tmp78 = new Object[3];
        tmp78[0] = PackUtilPacketInspector.invokeFirstNoArg(chatMessageS2CPacket, "unsignedContent", "getUnsignedContent");
        tmp78[1] = PackUtilPacketInspector.getRecordComponentValue(chatMessageS2CPacket, 5);
        tmp78[2] = PackUtilPacketInspector.findRecordTextComponent(chatMessageS2CPacket, body, serializedParameters, sender, filterMask);
        unsignedContent = PackUtilPacketInspector.firstNonNull(tmp78);
        message = unsignedContent;
        timestamp = null;
        if (body != null) {
            Object[] tmp81 = new Object[3];
            tmp81[0] = PackUtilPacketInspector.invokeFirstNoArg(body, "content", "getContent");
            tmp81[1] = PackUtilPacketInspector.getRecordComponentValue(body, 0);
            tmp81[2] = PackUtilPacketInspector.findRecordTextComponent(body, new Object[0]);
            Object bodyContent = PackUtilPacketInspector.firstNonNull(tmp81);
            if (bodyContent != null) {
                if (message == null || PackUtilPacketInspector.extractTextValue(message) == null || PackUtilPacketInspector.extractTextValue(message).isBlank()) {
                    message = bodyContent;
                }
            }
            Object[] tmp83 = new Object[3];
            tmp83[0] = PackUtilPacketInspector.invokeFirstNoArg(body, "timestamp", "getTimestamp");
            tmp83[1] = PackUtilPacketInspector.getRecordComponentValue(body, 1);
            tmp83[2] = PackUtilPacketInspector.findRecordComponentByValueType(body, Instant.class);
            timestamp = PackUtilPacketInspector.firstNonNull(tmp83);
        }
        UUID uuid = (UUID)sender;
        chatSummary = PackUtilPacketInspector.appendChatSummary(message, serializedParameters, sender instanceof UUID ? uuid : null, timestamp, filterMask, "Incoming Signed Chat Message", builder);
        if (chatSummary.wroteAny()) {
            return new PackUtilPacketInspector.SummaryResult(true, chatSummary.complete());
        }
        if (!packet instanceof class_5894) { /* goto L4801; */ }
        overlayMessagePacket = (class_5894)packet;
        text = PackUtilPacketInspector.invokeFirstNoArg(overlayMessagePacket, "text", "getText");
        message = PackUtilPacketInspector.extractTextValue(text);
        if (message != null) { /* goto L4735; */ }
        if (text == null) { /* goto L4801; */ }
        L4735: ;
        builder.line("Kind: Overlay / HUD message", PackUtilColors.textPrimary());
        builder.line("Message: " + message == null ? PackUtilPacketInspector.summarizeValue(text) : PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(message)), message == null ? PackUtilPacketInspector.colorForSummary(text) : PackUtilColors.successText());
        return new PackUtilPacketInspector.SummaryResult(true, true);
        if (packet instanceof class_3895) {
            openWrittenBookPacket = (class_3895)packet;
            hand = PackUtilPacketInspector.invokeFirstNoArg(openWrittenBookPacket, "getHand", "hand");
            if (hand != null) {
                builder.line("Interaction: Open Written Book", PackUtilColors.textPrimary());
                builder.line("Hand: " + PackUtilPacketInspector.safeLeafString(hand), PackUtilColors.textPrimary());
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2661) {
            disconnectPacket = (class_2661)packet;
            reason = PackUtilPacketInspector.invokeFirstNoArg(disconnectPacket, "reason", "getReason");
            if (reason != null) {
                builder.line("Reason: " + PackUtilPacketInspector.summarizeValue(reason), PackUtilPacketInspector.colorForSummary(reason));
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        if (packet instanceof class_2828) {
            playerMovePacket = (class_2828)packet;
            x = PackUtilPacketInspector.invokeFirstNoArg(playerMovePacket, "getX", "x");
            y = PackUtilPacketInspector.invokeFirstNoArg(playerMovePacket, "getY", "y");
            z = PackUtilPacketInspector.invokeFirstNoArg(playerMovePacket, "getZ", "z");
            yaw = PackUtilPacketInspector.invokeFirstNoArg(playerMovePacket, "getYaw", "yaw");
            pitch = PackUtilPacketInspector.invokeFirstNoArg(playerMovePacket, "getPitch", "pitch");
            onGround = PackUtilPacketInspector.invokeFirstNoArg(playerMovePacket, "isOnGround", "onGround");
            if (x != null || y != null || z != null || yaw != null || pitch != null || onGround != null) {
                if (x != null || y != null || z != null) {
                    builder.line("Pos: x=" + PackUtilPacketInspector.safeLeafString(x) + ", y=" + PackUtilPacketInspector.safeLeafString(y) + ", z=" + PackUtilPacketInspector.safeLeafString(z), PackUtilColors.textPrimary());
                }
                if (yaw != null || pitch != null) {
                    builder.line("Rot: yaw=" + PackUtilPacketInspector.safeLeafString(yaw) + ", pitch=" + PackUtilPacketInspector.safeLeafString(pitch), PackUtilColors.textPrimary());
                }
                if (onGround != null) {
                    builder.line("On Ground: " + PackUtilPacketInspector.safeLeafString(onGround), PackUtilColors.textPrimary());
                }
                return new PackUtilPacketInspector.SummaryResult(true, true);
            }
        }
        return PackUtilPacketInspector.SummaryResult.NONE;
    }

    private static void dumpRootFields(Object root, PackUtilPacketInspector.InspectionBuilder builder, IdentityHashMap<Object, Boolean> visited) {
        visited.put(root, Boolean.TRUE);
        List<PackUtilPacketInspector.PropertyValue> properties = PackUtilPacketInspector.getInspectableProperties(root);
        List<Field> fields = PackUtilPacketInspector.getInspectableFields(root.getClass());
        Set<String> consumedFieldNames = new LinkedHashSet();
        boolean wroteAny = properties.iterator();
        while (wroteAny.hasNext()) {
            PropertyValue property = (PackUtilPacketInspector.PropertyValue)wroteAny.next();
            PackUtilPacketInspector.dumpValue(property.label(), property.value(), 0, builder, visited);
            consumedFieldNames.add(PackUtilPacketInspector.decapitalize(PackUtilPacketInspector.normalizeName(property.label())));
        }
        wroteAny = !properties.isEmpty();
        rawFallback = fields.iterator();
        while (rawFallback.hasNext()) {
            Field field = (Field)rawFallback.next();
            String fieldLabel = PackUtilPacketInspector.resolveFieldLabel(field);
            if (fieldLabel == null) continue;
            while (fieldLabel.isBlank()) {
            }
            while (consumedFieldNames.contains(PackUtilPacketInspector.decapitalize(PackUtilPacketInspector.normalizeName(fieldLabel)))) {
            }
            PackUtilPacketInspector.dumpValue(fieldLabel, PackUtilPacketInspector.readField(field, root), 0, builder, visited);
            wroteAny = true;
        }
        if (wroteAny) { /* goto L254; */ }
        rawFallback = PackUtilPacketInspector.rawFallbackString(root);
        if (rawFallback != null) {
            builder.line("Raw: " + rawFallback, PackUtilColors.textMuted());
        } else {
            builder.line("<No readable fields>", PackUtilColors.textMuted());
        }
    }

    private static void dumpValue(String label, Object value, int depth, PackUtilPacketInspector.InspectionBuilder builder, IdentityHashMap<Object, Boolean> visited) {
        String indent = "  ".repeat(Math.max(0, depth));
        try {
            PackUtilPacketInspector.dumpValueUnsafe(label, value, depth, indent, builder, visited);
        }
        catch (Throwable t) {
            builder.line(indent + label + ": <error reading value: " + t.getClass().getSimpleName() + ">", PackUtilColors.dangerText());
            L52: ;
            return;
        }
    }

    private static void dumpValueUnsafe(String label, Object value, int depth, String indent, PackUtilPacketInspector.InspectionBuilder builder, IdentityHashMap<Object, Boolean> visited) {
        if (builder.isFull()) {
            return;
        }
        if (value == INACCESSIBLE) {
            builder.line(indent + label + ": <inaccessible>", PackUtilColors.textMuted());
            return;
        }
        if (value == null) {
            builder.line(indent + label + ": null", PackUtilColors.textMuted());
            return;
        }
        if (depth >= 7) {
            builder.line(indent + label + ": <max depth reached>", PackUtilColors.textMuted());
            return;
        }
        Class<?> valueClass = value.getClass();
        if (PackUtilPacketInspector.isSimpleValue(value)) {
            builder.line(indent + label + ": " + PackUtilPacketInspector.formatSimpleValue(value), PackUtilPacketInspector.semanticFieldColor(label, value));
            return;
        }
        if (value instanceof Optional) {
            Optional<?> optional = (Optional)value;
            if (optional.isEmpty()) {
                builder.line(indent + label + ": Optional.empty", PackUtilColors.textMuted());
                return;
            }
            builder.line(indent + label + ": Optional", PackUtilColors.textSecondary());
            PackUtilPacketInspector.dumpValue("value", optional.get(), depth + 1, builder, visited);
            return;
        }
        if (value instanceof class_3965) {
            hit = (class_3965)value;
            builder.line(indent + label + ": BlockHitResult", PackUtilColors.textSecondary());
            PackUtilPacketInspector.dumpValue("blockPos", hit.method_17777(), depth + 1, builder, visited);
            PackUtilPacketInspector.dumpValue("hitPos", hit.method_17784(), depth + 1, builder, visited);
            PackUtilPacketInspector.dumpValue("side", hit.method_17780(), depth + 1, builder, visited);
            PackUtilPacketInspector.dumpValue("type", hit.method_17783(), depth + 1, builder, visited);
            PackUtilPacketInspector.dumpValue("insideBlock", hit.method_17781(), depth + 1, builder, visited);
            return;
        }
        if (!value instanceof Map) { /* goto L536; */ }
        map = (Map)value;
        builder.line(indent + label + ": Map[" + map.size() + "]", PackUtilColors.textSecondary());
        int index = 0;
        Set<String> consumedFieldNames = map.entrySet().iterator();
        while (consumedFieldNames.hasNext()) {
            Map.Entry<?, ?> entry = (Map.Entry)consumedFieldNames.next();
            if (index >= 64) {
                builder.line(indent + "  ... " + map.size() - index + " more entries", PackUtilColors.textMuted());
                return;
            }
            builder.line(indent + "  [" + index + "] " + PackUtilPacketInspector.formatSimpleValue(entry.getKey()) + " = " + PackUtilPacketInspector.formatSimpleValue(entry.getValue()), PackUtilColors.textPrimary());
            if (PackUtilPacketInspector.isSimpleValue(entry.getKey()) && PackUtilPacketInspector.isSimpleValue(entry.getValue())) {
            } else {
                builder.line(indent + "  [" + index + "]", PackUtilColors.textSecondary());
                PackUtilPacketInspector.dumpValue("key", entry.getKey(), depth + 2, builder, visited);
                PackUtilPacketInspector.dumpValue("value", entry.getValue(), depth + 2, builder, visited);
            }
            index++;
        }
        return;
        L536: ;
        if (!value instanceof Collection) { /* goto L660; */ }
        collection = (Collection)value;
        builder.line(indent + label + ": List[" + collection.size() + "]", PackUtilColors.textSecondary());
        index = 0;
        consumedFieldNames = collection.iterator();
        while (consumedFieldNames.hasNext()) {
            item = consumedFieldNames.next();
            if (index >= 64) {
                builder.line(indent + "  ... " + collection.size() - index + " more entries", PackUtilColors.textMuted());
                return;
            }
            PackUtilPacketInspector.dumpValue("[" + index + "]", item, depth + 1, builder, visited);
            index++;
        }
        return;
        L660: ;
        if (!valueClass.isArray()) { /* goto L798; */ }
        length = Array.getLength(value);
        if (valueClass.getComponentType().isPrimitive()) {
            builder.line(indent + label + ": " + PackUtilPacketInspector.formatPrimitiveArray(value), PackUtilColors.textPrimary());
            return;
        }
        builder.line(indent + label + ": " + PackUtilPacketInspector.prettifyClassName(valueClass) + "[" + length + "]", PackUtilColors.textSecondary());
        for (i = 0; i < Math.min(length, 64); i++) {
            PackUtilPacketInspector.dumpValue("[" + i + "]", Array.get(value, i), depth + 1, builder, visited);
        }
        if (length > 64) {
            builder.line(indent + "  ... " + length - 64 + " more entries", PackUtilColors.textMuted());
        }
        return;
        L798: ;
        if (visited.containsKey(value)) {
            builder.line(indent + label + ": <already shown " + PackUtilPacketInspector.prettifyClassName(valueClass) + ">", PackUtilColors.textMuted());
            return;
        }
        if (PackUtilPacketInspector.shouldTreatAsLeaf(valueClass)) {
            builder.line(indent + label + ": " + PackUtilPacketInspector.safeLeafString(value), PackUtilPacketInspector.semanticFieldColor(label, value));
            return;
        }
        visited.put(value, Boolean.TRUE);
        properties = PackUtilPacketInspector.getInspectableProperties(value);
        fields = PackUtilPacketInspector.getInspectableFields(valueClass);
        builder.line(indent + label + ": " + PackUtilPacketInspector.safeLeafString(value), PackUtilPacketInspector.semanticFieldColor(label, value));
        if (properties.isEmpty() && fields.isEmpty()) {
            return;
        }
        builder.line(indent + label + ": " + PackUtilPacketInspector.prettifyClassName(valueClass), PackUtilColors.textSecondary());
        consumedFieldNames = new LinkedHashSet();
        item = properties.iterator();
        while (item.hasNext()) {
            PropertyValue property = (PackUtilPacketInspector.PropertyValue)item.next();
            PackUtilPacketInspector.dumpValue(property.label(), property.value(), depth + 1, builder, visited);
            consumedFieldNames.add(PackUtilPacketInspector.decapitalize(PackUtilPacketInspector.normalizeName(property.label())));
        }
        item = fields.iterator();
        while (item.hasNext()) {
            field = (Field)item.next();
            String fieldLabel = PackUtilPacketInspector.resolveFieldLabel(field);
            if (fieldLabel == null) continue;
            while (fieldLabel.isBlank()) {
            }
            while (consumedFieldNames.contains(PackUtilPacketInspector.decapitalize(PackUtilPacketInspector.normalizeName(fieldLabel)))) {
            }
            PackUtilPacketInspector.dumpValue(fieldLabel, PackUtilPacketInspector.readField(field, value), depth + 1, builder, visited);
        }
    }

    private static List<PackUtilPacketInspector.PropertyValue> getInspectableProperties(Object owner) {
        if (owner == null) {
            return List.of();
        }
        Map<String, PackUtilPacketInspector.PropertyValue> properties = new LinkedHashMap();
        Class<?> type = owner.getClass();
        if (!type.isRecord()) { /* goto L85; */ }
        var var3 = type.getRecordComponents();
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            RecordComponent component = var3[var5];
            Object value = PackUtilPacketInspector.invokeAccessor(component.getAccessor(), owner);
            PackUtilPacketInspector.putProperty(properties, PackUtilPacketInspector.resolveRecordComponentLabel(type, component), value, PackUtilPacketInspector.PropertySource.RECORD);
        }
        Arrays.stream(type.getMethods()).filter(PackUtilPacketInspector::lambda$getInspectableProperties$0).sorted(Comparator.comparing(Method::getName, String.CASE_INSENSITIVE_ORDER)).forEach(PackUtilPacketInspector::lambda$getInspectableProperties$1 /* captured: properties, owner */);
        if (properties.isEmpty()) {
            PackUtilPacketInspector.addFallbackRecordProperties(properties, owner, type);
        }
        return new ArrayList(properties.values());
    }

    private static void addFallbackRecordProperties(Map<String, PackUtilPacketInspector.PropertyValue> properties, Object owner, Class<?> type) {
        if (!type.isRecord()) {
            return;
        }
        Map<String, Integer> labelCounts = new LinkedHashMap();
        var var4 = type.getRecordComponents();
        var var5 = var4.length;
        for (int var6 = 0; var6 < var5; var6++) {
            RecordComponent component = var4[var6];
            Object value = PackUtilPacketInspector.invokeAccessor(component.getAccessor(), owner);
            String[] tmp0 = new String[2];
            tmp0[0] = PackUtilPacketInspector.resolveRecordComponentLabel(type, component);
            tmp0[1] = PackUtilPacketInspector.fallbackLabelFor(component.getAccessor().getReturnType(), labelCounts);
            String alias = PackUtilPacketInspector.firstNonBlank(tmp0);
            PackUtilPacketInspector.putProperty(properties, alias, value, PackUtilPacketInspector.PropertySource.RECORD);
        }
    }

    private static String fallbackLabelFor(Class<?> type, Map<String, Integer> labelCounts) {
        String base = PackUtilPacketInspector.fallbackBaseLabel(type);
        int count = ((Integer)labelCounts.getOrDefault(base, 0)).intValue() + 1;
        labelCounts.put(base, count);
        return count == 1 ? base : base + " " + count;
    }

    private static String fallbackBaseLabel(Class<?> type) {
        if (type == null) {
            return "Value";
        }
        if (type == Boolean.TYPE || type == Boolean.class) {
            return "Flag";
        }
        if (type == String.class || class_2561.class.isAssignableFrom(type)) {
            return "Text";
        }
        if (type == UUID.class) {
            return "Uuid";
        }
        if (type == class_2960.class) {
            return "Identifier";
        }
        if (type == class_2338.class) {
            return "Block Pos";
        }
        if (type == class_243.class) {
            return "Position";
        }
        if (type == class_1799.class) {
            return "Item";
        }
        if (type == class_2520.class) {
            return "Nbt";
        }
        if (type == Instant.class) {
            return "Timestamp";
        }
        if (type.isEnum()) {
            return "Type";
        }
        if (type.isPrimitive()) {
            if (type == Integer.TYPE || type == Long.TYPE || type == Short.TYPE || type == Byte.TYPE) {
                return "Number";
            }
            if (type == Float.TYPE || type == Double.TYPE) {
                return "Decimal";
            }
            if (type == Character.TYPE) {
                return "Character";
            }
        }
        if (Number.class.isAssignableFrom(type)) {
            return "Number";
        }
        if (Collection.class.isAssignableFrom(type)) {
            return "Entries";
        }
        if (Map.class.isAssignableFrom(type)) {
            return "Map";
        }
        if (Optional.class.isAssignableFrom(type)) {
            return "Optional";
        }
        if (type.isArray()) {
            return PackUtilPacketInspector.fallbackBaseLabel(type.getComponentType()) + " List";
        }
        return PackUtilPacketInspector.prettifyClassName(type);
    }

    private static void putProperty(Map<String, PackUtilPacketInspector.PropertyValue> properties, String label, Object value, PackUtilPacketInspector.PropertySource source) {
        if (label == null || label.isBlank()) {
            return;
        }
        if (PackUtilPacketInspector.isObfuscatedComponentLabel(label)) {
            return;
        }
        if (PackUtilPacketInspector.isIgnoredPropertyLabel(label)) {
            return;
        }
        String key = PackUtilPacketInspector.normalizeName(label);
        if (properties.containsKey(key)) {
            return;
        }
        properties.put(key, new PackUtilPacketInspector.PropertyValue(PackUtilPacketInspector.prettifyLabel(label), value, source));
    }

    private static boolean isInspectableMethod(Method method) {
        int modifiers = method.getModifiers();
        if (!Modifier.isPublic(modifiers)) {
            return false;
        }
        if (Modifier.isStatic(modifiers)) {
            return false;
        }
        if (method.isSynthetic()) {
            return false;
        }
        if (method.getParameterCount() != 0) {
            return false;
        }
        if (method.getReturnType() == Void.TYPE) {
            return false;
        }
        if (PackUtilPacketInspector.isIgnoredPropertyLabel(method.getName())) {
            return false;
        }
        String mappedLabel = PackUtilPacketInspector.normalizeAccessorLabel(PackUtilYarnMappings.lookupMethodLabel(method), method.getReturnType());
        if (PackUtilPacketInspector.isIgnoredPropertyLabel(mappedLabel)) {
            return false;
        }
        if (!PackUtilPacketInspector.isGetterLikeMethod(method)) {
            if (!EXTRA_ACCESSOR_NAMES.contains(method.getName())) {
                if (mappedLabel == null || !EXTRA_ACCESSOR_NAMES.contains(mappedLabel)) {
                    if (mappedLabel == null) { /* goto @139; */ }
                }
            }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L140; */
        L139: ;
        L140: ;
        return false;
    }

    private static boolean isGetterLikeMethod(Method method) {
        String name = method.getName();
        if (name.startsWith("get") && name.length() > 3) {
            return true;
        }
        if (name.length() <= 2) { /* goto @67; */ }
        if (method.getReturnType() == Boolean.TYPE) { /* goto L63; */ }
        if (method.getReturnType() != Boolean.class) { /* goto @67; */ }
        L63: ;
        return name.startsWith("is");
    }

    private static String propertyLabelFor(Method method) {
        String mappedLabel = PackUtilPacketInspector.normalizeAccessorLabel(PackUtilYarnMappings.lookupMethodLabel(method), method.getReturnType());
        if (mappedLabel != null && !mappedLabel.isBlank()) {
            return mappedLabel;
        }
        return PackUtilPacketInspector.normalizeAccessorLabel(method.getName(), method.getReturnType());
    }

    private static Object invokeAccessor(Method method, Object owner) {
        try {
            if (!method.canAccess(owner)) {
                method.setAccessible(true);
            }
            return method.invoke(owner, new Object[0]);
        }
        catch (Throwable ignored) {
            return INACCESSIBLE;
        }
    }

    private static List<Field> getInspectableFields(Class<?> type) {
        List<Field> fields = new ArrayList();
        Class<?> cursor = type;
        while (cursor != null) {
            if (cursor == Object.class) break;
            fields.addAll((Collection)Arrays.stream(cursor.getDeclaredFields()).filter(PackUtilPacketInspector::lambda$getInspectableFields$2).filter(PackUtilPacketInspector::lambda$getInspectableFields$3).filter(PackUtilPacketInspector::lambda$getInspectableFields$4).filter(PackUtilPacketInspector::lambda$getInspectableFields$5).sorted(PackUtilPacketInspector::lambda$getInspectableFields$6).collect(Collectors.toList()));
            cursor = cursor.getSuperclass();
        }
        return fields;
    }

    private static Object readField(Field field, Object owner) {
        try {
            if (!field.canAccess(owner)) {
                field.setAccessible(true);
            }
            return field.get(owner);
        }
        catch (Throwable ignored) {
            return INACCESSIBLE;
        }
    }

    private static Object getField(Object owner, String fieldName) {
        if (owner == null || fieldName == null) {
            return null;
        }
        Class<?> cursor = owner.getClass();
        while (cursor != null) {
            try {
                Field field = cursor.getDeclaredField(fieldName);
                if (field.canAccess(owner)) continue;
                field.setAccessible(true);
                return field.get(owner);
            }
            catch (Throwable field) {
                cursor = cursor.getSuperclass();
            }
        }
        return null;
    }

    private static Object firstNonNullField(Object owner, String ... fieldNames) {
        var var2 = fieldNames;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            String fieldName = var2[var4];
            Object value = PackUtilPacketInspector.getField(owner, fieldName);
            if (value == null) continue;
            return value;
        }
        return null;
    }

    private static Object firstNonNull(Object ... values) {
        if (values == null) {
            return null;
        }
        var var1 = values;
        var var2 = var1.length;
        for (int var3 = 0; var3 < var2; var3++) {
            Object value = var1[var3];
            if (!value != null && value != INACCESSIBLE) continue;
            return value;
        }
        return null;
    }

    private static String firstNonBlank(String ... values) {
        if (values == null) {
            return null;
        }
        var var1 = values;
        var var2 = var1.length;
        for (int var3 = 0; var3 < var2; var3++) {
            String value = var1[var3];
            if (!value != null && !value.isBlank()) continue;
            return value;
        }
        return null;
    }

    private static String resolveRecordComponentLabel(Class<?> ownerType, RecordComponent component) {
        if (component == null) {
            return null;
        }
        String[] tmp0 = new String[2];
        tmp0[0] = PackUtilYarnMappings.lookupMethodLabel(component.getAccessor());
        tmp0[1] = component.getName();
        return PackUtilPacketInspector.firstNonBlank(tmp0);
    }

    private static String resolveFieldLabel(Field field) {
        if (field == null) {
            return null;
        }
        String[] tmp0 = new String[2];
        tmp0[0] = PackUtilYarnMappings.lookupFieldLabel(field);
        tmp0[1] = PackUtilPacketInspector.isObfuscatedComponentLabel(field.getName()) ? null : field.getName();
        return PackUtilPacketInspector.firstNonBlank(tmp0);
    }

    private static Object getRecordComponentValue(Object owner, int index) {
        if (owner == null || index < 0) {
            return null;
        }
        try {
            Class<?> type = owner.getClass();
            if (!type.isRecord()) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            RecordComponent[] components = type.getRecordComponents();
            if (components == null || index >= components.length) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            return PackUtilPacketInspector.invokeAccessor(components[index].getAccessor(), owner);
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static Object findRecordComponentByValueType(Object owner, Class<?> expectedType) {
        if (owner == null || expectedType == null) {
            return null;
        }
        try {
            Class<?> type = owner.getClass();
            if (!type.isRecord()) {
                return null;
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            RecordComponent[] components = type.getRecordComponents();
            if (components == null) {
                return null;
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            var var4 = components;
            var var5 = var4.length;
            int var6 = 0;
            L46: ;
            if (var6 < var5) {
                RecordComponent component = var4[var6];
                Object value = PackUtilPacketInspector.invokeAccessor(component.getAccessor(), owner);
                if (value != null) {
                    if (value != INACCESSIBLE) {
                        if (expectedType.isInstance(value)) {
                            return value;
                        }
                    }
                }
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            var6++;
            /* goto @46; */
        }
        catch (Throwable type) {
            return null;
        }
        return null;
    }

    private static Object findRecordComponentByMethodNames(Object owner, int requiredMatches, String ... methodNames) {
        if (owner == null || requiredMatches <= 0 || methodNames == null || methodNames.length == 0) {
            return null;
        }
        try {
            Class<?> type = owner.getClass();
            if (!type.isRecord()) {
                return null;
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            RecordComponent[] components = type.getRecordComponents();
            if (components == null) {
                return null;
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            var var5 = components;
            var var6 = var5.length;
            int var7 = 0;
            L58: ;
            if (var7 >= var6) { /* goto @164; */ }
            RecordComponent component = var5[var7];
            Object value = PackUtilPacketInspector.invokeAccessor(component.getAccessor(), owner);
            if (value == null) { /* goto @158; */ }
            if (value == INACCESSIBLE) {
            } else {
                int matches = 0;
                var var11 = methodNames;
                var var12 = var11.length;
                for (int var13 = 0; var13 < var12; var13++) {
                    String methodName = var11[var13];
                    if (!PackUtilPacketInspector.hasNoArgMethod(value.getClass(), methodName)) continue;
                    matches++;
                }
                if (matches >= requiredMatches) {
                    return value;
                }
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            var7++;
            /* goto @58; */
        }
        catch (Throwable type) {
            return null;
        }
        return null;
    }

    private static Object findRecordTextComponent(Object owner, Object ... excludedValues) {
        if (owner == null) {
            return null;
        }
        try {
            Class<?> type = owner.getClass();
            if (!type.isRecord()) {
                return null;
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            RecordComponent[] components = type.getRecordComponents();
            if (components == null) {
                return null;
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            var var4 = components;
            var var5 = var4.length;
            int var6 = 0;
            L42: ;
            if (var6 >= var5) { /* goto @121; */ }
            RecordComponent component = var4[var6];
            Object value = PackUtilPacketInspector.invokeAccessor(component.getAccessor(), owner);
            if (value == null) { /* goto @115; */ }
            if (value == INACCESSIBLE) { /* goto @115; */ }
            if (PackUtilPacketInspector.isExcludedReference(value, excludedValues)) {
            } else {
                String text = PackUtilPacketInspector.extractTextValue(value);
                if (text != null) {
                    if (!text.isBlank()) {
                        return value;
                    }
                }
            }
        }
        catch (Throwable type) {
            return null;
        }
        try {
            var6++;
            /* goto @42; */
        }
        catch (Throwable type) {
            return null;
        }
        return null;
    }

    private static Integer getIntField(Object owner, String fieldName) {
        Object value = PackUtilPacketInspector.getField(owner, fieldName);
        Number number = (Number)value;
        return value instanceof Number ? number.intValue() : null;
    }

    private static Boolean getBooleanField(Object owner, String fieldName) {
        Object value = PackUtilPacketInspector.getField(owner, fieldName);
        Boolean bool = (Boolean)value;
        return value instanceof Boolean ? bool : null;
    }

    private static Object invokeNoArg(Object owner, String methodName) {
        if (owner == null || methodName == null) {
            return null;
        }
        try {
            Method method = owner.getClass().getMethod(methodName, new Class[0]);
            if (!method.canAccess(owner)) {
                method.setAccessible(true);
            }
            return method.invoke(owner, new Object[0]);
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static Object invokeFirstNoArg(Object owner, String ... methodNames) {
        var var2 = methodNames;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            String methodName = var2[var4];
            Object value = PackUtilPacketInspector.invokeNoArg(owner, methodName);
            if (value == null) continue;
            return value;
        }
        return null;
    }

    private static Object findInspectablePropertyValue(Object owner, String ... labels) {
        if (owner == null || labels == null || labels.length == 0) {
            return null;
        }
        List<PackUtilPacketInspector.PropertyValue> properties = PackUtilPacketInspector.getInspectableProperties(owner);
        var var3 = labels;
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String label = var3[var5];
            String normalizedTarget = PackUtilPacketInspector.normalizeName(label);
            var var8 = properties.iterator();
            while (var8.hasNext()) {
                PropertyValue property = (PackUtilPacketInspector.PropertyValue)var8.next();
                if (normalizedTarget.equals(PackUtilPacketInspector.normalizeName(property.label()))) {
                    Object value = property.value();
                    if (value != null) {
                        if (value == INACCESSIBLE) continue;
                        return value;
                    }
                }
            }
        }
        return null;
    }

    private static boolean hasNoArgMethod(Class<?> type, String methodName) {
        if (type == null || methodName == null || methodName.isBlank()) {
            return false;
        }
        try {
            type.getMethod(methodName, new Class[0]);
            return true;
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isExcludedReference(Object value, Object ... excludedValues) {
        if (value == null || excludedValues == null) {
            return false;
        }
        var var2 = excludedValues;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            Object excluded = var2[var4];
            if (value != excluded) continue;
            return true;
        }
        return false;
    }

    private static boolean packetMatchesHint(class_2596<?> packet, String packetNameHint, String ... names) {
        if (packetNameHint == null) { /* goto L43; */ }
        String simpleName = names;
        var var4 = simpleName.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String name = simpleName[var5];
            if (!name.equalsIgnoreCase(packetNameHint)) continue;
            return true;
        }
        simpleName = packet == null || packet.getClass() == null ? null : packet.getClass().getSimpleName();
        if (simpleName == null) { /* goto L116; */ }
        var4 = names;
        var5 = var4.length;
        for (name = 0; name < var5; name++) {
            String name = var4[name];
            if (!name.equalsIgnoreCase(simpleName)) continue;
            return true;
        }
        return false;
    }

    private static boolean isSimpleValue(Object value) {
        if (value == null) {
            return true;
        }
        return value instanceof String || value instanceof Number || value instanceof Boolean || value instanceof Character || value instanceof Enum || value instanceof UUID || value instanceof Instant || value instanceof class_2960 || value instanceof class_2561 || value instanceof class_2338 || value instanceof class_243 || value instanceof class_1297 || value instanceof class_1799 || value instanceof class_2520 || value instanceof class_2680 || value instanceof class_6880 || value instanceof BitSet || value instanceof Class;
    }

    private static boolean shouldTreatAsLeaf(Class<?> type) {
        if (type == null) {
            return true;
        }
        String name = type.getName();
        return class_1297.class.isAssignableFrom(type) || class_1799.class.isAssignableFrom(type) || class_2520.class.isAssignableFrom(type) || name.startsWith("net.minecraft.world.") || name.startsWith("net.minecraft.client.") || name.startsWith("io.netty.") || name.contains("PacketCodec") || name.contains("PacketType") || name.contains("ByteBuf");
    }

    private static int colorForValue(Object value) {
        if (!value instanceof Boolean) { /* goto L29; */ }
        Boolean bool = (Boolean)value;
        return bool.booleanValue() ? PackUtilColors.packetGreen() : PackUtilColors.packetPink();
        if (value instanceof class_1297 || value instanceof UUID) {
            return PackUtilColors.packetCyan();
        }
        if (value instanceof class_2680 || value instanceof class_2338 || value instanceof class_243) {
            return PackUtilColors.packetYellow();
        }
        if (value instanceof class_1799 || value instanceof class_2561 || value instanceof String) {
            return PackUtilColors.packetGreen();
        }
        if (value instanceof Enum) {
            return PackUtilColors.packetOrange();
        }
        if (value instanceof class_2960) {
            return PackUtilColors.packetBlue();
        }
        if (value instanceof Number || value instanceof Instant || value instanceof BitSet) {
            return PackUtilColors.packetGray();
        }
        return PackUtilColors.packetWhite();
    }

    private static int directionColor(String direction) {
        return "C2S".equalsIgnoreCase(direction) ? PackUtilColors.packetCyan() : PackUtilColors.packetOrange();
    }

    private static String formatSimpleValue(Object value) {
        if (value == null) {
            return "null";
        }
        if (value instanceof String) {
            String string = (String)value;
            return PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(string));
        }
        if (value instanceof Character) {
            c = (Character)value;
            return PackUtilPacketInspector.quote(String.valueOf(c));
        }
        if (value instanceof class_2561) {
            text = (class_2561)value;
            return PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(text.getString()));
        }
        if (value instanceof class_2960) {
            id = (class_2960)value;
            return id.toString();
        }
        if (value instanceof UUID) {
            uuid = (UUID)value;
            return uuid.toString();
        }
        if (value instanceof Instant) {
            instant = (Instant)value;
            return instant.toString();
        }
        if (value instanceof Enum) {
            enumValue = (Enum)value;
            return enumValue.name();
        }
        if (value instanceof class_2338) {
            pos = (class_2338)value;
            return PackUtilPacketInspector.formatBlockPos(pos);
        }
        if (value instanceof class_243) {
            vec = (class_243)value;
            return PackUtilPacketInspector.formatVec3(vec);
        }
        if (value instanceof class_1297) {
            entity = (class_1297)value;
            return PackUtilPacketInspector.formatEntity(entity);
        }
        if (value instanceof class_1799) {
            stack = (class_1799)value;
            return PackUtilPacketInspector.formatItemStack(stack);
        }
        if (value instanceof class_2520) {
            nbt = (class_2520)value;
            return PackUtilPacketInspector.shorten((String)nbt.method_68658().orElse(String.valueOf(nbt)));
        }
        if (value instanceof class_2680) {
            state = (class_2680)value;
            return PackUtilPacketInspector.formatBlockState(state);
        }
        if (value instanceof class_6880) {
            entry = (class_6880)value;
            return PackUtilPacketInspector.formatRegistryEntry(entry);
        }
        if (value instanceof BitSet) {
            bitSet = (BitSet)value;
            return PackUtilPacketInspector.formatBitSet(bitSet);
        }
        if (value instanceof Class) {
            clazz = (Class)value;
            return PackUtilPacketInspector.prettifyClassName(clazz);
        }
        return PackUtilPacketInspector.rewriteKnownClassAliases(PackUtilPacketInspector.shorten(String.valueOf(value)));
    }

    private static String safeLeafString(Object value) {
        if (value == null) {
            return "null";
        }
        if (PackUtilPacketInspector.isSimpleValue(value)) {
            return PackUtilPacketInspector.formatSimpleValue(value);
        }
        try {
            return PackUtilPacketInspector.rewriteKnownClassAliases(PackUtilPacketInspector.shorten(String.valueOf(value)));
        }
        catch (Throwable ignored) {
            return "<unprintable " + PackUtilPacketInspector.prettifyClassName(value.getClass()) + ">";
        }
    }

    private static String rawFallbackString(Object value) {
        if (value == null) {
            return null;
        }
        try {
            String raw = PackUtilPacketInspector.rewriteKnownClassAliases(PackUtilPacketInspector.shorten(String.valueOf(value)));
            if (raw == null || raw.isBlank()) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            if (PackUtilPacketInspector.looksLikeDefaultObjectString(raw)) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            return raw;
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static boolean looksLikeDefaultObjectString(String raw) {
        return raw != null && raw.matches("[\\w.$]+@[0-9a-fA-F]+");
    }

    private static String formatHotbarSlot(int slot) {
        if (slot >= 0 && slot <= 8) {
            return slot + 1 + " (hotbar index " + slot + ")";
        }
        return String.valueOf(slot);
    }

    private static String describePlayerAction(class_2846.class_2847 action) {
        switch (PackUtilPacketInspector.2.$SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[action.ordinal()]) {
            case 1::
                return "Start breaking targeted block";
            case 2::
                return "Abort breaking targeted block";
            case 3::
                return "Finish breaking targeted block";
            case 4::
                return "Drop full held stack";
            case 5::
                return "Drop one held item";
            case 6::
                return "Release item use";
            case 7::
                return "Swap main hand and offhand";
            default:
                return PackUtilPacketInspector.prettifyClassName(action.name());
        }
    }

    private static String describeSlotActionType(Object actionType) {
        if (actionType instanceof Enum) {
            Enum<?> enumValue = (Enum)actionType;
        } else {
            return actionType == null ? "Click Slot" : "Click Slot (" + PackUtilPacketInspector.safeLeafString(actionType) + ")";
        }
        var var2 = enumValue.name();
        int var3 = -1;
        switch (var2.hashCode()) {
            case -1935147396::
                if (!var2.equals("PICKUP")) { /* goto @215; */ }
                var3 = 0;
                /* goto @215; */
            case -2100865277::
                if (!var2.equals("QUICK_MOVE")) { /* goto @215; */ }
                var3 = 1;
                /* goto @215; */
            case 2558355::
                if (!var2.equals("SWAP")) { /* goto @215; */ }
                var3 = 2;
                /* goto @215; */
            case 64218429::
                if (!var2.equals("CLONE")) { /* goto @215; */ }
                var3 = 3;
                /* goto @215; */
            case 79802054::
                if (!var2.equals("THROW")) { /* goto @215; */ }
                var3 = 4;
                /* goto @215; */
            case -711480050::
                if (!var2.equals("QUICK_CRAFT")) { /* goto @215; */ }
                var3 = 5;
                /* goto @215; */
            case -478638786::
                if (var2.equals("PICKUP_ALL")) {
                    var3 = 6;
                }
            default:
                switch (var3) {
                    case 0::
                        return "Pick up / place stack";
                    case 1::
                        return "Quick move / shift-click";
                    case 2::
                        return "Swap with hotbar slot";
                    case 3::
                        return "Clone stack";
                    case 4::
                        return "Throw item";
                    case 5::
                        return "Drag split across slots";
                    case 6::
                        return "Pick up all matching items";
                    default:
                        return "Click Slot (" + enumValue.name() + ")";
                }
        }
    }

    private static String extractTextValue(Object value) {
        if (value == null || value == INACCESSIBLE) {
            return null;
        }
        if (value instanceof class_2561) {
            class_2561 text = (class_2561)value;
            return text.getString();
        }
        if (value instanceof String) {
            string = (String)value;
            return string;
        }
        if (value instanceof Optional) {
            optional = (Optional)value;
            return (String)optional.map(PackUtilPacketInspector::extractTextValue).orElse(null);
        }
        if (value instanceof String[]) {
            array = (String[])value;
            return String.join(" | ", array);
        }
        stringLike = PackUtilPacketInspector.invokeFirstNoArg(value, "getString", "string", "content", "raw", "name");
        if (stringLike instanceof class_2561) {
            class_2561 text = (class_2561)stringLike;
            return text.getString();
        }
        if (stringLike instanceof String) {
            string = (String)stringLike;
            return string;
        }
        return null;
    }

    private static String summarizeBookPages(Collection<?> pages) {
        List<String> previews = new ArrayList();
        int index = 0;
        var var3 = pages.iterator();
        while (var3.hasNext()) {
            Object page = var3.next();
            String text = PackUtilPacketInspector.extractTextValue(page);
            if (text == null || text.isBlank()) {
                if (page == null) continue;
                text = PackUtilPacketInspector.safeLeafString(page);
            }
            if (text != null) {
                if (text.isBlank()) continue;
                previews.add("p" + index + 1 + "=" + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(text)));
            }
            index++;
            if (previews.size() < 2) { /* goto @118; */ }
            break;
        }
        if (previews.isEmpty()) {
            return null;
        }
        return String.join(" | ", previews);
    }

    private static String summarizeSignLines(String[] lines) {
        List<String> parts = new ArrayList();
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i] == null ? "" : lines[i].trim();
            if (line.isEmpty()) {
            } else {
                parts.add("L" + i + 1 + "=" + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(line)));
            }
        }
        return parts.isEmpty() ? "<empty sign>" : String.join(" | ", parts);
    }

    private static PackUtilPacketInspector.ChatSummaryState appendChatSummary(Object messageValue, Object parameters, UUID senderUuid, Object timestampValue, Object filterMask, String kind, PackUtilPacketInspector.InspectionBuilder builder) {
        boolean wrote = false;
        boolean informative = false;
        builder.line("Kind: " + kind, PackUtilPacketInspector.semanticFieldColor("Kind", kind));
        if (kind != null && !kind.isBlank()) {
            wrote = true;
        }
        String chatType = PackUtilPacketInspector.extractMessageType(parameters);
        builder.line("Chat Type: " + chatType, PackUtilPacketInspector.semanticFieldColor("Chat Type", chatType));
        if (chatType != null && !chatType.isBlank()) {
            wrote = true;
            informative = true;
        }
        String sender = PackUtilPacketInspector.extractMessageSender(parameters, senderUuid);
        builder.line("Sender: " + sender, PackUtilPacketInspector.semanticFieldColor("Sender", sender));
        if (sender != null && !sender.isBlank()) {
            wrote = true;
            informative = true;
        }
        String target = PackUtilPacketInspector.extractMessageTarget(parameters);
        builder.line("Target: " + target, PackUtilPacketInspector.semanticFieldColor("Target", target));
        if (target != null && !target.isBlank()) {
            wrote = true;
            informative = true;
        }
        String message = PackUtilPacketInspector.extractTextValue(messageValue);
        if (message != null) {
            if (!message.isBlank()) {
                builder.line("Message: " + PackUtilPacketInspector.quote(PackUtilPacketInspector.shorten(message)), PackUtilPacketInspector.semanticFieldColor("Message", message));
                wrote = true;
                informative = true;
            }
        } else {
            if (messageValue != null) {
                builder.line("Message: " + PackUtilPacketInspector.summarizeValue(messageValue), PackUtilPacketInspector.colorForSummary("Message", messageValue));
                wrote = true;
                informative = true;
            }
        }
        if (timestampValue != null) {
            builder.line("Timestamp: " + PackUtilPacketInspector.safeLeafString(timestampValue), PackUtilPacketInspector.semanticFieldColor("Timestamp", timestampValue));
            wrote = true;
            informative = true;
        }
        String filter = PackUtilPacketInspector.describeFilterMask(filterMask);
        if (filter != null) {
            builder.line("Filter: " + filter, PackUtilPacketInspector.semanticFieldColor("Filter", filter));
            wrote = true;
            informative = true;
        }
        return new PackUtilPacketInspector.ChatSummaryState(wrote, informative);
    }

    private static String extractMessageSender(Object parameters, UUID senderUuid) {
        Object[] tmp0 = new Object[3];
        tmp0[0] = PackUtilPacketInspector.invokeNoArg(parameters, "name");
        tmp0[1] = PackUtilPacketInspector.getRecordComponentValue(parameters, 1);
        tmp0[2] = PackUtilPacketInspector.findRecordTextComponent(parameters, PackUtilPacketInspector.getRecordComponentValue(parameters, 0), PackUtilPacketInspector.getRecordComponentValue(parameters, 2));
        String senderName = PackUtilPacketInspector.extractTextValue(PackUtilPacketInspector.firstNonNull(tmp0));
        if (senderName == null || senderName.isBlank()) {
            senderName = PackUtilPacketInspector.resolvePlayerName(senderUuid);
        }
        if (senderName == null) { /* goto L108; */ }
        if (senderName.isBlank()) { /* goto L108; */ }
        return senderUuid == null ? PackUtilPacketInspector.shorten(senderName) : PackUtilPacketInspector.shorten(senderName) + " (" + String.valueOf(senderUuid) + ")";
        return senderUuid == null ? null : senderUuid.toString();
    }

    private static String extractMessageTarget(Object parameters) {
        Object[] tmp0 = new Object[2];
        tmp0[0] = PackUtilPacketInspector.invokeNoArg(parameters, "targetName");
        tmp0[1] = PackUtilPacketInspector.getRecordComponentValue(parameters, 2);
        String targetName = PackUtilPacketInspector.extractTextValue(PackUtilPacketInspector.firstNonNull(tmp0));
        return targetName == null || targetName.isBlank() ? null : PackUtilPacketInspector.shorten(targetName);
    }

    private static String extractMessageType(Object parameters) {
        Object[] tmp0 = new Object[2];
        tmp0[0] = PackUtilPacketInspector.invokeNoArg(parameters, "type");
        tmp0[1] = PackUtilPacketInspector.getRecordComponentValue(parameters, 0);
        Object type = PackUtilPacketInspector.firstNonNull(tmp0);
        return type == null ? null : PackUtilPacketInspector.safeLeafString(type);
    }

    private static String describeFilterMask(Object filterMask) {
        if (filterMask == null) {
            return null;
        }
        Object fullyFiltered = PackUtilPacketInspector.invokeNoArg(filterMask, "isFullyFiltered");
        if (Boolean.TRUE.equals(fullyFiltered)) {
            return "Fully filtered";
        }
        Object passThrough = PackUtilPacketInspector.invokeNoArg(filterMask, "isPassThrough");
        if (Boolean.TRUE.equals(passThrough)) {
            return "Pass-through";
        }
        return "Partially filtered";
    }

    private static String resolvePlayerName(UUID uuid) {
        if (uuid == null) {
            return null;
        }
        try {
            if (MC.method_1562() != null) {
                class_640 entry = MC.method_1562().method_2871(uuid);
                if (entry != null) {
                    if (entry.method_2966() != null) {
                        String profileName = PackUtilPacketInspector.extractTextValue(entry.method_2966());
                        if (profileName != null) {
                            if (!profileName.isBlank()) {
                                return profileName;
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable entry) {
            if (MC.field_1687 != null) {
                entry = MC.field_1687.method_18456().iterator();
                L86: ;
                if (entry.hasNext()) {
                    player = (class_742)entry.next();
                    if (uuid.equals(player.method_5667())) {
                        if (player.method_7334() != null) {
                            String profileName = PackUtilPacketInspector.extractTextValue(player.method_7334());
                            if (profileName != null) {
                                if (!profileName.isBlank()) {
                                    return profileName;
                                }
                            }
                        }
                    }
                }
            }
        }
        try {
            if (MC.field_1687 != null) {
                entry = MC.field_1687.method_18456().iterator();
                L86: ;
                if (entry.hasNext()) {
                    player = (class_742)entry.next();
                    if (uuid.equals(player.method_5667())) {
                        if (player.method_7334() != null) {
                            profileName = PackUtilPacketInspector.extractTextValue(player.method_7334());
                            if (profileName != null) {
                                if (!profileName.isBlank()) {
                                    return profileName;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable entry) {
            return null;
        }
        try {
            /* goto @86; */
        }
        catch (Throwable entry) {
            return null;
        }
        return null;
    }

    private static PackUtilPacketInspector.ParsedChatLine parseChatLine(String raw) {
        if (raw == null) {
            return null;
        }
        String text = raw.trim();
        if (text.isEmpty()) {
            return null;
        }
        if (text.startsWith("<")) {
            int end = text.indexOf("> ");
            if (end > 1) {
                if (end + 2 < text.length()) {
                    return new PackUtilPacketInspector.ParsedChatLine(text.substring(1, end).trim(), text.substring(end + 2).trim());
                }
            }
        }
        colon = text.indexOf(": ");
        if (colon > 0) {
            if (colon <= 48) {
                if (colon + 2 < text.length()) {
                    String sender = text.substring(0, colon).trim();
                    String message = text.substring(colon + 2).trim();
                    if (!sender.isEmpty()) {
                        if (!message.isEmpty()) {
                            return new PackUtilPacketInspector.ParsedChatLine(sender, message);
                        }
                    }
                }
            }
        }
        return null;
    }

    private static String formatEntity(class_1297 entity) {
        String typeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
        String name = entity.method_5476() == null ? "" : entity.method_5476().getString();
        return typeId + " #" + entity.method_5628() + " [" + PackUtilPacketInspector.shorten(name) + "] @" + PackUtilPacketInspector.formatVec3(new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321()));
    }

    private static String formatItemStack(class_1799 stack) {
        if (stack.method_7960()) {
            return "ItemStack.EMPTY";
        }
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        String name = stack.method_7964() == null ? "" : stack.method_7964().getString();
        String display = itemId;
        if (!name.isEmpty()) {
            if (!Objects.equals(name, stack.method_7909().method_63680().getString())) {
                display = display + " [" + PackUtilPacketInspector.shorten(name) + "]";
            }
        }
        return stack.method_7947() + "x " + display;
    }

    private static String formatBlockState(class_2680 state) {
        return String.valueOf(class_7923.field_41175.method_10221(state.method_26204())) + " " + PackUtilPacketInspector.shorten(state.toString());
    }

    private static String formatBlockPos(class_2338 pos) {
        return "x=" + pos.method_10263() + ", y=" + pos.method_10264() + ", z=" + pos.method_10260();
    }

    private static String formatVec3(class_243 vec) {
        return String.format(Locale.ROOT, "x=%.3f, y=%.3f, z=%.3f", vec.field_1352, vec.field_1351, vec.field_1350);
    }

    private static String formatBitSet(BitSet bitSet) {
        int shown = 0;
        StringBuilder builder = new StringBuilder("BitSet{");
        int bit = bitSet.nextSetBit(0);
        while (bit >= 0) {
            if (shown >= 16) {
                builder.append("...");
            } else {
                if (!shown > 0) continue;
                builder.append(", ");
                builder.append(bit);
                shown++;
                bit = bitSet.nextSetBit(bit + 1);
            }
        }
        builder.append("}");
        return builder.toString();
    }

    private static String formatRegistryEntry(class_6880<?> entry) {
        try {
            Optional<?> key = entry.method_40230();
            if (key.isPresent()) {
                return PackUtilPacketInspector.shorten(String.valueOf(key.get()));
            }
        }
        catch (Throwable value) {
            value = PackUtilPacketInspector.invokeNoArg(entry, "value");
            if (value != null) {
                return PackUtilPacketInspector.shorten(String.valueOf(value));
            }
        }
        try {
            value = PackUtilPacketInspector.invokeNoArg(entry, "value");
            if (value != null) {
                return PackUtilPacketInspector.shorten(String.valueOf(value));
            }
        }
        catch (Throwable value) {
            return PackUtilPacketInspector.shorten(String.valueOf(entry));
        }
    }

    private static String summarizeValue(Object value) {
        if (value == null || value == INACCESSIBLE) {
            return null;
        }
        if (PackUtilPacketInspector.isSimpleValue(value)) {
            return PackUtilPacketInspector.formatSimpleValue(value);
        }
        if (value instanceof Optional) {
            Optional<?> optional = (Optional)value;
            return (String)optional.map(PackUtilPacketInspector::summarizeValue).orElse("Optional.empty");
        }
        if (value instanceof Collection) {
            collection = (Collection)value;
            return PackUtilPacketInspector.prettifyClassName(value.getClass()) + "[" + collection.size() + "]";
        }
        if (value instanceof Map) {
            map = (Map)value;
            return "Map[" + map.size() + "]";
        }
        type = value.getClass();
        if (type.isArray()) {
            return type.getComponentType().getSimpleName() + "[" + Array.getLength(value) + "]";
        }
        return PackUtilPacketInspector.safeLeafString(value);
    }

    private static int colorForSummary(String label, Object value) {
        if (value == null || value == INACCESSIBLE) {
            return PackUtilColors.textMuted();
        }
        if (value instanceof Collection || value instanceof Map || value.getClass().isArray()) {
            return PackUtilColors.textSecondary();
        }
        return PackUtilPacketInspector.semanticFieldColor(label, value);
    }

    private static int colorForSummary(Object value) {
        return PackUtilPacketInspector.colorForSummary("", value);
    }

    private static int semanticFieldColor(String label, Object value) {
        String normalized = PackUtilPacketInspector.normalizeName(label);
        if (!value instanceof Boolean) { /* goto L34; */ }
        Boolean bool = (Boolean)value;
        return bool.booleanValue() ? PackUtilColors.packetGreen() : PackUtilColors.packetPink();
        if (normalized.contains("sender") || normalized.contains("author") || normalized.contains("player") || normalized.equals("entity") || normalized.contains("owner")) {
            return PackUtilColors.packetCyan();
        }
        if (normalized.contains("target") || normalized.contains("recipient") || normalized.contains("team")) {
            return PackUtilColors.packetPink();
        }
        if (normalized.contains("message") || normalized.contains("content") || normalized.equals("text") || normalized.contains("title") || normalized.contains("book") || normalized.contains("page") || normalized.contains("sign") || normalized.contains("recipe") || normalized.contains("item") || normalized.contains("stack")) {
            return PackUtilColors.packetGreen();
        }
        if (normalized.equals("kind") || normalized.contains("action") || normalized.contains("interaction") || normalized.equals("type") || normalized.contains("mode") || normalized.contains("reason") || normalized.contains("status") || normalized.contains("hand")) {
            return PackUtilColors.packetOrange();
        }
        if (normalized.contains("timestamp") || normalized.contains("time") || normalized.contains("sequence") || normalized.contains("salt")) {
            return PackUtilColors.packetLightYellow();
        }
        if (normalized.contains("slot") || normalized.contains("syncid") || normalized.contains("index") || normalized.contains("revision") || normalized.contains("checksum") || normalized.contains("offset")) {
            return PackUtilColors.packetBlue();
        }
        if (normalized.contains("sound") || normalized.contains("channel") || normalized.contains("identifier") || normalized.contains("packettype")) {
            return PackUtilColors.packetBlue();
        }
        if (normalized.contains("block") || normalized.contains("pos") || normalized.equals("x") || normalized.equals("y") || normalized.equals("z") || normalized.contains("yaw") || normalized.contains("pitch") || normalized.contains("velocity")) {
            return PackUtilColors.packetYellow();
        }
        if (!normalized.contains("filter")) { /* goto L608; */ }
        text = value == null ? "" : String.valueOf(value).toLowerCase(Locale.ROOT);
        if (text.contains("fully filtered")) {
            return PackUtilColors.packetPink();
        }
        if (text.contains("pass-through")) {
            return PackUtilColors.packetGreen();
        }
        return PackUtilColors.packetYellow();
        L608: ;
        return PackUtilPacketInspector.colorForValue(value);
    }

    private static String prettifyLabel(String label) {
        return PackUtilPacketInspector.prettifyClassName(label).replace(46, 32).trim();
    }

    private static String decapitalize(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return Character.toLowerCase(value.charAt(0)) + value.substring(1);
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "";
        }
        return value.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
    }

    private static boolean isObfuscatedComponentLabel(String label) {
        if (label == null || label.isBlank()) {
            return false;
        }
        String normalized = label.trim().toLowerCase(Locale.ROOT);
        return normalized.matches("(comp|field|method|class)_?\\d+");
    }

    private static boolean isIgnoredPropertyLabel(String label) {
        if (label == null || label.isBlank()) {
            return false;
        }
        return IGNORED_PROPERTY_METHODS.contains(label) || IGNORED_PROPERTY_NORMALIZED.contains(PackUtilPacketInspector.normalizeName(label));
    }

    private static int countNonEmpty(List<class_1799> stacks) {
        int count = 0;
        var var2 = stacks.iterator();
        while (var2.hasNext()) {
            class_1799 stack = (class_1799)var2.next();
            if (stack != null) {
                if (stack.method_7960()) continue;
                count++;
            }
        }
        return count;
    }

    private static PackUtilPacketInspector.InteractionCapture captureInteraction(class_2824 packet) {
        InteractionCapture capture = new PackUtilPacketInspector.InteractionCapture();
        try {
            packet.method_34209(new PackUtilPacketInspector.1(capture));
        }
        catch (Throwable ignored) {
            Object interactionType = PackUtilPacketInspector.getField(packet, "type");
            if (interactionType != null) {
                if (interactionType != INACCESSIBLE) {
                    capture.kind = PackUtilPacketInspector.prettifyClassName(interactionType.getClass());
                    Object hand = PackUtilPacketInspector.firstNonNullField(interactionType, "hand", "interactionHand");
                    if (hand instanceof class_1268) {
                        class_1268 actualHand = (class_1268)hand;
                        capture.hand = actualHand;
                    }
                    hitPos = PackUtilPacketInspector.firstNonNullField(interactionType, "pos", "hitPos", "location");
                    if (hitPos instanceof class_243) {
                        class_243 actualHitPos = (class_243)hitPos;
                        capture.hitPos = actualHitPos;
                    }
                }
            }
            return capture;
        }
        return capture;
    }

    private static String formatPrimitiveArray(Object array) {
        int length = Array.getLength(array);
        StringBuilder builder = new StringBuilder();
        builder.append(array.getClass().getComponentType().getSimpleName()).append(91).append(length).append("] ");
        builder.append(91);
        int shown = Math.min(length, 64);
        for (int i = 0; i < shown; i++) {
            if (!i > 0) continue;
            builder.append(", ");
            builder.append(Array.get(array, i));
        }
        if (length > shown) {
            builder.append(", ...");
        }
        builder.append(93);
        return builder.toString();
    }

    private static String prettifyClassName(Class<?> type) {
        if (type == null) {
            return "Unknown";
        }
        String alias = PackUtilYarnMappings.lookupClassAlias(type);
        if (alias != null && !alias.isBlank()) {
            return PackUtilPacketInspector.prettifyClassName(alias);
        }
        return PackUtilPacketInspector.prettifyClassName(type.getSimpleName().isEmpty() ? type.getName() : type.getSimpleName());
    }

    private static String prettifyClassName(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        String[] tmp0 = new String[2];
        tmp0[0] = PackUtilYarnMappings.lookupClassAlias(value.replace(47, 46));
        tmp0[1] = PackUtilYarnMappings.lookupSimpleClassAlias(value.substring(value.lastIndexOf(46) + 1));
        String alias = PackUtilPacketInspector.firstNonBlank(tmp0);
        String source = (alias == null ? value : alias).replace(36, 46);
        if (source.endsWith("Packet")) {
            source = source.substring(0, source.length() - 6);
        }
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < source.length(); i++) {
            char ch = source.charAt(i);
            if (i > 0) {
                if (Character.isUpperCase(ch)) {
                    if (!Character.isLowerCase(source.charAt(i - 1))) continue;
                    builder.append(32);
                }
            }
            builder.append(ch);
        }
        return builder.toString();
    }

    private static String normalizeAccessorLabel(String label, Class<?> returnType) {
        if (label == null || label.isBlank()) {
            return label;
        }
        if (label.startsWith("get") && label.length() > 3 && Character.isUpperCase(label.charAt(3))) {
            return label.substring(3);
        }
        if (label.startsWith("is")) {
            if (label.length() > 2) {
                if (Character.isUpperCase(label.charAt(2))) {
                    if (returnType == Boolean.TYPE || returnType == Boolean.class) {
                        return label.substring(2);
                    }
                }
            }
        }
        return label;
    }

    private static String summarizeEquipmentEntries(Collection<?> equipmentEntries) {
        if (equipmentEntries == null || equipmentEntries.isEmpty()) {
            return null;
        }
        List<String> parts = new ArrayList();
        int shown = 0;
        var var3 = equipmentEntries.iterator();
        while (var3.hasNext()) {
            Object entry = var3.next();
            if (shown >= 6) {
                parts.add("... +" + equipmentEntries.size() - shown + " more");
            } else {
                String summary = PackUtilPacketInspector.summarizeEquipmentEntry(entry);
                if (summary != null) {
                    if (!summary.isBlank()) {
                        parts.add(summary);
                        shown++;
                    }
                }
            }
        }
        return parts.isEmpty() ? null : String.join(", ", parts);
    }

    private static String summarizeEquipmentEntry(Object entry) {
        if (entry == null) {
            return null;
        }
        Object[] tmp0 = new Object[3];
        tmp0[0] = PackUtilPacketInspector.invokeFirstNoArg(entry, "getFirst", "first", "slot", "getSlot");
        tmp0[1] = PackUtilPacketInspector.getRecordComponentValue(entry, 0);
        tmp0[2] = PackUtilPacketInspector.getField(entry, "first");
        Object slot = PackUtilPacketInspector.firstNonNull(tmp0);
        Object[] tmp2 = new Object[3];
        tmp2[0] = PackUtilPacketInspector.invokeFirstNoArg(entry, "getSecond", "second", "stack", "getStack");
        tmp2[1] = PackUtilPacketInspector.getRecordComponentValue(entry, 1);
        tmp2[2] = PackUtilPacketInspector.getField(entry, "second");
        Object stack = PackUtilPacketInspector.firstNonNull(tmp2);
        if (slot == null && stack == null) {
            return PackUtilPacketInspector.summarizeValue(entry);
        }
        String slotText = slot == null ? "Unknown Slot" : PackUtilPacketInspector.safeLeafString(slot);
        class_1799 itemStack = (class_1799)stack;
        String stackText = stack instanceof class_1799 ? PackUtilPacketInspector.formatItemStack(itemStack) : PackUtilPacketInspector.summarizeValue(stack);
        return slotText + "=" + stackText;
    }

    private static String rewriteKnownClassAliases(String raw) {
        if (raw == null || raw.isBlank()) {
            return raw;
        }
        String rewritten = PackUtilPacketInspector.replaceAliases(raw, QUALIFIED_CLASS_ALIAS_PATTERN, true);
        rewritten = PackUtilPacketInspector.replaceAliases(rewritten, SIMPLE_CLASS_ALIAS_PATTERN, false);
        return rewritten;
    }

    private static String replaceAliases(String raw, Pattern pattern, boolean qualified) {
        Matcher matcher = pattern.matcher(raw);
        StringBuffer buffer = new StringBuffer();
        boolean changed = false;
        while (matcher.find()) {
            String original = matcher.group(1);
            String alias = qualified ? PackUtilYarnMappings.lookupClassAlias(original) : PackUtilYarnMappings.lookupSimpleClassAlias(original);
            if (alias == null) continue;
            while (alias.isBlank()) {
            }
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(alias));
            changed = true;
        }
        if (!changed) {
            return raw;
        }
        matcher.appendTail(buffer);
        return buffer.toString();
    }

    private static String quote(String value) {
        return "\"" + value + "\"";
    }

    private static String shorten(String value) {
        if (value == null) {
            return "";
        }
        String sanitized = value.replace(10, 32).replace(13, 32).trim();
        if (sanitized.length() <= 320) {
            return sanitized;
        }
        return sanitized.substring(0, 317) + "...";
    }

    private static class_2680 getWorldBlockState(class_2338 pos) {
        try {
            return MC.field_1687 != null ? MC.field_1687.method_8320(pos) : null;
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    static {
        String[] tmp0 = new String[13];
        tmp0[0] = "getClass";
        tmp0[1] = "getPacketType";
        tmp0[2] = "toString";
        tmp0[3] = "hashCode";
        tmp0[4] = "copy";
        tmp0[5] = "apply";
        tmp0[6] = "write";
        tmp0[7] = "read";
        tmp0[8] = "streamCodec";
        tmp0[9] = "codec";
        tmp0[10] = "isWritingErrorSkippable";
        tmp0[11] = "writingErrorSkippable";
        tmp0[12] = "WritingErrorSkippable";
        IGNORED_PROPERTY_METHODS = Set.of(tmp0);
        String[] tmp1 = new String[12];
        tmp1[0] = "getclass";
        tmp1[1] = "getpackettype";
        tmp1[2] = "tostring";
        tmp1[3] = "hashcode";
        tmp1[4] = "copy";
        tmp1[5] = "apply";
        tmp1[6] = "write";
        tmp1[7] = "read";
        tmp1[8] = "streamcodec";
        tmp1[9] = "codec";
        tmp1[10] = "iswritingerrorskippable";
        tmp1[11] = "writingerrorskippable";
        IGNORED_PROPERTY_NORMALIZED = Set.of(tmp1);
        String[] tmp2 = new String[30];
        tmp2[0] = "id";
        tmp2[1] = "syncId";
        tmp2[2] = "revision";
        tmp2[3] = "slot";
        tmp2[4] = "contents";
        tmp2[5] = "cursorStack";
        tmp2[6] = "trackedValues";
        tmp2[7] = "values";
        tmp2[8] = "reason";
        tmp2[9] = "value";
        tmp2[10] = "hand";
        tmp2[11] = "sequence";
        tmp2[12] = "yaw";
        tmp2[13] = "pitch";
        tmp2[14] = "chunkX";
        tmp2[15] = "chunkZ";
        tmp2[16] = "chunkData";
        tmp2[17] = "lightData";
        tmp2[18] = "sound";
        tmp2[19] = "category";
        tmp2[20] = "x";
        tmp2[21] = "y";
        tmp2[22] = "z";
        tmp2[23] = "onGround";
        tmp2[24] = "name";
        tmp2[25] = "screenHandlerType";
        tmp2[26] = "type";
        tmp2[27] = "state";
        tmp2[28] = "mode";
        tmp2[29] = "seed";
        EXTRA_ACCESSOR_NAMES = Set.of(tmp2);
    }
}
