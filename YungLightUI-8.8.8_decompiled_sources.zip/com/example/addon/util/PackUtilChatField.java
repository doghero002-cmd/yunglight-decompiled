/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.util.PackUtilText;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilChatField {
    private static final PackUiTheme THEME = new PackUiTheme();
    private final class_310 mc;
    private final class_327 textRenderer;
    private final PackUiTextField field = new PackUiTextField().setHorizontalPadding(3).setTextYOffset(1);
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean submitOnEnter;
    private Predicate<String> submitHandler;
    private String placeholderText = "";

    public PackUtilChatField(class_310 mc, class_327 textRenderer, int x, int y, int width, int height, boolean submitOnEnter) {
        this.mc = mc;
        this.textRenderer = textRenderer;
        this.x = x;
        this.y = y;
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.submitOnEnter = submitOnEnter;
        this.syncBounds();
    }

    public void setSubmitOnEnter(boolean submitOnEnter) {
        this.submitOnEnter = submitOnEnter;
    }

    public void setSubmitHandler(Predicate<String> submitHandler) {
        this.submitHandler = submitHandler;
    }

    public void setChangedListener(Consumer<String> changedListener) {
        this.field.setOnChange(changedListener);
    }

    public void setDisplayTextProvider(Function<String, class_2561> displayTextProvider) {
        this.field.setDisplayTextProvider(displayTextProvider);
    }

    public void setMultiline(boolean multiline) {
        this.field.setMultiline(multiline);
    }

    public void setPlaceholder(class_2561 placeholder) {
        this.placeholderText = placeholder == null ? "" : PackUtilText.sanitizeUiLabel(placeholder.getString());
        this.field.setPlaceholder(this.placeholderText);
    }

    public String getPlaceholderText() {
        return this.placeholderText;
    }

    public void setDrawsBackground(boolean drawsBackground) {
        this.field.setDrawBackground(drawsBackground);
    }

    public void setEditable(boolean editable) {
        this.field.setEditable(editable);
    }

    public void setFilter(Predicate<String> filter) {
        this.field.setFilter(filter);
    }

    public void setNumericOnly(boolean allowNegative) {
        this.field.setFilter(PackUtilChatField::lambda$setNumericOnly$0 /* captured: allowNegative */);
    }

    public boolean isFocused() {
        return this.field.isFocused();
    }

    public void setFocused(boolean focused) {
        this.field.setFocused(focused);
    }

    public void setMaxLength(int maxLength) {
        this.field.setMaxLength(maxLength);
    }

    public void setText(String text) {
        this.field.setText(text);
    }

    public String getText() {
        return this.field.text();
    }

    public void write(String content) {
        if (content == null || content.isEmpty() || !this.field.isFocused() || !this.field.isEditable()) {
            return;
        }
        PackUiRenderContext context = this.inputContext();
        for (int i = 0; i < content.length(); i++) {
            this.field.charTyped(context, content.charAt(i), 0);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return false;
        }
        this.syncBounds();
        if (!this.contains(mouseX, mouseY)) {
            this.field.setFocused(false);
            return false;
        }
        return this.field.mouseClicked(this.inputContext(), (float)mouseX, (float)mouseY, button);
    }

    public boolean mouseClicked(class_11909 click, boolean ignored) {
        return this.mouseClicked(click.comp_4798(), click.comp_4799(), 0);
    }

    public boolean keyPressed(class_11908 keyInput) {
        if (!this.field.isFocused()) {
            return false;
        }
        int key = keyInput.comp_4795();
        if (key == 257 || key == 335) {
            if (this.submitOnEnter) {
                return this.handleSubmit();
            }
            this.field.setFocused(false);
            return true;
        }
        return this.field.keyPressed(this.inputContext(), key, keyInput.comp_4796(), keyInput.comp_4797());
    }

    public boolean charTyped(class_11905 charInput) {
        return this.field.isFocused() && this.field.charTyped(this.inputContext(), (char)charInput.comp_4793(), charInput.comp_4794());
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        this.syncBounds();
        this.field.render(this.renderContext(context, mouseX, mouseY, delta));
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
        this.syncBounds();
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
        this.syncBounds();
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int width) {
        this.width = Math.max(1, width);
        this.syncBounds();
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = Math.max(1, height);
        this.syncBounds();
    }

    public void setSelectionEnd(int selectionEnd) {
        this.field.setSelectionEnd(selectionEnd);
    }

    private void syncBounds() {
        this.field.setBounds((float)this.x, (float)this.y, (float)this.width, (float)this.height);
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }

    private boolean handleSubmit() {
        String value = this.field.text().trim();
        if (value.isEmpty()) {
            return true;
        }
        boolean submitted = this.submitHandler != null ? this.submitHandler.test(value) : this.sendChat(value);
        if (!submitted) {
            return true;
        }
        if (this.mc.field_1705 != null) {
            this.mc.field_1705.method_1743().method_1803(value);
        }
        this.field.setText("");
        this.field.setFocused(false);
        return true;
    }

    private boolean sendChat(String message) {
        if (this.mc.method_1562() == null) {
            YungLightAddon.LOG.warn("Failed to send PackUtil chat message because network handler was null.");
            return false;
        }
        this.mc.method_1562().method_45730(message.substring(1));
        if (message.startsWith("/") && message.length() > 1) {
        } else {
            this.mc.method_1562().method_45729(message);
        }
        return true;
    }

    private PackUiRenderContext inputContext() {
        return new PackUiRenderContext(null, this.textRenderer, PackUiViewport.current(2f), THEME, 0f, 0f, 0f);
    }

    private PackUiRenderContext renderContext(class_332 drawContext, int mouseX, int mouseY, float delta) {
        return new PackUiRenderContext(drawContext, this.textRenderer, PackUiViewport.current(2f), THEME, (float)mouseX, (float)mouseY, delta);
    }
}
