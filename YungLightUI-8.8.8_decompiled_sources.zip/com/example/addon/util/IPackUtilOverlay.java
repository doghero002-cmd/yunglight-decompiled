/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilWindowLayout;
import net.minecraft.class_332;

public interface IPackUtilOverlay {
    public void render(class_332 var1, int var2, int var3, float var4);

    public boolean mouseClicked(double var1, double var3, int var5);

    public boolean mouseReleased(double var1, double var3, int var5);

    public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8);

    public boolean mouseScrolled(double var1, double var3, double var5);

    public boolean keyPressed(int var1, int var2, int var3);

    public boolean charTyped(char var1, int var2);

    public boolean isVisible();

    public void setVisible(boolean var1);

    public boolean isMouseOver(double var1, double var3);

    public boolean isOverDragBar(double var1, double var3);

    public int getZLevel() {
        return 0;
    }

    public boolean isCollapsed() {
        return false;
    }

    public void setCollapsed(boolean collapsed) {
    }

    public void toggleCollapsed() {
        this.setCollapsed(!this.isCollapsed());
    }

    public boolean hasTextFieldFocused() {
        return false;
    }

    public void clearTextFieldFocus() {
    }

    public boolean wantsKeyboardCapture() {
        return false;
    }

    public String getOverlayId() {
        return this.getClass().getSimpleName();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(0, 0, this.getMinWidth(), this.getMinHeight(), this.isVisible(), this.isCollapsed());
    }

    public void setBounds(PackUtilWindowLayout bounds) {
    }

    public int getMinWidth() {
        return 240;
    }

    public int getMinHeight() {
        return 140;
    }

    public boolean isOverResizeHandle(double mouseX, double mouseY) {
        return false;
    }

    public boolean usesSharedHeaderClickCollapse() {
        return false;
    }

    public void saveLayout() {
        PackUtilSharedState.get().setWindowLayout(this.getOverlayId(), this.getBounds());
    }

    public void restoreLayout() {
        PackUtilWindowLayout layout = PackUtilSharedState.get().getWindowLayout(this.getOverlayId());
        if (layout != null) {
            this.setBounds(layout);
        }
    }
}
