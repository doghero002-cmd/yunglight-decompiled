/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilFabricatorOverlay;

final class PackUtilFabricatorOverlay.FabricatorAction.4
extends PackUtilFabricatorOverlay.FabricatorAction {
    boolean isCraftAction() {
        return true;
    }

    PackUtilDropAction toPacketAction(boolean dropWholeStack) {
        return PackUtilDropAction.QUICK_MOVE;
    }
}
