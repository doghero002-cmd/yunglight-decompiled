/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilCraftingHelper;
import com.example.addon.util.PackUtilLocalCraftingRegistry;
import net.minecraft.class_10297;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public static final class PackUtilCraftingHelper.CraftableRecipeOption {
    public final String recipeKey;
    public final int recipeId;
    public final int syncedRecipeId;
    public final class_10297 syncedEntry;
    public final PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe;
    public final class_1799 result;
    public final String label;
    public final String registryId;
    public final String searchKey;
    public final boolean hasMaterialsNow;
    public final boolean hasInventoryRoomNow;
    public final int maxCraftsByMaterials;
    public final int maxCraftsByStorage;
    public final boolean craftableNow;
    public final int maxCraftsNow;
    public final int maxOutputNow;
    public final PackUtilCraftingHelper.CraftSource craftSource;

    public PackUtilCraftingHelper.CraftableRecipeOption(PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe, class_10297 syncedEntry, int maxCraftsByMaterials, int maxCraftsByStorage, PackUtilCraftingHelper.CraftSource craftSource) {
        this.localRecipe = localRecipe;
        this.syncedEntry = syncedEntry;
        this.recipeKey = localRecipe.recipeKey;
        this.recipeId = localRecipe.recipeKey.hashCode();
        this.syncedRecipeId = syncedEntry != null ? syncedEntry.comp_3262().comp_3267() : -1;
        this.result = localRecipe.result.method_7972();
        this.label = this.result.method_7964().getString();
        this.maxCraftsByMaterials = Math.max(0, maxCraftsByMaterials);
        this.maxCraftsByStorage = Math.max(0, maxCraftsByStorage);
        this.hasMaterialsNow = this.maxCraftsByMaterials > 0;
        this.hasInventoryRoomNow = this.maxCraftsByStorage > 0;
        this.maxCraftsNow = Math.max(0, Math.min(this.maxCraftsByMaterials, this.maxCraftsByStorage));
        this.craftableNow = this.maxCraftsNow > 0;
        this.maxOutputNow = this.maxCraftsNow * Math.max(1, this.result.method_7947());
        this.craftSource = craftSource == null ? PackUtilCraftingHelper.CraftSource.PLAYER_2X2 : craftSource;
        class_2960 id = this.result.method_7909() == null ? null : class_7923.field_41178.method_10221(this.result.method_7909());
        this.registryId = id == null ? "" : id.toString();
        this.searchKey = this.label + " " + this.registryId + " " + this.recipeKey.toLowerCase();
    }

    public boolean hasSyncedRecipe() {
        return this.syncedEntry != null && this.syncedRecipeId >= 0;
    }
}
