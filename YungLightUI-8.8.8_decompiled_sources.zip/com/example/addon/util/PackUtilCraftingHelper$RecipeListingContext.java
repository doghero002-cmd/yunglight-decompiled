/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilCraftingHelper;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10297;
import net.minecraft.class_1799;

private static final class PackUtilCraftingHelper.RecipeListingContext {
    private final PackUtilCraftingHelper.CraftSource source;
    private final int gridWidth;
    private final int gridHeight;
    private final List<class_1799> inputStacks;
    private final Map<String, class_10297> syncedBySignature;

    private PackUtilCraftingHelper.RecipeListingContext(PackUtilCraftingHelper.CraftSource source, int gridWidth, int gridHeight, List<class_1799> inputStacks, Map<String, class_10297> syncedBySignature) {
        this.source = source;
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        this.inputStacks = inputStacks == null ? List.of() : List.copyOf(inputStacks);
        this.syncedBySignature = syncedBySignature == null ? Map.of() : Map.copyOf(syncedBySignature);
    }
}
