/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilCustomFilterPresetOverlay;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketSelectorOverlay;
import com.example.addon.util.PackUtilText;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilCustomFilterOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final int DEFAULT_PANEL_WIDTH = 220;
    private static final int MIN_PANEL_WIDTH = 220;
    private static final int ACTION_HEIGHT = 13;
    private static final int ACTION_GAP = 2;
    private static final int SECTION_GAP = 6;
    private static final int SEARCH_HEIGHT = 16;
    private static final int FILTER_ROW_HEIGHT = 14;
    private static final int FILTER_FOOTER_HEIGHT = 12;
    private static final int FILTER_FOOTER_GAP = 4;
    private static final int FILTER_ROW_STEP = 15;
    private static final int SCROLLBAR_GUTTER = 8;
    private static final int SCROLLBAR_TRACK_WIDTH = 3;
    private static final int SCROLLBAR_NONE = 0;
    private static final int SCROLLBAR_C2S = 1;
    private static final int SCROLLBAR_S2C = 2;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiTextField c2sSearchField;
    private final PackUiTextField s2cSearchField;
    private final PackUtilPacketSelectorOverlay packetSelectorOverlay;
    private final PackUtilCustomFilterPresetOverlay presetManagerOverlay;
    private final List<PackUtilCustomFilterOverlay.ActionButton> buttons = new ArrayList();
    private final PackUtilCustomFilterOverlay.PacketListState c2sListState = new PackUtilCustomFilterOverlay.PacketListState();
    private final PackUtilCustomFilterOverlay.PacketListState s2cListState = new PackUtilCustomFilterOverlay.PacketListState();
    private int panelX = 260;
    private int panelY = 36;
    private int panelWidth = 220;
    private int panelHeight = 326;
    private boolean visible = false;
    private boolean collapsed = false;
    private boolean dragging = false;
    private boolean resizing = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    private double resizeStartMouseX = 0;
    private double resizeStartMouseY = 0;
    private int resizeStartWidth = 0;
    private int resizeStartHeight = 0;
    private int activeScrollbarDrag = 0;
    private int scrollbarGrabOffset = 0;

    public PackUtilCustomFilterOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.panelWidth = this.defaultPanelWidth();
        this.panelHeight = this.defaultPanelHeight();
        this.c2sSearchField = this.createField("Search C2S packets...");
        this.s2cSearchField = this.createField("Search S2C packets...");
        this.packetSelectorOverlay = new PackUtilPacketSelectorOverlay(textRenderer);
        this.presetManagerOverlay = new PackUtilCustomFilterPresetOverlay(textRenderer);
        this.c2sSearchField.setOnChange(this::lambda$new$0);
        this.s2cSearchField.setOnChange(this::lambda$new$1);
    }

    private PackUiTextField createField(String placeholder) {
        PackUiTextField field = new PackUiTextField().setPlaceholder(placeholder).setFieldHeight(this.searchHeight()).setMinWidth(120f).setPreferredWidth(120f).setTextTone(PackUiTone.BODY).setPlaceholderTone(PackUiTone.MUTED);
        return field;
    }

    public PackUtilCustomFilterPresetOverlay getPresetManagerOverlay() {
        return this.presetManagerOverlay;
    }

    public PackUtilPacketSelectorOverlay getPacketSelectorOverlay() {
        return this.packetSelectorOverlay;
    }

    public String getOverlayId() {
        return "packutil-custom-filter";
    }

    public int getMinWidth() {
        return this.defaultPanelWidth();
    }

    public int getMinHeight() {
        return this.defaultPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = this.defaultPanelWidth();
        this.panelHeight = Math.max(this.getMinHeight(), clamped.height);
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visible) {
            PackUtilOverlayManager.get().bringToFront(this);
        } else {
            this.clearFocus();
            this.packetSelectorOverlay.close();
        }
        this.saveLayout();
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.saveLayout();
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.panelWidth) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + 16) && !this.isOverWindowControl(mouseX, mouseY, bounds);
    }

    public boolean hasTextFieldFocused() {
        return this.packetSelectorOverlay.isVisible() || this.c2sSearchField.isFocused() || this.s2cSearchField.isFocused();
    }

    public void clearTextFieldFocus() {
        this.clearFocus();
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        this.buttons.clear();
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
        if (this.dragging) { /* goto L151; */ }
        this.renderWindowFrame(context, mouseX, mouseY, bounds, "Custom Filter", this.collapsed, this.resizing);
        boolean clipBody = this.beginWindowBodyClip(context, bounds, this.collapsed);
        if (clipBody) { /* goto @208; */ }
        if (this.dragging) { /* goto L199; */ }
        this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.resizing);
        return;
        try {
            int x = this.panelX + this.panelInset();
            int y = this.panelY + 16 + this.topInset();
            int width = this.panelWidth - this.panelInset() * 2;
            PackUtilModule module = PackUtilModule.get();
            y = this.drawAction(context, mouseX, mouseY, x, y, width, "Custom Filter " + module.shouldUseCustomPackets() ? "On" : "Off", PackUtilCustomFilterOverlay::lambda$render$2 /* captured: module */, module.shouldUseCustomPackets() ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER, true);
            PackUtilText.draw(context, this.textRenderer, "C2S " + module.getC2SPackets().size() + " | S2C " + module.getS2CPackets().size(), PackUtilText.Tone.MUTED, x, y, false);
            y = y + (this.infoLineHeight() + this.actionGap());
            y = this.drawAction(context, mouseX, mouseY, x, y, width, "Presets", this::lambda$render$3, PackUiOverlayButton.Variant.SECONDARY, true);
            y = y + (this.sectionGap() - this.actionGap());
            int availableHeight = Math.max(this.sectionMinimumHeight() * 2 + this.sectionGap(), this.panelHeight - (y - this.panelY) - this.panelInset());
            int sectionHeight = Math.max(this.sectionMinimumHeight(), (availableHeight - this.sectionGap()) / 2);
            y = this.renderPacketSection(context, mouseX, mouseY, delta, x, y, width, sectionHeight, true, module, this.c2sSearchField, this.c2sListState);
            this.renderPacketSection(context, mouseX, mouseY, delta, x, y, width, sectionHeight, false, module, this.s2cSearchField, this.s2cListState);
        }
        finally {
            this.endWindowBodyClip(context, clipBody);
            if (this.dragging) { /* goto L591; */ }
            this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.resizing);
            throw var14;
        }
        if (this.packetSelectorOverlay.isVisible()) {
            this.packetSelectorOverlay.render(context, mouseX, mouseY, delta);
        }
    }

    private int renderPacketSection(class_332 context, int mouseX, int mouseY, float delta, int x, int y, int width, int sectionHeight, boolean c2s, PackUtilModule module, PackUiTextField searchField, PackUtilCustomFilterOverlay.PacketListState listState) {
        int sectionStartY = y;
        String label = c2s ? "C2S Packets" : "S2C Packets";
        List<Class<? extends class_2596<?>>> packets = new ArrayList(c2s ? module.getC2SPackets() : module.getS2CPackets());
        packets.sort(Comparator.comparing(PackUtilPacketNamer::getFriendlyName, String.CASE_INSENSITIVE_ORDER));
        List<Class<? extends class_2596<?>>> filteredPackets = this.filterPackets(packets, searchField.text());
        listState.filteredPackets = filteredPackets;
        PackUiListRenderer.drawHeader(context, this.textRenderer, label + " (" + packets.size() + ")", x, y);
        y = y + (this.headerLabelHeight() + 2);
        searchField.setBounds((float)x, (float)y, (float)width, (float)this.searchHeight());
        searchField.render(this.renderContext(context, mouseX, mouseY, delta));
        y = y + (this.searchHeight() + this.actionGap());
        y = this.drawAction(context, mouseX, mouseY, x, y, width, c2s ? "Add C2S" : "Add S2C", this::lambda$renderPacketSection$6 /* captured: c2s, module */, PackUiOverlayButton.Variant.SECONDARY, true);
        int listHeight = Math.max(this.listMinimumHeight(), sectionHeight - (y - sectionStartY) - this.footerHeight() - this.footerGap());
        int viewHeight = Math.max(1, this.alignViewportHeight(Math.max(1, listHeight - 4), this.filterRowStep()));
        int contentHeight = filteredPackets.size() * this.filterRowStep();
        int maxScroll = Math.max(0, contentHeight - viewHeight);
        int visualScroll = listState.scroll.tick(delta, maxScroll);
        boolean focused = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        PackUiListRenderer.drawFrame(context, x, y, width, listHeight, focused);
        Metrics scrollbar = this.computePacketScrollbarMetrics(x, y, width, listHeight, contentHeight, visualScroll);
        int contentWidth = Math.max(24, width - 4 - (scrollbar.hasScroll() ? this.scrollbarGutter() : 0));
        listState.setBounds(x, y, width, listHeight, scrollbar);
        if (filteredPackets.isEmpty()) {
            PackUiListRenderer.drawEmptyState(context, this.textRenderer, "No packets", x, y, contentWidth);
        } else {
            PackUiViewport viewport = PackUiViewport.current(1f);
            viewport.enableScissor(context, (float)(x + 2), (float)(y + 2), (float)(x + 2 + contentWidth), (float)(y + 2 + viewHeight));
        }
        try {
            int scrollPixels = visualScroll;
            int firstVisible = scrollPixels / this.filterRowStep();
            int rowY = y + 2 - scrollPixels % this.filterRowStep();
            for (int i = firstVisible; i < filteredPackets.size(); i++) {
                if (rowY >= y + 2 + viewHeight) break;
                Class<? extends class_2596<?>> packetClass = (Class)filteredPackets.get(i);
                if (rowY + this.filterRowHeight() <= y + 2) { /* goto L744; */ }
                boolean hovered = mouseX >= x + 2 && mouseX < x + 2 + contentWidth && mouseY >= rowY && mouseY < rowY + this.filterRowHeight();
                String packetName = PackUtilPacketNamer.getFriendlyName(packetClass);
                PackUiListRenderer.drawRow(context, this.textRenderer, packetName, x + 2, rowY, contentWidth, this.filterRowHeight(), hovered, false, c2s ? PackUiListRenderer.RowTone.WARNING : PackUiListRenderer.RowTone.NORMAL);
                int iconSize = this.filterRowHeight() - 2;
                int iconX = x + 2 + contentWidth - iconSize - 1;
                int iconY = rowY + 1;
                PackUiListRenderer.drawIconButton(context, iconX, iconY, iconSize, PackUiAssets.ICON_WINDOW_CLOSE, hovered, true);
                PackUiListRenderer.drawDivider(context, x + 2, rowY + this.filterRowHeight(), contentWidth);
                this.buttons.add(new PackUtilCustomFilterOverlay.ActionButton(x + 2, rowY, contentWidth, this.filterRowHeight(), this::lambda$renderPacketSection$7 /* captured: c2s, packetClass */, true));
                L744: ;
                rowY = rowY + this.filterRowStep();
            }
        }
        finally {
            viewport.disableScissor(context);
            throw var36;
        }
        PackUiScrollbar.draw(context, scrollbar, scrollbar.contains((double)mouseX, (double)mouseY), this.activeScrollbarDrag == c2s ? 1 : 2);
        footer = filteredPackets.isEmpty() ? "" : maxScroll > 0 ? "Scroll: " + Math.min(filteredPackets.size(), Math.round((float)listState.scroll.targetOffset() / (float)this.filterRowStep()) + 1) + "/" + Math.max(1, Math.round((float)maxScroll / (float)this.filterRowStep()) + 1) : "Click a row to remove";
        if (!footer.isEmpty()) {
            PackUtilText.draw(context, this.textRenderer, footer, PackUtilText.Tone.MUTED, x + 4, y + listHeight + this.footerGap(), false);
        }
        return sectionStartY + sectionHeight + this.sectionGap();
    }

    private List<Class<? extends class_2596<?>>> filterPackets(List<Class<? extends class_2596<?>>> packets, String query) {
        if (query == null || query.isBlank()) {
            return packets;
        }
        String lowered = query.toLowerCase();
        List<Class<? extends class_2596<?>>> filtered = new ArrayList();
        var var5 = packets.iterator();
        while (var5.hasNext()) {
            Class<? extends class_2596<?>> packetClass = (Class)var5.next();
            String name = PackUtilPacketNamer.getFriendlyName(packetClass).toLowerCase();
            String fullName = packetClass.getName().toLowerCase();
            if (!name.contains(lowered) || fullName.contains(lowered)) continue;
            filtered.add(packetClass);
        }
        return filtered;
    }

    private void addPacket(boolean c2s, Class<? extends class_2596<?>> packetClass) {
        PackUtilModule module = PackUtilModule.get();
        Set<Class<? extends class_2596<?>>> packets = new LinkedHashSet(c2s ? module.getC2SPackets() : module.getS2CPackets());
        if (!packets.add(packetClass)) { /* goto L58; */ }
        if (c2s) {
            module.setC2SPackets(packets);
        } else {
            module.setS2CPackets(packets);
        }
    }

    private void removePacket(boolean c2s, Class<? extends class_2596<?>> packetClass) {
        PackUtilModule module = PackUtilModule.get();
        Set<Class<? extends class_2596<?>>> packets = new LinkedHashSet(c2s ? module.getC2SPackets() : module.getS2CPackets());
        if (!packets.remove(packetClass)) { /* goto L58; */ }
        if (c2s) {
            module.setC2SPackets(packets);
        } else {
            module.setS2CPackets(packets);
        }
    }

    private void setPacketSelected(boolean c2s, Class<? extends class_2596<?>> packetClass, boolean selected) {
        if (selected) {
            this.addPacket(c2s, packetClass);
        } else {
            this.removePacket(c2s, packetClass);
        }
    }

    private int drawAction(class_332 context, int mouseX, int mouseY, int x, int y, int width, String label, Runnable action, PackUiOverlayButton.Variant variant, boolean enabled) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, width, this.actionHeight(), class_2561.method_43470(label), PackUtilCustomFilterOverlay::lambda$drawAction$8 /* captured: action */);
        button.setVariant(enabled ? variant : PackUiOverlayButton.Variant.GHOST);
        button.active = enabled;
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, mouseX, mouseY);
        this.buttons.add(new PackUtilCustomFilterOverlay.ActionButton(x, y, width, this.actionHeight(), action, enabled));
        return y + this.actionHeight() + this.actionGap();
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.mouseClicked(mouseX, mouseY, button);
        }
        if (button == 0) {
            if (mouseX >= (double)this.panelX) {
                if (mouseX < (double)(this.panelX + this.panelWidth)) {
                    if (mouseY >= (double)this.panelY) {
                        if (mouseY < (double)(this.panelY + 16)) {
                            PackUtilWindowLayout bounds = this.getBounds();
                            if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
                                this.setVisible(false);
                                return true;
                            }
                            if (this.isOverCollapseButton(mouseX, mouseY, bounds)) {
                                this.toggleCollapsed();
                                return true;
                            }
                            this.dragging = true;
                            this.dragOffsetX = mouseX - (double)this.panelX;
                            this.dragOffsetY = mouseY - (double)this.panelY;
                            this.clearFocus();
                            return true;
                        }
                    }
                }
            }
        }
        if (this.collapsed) {
            return false;
        }
        if (button == 0) {
            if (this.tryStartScrollbarDrag(this.c2sListState, 1, mouseX, mouseY)) {
                return true;
            }
            if (this.tryStartScrollbarDrag(this.s2cListState, 2, mouseX, mouseY)) {
                return true;
            }
        }
        if (this.handleTextFieldClick(this.c2sSearchField, mouseX, mouseY, button)) {
            this.c2sListState.scroll.jumpTo(0, 0);
            return true;
        }
        if (this.handleTextFieldClick(this.s2cSearchField, mouseX, mouseY, button)) {
            this.s2cListState.scroll.jumpTo(0, 0);
            return true;
        }
        this.clearFocus();
        if (button != 0) { /* goto L339; */ }
        bounds = this.buttons.iterator();
        while (bounds.hasNext()) {
            ActionButton actionButton = (PackUtilCustomFilterOverlay.ActionButton)bounds.next();
            if (actionButton.contains(mouseX, mouseY)) {
                if (actionButton.enabled()) continue;
                return true;
                actionButton.action.run();
                return true;
            }
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    private boolean handleTextFieldClick(PackUiTextField field, double mouseX, double mouseY, int button) {
        boolean clicked = field.mouseClicked(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button);
        if (clicked) {
            this.clearFocus();
            field.setFocused(true);
        }
        return clicked;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (this.packetSelectorOverlay.isVisible() && this.packetSelectorOverlay.mouseReleased(mouseX, mouseY, button)) {
            return true;
        }
        if (this.c2sSearchField.mouseReleased(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button)) {
            return true;
        }
        if (this.s2cSearchField.mouseReleased(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button)) {
            return true;
        }
        this.activeScrollbarDrag = 0;
        if (button == 0 && this.activeScrollbarDrag != 0) {
            return true;
        }
        if (button == 0) {
            if (this.dragging || this.resizing) {
                this.saveLayout();
            }
            this.dragging = false;
            this.resizing = false;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.packetSelectorOverlay.isVisible() && this.packetSelectorOverlay.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        if (this.c2sSearchField.mouseDragged(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button, (float)deltaX, (float)deltaY)) {
            return true;
        }
        if (this.s2cSearchField.mouseDragged(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button, (float)deltaX, (float)deltaY)) {
            return true;
        }
        if (this.activeScrollbarDrag == 1) {
            this.c2sListState.scroll.setFromThumbStepped(this.c2sListState.scrollbarMetrics, mouseY, this.scrollbarGrabOffset, this.filterRowStep());
            return true;
        }
        if (this.activeScrollbarDrag == 2) {
            this.s2cListState.scroll.setFromThumbStepped(this.s2cListState.scrollbarMetrics, mouseY, this.scrollbarGrabOffset, this.filterRowStep());
            return true;
        }
        PackUtilWindowLayout nextBounds = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.resizeStartWidth + (int)Math.round(mouseX - this.resizeStartMouseX), this.resizeStartHeight + (int)Math.round(mouseY - this.resizeStartMouseY), this.visible, this.collapsed));
        if (this.resizing && button == 0) {
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.panelWidth = nextBounds.width;
            this.panelHeight = nextBounds.height;
            return true;
        }
        nextBounds = this.clampToScreen(this, new PackUtilWindowLayout((int)(mouseX - this.dragOffsetX), (int)(mouseY - this.dragOffsetY), this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        if (this.dragging && button == 0) {
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.mouseScrolled(mouseX, mouseY, amount);
        }
        if (this.c2sListState.contains(mouseX, mouseY)) {
            int maxScroll = Math.max(0, this.c2sListState.filteredPackets.size() * this.filterRowStep() - this.alignViewportHeight(Math.max(1, this.c2sListState.height - 4), this.filterRowStep()));
            this.c2sListState.scroll.nudge(amount, (float)this.filterRowStep(), maxScroll);
            return true;
        }
        if (this.s2cListState.contains(mouseX, mouseY)) {
            maxScroll = Math.max(0, this.s2cListState.filteredPackets.size() * this.filterRowStep() - this.alignViewportHeight(Math.max(1, this.s2cListState.height - 4), this.filterRowStep()));
            this.s2cListState.scroll.nudge(amount, (float)this.filterRowStep(), maxScroll);
            return true;
        }
        return false;
    }

    private PackUiScrollbar.Metrics computePacketScrollbarMetrics(int x, int y, int width, int listHeight, int contentHeight, int scrollOffset) {
        int viewHeight = Math.max(1, this.alignViewportHeight(Math.max(1, listHeight - 4), this.filterRowStep()));
        return PackUiScrollbar.compute(contentHeight, viewHeight, x + width - 5, y + 2, this.scrollbarTrackWidth(), Math.max(1, listHeight - 4), scrollOffset);
    }

    private boolean tryStartScrollbarDrag(PackUtilCustomFilterOverlay.PacketListState listState, int dragId, double mouseX, double mouseY) {
        Metrics metrics = listState.scrollbarMetrics;
        if (metrics == null || !metrics.hasScroll()) {
            return false;
        }
        if (!metrics.contains(mouseX, mouseY)) {
            return false;
        }
        this.activeScrollbarDrag = dragId;
        this.scrollbarGrabOffset = Math.max(0, (int)mouseY - metrics.thumbY());
        listState.scroll.setFromThumbStepped(metrics, mouseY, this.scrollbarGrabOffset, this.filterRowStep());
        return true;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.keyPressed(keyCode, scanCode, modifiers);
        }
        if (!this.visible) {
            return false;
        }
        if (keyCode == 256) {
            this.clearFocus();
            return false;
        }
        PackUiTextField focusedField = this.getFocusedField();
        if (focusedField == null) {
            return false;
        }
        if (keyCode == 257 || keyCode == 335) {
            return true;
        }
        focusedField.keyPressed(this.inputContext(0, 0), keyCode, scanCode, modifiers);
        return true;
    }

    public boolean charTyped(char chr, int modifiers) {
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.charTyped(chr, modifiers);
        }
        if (!this.visible) {
            return false;
        }
        PackUiTextField focusedField = this.getFocusedField();
        if (focusedField == null) {
            return false;
        }
        return focusedField.charTyped(this.inputContext(0, 0), chr, modifiers);
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        if (this.packetSelectorOverlay.isVisible()) {
            return true;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        int frameHeight = this.collapsed ? 16 : this.panelHeight;
        if (mouseX >= (double)bounds.x && mouseX <= (double)(bounds.x + bounds.width) && mouseY >= (double)bounds.y && mouseY <= (double)(bounds.y + frameHeight)) {
            return true;
        }
        return this.isMouseOverField(this.c2sSearchField, mouseX, mouseY) || this.isMouseOverField(this.s2cSearchField, mouseX, mouseY);
    }

    private PackUiTextField getFocusedField() {
        if (this.c2sSearchField.isFocused()) {
            return this.c2sSearchField;
        }
        if (this.s2cSearchField.isFocused()) {
            return this.s2cSearchField;
        }
        return null;
    }

    private int defaultPanelWidth() {
        return 220;
    }

    private int defaultPanelHeight() {
        return 308;
    }

    private int panelInset() {
        return 10;
    }

    private int topInset() {
        return 6;
    }

    private int actionHeight() {
        return 13;
    }

    private int actionGap() {
        return 2;
    }

    private int sectionGap() {
        return 6;
    }

    private int searchHeight() {
        return 16;
    }

    private int filterRowHeight() {
        return 14;
    }

    private int filterRowStep() {
        return this.filterRowHeight() + 1;
    }

    private int footerHeight() {
        return 12;
    }

    private int footerGap() {
        return 4;
    }

    private int scrollbarGutter() {
        return 8;
    }

    private int scrollbarTrackWidth() {
        return 3;
    }

    private int infoLineHeight() {
        return 10;
    }

    private int headerLabelHeight() {
        return 10;
    }

    private int sectionMinimumHeight() {
        return 86;
    }

    private int listMinimumHeight() {
        return 40;
    }

    private void clearFocus() {
        this.c2sSearchField.setFocused(false);
        this.s2cSearchField.setFocused(false);
    }

    private PackUiRenderContext renderContext(class_332 context, int mouseX, int mouseY, float delta) {
        PackUiViewport viewport = PackUiViewport.current(1f);
        return new PackUiRenderContext(context, this.textRenderer, viewport, this.theme, viewport.toUiX((double)mouseX), viewport.toUiY((double)mouseY), delta);
    }

    private PackUiRenderContext inputContext(double mouseX, double mouseY) {
        PackUiViewport viewport = PackUiViewport.current(1f);
        return new PackUiRenderContext(null, this.textRenderer, viewport, this.theme, viewport.toUiX(mouseX), viewport.toUiY(mouseY), 0f);
    }

    private boolean isMouseOverField(PackUiTextField field, double mouseX, double mouseY) {
        return mouseX >= (double)field.x() && mouseX <= (double)(field.x() + field.width()) && mouseY >= (double)field.y() && mouseY <= (double)(field.y() + field.height());
    }
}
