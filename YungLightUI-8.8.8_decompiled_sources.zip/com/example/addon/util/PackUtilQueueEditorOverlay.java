/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiLegacyLayout;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilClipboardHelper;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilText;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilQueueEditorOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private int panelX = 100;
    private int panelY = 100;
    private int PANEL_WIDTH = 248;
    private int PANEL_HEIGHT = 176;
    private boolean isDragging = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    private int scrollOffset = 0;
    private boolean collapsed = false;
    private boolean visible = false;
    private int selectedPacketId = -1;
    private boolean keepSelectedPacketVisible = false;
    private long lastObservedQueueChangeMs = 0L;
    private String lastObservedQueueSignature = "";
    private boolean pendingAutoReorder = false;
    private boolean scrollbarDragging = false;
    private int scrollbarGrabOffset = 0;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiSmoothScroll listScrollState = new PackUiSmoothScroll();
    private List<PackUtilSharedState.QueuedPacket> cachedDisplayQueue = new ArrayList();
    private final List<PackUtilQueueEditorOverlay.ClickRegion> toolbarRegions = new ArrayList();
    private final List<PackUtilQueueEditorOverlay.RowRegion> rowRegions = new ArrayList();
    private String hoveredTooltip = null;
    private int tooltipX = 0;
    private int tooltipY = 0;

    public PackUtilQueueEditorOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.PANEL_WIDTH = this.defaultPanelWidth();
        this.PANEL_HEIGHT = this.defaultPanelHeight();
    }

    public int getMinWidth() {
        return this.defaultPanelWidth();
    }

    public int getMinHeight() {
        return this.minimumPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = this.defaultPanelWidth();
        this.PANEL_HEIGHT = Math.max(this.getMinHeight(), Math.max(this.defaultPanelHeight(), clamped.height));
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
    }

    public boolean isCaptureMode() {
        return PackUtilSharedState.get().isCaptureMode();
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visible) {
            this.scrollOffset = 0;
            this.listScrollState.jumpTo(0, 0);
            PackUtilOverlayManager.get().bringToFront(this);
        }
        this.saveState();
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.saveLayout();
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        List<PackUtilSharedState.QueuedPacket> displayQueue = this.cachedDisplayQueue.isEmpty() ? this.getCurrentQueue() : this.cachedDisplayQueue;
        int panelHeight = this.collapsed ? 16 : this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.getPanelHeight(displayQueue), this.visible, this.collapsed)).height;
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + panelHeight);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + 16) && !this.isOverWindowControl(mouseX, mouseY, bounds);
    }

    public void saveState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setQueueEditorOverlayVisible(this.visible);
        shared.setQueueEditorOverlayX(this.panelX);
        shared.setQueueEditorOverlayY(this.panelY);
        this.saveLayout();
    }

    public void restoreState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.restoreLayout();
        this.visible = shared.isQueueEditorOverlayVisible();
        this.panelX = shared.getQueueEditorOverlayX();
        this.panelY = shared.getQueueEditorOverlayY();
    }

    private int getContentStartY() {
        return this.panelY + this.getContentStartOffset();
    }

    private int getContentStartOffset() {
        int toolbarRows = PackUtilLANSync.getInstance().isInSession() ? 4 : 3;
        return this.toolbarTopOffset() + toolbarRows * this.toolbarButtonHeight() + (toolbarRows - 1) * this.toolbarGap() + this.contentTopGap();
    }

    private int getListX() {
        return this.panelX + this.panelInset();
    }

    private int getListWidth() {
        return PackUiLegacyLayout.contentWidth(this.PANEL_WIDTH, this.panelInset());
    }

    private int getListContentWidth(boolean hasScrollbar) {
        return Math.max(40, PackUiLegacyLayout.reserveScrollbar(this.getListWidth(), hasScrollbar, this.listScrollbarGutter()));
    }

    private int getToolbarRowWidth() {
        return this.getListWidth();
    }

    private int fitToolbarButtonWidth(String label, int minWidth, int maxWidth) {
        return PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, label, 5, minWidth, maxWidth);
    }

    private int getListHeight(int panelHeight) {
        return Math.max(this.rowHeight() + 4, panelHeight - this.getContentStartOffset() - this.panelInset());
    }

    private int getListViewportHeight(int panelHeight) {
        return this.alignViewportHeight(Math.max(0, this.getListHeight(panelHeight) - 2), this.rowHeight());
    }

    private int getListClipTop() {
        return this.getContentStartY() - 1;
    }

    private int getListClipBottom(int panelHeight) {
        return this.getListClipTop() + this.getListViewportHeight(panelHeight);
    }

    private PackUiScrollbar.Metrics getScrollbarMetrics(int panelHeight) {
        int visibleHeight = this.getListViewportHeight(panelHeight);
        int contentHeight = this.cachedDisplayQueue.size() * this.rowHeight();
        int maxScroll = Math.max(0, contentHeight - visibleHeight);
        return PackUiScrollbar.compute(contentHeight, Math.max(1, visibleHeight), this.getListX() + this.getListWidth() - 5, this.getListClipTop(), 4, Math.max(1, this.getListHeight(panelHeight) - 2), this.listScrollState.tick(0f, maxScroll));
    }

    private int getRemoveButtonX(int rowX, int rowWidth) {
        return rowX + rowWidth - this.rowButtonSize() - this.panelInset();
    }

    private int getDelayButtonWidth() {
        return this.fixedDelayButtonWidth();
    }

    private int getDelayButtonX(int rowX, int rowWidth) {
        return this.getRemoveButtonX(rowX, rowWidth) - 4 - this.getDelayButtonWidth();
    }

    private int getRowLabelMaxWidth(int rowX, int rowWidth) {
        return Math.max(40, this.getDelayButtonX(rowX, rowWidth) - (rowX + 8) - 6);
    }

    private int getPanelHeight(List<PackUtilSharedState.QueuedPacket> displayQueue) {
        int contentHeight = Math.min(displayQueue.size(), this.maxVisibleRows()) * this.rowHeight();
        return Math.max(this.getMinHeight(), this.getContentStartOffset() + contentHeight + this.contentBottomGap());
    }

    private PackUtilSharedState.QueuedPacket getSelectedPacket(List<PackUtilSharedState.QueuedPacket> queue) {
        if (this.selectedPacketId == -1) {
            return null;
        }
        var var2 = queue.iterator();
        while (var2.hasNext()) {
            QueuedPacket packet = (PackUtilSharedState.QueuedPacket)var2.next();
            if (packet.getId() != this.selectedPacketId) continue;
            return packet;
        }
        this.selectedPacketId = -1;
        return null;
    }

    private void clearSelection() {
        this.selectedPacketId = -1;
    }

    private List<PackUtilSharedState.QueuedPacket> getCurrentQueue() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        List<PackUtilSharedState.QueuedPacket> queue = shared.getStaggeredQueue();
        if (queue.isEmpty()) {
            queue = shared.getDelayedPackets();
        }
        return queue;
    }

    private int drawAutoToolbarButton(class_332 context, int x, int y, int h, String label, boolean active, int mouseX, int mouseY, String tip, Runnable action) {
        int width = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, label, 5, 24, 96);
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, width, h, class_2561.method_43470(label), PackUtilQueueEditorOverlay::lambda$drawAutoToolbarButton$0 /* captured: action */);
        button.setVariant(active ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.GHOST);
        button.active = true;
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, mouseX, mouseY);
        this.toolbarRegions.add(new PackUtilQueueEditorOverlay.ClickRegion(x, y, width, h, action));
        this.checkBtnHover(x, y, width, h, mouseX, mouseY, tip);
        return x + width;
    }

    private int drawAutoToolbarButton(class_332 context, int x, int y, int h, String label, int mouseX, int mouseY, String tip, Runnable action) {
        return this.drawAutoToolbarButton(context, x, y, h, label, false, mouseX, mouseY, tip, action);
    }

    private int drawAutoToolbarStatusButton(class_332 context, int x, int y, int h, String label, boolean active, int mouseX, int mouseY, String tip, Runnable action) {
        int width = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, label, 5, 24, 112);
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, width, h, class_2561.method_43470(label), PackUtilQueueEditorOverlay::lambda$drawAutoToolbarStatusButton$1 /* captured: action */);
        button.setVariant(active ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.GHOST);
        button.active = true;
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, mouseX, mouseY);
        this.toolbarRegions.add(new PackUtilQueueEditorOverlay.ClickRegion(x, y, width, h, action));
        this.checkBtnHover(x, y, width, h, mouseX, mouseY, tip);
        return x + width;
    }

    private void drawFixedToolbarButton(class_332 context, int x, int y, int w, int h, String label, boolean active, int mouseX, int mouseY, String tip, Runnable action) {
        this.drawFixedToolbarButton(context, x, y, w, h, label, PackUiOverlayButton.Variant.SECONDARY, active, mouseX, mouseY, tip, action);
    }

    private void drawFixedToolbarButton(class_332 context, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean active, int mouseX, int mouseY, String tip, Runnable action) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), PackUtilQueueEditorOverlay::lambda$drawFixedToolbarButton$2 /* captured: action */);
        button.setVariant(variant);
        button.active = active;
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, mouseX, mouseY);
        this.toolbarRegions.add(new PackUtilQueueEditorOverlay.ClickRegion(x, y, w, h, action));
        this.checkBtnHover(x, y, w, h, mouseX, mouseY, tip);
    }

    private void drawFixedToolbarButton(class_332 context, int x, int y, int w, int h, String label, int mouseX, int mouseY, String tip, Runnable action) {
        this.drawFixedToolbarButton(context, x, y, w, h, label, false, mouseX, mouseY, tip, action);
    }

    private void drawFixedToolbarStateButton(class_332 context, int x, int y, int w, int h, String label, boolean enabled, int mouseX, int mouseY, String tip, Runnable action) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), PackUtilQueueEditorOverlay::lambda$drawFixedToolbarStateButton$3 /* captured: action */);
        button.setVariant(enabled ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER);
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, mouseX, mouseY);
        this.toolbarRegions.add(new PackUtilQueueEditorOverlay.ClickRegion(x, y, w, h, action));
        this.checkBtnHover(x, y, w, h, mouseX, mouseY, tip);
    }

    private boolean isQueueSortedByDelay(List<PackUtilSharedState.QueuedPacket> queue) {
        for (int i = 1; i < queue.size(); i++) {
            QueuedPacket previous = (PackUtilSharedState.QueuedPacket)queue.get(i - 1);
            QueuedPacket current = (PackUtilSharedState.QueuedPacket)queue.get(i);
            if (!previous.getDelay() > current.getDelay()) continue;
            return false;
            if (!previous.getDelay() == current.getDelay() && previous.getId() > current.getId()) continue;
            return false;
        }
        return true;
    }

    private String buildQueueSignature(List<PackUtilSharedState.QueuedPacket> queue) {
        if (queue.isEmpty()) {
            return "";
        }
        StringBuilder signature = new StringBuilder(queue.size() * 16);
        var var3 = queue.iterator();
        while (var3.hasNext()) {
            QueuedPacket packet = (PackUtilSharedState.QueuedPacket)var3.next();
            signature.append(packet.getId()).append(58).append(packet.getDelay()).append(59);
        }
        return signature.toString();
    }

    private void observeQueueChanges(List<PackUtilSharedState.QueuedPacket> queue) {
        String signature = this.buildQueueSignature(queue);
        if (!signature.equals(this.lastObservedQueueSignature)) {
            this.lastObservedQueueSignature = signature;
            this.lastObservedQueueChangeMs = System.currentTimeMillis();
            this.pendingAutoReorder = true;
        }
    }

    private void maybeAutoReorderDelayedQueue(PackUtilSharedState shared) {
        List<PackUtilSharedState.QueuedPacket> delayedQueue = shared.getDelayedPackets();
        this.observeQueueChanges(delayedQueue);
        if (delayedQueue.size() < 2) {
            return;
        }
        if (!this.pendingAutoReorder) {
            return;
        }
        if (System.currentTimeMillis() - this.lastObservedQueueChangeMs < 800L) {
            return;
        }
        if (this.isQueueSortedByDelay(delayedQueue)) {
            this.pendingAutoReorder = false;
            return;
        }
        shared.sortDelayedPacketsByDelayPreservingIds();
        this.lastObservedQueueSignature = this.buildQueueSignature(shared.getDelayedPackets());
        this.pendingAutoReorder = false;
        this.keepSelectedPacketVisible = true;
    }

    private void ensureSelectedPacketVisible(List<PackUtilSharedState.QueuedPacket> queue, PackUtilSharedState.QueuedPacket selectedPacket, int panelHeight) {
        if (selectedPacket == null || queue.isEmpty()) {
            return;
        }
        int selectedIndex = -1;
        int i = 0;
        while (i < queue.size()) {
            if (((PackUtilSharedState.QueuedPacket)queue.get(i)).getId() == selectedPacket.getId()) {
                selectedIndex = i;
            } else {
                i++;
            }
        }
        if (selectedIndex < 0) {
            return;
        }
        visibleHeight = this.getListViewportHeight(panelHeight);
        int maxScroll = Math.max(0, queue.size() * this.rowHeight() - visibleHeight);
        int rowTop = selectedIndex * this.rowHeight();
        int rowBottom = rowTop + this.rowHeight();
        if (rowTop < this.scrollOffset) {
            this.scrollOffset = rowTop;
        } else {
            if (rowBottom > this.scrollOffset + visibleHeight) {
                this.scrollOffset = rowBottom - visibleHeight;
            }
        }
        this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset, this.rowHeight(), maxScroll);
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        List<PackUtilSharedState.QueuedPacket> staggeredQueue = shared.getStaggeredQueue();
        if (staggeredQueue.isEmpty()) {
            this.maybeAutoReorderDelayedQueue(shared);
            this.cachedDisplayQueue = shared.getDelayedPackets();
        } else {
            this.cachedDisplayQueue = new ArrayList(staggeredQueue);
        }
        QueuedPacket selectedPacket = this.getSelectedPacket(this.cachedDisplayQueue);
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.getPanelHeight(this.cachedDisplayQueue), this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = clamped.width;
        int panelHeight = clamped.height;
        this.PANEL_HEIGHT = panelHeight;
        this.ensureSelectedPacketVisible(this.cachedDisplayQueue, selectedPacket, panelHeight);
        if (!this.collapsed && this.keepSelectedPacketVisible) {
            this.keepSelectedPacketVisible = false;
        }
        this.toolbarRegions.clear();
        this.rowRegions.clear();
        this.hoveredTooltip = null;
        String title = "Queue (" + this.cachedDisplayQueue.size() + ")";
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, panelHeight, this.visible, this.collapsed);
        this.renderWindowFrame(context, mouseX, mouseY, bounds, title, this.collapsed, this.isDragging);
        boolean clipBody = this.beginWindowBodyClip(context, bounds, this.collapsed);
        if (!clipBody) {
            this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.isDragging);
            return;
        }
        try {
            int gap = this.toolbarGap();
            int row1Y = this.panelY + this.toolbarTopOffset();
            int row2Y = row1Y + this.toolbarButtonHeight() + gap;
            int row3Y = row2Y + this.toolbarButtonHeight() + gap;
            int row4Y = row3Y + this.toolbarButtonHeight() + gap;
            int leftX = this.panelX + this.panelInset();
            int rowWidth = this.getToolbarRowWidth();
            int rowRight = leftX + rowWidth;
            int bx = leftX;
            bx = this.drawAutoToolbarButton(context, bx, row1Y, this.toolbarButtonHeight(), "Copy", mouseX, mouseY, "Copy queue to clipboard (serialized)", this::lambda$render$4) + gap;
            bx = this.drawAutoToolbarButton(context, bx, row1Y, this.toolbarButtonHeight(), "Paste", mouseX, mouseY, "Replace queue from clipboard", this::lambda$render$5) + gap;
            bx = this.drawAutoToolbarButton(context, bx, row1Y, this.toolbarButtonHeight(), "Dupe", mouseX, mouseY, "Duplicate all packets in the queue", this::lambda$render$6) + gap;
            bx = this.drawAutoToolbarButton(context, bx, row1Y, this.toolbarButtonHeight(), "Ins", mouseX, mouseY, "Insert clipboard packets at the end of the queue", this::lambda$render$7) + gap;
            int replayWidth = Math.max(this.fitToolbarButtonWidth("Replay", 48, 84), rowRight - bx);
            this.drawFixedToolbarButton(context, bx, row1Y, replayWidth, this.toolbarButtonHeight(), "Replay", PackUiOverlayButton.Variant.GHOST, true, mouseX, mouseY, "Restore the last flushed queue back into the editor", this::lambda$render$8);
            boolean flushOnDelay = PackUtilModule.get().shouldFlushQueueOnDelayDisable();
            int clearWidth = this.fitToolbarButtonWidth("Clear", 42, 58);
            int flushWidth = Math.max(this.fitToolbarButtonWidth("FLUSH ON DELAY", 120, 164), rowWidth - clearWidth - gap);
            this.drawFixedToolbarStateButton(context, leftX, row2Y, flushWidth, this.toolbarButtonHeight(), "FLUSH ON DELAY", flushOnDelay, mouseX, mouseY, flushOnDelay ? "When delay turns off, queued packets auto-flush" : "When delay turns off, keep the queued packets until you flush or clear them", PackUtilQueueEditorOverlay::lambda$render$9);
            this.drawFixedToolbarButton(context, leftX + flushWidth + gap, row2Y, clearWidth, this.toolbarButtonHeight(), "Clear", PackUiOverlayButton.Variant.DANGER, true, mouseX, mouseY, "Remove all packets from the queue", this::lambda$render$10);
            boolean captureModeOn = PackUtilSharedState.get().isCaptureMode();
            String delayModeLabel = PackUtilSharedState.get().getDelayMode() == PackUtilSharedState.DelayMode.TICKS ? "Ticks" : "Ms";
            int modeWidth = this.fitToolbarButtonWidth(delayModeLabel, 34, 44);
            int captureWidth = this.fitToolbarButtonWidth("Capture", 56, 72);
            int plus1Width = this.fitToolbarButtonWidth("+1", 22, 28);
            int plus10Width = this.fitToolbarButtonWidth("+10", 26, 34);
            int plus20Width = this.fitToolbarButtonWidth("+20", 26, 34);
            int sendWidth = Math.max(this.fitToolbarButtonWidth("Send Q", 54, 82), rowWidth - modeWidth - captureWidth - plus1Width - plus10Width - plus20Width - gap * 5);
            this.drawFixedToolbarButton(context, leftX, row3Y, modeWidth, this.toolbarButtonHeight(), delayModeLabel, PackUiOverlayButton.Variant.GHOST, true, mouseX, mouseY, "Toggle delay unit: Ticks or milliseconds", PackUtilQueueEditorOverlay::lambda$render$11);
            this.drawFixedToolbarButton(context, leftX + modeWidth + gap, row3Y, captureWidth, this.toolbarButtonHeight(), "Capture", captureModeOn ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER, true, mouseX, mouseY, "Record real timing between captured packets", PackUtilQueueEditorOverlay::lambda$render$12);
            int adjustX = leftX + modeWidth + gap + captureWidth + gap;
            this.drawFixedToolbarButton(context, adjustX, row3Y, plus1Width, this.toolbarButtonHeight(), "+1", PackUiOverlayButton.Variant.GHOST, true, mouseX, mouseY, "Add +1 to the selected packet, or apply a +1 incremental pattern to the whole queue", this::lambda$render$13);
            this.drawFixedToolbarButton(context, adjustX + plus1Width + gap, row3Y, plus10Width, this.toolbarButtonHeight(), "+10", PackUiOverlayButton.Variant.GHOST, true, mouseX, mouseY, "Add +10 to the selected packet, or apply a +10 incremental pattern to the whole queue", this::lambda$render$14);
            this.drawFixedToolbarButton(context, adjustX + plus1Width + gap + plus10Width + gap, row3Y, plus20Width, this.toolbarButtonHeight(), "+20", PackUiOverlayButton.Variant.GHOST, true, mouseX, mouseY, "Add +20 to the selected packet, or apply a +20 incremental pattern to the whole queue", this::lambda$render$15);
            this.drawFixedToolbarButton(context, rowRight - sendWidth, row3Y, sendWidth, this.toolbarButtonHeight(), "Send Q", PackUiOverlayButton.Variant.SUCCESS, true, mouseX, mouseY, "Send all queued packets to the server", PackUtilQueueEditorOverlay::lambda$render$16);
            boolean inLanSession = PackUtilLANSync.getInstance().isInSession();
            if (inLanSession) {
                int syncWidth = this.fitToolbarButtonWidth("Sync", 46, 58);
                int syncExecWidth = Math.max(this.fitToolbarButtonWidth("Sync Exec", 92, 118), rowWidth - syncWidth - gap);
                this.drawFixedToolbarButton(context, leftX, row4Y, syncWidth, this.toolbarButtonHeight(), "Sync", PackUiOverlayButton.Variant.GHOST, true, mouseX, mouseY, "Broadcast this queue to all LAN peers", this::handleSyncButton);
                this.drawFixedToolbarButton(context, leftX + syncWidth + gap, row4Y, syncExecWidth, this.toolbarButtonHeight(), "Sync Exec", PackUiOverlayButton.Variant.SUCCESS, true, mouseX, mouseY, "Tell LAN peers to execute their queues together", PackUtilQueueEditorOverlay::lambda$render$17);
            }
            if (this.cachedDisplayQueue.isEmpty()) {
                PackUtilText.draw(context, this.textRenderer, "Queue empty", PackUtilText.Tone.MUTED, this.panelX + 10, this.getContentStartY(), false);
            } else {
                visibleHeight = this.getListViewportHeight(panelHeight);
                totalContentHeight = this.cachedDisplayQueue.size() * this.rowHeight();
                int maxScroll = Math.max(0, totalContentHeight - visibleHeight);
                this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset, this.rowHeight(), maxScroll);
                this.listScrollState.setTarget(this.scrollOffset, maxScroll);
                int drawScroll = this.listScrollState.tick(delta, maxScroll);
                int contentStartY = this.getContentStartY();
                int listX = this.getListX();
                int listY = contentStartY - 2;
                int listWidth = this.getListWidth();
                int listHeight = this.getListHeight(panelHeight);
                int clipTop = this.getListClipTop();
                int clipBottom = this.getListClipBottom(panelHeight);
                PackUiListRenderer.drawFrame(context, listX, listY, listWidth, listHeight, selectedPacket != null);
                Metrics scrollbarMetrics = this.getScrollbarMetrics(panelHeight);
                int listContentWidth = this.getListContentWidth(scrollbarMetrics.hasScroll());
                PackUtilUiScale.enableOverlayScissor(context, listX + 1, clipTop, listX + listWidth - 1, clipBottom);
                int baseY = contentStartY - drawScroll;
                int groupColorIndex = 0;
                int lastDelay = -2147483648;
                for (int i = 0; i < this.cachedDisplayQueue.size(); i++) {
                    QueuedPacket packet = (PackUtilSharedState.QueuedPacket)this.cachedDisplayQueue.get(i);
                    int itemY = baseY + i * this.rowHeight();
                    int rowY = itemY - 1;
                    if (rowY + this.rowHeight() <= clipTop) { /* goto L2137; */ }
                    if (rowY >= clipBottom) {
                    } else {
                        boolean grouped = false;
                        if (i > 0) {
                            if (((PackUtilSharedState.QueuedPacket)this.cachedDisplayQueue.get(i - 1)).getDelay() == packet.getDelay()) {
                                grouped = true;
                            }
                        }
                        if (i < this.cachedDisplayQueue.size() - 1) {
                            if (((PackUtilSharedState.QueuedPacket)this.cachedDisplayQueue.get(i + 1)).getDelay() == packet.getDelay()) {
                                grouped = true;
                            }
                        }
                        int textColor = PackUtilColors.textPrimary();
                        if (!grouped) { /* goto L1637; */ }
                        if (packet.getDelay() != lastDelay) {
                            groupColorIndex++;
                        }
                        textColor = groupColorIndex % 2 == 0 ? -12268289 : -21948;
                        lastDelay = packet.getDelay();
                        int rowX = listX + 1;
                        int rowW = Math.max(36, listContentWidth - 2);
                        boolean selected = selectedPacket != null && selectedPacket.getId() == packet.getId();
                        boolean hovered = mouseX >= rowX && mouseX < rowX + rowW && mouseY >= rowY && mouseY < rowY + this.rowHeight();
                        PackUiListRenderer.drawRow(context, this.textRenderer, "", rowX, rowY, rowW, this.rowHeight(), hovered, selected, grouped ? PackUiListRenderer.RowTone.WARNING : PackUiListRenderer.RowTone.NORMAL);
                        String label = "#" + packet.getId() + " " + PackUtilPacketNamer.getFriendlyName(packet.packet);
                        String delayText = String.valueOf(packet.getDelay());
                        int labelMaxWidth = this.getRowLabelMaxWidth(rowX, rowW);
                        String trimmed = PackUiText.width(this.textRenderer, label, this.theme.fontFor(PackUiTone.BODY), textColor) > labelMaxWidth ? PackUiText.trimToWidth(this.textRenderer, label, Math.max(1, labelMaxWidth), this.theme.fontFor(PackUiTone.BODY), textColor) : label;
                        int rowTextY = PackUiSizing.alignTextY(rowY, this.rowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
                        PackUiText.draw(context, this.textRenderer, trimmed, this.theme.fontFor(PackUiTone.BODY), selected ? PackUtilColors.rowSelectedText() : textColor, rowX + 7, rowTextY, false);
                        int delayBtnWidth = this.getDelayButtonWidth();
                        int delayBtnX = this.getDelayButtonX(rowX, rowW);
                        int buttonY = rowY + Math.max(0, (this.rowHeight() - this.rowButtonSize()) / 2);
                        PackUiOverlayButton delayButton = PackUiOverlayButton.create(delayBtnX, buttonY, delayBtnWidth, this.rowButtonSize(), class_2561.method_43470(delayText), PackUtilQueueEditorOverlay::lambda$render$18);
                        delayButton.setVariant(PackUiOverlayButton.Variant.PRIMARY);
                        PackUiOverlayButton.renderStyled(context, this.textRenderer, delayButton, mouseX, mouseY);
                        int removeBtnX = this.getRemoveButtonX(rowX, rowW);
                        boolean removeHovered = mouseX >= removeBtnX && mouseX < removeBtnX + this.rowButtonSize() && mouseY >= buttonY && mouseY < buttonY + this.rowButtonSize();
                        PackUiListRenderer.drawIconButton(context, removeBtnX, buttonY, this.rowButtonSize(), PackUiAssets.ICON_WINDOW_CLOSE, removeHovered, true);
                        PackUiListRenderer.drawDivider(context, rowX, rowY + this.rowHeight(), rowW);
                        this.rowRegions.add(new PackUtilQueueEditorOverlay.RowRegion(packet, rowX, rowY, rowW, this.rowHeight(), delayBtnX, delayBtnWidth, removeBtnX, this.rowButtonSize()));
                    }
                }
                context.method_44380();
                PackUiScrollbar.draw(context, scrollbarMetrics, scrollbarMetrics.contains((double)mouseX, (double)mouseY), this.scrollbarDragging);
            }
        }
        finally {
            this.endWindowBodyClip(context, clipBody);
            this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.isDragging);
            throw var73;
        }
        PackUiText.interOverlayFlush(context);
        if (!this.collapsed && this.hoveredTooltip != null) {
            this.drawTooltip(context, this.hoveredTooltip, this.tooltipX, this.tooltipY);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        List<PackUtilSharedState.QueuedPacket> displayQueue = this.cachedDisplayQueue.isEmpty() ? this.getCurrentQueue() : this.cachedDisplayQueue;
        int panelHeight = this.collapsed ? 16 : this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.getPanelHeight(displayQueue), this.visible, this.collapsed)).height;
        if (button == 0) {
            if (mouseX >= (double)this.panelX) {
                if (mouseX <= (double)(this.panelX + this.PANEL_WIDTH)) {
                    if (mouseY >= (double)this.panelY) {
                        if (mouseY <= (double)(this.panelY + 16)) {
                            PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, panelHeight, this.visible, this.collapsed);
                            if (this.isOverCollapseButton(mouseX, mouseY, bounds)) {
                                this.toggleCollapsed();
                                return true;
                            }
                            if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
                                this.setVisible(false);
                                return true;
                            }
                            this.isDragging = true;
                            this.dragOffsetX = mouseX - (double)this.panelX;
                            this.dragOffsetY = mouseY - (double)this.panelY;
                            return true;
                        }
                    }
                }
            }
        }
        if (this.collapsed) {
            return false;
        }
        if (button != 0) { /* goto L314; */ }
        scrollbarMetrics = this.toolbarRegions.iterator();
        while (scrollbarMetrics.hasNext()) {
            ClickRegion region = (PackUtilQueueEditorOverlay.ClickRegion)scrollbarMetrics.next();
            if (region.contains(mouseX, mouseY)) {
                region.action.run();
                return true;
            }
        }
        scrollbarMetrics = this.getScrollbarMetrics(panelHeight);
        if (button != 0) { /* goto L430; */ }
        if (!scrollbarMetrics.hasScroll()) { /* goto L430; */ }
        if (!scrollbarMetrics.contains(mouseX, mouseY)) { /* goto L430; */ }
        this.scrollbarDragging = true;
        this.scrollbarGrabOffset = scrollbarMetrics.overThumb(mouseX, mouseY) ? (int)Math.round(mouseY) - scrollbarMetrics.thumbY() : scrollbarMetrics.thumbHeight() / 2;
        this.scrollOffset = this.quantizeScrollOffset(PackUiScrollbar.scrollFromThumb(scrollbarMetrics, mouseY, this.scrollbarGrabOffset), this.rowHeight(), scrollbarMetrics.maxScroll());
        this.listScrollState.jumpTo(this.scrollOffset, scrollbarMetrics.maxScroll());
        return true;
        region = this.rowRegions.iterator();
        while (region.hasNext()) {
            RowRegion region = (PackUtilQueueEditorOverlay.RowRegion)region.next();
            while (!region.contains(mouseX, mouseY)) {
            }
            if (region.overRemove(mouseX, mouseY)) {
                if (button == 0) {
                    shared.removeQueuedPacket(region.packet);
                    if (this.selectedPacketId != region.packet.getId()) continue;
                    this.clearSelection();
                    return true;
                }
            }
            if (region.overDelay(mouseX, mouseY)) {
                if (button == 0) {
                    shared.updatePacketDelay(region.packet, region.packet.getDelay() + 1);
                    return true;
                }
                if (button == 1) {
                    shared.updatePacketDelay(region.packet, Math.max(0, region.packet.getDelay() - 1));
                    return true;
                }
            }
            if (button != 0) { /* goto @629; */ }
            this.selectedPacketId = this.selectedPacketId == region.packet.getId() ? -1 : region.packet.getId();
            return true;
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        PackUtilWindowLayout nextBounds = this.clampToScreen(this, new PackUtilWindowLayout((int)(mouseX - this.dragOffsetX), (int)(mouseY - this.dragOffsetY), this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed));
        if (this.isDragging && button == 0) {
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.saveState();
            return true;
        }
        if (!this.scrollbarDragging) { /* goto L225; */ }
        if (button != 0) { /* goto L225; */ }
        displayQueue = this.cachedDisplayQueue.isEmpty() ? this.getCurrentQueue() : this.cachedDisplayQueue;
        int panelHeight = this.collapsed ? 16 : this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.getPanelHeight(displayQueue), this.visible, this.collapsed)).height;
        Metrics scrollbarMetrics = this.getScrollbarMetrics(panelHeight);
        this.scrollOffset = this.quantizeScrollOffset(PackUiScrollbar.scrollFromThumb(scrollbarMetrics, mouseY, this.scrollbarGrabOffset), this.rowHeight(), scrollbarMetrics.maxScroll());
        this.listScrollState.jumpTo(this.scrollOffset, scrollbarMetrics.maxScroll());
        return true;
        return false;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.isDragging = false;
        if (button == 0 && this.isDragging) {
            this.saveState();
            return true;
        }
        this.scrollbarDragging = false;
        if (button == 0 && this.scrollbarDragging) {
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible || this.collapsed || !this.isMouseOver(mouseX, mouseY)) {
            return false;
        }
        List<PackUtilSharedState.QueuedPacket> displayQueue = this.cachedDisplayQueue.isEmpty() ? this.getCurrentQueue() : this.cachedDisplayQueue;
        int panelHeight = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.getPanelHeight(displayQueue), this.visible, this.collapsed)).height;
        int visibleHeight = this.getListViewportHeight(panelHeight);
        int maxScroll = Math.max(0, displayQueue.size() * this.rowHeight() - visibleHeight);
        if (maxScroll <= 0) {
            return false;
        }
        this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset - (int)(Math.signum(amount) * (double)this.rowHeight()), this.rowHeight(), maxScroll);
        return true;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        return false;
    }

    private void handleSyncButton() {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        if (!sync.isInSession()) {
            PackUtilClientMessaging.sendPrefixed("§cNot in LAN session");
            return;
        }
        List<PackUtilSharedState.QueuedPacket> queue = this.getCurrentQueue();
        if (queue.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("§cQueue is empty");
            return;
        }
        String queueData = PackUtilClipboardHelper.serializeQueueToBase64(queue);
        if (queueData == null) {
            PackUtilClientMessaging.sendPrefixed("§cFailed to serialize queue");
            return;
        }
        sync.broadcastQueueSync(queueData);
        PackUtilClientMessaging.sendPrefixed("§aQueue sent to " + sync.getConnectedClientCount() + " clients");
    }

    private void checkBtnHover(int x, int y, int w, int h, int mx, int my, String tip) {
        this.hoveredTooltip = tip;
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            this.tooltipX = mx + 8;
            this.tooltipY = my + 12;
        }
    }

    private void drawTooltip(class_332 ctx, String text, int x, int y) {
        List<String> lines = this.wrapTooltipText(text, 200);
        int lineH = this.theme.lineHeight(PackUiTone.MUTED, 2);
        int maxW = 0;
        int tw = lines.iterator();
        while (tw.hasNext()) {
            String line = (String)tw.next();
            maxW = Math.max(maxW, PackUiText.width(this.textRenderer, line, this.theme.fontFor(PackUiTone.MUTED), this.theme.color(PackUiTone.MUTED)));
        }
        tw = maxW + 6;
        th = lines.size() * lineH + 6;
        int screenW = PackUtilUiScale.getVirtualScreenWidth();
        int screenH = PackUtilUiScale.getVirtualScreenHeight();
        if (x + tw > screenW - 4) {
            x = screenW - tw - 4;
        }
        if (y + th > screenH - 4) {
            y = screenH - th - 4;
        }
        ctx.method_25294(x - 2, y - 2, x + tw, y + th, this.theme.windowFill());
        ctx.method_25294(x - 2, y - 2, x + tw, y - 1, this.theme.borderColor());
        ctx.method_25294(x - 2, y + th - 1, x + tw, y + th, this.theme.borderColor());
        ctx.method_25294(x - 2, y - 2, x - 1, y + th, this.theme.borderColor());
        ctx.method_25294(x + tw - 1, y - 2, x + tw, y + th, this.theme.borderColor());
        ctx.method_25294(x - 2, y - 2, x + tw, y - 1, this.theme.headerAccent());
        for (int i = 0; i < lines.size(); i++) {
            PackUiText.draw(ctx, this.textRenderer, (String)lines.get(i), this.theme.fontFor(PackUiTone.MUTED), this.theme.color(PackUiTone.BODY), x + 2, y + 2 + i * lineH, false);
        }
    }

    private List<String> wrapTooltipText(String text, int maxWidth) {
        List<String> lines = new ArrayList();
        String[] words = text.split(" ");
        StringBuilder current = new StringBuilder();
        var var6 = words;
        var var7 = var6.length;
        for (int var8 = 0; var8 < var7; var8++) {
            String word = var6[var8];
            String next = current.length() == 0 ? word : String.valueOf(current) + " " + word;
            if (PackUiText.width(this.textRenderer, next, this.theme.fontFor(PackUiTone.MUTED), this.theme.color(PackUiTone.MUTED)) > maxWidth) {
                if (current.length() > 0) {
                    lines.add(current.toString());
                    current = new StringBuilder(word);
                }
            } else {
                if (!current.length() > 0) continue;
                current.append(" ");
                current.append(word);
            }
        }
        if (current.length() > 0) {
            lines.add(current.toString());
        }
        return lines;
    }

    private void handleIncrementalDelay(int increment) {
        List<PackUtilSharedState.QueuedPacket> queue = this.getCurrentQueue();
        if (queue.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("§cQueue is empty");
            return;
        }
        if (this.selectedPacketId == -1) { /* goto L138; */ }
        int i = queue.iterator();
        while (i.hasNext()) {
            QueuedPacket packet = (PackUtilSharedState.QueuedPacket)i.next();
            if (packet.getId() != this.selectedPacketId) { /* goto @124; */ }
            packet.setDelay(packet.getDelay() + increment);
            String modeStr = PackUtilSharedState.get().getQueueDisplayDelayMode() == PackUtilSharedState.DelayMode.TICKS ? "ticks" : "ms";
            PackUtilClientMessaging.sendPrefixed("§aPacket #" + packet.getId() + " delay: " + packet.getDelay() + " " + modeStr);
            return;
        }
        this.clearSelection();
        PackUtilClientMessaging.sendPrefixed("§cSelected packet not found");
        return;
        L138: ;
        for (i = 0; i < queue.size(); i++) {
            ((PackUtilSharedState.QueuedPacket)queue.get(i)).setDelay(i * increment);
        }
        PackUtilClientMessaging.sendPrefixed("§aApplied +" + increment + " incremental delays");
    }

    private int defaultPanelWidth() {
        return 248;
    }

    private int defaultPanelHeight() {
        return 176;
    }

    private int minimumPanelHeight() {
        return 168;
    }

    private int rowHeight() {
        return 14;
    }

    private int rowButtonSize() {
        return 12;
    }

    private int toolbarButtonHeight() {
        return 13;
    }

    private int maxVisibleRows() {
        return 6;
    }

    private int fixedDelayButtonWidth() {
        return 40;
    }

    private int listScrollbarGutter() {
        return 12;
    }

    private int panelInset() {
        return 4;
    }

    private int toolbarGap() {
        return 2;
    }

    private int toolbarTopOffset() {
        return 20;
    }

    private int contentTopGap() {
        return 6;
    }

    private int contentBottomGap() {
        return 6;
    }
}
