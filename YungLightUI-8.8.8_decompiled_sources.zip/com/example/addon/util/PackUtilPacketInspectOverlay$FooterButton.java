/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketInspectOverlay;

private static final record PackUtilPacketInspectOverlay.FooterButton {
    private final PackUtilPacketInspectOverlay.FooterAction action;
    private final int x;
    private final int y;
    private final int width;

    private PackUtilPacketInspectOverlay.FooterButton(PackUtilPacketInspectOverlay.FooterAction action, int x, int y, int width) {
        this.action = action;
        this.x = x;
        this.y = y;
        this.width = width;
    }

    private String label() {
        return this.action.label;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public PackUtilPacketInspectOverlay.FooterAction action() {
        return this.action;
    }

    public int x() {
        return this.x;
    }

    public int y() {
        return this.y;
    }

    public int width() {
        return this.width;
    }
}
