/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroListOverlay;

private static final class PackUtilMacroListOverlay.DisplayItem {
    private PackUtilMacroListOverlay.ItemType type;
    private String label;
    private int color;
    private PackUtilMacro macro;
    private String remoteSource;
    private boolean remoteMeteor;

    private PackUtilMacroListOverlay.DisplayItem() {
    }

    private static PackUtilMacroListOverlay.DisplayItem section(String label, int color) {
        DisplayItem item = new PackUtilMacroListOverlay.DisplayItem();
        item.type = PackUtilMacroListOverlay.ItemType.SECTION_HEADER;
        item.label = label;
        item.color = color;
        return item;
    }

    private static PackUtilMacroListOverlay.DisplayItem localMacro(PackUtilMacro macro) {
        DisplayItem item = new PackUtilMacroListOverlay.DisplayItem();
        item.type = PackUtilMacroListOverlay.ItemType.LOCAL_MACRO;
        item.macro = macro;
        return item;
    }

    private static PackUtilMacroListOverlay.DisplayItem remoteMacro(String label, String source, boolean remoteMeteor) {
        DisplayItem item = new PackUtilMacroListOverlay.DisplayItem();
        item.type = PackUtilMacroListOverlay.ItemType.REMOTE_MACRO;
        item.label = label;
        item.remoteSource = source;
        item.remoteMeteor = remoteMeteor;
        return item;
    }

    private static PackUtilMacroListOverlay.DisplayItem meteorMacro(PackUtilMacro macro) {
        DisplayItem item = new PackUtilMacroListOverlay.DisplayItem();
        item.type = PackUtilMacroListOverlay.ItemType.METEOR_MACRO;
        item.macro = macro;
        return item;
    }
}
