/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.macro.ClickAction;
import com.example.addon.util.macro.CloseGuiAction;
import com.example.addon.util.macro.CraftAction;
import com.example.addon.util.macro.DelayAction;
import com.example.addon.util.macro.DelayPacketsAction;
import com.example.addon.util.macro.DesyncAction;
import com.example.addon.util.macro.DisconnectAction;
import com.example.addon.util.macro.DropAction;
import com.example.addon.util.macro.GoToAction;
import com.example.addon.util.macro.InventoryAction;
import com.example.addon.util.macro.InventoryAuditAction;
import com.example.addon.util.macro.ItemAction;
import com.example.addon.util.macro.JumpAction;
import com.example.addon.util.macro.LookAtBlockAction;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.MacroExecutor;
import com.example.addon.util.macro.MineAction;
import com.example.addon.util.macro.MoveAction;
import com.example.addon.util.macro.NbtBookAction;
import com.example.addon.util.macro.OpenContainerAction;
import com.example.addon.util.macro.PacketAction;
import com.example.addon.util.macro.PayAction;
import com.example.addon.util.macro.RepeatAction;
import com.example.addon.util.macro.RestoreGuiAction;
import com.example.addon.util.macro.RevisionSyncAction;
import com.example.addon.util.macro.RotateAction;
import com.example.addon.util.macro.SaveGuiAction;
import com.example.addon.util.macro.SelectSlotAction;
import com.example.addon.util.macro.SendChatAction;
import com.example.addon.util.macro.SendPacketAction;
import com.example.addon.util.macro.SendToggleAction;
import com.example.addon.util.macro.ServerTickSyncAction;
import com.example.addon.util.macro.SneakAction;
import com.example.addon.util.macro.SprintAction;
import com.example.addon.util.macro.StopMacroAction;
import com.example.addon.util.macro.StoreItemAction;
import com.example.addon.util.macro.SwapSlotsAction;
import com.example.addon.util.macro.TickSyncAction;
import com.example.addon.util.macro.ToggleModuleAction;
import com.example.addon.util.macro.UseItemAction;
import com.example.addon.util.macro.WaitForBlockAction;
import com.example.addon.util.macro.WaitForChatAction;
import com.example.addon.util.macro.WaitForCooldownAction;
import com.example.addon.util.macro.WaitForEntityAction;
import com.example.addon.util.macro.WaitForGuiAction;
import com.example.addon.util.macro.WaitForHealthAction;
import com.example.addon.util.macro.WaitForLanStepAction;
import com.example.addon.util.macro.WaitForPacketAction;
import com.example.addon.util.macro.WaitForSlotChangeAction;
import com.example.addon.util.macro.WaitForSoundAction;
import com.example.addon.util.macro.WaitPosAction;
import com.example.addon.util.macro.XCarryAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class PackUtilMacro {
    public String name = "New Macro";
    public String description = "";
    public boolean loop = false;
    public int loopCount = -1;
    public int keyCode = -1;
    public List<MacroAction> actions = new ArrayList();

    public PackUtilMacro() {
    }

    public PackUtilMacro(String name) {
        this.name = name;
    }

    public PackUtilMacro deepCopy() {
        return new PackUtilMacro().fromTag(this.toTag());
    }

    public PackUtilMacro deepCopy(String newName) {
        PackUtilMacro copy = this.deepCopy();
        if (newName != null) {
            if (!newName.isBlank()) {
                copy.name = newName;
            }
        }
        return copy;
    }

    public void execute() {
        this.execute(true);
    }

    public void execute(boolean regenerate) {
        if (this.actions.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("§cMacro has no actions!");
            return;
        }
        if (regenerate) {
            this.regenerateAllPackets();
        }
        MacroExecutor.execute(this);
    }

    public void regenerateAllPackets() {
        var var1 = this.actions.iterator();
        while (var1.hasNext()) {
            MacroAction action = (MacroAction)var1.next();
            if (!action instanceof SendPacketAction) continue;
            ((SendPacketAction)action).regeneratePackets();
        }
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("name", this.name);
        tag.method_10582("description", this.description);
        tag.method_10556("loop", this.loop);
        tag.method_10569("loopCount", this.loopCount);
        tag.method_10569("keyCode", this.keyCode);
        class_2499 actionsList = new class_2499();
        var var3 = this.actions.iterator();
        while (var3.hasNext()) {
            MacroAction action = (MacroAction)var3.next();
            actionsList.add(action.toTag());
        }
        tag.method_10566("actions", actionsList);
        return tag;
    }

    public PackUtilMacro fromTag(class_2487 tag) {
        if (tag.method_10545("name")) {
            this.name = tag.method_68564("name", "");
        }
        if (tag.method_10545("description")) {
            this.description = tag.method_68564("description", "");
        }
        if (tag.method_10545("loop")) {
            this.loop = tag.method_68566("loop", false);
        }
        if (tag.method_10545("loopCount")) {
            this.loopCount = tag.method_68083("loopCount", -1);
        }
        if (tag.method_10545("keyCode")) {
            this.keyCode = tag.method_68083("keyCode", -1);
        }
        if (tag.method_10545("actions")) {
            this.actions.clear();
            class_2499 actionsList = (class_2499)tag.method_10580("actions");
            var var3 = actionsList.iterator();
        }
        while (var3.hasNext()) {
            class_2520 element = (class_2520)var3.next();
            if (!element instanceof class_2487) continue;
            class_2487 actionTag = (class_2487)element;
            try {
                String typeName = actionTag.method_68564("type", "");
                MacroActionType type = MacroActionType.valueOf(typeName);
                MacroAction action = null;
                switch (PackUtilMacro.1.$SwitchMap$com$example$addon$util$macro$MacroActionType[type.ordinal()]) {
                    case 1::
                        action = new DelayAction();
                        /* goto @1048; */
                    case 2::
                        action = new PacketAction();
                        /* goto @1048; */
                    case 3::
                        action = new WaitForPacketAction();
                        /* goto @1048; */
                    case 4::
                        action = new WaitForHealthAction();
                        /* goto @1048; */
                    case 5::
                        WaitForSlotChangeAction migrated = new WaitForSlotChangeAction();
                        migrated.fromTagLegacyItem(actionTag);
                        action = migrated;
                        /* goto @1048; */
                    case 6::
                        action = new WaitForBlockAction();
                        /* goto @1048; */
                    case 7::
                        action = new WaitForGuiAction();
                        /* goto @1048; */
                    case 8::
                        action = new ClickAction();
                        /* goto @1048; */
                    case 9::
                        action = new RotateAction();
                        /* goto @1048; */
                    case 10::
                        action = new UseItemAction();
                        /* goto @1048; */
                    case 11::
                        action = new InventoryAction();
                        /* goto @1048; */
                    case 12::
                        action = new SendPacketAction();
                        /* goto @1048; */
                    case 13::
                        action = new CraftAction();
                        /* goto @1048; */
                    case 14::
                        action = new SelectSlotAction();
                        /* goto @1048; */
                    case 15::
                        action = new XCarryAction();
                        /* goto @1048; */
                    case 16::
                        action = new DropAction();
                        /* goto @1048; */
                    case 17::
                        action = new ItemAction();
                        /* goto @1048; */
                    case 18::
                        action = new TickSyncAction();
                        /* goto @1048; */
                    case 19::
                        action = new RevisionSyncAction();
                        /* goto @1048; */
                    case 20::
                        action = new ServerTickSyncAction();
                        /* goto @1048; */
                    case 21::
                        action = new CloseGuiAction();
                        /* goto @1048; */
                    case 22::
                        action = new SwapSlotsAction();
                        /* goto @1048; */
                    case 23::
                        action = new WaitForCooldownAction();
                        /* goto @1048; */
                    case 24::
                        action = new GoToAction();
                        /* goto @1048; */
                    case 25::
                        action = new WaitPosAction();
                        /* goto @1048; */
                    case 26::
                        action = new DisconnectAction();
                        /* goto @1048; */
                    case 27::
                        action = new ToggleModuleAction();
                        /* goto @1048; */
                    case 28::
                        action = new StopMacroAction();
                        /* goto @1048; */
                    case 29::
                        action = new SneakAction();
                        /* goto @1048; */
                    case 30::
                        action = new JumpAction();
                        /* goto @1048; */
                    case 31::
                        action = new SprintAction();
                        /* goto @1048; */
                    case 32::
                        action = new MoveAction();
                        /* goto @1048; */
                    case 33::
                        action = new LookAtBlockAction();
                        /* goto @1048; */
                    case 34::
                        action = new RepeatAction();
                        /* goto @1048; */
                    case 35::
                        action = new WaitForChatAction();
                        /* goto @1048; */
                    case 36::
                        action = new WaitForEntityAction();
                        /* goto @1048; */
                    case 37::
                        action = new WaitForSlotChangeAction();
                        /* goto @1048; */
                    case 38::
                        action = new OpenContainerAction();
                        /* goto @1048; */
                    case 39::
                        action = new DesyncAction();
                        /* goto @1048; */
                    case 40::
                        action = new RestoreGuiAction();
                        /* goto @1048; */
                    case 41::
                        action = new SaveGuiAction();
                        /* goto @1048; */
                    case 42::
                        action = new SendToggleAction();
                        /* goto @1048; */
                    case 43::
                        action = new DelayPacketsAction();
                        /* goto @1048; */
                    case 44::
                        action = new InventoryAuditAction();
                        /* goto @1048; */
                    case 45::
                        action = new StoreItemAction();
                        /* goto @1048; */
                    case 46::
                        action = new WaitForSoundAction();
                        /* goto @1048; */
                    case 47::
                        action = new MineAction();
                        /* goto @1048; */
                    case 48::
                        action = new PayAction();
                        /* goto @1048; */
                    case 49::
                        action = new NbtBookAction();
                        /* goto @1048; */
                    case 50::
                        action = new SendChatAction();
                        /* goto @1048; */
                    case 51::
                        action = new WaitForLanStepAction();
                    default:
                        if (action != null) {
                            if (type == MacroActionType.WAIT_ITEM) continue;
                            action.fromTag(actionTag);
                            this.actions.add(action);
                        }
                }
            }
            catch (IllegalArgumentException typeName) {
            }
        }
        return this;
    }

    public static MacroAction createActionFromTag(class_2487 actionTag) {
        if (actionTag == null || !actionTag.method_10545("type")) {
            return null;
        }
        try {
            String typeName = actionTag.method_68564("type", "");
            MacroActionType type = MacroActionType.valueOf(typeName);
            MacroAction action = null;
            switch (PackUtilMacro.1.$SwitchMap$com$example$addon$util$macro$MacroActionType[type.ordinal()]) {
                case 1::
                    action = new DelayAction();
                    /* goto @824; */
                case 2::
                    action = new PacketAction();
                    /* goto @824; */
                case 3::
                    action = new WaitForPacketAction();
                    /* goto @824; */
                case 4::
                    action = new WaitForHealthAction();
                    /* goto @824; */
                case 5::
                    WaitForSlotChangeAction migrated = new WaitForSlotChangeAction();
                    migrated.fromTagLegacyItem(actionTag);
                    action = migrated;
                    /* goto @824; */
                case 6::
                    action = new WaitForBlockAction();
                    /* goto @824; */
                case 7::
                    action = new WaitForGuiAction();
                    /* goto @824; */
                case 8::
                    action = new ClickAction();
                    /* goto @824; */
                case 9::
                    action = new RotateAction();
                    /* goto @824; */
                case 10::
                    action = new UseItemAction();
                    /* goto @824; */
                case 11::
                    action = new InventoryAction();
                    /* goto @824; */
                case 12::
                    action = new SendPacketAction();
                    /* goto @824; */
                case 13::
                    action = new CraftAction();
                    /* goto @824; */
                case 14::
                    action = new SelectSlotAction();
                    /* goto @824; */
                case 15::
                    action = new XCarryAction();
                    /* goto @824; */
                case 16::
                    action = new DropAction();
                    /* goto @824; */
                case 17::
                    action = new ItemAction();
                    /* goto @824; */
                case 18::
                    action = new TickSyncAction();
                    /* goto @824; */
                case 19::
                    action = new RevisionSyncAction();
                    /* goto @824; */
                case 20::
                    action = new ServerTickSyncAction();
                    /* goto @824; */
                case 21::
                    action = new CloseGuiAction();
                    /* goto @824; */
                case 22::
                    action = new SwapSlotsAction();
                    /* goto @824; */
                case 23::
                    action = new WaitForCooldownAction();
                    /* goto @824; */
                case 24::
                    action = new GoToAction();
                    /* goto @824; */
                case 25::
                    action = new WaitPosAction();
                    /* goto @824; */
                case 26::
                    action = new DisconnectAction();
                    /* goto @824; */
                case 27::
                    action = new ToggleModuleAction();
                    /* goto @824; */
                case 28::
                    action = new StopMacroAction();
                    /* goto @824; */
                case 29::
                    action = new SneakAction();
                    /* goto @824; */
                case 30::
                    action = new JumpAction();
                    /* goto @824; */
                case 31::
                    action = new SprintAction();
                    /* goto @824; */
                case 32::
                    action = new MoveAction();
                    /* goto @824; */
                case 33::
                    action = new LookAtBlockAction();
                    /* goto @824; */
                case 34::
                    action = new RepeatAction();
                    /* goto @824; */
                case 35::
                    action = new WaitForChatAction();
                    /* goto @824; */
                case 36::
                    action = new WaitForEntityAction();
                    /* goto @824; */
                case 37::
                    action = new WaitForSlotChangeAction();
                    /* goto @824; */
                case 38::
                    action = new OpenContainerAction();
                    /* goto @824; */
                case 39::
                    action = new DesyncAction();
                    /* goto @824; */
                case 40::
                    action = new RestoreGuiAction();
                    /* goto @824; */
                case 41::
                    action = new SaveGuiAction();
                    /* goto @824; */
                case 42::
                    action = new SendToggleAction();
                    /* goto @824; */
                case 43::
                    action = new DelayPacketsAction();
                    /* goto @824; */
                case 44::
                    action = new InventoryAuditAction();
                    /* goto @824; */
                case 45::
                    action = new StoreItemAction();
                    /* goto @824; */
                case 46::
                    action = new WaitForSoundAction();
                    /* goto @824; */
                case 47::
                    action = new MineAction();
                    /* goto @824; */
                case 48::
                    action = new PayAction();
                    /* goto @824; */
                case 49::
                    action = new NbtBookAction();
                    /* goto @824; */
                case 50::
                    action = new SendChatAction();
                    /* goto @824; */
                case 51::
                    action = new WaitForLanStepAction();
                default:
                    if (action != null) {
                        if (type != MacroActionType.WAIT_ITEM) {
                            action.fromTag(actionTag);
                        }
                    }
                    return action;
            }
        }
        catch (IllegalArgumentException e) {
            return null;
        }
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        PackUtilMacro that = (PackUtilMacro)o;
        return Objects.equals(this.name, that.name);
    }

    public int hashCode() {
        Object[] tmp0 = new Object[1];
        tmp0[0] = this.name;
        return Objects.hash(tmp0);
    }
}
