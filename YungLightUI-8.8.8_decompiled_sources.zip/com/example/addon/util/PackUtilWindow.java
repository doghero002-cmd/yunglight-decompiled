/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiControlGlyphs;
import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindowLayout;
import net.minecraft.class_310;
import net.minecraft.class_332;

public abstract class PackUtilWindow {
    protected static final int HEADER_HEIGHT = 16;
    protected static final int RESIZE_HANDLE = 10;
    private static final PackUiTheme THEME = new PackUiTheme();
    private static final int HEADER_PAD_X = 8;
    private static final int CONTROL_SIZE = 12;
    private static final int CONTROL_GAP = 2;
    private static final int CONTROL_MARGIN = 2;
    private static final float BODY_FADE_DURATION_SECONDS = 0f;
    private boolean bodyFadeInitialized = false;
    private float bodyFadeAlpha = 1f;
    private long lastBodyFadeNanos = System.nanoTime();

    protected boolean isResizeActive(double mouseX, double mouseY, int x, int y, int width, int height) {
        return false;
    }

    protected PackUtilWindowLayout clampToScreen(IPackUtilOverlay overlay) {
        return this.clampToScreen(overlay, overlay.getBounds());
    }

    protected PackUtilWindowLayout clampToScreen(IPackUtilOverlay overlay, PackUtilWindowLayout bounds) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_22683() == null || bounds == null) {
            return bounds;
        }
        int screenWidth = PackUtilUiScale.getVirtualScreenWidth();
        int screenHeight = PackUtilUiScale.getVirtualScreenHeight();
        int minWidth = Math.min(overlay.getMinWidth(), screenWidth);
        int minHeight = Math.min(overlay.getMinHeight(), screenHeight);
        int width = Math.max(minWidth, Math.min(bounds.width, screenWidth));
        int height = Math.max(minHeight, Math.min(bounds.height, screenHeight));
        int minVisibleWidth = Math.min(width, PackUtilWindow.visibleHeaderWidth());
        int x = Math.max(Math.min(0, screenWidth - width), Math.min(bounds.x, Math.max(0, screenWidth - minVisibleWidth)));
        int y = Math.max(0, Math.min(bounds.y, Math.max(0, screenHeight - 16)));
        return new PackUtilWindowLayout(x, y, width, height, bounds.visible, bounds.collapsed);
    }

    protected void renderWindowFrame(class_332 context, int mouseX, int mouseY, PackUtilWindowLayout bounds, String title, boolean collapsed, boolean activeDrag) {
        boolean active = activeDrag || this.isWindowActive();
        int frameHeight = this.getRenderedFrameHeight(bounds, collapsed);
        int frameFill = active ? -1005975028 : -1744369911;
        int headerFill = activeDrag ? -702934507 : active ? THEME.headerFill() : -1979053556;
        int border = activeDrag ? -44205 : active ? THEME.borderColor() : THEME.borderSoft();
        int accent = activeDrag ? -40607 : active ? THEME.headerAccent() : -1434836960;
        int titleColor = active ? THEME.color(PackUiTone.LABEL) : THEME.color(PackUiTone.MUTED);
        int titleY = PackUiSizing.alignTextY(bounds.y, 16, THEME.fontHeight(PackUiTone.LABEL), THEME.bodyTextNudge());
        int controlLeft = this.getCollapseButtonLeft(bounds);
        int titleWidthLimit = Math.max(40, controlLeft - bounds.x - PackUtilWindow.headerPadX() * 2);
        String displayTitle = PackUiText.trimToWidth(class_310.method_1551().field_1772, title, titleWidthLimit, THEME.fontFor(PackUiTone.LABEL), titleColor);
        context.method_25294(bounds.x, bounds.y, bounds.x + bounds.width, bounds.y + frameHeight, frameFill);
        context.method_25294(bounds.x + 1, bounds.y + 1, bounds.x + bounds.width - 1, bounds.y + 16 - 1, headerFill);
        if (frameHeight > 16) {
            context.method_25294(bounds.x + 1, bounds.y + 16, bounds.x + bounds.width - 1, bounds.y + frameHeight - 1, 301989888);
        }
        context.method_25294(bounds.x, bounds.y, bounds.x + bounds.width, bounds.y + 1, border);
        context.method_25294(bounds.x, bounds.y + frameHeight - 1, bounds.x + bounds.width, bounds.y + frameHeight, border);
        context.method_25294(bounds.x, bounds.y, bounds.x + 1, bounds.y + frameHeight, border);
        context.method_25294(bounds.x + bounds.width - 1, bounds.y, bounds.x + bounds.width, bounds.y + frameHeight, border);
        context.method_25294(bounds.x, bounds.y + 16 - 1, bounds.x + bounds.width, bounds.y + 16, accent);
        PackUiText.draw(context, class_310.method_1551().field_1772, displayTitle, THEME.fontFor(PackUiTone.LABEL), titleColor, bounds.x + PackUtilWindow.headerPadX(), titleY, false);
        this.drawWindowControls(context, mouseX, mouseY, bounds, collapsed, active);
    }

    protected boolean beginWindowBodyClip(class_332 context, PackUtilWindowLayout bounds, boolean collapsed) {
        int frameHeight = this.getRenderedFrameHeight(bounds, collapsed);
        if (frameHeight <= 17 || this.getBodyFadeAlpha(collapsed) <= 0.001f) {
            return false;
        }
        PackUtilUiScale.enableOverlayScissor(context, bounds.x + 1, bounds.y + 16, bounds.x + bounds.width - 1, bounds.y + frameHeight - 1);
        return true;
    }

    protected void endWindowBodyClip(class_332 context, boolean clipped) {
        if (clipped) {
            context.method_44380();
        }
    }

    protected void renderWindowInactiveOverlay(class_332 context, PackUtilWindowLayout bounds, boolean collapsed, boolean activeDrag) {
        int frameHeight = this.getRenderedFrameHeight(bounds, collapsed);
        int bodyTop = bounds.y + 16;
        int bodyBottom = bounds.y + frameHeight - 1;
        if (bodyBottom > bodyTop) {
            float coverAlpha = 1f - this.getBodyFadeAlpha(collapsed);
            if (coverAlpha > 0.001f) {
                float easedCover = 1f - (float)Math.pow((double)(1f - coverAlpha), 2);
                float fadeAlpha = Math.min(0.96f, 0.1f + easedCover * 0.86f);
                context.method_25294(bounds.x + 1, bodyTop, bounds.x + bounds.width - 1, bodyBottom, PackUiRenderContext.applyAlpha(-704050933, fadeAlpha));
            }
        }
        if (activeDrag || this.isWindowActive()) {
            return;
        }
        context.method_25294(bounds.x + 1, bounds.y + 1, bounds.x + bounds.width - 1, bounds.y + frameHeight - 1, 905969664);
    }

    protected int alignViewportHeight(int innerHeight, int rowStep) {
        int safeInnerHeight = Math.max(0, innerHeight);
        int safeRowStep = Math.max(1, rowStep);
        if (safeInnerHeight == 0 || safeRowStep <= 1) {
            return safeInnerHeight;
        }
        int aligned = safeInnerHeight / safeRowStep * safeRowStep;
        return aligned > 0 ? aligned : Math.min(safeInnerHeight, safeRowStep);
    }

    protected int quantizeScrollOffset(int offset, int stepSize, int maxScroll) {
        int clampedMax = Math.max(0, maxScroll);
        int clampedOffset = Math.max(0, Math.min(offset, clampedMax));
        int safeStepSize = Math.max(1, stepSize);
        if (safeStepSize <= 1) {
            return clampedOffset;
        }
        int quantized = clampedOffset / safeStepSize * safeStepSize;
        if (quantized > clampedMax) {
            quantized = clampedMax / safeStepSize * safeStepSize;
        }
        return Math.max(0, Math.min(quantized, clampedMax));
    }

    protected int getRenderedFrameHeight(PackUtilWindowLayout bounds, boolean collapsed) {
        if (bounds == null) {
            return 16;
        }
        float bodyAlpha = this.getBodyFadeAlpha(collapsed);
        if (collapsed && bodyAlpha <= 0.001f) {
            return 16;
        }
        return Math.max(16, bounds.height);
    }

    protected boolean isOverCloseButton(double mouseX, double mouseY, PackUtilWindowLayout bounds) {
        int x = this.getCloseButtonLeft(bounds);
        int y = this.getControlTop(bounds);
        return mouseX >= (double)x && mouseX <= (double)(x + PackUtilWindow.controlSize()) && mouseY >= (double)y && mouseY <= (double)(y + PackUtilWindow.controlSize());
    }

    protected boolean isOverCollapseButton(double mouseX, double mouseY, PackUtilWindowLayout bounds) {
        if (this.usesSharedHeaderClickCollapse()) {
            return false;
        }
        int x = this.getCollapseButtonLeft(bounds);
        int y = this.getControlTop(bounds);
        return mouseX >= (double)x && mouseX <= (double)(x + PackUtilWindow.controlSize()) && mouseY >= (double)y && mouseY <= (double)(y + PackUtilWindow.controlSize());
    }

    protected boolean isOverWindowControl(double mouseX, double mouseY, PackUtilWindowLayout bounds) {
        return this.isOverCloseButton(mouseX, mouseY, bounds) || this.isOverCollapseButton(mouseX, mouseY, bounds);
    }

    private void drawWindowControls(class_332 context, int mouseX, int mouseY, PackUtilWindowLayout bounds, boolean collapsed, boolean active) {
        int controlTop = this.getControlTop(bounds);
        int closeX = this.getCloseButtonLeft(bounds);
        int collapseX = this.getCollapseButtonLeft(bounds);
        boolean hoverClose = this.isOverCloseButton((double)mouseX, (double)mouseY, bounds);
        PackUiControlGlyphs.drawChevron(context, collapseX + 1, controlTop + 1, PackUtilWindow.controlSize() - 2, collapsed ? PackUiControlGlyphs.ChevronDirection.RIGHT : PackUiControlGlyphs.ChevronDirection.DOWN, -725523, -1002629349, active ? 1f : 0.56f);
        PackUiHeaderControls.drawCloseButton(context, closeX, controlTop, PackUtilWindow.controlSize(), PackUtilWindow.controlSize(), hoverClose ? 1f : 0f, active, 1f);
    }

    private boolean isWindowActive() {
        var var2 = this;
        if (var2 instanceof IPackUtilOverlay) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var2;
        } else {
            return true;
        }
        return PackUtilOverlayManager.get().isFocusedOverlay(overlay) || PackUtilOverlayManager.get().isTopOverlay(overlay);
    }

    private float getBodyFadeAlpha(boolean collapsed) {
        this.lastBodyFadeNanos = System.nanoTime();
        this.bodyFadeInitialized = true;
        this.bodyFadeAlpha = collapsed ? 0f : 1f;
        return this.bodyFadeAlpha;
    }

    private int getControlTop(PackUtilWindowLayout bounds) {
        return bounds.y + Math.max(1, (16 - PackUtilWindow.controlSize()) / 2);
    }

    private int getCloseButtonLeft(PackUtilWindowLayout bounds) {
        return bounds.x + bounds.width - PackUtilWindow.controlMargin() - PackUtilWindow.controlSize();
    }

    private int getCollapseButtonLeft(PackUtilWindowLayout bounds) {
        return this.getCloseButtonLeft(bounds) - PackUtilWindow.controlGap() - PackUtilWindow.controlSize();
    }

    private static int headerPadX() {
        return 8;
    }

    private static int controlSize() {
        return 12;
    }

    private static int controlGap() {
        return 2;
    }

    private static int controlMargin() {
        return 2;
    }

    private static int visibleHeaderWidth() {
        return 56;
    }

    private boolean usesSharedHeaderClickCollapse() {
        var var2 = this;
        IPackUtilOverlay overlay = (IPackUtilOverlay)var2;
        if (!overlay.usesSharedHeaderClickCollapse()) { /* goto @27; */ }
        return var2 instanceof IPackUtilOverlay;
    }
}
