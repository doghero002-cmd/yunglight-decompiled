/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.macro.MacroExecutor;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import net.minecraft.class_11908;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_463;
import net.minecraft.class_465;
import net.minecraft.class_471;
import net.minecraft.class_481;
import net.minecraft.class_497;

public final class PackUtilInventoryMoveHelper {
    private static final class_310 MC = class_310.method_1551();
    private static final Set<class_304> OWNED_KEYS = Collections.newSetFromMap(new IdentityHashMap());

    private PackUtilInventoryMoveHelper() {
    }

    public static boolean handleKeyInput(class_11908 input, boolean pressed) {
        if (input == null) {
            return false;
        }
        PackUtilModule module = PackUtilModule.get();
        if (module == null || !module.isActive() || !module.isInventoryMoveEnabled()) {
            PackUtilInventoryMoveHelper.releaseMovementKeysIfSafe();
            return false;
        }
        if (MacroExecutor.isRunning()) {
            PackUtilInventoryMoveHelper.releaseMovementKeysIfSafe();
            return false;
        }
        if (!PackUtilInventoryMoveHelper.shouldHandleCurrentScreen()) {
            PackUtilInventoryMoveHelper.releaseMovementKeysIfSafe();
            return false;
        }
        if (PackUtilOverlayManager.get().isAnyTextFieldFocused()) {
            PackUtilInventoryMoveHelper.releaseMovementKeysIfSafe();
            return false;
        }
        if (MC == null || MC.field_1690 == null) {
            PackUtilInventoryMoveHelper.releaseMovementKeysIfSafe();
            return false;
        }
        boolean handled = false;
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1894, input, pressed);
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1881, input, pressed);
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1913, input, pressed);
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1849, input, pressed);
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1903, input, pressed);
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1832, input, pressed);
        handled = handled | PackUtilInventoryMoveHelper.pass(MC.field_1690.field_1867, input, pressed);
        return handled;
    }

    public static void releaseMovementKeysIfSafe() {
        if (MC == null || MC.field_1690 == null) {
            return;
        }
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1894);
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1881);
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1913);
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1849);
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1903);
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1832);
        PackUtilInventoryMoveHelper.releaseOwned(MC.field_1690.field_1867);
    }

    private static boolean pass(class_304 binding, class_11908 input, boolean pressed) {
        if (binding == null || !binding.method_1417(input)) {
            return false;
        }
        binding.method_23481(pressed);
        if (pressed) {
            OWNED_KEYS.add(binding);
        } else {
            OWNED_KEYS.remove(binding);
        }
        return true;
    }

    private static void releaseOwned(class_304 binding) {
        if (binding == null) {
            return;
        }
        if (OWNED_KEYS.remove(binding)) {
            binding.method_23481(false);
        }
    }

    private static boolean shouldHandleCurrentScreen() {
        if (MC == null || MC.field_1755 == null) {
            return false;
        }
        if (!(MC.field_1755 instanceof class_465)) {
            return false;
        }
        if (MC.field_1755 instanceof class_481) {
            return false;
        }
        if (MC.field_1755 instanceof class_471) {
            return false;
        }
        if (MC.field_1755 instanceof class_463) {
            return false;
        }
        if (MC.field_1755 instanceof class_497) {
            return false;
        }
        return true;
    }
}
