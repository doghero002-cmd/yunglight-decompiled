/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_2596;
import net.minecraft.class_310;

@FunctionalInterface
public static interface PacketRegenerator.PacketHandler<T extends class_2596<?>> {
    public T regenerate(T var1, class_310 var2);
}
