/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilSharedState;

private static class PackUtilQueueEditorOverlay.RowRegion {
    final PackUtilSharedState.QueuedPacket packet;
    final int x;
    final int y;
    final int width;
    final int height;
    final int delayX;
    final int delayWidth;
    final int removeX;
    final int removeWidth;

    private PackUtilQueueEditorOverlay.RowRegion(PackUtilSharedState.QueuedPacket packet, int x, int y, int width, int height, int delayX, int delayWidth, int removeX, int removeWidth) {
        this.packet = packet;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.delayX = delayX;
        this.delayWidth = delayWidth;
        this.removeX = removeX;
        this.removeWidth = removeWidth;
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }

    private boolean overDelay(double mouseX, double mouseY) {
        return this.contains(mouseX, mouseY) && mouseX >= (double)this.delayX && mouseX < (double)(this.delayX + this.delayWidth);
    }

    private boolean overRemove(double mouseX, double mouseY) {
        return this.contains(mouseX, mouseY) && mouseX >= (double)this.removeX && mouseX < (double)(this.removeX + this.removeWidth);
    }
}
