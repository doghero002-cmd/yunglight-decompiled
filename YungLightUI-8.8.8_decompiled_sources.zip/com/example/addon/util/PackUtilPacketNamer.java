/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketRegistry;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_2596;

public class PackUtilPacketNamer {
    private static final String UNKNOWN_PACKET = "Unknown Packet";
    private static final Map<String, String> MANUAL_NAME_ALIASES = PackUtilPacketNamer.createManualNameAliases();

    private static String stripSuffix(String name) {
        if (name != null && name.endsWith("Packet")) {
            return name.substring(0, name.length() - 6);
        }
        return name;
    }

    public static String getFriendlyName(class_2596<?> packet) {
        Class<? extends class_2596<?>> packetClass = packet.getClass();
        String name = PackUtilPacketNamer.resolveRegistryName(packetClass);
        if (name != null) {
            return PackUtilPacketNamer.stripSuffix(name);
        }
        String typeName = PackUtilPacketNamer.resolveNameFromPacketType(packet);
        if (typeName != null) {
            return PackUtilPacketNamer.stripSuffix(typeName);
        }
        String inspected = PackUtilPacketNamer.inspectObfuscatedPacket(packet, packetClass.getSimpleName());
        if (inspected != null) {
            return inspected;
        }
        String readable = PackUtilPacketNamer.deriveReadableClassName(packetClass);
        return readable != null ? readable : "Unknown Packet";
    }

    public static String getFriendlyName(class_2596<?> packet, String direction) {
        Class<? extends class_2596<?>> packetClass = packet.getClass();
        String name = PackUtilPacketNamer.resolveRegistryName(packetClass, direction);
        if (name != null) {
            return PackUtilPacketNamer.stripSuffix(name);
        }
        String typeName = PackUtilPacketNamer.resolveNameFromPacketType(packet, direction);
        if (typeName != null) {
            return PackUtilPacketNamer.stripSuffix(typeName);
        }
        String inspected = PackUtilPacketNamer.inspectObfuscatedPacket(packet, packetClass.getSimpleName());
        if (inspected != null) {
            return inspected;
        }
        String readable = PackUtilPacketNamer.deriveReadableClassName(packetClass);
        return readable != null ? readable : "Unknown Packet";
    }

    public static String getFriendlyName(Class<? extends class_2596<?>> packetClass) {
        String name = PackUtilPacketNamer.resolveRegistryName(packetClass);
        if (name != null) {
            return PackUtilPacketNamer.stripSuffix(name);
        }
        String readable = PackUtilPacketNamer.deriveReadableClassName(packetClass);
        return readable != null ? readable : "Unknown Packet";
    }

    public static String getFriendlyName(String name) {
        if (name == null || name.isEmpty()) {
            return "";
        }
        Class<? extends class_2596<?>> packetClass = PackUtilPacketRegistry.getPacket(name);
        if (packetClass == null) { /* goto L42; */ }
        String resolved = PackUtilPacketNamer.resolveRegistryName(packetClass);
        return resolved != null ? PackUtilPacketNamer.stripSuffix(resolved) : "Unknown Packet";
        resolved = PackUtilPacketNamer.resolveNameFromText(name);
        if (resolved != null) {
            return PackUtilPacketNamer.stripSuffix(resolved);
        }
        String readable = PackUtilPacketNamer.prettifyRawName(name);
        return readable != null ? readable : "Unknown Packet";
    }

    private static String resolveRegistryName(Class<? extends class_2596<?>> packetClass) {
        if (packetClass == null) {
            return null;
        }
        String direct = PackUtilPacketRegistry.getName(packetClass);
        if (direct != null) {
            return direct;
        }
        String byText = PackUtilPacketRegistry.PACKETS.iterator();
        while (byText.hasNext()) {
            Class<? extends class_2596<?>> registeredClass = (Class)byText.next();
            if (registeredClass == packetClass || registeredClass.isAssignableFrom(packetClass)) {
                String name = PackUtilPacketRegistry.getName(registeredClass);
                if (name == null) continue;
                return name;
            }
        }
        byText = PackUtilPacketNamer.resolveNameFromText(packetClass.getName());
        if (byText != null) {
            return byText;
        }
        return PackUtilPacketNamer.resolveNameFromText(packetClass.getCanonicalName());
    }

    private static String resolveRegistryName(Class<? extends class_2596<?>> packetClass, String direction) {
        if (packetClass == null) {
            return null;
        }
        String direct = PackUtilPacketNamer.resolveDirectionalRegistryName(packetClass, direction);
        if (direct != null) {
            return direct;
        }
        String byText = PackUtilPacketNamer.resolveNameFromText(packetClass.getName(), direction);
        if (byText != null) {
            return byText;
        }
        return PackUtilPacketNamer.resolveNameFromText(packetClass.getCanonicalName(), direction);
    }

    private static String resolveNameFromPacketType(class_2596<?> packet) {
        if (packet == null) {
            return null;
        }
        try {
            Object packetType = packet.getClass().getMethod("getPacketType", new Class[0]).invoke(packet, new Object[0]);
            if (packetType == null) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            return PackUtilPacketNamer.resolveNameFromText(packetType.toString());
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static String resolveNameFromPacketType(class_2596<?> packet, String direction) {
        if (packet == null) {
            return null;
        }
        try {
            Object packetType = packet.getClass().getMethod("getPacketType", new Class[0]).invoke(packet, new Object[0]);
            if (packetType == null) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            return PackUtilPacketNamer.resolveNameFromText(packetType.toString(), direction);
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static String resolveNameFromText(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        String normalizedText = PackUtilPacketNamer.normalizePacketKey(text);
        if (normalizedText.isEmpty()) {
            return null;
        }
        String manual = (String)MANUAL_NAME_ALIASES.get(normalizedText);
        if (manual != null) {
            return manual;
        }
        var var3 = PackUtilPacketRegistry.PACKETS.iterator();
        while (var3.hasNext()) {
            Class<? extends class_2596<?>> registeredClass = (Class)var3.next();
            String registeredName = PackUtilPacketRegistry.getName(registeredClass);
            while (registeredName == null) {
            }
            if (!PackUtilPacketNamer.matchesRegisteredName(normalizedText, registeredName, registeredClass)) continue;
            return registeredName;
        }
        return null;
    }

    private static String resolveNameFromText(String text, String direction) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        String normalizedText = PackUtilPacketNamer.normalizePacketKey(text);
        if (normalizedText.isEmpty()) {
            return null;
        }
        String manual = (String)MANUAL_NAME_ALIASES.get(normalizedText);
        if (manual != null) {
            return manual;
        }
        var var4 = PackUtilPacketNamer.getDirectionalRegistry(direction).iterator();
        while (var4.hasNext()) {
            Class<? extends class_2596<?>> registeredClass = (Class)var4.next();
            String registeredName = PackUtilPacketRegistry.getName(registeredClass);
            while (registeredName == null) {
            }
            if (!PackUtilPacketNamer.matchesRegisteredName(normalizedText, registeredName, registeredClass)) continue;
            return registeredName;
        }
        return null;
    }

    private static String resolveDirectionalRegistryName(Class<? extends class_2596<?>> packetClass, String direction) {
        var var2 = PackUtilPacketNamer.getDirectionalRegistry(direction).iterator();
        while (var2.hasNext()) {
            Class<? extends class_2596<?>> registeredClass = (Class)var2.next();
            if (registeredClass != packetClass) continue;
            return PackUtilPacketRegistry.getName(registeredClass);
        }
        return null;
    }

    private static Iterable<Class<? extends class_2596<?>>> getDirectionalRegistry(String direction) {
        if ("C2S".equalsIgnoreCase(direction)) {
            return PackUtilPacketRegistry.getC2SPackets();
        }
        if ("S2C".equalsIgnoreCase(direction)) {
            return PackUtilPacketRegistry.getS2CPackets();
        }
        return PackUtilPacketRegistry.PACKETS;
    }

    private static boolean matchesRegisteredName(String normalizedText, String registeredName, Class<? extends class_2596<?>> registeredClass) {
        String normalizedRegistered = PackUtilPacketNamer.normalizePacketKey(registeredName);
        if (normalizedRegistered.equals(normalizedText)) {
            return true;
        }
        String strippedRegistered = PackUtilPacketNamer.normalizePacketKey(PackUtilPacketNamer.stripSuffix(registeredName));
        if (strippedRegistered.equals(normalizedText)) {
            return true;
        }
        String className = PackUtilPacketNamer.normalizePacketKey(registeredClass.getName());
        if (className.equals(normalizedText) || normalizedText.endsWith(className)) {
            return true;
        }
        String simpleName = PackUtilPacketNamer.normalizePacketKey(registeredClass.getSimpleName());
        if (simpleName.equals(normalizedText) || normalizedText.endsWith(simpleName)) {
            return true;
        }
        String canonicalName = PackUtilPacketNamer.normalizePacketKey(registeredClass.getCanonicalName());
        if (!canonicalName.isEmpty()) {
            if (canonicalName.equals(normalizedText) || normalizedText.endsWith(canonicalName)) {
                return true;
            }
        }
        return normalizedText.endsWith(normalizedRegistered) || normalizedText.endsWith(strippedRegistered);
    }

    private static Map<String, String> createManualNameAliases() {
        Map<String, String> aliases = new HashMap();
        PackUtilPacketNamer.registerManualAlias(aliases, "BundleS2CPacket", "BundleS2C", "class_8042", "net.minecraft.class_8042", "net.minecraft.network.packet.s2c.play.BundleS2CPacket", "net.minecraft.network.protocol.game.ClientboundBundlePacket");
        return Collections.unmodifiableMap(aliases);
    }

    private static void registerManualAlias(Map<String, String> aliases, String canonicalName, String ... variants) {
        aliases.put(PackUtilPacketNamer.normalizePacketKey(canonicalName), canonicalName);
        aliases.put(PackUtilPacketNamer.normalizePacketKey(PackUtilPacketNamer.stripSuffix(canonicalName)), canonicalName);
        var var3 = variants;
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String variant = var3[var5];
            if (variant != null) {
                if (variant.isEmpty()) continue;
                aliases.put(PackUtilPacketNamer.normalizePacketKey(variant), canonicalName);
            }
        }
    }

    private static String deriveReadableClassName(Class<?> packetClass) {
        if (packetClass == null) {
            return null;
        }
        String canonical = PackUtilPacketNamer.prettifyRawName(packetClass.getCanonicalName());
        if (canonical != null) {
            return canonical;
        }
        return PackUtilPacketNamer.prettifyRawName(packetClass.getName());
    }

    private static String prettifyRawName(String rawName) {
        if (rawName == null || rawName.isEmpty()) {
            return null;
        }
        int lastDot = rawName.lastIndexOf(46);
        String shortName = lastDot >= 0 ? rawName.substring(lastDot + 1) : rawName;
        shortName = shortName.replace(36, 46);
        if (PackUtilPacketNamer.isObfuscatedName(shortName)) {
            return null;
        }
        return PackUtilPacketNamer.stripSuffix(shortName);
    }

    private static boolean isObfuscatedName(String name) {
        String normalized = PackUtilPacketNamer.normalizePacketKey(name);
        return normalized.startsWith("class") && normalized.length() > 5;
    }

    private static String normalizePacketKey(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static String inspectObfuscatedPacket(class_2596<?> packet, String className) {
        try {
            String packetStr = packet.toString();
            if (packetStr.contains("slot=") || packetStr.contains("Slot")) {
                if (packetStr.contains("button=") || packetStr.contains("Button")) {
                    return "Click Slot";
                }
                return "Slot Action";
            }
        }
        catch (Exception e) {
            return null;
        }
        try {
            return "Slot Action";
        }
        catch (Exception e) {
            return null;
        }
        try {
            if (packetStr.contains("hand=") || packetStr.contains("Hand")) {
                return "Swing Hand";
            }
        }
        catch (Exception e) {
            return null;
        }
        try {
            if (packetStr.contains("button=") || packetStr.contains("Button")) {
                return "Click Button";
            }
        }
        catch (Exception e) {
            return null;
        }
        try {
            if (packetStr.contains("action=") || packetStr.contains("Action")) {
                if (packetStr.contains("DROP_ITEM") || packetStr.contains("drop")) {
                    return "Drop Item";
                }
                if (packetStr.contains("DROP_ALL") || packetStr.contains("drop_all")) {
                    return "Drop Stack";
                }
                if (packetStr.contains("SWAP") || packetStr.contains("swap")) {
                    return "Swap Hands";
                }
                return "Player Action";
            }
        }
        catch (Exception e) {
            return null;
        }
        try {
            if (packetStr.contains("DROP_ALL") || packetStr.contains("drop_all")) {
                return "Drop Stack";
            }
        }
        catch (Exception e) {
            return null;
        }
        try {
            if (packetStr.contains("SWAP") || packetStr.contains("swap")) {
                return "Swap Hands";
            }
        }
        catch (Exception e) {
            return null;
        }
        try {
            return "Player Action";
        }
        catch (Exception e) {
            return null;
        }
        try {
            return null;
        }
        catch (Exception e) {
            return null;
        }
    }
}
