/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.SearchRequestPacket
extends LanPacket {
    public LanPacket.SearchRequestPacket(String sessionId) {
        super(LanPacketType.SEARCH_REQUEST, sessionId);
    }

    public LanPacket.SearchRequestPacket() {
        super(LanPacketType.SEARCH_REQUEST, "");
    }

    public void write(DataOutputStream out) throws IOException {
    }

    public void read(DataInputStream in) throws IOException {
    }
}
