/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.TcpCommandAckPacket
extends LanPacket {
    public String senderUsername;
    public long executeNanoTime;

    public LanPacket.TcpCommandAckPacket(String sessionId, String senderUsername, long executeNanoTime) {
        super(LanPacketType.TCP_COMMAND_ACK, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.executeNanoTime = executeNanoTime;
    }

    public LanPacket.TcpCommandAckPacket() {
        super(LanPacketType.TCP_COMMAND_ACK, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeLong(this.executeNanoTime);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.executeNanoTime = in.readLong();
    }
}
