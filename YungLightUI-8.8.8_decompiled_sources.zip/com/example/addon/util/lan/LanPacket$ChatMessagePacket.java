/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.ChatMessagePacket
extends LanPacket {
    public String senderUsername;
    public String message;

    public LanPacket.ChatMessagePacket(String sessionId, String senderUsername, String message) {
        super(LanPacketType.CHAT_MESSAGE, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.message = message != null ? message : "";
    }

    public LanPacket.ChatMessagePacket() {
        super(LanPacketType.CHAT_MESSAGE, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.message);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.message = in.readUTF();
    }
}
