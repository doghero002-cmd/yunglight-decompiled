/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.RequestMacroPacket
extends LanPacket {
    public String macroName;

    public LanPacket.RequestMacroPacket(String sessionId, String macroName) {
        super(LanPacketType.REQUEST_MACRO, sessionId);
        this.macroName = macroName;
    }

    public LanPacket.RequestMacroPacket() {
        super(LanPacketType.REQUEST_MACRO, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.macroName);
    }

    public void read(DataInputStream in) throws IOException {
        this.macroName = in.readUTF();
    }
}
