/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.ClientReadyPacket
extends LanPacket {
    public long executionId;
    public String senderUsername;

    public LanPacket.ClientReadyPacket(String sessionId, long executionId, String senderUsername) {
        super(LanPacketType.CLIENT_READY, sessionId);
        this.executionId = executionId;
        this.senderUsername = senderUsername;
    }

    public LanPacket.ClientReadyPacket() {
        super(LanPacketType.CLIENT_READY, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(this.executionId);
        out.writeUTF(this.senderUsername);
    }

    public void read(DataInputStream in) throws IOException {
        this.executionId = in.readLong();
        this.senderUsername = in.readUTF();
    }
}
