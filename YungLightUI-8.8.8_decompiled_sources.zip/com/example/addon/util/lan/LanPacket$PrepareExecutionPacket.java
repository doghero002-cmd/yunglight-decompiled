/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public static class LanPacket.PrepareExecutionPacket
extends LanPacket {
    public long executionId;
    public boolean isMacro;
    public String targetName;
    public String queueData;
    public String senderUsername;
    public String macroAssignments = "";

    public LanPacket.PrepareExecutionPacket(String sessionId, long executionId, boolean isMacro, String targetName, String queueData, String senderUsername) {
        super(LanPacketType.PREPARE_EXECUTION, sessionId);
        this.executionId = executionId;
        this.isMacro = isMacro;
        this.targetName = targetName;
        this.queueData = queueData != null ? queueData : "";
        this.senderUsername = senderUsername;
    }

    public LanPacket.PrepareExecutionPacket() {
        super(LanPacketType.PREPARE_EXECUTION, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(this.executionId);
        out.writeBoolean(this.isMacro);
        out.writeUTF(this.targetName);
        out.writeUTF(this.queueData);
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.macroAssignments);
    }

    public void read(DataInputStream in) throws IOException {
        this.executionId = in.readLong();
        this.isMacro = in.readBoolean();
        this.targetName = in.readUTF();
        this.queueData = in.readUTF();
        try {
            this.senderUsername = in.readUTF();
        }
        catch (EOFException e) {
            this.senderUsername = "";
            return;
        }
        try {
            this.macroAssignments = in.readUTF();
        }
        catch (EOFException e) {
            this.macroAssignments = "";
            L69: ;
            return;
        }
    }
}
