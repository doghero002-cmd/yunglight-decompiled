/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.ClientOffsetUpdatePacket
extends LanPacket {
    public String senderUsername;
    public String targetUsername;
    public int offsetMs;

    public LanPacket.ClientOffsetUpdatePacket(String sessionId, String senderUsername, String targetUsername, int offsetMs) {
        super(LanPacketType.CLIENT_OFFSET_UPDATE, sessionId);
        this.senderUsername = senderUsername;
        this.targetUsername = targetUsername;
        this.offsetMs = offsetMs;
    }

    public LanPacket.ClientOffsetUpdatePacket() {
        super(LanPacketType.CLIENT_OFFSET_UPDATE, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.targetUsername);
        out.writeInt(this.offsetMs);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.targetUsername = in.readUTF();
        this.offsetMs = in.readInt();
    }
}
