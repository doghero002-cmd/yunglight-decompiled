/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.RequestSyncPacket
extends LanPacket {
    public String senderUsername;
    public boolean isMacro;
    public String macroName;
    public String command;

    public LanPacket.RequestSyncPacket(String sessionId, String senderUsername, boolean isMacro, String macroName, String command) {
        super(LanPacketType.REQUEST_SYNC, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.isMacro = isMacro;
        this.macroName = macroName != null ? macroName : "";
        this.command = command != null ? command : "";
    }

    public LanPacket.RequestSyncPacket() {
        super(LanPacketType.REQUEST_SYNC, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeBoolean(this.isMacro);
        out.writeUTF(this.macroName);
        out.writeUTF(this.command);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.isMacro = in.readBoolean();
        this.macroName = in.readUTF();
        this.command = in.readUTF();
    }
}
