/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.PresetDataPacket
extends LanPacket {
    public String senderUsername;
    public String presetName;
    public String presetJson;

    public LanPacket.PresetDataPacket(String sessionId, String senderUsername, String presetName, String presetJson) {
        super(LanPacketType.PRESET_DATA, sessionId);
        this.senderUsername = senderUsername;
        this.presetName = presetName;
        this.presetJson = presetJson;
    }

    public LanPacket.PresetDataPacket() {
        super(LanPacketType.PRESET_DATA, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.presetName);
        out.writeUTF(this.presetJson);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.presetName = in.readUTF();
        this.presetJson = in.readUTF();
    }
}
