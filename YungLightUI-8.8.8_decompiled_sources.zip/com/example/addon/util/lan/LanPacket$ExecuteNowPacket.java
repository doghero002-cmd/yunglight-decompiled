/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.ExecuteNowPacket
extends LanPacket {
    public long executionId;
    public long targetTime;

    public LanPacket.ExecuteNowPacket(String sessionId, long executionId, long targetTime) {
        super(LanPacketType.EXECUTE_NOW, sessionId);
        this.executionId = executionId;
        this.targetTime = targetTime;
    }

    public LanPacket.ExecuteNowPacket() {
        super(LanPacketType.EXECUTE_NOW, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(this.executionId);
        out.writeLong(this.targetTime);
    }

    public void read(DataInputStream in) throws IOException {
        this.executionId = in.readLong();
        this.targetTime = in.readLong();
    }
}
