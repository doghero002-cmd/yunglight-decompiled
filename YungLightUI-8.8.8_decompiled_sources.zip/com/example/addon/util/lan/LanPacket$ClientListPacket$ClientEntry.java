/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

public static class LanPacket.ClientListPacket.ClientEntry {
    public String name;
    public boolean isHost;

    public LanPacket.ClientListPacket.ClientEntry(String name, boolean isHost) {
        this.name = name;
        this.isHost = isHost;
    }
}
