/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.SyncStateUpdatePacket
extends LanPacket {
    public int stateOrdinal;
    public String detail;

    public LanPacket.SyncStateUpdatePacket(String sessionId, int stateOrdinal, String detail) {
        super(LanPacketType.SYNC_STATE_UPDATE, sessionId);
        this.stateOrdinal = stateOrdinal;
        this.detail = detail != null ? detail : "";
    }

    public LanPacket.SyncStateUpdatePacket() {
        super(LanPacketType.SYNC_STATE_UPDATE, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeInt(this.stateOrdinal);
        out.writeUTF(this.detail);
    }

    public void read(DataInputStream in) throws IOException {
        this.stateOrdinal = in.readInt();
        this.detail = in.readUTF();
    }
}
