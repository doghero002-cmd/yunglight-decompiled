/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public static class LanPacket.PlayerOffsetsPacket
extends LanPacket {
    public Map<String, Integer> offsets = new HashMap();

    public LanPacket.PlayerOffsetsPacket(String sessionId, Map<String, Integer> offsets) {
        super(LanPacketType.PLAYER_OFFSETS, sessionId);
        this.offsets = offsets != null ? new HashMap(offsets) : new HashMap();
    }

    public LanPacket.PlayerOffsetsPacket() {
        super(LanPacketType.PLAYER_OFFSETS, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeInt(this.offsets.size());
        var var2 = this.offsets.entrySet().iterator();
        while (var2.hasNext()) {
            Map.Entry<String, Integer> entry = (Map.Entry)var2.next();
            out.writeUTF((String)entry.getKey());
            out.writeInt(((Integer)entry.getValue()).intValue());
        }
    }

    public void read(DataInputStream in) throws IOException {
        int count = in.readInt();
        this.offsets = new HashMap();
        for (int i = 0; i < count; i++) {
            String player = in.readUTF();
            int offset = in.readInt();
            this.offsets.put(player, offset);
        }
    }
}
