/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.MacroDeletePacket
extends LanPacket {
    public String senderUsername;
    public String macroName;

    public LanPacket.MacroDeletePacket(String sessionId, String senderUsername, String macroName) {
        super(LanPacketType.MACRO_DELETE, sessionId);
        this.senderUsername = senderUsername;
        this.macroName = macroName;
    }

    public LanPacket.MacroDeletePacket() {
        super(LanPacketType.MACRO_DELETE, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.macroName);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.macroName = in.readUTF();
    }
}
