/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.MacroDataChunkPacket
extends LanPacket {
    public String senderUsername;
    public String macroName;
    public int chunkIndex;
    public int totalChunks;
    public byte[] chunkData;

    public LanPacket.MacroDataChunkPacket(String sessionId, String senderUsername, String macroName, int chunkIndex, int totalChunks, byte[] chunkData) {
        super(LanPacketType.MACRO_DATA_CHUNK, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.macroName = macroName != null ? macroName : "";
        this.chunkIndex = chunkIndex;
        this.totalChunks = totalChunks;
        this.chunkData = chunkData != null ? chunkData : new byte[0];
    }

    public LanPacket.MacroDataChunkPacket() {
        super(LanPacketType.MACRO_DATA_CHUNK, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.macroName);
        out.writeInt(this.chunkIndex);
        out.writeInt(this.totalChunks);
        out.writeInt(this.chunkData.length);
        out.write(this.chunkData);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.macroName = in.readUTF();
        this.chunkIndex = in.readInt();
        this.totalChunks = in.readInt();
        int len = in.readInt();
        this.chunkData = new byte[len];
        in.readFully(this.chunkData);
    }
}
