/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.LeavePacket
extends LanPacket {
    public String username;

    public LanPacket.LeavePacket(String sessionId, String username) {
        super(LanPacketType.LEAVE, sessionId);
        this.username = username;
    }

    public LanPacket.LeavePacket() {
        super(LanPacketType.LEAVE, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.username);
    }

    public void read(DataInputStream in) throws IOException {
        this.username = in.readUTF();
    }
}
