/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.MacroAssignmentSyncPacket
extends LanPacket {
    public String senderUsername = "";
    public String assignments = "";

    public LanPacket.MacroAssignmentSyncPacket(String sessionId, String senderUsername, String assignments) {
        super(LanPacketType.MACRO_ASSIGNMENT_SYNC, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.assignments = assignments != null ? assignments : "";
    }

    public LanPacket.MacroAssignmentSyncPacket() {
        super(LanPacketType.MACRO_ASSIGNMENT_SYNC, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.assignments);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.assignments = in.readUTF();
    }
}
