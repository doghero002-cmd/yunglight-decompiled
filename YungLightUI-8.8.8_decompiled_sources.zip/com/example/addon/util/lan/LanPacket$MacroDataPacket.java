/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public static class LanPacket.MacroDataPacket
extends LanPacket {
    public String senderUsername;
    public String macroName;
    public String nbtData;
    public byte sourceType;

    public LanPacket.MacroDataPacket(String sessionId, String senderUsername, String macroName, String nbtData, byte sourceType) {
        super(LanPacketType.MACRO_DATA, sessionId);
        this.senderUsername = senderUsername;
        this.macroName = macroName;
        this.nbtData = nbtData != null ? nbtData : "";
        this.sourceType = sourceType;
    }

    public LanPacket.MacroDataPacket() {
        super(LanPacketType.MACRO_DATA, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeUTF(this.macroName);
        out.writeUTF(this.nbtData);
        out.writeByte(this.sourceType);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.macroName = in.readUTF();
        this.nbtData = in.readUTF();
        try {
            this.sourceType = in.readByte();
        }
        catch (EOFException e) {
            this.sourceType = 0;
            L41: ;
            return;
        }
    }
}
