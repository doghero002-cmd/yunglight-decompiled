/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.MacroStepProgressPacket
extends LanPacket {
    public String senderUsername;
    public int completedStep;
    public int totalSteps;
    public String macroName;

    public LanPacket.MacroStepProgressPacket(String sessionId, String senderUsername, int completedStep, int totalSteps, String macroName) {
        super(LanPacketType.MACRO_STEP_PROGRESS, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.completedStep = completedStep;
        this.totalSteps = totalSteps;
        this.macroName = macroName != null ? macroName : "";
    }

    public LanPacket.MacroStepProgressPacket() {
        super(LanPacketType.MACRO_STEP_PROGRESS, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeInt(this.completedStep);
        out.writeInt(this.totalSteps);
        out.writeUTF(this.macroName);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.completedStep = in.readInt();
        this.totalSteps = in.readInt();
        this.macroName = in.readUTF();
    }
}
