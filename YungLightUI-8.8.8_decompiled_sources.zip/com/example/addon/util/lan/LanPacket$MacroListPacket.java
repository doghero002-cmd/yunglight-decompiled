/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public static class LanPacket.MacroListPacket
extends LanPacket {
    public String senderUsername;
    public List<String> macroNames = new ArrayList();

    public LanPacket.MacroListPacket(String sessionId, String senderUsername, List<String> macroNames) {
        super(LanPacketType.MACRO_LIST, sessionId);
        this.senderUsername = senderUsername;
        this.macroNames = macroNames;
    }

    public LanPacket.MacroListPacket() {
        super(LanPacketType.MACRO_LIST, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeInt(this.macroNames.size());
        var var2 = this.macroNames.iterator();
        while (var2.hasNext()) {
            String name = (String)var2.next();
            out.writeUTF(name);
        }
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        int size = in.readInt();
        this.macroNames.clear();
        for (int i = 0; i < size; i++) {
            this.macroNames.add(in.readUTF());
        }
    }
}
