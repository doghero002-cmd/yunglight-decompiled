/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacketType;

static class LanPacket.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$lan$LanPacketType;

    static {
        $SwitchMap$com$example$addon$util$lan$LanPacketType = new int[LanPacketType.values().length];
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.SEARCH_REQUEST.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.SESSION.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.SESSION.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.JOIN.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.JOIN.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.REQUEST_CLIENT_LIST.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.REQUEST_CLIENT_LIST.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CLIENT_LIST.ordinal()] = 5;
            /* goto @84; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CLIENT_LIST.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.LEAVE.ordinal()] = 6;
            /* goto @100; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.LEAVE.ordinal()] = 6;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.REQUEST_MACRO.ordinal()] = 7;
            /* goto @116; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.REQUEST_MACRO.ordinal()] = 7;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_DATA.ordinal()] = 8;
            /* goto @132; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_DATA.ordinal()] = 8;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_DELETE.ordinal()] = 9;
            /* goto @148; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_DELETE.ordinal()] = 9;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_LIST.ordinal()] = 10;
            /* goto @164; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_LIST.ordinal()] = 10;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.QUEUE_SYNC.ordinal()] = 11;
            /* goto @180; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.QUEUE_SYNC.ordinal()] = 11;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.PRESET_DATA.ordinal()] = 12;
            /* goto @196; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.PRESET_DATA.ordinal()] = 12;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CHAT_MESSAGE.ordinal()] = 13;
            /* goto @212; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CHAT_MESSAGE.ordinal()] = 13;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.TCP_COMMAND_ACK.ordinal()] = 14;
            /* goto @228; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.TCP_COMMAND_ACK.ordinal()] = 14;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.PLAYER_OFFSETS.ordinal()] = 15;
            /* goto @244; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.PLAYER_OFFSETS.ordinal()] = 15;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CLIENT_OFFSET_UPDATE.ordinal()] = 16;
            /* goto @260; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CLIENT_OFFSET_UPDATE.ordinal()] = 16;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.PREPARE_EXECUTION.ordinal()] = 17;
            /* goto @276; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.PREPARE_EXECUTION.ordinal()] = 17;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CLIENT_READY.ordinal()] = 18;
            /* goto @292; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.CLIENT_READY.ordinal()] = 18;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.EXECUTE_NOW.ordinal()] = 19;
            /* goto @308; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.EXECUTE_NOW.ordinal()] = 19;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.GO.ordinal()] = 20;
            /* goto @324; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.GO.ordinal()] = 20;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.HEARTBEAT.ordinal()] = 21;
            /* goto @340; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.HEARTBEAT.ordinal()] = 21;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.SYNC_STATE_UPDATE.ordinal()] = 22;
            /* goto @356; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.SYNC_STATE_UPDATE.ordinal()] = 22;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.REQUEST_SYNC.ordinal()] = 23;
            /* goto @372; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.REQUEST_SYNC.ordinal()] = 23;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.OFFSET_SYNC.ordinal()] = 24;
            /* goto @388; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.OFFSET_SYNC.ordinal()] = 24;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_STEP_PROGRESS.ordinal()] = 25;
            /* goto @404; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_STEP_PROGRESS.ordinal()] = 25;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_DATA_CHUNK.ordinal()] = 26;
            /* goto @420; */
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_DATA_CHUNK.ordinal()] = 26;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_ASSIGNMENT_SYNC.ordinal()] = 27;
            /* goto L436; */
            var0 = null;
            L436: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$lan$LanPacketType[LanPacketType.MACRO_ASSIGNMENT_SYNC.ordinal()] = 27;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
