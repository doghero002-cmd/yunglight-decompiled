/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.GoPacket
extends LanPacket {
    public long executionId;

    public LanPacket.GoPacket(String sessionId, long executionId) {
        super(LanPacketType.GO, sessionId);
        this.executionId = executionId;
    }

    public LanPacket.GoPacket() {
        super(LanPacketType.GO, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(this.executionId);
    }

    public void read(DataInputStream in) throws IOException {
        this.executionId = in.readLong();
    }
}
