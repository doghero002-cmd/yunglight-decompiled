/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public static class LanPacket.ClientListPacket
extends LanPacket {
    public List<LanPacket.ClientListPacket.ClientEntry> clients = new ArrayList();

    public LanPacket.ClientListPacket(String sessionId, List<LanPacket.ClientListPacket.ClientEntry> clients) {
        super(LanPacketType.CLIENT_LIST, sessionId);
        this.clients = clients;
    }

    public LanPacket.ClientListPacket() {
        super(LanPacketType.CLIENT_LIST, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeInt(this.clients.size());
        var var2 = this.clients.iterator();
        while (var2.hasNext()) {
            ClientEntry client = (LanPacket.ClientListPacket.ClientEntry)var2.next();
            out.writeUTF(client.name);
            out.writeBoolean(client.isHost);
        }
    }

    public void read(DataInputStream in) throws IOException {
        int size = in.readInt();
        this.clients.clear();
        for (int i = 0; i < size; i++) {
            this.clients.add(new LanPacket.ClientListPacket.ClientEntry(in.readUTF(), in.readBoolean()));
        }
    }
}
