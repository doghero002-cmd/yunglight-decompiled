/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.HeartbeatPacket
extends LanPacket {
    public String senderUsername;
    public long timestamp;

    public LanPacket.HeartbeatPacket(String sessionId, String senderUsername, long timestamp) {
        super(LanPacketType.HEARTBEAT, sessionId);
        this.senderUsername = senderUsername != null ? senderUsername : "";
        this.timestamp = timestamp;
    }

    public LanPacket.HeartbeatPacket() {
        super(LanPacketType.HEARTBEAT, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.senderUsername);
        out.writeLong(this.timestamp);
    }

    public void read(DataInputStream in) throws IOException {
        this.senderUsername = in.readUTF();
        this.timestamp = in.readLong();
    }
}
