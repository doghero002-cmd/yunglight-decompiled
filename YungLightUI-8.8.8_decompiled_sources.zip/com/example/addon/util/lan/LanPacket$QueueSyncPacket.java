/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.QueueSyncPacket
extends LanPacket {
    public String queueData;
    public String senderUsername;

    public LanPacket.QueueSyncPacket(String sessionId, String queueData, String senderUsername) {
        super(LanPacketType.QUEUE_SYNC, sessionId);
        this.queueData = queueData;
        this.senderUsername = senderUsername;
    }

    public LanPacket.QueueSyncPacket() {
        super(LanPacketType.QUEUE_SYNC, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeUTF(this.queueData);
        out.writeUTF(this.senderUsername);
    }

    public void read(DataInputStream in) throws IOException {
        this.queueData = in.readUTF();
        this.senderUsername = in.readUTF();
    }
}
