/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class LanPacket {
    protected final LanPacketType type;
    protected String sessionId;

    public LanPacket(LanPacketType type, String sessionId) {
        this.type = type;
        this.sessionId = sessionId != null ? sessionId : "";
    }

    public LanPacketType getType() {
        return this.type;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public abstract void write(DataOutputStream var1) throws IOException;

    public abstract void read(DataInputStream var1) throws IOException;

    public static LanPacket create(LanPacketType type, String sessionId) {
        switch (LanPacket.1.$SwitchMap$com$example$addon$util$lan$LanPacketType[type.ordinal()]) {
            case 1::
                return new LanPacket.SearchRequestPacket(sessionId);
            case 2::
                return new LanPacket.SessionPacket(sessionId, 0L, "");
            case 3::
                return new LanPacket.JoinPacket(sessionId, "");
            case 4::
                return new LanPacket.RequestClientListPacket(sessionId);
            case 5::
                return new LanPacket.ClientListPacket(sessionId, new ArrayList());
            case 6::
                return new LanPacket.LeavePacket(sessionId, "");
            case 7::
                return new LanPacket.RequestMacroPacket(sessionId, "");
            case 8::
                return new LanPacket.MacroDataPacket(sessionId, "", "", "", 0);
            case 9::
                return new LanPacket.MacroDeletePacket(sessionId, "", "");
            case 10::
                return new LanPacket.MacroListPacket(sessionId, "", new ArrayList());
            case 11::
                return new LanPacket.QueueSyncPacket(sessionId, "", "");
            case 12::
                return new LanPacket.PresetDataPacket(sessionId, "", "", "");
            case 13::
                return new LanPacket.ChatMessagePacket(sessionId, "", "");
            case 14::
                return new LanPacket.TcpCommandAckPacket(sessionId, "", 0L);
            case 15::
                return new LanPacket.PlayerOffsetsPacket(sessionId, new HashMap());
            case 16::
                return new LanPacket.ClientOffsetUpdatePacket(sessionId, "", "", 0);
            case 17::
                return new LanPacket.PrepareExecutionPacket(sessionId, 0L, false, "", "", "");
            case 18::
                return new LanPacket.ClientReadyPacket(sessionId, 0L, "");
            case 19::
                return new LanPacket.ExecuteNowPacket(sessionId, 0L, 0L);
            case 20::
                return new LanPacket.GoPacket(sessionId, 0L);
            case 21::
                return new LanPacket.HeartbeatPacket(sessionId, "", 0L);
            case 22::
                return new LanPacket.SyncStateUpdatePacket(sessionId, 0, "");
            case 23::
                return new LanPacket.RequestSyncPacket(sessionId, "", false, "", "");
            case 24::
                return new LanPacket.OffsetSyncPacket(sessionId, "", "", 0);
            case 25::
                return new LanPacket.MacroStepProgressPacket(sessionId, "", 0, 0, "");
            case 26::
                return new LanPacket.MacroDataChunkPacket(sessionId, "", "", 0, 0, new byte[0]);
            case 27::
                return new LanPacket.MacroAssignmentSyncPacket(sessionId, "", "");
            default:
                return null;
        }
    }
}
