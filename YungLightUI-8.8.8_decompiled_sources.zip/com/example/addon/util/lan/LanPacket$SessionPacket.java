/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public static class LanPacket.SessionPacket
extends LanPacket {
    public long startTime;
    public String hostName;
    public byte transportType;

    public LanPacket.SessionPacket(String sessionId, long startTime, String hostName, byte transportType) {
        super(LanPacketType.SESSION, sessionId);
        this.startTime = startTime;
        this.hostName = hostName;
        this.transportType = transportType;
    }

    public LanPacket.SessionPacket(String sessionId, long startTime, String hostName) {
        this(sessionId, startTime, hostName, 1);
    }

    public LanPacket.SessionPacket() {
        super(LanPacketType.SESSION, "");
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(this.startTime);
        out.writeUTF(this.hostName);
        out.writeByte(this.transportType);
    }

    public void read(DataInputStream in) throws IOException {
        this.startTime = in.readLong();
        this.hostName = in.readUTF();
        try {
            this.transportType = in.readByte();
        }
        catch (EOFException e) {
            this.transportType = 1;
            L33: ;
            return;
        }
    }
}
