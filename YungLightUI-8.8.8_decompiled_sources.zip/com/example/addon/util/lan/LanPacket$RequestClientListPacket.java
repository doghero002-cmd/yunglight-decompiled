/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.lan.LanPacketType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public static class LanPacket.RequestClientListPacket
extends LanPacket {
    public LanPacket.RequestClientListPacket(String sessionId) {
        super(LanPacketType.REQUEST_CLIENT_LIST, sessionId);
    }

    public LanPacket.RequestClientListPacket() {
        super(LanPacketType.REQUEST_CLIENT_LIST, "");
    }

    public void write(DataOutputStream out) throws IOException {
    }

    public void read(DataInputStream in) throws IOException {
    }
}
