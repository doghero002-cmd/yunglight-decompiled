/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util.lan;

public enum LanPacketType {
    public static final LanPacketType SEARCH_REQUEST = new LanPacketType("SEARCH_REQUEST", 0, 1);
    public static final LanPacketType SESSION = new LanPacketType("SESSION", 1, 2);
    public static final LanPacketType JOIN = new LanPacketType("JOIN", 2, 3);
    public static final LanPacketType REQUEST_CLIENT_LIST = new LanPacketType("REQUEST_CLIENT_LIST", 3, 4);
    public static final LanPacketType CLIENT_LIST = new LanPacketType("CLIENT_LIST", 4, 5);
    public static final LanPacketType LEAVE = new LanPacketType("LEAVE", 5, 6);
    public static final LanPacketType REQUEST_MACRO = new LanPacketType("REQUEST_MACRO", 6, 16);
    public static final LanPacketType MACRO_DATA = new LanPacketType("MACRO_DATA", 7, 17);
    public static final LanPacketType MACRO_DELETE = new LanPacketType("MACRO_DELETE", 8, 23);
    public static final LanPacketType MACRO_LIST = new LanPacketType("MACRO_LIST", 9, 18);
    public static final LanPacketType QUEUE_SYNC = new LanPacketType("QUEUE_SYNC", 10, 19);
    public static final LanPacketType PRESET_DATA = new LanPacketType("PRESET_DATA", 11, 20);
    public static final LanPacketType CHAT_MESSAGE = new LanPacketType("CHAT_MESSAGE", 12, 21);
    public static final LanPacketType TCP_COMMAND_ACK = new LanPacketType("TCP_COMMAND_ACK", 13, 28);
    public static final LanPacketType PLAYER_OFFSETS = new LanPacketType("PLAYER_OFFSETS", 14, 30);
    public static final LanPacketType CLIENT_OFFSET_UPDATE = new LanPacketType("CLIENT_OFFSET_UPDATE", 15, 31);
    public static final LanPacketType PREPARE_EXECUTION = new LanPacketType("PREPARE_EXECUTION", 16, 33);
    public static final LanPacketType CLIENT_READY = new LanPacketType("CLIENT_READY", 17, 34);
    public static final LanPacketType EXECUTE_NOW = new LanPacketType("EXECUTE_NOW", 18, 35);
    public static final LanPacketType GO = new LanPacketType("GO", 19, 40);
    public static final LanPacketType HEARTBEAT = new LanPacketType("HEARTBEAT", 20, 42);
    public static final LanPacketType SYNC_STATE_UPDATE = new LanPacketType("SYNC_STATE_UPDATE", 21, 43);
    public static final LanPacketType REQUEST_SYNC = new LanPacketType("REQUEST_SYNC", 22, 44);
    public static final LanPacketType OFFSET_SYNC = new LanPacketType("OFFSET_SYNC", 23, 45);
    public static final LanPacketType MACRO_STEP_PROGRESS = new LanPacketType("MACRO_STEP_PROGRESS", 24, 46);
    public static final LanPacketType MACRO_DATA_CHUNK = new LanPacketType("MACRO_DATA_CHUNK", 25, 50);
    public static final LanPacketType MACRO_ASSIGNMENT_SYNC = new LanPacketType("MACRO_ASSIGNMENT_SYNC", 26, 51);
    private final int id;
    private static final /* synthetic */ LanPacketType[] $VALUES;

    public static LanPacketType[] values() {
        return (LanPacketType[])$VALUES.clone();
    }

    public static LanPacketType valueOf(String name) {
        return (LanPacketType)Enum.valueOf(LanPacketType.class, name);
    }

    private LanPacketType(int var1) {
        super(var1, var2);
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public static LanPacketType fromId(int id) {
        var var1 = LanPacketType.values();
        var var2 = var1.length;
        for (int var3 = 0; var3 < var2; var3++) {
            LanPacketType type = var1[var3];
            if (type.id != id) continue;
            return type;
        }
        return null;
    }

    static {
        $VALUES = LanPacketType.$values();
    }
}
