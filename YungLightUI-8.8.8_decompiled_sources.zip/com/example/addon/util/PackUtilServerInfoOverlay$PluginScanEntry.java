/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilServerInfoOverlay;
import java.util.Set;
import java.util.TreeSet;

private static final class PackUtilServerInfoOverlay.PluginScanEntry {
    String displayName;
    boolean commandBacked;
    PackUtilServerInfoOverlay.PluginEvidence evidence = PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN;
    final Set<String> commands = new TreeSet(String.CASE_INSENSITIVE_ORDER);

    private PackUtilServerInfoOverlay.PluginScanEntry() {
    }
}
