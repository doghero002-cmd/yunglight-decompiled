/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiFormRow;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiLabel;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiTone;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

private final class PackUtilKeybindOverlay.ToggleRowNode
extends PackUiFormRow {
    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;
    private final String tooltip;
    private final PackUiLabel labelNode;
    private final PackUiButton toggleButton;

    private PackUtilKeybindOverlay.ToggleRowNode(String label, String tooltip, BooleanSupplier getter, Consumer<Boolean> setter) {
        super(new PackUiLabel(label, PackUiTone.BODY).setTrimToBounds(true), new PackUiButton("OFF", PackUiButton.Variant.SECONDARY, null).setPreferredWidth((float)PackUtilKeybindOverlay.this.bindButtonWidth()).setMinWidth((float)PackUtilKeybindOverlay.this.bindButtonWidth()).setMaxWidth((float)PackUtilKeybindOverlay.this.bindButtonWidth()).setHorizontalPadding(PackUtilKeybindOverlay.this.bindButtonPadding()).setButtonHeight(PackUtilKeybindOverlay.this.chooserButtonHeight()).setTextYOffset(0));
        this.getter = getter;
        this.setter = setter;
        this.tooltip = tooltip;
        this.labelNode = (PackUiLabel)this.labelNode();
        this.toggleButton = (PackUiButton)this.controlNode();
        this.toggleButton.setOnPress(this::lambda$new$0 /* captured: setter, getter */);
        this.height = 18f;
        this.growX = true;
        this.setLabelWidth((float)packUtilKeybindOverlay.computeLabelColumnWidth());
        this.setGap(packUtilKeybindOverlay.rowLabelGap());
        this.setAlignControlEnd(true);
        this.setPadding(PackUiInsets.NONE);
    }

    public float preferredWidth(PackUiRenderContext context) {
        return (float)(PackUtilKeybindOverlay.this.panelWidth - PackUtilKeybindOverlay.this.theme.scale(10));
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return (float)PackUtilKeybindOverlay.this.rowHeight();
    }

    public void render(PackUiRenderContext context) {
        boolean on = this.getter.getAsBoolean();
        this.toggleButton.setText(on ? "ON" : "OFF");
        this.toggleButton.setVariant(on ? PackUiButton.Variant.SUCCESS : PackUiButton.Variant.SECONDARY);
        super.render(context);
        if (this.labelNode.contains(context.mouseX(), context.mouseY())) {
            PackUtilKeybindOverlay.this.hoveredTooltip = this.tooltip;
            PackUtilKeybindOverlay.this.tooltipUiX = context.mouseX() + (float)PackUtilKeybindOverlay.this.tooltipOffsetX();
            PackUtilKeybindOverlay.this.tooltipUiY = context.mouseY() - (float)PackUtilKeybindOverlay.this.tooltipOffsetY();
        }
    }
}
