/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilMacroEditorOverlay;

private static final class PackUtilMacroEditorOverlay.StepPickerButtonLayout {
    private final PackUtilMacroEditorOverlay.StepPickerEntry entry;
    private final int x;
    private final int y;
    private final int width;
    private final int height;

    private PackUtilMacroEditorOverlay.StepPickerButtonLayout(PackUtilMacroEditorOverlay.StepPickerEntry entry, int x, int y, int width, int height) {
        this.entry = entry;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
}
