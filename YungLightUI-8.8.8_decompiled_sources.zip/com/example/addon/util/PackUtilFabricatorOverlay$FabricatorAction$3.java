/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilFabricatorOverlay;

final class PackUtilFabricatorOverlay.FabricatorAction.3
extends PackUtilFabricatorOverlay.FabricatorAction {
    PackUtilDropAction toPacketAction(boolean dropWholeStack) {
        return PackUtilDropAction.PICKUP_ALL;
    }
}
