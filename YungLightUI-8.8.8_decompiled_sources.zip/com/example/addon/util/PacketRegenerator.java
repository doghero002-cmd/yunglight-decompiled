/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_2811;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_310;

public class PacketRegenerator {
    private static final Map<Class<? extends class_2596<?>>, PacketRegenerator.PacketHandler<?>> handlers = new HashMap();

    public static <T extends class_2596<?>> T regenerate(T original) {
        if (original == null) {
            return null;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return original;
        }
        PacketRegenerator.PacketHandler<T> handler = (PacketRegenerator.PacketHandler)handlers.get(original.getClass());
        try {
            T result = handler.regenerate(original, mc);
            return result;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to regenerate {}: {}", original.getClass().getSimpleName(), e.getMessage());
            return original;
        }
        return original;
    }

    private static void registerAllHandlers() {
        PacketRegenerator.register(class_2846.class, PacketRegenerator::lambda$registerAllHandlers$0);
        PacketRegenerator.register(class_2885.class, PacketRegenerator::lambda$registerAllHandlers$1);
        PacketRegenerator.register(class_2813.class, PacketRegenerator::lambda$registerAllHandlers$2);
        PacketRegenerator.register(class_2811.class, PacketRegenerator::lambda$registerAllHandlers$3);
        PacketRegenerator.register(class_2886.class, PacketRegenerator::lambda$registerAllHandlers$4);
        PacketRegenerator.register(class_2828.class_2830.class, PacketRegenerator::lambda$registerAllHandlers$5);
        PacketRegenerator.register(class_2828.class_2829.class, PacketRegenerator::lambda$registerAllHandlers$6);
        PacketRegenerator.register(class_2828.class_2831.class, PacketRegenerator::lambda$registerAllHandlers$7);
        PacketRegenerator.register(class_2828.class_5911.class, PacketRegenerator::lambda$registerAllHandlers$8);
        PacketRegenerator.register(class_2824.class, PacketRegenerator::lambda$registerAllHandlers$10);
        PacketRegenerator.register(class_2868.class, PacketRegenerator::lambda$registerAllHandlers$11);
        PacketRegenerator.register(class_2815.class, PacketRegenerator::lambda$registerAllHandlers$12);
        PacketRegenerator.register(class_2797.class, PacketRegenerator::lambda$registerAllHandlers$13);
    }

    private static <T extends class_2596<?>> void register(Class<T> clazz, PacketRegenerator.PacketHandler<T> handler) {
        handlers.put(clazz, handler);
    }

    private static int getFieldInt(Object obj, String hint, Class<?> type, int index) {
        try {
            Field field = PacketRegenerator.findField(obj.getClass(), type, index);
            if (type == Byte.TYPE) {
                return field.getByte(obj);
            }
        }
        catch (Exception e) {
            return 0;
        }
        try {
            if (type == Short.TYPE) {
                return field.getShort(obj);
            }
        }
        catch (Exception e) {
            return 0;
        }
        try {
            return field.getInt(obj);
        }
        catch (Exception e) {
            return 0;
        }
    }

    private static void setFieldInt(Object obj, String hint, Class<?> type, int index, int value) throws Exception {
        Field field = PacketRegenerator.findField(obj.getClass(), type, index);
        field.setInt(obj, value);
    }

    private static String getFieldString(Object obj, String hint, int index) {
        try {
            Field field = PacketRegenerator.findField(obj.getClass(), String.class, index);
            return (String)field.get(obj);
        }
        catch (Exception e) {
            return null;
        }
    }

    private static <E extends Enum<E>> E getFieldEnum(Object obj, Class<E> enumClass) {
        try {
            Field field = PacketRegenerator.findField(obj.getClass(), enumClass, 0);
            return (Enum)field.get(obj);
        }
        catch (Exception e) {
            return null;
        }
    }

    private static Field findField(Class<?> clazz, Class<?> type, int index) throws NoSuchFieldException {
        List<Field> matches = new ArrayList();
        Class<?> current = clazz;
        while (current != null) {
            if (current == Object.class) break;
            Field f = current.getDeclaredFields();
            var var6 = f.length;
            for (int var7 = 0; var7 < var6; var7++) {
                Field f = f[var7];
                if (!f.getType().equals(type)) continue;
                matches.add(f);
            }
            current = current.getSuperclass();
        }
        f = (Field)matches.get(index);
        if (index >= 0 && index < matches.size()) {
            f.setAccessible(true);
            return f;
        }
        throw new NoSuchFieldException("Field of type " + type.getName() + " at index " + index + " not found");
    }

    static {
        PacketRegenerator.registerAllHandlers();
    }
}
