/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilContainerTarget.Kind {
    public static final PackUtilContainerTarget.Kind BLOCK = new PackUtilContainerTarget.Kind("BLOCK", 0);
    public static final PackUtilContainerTarget.Kind ENTITY_INTERACT = new PackUtilContainerTarget.Kind("ENTITY_INTERACT", 1);
    public static final PackUtilContainerTarget.Kind ENTITY_INTERACT_AT = new PackUtilContainerTarget.Kind("ENTITY_INTERACT_AT", 2);
    private static final /* synthetic */ PackUtilContainerTarget.Kind[] $VALUES;

    public static PackUtilContainerTarget.Kind[] values() {
        return (PackUtilContainerTarget.Kind[])$VALUES.clone();
    }

    public static PackUtilContainerTarget.Kind valueOf(String name) {
        return (PackUtilContainerTarget.Kind)Enum.valueOf(PackUtilContainerTarget.Kind.class, name);
    }

    private PackUtilContainerTarget.Kind() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilContainerTarget.Kind.$values();
    }
}
