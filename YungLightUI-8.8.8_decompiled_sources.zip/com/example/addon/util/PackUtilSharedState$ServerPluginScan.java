/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public static final class PackUtilSharedState.ServerPluginScan {
    private final String address;
    private final String contextSignature;
    private final List<String> plugins;
    private final Map<String, List<String>> pluginCommands;
    private final Map<String, String> pluginEvidence;

    private PackUtilSharedState.ServerPluginScan(String address, String contextSignature, List<String> plugins, Map<String, List<String>> pluginCommands, Map<String, String> pluginEvidence) {
        this.address = address;
        this.contextSignature = contextSignature == null ? "" : contextSignature;
        this.plugins = plugins == null ? List.of() : new ArrayList(plugins);
        this.pluginCommands = PackUtilSharedState.ServerPluginScan.copyPluginCommands(pluginCommands);
        this.pluginEvidence = PackUtilSharedState.ServerPluginScan.copyPluginEvidence(pluginEvidence);
    }

    public String getAddress() {
        return this.address;
    }

    public List<String> getPlugins() {
        return new ArrayList(this.plugins);
    }

    public String getContextSignature() {
        return this.contextSignature;
    }

    public Map<String, List<String>> getPluginCommands() {
        return PackUtilSharedState.ServerPluginScan.copyPluginCommands(this.pluginCommands);
    }

    public Map<String, String> getPluginEvidence() {
        return PackUtilSharedState.ServerPluginScan.copyPluginEvidence(this.pluginEvidence);
    }

    private PackUtilSharedState.ServerPluginScan copy() {
        return new PackUtilSharedState.ServerPluginScan(this.address, this.contextSignature, this.plugins, this.pluginCommands, this.pluginEvidence);
    }

    private static Map<String, List<String>> copyPluginCommands(Map<String, List<String>> source) {
        if (source == null || source.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<String, List<String>> copy = new LinkedHashMap();
        var var2 = source.entrySet().iterator();
        while (var2.hasNext()) {
            Map.Entry<String, List<String>> entry = (Map.Entry)var2.next();
            while (entry.getKey() == null) {
            }
            copy.put((String)entry.getKey(), entry.getValue() == null ? List.of() : new ArrayList((Collection)entry.getValue()));
        }
        return copy;
    }

    private static Map<String, String> copyPluginEvidence(Map<String, String> source) {
        if (source == null || source.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<String, String> copy = new LinkedHashMap();
        var var2 = source.entrySet().iterator();
        while (var2.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var2.next();
            if (entry.getKey() == null) continue;
            while (((String)entry.getKey()).isBlank()) {
            }
            copy.put((String)entry.getKey(), entry.getValue() == null ? "" : (String)entry.getValue());
        }
        return copy;
    }
}
