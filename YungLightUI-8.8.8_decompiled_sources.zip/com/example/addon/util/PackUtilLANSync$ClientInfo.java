/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static class PackUtilLANSync.ClientInfo {
    public String username;
    public boolean isHost;
    public long lastSeen;
    public int delayOffsetMs;

    PackUtilLANSync.ClientInfo(String username, boolean isHost) {
        this.username = username;
        this.isHost = isHost;
        this.lastSeen = System.currentTimeMillis();
        this.delayOffsetMs = 0;
    }
}
