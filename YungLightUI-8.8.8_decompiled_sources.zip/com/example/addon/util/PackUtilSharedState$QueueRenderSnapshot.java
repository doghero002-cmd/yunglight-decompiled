/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilSharedState;
import java.util.List;

public static final record PackUtilSharedState.QueueRenderSnapshot {
    private final List<PackUtilSharedState.QueuedPacket> packets;
    private final int totalCount;

    public PackUtilSharedState.QueueRenderSnapshot(List<PackUtilSharedState.QueuedPacket> packets, int totalCount) {
        this.packets = packets;
        this.totalCount = totalCount;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public List<PackUtilSharedState.QueuedPacket> packets() {
        return this.packets;
    }

    public int totalCount() {
        return this.totalCount;
    }
}
