/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilMacroEditorOverlay.StepPickerMode {
    public static final PackUtilMacroEditorOverlay.StepPickerMode ACTION = new PackUtilMacroEditorOverlay.StepPickerMode("ACTION", 0);
    public static final PackUtilMacroEditorOverlay.StepPickerMode CONDITIONAL = new PackUtilMacroEditorOverlay.StepPickerMode("CONDITIONAL", 1);
    private static final /* synthetic */ PackUtilMacroEditorOverlay.StepPickerMode[] $VALUES;

    public static PackUtilMacroEditorOverlay.StepPickerMode[] values() {
        return (PackUtilMacroEditorOverlay.StepPickerMode[])$VALUES.clone();
    }

    public static PackUtilMacroEditorOverlay.StepPickerMode valueOf(String name) {
        return (PackUtilMacroEditorOverlay.StepPickerMode)Enum.valueOf(PackUtilMacroEditorOverlay.StepPickerMode.class, name);
    }

    private PackUtilMacroEditorOverlay.StepPickerMode() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilMacroEditorOverlay.StepPickerMode.$values();
    }
}
