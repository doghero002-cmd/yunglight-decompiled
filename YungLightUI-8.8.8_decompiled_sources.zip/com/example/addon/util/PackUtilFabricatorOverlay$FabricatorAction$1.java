/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilFabricatorOverlay;

final class PackUtilFabricatorOverlay.FabricatorAction.1
extends PackUtilFabricatorOverlay.FabricatorAction {
    boolean usesClickSelector() {
        return true;
    }

    PackUtilDropAction toPacketAction(boolean dropWholeStack) {
        return PackUtilDropAction.PICKUP;
    }
}
