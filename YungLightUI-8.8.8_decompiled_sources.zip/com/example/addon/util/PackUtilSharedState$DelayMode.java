/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilSharedState.DelayMode {
    public static final PackUtilSharedState.DelayMode TICKS = new PackUtilSharedState.DelayMode("TICKS", 0);
    public static final PackUtilSharedState.DelayMode MS = new PackUtilSharedState.DelayMode("MS", 1);
    private static final /* synthetic */ PackUtilSharedState.DelayMode[] $VALUES;

    public static PackUtilSharedState.DelayMode[] values() {
        return (PackUtilSharedState.DelayMode[])$VALUES.clone();
    }

    public static PackUtilSharedState.DelayMode valueOf(String name) {
        return (PackUtilSharedState.DelayMode)Enum.valueOf(PackUtilSharedState.DelayMode.class, name);
    }

    private PackUtilSharedState.DelayMode() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilSharedState.DelayMode.$values();
    }
}
