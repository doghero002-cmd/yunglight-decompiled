/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_7923;

public final class PackUtilContainerTarget {
    private final PackUtilContainerTarget.Kind kind;
    private final class_2338 blockPos;
    private final String entityRef;
    private final class_1268 hand;
    private final class_243 hitPos;

    private PackUtilContainerTarget(PackUtilContainerTarget.Kind kind, class_2338 blockPos, String entityRef, class_1268 hand, class_243 hitPos) {
        this.kind = kind;
        this.blockPos = blockPos == null ? null : blockPos.method_10062();
        this.entityRef = entityRef == null ? "" : entityRef;
        this.hand = hand == null ? class_1268.field_5808 : hand;
        this.hitPos = hitPos;
    }

    public static PackUtilContainerTarget forBlock(class_2338 pos) {
        if (pos == null) {
            return null;
        }
        return new PackUtilContainerTarget(PackUtilContainerTarget.Kind.BLOCK, pos, "", class_1268.field_5808, null);
    }

    public static PackUtilContainerTarget forEntity(class_1297 entity, class_1268 hand) {
        if (entity == null) {
            return null;
        }
        return new PackUtilContainerTarget(PackUtilContainerTarget.Kind.ENTITY_INTERACT, null, PackUtilContainerTarget.toSpecificEntityRef(entity), hand, null);
    }

    public static PackUtilContainerTarget forEntityAt(class_1297 entity, class_1268 hand, class_243 hitPos) {
        if (entity == null) {
            return null;
        }
        return new PackUtilContainerTarget(PackUtilContainerTarget.Kind.ENTITY_INTERACT_AT, null, PackUtilContainerTarget.toSpecificEntityRef(entity), hand, hitPos);
    }

    public static PackUtilContainerTarget forEntityRef(String entityRef) {
        if (entityRef == null || entityRef.isBlank()) {
            return null;
        }
        return new PackUtilContainerTarget(PackUtilContainerTarget.Kind.ENTITY_INTERACT, null, entityRef.trim(), class_1268.field_5808, null);
    }

    public static String toSpecificEntityRef(class_1297 entity) {
        if (entity == null) {
            return "";
        }
        String uuid = entity.method_5845();
        String typeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
        String displayName = entity.method_5476().getString().replaceAll("§.", "").trim();
        return "~" + uuid + "~" + typeId + "~" + displayName;
    }

    public PackUtilContainerTarget.Kind kind() {
        return this.kind;
    }

    public class_2338 blockPos() {
        return this.blockPos;
    }

    public String entityRef() {
        return this.entityRef;
    }

    public boolean isBlock() {
        return this.kind == PackUtilContainerTarget.Kind.BLOCK;
    }

    public boolean interact(class_310 mc) {
        if (mc == null || mc.method_1562() == null) {
            return false;
        }
        if (this.kind == PackUtilContainerTarget.Kind.BLOCK) {
            if (this.blockPos == null) {
                return false;
            }
            class_243 hitVec = class_243.method_24953(this.blockPos);
            class_3965 hitResult = new class_3965(hitVec, class_2350.field_11036, this.blockPos, false);
            mc.method_1562().method_52787(new class_2885(this.hand, hitResult, 0));
            return true;
        }
        entity = this.resolveEntity(mc);
        if (entity == null) {
            return false;
        }
        mc.method_1562().method_52787(class_2824.method_34208(entity, mc.field_1724.method_5715(), this.hand, this.hitPos));
        if (this.kind == PackUtilContainerTarget.Kind.ENTITY_INTERACT_AT && this.hitPos != null) {
            return true;
        }
        mc.method_1562().method_52787(class_2824.method_34207(entity, mc.field_1724.method_5715(), this.hand));
        return true;
    }

    private class_1297 resolveEntity(class_310 mc) {
        if (mc == null || mc.field_1687 == null) {
            return null;
        }
        String uuid = "";
        String typeId = this.entityRef;
        if (!this.entityRef.startsWith("~")) { /* goto L79; */ }
        String[] parts = this.entityRef.split("~", 4);
        uuid = parts.length >= 2 ? parts[1] : "";
        typeId = parts.length >= 3 ? parts[2] : "";
        nearestTypeMatch = null;
        double nearestDistance = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        var var7 = mc.field_1687.method_18112().iterator();
        while (var7.hasNext()) {
            class_1297 entity = (class_1297)var7.next();
            while (entity == null) {
            }
            if (uuid.isEmpty() && uuid.equals(entity.method_5845())) continue;
            return entity;
            while (typeId.isBlank()) {
            }
            String entityTypeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
            while (!typeId.equalsIgnoreCase(entityTypeId)) {
            }
            double distance = mc.field_1724 == null ? 0 : entity.method_5858(mc.field_1724);
            while (distance >= nearestDistance) {
            }
            nearestDistance = distance;
            nearestTypeMatch = entity;
        }
        return nearestTypeMatch;
    }
}
