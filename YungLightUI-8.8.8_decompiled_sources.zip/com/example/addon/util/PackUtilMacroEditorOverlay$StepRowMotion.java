/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilMacroEditorOverlay;

private static final class PackUtilMacroEditorOverlay.StepRowMotion {
    private final int stableId;
    private final String label;
    private final boolean conditional;
    private final int fromRowIndex;
    private final int toRowIndex;
    private final PackUtilMacroEditorOverlay.StepRowMotionKind kind;
    private float progress;

    private PackUtilMacroEditorOverlay.StepRowMotion(int stableId, String label, boolean conditional, int fromRowIndex, int toRowIndex, PackUtilMacroEditorOverlay.StepRowMotionKind kind) {
        this.stableId = stableId;
        this.label = label;
        this.conditional = conditional;
        this.fromRowIndex = fromRowIndex;
        this.toRowIndex = toRowIndex;
        this.kind = kind;
    }
}
