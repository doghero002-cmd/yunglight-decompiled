/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.util.MeteorMacroAdapter;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilClipboardHelper;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroManager;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.lan.LanPacket;
import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.MacroExecutor;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_310;

public class PackUtilLANSync {
    private static PackUtilLANSync instance;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private String sessionId;
    private boolean isHost = false;
    private String myUsername = "";
    private final Map<String, PackUtilLANSync.ClientInfo> connectedClients = new ConcurrentHashMap();
    private final Map<String, String> discoveredSessions = new ConcurrentHashMap();
    private final Set<String> clientsReady = ConcurrentHashMap.newKeySet();
    private volatile boolean isSearching = false;
    private int searchTicksRemaining = 0;
    private static final int SEARCH_DURATION_TICKS = 400;
    private static final int SEARCH_BROADCAST_INTERVAL = 5;
    private Runnable onClientJoined;
    private Runnable onClientLeft;
    private Runnable onCountdown;
    private Runnable onSendNow;
    private Runnable onSessionStateChanged;
    private Runnable onSyncStateChanged;
    private Runnable onSpreadCalculated;
    private Runnable onPeerStatusChanged;
    private volatile ConcurrentHashMap<String, Map<String, PackUtilMacro>> clientMacroLists = new ConcurrentHashMap();
    private volatile ConcurrentHashMap<String, Map<String, PackUtilMacro>> remoteMeteorMacros = new ConcurrentHashMap();
    private Map<String, String> lastBroadcastMeteorMacros = new ConcurrentHashMap();
    private volatile Map<String, String> syncedAssignments = new ConcurrentHashMap();
    private volatile String assignmentSetBy = "";
    private Runnable onAssignmentsChanged;
    private volatile PackUtilLANSync.SpreadResult lastSpreadResult = null;
    private final CopyOnWriteArrayList<PackUtilLANSync.SpreadResult> spreadHistory = new CopyOnWriteArrayList();
    private static final int MAX_SPREAD_HISTORY = 10;
    private volatile PackUtilLANSync.SyncContext activeSyncCtx = null;
    private volatile PackUtilLANSync.SyncState syncState = PackUtilLANSync.SyncState.IDLE;
    private final Map<String, Long> executionTimestamps = new ConcurrentHashMap();
    private final Map<String, Long> ackReceiptTimes = new ConcurrentHashMap();
    private final Map<String, Integer> peerStepProgress = new ConcurrentHashMap();
    private volatile Runnable onStepProgressChanged;
    private static final int TCP_PORT = 25568;
    private ServerSocket tcpServer;
    private Thread tcpAcceptThread;
    private final Map<String, Socket> tcpClients = new ConcurrentHashMap();
    private Socket tcpHostSocket;
    private Thread tcpReadThread;
    private final Object tcpHostWriteLock = new Object();
    private final Map<String, Object> tcpClientWriteLocks = new ConcurrentHashMap();
    private final Map<String, Long> lastHeartbeatTime = new ConcurrentHashMap();
    private long lastHeartbeatSentMs = 0L;
    private static final long HEARTBEAT_INTERVAL_MS = 9000L;
    private static final long HEARTBEAT_STALE_MS = 15000L;
    private static final long HEARTBEAT_DEAD_MS = 30000L;
    private volatile boolean reconnecting = false;
    private volatile String lastHostIp = null;
    private volatile String lastSessionId = null;

    private PackUtilLANSync() {
    }

    public static PackUtilLANSync getInstance() {
        if (instance == null) {
            instance = new PackUtilLANSync();
        }
        return instance;
    }

    public void start() {
        if (this.running.get()) {
            return;
        }
        this.running.set(true);
        PackUtilClientMessaging.sendPrefixed("§aLAN Sync started (TCP mode on port 25568).");
        YungLightAddon.LOG.info("[PackUtil-LAN] Started in TCP-only mode on port {}", 25568);
    }

    public void stop() {
        if (!this.running.get()) {
            return;
        }
        if (this.sessionId != null) {
            this.leaveSession();
        }
        this.running.set(false);
        this.clearSession();
        this.discoveredSessions.clear();
        PackUtilClientMessaging.sendPrefixed("§eLAN Sync stopped.");
    }

    public void createSession() {
        if (!this.running.get()) {
            PackUtilClientMessaging.sendPrefixed("§cStart LAN Sync first.");
            return;
        }
        this.cancelSearch();
        this.discoveredSessions.clear();
        if (this.sessionId != null) {
            this.leaveSession();
        }
        this.stopTcp();
        this.sessionId = this.generateSessionId();
        this.isHost = true;
        this.myUsername = this.getUsername();
        if (this.myUsername.isEmpty()) {
            this.myUsername = "Host";
        }
        this.connectedClients.put(this.myUsername, new PackUtilLANSync.ClientInfo(this.myUsername, true));
        this.resetSyncState();
        this.startTcpServer();
        PackUtilClientMessaging.sendPrefixed("§aSession created: " + this.sessionId + " [TCP Sync]");
        this.fireCallback(this.onSessionStateChanged);
    }

    public void joinSession(String targetSessionId) {
        this.joinSession(targetSessionId, "127.0.0.1");
    }

    public void joinSession(String targetSessionId, String hostIp) {
        if (!this.running.get()) {
            PackUtilClientMessaging.sendPrefixed("§cStart LAN Sync first.");
            return;
        }
        PackUtilClientMessaging.sendPrefixed("§cAlready in session " + this.sessionId);
        if (this.sessionId != null && this.sessionId.equals(targetSessionId)) {
            return;
        }
        this.cancelSearch();
        this.discoveredSessions.clear();
        if (this.sessionId != null) {
            this.leaveSession();
        }
        this.stopTcp();
        this.sessionId = targetSessionId;
        this.lastSessionId = targetSessionId;
        this.isHost = false;
        this.myUsername = this.getUsername();
        if (this.myUsername.isEmpty()) {
            this.myUsername = "Player";
        }
        this.connectedClients.put(this.myUsername, new PackUtilLANSync.ClientInfo(this.myUsername, false));
        this.resetSyncState();
        this.lastHostIp = hostIp != null && !hostIp.isBlank() ? hostIp : "127.0.0.1";
        this.connectToTcpServer(this.lastHostIp);
        YungLightAddon.LOG.info("[TCP] Connecting to {}:{}", this.lastHostIp, 25568);
        this.fireCallback(this.onClientJoined);
        this.fireCallback(this.onSessionStateChanged);
    }

    public void leaveSession() {
        if (this.sessionId == null) {
            return;
        }
        this.reconnecting = false;
        this.lastHostIp = null;
        this.lastSessionId = null;
        this.sendTcpPacket(new LanPacket.LeavePacket(this.sessionId, this.getUsername()));
        this.clearSession();
        PackUtilClientMessaging.sendPrefixed("§eLeft session.");
        this.fireCallback(this.onSessionStateChanged);
    }

    private void clearSession() {
        this.sessionId = null;
        this.isHost = false;
        this.myUsername = "";
        this.reconnecting = false;
        this.lastHostIp = null;
        this.lastSessionId = null;
        this.connectedClients.clear();
        this.clientMacroLists.clear();
        this.remoteMeteorMacros.clear();
        this.lastBroadcastMeteorMacros.clear();
        this.syncedAssignments.clear();
        this.assignmentSetBy = "";
        this.isSearching = false;
        this.searchTicksRemaining = 0;
        this.lastSpreadResult = null;
        this.resetSyncState();
        this.lastHeartbeatTime.clear();
        this.stopTcp();
    }

    private void resetSyncState() {
        this.activeSyncCtx = null;
        this.setSyncState(PackUtilLANSync.SyncState.IDLE);
        this.executionTimestamps.clear();
        this.ackReceiptTimes.clear();
        this.clientsReady.clear();
        this.peerStepProgress.clear();
    }

    private void setSyncState(PackUtilLANSync.SyncState state) {
        this.syncState = state;
        this.fireCallback(this.onSyncStateChanged);
    }

    private void initiateGoSync(boolean isMacro, String macroName, String command) {
        this.initiateGoSync(isMacro, macroName, command, null);
    }

    private void initiateGoSync(boolean isMacro, String macroName, String command, Map<String, String> macroAssignments) {
        long executionId = System.nanoTime();
        if (!isMacro) { /* goto L104; */ }
        if (macroAssignments != null) {
            if (!macroAssignments.isEmpty()) {
                Map<String, String> missingAssignments = this.getMissingAssignedMacros(macroAssignments);
                if (!missingAssignments.isEmpty()) {
                    PackUtilClientMessaging.sendPrefixed("§cMissing assigned macros on: " + this.summarizeAssignments(missingAssignments));
                    return;
                }
            }
        } else {
            if (macroName != null) {
                if (!macroName.isBlank()) {
                    List<String> missingPeers = this.getPeersMissingMacro(macroName);
                    if (!missingPeers.isEmpty()) {
                        PackUtilClientMessaging.sendPrefixed("§cMissing '" + macroName + "' on: " + this.summarizeNames(missingPeers));
                        return;
                    }
                }
            }
        }
        myMacroName = macroName;
        if (macroAssignments != null) {
            if (macroAssignments.containsKey(this.myUsername)) {
                myMacroName = (String)macroAssignments.get(this.myUsername);
            }
        }
        PackUtilMacro macro = null;
        if (!isMacro) { /* goto L188; */ }
        if (myMacroName == null) { /* goto L188; */ }
        macro = PackUtilMacroManager.get().get(myMacroName);
        if (macro != null) {
            macro.regenerateAllPackets();
        } else {
            PackUtilClientMessaging.sendPrefixed("§cMacro not found: " + myMacroName);
            return;
        }
        this.activeSyncCtx = new PackUtilLANSync.SyncContext(executionId, isMacro, myMacroName, command, macro, true);
        this.clientsReady.clear();
        this.executionTimestamps.clear();
        this.ackReceiptTimes.clear();
        this.peerStepProgress.clear();
        this.clientsReady.add(this.myUsername);
        this.setSyncState(PackUtilLANSync.SyncState.PREPARING);
        YungLightAddon.LOG.info("[Sync] Initiating GO-sync: execId={}", executionId);
        String assignmentStr = "";
        if (macroAssignments == null) { /* goto L405; */ }
        if (macroAssignments.isEmpty()) { /* goto L405; */ }
        StringBuilder sb = new StringBuilder();
        var var11 = macroAssignments.entrySet().iterator();
        while (var11.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var11.next();
            if (!sb.length() > 0) continue;
            sb.append(9);
            sb.append((String)entry.getKey()).append(9).append((String)entry.getValue());
        }
        assignmentStr = sb.toString();
        L405: ;
        preparePacket = new LanPacket.PrepareExecutionPacket(this.sessionId, executionId, isMacro, macroName != null ? macroName : "", command, this.myUsername);
        preparePacket.macroAssignments = assignmentStr;
        this.sendTcpPacket(preparePacket);
        this.broadcastSyncState(PackUtilLANSync.SyncState.PREPARING, this.clientsReady.size() + "/" + this.connectedClients.size() + " ready");
        new Thread(this::lambda$initiateGoSync$1 /* captured: executionId */, "Sync-GO-Initiator").start();
    }

    private void initiateGoSyncForQueue() {
        long executionId = System.nanoTime();
        this.activeSyncCtx = new PackUtilLANSync.SyncContext(executionId, false, null, "__QUEUE_FLUSH__", null, true);
        this.clientsReady.clear();
        this.executionTimestamps.clear();
        this.ackReceiptTimes.clear();
        this.clientsReady.add(this.myUsername);
        this.setSyncState(PackUtilLANSync.SyncState.PREPARING);
        YungLightAddon.LOG.info("[Sync] Initiating queue flush GO-sync: execId={}", executionId);
        this.sendTcpPacket(new LanPacket.PrepareExecutionPacket(this.sessionId, executionId, false, "", "__QUEUE_FLUSH__", this.myUsername));
        this.broadcastSyncState(PackUtilLANSync.SyncState.PREPARING, this.clientsReady.size() + "/" + this.connectedClients.size() + " ready");
        new Thread(this::lambda$initiateGoSyncForQueue$3 /* captured: executionId */, "Sync-GO-QueueFlush").start();
    }

    private void handlePrepare(long executionId, boolean isMacro, String macroName, String command, String senderUsername, String macroAssignments) {
        if (senderUsername != null && senderUsername.equals(this.myUsername)) {
            return;
        }
        YungLightAddon.LOG.info("[Sync] Received PREPARE from {}", senderUsername);
        this.peerStepProgress.clear();
        String myMacroName = macroName;
        if (macroAssignments == null) { /* goto L113; */ }
        if (macroAssignments.isEmpty()) { /* goto L113; */ }
        String[] parts = macroAssignments.split("\t");
        int pi = 0;
        while (pi + 1 < parts.length) {
            if (parts[pi].equals(this.myUsername)) {
                myMacroName = parts[pi + 1];
            } else {
                pi += 2;
            }
        }
        macro = null;
        if (isMacro) {
            if (myMacroName != null) {
                if (!myMacroName.isEmpty()) {
                    macro = PackUtilMacroManager.get().get(myMacroName);
                    if (macro != null) {
                        macro.regenerateAllPackets();
                    }
                }
            }
        } else {
            if ("__QUEUE_FLUSH__".equals(command)) {
                PackUtilSharedState.get().regenerateQueue();
            }
        }
        this.activeSyncCtx = new PackUtilLANSync.SyncContext(executionId, isMacro, myMacroName, command, macro, false);
        this.setSyncState(PackUtilLANSync.SyncState.PREPARING);
        this.sendTcpPacket(new LanPacket.ClientReadyPacket(this.sessionId, executionId, this.myUsername));
        YungLightAddon.LOG.info("[Sync] Sent READY signal");
    }

    private void handleClientReady(long executionId, String username) {
        SyncContext ctx = this.activeSyncCtx;
        this.clientsReady.add(username);
        if (ctx != null && executionId == ctx.executionId) {
            this.broadcastSyncState(PackUtilLANSync.SyncState.PREPARING, this.clientsReady.size() + "/" + this.connectedClients.size() + " ready");
            YungLightAddon.LOG.info("[Sync] Client ready: {} (total: {})", username, this.clientsReady.size());
        }
    }

    private void handleGo(long executionId) {
        SyncContext ctx = this.activeSyncCtx;
        if (ctx == null || executionId != ctx.executionId) {
            YungLightAddon.LOG.warn("[Sync] GO for wrong execId, ignoring");
            return;
        }
        if (ctx.isInitiator) {
            return;
        }
        int offset = this.getPlayerDelayOffset(this.myUsername);
        if (offset > 0) {
            YungLightAddon.LOG.info("[Sync] Received GO! Applying {}ms offset before executing.", offset);
            this.setSyncState(PackUtilLANSync.SyncState.EXECUTING);
        }
        try {
            Thread.sleep((long)offset);
        }
        catch (InterruptedException e5) {
            this.executeAction();
            /* goto L116; */
            L94: ;
            YungLightAddon.LOG.info("[Sync] Received GO! Executing immediately.");
            this.setSyncState(PackUtilLANSync.SyncState.EXECUTING);
            this.executeAction();
            L116: ;
            return;
        }
        this.executeAction();
        /* goto L116; */
        L94: ;
        YungLightAddon.LOG.info("[Sync] Received GO! Executing immediately.");
        this.setSyncState(PackUtilLANSync.SyncState.EXECUTING);
        this.executeAction();
        L116: ;
    }

    private void executeAction() {
        long executedAtMs = System.currentTimeMillis();
        SyncContext ctx = this.activeSyncCtx;
        if (ctx == null) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if ("__QUEUE_FLUSH__".equals(ctx.command)) {
            mc.execute(PackUtilLANSync::lambda$executeAction$4 /* captured: mc */);
        } else {
            if (ctx.command != null) {
                if (ctx.command.startsWith("__CHAT__\t")) {
                    String chatMsg = ctx.command.substring("__CHAT__\t".length());
                    mc.execute(PackUtilLANSync::lambda$executeAction$5 /* captured: mc, chatMsg */);
                }
            } else {
                if (ctx.isMacro) {
                    if (ctx.macro != null) {
                        mc.execute(PackUtilLANSync::lambda$executeAction$6 /* captured: ctx */);
                    }
                }
            }
        }
        YungLightAddon.LOG.info("[Sync] EXECUTED at {}", executedAtMs);
        this.executionTimestamps.put(this.myUsername, executedAtMs);
        this.sendTcpPacket(new LanPacket.TcpCommandAckPacket(this.sessionId, this.myUsername, executedAtMs));
        this.setSyncState(PackUtilLANSync.SyncState.REPORTING);
        if (ctx.isInitiator) {
            new Thread(this::lambda$executeAction$7, "Sync-SpreadCalc").start();
        }
    }

    private void handleExecutionTimestamp(String username, long timestampMs) {
        this.executionTimestamps.put(username, timestampMs);
        this.ackReceiptTimes.put(username, System.nanoTime());
        YungLightAddon.LOG.info("[Sync] ACK from {}: remoteMs={}, hostReceiptNano={}", username, timestampMs, this.ackReceiptTimes.get(username));
    }

    private void calculateAndDisplaySpread() {
        Map<String, Long> timings = this.ackReceiptTimes.isEmpty() ? this.executionTimestamps : this.ackReceiptTimes;
        if (timings.size() < 2) {
            this.setSyncState(PackUtilLANSync.SyncState.DONE);
            return;
        }
        long earliest = 9223372036854775807L;
        long latest = -9223372036854775808L;
        String earliestClient = "";
        String latestClient = "";
        boolean isNanos = timings.entrySet().iterator();
        while (isNanos.hasNext()) {
            Map.Entry<String, Long> entry = (Map.Entry)isNanos.next();
            long ts = ((Long)entry.getValue()).longValue();
            if (ts < earliest) {
                earliest = ts;
                earliestClient = (String)entry.getKey();
            }
            if (ts > latest) {
                latest = ts;
                latestClient = (String)entry.getKey();
            }
        }
        isNanos = !this.ackReceiptTimes.isEmpty();
        spreadNanos = latest - earliest;
        long totalSpreadMs = isNanos ? spreadNanos / 1000000L : latest - earliest;
        this.lastSpreadResult = new PackUtilLANSync.SpreadResult(isNanos ? spreadNanos : totalSpreadMs * 1000000L, latestClient, timings.size());
        this.spreadHistory.add(this.lastSpreadResult);
        while (this.spreadHistory.size() > 10) {
            this.spreadHistory.remove(0);
        }
        if (totalSpreadMs == 0L) {
            String report = "§aPerfect sync!";
        } else {
            String report = "§e" + latestClient + " §7was §c+" + totalSpreadMs + "ms §7late";
        }
        PackUtilClientMessaging.sendPrefixed(report);
        this.sendTcpPacket(new LanPacket.ChatMessagePacket(this.sessionId, "__SYNC__", report));
        this.sendTcpPacket(new LanPacket.ChatMessagePacket(this.sessionId, "__SPREAD_DATA__", spreadNanos + "\t" + latestClient + "\t" + timings.size()));
        this.broadcastSyncState(PackUtilLANSync.SyncState.DONE, totalSpreadMs + "ms spread");
        this.setSyncState(PackUtilLANSync.SyncState.DONE);
        this.fireCallback(this.onSpreadCalculated);
        new Thread(this::lambda$calculateAndDisplaySpread$8, "Sync-ResetIdle").start();
    }

    public void sendQueuedPackets() {
        if (this.sessionId == null) {
            PackUtilClientMessaging.sendPrefixed("§cJoin a session first.");
            return;
        }
        PackUtilSharedState.get().regenerateQueue();
        if (this.isHost) {
            this.initiateGoSyncForQueue();
        } else {
            this.sendTcpPacket(new LanPacket.RequestSyncPacket(this.sessionId, this.myUsername, false, "", "__QUEUE_FLUSH__"));
            PackUtilClientMessaging.sendPrefixed("§eRequested sync execution from host...");
        }
    }

    public void executeMacroSynchronized(String macroName) {
        if (this.sessionId == null) {
            PackUtilClientMessaging.sendPrefixed("§cJoin a session first.");
            return;
        }
        if (this.isHost) {
            this.initiateGoSync(true, macroName, "");
        } else {
            this.sendTcpPacket(new LanPacket.RequestSyncPacket(this.sessionId, this.myUsername, true, macroName, ""));
            PackUtilClientMessaging.sendPrefixed("§eRequested sync execution from host...");
        }
    }

    public void executeMacrosSynchronized(Map<String, String> assignments) {
        if (this.sessionId == null) {
            PackUtilClientMessaging.sendPrefixed("§cJoin a session first.");
            return;
        }
        if (assignments == null || assignments.isEmpty()) {
            return;
        }
        String defaultMacro = (String)assignments.values().iterator().next();
        if (this.isHost) {
            this.initiateGoSync(true, defaultMacro, "", assignments);
        } else {
            StringBuilder sb = new StringBuilder();
            RequestSyncPacket rsp = assignments.entrySet().iterator();
            while (rsp.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry)rsp.next();
                if (!sb.length() > 0) continue;
                sb.append(9);
                sb.append((String)entry.getKey()).append(9).append((String)entry.getValue());
            }
            rsp = new LanPacket.RequestSyncPacket(this.sessionId, this.myUsername, true, defaultMacro, "__PER_USER__\t" + String.valueOf(sb));
            this.sendTcpPacket(rsp);
            PackUtilClientMessaging.sendPrefixed("§eRequested per-user sync from host...");
        }
    }

    public void startSearching() {
        if (!this.running.get()) {
            PackUtilClientMessaging.sendPrefixed("§cStart LAN Sync first.");
            return;
        }
        if (this.isInSession()) {
            PackUtilClientMessaging.sendPrefixed("§cAlready in session.");
            return;
        }
        if (this.myUsername.isEmpty()) {
            this.myUsername = this.getUsername();
        }
        this.discoveredSessions.clear();
        this.isSearching = true;
        this.searchTicksRemaining = 400;
        new Thread(this::lambda$startSearching$9, "TCP-Search-Loop").start();
    }

    public void cancelSearch() {
        this.isSearching = false;
        this.searchTicksRemaining = 0;
    }

    public void tick() {
        if (!this.running.get() && this.sessionId == null) {
            return;
        }
        if (this.sessionId != null) {
            long nowMs = System.currentTimeMillis();
            if (nowMs - this.lastHeartbeatSentMs >= 9000L) {
                this.lastHeartbeatSentMs = nowMs;
                this.sendTcpPacket(new LanPacket.HeartbeatPacket(this.sessionId, this.myUsername, nowMs));
                this.checkPeerHealth();
            }
        }
        mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        long currentTick = mc.field_1687.method_75260();
        if (this.sessionId != null) {
            if (currentTick % 40L == 10L) {
                this.checkAndBroadcastMacroListChanges();
            }
        }
        if (this.isSearching) {
            if (this.searchTicksRemaining > 0) {
                this.searchTicksRemaining = this.searchTicksRemaining - 1;
                if (!this.discoveredSessions.isEmpty()) {
                    String firstSessionId = (String)this.discoveredSessions.keySet().iterator().next();
                    String hostName = (String)this.discoveredSessions.get(firstSessionId);
                    this.isSearching = false;
                    this.searchTicksRemaining = 0;
                    this.joinSession(firstSessionId);
                    PackUtilClientMessaging.sendPrefixed("§aJoined session " + firstSessionId + " (Host: " + hostName + ").");
                    return;
                }
                if (this.searchTicksRemaining == 0) {
                    this.isSearching = false;
                    PackUtilClientMessaging.sendPrefixed("§cNo sessions found.");
                }
            }
        }
    }

    private void checkPeerHealth() {
        long now = System.currentTimeMillis();
        List<String> deadPeers = new ArrayList();
        var var4 = this.lastHeartbeatTime.entrySet().iterator();
        while (var4.hasNext()) {
            Map.Entry<String, Long> entry = (Map.Entry)var4.next();
            String peer = (String)entry.getKey();
            while (peer.equals(this.myUsername)) {
            }
            long elapsed = now - ((Long)entry.getValue()).longValue();
            if (!elapsed > 30000L) continue;
            deadPeers.add(peer);
        }
        var4 = deadPeers.iterator();
        while (var4.hasNext()) {
            dead = (String)var4.next();
            this.connectedClients.remove(dead);
            this.lastHeartbeatTime.remove(dead);
            this.clientMacroLists.remove(dead);
            this.remoteMeteorMacros.remove(dead);
            this.peerStepProgress.remove(dead);
            if (!this.isHost) continue;
            s = (Socket)this.tcpClients.remove(dead);
            try {
                s.close();
            }
            catch (IOException elapsed) {
                this.tcpClientWriteLocks.remove(dead);
                L251: ;
                PackUtilClientMessaging.sendPrefixed("§e" + dead + " timed out.");
                YungLightAddon.LOG.info("[Heartbeat] Peer timed out: {}", dead);
                this.fireCallback(this.onClientLeft);
                this.fireCallback(this.onPeerStatusChanged);
                MacroConditionRegistry.onLanStepProgress();
            }
            this.tcpClientWriteLocks.remove(dead);
            L251: ;
            PackUtilClientMessaging.sendPrefixed("§e" + dead + " timed out.");
            YungLightAddon.LOG.info("[Heartbeat] Peer timed out: {}", dead);
            this.fireCallback(this.onClientLeft);
            this.fireCallback(this.onPeerStatusChanged);
            MacroConditionRegistry.onLanStepProgress();
        }
        if (this.isHost) {
            if (!deadPeers.isEmpty()) {
                this.broadcastClientList();
            }
        }
    }

    public PackUtilLANSync.PeerStatus getPeerStatus(String username) {
        if (username.equals(this.myUsername)) {
            return PackUtilLANSync.PeerStatus.HEALTHY;
        }
        Long lastBeat = (Long)this.lastHeartbeatTime.get(username);
        if (lastBeat == null) {
            return PackUtilLANSync.PeerStatus.UNKNOWN;
        }
        long elapsed = System.currentTimeMillis() - lastBeat.longValue();
        if (elapsed > 15000L) {
            return PackUtilLANSync.PeerStatus.STALE;
        }
        return PackUtilLANSync.PeerStatus.HEALTHY;
    }

    private void handlePacket(LanPacket packet) {
        switch (PackUtilLANSync.1.$SwitchMap$com$example$addon$util$lan$LanPacketType[packet.getType().ordinal()]) {
            case 1::
                /* goto @1622; */
            case 2::
                if (!packet instanceof LanPacket.SessionPacket) { /* goto @1622; */ }
                SessionPacket p = (LanPacket.SessionPacket)packet;
                String sid = p.getSessionId();
                String host = p.hostName;
                if (host.equals(this.myUsername)) { /* goto L210; */ }
                if (this.isInSession()) { /* goto L210; */ }
                boolean isNew = !this.discoveredSessions.containsKey(sid);
                this.discoveredSessions.put(sid, host);
                if (isNew) {
                    PackUtilClientMessaging.sendPrefixed("§eFound session " + sid + " (Host: " + host + ").");
                }
                /* goto @1622; */
            case 3::
                if (!packet instanceof LanPacket.JoinPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.JoinPacket)packet;
                username = p.username;
                if (username != null) {
                    if (!username.isEmpty()) {
                        if (!username.equals(this.myUsername)) {
                            if (!this.connectedClients.containsKey(username)) {
                                this.connectedClients.put(username, new PackUtilLANSync.ClientInfo(username, false));
                                this.lastHeartbeatTime.put(username, System.currentTimeMillis());
                                PackUtilClientMessaging.sendPrefixed("§e" + username + " joined.");
                                this.executionTimestamps.clear();
                                if (this.isHost) {
                                    this.broadcastClientList();
                                    this.broadcastMacroList();
                                }
                                this.fireCallback(this.onClientJoined);
                                this.fireCallback(this.onPeerStatusChanged);
                            }
                        }
                    }
                }
                /* goto @1622; */
            case 4::
                if (!packet instanceof LanPacket.ClientListPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.ClientListPacket)packet;
                if (p.clients.isEmpty()) { /* goto L614; */ }
                ourInfo = (PackUtilLANSync.ClientInfo)this.connectedClients.get(this.myUsername);
                this.connectedClients.clear();
                now = System.currentTimeMillis();
                Set<String> listedPeers = new HashSet();
                var var7 = p.clients.iterator();
                while (var7.hasNext()) {
                    ClientEntry entry = (LanPacket.ClientListPacket.ClientEntry)var7.next();
                    this.connectedClients.put(entry.name, new PackUtilLANSync.ClientInfo(entry.name, entry.isHost));
                    if (!entry.name.equals(this.myUsername)) {
                        this.lastHeartbeatTime.put(entry.name, now);
                        listedPeers.add(entry.name);
                    }
                }
                this.lastHeartbeatTime.keySet().retainAll(listedPeers);
                if (!this.connectedClients.containsKey(this.myUsername)) {
                    if (ourInfo != null) {
                        this.connectedClients.put(this.myUsername, ourInfo);
                    }
                }
                /* goto @1622; */
            case 5::
                if (!packet instanceof LanPacket.LeavePacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.LeavePacket)packet;
                username = p.username;
                if (username == null) { /* goto @959; */ }
                if (username.isEmpty()) { /* goto @959; */ }
                if (username.equals(this.myUsername)) { /* goto @959; */ }
                leavingClient = (PackUtilLANSync.ClientInfo)this.connectedClients.get(username);
                leavingWasHost = leavingClient != null && leavingClient.isHost;
                this.connectedClients.remove(username);
                this.lastHeartbeatTime.remove(username);
                this.clientMacroLists.remove(username);
                this.remoteMeteorMacros.remove(username);
                this.peerStepProgress.remove(username);
                PackUtilClientMessaging.sendPrefixed("§e" + username + " left.");
                if (this.isHost) {
                    s = (Socket)this.tcpClients.remove(username);
                }
                try {
                    s.close();
                }
                catch (IOException e7) {
                    this.tcpClientWriteLocks.remove(username);
                    this.relayTcpPacketToClients(packet, username);
                    this.broadcastClientList();
                    L823: ;
                    if (leavingWasHost) {
                        if (!this.connectedClients.isEmpty()) {
                            newHostUsername = (String)this.connectedClients.keySet().stream().sorted().findFirst().orElse(null);
                            if (newHostUsername != null) {
                                if (newHostUsername.equals(this.myUsername)) {
                                    this.isHost = true;
                                    this.connectedClients.put(this.myUsername, new PackUtilLANSync.ClientInfo(this.myUsername, true));
                                    PackUtilClientMessaging.sendPrefixed("§aYou are now the host!");
                                    this.executionTimestamps.clear();
                                    this.broadcastClientList();
                                }
                            }
                        }
                    }
                    this.fireCallback(this.onClientLeft);
                    this.fireCallback(this.onPeerStatusChanged);
                    MacroConditionRegistry.onLanStepProgress();
                    L959: ;
                    /* goto @1622; */
                }
                this.tcpClientWriteLocks.remove(username);
                this.relayTcpPacketToClients(packet, username);
                this.broadcastClientList();
                L823: ;
                if (leavingWasHost) {
                    if (!this.connectedClients.isEmpty()) {
                        newHostUsername = (String)this.connectedClients.keySet().stream().sorted().findFirst().orElse(null);
                        if (newHostUsername != null) {
                            if (newHostUsername.equals(this.myUsername)) {
                                this.isHost = true;
                                this.connectedClients.put(this.myUsername, new PackUtilLANSync.ClientInfo(this.myUsername, true));
                                PackUtilClientMessaging.sendPrefixed("§aYou are now the host!");
                                this.executionTimestamps.clear();
                                this.broadcastClientList();
                            }
                        }
                    }
                }
                this.fireCallback(this.onClientLeft);
                this.fireCallback(this.onPeerStatusChanged);
                MacroConditionRegistry.onLanStepProgress();
                L959: ;
                /* goto @1622; */
            case 6::
                /* goto @1622; */
            case 7::
                /* goto @1622; */
            case 8::
                if (!this.isHost) { /* goto @1622; */ }
                this.broadcastClientList();
                /* goto @1622; */
            case 9::
                this.handleMacroData(packet);
                /* goto @1622; */
            case 10::
                this.handleMacroDelete(packet);
                /* goto @1622; */
            case 11::
                if (!packet instanceof LanPacket.QueueSyncPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                qp = (LanPacket.QueueSyncPacket)packet;
                this.handleQueueSync(qp.queueData, qp.senderUsername);
                /* goto @1622; */
            case 12::
                if (!packet instanceof LanPacket.ChatMessagePacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                cp = (LanPacket.ChatMessagePacket)packet;
                this.handleChatMessage(cp.senderUsername, cp.message);
                /* goto @1622; */
            case 13::
                if (!packet instanceof LanPacket.PrepareExecutionPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.PrepareExecutionPacket)packet;
                this.handlePrepare(p.executionId, p.isMacro, p.targetName, p.queueData, p.senderUsername, p.macroAssignments);
                /* goto @1622; */
            case 14::
                if (!packet instanceof LanPacket.ClientReadyPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.ClientReadyPacket)packet;
                this.handleClientReady(p.executionId, p.senderUsername);
                /* goto @1622; */
            case 15::
                /* goto @1622; */
            case 16::
                if (!packet instanceof LanPacket.GoPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.GoPacket)packet;
                this.handleGo(p.executionId);
                /* goto @1622; */
            case 17::
                if (!packet instanceof LanPacket.TcpCommandAckPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.TcpCommandAckPacket)packet;
                this.handleExecutionTimestamp(p.senderUsername, p.executeNanoTime);
                /* goto @1622; */
            case 18::
                if (!packet instanceof LanPacket.HeartbeatPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.HeartbeatPacket)packet;
                if (!p.senderUsername.equals(this.myUsername)) {
                    this.lastHeartbeatTime.put(p.senderUsername, System.currentTimeMillis());
                    if (this.isHost) {
                        this.relayTcpPacketToClients(packet, p.senderUsername);
                    }
                }
                /* goto @1622; */
            case 19::
                if (!packet instanceof LanPacket.RequestSyncPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.RequestSyncPacket)packet;
                this.handleRequestSync(p.senderUsername, p.isMacro, p.macroName, p.command);
                /* goto @1622; */
            case 20::
                if (!packet instanceof LanPacket.OffsetSyncPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.OffsetSyncPacket)packet;
                this.handleOffsetSync(p.senderUsername, p.targetUsername, p.offsetMs);
                /* goto @1622; */
            case 21::
                if (!packet instanceof LanPacket.MacroStepProgressPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.MacroStepProgressPacket)packet;
                this.handleStepProgress(p.senderUsername, p.completedStep, p.totalSteps, p.macroName);
                /* goto @1622; */
            case 22::
                if (!packet instanceof LanPacket.SyncStateUpdatePacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.SyncStateUpdatePacket)packet;
                states = PackUtilLANSync.SyncState.values();
                if (p.stateOrdinal >= 0) {
                    if (p.stateOrdinal < states.length) {
                        ctx = this.activeSyncCtx;
                        if (ctx == null || !ctx.isInitiator) {
                            this.syncState = states[p.stateOrdinal];
                            this.fireCallback(this.onSyncStateChanged);
                        }
                    }
                }
                /* goto @1622; */
            case 23::
                if (!packet instanceof LanPacket.MacroAssignmentSyncPacket) { /* goto @1622; */ }
                if (!packet.getSessionId().equals(this.sessionId)) { /* goto @1622; */ }
                p = (LanPacket.MacroAssignmentSyncPacket)packet;
                if (!p.senderUsername.equals(this.myUsername)) {
                    this.handleAssignmentSync(p.senderUsername, p.assignments);
                }
                /* goto @1622; */
            default:
                /* goto L1642; */
                e = null;
                YungLightAddon.LOG.error("[PackUtil-LAN] Error handling packet: {}", packet.getType(), e);
                L1642: ;
                return;
        }
    }

    private void startTcpServer() {
        try {
            this.tcpServer = new ServerSocket(25568);
            this.tcpServer.setReuseAddress(true);
            this.tcpAcceptThread = new Thread(this::lambda$startTcpServer$10, "TCP-Accept");
            this.tcpAcceptThread.setDaemon(true);
            this.tcpAcceptThread.start();
            YungLightAddon.LOG.info("[TCP] Server started on port {}", 25568);
        }
        catch (IOException e) {
            YungLightAddon.LOG.error("[TCP] Failed to start server: {}", e.getMessage());
            L93: ;
            return;
        }
    }

    private void handleNewTcpClient(Socket clientSocket) {
        new Thread(this::lambda$handleNewTcpClient$11 /* captured: clientSocket */, "TCP-Client-Handler").start();
    }

    private void sendClientListToClient(Socket clientSocket, String clientUsername) {
        List<LanPacket.ClientListPacket.ClientEntry> entries = new ArrayList();
        ClientListPacket packet = this.connectedClients.entrySet().iterator();
        while (packet.hasNext()) {
            Map.Entry<String, PackUtilLANSync.ClientInfo> entry = (Map.Entry)packet.next();
            entries.add(new LanPacket.ClientListPacket.ClientEntry((String)entry.getKey(), ((PackUtilLANSync.ClientInfo)entry.getValue()).isHost));
        }
        packet = new LanPacket.ClientListPacket(this.sessionId, entries);
        data = this.serializePacket(packet);
        Object lock = this.tcpClientWriteLocks.computeIfAbsent(clientUsername, PackUtilLANSync::lambda$sendClientListToClient$12);
        var var7 = lock;
        synchronized (lock) {
        clientSocket.getOutputStream().write(data);
        clientSocket.getOutputStream().flush();
        }
        /* goto L161; */
        var var8 = null;
        throw var8;
        L161: ;
        /* goto L180; */
        e = null;
        YungLightAddon.LOG.warn("[TCP] Failed to send client list: {}", e.getMessage());
        L180: ;
    }

    private void sendMacroListToClient(Socket clientSocket, String clientUsername) {
        List<PackUtilMacro> localMacros = PackUtilMacroManager.get().getAll();
        Object lock = this.tcpClientWriteLocks.computeIfAbsent(clientUsername, PackUtilLANSync::lambda$sendMacroListToClient$13);
        var var5 = localMacros.iterator();
        while (var5.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var5.next();
            class_2487 nbt = macro.toTag();
            String nbtString = nbt.toString();
            MacroDataPacket packet = new LanPacket.MacroDataPacket(this.sessionId, this.myUsername, macro.name, nbtString, 0);
            byte[] data = this.serializePacket(packet);
            var var11 = lock;
            synchronized (lock) {
            clientSocket.getOutputStream().write(data);
            clientSocket.getOutputStream().flush();
            }
            /* goto @137; */
            var var12 = null;
            throw var12;
        }
        /* goto L159; */
        e = null;
        YungLightAddon.LOG.warn("[TCP] Failed to send macro list: {}", e.getMessage());
        L159: ;
    }

    private void connectToTcpServer(String hostIp) {
        new Thread(this::lambda$connectToTcpServer$15 /* captured: hostIp */, "TCP-Connect").start();
    }

    private void attemptReconnect() {
        if (this.reconnecting || !this.running.get() || this.lastHostIp == null || this.lastSessionId == null) {
            return;
        }
        if (this.isHost) {
            return;
        }
        this.reconnecting = true;
        PackUtilClientMessaging.sendPrefixed("§eConnection lost. Reconnecting...");
        new Thread(this::lambda$attemptReconnect$16, "TCP-Reconnect").start();
    }

    private void sendMacroListViaConnection(DataOutputStream out) {
        List<PackUtilMacro> localMacros = PackUtilMacroManager.get().getAll();
        var var3 = this.tcpHostWriteLock;
        synchronized (this.tcpHostWriteLock) {
        var var4 = localMacros.iterator();
        while (var4.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var4.next();
            class_2487 nbt = macro.toTag();
            String nbtString = nbt.toString();
            MacroDataPacket packet = new LanPacket.MacroDataPacket(this.sessionId, this.myUsername, macro.name, nbtString, 0);
            out.writeInt(packet.getType().getId());
            out.writeUTF(packet.getSessionId());
            packet.write(out);
            out.flush();
        }
        }
        /* goto L129; */
        var var9 = null;
        throw var9;
        L129: ;
        /* goto L148; */
        e = null;
        YungLightAddon.LOG.warn("[TCP] Failed to send macro list: {}", e.getMessage());
        L148: ;
    }

    private byte[] serializePacket(LanPacket packet) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(baos);
        out.writeInt(packet.getType().getId());
        out.writeUTF(packet.getSessionId());
        packet.write(out);
        return baos.toByteArray();
    }

    private void sendTcpPacket(LanPacket packet) {
        byte[] data = this.serializePacket(packet);
        if (this.isHost) {
            var var3 = this.tcpClients.entrySet().iterator();
            while (var3.hasNext()) {
                Map.Entry<String, Socket> entry = (Map.Entry)var3.next();
                Socket client = (Socket)entry.getValue();
                String clientName = (String)entry.getKey();
                if (client.isClosed()) { /* goto L135; */ }
                Object lock = this.tcpClientWriteLocks.computeIfAbsent(clientName, PackUtilLANSync::lambda$sendTcpPacket$17);
                var var8 = lock;
                synchronized (lock) {
                client.getOutputStream().write(data);
                client.getOutputStream().flush();
                }
                /* goto L135; */
                var var9 = null;
                throw var9;
                L135: ;
                /* goto @140; */
                lock = null;
            }
        } else {
            var var3 = this.tcpHostWriteLock;
            synchronized (this.tcpHostWriteLock) {
            this.tcpHostSocket.getOutputStream().write(data);
            if (this.tcpHostSocket != null && !this.tcpHostSocket.isClosed()) {
                this.tcpHostSocket.getOutputStream().flush();
            }
            }
            /* goto @203; */
            var var10 = null;
            throw var10;
        }
        /* goto L222; */
        e = null;
        YungLightAddon.LOG.warn("[TCP] Failed to send packet: {}", e.getMessage());
        L222: ;
    }

    private void relayTcpPacketToClients(LanPacket packet, String excludedUsername) {
        if (!this.isHost) {
            return;
        }
        byte[] data = this.serializePacket(packet);
        var var4 = this.tcpClients.entrySet().iterator();
        while (var4.hasNext()) {
            Map.Entry<String, Socket> entry = (Map.Entry)var4.next();
            String clientName = (String)entry.getKey();
            while (excludedUsername != null) {
                if (!excludedUsername.equals(clientName)) break;
            }
            Socket client = (Socket)entry.getValue();
            if (client.isClosed()) { /* goto L155; */ }
            Object lock = this.tcpClientWriteLocks.computeIfAbsent(clientName, PackUtilLANSync::lambda$relayTcpPacketToClients$18);
            var var9 = lock;
            synchronized (lock) {
            client.getOutputStream().write(data);
            client.getOutputStream().flush();
            }
            /* goto L155; */
            var var10 = null;
            throw var10;
            L155: ;
            /* goto @160; */
            lock = null;
        }
        /* goto L182; */
        e = null;
        YungLightAddon.LOG.warn("[TCP] Failed to relay packet: {}", e.getMessage());
        L182: ;
    }

    private void stopTcp() {
        if (this.tcpServer != null) {
            this.tcpServer.close();
            this.tcpServer = null;
        }
        if (this.tcpHostSocket != null) {
            this.tcpHostSocket.close();
            this.tcpHostSocket = null;
        }
        IOException e = this.tcpClients.values().iterator();
        while (e.hasNext()) {
            Socket s = (Socket)e.next();
            s.close();
            /* goto @80; */
            var var3 = null;
        }
        this.tcpClients.clear();
        this.tcpClientWriteLocks.clear();
        /* goto L120; */
        e = null;
        YungLightAddon.LOG.warn("[TCP] Stop error: {}", e.getMessage());
        L120: ;
    }

    private void broadcastClientList() {
        if (!this.isHost) {
            return;
        }
        List<LanPacket.ClientListPacket.ClientEntry> entries = new ArrayList();
        var var2 = this.connectedClients.entrySet().iterator();
        while (var2.hasNext()) {
            Map.Entry<String, PackUtilLANSync.ClientInfo> entry = (Map.Entry)var2.next();
            entries.add(new LanPacket.ClientListPacket.ClientEntry((String)entry.getKey(), ((PackUtilLANSync.ClientInfo)entry.getValue()).isHost));
        }
        this.sendTcpPacket(new LanPacket.ClientListPacket(this.sessionId, entries));
    }

    private void broadcastSyncState(PackUtilLANSync.SyncState state, String detail) {
        if (this.isHost) {
            this.sendTcpPacket(new LanPacket.SyncStateUpdatePacket(this.sessionId, state.ordinal(), detail));
        }
    }

    private void checkAndBroadcastMacroListChanges() {
        try {
            Map<String, String> currentMeteorMacros = this.snapshotMeteorMacros();
            boolean changed = currentMeteorMacros.size() != this.lastBroadcastMeteorMacros.size();
            if (changed) { /* goto L112; */ }
            var var3 = currentMeteorMacros.entrySet().iterator();
            while (var3.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry)var3.next();
                String lastValue = (String)this.lastBroadcastMeteorMacros.get(entry.getKey());
                if (((String)entry.getValue()).equals(lastValue)) { /* goto @109; */ }
                changed = true;
                break;
            }
            if (!changed) { /* goto @192; */ }
            var3 = new ArrayList(this.lastBroadcastMeteorMacros.keySet()).iterator();
            while (var3.hasNext()) {
                previousName = (String)var3.next();
                if (currentMeteorMacros.containsKey(previousName)) continue;
                this.broadcastMacroDeletion(previousName);
            }
            this.lastBroadcastMeteorMacros = new ConcurrentHashMap(currentMeteorMacros);
            this.broadcastMacroList();
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil-LAN] Failed to check macro list changes", e);
            L208: ;
            return;
        }
    }

    public void broadcastMacroList() {
        if (this.sessionId == null) {
            return;
        }
        List<PackUtilMacro> localMacros = PackUtilMacroManager.get().getAll();
        List<PackUtilMacro> meteorMacros = localMacros.iterator();
        while (meteorMacros.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)meteorMacros.next();
            class_2487 nbt = macro.toTag();
            String nbtString = nbt.toString();
            this.sendTcpPacket(new LanPacket.MacroDataPacket(this.sessionId, this.myUsername, macro.name, nbtString, 0));
        }
        meteorMacros = MeteorMacroAdapter.getMeteorMacros();
        macro = meteorMacros.iterator();
        while (macro.hasNext()) {
            macro = (PackUtilMacro)macro.next();
            nbt = macro.toTag();
            String nbtString = nbt.toString();
            this.sendTcpPacket(new LanPacket.MacroDataPacket(this.sessionId, this.myUsername, macro.name, nbtString, 1));
        }
        this.lastBroadcastMeteorMacros = new ConcurrentHashMap(this.snapshotMeteorMacros());
    }

    private Map<String, String> snapshotMeteorMacros() {
        Map<String, String> snapshot = new LinkedHashMap();
        var var2 = MeteorMacroAdapter.getMeteorMacros().iterator();
        while (var2.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var2.next();
            if (macro == null) continue;
            if (macro.name == null) continue;
            while (macro.name.isBlank()) {
            }
            snapshot.put(macro.name, macro.toTag().toString());
        }
        return snapshot;
    }

    private void handleMacroData(LanPacket packet) {
        if (!packet instanceof LanPacket.MacroDataPacket || !packet.getSessionId().equals(this.sessionId)) {
            return;
        }
        MacroDataPacket p = (LanPacket.MacroDataPacket)packet;
        String sender = p.senderUsername;
        if (sender != null) {
            if (sender.equals(this.myUsername)) {
                return;
            }
        }
        try {
            class_2487 nbt = class_2512.method_32260(p.nbtData);
            PackUtilMacro macro = new PackUtilMacro();
            macro.fromTag(nbt);
            if (p.sourceType == 1) {
                this.remoteMeteorMacros.putIfAbsent(sender, new ConcurrentHashMap());
                ((Map)this.remoteMeteorMacros.get(sender)).put(macro.name, macro);
            } else {
                this.clientMacroLists.putIfAbsent(sender, new ConcurrentHashMap());
                ((Map)this.clientMacroLists.get(sender)).put(macro.name, macro);
            }
            if (p.sourceType == 2) {
                this.importSharedMacroIfMissing(macro, sender);
            }
            if (this.isHost) {
                if (sender != null) {
                    if (!sender.isBlank()) {
                        this.relayTcpPacketToClients(new LanPacket.MacroDataPacket(this.sessionId, sender, macro.name, p.nbtData, p.sourceType), sender);
                    }
                }
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil-LAN] Failed to deserialize macro", e);
            L246: ;
            return;
        }
    }

    private void importSharedMacroIfMissing(PackUtilMacro macro, String sender) {
        if (macro == null || macro.name == null || macro.name.isBlank()) {
            return;
        }
        PackUtilMacroManager manager = PackUtilMacroManager.get();
        PackUtilMacro existing = manager.get(macro.name);
        if (existing != null) {
            PackUtilMacro fresh = macro.deepCopy(existing.name);
            existing.actions.clear();
            existing.actions.addAll(fresh.actions);
            existing.loop = fresh.loop;
            existing.loopCount = fresh.loopCount;
            manager.save();
            PackUtilClientMessaging.sendPrefixed("§aUpdated macro from " + sender + ": " + existing.name);
            return;
        }
        installed = macro.deepCopy(macro.name);
        manager.add(installed);
        PackUtilClientMessaging.sendPrefixed("§aReceived macro from " + sender + ": " + installed.name);
    }

    private void handleMacroDelete(LanPacket packet) {
        if (!packet instanceof LanPacket.MacroDeletePacket || !packet.getSessionId().equals(this.sessionId)) {
            return;
        }
        MacroDeletePacket p = (LanPacket.MacroDeletePacket)packet;
        if (p.senderUsername != null && p.senderUsername.equals(this.myUsername)) {
            return;
        }
        if (this.clientMacroLists.containsKey(p.senderUsername)) {
            ((Map)this.clientMacroLists.get(p.senderUsername)).remove(p.macroName);
        }
        if (this.remoteMeteorMacros.containsKey(p.senderUsername)) {
            ((Map)this.remoteMeteorMacros.get(p.senderUsername)).remove(p.macroName);
        }
        if (this.isHost) {
            if (p.senderUsername != null) {
                if (!p.senderUsername.isBlank()) {
                    this.relayTcpPacketToClients(new LanPacket.MacroDeletePacket(this.sessionId, p.senderUsername, p.macroName), p.senderUsername);
                }
            }
        }
    }

    private void handleQueueSync(String queueData, String senderUsername) {
        try {
            if (senderUsername != null) {
                if (senderUsername.equals(this.myUsername)) {
                    return;
                }
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil-LAN] Failed to process queue sync", e);
            PackUtilClientMessaging.sendPrefixed("§cFailed to receive queue");
            L87: ;
            return;
        }
        try {
            PackUtilSharedState.QueuedPacket.resetIdCounter();
            receivedQueue = PackUtilClipboardHelper.deserializeQueueFromBase64(queueData);
            if (receivedQueue == null || receivedQueue.isEmpty()) {
                PackUtilClientMessaging.sendPrefixed("§cReceived empty queue");
                return;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil-LAN] Failed to process queue sync", e);
            PackUtilClientMessaging.sendPrefixed("§cFailed to receive queue");
            L87: ;
            return;
        }
        try {
            PackUtilSharedState.get().setDelayedPackets(receivedQueue);
            PackUtilClientMessaging.sendPrefixed("§aReceived queue: " + receivedQueue.size() + " packets");
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil-LAN] Failed to process queue sync", e);
            PackUtilClientMessaging.sendPrefixed("§cFailed to receive queue");
            L87: ;
            return;
        }
    }

    private void handleChatMessage(String senderUsername, String message) {
        String safeSender = senderUsername == null || senderUsername.isBlank() ? "Peer" : senderUsername;
        String safeMessage = message == null ? "" : message.trim();
        if (safeMessage.isEmpty()) {
            return;
        }
        if ("__SYNC__".equals(safeSender)) {
            PackUtilClientMessaging.sendPrefixed(safeMessage);
            return;
        }
        if ("__STOP_ALL__".equals(safeSender)) {
            MacroExecutor.stop();
            PackUtilClientMessaging.sendPrefixed("§c[LAN] Macros stopped by " + safeMessage);
            return;
        }
        try {
            String[] parts = safeMessage.split("\t");
            if (parts.length < 3) { /* goto @195; */ }
            long nanos = Long.parseLong(parts[0]);
            String lateClient = parts[1];
            int count = Integer.parseInt(parts[2]);
            this.lastSpreadResult = new PackUtilLANSync.SpreadResult(nanos, lateClient, count);
            this.spreadHistory.add(this.lastSpreadResult);
            while (this.spreadHistory.size() > 10) {
                this.spreadHistory.remove(0);
            }
            this.fireCallback(this.onSpreadCalculated);
        }
        catch (NumberFormatException parts) {
            return;
        }
        return;
        L201: ;
        if (safeSender.equals(this.myUsername)) {
            return;
        }
        PackUtilClientMessaging.send("[LAN] <" + safeSender + "> " + safeMessage);
    }

    private void handleRequestSync(String senderUsername, boolean isMacro, String macroName, String command) {
        if (senderUsername == null || senderUsername.equals(this.myUsername)) {
            return;
        }
        if (!this.isHost) {
            YungLightAddon.LOG.warn("[Sync] Non-host received REQUEST_SYNC from {} — ignoring", senderUsername);
            return;
        }
        YungLightAddon.LOG.info("[Sync] Received sync request from {}: isMacro={}, name={}, cmd={}", senderUsername, isMacro, macroName, command);
        if ("__QUEUE_FLUSH__".equals(command)) {
            this.initiateGoSyncForQueue();
        } else {
            if (command != null) {
                if (!command.startsWith("__PER_USER__\t")) { /* goto @189; */ }
                String assignStr = command.substring("__PER_USER__\t".length());
                String[] parts = assignStr.split("\t");
                Map<String, String> assignments = new LinkedHashMap();
                for (int pi = 0; pi + 1 < parts.length; pi += 2) {
                    assignments.put(parts[pi], parts[pi + 1]);
                }
                this.initiateGoSync(isMacro, macroName, "", assignments);
            } else {
                this.initiateGoSync(isMacro, macroName, command);
            }
        }
    }

    private void handleStepProgress(String senderUsername, int completedStep, int totalSteps, String macroName) {
        if (senderUsername == null || senderUsername.equals(this.myUsername)) {
            return;
        }
        if (this.isHost) {
            this.sendTcpPacket(new LanPacket.MacroStepProgressPacket(this.sessionId, senderUsername, completedStep, totalSteps, macroName));
        }
        if (completedStep < 0) {
            this.peerStepProgress.remove(senderUsername);
        } else {
            this.peerStepProgress.put(senderUsername, completedStep);
        }
        MacroConditionRegistry.onLanStepProgress();
        Runnable listener = this.onStepProgressChanged;
        if (listener != null) {
            listener.run();
        }
    }

    private void handleOffsetSync(String senderUsername, String targetUsername, int offsetMs) {
        if (senderUsername == null || senderUsername.equals(this.myUsername)) {
            return;
        }
        ClientInfo info = (PackUtilLANSync.ClientInfo)this.connectedClients.get(targetUsername);
        if (info != null) {
            info.delayOffsetMs = Math.max(0, offsetMs);
            YungLightAddon.LOG.info("[Sync] Offset for {} set to {}ms by {}", targetUsername, offsetMs, senderUsername);
        }
        if (this.isHost) {
            this.sendTcpPacket(new LanPacket.OffsetSyncPacket(this.sessionId, senderUsername, targetUsername, offsetMs));
        }
    }

    public boolean isRunning() {
        return this.running.get();
    }

    public boolean isInSession() {
        return this.sessionId != null;
    }

    public void onGameJoined() {
        if (this.sessionId == null) {
            return;
        }
        if (this.isHost) {
            this.broadcastClientList();
        } else {
            this.sendTcpPacket(new LanPacket.RequestClientListPacket(this.sessionId));
        }
    }

    public boolean isHost() {
        return this.isHost;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public int getConnectedCount() {
        return this.connectedClients.size();
    }

    public boolean isSearching() {
        return this.isSearching;
    }

    public int getSearchSecondsRemaining() {
        return this.searchTicksRemaining / 20;
    }

    public boolean isReconnecting() {
        return this.reconnecting;
    }

    public PackUtilLANSync.SyncState getSyncState() {
        return this.syncState;
    }

    public PackUtilLANSync.SyncContext getActiveSyncContext() {
        return this.activeSyncCtx;
    }

    public PackUtilLANSync.SpreadResult getLastSpreadResult() {
        return this.lastSpreadResult;
    }

    public List<PackUtilLANSync.SpreadResult> getSpreadHistory() {
        return new ArrayList(this.spreadHistory);
    }

    public String getMyUsername() {
        return this.myUsername;
    }

    public Map<String, PackUtilLANSync.ClientInfo> getConnectedClients() {
        return new ConcurrentHashMap(this.connectedClients);
    }

    public void broadcastMacroDeletion(String macroName) {
        if (this.sessionId == null) {
            return;
        }
        this.sendTcpPacket(new LanPacket.MacroDeletePacket(this.sessionId, this.myUsername, macroName));
    }

    public void broadcastQueueSync(String queueData) {
        if (!this.isInSession()) {
            return;
        }
        this.sendTcpPacket(new LanPacket.QueueSyncPacket(this.sessionId, queueData, this.myUsername));
    }

    public void broadcastStopAll() {
        if (!this.isInSession()) {
            return;
        }
        MacroExecutor.stop();
        PackUtilClientMessaging.sendPrefixed("§c[LAN] Macros stopped by " + this.myUsername);
        this.sendTcpPacket(new LanPacket.ChatMessagePacket(this.sessionId, "__STOP_ALL__", this.myUsername));
    }

    public boolean sendChatMessage(String message) {
        String safeMessage = message == null ? "" : message.trim();
        if (safeMessage.isEmpty()) {
            return false;
        }
        if (!this.isInSession()) {
            PackUtilClientMessaging.sendPrefixed("Join a LAN Sync session first.");
            return false;
        }
        String command = "__CHAT__\t" + safeMessage;
        if (this.isHost) {
            this.initiateGoSync(false, null, command);
        } else {
            this.sendTcpPacket(new LanPacket.RequestSyncPacket(this.sessionId, this.myUsername, false, "", command));
            PackUtilClientMessaging.sendPrefixed("§eRequested sync chat from host...");
        }
        return true;
    }

    public int getConnectedClientCount() {
        return this.connectedClients.size();
    }

    public void broadcastStepProgress(int completedStep, int totalSteps, String macroName) {
        if (this.sessionId == null) {
            return;
        }
        if (completedStep < 0) {
            this.peerStepProgress.remove(this.myUsername);
        } else {
            this.peerStepProgress.put(this.myUsername, completedStep);
        }
        this.sendTcpPacket(new LanPacket.MacroStepProgressPacket(this.sessionId, this.myUsername, completedStep, totalSteps, macroName != null ? macroName : ""));
        MacroConditionRegistry.onLanStepProgress();
    }

    public int getPeerStep(String username) {
        return ((Integer)this.peerStepProgress.getOrDefault(username, 0)).intValue();
    }

    public Map<String, Integer> getAllPeerSteps() {
        return new ConcurrentHashMap(this.peerStepProgress);
    }

    public void clearStepProgress() {
        this.peerStepProgress.clear();
    }

    public void setOnStepProgressChanged(Runnable callback) {
        this.onStepProgressChanged = callback;
    }

    public Map<String, Map<String, PackUtilMacro>> getAllRemoteMacros() {
        return new HashMap(this.clientMacroLists);
    }

    public Map<String, Map<String, PackUtilMacro>> getAllRemoteMeteorMacros() {
        return new HashMap(this.remoteMeteorMacros);
    }

    public List<String> getPeersMissingMacro(String macroName) {
        List<String> missing = new ArrayList();
        if (macroName == null || macroName.isBlank()) {
            return missing;
        }
        Map<String, Map<String, PackUtilMacro>> remote = this.getAllRemoteMacros();
        TreeSet<String> peers = new TreeSet(this.connectedClients.keySet());
        var var5 = peers.iterator();
        while (var5.hasNext()) {
            String peer = (String)var5.next();
            while (peer.equals(this.myUsername)) {
            }
            Map<String, PackUtilMacro> peerMacros = (Map)remote.get(peer);
            if (!peerMacros == null || !peerMacros.containsKey(macroName)) continue;
            missing.add(peer);
        }
        return missing;
    }

    public Map<String, String> getMissingAssignedMacros(Map<String, String> assignments) {
        Map<String, String> missing = new LinkedHashMap();
        if (assignments == null || assignments.isEmpty()) {
            return missing;
        }
        Map<String, Map<String, PackUtilMacro>> remote = this.getAllRemoteMacros();
        var var4 = new LinkedHashMap(assignments).entrySet().iterator();
        while (var4.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var4.next();
            String username = (String)entry.getKey();
            String macroName = (String)entry.getValue();
            if (username == null) continue;
            if (username.isBlank()) continue;
            if (macroName == null) continue;
            while (macroName.isBlank()) {
            }
            while (username.equals(this.myUsername)) {
                if (PackUtilMacroManager.get().get(macroName) != null) continue;
                missing.put(username, macroName);
            }
            Map<String, PackUtilMacro> peerMacros = (Map)remote.get(username);
            if (!peerMacros == null || !peerMacros.containsKey(macroName)) continue;
            missing.put(username, macroName);
        }
        return missing;
    }

    public List<String> getRemoteMacros() {
        Set<String> remoteMacros = new HashSet();
        Set<String> ownMacros = new HashSet();
        ownMacros.addAll(PackUtilCompatManager.getMeteorMacroNames());
        var var3 = this.clientMacroLists.entrySet().iterator();
        while (var3.hasNext()) {
            Map.Entry<String, Map<String, PackUtilMacro>> entry = (Map.Entry)var3.next();
            if (((String)entry.getKey()).equals(this.myUsername)) { /* goto @146; */ }
            var var5 = ((Map)entry.getValue()).keySet().iterator();
            while (var5.hasNext()) {
                String macroName = (String)var5.next();
                if (ownMacros.contains(macroName)) continue;
                remoteMacros.add(macroName);
            }
        }
        return new ArrayList(remoteMacros);
    }

    public void importMacro(String clientUsername, String macroName) {
        Map<String, PackUtilMacro> clientMacros = (Map)this.clientMacroLists.get(clientUsername);
        if (clientMacros == null || !clientMacros.containsKey(macroName)) {
            PackUtilClientMessaging.sendPrefixed("§cMacro not found: " + macroName);
            return;
        }
        PackUtilMacro remoteMacro = (PackUtilMacro)clientMacros.get(macroName);
        String newName = macroName;
        int suffix = 1;
        while (PackUtilMacroManager.get().get(newName) != null) {
            newName = macroName + " (" + suffix + ")";
            suffix++;
        }
        PackUtilMacro newMacro = new PackUtilMacro(newName);
        newMacro.actions.addAll(remoteMacro.actions);
        PackUtilMacroManager.get().add(newMacro);
        PackUtilMacroManager.get().save();
        PackUtilClientMessaging.sendPrefixed("§aImported macro: " + newName);
        YungLightAddon.LOG.info("[PackUtil-LAN] Imported macro '{}' from {}", newName, clientUsername);
    }

    public void broadcastAssignments(Map<String, String> assignments) {
        if (this.sessionId == null || !this.isInSession()) {
            return;
        }
        this.syncedAssignments.clear();
        this.syncedAssignments.putAll(assignments);
        this.assignmentSetBy = this.myUsername;
        StringBuilder sb = new StringBuilder();
        var var3 = assignments.entrySet().iterator();
        while (var3.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var3.next();
            if (!sb.length() > 0) continue;
            sb.append(9);
            sb.append((String)entry.getKey()).append(9).append((String)entry.getValue());
        }
        this.sendTcpPacket(new LanPacket.MacroAssignmentSyncPacket(this.sessionId, this.myUsername, sb.toString()));
    }

    private void handleAssignmentSync(String sender, String encoded) {
        this.syncedAssignments.clear();
        this.assignmentSetBy = sender;
        if (encoded == null) { /* goto L71; */ }
        if (encoded.isEmpty()) { /* goto L71; */ }
        String[] parts = encoded.split("\t");
        for (int i = 0; i + 1 < parts.length; i += 2) {
            this.syncedAssignments.put(parts[i], parts[i + 1]);
        }
        this.fireCallback(this.onAssignmentsChanged);
    }

    public Map<String, String> getSyncedAssignments() {
        return new LinkedHashMap(this.syncedAssignments);
    }

    public String getAssignmentSetBy() {
        return this.assignmentSetBy;
    }

    public void setOnAssignmentsChanged(Runnable callback) {
        this.onAssignmentsChanged = callback;
    }

    public List<String> getRemoteMacroNamesForPeer(String peerUsername) {
        Map<String, PackUtilMacro> peerMacros = (Map)this.clientMacroLists.get(peerUsername);
        if (peerMacros == null || peerMacros.isEmpty()) {
            return Collections.emptyList();
        }
        return new ArrayList(peerMacros.keySet());
    }

    public boolean shareMacroWithPeers(String macroName) {
        if (this.sessionId == null || !this.isInSession()) {
            PackUtilClientMessaging.sendPrefixed("§cJoin a session first.");
            return false;
        }
        if (macroName == null || macroName.isBlank()) {
            PackUtilClientMessaging.sendPrefixed("§cSelect a macro first.");
            return false;
        }
        PackUtilMacro macro = PackUtilMacroManager.get().get(macroName);
        if (macro == null) {
            PackUtilClientMessaging.sendPrefixed("§cMacro not found: " + macroName);
            return false;
        }
        class_2487 nbt = macro.toTag();
        this.sendTcpPacket(new LanPacket.MacroDataPacket(this.sessionId, this.myUsername, macro.name, nbt.toString(), 2));
        PackUtilClientMessaging.sendPrefixed("§aSent macro to peers: " + macro.name);
        return true;
    }

    public void sharePreset(String presetName) {
        if (this.sessionId == null) {
            PackUtilClientMessaging.sendPrefixed("§cNot in session.");
            return;
        }
        File file = new File(new File(YungLightAddon.FOLDER, "presets"), presetName + ".json");
        if (!file.exists()) {
            PackUtilClientMessaging.sendPrefixed("§cPreset not found: " + presetName);
            return;
        }
        try {
            String json = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            this.sendTcpPacket(new LanPacket.PresetDataPacket(this.sessionId, this.myUsername, presetName, json));
            PackUtilClientMessaging.sendPrefixed("§aShared preset '" + presetName + "' with LAN.");
        }
        catch (IOException e) {
            PackUtilClientMessaging.sendPrefixed("§cFailed to read preset: " + e.getMessage());
            L122: ;
            return;
        }
    }

    public void requestMacro(String macroName) {
        if (this.sessionId == null || !this.isInSession()) {
            PackUtilClientMessaging.sendPrefixed("§cNot in a LAN Sync session!");
            return;
        }
        this.sendTcpPacket(new LanPacket.RequestMacroPacket(this.sessionId, macroName));
        PackUtilClientMessaging.sendPrefixed("§eRequesting macro: " + macroName);
    }

    public void startTwoPhaseExecution(String targetName, boolean isMacro) {
        if (!this.isInSession()) {
            return;
        }
        if (isMacro) {
            this.executeMacroSynchronized(targetName);
        } else {
            this.sendQueuedPackets();
        }
    }

    private String summarizeNames(List<String> names) {
        if (names == null || names.isEmpty()) {
            return "";
        }
        if (names.size() <= 3) {
            return String.join(", ", names);
        }
        return String.join(", ", names.subList(0, 3)) + " +" + names.size() - 3 + " more";
    }

    private String summarizeAssignments(Map<String, String> assignments) {
        if (assignments == null || assignments.isEmpty()) {
            return "";
        }
        List<String> parts = new ArrayList();
        var var3 = assignments.entrySet().iterator();
        while (var3.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var3.next();
            parts.add((String)entry.getKey() + "=" + (String)entry.getValue());
            if (parts.size() != 3) { /* goto @111; */ }
            if (assignments.size() <= 3) { /* goto @111; */ }
            break;
        }
        if (assignments.size() > 3) {
            parts.add("+" + assignments.size() - 3 + " more");
        }
        return String.join(", ", parts);
    }

    public void setOnClientJoined(Runnable callback) {
        this.onClientJoined = callback;
    }

    public void setOnClientLeft(Runnable callback) {
        this.onClientLeft = callback;
    }

    public void setOnCountdown(Runnable callback) {
        this.onCountdown = callback;
    }

    public void setOnSendNow(Runnable callback) {
        this.onSendNow = callback;
    }

    public void setOnSessionStateChanged(Runnable callback) {
        this.onSessionStateChanged = callback;
    }

    public void setOnSyncStateChanged(Runnable callback) {
        this.onSyncStateChanged = callback;
    }

    public void setOnSpreadCalculated(Runnable callback) {
        this.onSpreadCalculated = callback;
    }

    public void setOnPeerStatusChanged(Runnable callback) {
        this.onPeerStatusChanged = callback;
    }

    private void fireCallback(Runnable callback) {
        if (callback != null) {
            class_310.method_1551().execute(callback);
        }
    }

    private String generateSessionId() {
        return String.format("%04d", (int)(Math.random() * 10000));
    }

    private String getUsername() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            return mc.field_1724.method_5477().getString();
        }
        return "Player";
    }

    public void setPlayerDelayOffset(String username, int offsetMs) {
        ClientInfo info = (PackUtilLANSync.ClientInfo)this.connectedClients.get(username);
        if (info != null) {
            int clamped = Math.max(0, offsetMs);
            info.delayOffsetMs = clamped;
            if (this.sessionId != null) {
                this.sendTcpPacket(new LanPacket.OffsetSyncPacket(this.sessionId, this.myUsername, username, clamped));
            }
        }
    }

    public int getPlayerDelayOffset(String username) {
        ClientInfo info = (PackUtilLANSync.ClientInfo)this.connectedClients.get(username);
        return info != null ? info.delayOffsetMs : 0;
    }
}
