/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketInspector;

private static final record PackUtilPacketInspector.PropertyValue {
    private final String label;
    private final Object value;
    private final PackUtilPacketInspector.PropertySource source;

    private PackUtilPacketInspector.PropertyValue(String label, Object value, PackUtilPacketInspector.PropertySource source) {
        this.label = label;
        this.value = value;
        this.source = source;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String label() {
        return this.label;
    }

    public Object value() {
        return this.value;
    }

    public PackUtilPacketInspector.PropertySource source() {
        return this.source;
    }
}
