/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilSharedState;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_10938;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_7225;
import net.minecraft.class_7887;
import net.minecraft.class_7923;
import sun.misc.Unsafe;

public class PackUtilClipboardHelper {
    private static final int CLIPBOARD_VERSION = 1;
    private static final String MACRO_CLIPBOARD_TYPE = "packutil_macro";

    public static void copyToClipboard(List<PackUtilSharedState.QueuedPacket> queue) {
        try {
            class_2487 rootTag = new class_2487();
            class_2499 packetList = new class_2499();
            ByteArrayOutputStream outputStream = queue.iterator();
            while (outputStream.hasNext()) {
                QueuedPacket qp = (PackUtilSharedState.QueuedPacket)outputStream.next();
                class_2487 packetTag = PackUtilClipboardHelper.serializeQueuedPacket(qp);
                if (packetTag == null) continue;
                packetList.add(packetTag);
            }
            rootTag.method_10566("packets", packetList);
            rootTag.method_10569("version", 1);
            outputStream = new ByteArrayOutputStream();
            class_2507.method_10634(rootTag, outputStream);
            base64 = Base64.getEncoder().encodeToString(outputStream.toByteArray());
            class_310.method_1551().field_1774.method_1455(base64);
            YungLightAddon.LOG.info("[PackUtil] Copied {} packets to clipboard", queue.size());
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to copy packets to clipboard", e);
            L150: ;
            return;
        }
    }

    public static boolean copyMacroToClipboard(PackUtilMacro macro) {
        if (macro == null) {
            return false;
        }
        try {
            class_2487 rootTag = new class_2487();
            rootTag.method_10569("version", 1);
            rootTag.method_10582("type", "packutil_macro");
            rootTag.method_10566("macro", macro.toTag());
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            class_2507.method_10634(rootTag, outputStream);
            String base64 = Base64.getEncoder().encodeToString(outputStream.toByteArray());
            class_310.method_1551().field_1774.method_1455(base64);
            YungLightAddon.LOG.info("[PackUtil] Copied macro '{}' to clipboard", macro.name);
            return true;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to copy macro to clipboard", e);
            return false;
        }
    }

    public static PackUtilMacro pasteMacroFromClipboard() {
        try {
            String base64 = class_310.method_1551().field_1774.method_1460();
            if (base64 == null || base64.trim().isEmpty()) {
                YungLightAddon.LOG.warn("[PackUtil] Macro clipboard is empty");
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste macro from clipboard", e);
            return null;
        }
        try {
            byte[] data = Base64.getDecoder().decode(base64.trim());
            ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
            class_2487 rootTag = class_2507.method_10629(inputStream, class_2505.method_53898());
            int version = rootTag.method_68083("version", 0);
            if (version != 1) {
                YungLightAddon.LOG.error("[PackUtil] Unsupported macro clipboard version: {}", version);
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste macro from clipboard", e);
            return null;
        }
        try {
            String type = rootTag.method_68564("type", "");
            if (!"packutil_macro".equals(type)) {
                YungLightAddon.LOG.warn("[PackUtil] Clipboard data is not a PackUtil macro payload");
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste macro from clipboard", e);
            return null;
        }
        try {
            class_2487 macroTag = (class_2487)rootTag.method_10562("macro").orElse(new class_2487());
            if (macroTag.method_33133()) {
                YungLightAddon.LOG.warn("[PackUtil] Macro clipboard payload was empty");
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste macro from clipboard", e);
            return null;
        }
        try {
            return new PackUtilMacro().fromTag(macroTag);
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste macro from clipboard", e);
            return null;
        }
    }

    public static List<PackUtilSharedState.QueuedPacket> pasteFromClipboard() {
        try {
            String base64 = class_310.method_1551().field_1774.method_1460();
            if (base64 == null || base64.trim().isEmpty()) {
                YungLightAddon.LOG.warn("[PackUtil] Clipboard is empty");
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste packets from clipboard", e);
            return null;
        }
        try {
            byte[] data = Base64.getDecoder().decode(base64.trim());
            ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
            class_2487 rootTag = class_2507.method_10629(inputStream, class_2505.method_53898());
            int version = rootTag.method_68083("version", 0);
            if (version != 1) {
                YungLightAddon.LOG.error("[PackUtil] Unsupported clipboard format version: {}", version);
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste packets from clipboard", e);
            return null;
        }
        try {
            class_2499 packetList = (class_2499)rootTag.method_10580("packets");
            List<PackUtilSharedState.QueuedPacket> queue = new ArrayList();
            for (int i = 0; i < packetList.size(); i++) {
                class_2487 packetTag = (class_2487)packetList.get(i);
                QueuedPacket qp = PackUtilClipboardHelper.deserializeQueuedPacket(packetTag);
                if (qp == null) continue;
                queue.add(qp);
            }
            YungLightAddon.LOG.info("[PackUtil] Pasted {} packets from clipboard", queue.size());
            return queue.isEmpty() ? null : queue;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to paste packets from clipboard", e);
            return null;
        }
    }

    public static class_2596<?> deserializePacketFromBase64(String base64) {
        try {
            if (base64 == null || base64.trim().isEmpty()) {
                return null;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize packet from Base64", e);
            return null;
        }
        try {
            data = Base64.getDecoder().decode(base64.trim());
            ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
            class_2487 tag = class_2507.method_10629(inputStream, class_2505.method_53898());
            if (!tag.method_10545("packets")) { /* goto @113; */ }
            class_2499 list = (class_2499)tag.method_10580("packets");
            if (list == null) { /* goto @110; */ }
            if (list.isEmpty()) { /* goto @110; */ }
            class_2487 packetTag = (class_2487)list.get(0);
            QueuedPacket qp = PackUtilClipboardHelper.deserializeQueuedPacket(packetTag);
            return qp != null ? qp.packet : null;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize packet from Base64", e);
            return null;
        }
        try {
            /* goto @149; */
            L113: ;
            if (!tag.method_10545("packet")) { /* goto @144; */ }
            qp = PackUtilClipboardHelper.deserializeQueuedPacket(tag);
            return qp != null ? qp.packet : null;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize packet from Base64", e);
            return null;
        }
        try {
            return PackUtilClipboardHelper.deserializePacket(tag);
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize packet from Base64", e);
            return null;
        }
        try {
            return null;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize packet from Base64", e);
            return null;
        }
    }

    public static class_2487 serializeQueuedPacket(PackUtilSharedState.QueuedPacket qp) {
        try {
            class_2487 tag = new class_2487();
            tag.method_10569("delay", qp.getDelay());
            tag.method_10569("id", qp.getId());
            class_2487 packetData = PackUtilClipboardHelper.serializePacket(qp.packet);
            if (packetData != null) {
                tag.method_10566("packet", packetData);
                return tag;
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to serialize queued packet", e);
            return null;
        }
        try {
            return null;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to serialize queued packet", e);
            return null;
        }
    }

    public static PackUtilSharedState.QueuedPacket deserializeQueuedPacket(class_2487 tag) {
        try {
            int delay = tag.method_68083("delay", 0);
            int id = tag.method_68083("id", 0);
            class_2487 packetData = (class_2487)tag.method_10562("packet").orElse(new class_2487());
            class_2596<?> packet = PackUtilClipboardHelper.deserializePacket(packetData);
            if (packet == null) { /* goto @79; */ }
            return id > 0 ? new PackUtilSharedState.QueuedPacket(packet, delay, id) : new PackUtilSharedState.QueuedPacket(packet, delay);
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize queued packet", e);
            return null;
        }
        try {
            return null;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize queued packet", e);
            return null;
        }
    }

    private static class_2487 serializePacket(class_2596<?> packet) {
        class_2487 tag = new class_2487();
        String className = packet.getClass().getName();
        tag.method_10582("class", className);
        String friendlyName = PackUtilPacketRegistry.getName(packet.getClass());
        if (friendlyName != null) {
            tag.method_10582("friendlyName", friendlyName);
        }
        class_2487 fieldsTag = new class_2487();
        PackUtilClipboardHelper.serializeFields(packet, fieldsTag);
        tag.method_10566("fields", fieldsTag);
        return tag;
    }

    private static class_2596<?> deserializePacket(class_2487 tag) {
        String className = tag.method_68564("class", "");
        Class<?> packetClass = null;
        packetClass = Class.forName(className);
        /* goto L50; */
        ClassNotFoundException e = null;
        if (tag.method_10545("friendlyName")) {
            String friendlyName = tag.method_68564("friendlyName", "");
            packetClass = PackUtilPacketRegistry.getPacket(friendlyName);
        }
        if (packetClass == null) {
            YungLightAddon.LOG.error("[PackUtil] Could not find packet class: {}", className);
            return null;
        }
        fieldsTag = (class_2487)tag.method_10562("fields").orElse(new class_2487());
        if (packetClass.isRecord()) {
            return (class_2596)PackUtilClipboardHelper.deserializeRecord(packetClass, fieldsTag);
        }
        packet = (class_2596)PackUtilClipboardHelper.getUnsafe().allocateInstance(packetClass);
        PackUtilClipboardHelper.deserializeFields(packet, fieldsTag);
        if (!PackUtilPacketRegistry.getC2SPackets().contains(packetClass)) {
            YungLightAddon.LOG.warn("[PackUtil] Deserialized packet {} is NOT a registered C2S packet! It may be skipped when sending.", className);
        }
        return packet;
    }

    private static void serializeFields(Object obj, class_2487 fieldsTag) {
        Class<?> clazz = obj.getClass();
        while (clazz != null) {
            if (clazz == Object.class) { /* goto @132; */ }
            var var3 = clazz.getDeclaredFields();
            var var4 = var3.length;
            int var5 = 0;
            L27: ;
            if (var5 >= var4) { /* goto @124; */ }
            Field field = var3[var5];
            if (Modifier.isStatic(field.getModifiers())) { /* goto @118; */ }
            if (Modifier.isTransient(field.getModifiers())) {
            } else {
                field.setAccessible(true);
            }
            try {
                Object value = field.get(obj);
                PackUtilClipboardHelper.serializeField(fieldsTag, field.getName(), value, field.getType());
            }
            catch (Exception e) {
                YungLightAddon.LOG.warn("[PackUtil] Failed to serialize field: {}", field.getName(), e);
                L118: ;
                var5++;
                /* goto @27; */
                L124: ;
                clazz = clazz.getSuperclass();
            }
            var5++;
            /* goto @27; */
            L124: ;
            clazz = clazz.getSuperclass();
        }
    }

    private static void serializeField(class_2487 tag, String name, Object value, Class<?> type) {
        if (value == null) {
            tag.method_10556(name + "_null", true);
            return;
        }
        tag.method_10582(name + "_type", value.getClass().getName());
        if (value instanceof class_1799) {
            class_1799 stack = (class_1799)value;
            if (!stack.method_7960()) {
                class_2487 stackNbt = new class_2487();
            }
        }
        try {
            class_2520 encoded = (class_2520)class_1799.field_24671.encodeStart(PackUtilClipboardHelper.getRegistryManager().method_57093(class_2509.field_11560), stack).getOrThrow();
            tag.method_10566(name, encoded);
        }
        catch (Exception e) {
            stackNbt.method_10582("id", class_7923.field_41178.method_10221(stack.method_7909()).toString());
            stackNbt.method_10569("count", stack.method_7947());
            tag.method_10566(name, stackNbt);
            L152: ;
            /* goto @166; */
        }
        /* goto L166; */
        L155: ;
        tag.method_10556(name + "_empty", true);
        L166: ;
        /* goto @931; */
        L169: ;
        if (value instanceof class_2487) {
            tag.method_10566(name, (class_2487)value);
        } else {
            if (value instanceof class_2520) {
                tag.method_10566(name, (class_2520)value);
            } else {
                if (value instanceof class_2338) {
                    tag.method_10544(name, ((class_2338)value).method_10063());
                } else {
                    if (value instanceof class_2960) {
                        tag.method_10582(name, value.toString());
                    } else {
                        if (value instanceof class_2561) {
                            tag.method_10582(name, ((class_2561)value).getString());
                        } else {
                            if (value instanceof String) {
                                tag.method_10582(name, (String)value);
                            } else {
                                if (value instanceof Integer) {
                                    tag.method_10569(name, ((Integer)value).intValue());
                                } else {
                                    if (value instanceof Boolean) {
                                        tag.method_10556(name, ((Boolean)value).booleanValue());
                                    } else {
                                        if (value instanceof Long) {
                                            tag.method_10544(name, ((Long)value).longValue());
                                        } else {
                                            if (value instanceof Float) {
                                                tag.method_10548(name, ((Float)value).floatValue());
                                            } else {
                                                if (value instanceof Double) {
                                                    tag.method_10549(name, ((Double)value).doubleValue());
                                                } else {
                                                    if (value instanceof Byte) {
                                                        tag.method_10567(name, ((Byte)value).byteValue());
                                                    } else {
                                                        if (value instanceof Short) {
                                                            tag.method_10575(name, ((Short)value).shortValue());
                                                        } else {
                                                            if (value instanceof byte[]) {
                                                                tag.method_10570(name, (byte[])value);
                                                            } else {
                                                                if (value instanceof int[]) {
                                                                    tag.method_10539(name, (int[])value);
                                                                } else {
                                                                    if (value instanceof long[]) {
                                                                        tag.method_10564(name, (long[])value);
                                                                    } else {
                                                                        if (value instanceof Enum) {
                                                                            tag.method_10582(name, ((Enum)value).name());
                                                                            tag.method_10582(name + "_enumClass", value.getClass().getName());
                                                                        } else {
                                                                            if (value instanceof Instant) {
                                                                                tag.method_10544(name, ((Instant)value).toEpochMilli());
                                                                            } else {
                                                                                if (value instanceof UUID) {
                                                                                    uuid = (UUID)value;
                                                                                    tag.method_10544(name + "_mostSig", uuid.getMostSignificantBits());
                                                                                    tag.method_10544(name + "_leastSig", uuid.getLeastSignificantBits());
                                                                                } else {
                                                                                    if (value instanceof Optional) {
                                                                                        opt = (Optional)value;
                                                                                        if (opt.isPresent()) {
                                                                                            PackUtilClipboardHelper.serializeField(tag, name + "_value", opt.get(), opt.get().getClass());
                                                                                            tag.method_10556(name + "_present", true);
                                                                                        } else {
                                                                                            tag.method_10556(name + "_present", false);
                                                                                        }
                                                                                    } else {
                                                                                        if (value instanceof BitSet) {
                                                                                            bitSet = (BitSet)value;
                                                                                            tag.method_10564(name, bitSet.toLongArray());
                                                                                        } else {
                                                                                            if (value instanceof class_243) {
                                                                                                vec = (class_243)value;
                                                                                                tag.method_10549(name + "_x", vec.field_1352);
                                                                                                tag.method_10549(name + "_y", vec.field_1351);
                                                                                                tag.method_10549(name + "_z", vec.field_1350);
                                                                                            } else {
                                                                                                if (value instanceof class_3965) {
                                                                                                    hit = (class_3965)value;
                                                                                                    PackUtilClipboardHelper.serializeField(tag, name + "_pos", hit.method_17784(), class_243.class);
                                                                                                    tag.method_10582(name + "_side", hit.method_17780().name());
                                                                                                    PackUtilClipboardHelper.serializeField(tag, name + "_blockPos", hit.method_17777(), class_2338.class);
                                                                                                    tag.method_10556(name + "_insideBlock", hit.method_17781());
                                                                                                } else {
                                                                                                    if (value instanceof Int2ObjectMap) {
                                                                                                        PackUtilClipboardHelper.serializeInt2ObjectMap(tag, name, (Int2ObjectMap)value);
                                                                                                    } else {
                                                                                                        if (value instanceof Map) {
                                                                                                            PackUtilClipboardHelper.serializeMap(tag, name, (Map)value);
                                                                                                        } else {
                                                                                                            if (!value instanceof List) { /* goto @912; */ }
                                                                                                            PackUtilClipboardHelper.serializeList(tag, name, (List)value);
                                                                                                            /* goto @931; */
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        try {
            tag.method_10582(name + "_toString", value.toString());
        }
        catch (Exception hit) {
            return;
        }
    }

    private static void serializeInt2ObjectMap(class_2487 tag, String name, Int2ObjectMap<?> map) {
        class_2487 mapTag = new class_2487();
        int index = 0;
        var var5 = map.int2ObjectEntrySet().iterator();
        while (var5.hasNext()) {
            Int2ObjectMap.Entry<?> entry = (Int2ObjectMap.Entry)var5.next();
            String entryName = "entry_" + index++;
            class_2487 entryTag = new class_2487();
            int key = entry.getIntKey();
            Object val = entry.getValue();
            entryTag.method_10569("key", key);
            if (val == null) continue;
            PackUtilClipboardHelper.serializeField(entryTag, "value", val, val.getClass());
            mapTag.method_10566(entryName, entryTag);
        }
        mapTag.method_10569("size", map.size());
        tag.method_10566(name, mapTag);
    }

    private static void serializeMap(class_2487 tag, String name, Map<?, ?> map) {
        class_2487 mapTag = new class_2487();
        int index = 0;
        var var5 = map.entrySet().iterator();
        while (var5.hasNext()) {
            Map.Entry<?, ?> entry = (Map.Entry)var5.next();
            String entryName = "entry_" + index++;
            class_2487 entryTag = new class_2487();
            Object key = entry.getKey();
            Object val = entry.getValue();
            if (key == null) continue;
            PackUtilClipboardHelper.serializeField(entryTag, "key", key, key.getClass());
            if (val == null) continue;
            PackUtilClipboardHelper.serializeField(entryTag, "value", val, val.getClass());
            mapTag.method_10566(entryName, entryTag);
        }
        mapTag.method_10569("size", map.size());
        tag.method_10566(name, mapTag);
    }

    private static void serializeList(class_2487 tag, String name, List<?> list) {
        class_2499 listTag = new class_2499();
        var var4 = list.iterator();
        while (var4.hasNext()) {
            Object item = var4.next();
            if (item != null) {
                class_2487 itemTag = new class_2487();
                PackUtilClipboardHelper.serializeField(itemTag, "value", item, item.getClass());
                listTag.add(itemTag);
            }
        }
        tag.method_10566(name, listTag);
        tag.method_10569(name + "_size", list.size());
    }

    private static void deserializeFields(Object obj, class_2487 fieldsTag) {
        Class<?> clazz = obj.getClass();
        L5: ;
        if (clazz == null) { /* goto @440; */ }
        if (clazz == Object.class) { /* goto @440; */ }
        var var3 = clazz.getDeclaredFields();
        var var4 = var3.length;
        int var5 = 0;
        L27: ;
        if (var5 >= var4) { /* goto @432; */ }
        Field field = var3[var5];
        if (Modifier.isStatic(field.getModifiers())) { /* goto @426; */ }
        if (Modifier.isTransient(field.getModifiers())) {
        } else {
            field.setAccessible(true);
            String fieldName = field.getName();
            if (!fieldsTag.method_10545(fieldName + "_null")) { /* goto @95; */ }
            /* goto @426; */
        }
        try {
            Object value = PackUtilClipboardHelper.deserializeField(fieldsTag, fieldName, field.getType());
            if (value != null) {
                long offset = PackUtilClipboardHelper.getUnsafe().objectFieldOffset(field);
                Class<?> type = field.getType();
                if (type == Integer.TYPE) {
                    PackUtilClipboardHelper.getUnsafe().putInt(obj, offset, ((Integer)value).intValue());
                } else {
                    if (type == Boolean.TYPE) {
                        PackUtilClipboardHelper.getUnsafe().putBoolean(obj, offset, ((Boolean)value).booleanValue());
                    } else {
                        if (type == Byte.TYPE) {
                            PackUtilClipboardHelper.getUnsafe().putByte(obj, offset, ((Byte)value).byteValue());
                        } else {
                            if (type == Short.TYPE) {
                                PackUtilClipboardHelper.getUnsafe().putShort(obj, offset, ((Short)value).shortValue());
                            } else {
                                if (type == Long.TYPE) {
                                    PackUtilClipboardHelper.getUnsafe().putLong(obj, offset, ((Long)value).longValue());
                                } else {
                                    if (type == Float.TYPE) {
                                        PackUtilClipboardHelper.getUnsafe().putFloat(obj, offset, ((Float)value).floatValue());
                                    } else {
                                        if (type == Double.TYPE) {
                                            PackUtilClipboardHelper.getUnsafe().putDouble(obj, offset, ((Double)value).doubleValue());
                                        } else {
                                            if (type == Character.TYPE) {
                                                PackUtilClipboardHelper.getUnsafe().putChar(obj, offset, ((Character)value).charValue());
                                            } else {
                                                PackUtilClipboardHelper.getUnsafe().putObject(obj, offset, value);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Object defaultValue = PackUtilClipboardHelper.getSafeDefault(field.getType(), fieldName);
                if (defaultValue != null) {
                    long offset = PackUtilClipboardHelper.getUnsafe().objectFieldOffset(field);
                    PackUtilClipboardHelper.getUnsafe().putObject(obj, offset, defaultValue);
                }
            }
        }
        catch (Exception e) {
            YungLightAddon.LOG.warn("[PackUtil] Failed to deserialize field: {}", fieldName, e);
            L426: ;
            var5++;
            /* goto @27; */
            L432: ;
            clazz = clazz.getSuperclass();
            /* goto @5; */
            L440: ;
            return;
        }
        var5++;
        /* goto @27; */
        L432: ;
        clazz = clazz.getSuperclass();
        /* goto @5; */
        L440: ;
    }

    private static Object deserializeField(class_2487 tag, String name, Class<?> targetType) {
        if (!tag.method_10545(name + "_type") && !tag.method_10545(name)) {
            return null;
        }
        if (tag.method_10545(name + "_empty") && tag.method_68566(name + "_empty", false)) {
            return class_1799.field_8037;
        }
        String typeName = tag.method_10545(name + "_type") ? tag.method_68564(name + "_type", "") : null;
        if (targetType != class_1799.class) {
            if (typeName == null) { /* goto @173; */ }
        }
        try {
            class_2520 stackNbt = tag.method_10580(name);
            if (stackNbt == null) {
                return class_1799.field_8037;
            }
        }
        catch (Exception e) {
            return class_1799.field_8037;
        }
        try {
            return class_1799.field_24671.parse(PackUtilClipboardHelper.getRegistryManager().method_57093(class_2509.field_11560), stackNbt).result().orElse(class_1799.field_8037);
        }
        catch (Exception e) {
            return class_1799.field_8037;
        }
        return class_1799.field_8037;
        L173: ;
        if (targetType == class_2487.class) {
            return tag.method_10562(name).orElse(new class_2487());
        }
        if (targetType == class_2520.class) {
            return tag.method_10580(name);
        }
        if (targetType == class_2338.class) {
            return class_2338.method_10092(tag.method_68080(name, 0L));
        }
        if (targetType == class_2960.class) {
            return class_2960.method_60654(tag.method_68564(name, ""));
        }
        if (targetType == class_2561.class) {
            return class_2561.method_30163(tag.method_68564(name, ""));
        }
        if (targetType == String.class) {
            return tag.method_68564(name, "");
        }
        if (targetType == Integer.class || targetType == Integer.TYPE) {
            return tag.method_68083(name, 0);
        }
        if (targetType == Boolean.class || targetType == Boolean.TYPE) {
            return tag.method_68566(name, false);
        }
        if (targetType == Long.class || targetType == Long.TYPE) {
            return tag.method_68080(name, 0L);
        }
        if (targetType == Float.class || targetType == Float.TYPE) {
            return tag.method_66563(name, 0f);
        }
        if (targetType == Double.class || targetType == Double.TYPE) {
            return tag.method_68563(name, 0);
        }
        if (targetType == Byte.class || targetType == Byte.TYPE) {
            return tag.method_68562(name, 0);
        }
        if (targetType == Short.class || targetType == Short.TYPE) {
            return tag.method_68565(name, 0);
        }
        if (targetType == byte[].class) {
            return tag.method_10547(name).orElse(new byte[0]);
        }
        if (targetType == int[].class) {
            return tag.method_10561(name).orElse(new int[0]);
        }
        if (targetType == long[].class) {
            return tag.method_10565(name).orElse(new long[0]);
        }
        if (targetType.isEnum()) {
            enumName = tag.method_68564(name, "");
        }
        try {
            Enum<?> enumValue = Enum.valueOf(targetType, enumName);
            return enumValue;
        }
        catch (Exception e) {
            return null;
        }
        if (targetType == Instant.class) {
            epochMilli = tag.method_68080(name, System.currentTimeMillis());
            return Instant.ofEpochMilli(epochMilli);
        }
        if (targetType == UUID.class) {
            if (tag.method_10545(name + "_mostSig")) {
                mostSig = tag.method_68080(name + "_mostSig", 0L);
                long leastSig = tag.method_68080(name + "_leastSig", 0L);
                return new UUID(mostSig, leastSig);
            }
            return new UUID(0L, 0L);
        }
        if (targetType == Optional.class || Optional.class.isAssignableFrom(targetType)) {
            if (tag.method_68566(name + "_present", false)) {
                value = PackUtilClipboardHelper.deserializeField(tag, name + "_value", Object.class);
                return Optional.ofNullable(value);
            }
            return Optional.empty();
        }
        if (targetType == BitSet.class) {
            longs = (long[])tag.method_10565(name).orElse(new long[0]);
            return BitSet.valueOf(longs);
        }
        if (targetType == class_243.class) {
            x = tag.method_68563(name + "_x", 0);
            y = tag.method_68563(name + "_y", 0);
            double z = tag.method_68563(name + "_z", 0);
            return new class_243(x, y, z);
        }
        if (targetType == class_3965.class) {
            pos = (class_243)PackUtilClipboardHelper.deserializeField(tag, name + "_pos", class_243.class);
            if (pos == null) {
                pos = class_243.field_1353;
            }
            sideName = tag.method_68564(name + "_side", "UP");
        }
        try {
            side = class_2350.valueOf(sideName);
        }
        catch (IllegalArgumentException e) {
            side = class_2350.field_11036;
            L836: ;
            blockPos = (class_2338)PackUtilClipboardHelper.deserializeField(tag, name + "_blockPos", class_2338.class);
            if (blockPos == null) {
                blockPos = class_2338.field_10980;
            }
            insideBlock = tag.method_68566(name + "_insideBlock", false);
            return new class_3965(pos, side, blockPos, insideBlock);
        }
        blockPos = (class_2338)PackUtilClipboardHelper.deserializeField(tag, name + "_blockPos", class_2338.class);
        if (blockPos == null) {
            blockPos = class_2338.field_10980;
        }
        insideBlock = tag.method_68566(name + "_insideBlock", false);
        return new class_3965(pos, side, blockPos, insideBlock);
        L893: ;
        if (targetType == class_10938.class) {
            return class_10938.field_58176;
        }
        if (Int2ObjectMap.class.isAssignableFrom(targetType)) {
            return PackUtilClipboardHelper.deserializeInt2ObjectMap((class_2487)tag.method_10562(name).orElse(new class_2487()));
        }
        if (Map.class.isAssignableFrom(targetType)) {
            return PackUtilClipboardHelper.deserializeMap((class_2487)tag.method_10562(name).orElse(new class_2487()));
        }
        if (List.class.isAssignableFrom(targetType)) {
            return PackUtilClipboardHelper.deserializeList((class_2499)tag.method_10580(name));
        }
        if (tag.method_10545(name + "_toString")) {
            return null;
        }
        return null;
    }

    private static Int2ObjectMap<Object> deserializeInt2ObjectMap(class_2487 mapTag) {
        Int2ObjectMap<Object> map = new Int2ObjectArrayMap();
        int size = mapTag.method_68083("size", 0);
        for (int i = 0; i < size; i++) {
            String entryName = "entry_" + i;
            if (mapTag.method_10545(entryName)) {
                class_2487 entryTag = (class_2487)mapTag.method_10562(entryName).orElse(new class_2487());
                int key = entryTag.method_68083("key", 0);
                Object value = PackUtilClipboardHelper.deserializeField(entryTag, "value", Object.class);
                if (value == null) continue;
                map.put(key, value);
            }
        }
        return map;
    }

    private static Map<Object, Object> deserializeMap(class_2487 mapTag) {
        Map<Object, Object> map = new HashMap();
        int size = mapTag.method_68083("size", 0);
        for (int i = 0; i < size; i++) {
            String entryName = "entry_" + i;
            if (mapTag.method_10545(entryName)) {
                class_2487 entryTag = (class_2487)mapTag.method_10562(entryName).orElse(new class_2487());
                Object key = PackUtilClipboardHelper.deserializeField(entryTag, "key", Object.class);
                Object value = PackUtilClipboardHelper.deserializeField(entryTag, "value", Object.class);
                if (key == null) continue;
                map.put(key, value);
            }
        }
        return map;
    }

    private static List<Object> deserializeList(class_2499 listTag) {
        List<Object> list = new ArrayList();
        for (int i = 0; i < listTag.size(); i++) {
            class_2487 itemTag = (class_2487)listTag.get(i);
            Object value = PackUtilClipboardHelper.deserializeField(itemTag, "value", Object.class);
            if (value == null) continue;
            list.add(value);
        }
        return list;
    }

    private static class_7225.class_7874 getRegistryManager() {
        if (class_310.method_1551().field_1687 != null) {
            return class_310.method_1551().field_1687.method_30349();
        }
        if (class_310.method_1551().method_1562() != null) {
            return class_310.method_1551().method_1562().method_29091();
        }
        return class_7887.method_46817();
    }

    private static Unsafe getUnsafe() {
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            return (Unsafe)f.get(null);
        }
        catch (Exception e) {
            throw new RuntimeException("Cannot access Unsafe", e);
        }
    }

    private static Object deserializeRecord(Class<?> recordClass, class_2487 fieldsTag) throws Exception {
        RecordComponent[] components = recordClass.getRecordComponents();
        Class<?>[] paramTypes = new Class[components.length];
        Object[] args = new Object[components.length];
        for (int i = 0; i < components.length; i++) {
            RecordComponent component = components[i];
            paramTypes[i] = component.getType();
            String name = component.getName();
            Object value = PackUtilClipboardHelper.deserializeField(fieldsTag, name, component.getType());
            if (value != null) { /* goto L240; */ }
            if (component.getType() == Integer.TYPE) {
                value = 0;
            } else {
                if (component.getType() == Boolean.TYPE) {
                    value = false;
                } else {
                    if (component.getType() == Byte.TYPE) {
                        value = 0;
                    } else {
                        if (component.getType() == Short.TYPE) {
                            value = 0;
                        } else {
                            if (component.getType() == Long.TYPE) {
                                value = 0L;
                            } else {
                                if (component.getType() == Float.TYPE) {
                                    value = 0f;
                                } else {
                                    if (component.getType() == Double.TYPE) {
                                        value = 0;
                                    } else {
                                        if (component.getType() == Character.TYPE) {
                                            value = 0;
                                        } else {
                                            value = PackUtilClipboardHelper.getSafeDefault(component.getType(), name);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            args[i] = value;
        }
        constructor = recordClass.getDeclaredConstructor(paramTypes);
        constructor.setAccessible(true);
        return constructor.newInstance(args);
    }

    private static Object getSafeDefault(Class<?> type, String fieldName) {
        Field emptyField = type.getDeclaredField("EMPTY");
        if (Modifier.isStatic(emptyField.getModifiers())) {
            emptyField.setAccessible(true);
            Object empty = emptyField.get(null);
            if (empty != null) {
                YungLightAddon.LOG.warn("[PackUtil] Using {}.EMPTY for unsupported field: {}", type.getSimpleName(), fieldName);
                return empty;
            }
        }
        /* goto L55; */
        defaultField = null;
        L55: ;
        defaultField = type.getDeclaredField("DEFAULT");
        if (Modifier.isStatic(defaultField.getModifiers())) {
            defaultField.setAccessible(true);
            defaultValue = defaultField.get(null);
            if (defaultValue != null) {
                YungLightAddon.LOG.warn("[PackUtil] Using {}.DEFAULT for unsupported field: {}", type.getSimpleName(), fieldName);
                return defaultValue;
            }
        }
        /* goto L110; */
        components = null;
        L110: ;
        if (!type.isRecord()) { /* goto L397; */ }
        components = type.getRecordComponents();
        paramTypes = new Class[components.length];
        Object[] args = new Object[components.length];
        for (int i = 0; i < components.length; i++) {
            paramTypes[i] = components[i].getType();
            if (paramTypes[i] == byte[].class) {
                args[i] = new byte[0];
            } else {
                if (paramTypes[i] == BitSet.class) {
                    args[i] = new BitSet();
                } else {
                    if (paramTypes[i] == class_243.class) {
                        args[i] = class_243.field_1353;
                    } else {
                        if (paramTypes[i] == class_3965.class) {
                            args[i] = class_3965.method_17778(class_243.field_1353, class_2350.field_11036, class_2338.field_10980);
                        } else {
                            if (paramTypes[i].isPrimitive()) {
                                args[i] = PackUtilClipboardHelper.getPrimitiveDefault(paramTypes[i]);
                            } else {
                                if (paramTypes[i].isRecord()) {
                                    args[i] = PackUtilClipboardHelper.getSafeDefault(paramTypes[i], components[i].getName());
                                    /* goto @350; */
                                    Exception e = null;
                                    YungLightAddon.LOG.warn("[PackUtil] Failed to create nested Record {}: {}", paramTypes[i].getSimpleName(), e.getMessage());
                                    args[i] = null;
                                } else {
                                    args[i] = null;
                                }
                            }
                        }
                    }
                }
            }
        }
        constructor = type.getDeclaredConstructor(paramTypes);
        constructor.setAccessible(true);
        Object instance = constructor.newInstance(args);
        YungLightAddon.LOG.warn("[PackUtil] Created default {} for unsupported field: {}", type.getSimpleName(), fieldName);
        return instance;
        L397: ;
        /* goto L420; */
        e = null;
        YungLightAddon.LOG.warn("[PackUtil] Could not create safe default for {}: {}", type.getSimpleName(), e.getMessage());
        L420: ;
        YungLightAddon.LOG.error("[PackUtil] No safe default found for unsupported type: {} field: {}", type.getSimpleName(), fieldName);
        return null;
    }

    private static Object getPrimitiveDefault(Class<?> type) {
        if (type == Integer.TYPE) {
            return 0;
        }
        if (type == Boolean.TYPE) {
            return false;
        }
        if (type == Byte.TYPE) {
            return 0;
        }
        if (type == Short.TYPE) {
            return 0;
        }
        if (type == Long.TYPE) {
            return 0L;
        }
        if (type == Float.TYPE) {
            return 0f;
        }
        if (type == Double.TYPE) {
            return 0;
        }
        if (type == Character.TYPE) {
            return 0;
        }
        return null;
    }

    public static String serializeQueueToBase64(List<PackUtilSharedState.QueuedPacket> queue) {
        try {
            class_2487 rootTag = new class_2487();
            class_2499 packetList = new class_2499();
            ByteArrayOutputStream outputStream = queue.iterator();
            while (outputStream.hasNext()) {
                QueuedPacket qp = (PackUtilSharedState.QueuedPacket)outputStream.next();
                class_2487 packetTag = PackUtilClipboardHelper.serializeQueuedPacket(qp);
                if (packetTag == null) continue;
                packetList.add(packetTag);
            }
            rootTag.method_10566("packets", packetList);
            rootTag.method_10569("version", 1);
            outputStream = new ByteArrayOutputStream();
            class_2507.method_10634(rootTag, outputStream);
            return Base64.getEncoder().encodeToString(outputStream.toByteArray());
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to serialize queue to Base64", e);
            return null;
        }
    }

    public static List<PackUtilSharedState.QueuedPacket> deserializeQueueFromBase64(String base64) {
        try {
            byte[] compressed = Base64.getDecoder().decode(base64);
            ByteArrayInputStream inputStream = new ByteArrayInputStream(compressed);
            class_2487 rootTag = class_2507.method_10629(inputStream, class_2505.method_53898());
            class_2499 packetList = (class_2499)rootTag.method_10554("packets").orElse(new class_2499());
            List<PackUtilSharedState.QueuedPacket> queue = new ArrayList();
            for (int i = 0; i < packetList.size(); i++) {
                class_2487 packetTag = (class_2487)packetList.get(i);
                QueuedPacket qp = PackUtilClipboardHelper.deserializeQueuedPacket(packetTag);
                if (qp == null) continue;
                queue.add(qp);
            }
            YungLightAddon.LOG.info("[PackUtil] Deserialized {} packets from Base64", queue.size());
            return queue.isEmpty() ? null : queue;
        }
        catch (Exception e) {
            YungLightAddon.LOG.error("[PackUtil] Failed to deserialize queue from Base64", e);
            return null;
        }
    }
}
