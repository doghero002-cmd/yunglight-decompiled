/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.macro.MacroAction;

private static final class PackUtilMacroEditorOverlay.StepRowSnapshot {
    private final MacroAction action;
    private final int stableId;
    private final String label;
    private final boolean conditional;
    private final int index;

    private PackUtilMacroEditorOverlay.StepRowSnapshot(MacroAction action, int stableId, String label, boolean conditional, int index) {
        this.action = action;
        this.stableId = stableId;
        this.label = label;
        this.conditional = conditional;
        this.index = index;
    }
}
