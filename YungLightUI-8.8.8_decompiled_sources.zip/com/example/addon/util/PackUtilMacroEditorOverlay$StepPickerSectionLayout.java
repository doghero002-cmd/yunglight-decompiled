/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilMacroEditorOverlay;
import java.util.List;

private static final class PackUtilMacroEditorOverlay.StepPickerSectionLayout {
    private final PackUtilMacroEditorOverlay.StepPickerCategory category;
    private final int headerY;
    private final List<PackUtilMacroEditorOverlay.StepPickerButtonLayout> buttons;
    private final int bottomY;

    private PackUtilMacroEditorOverlay.StepPickerSectionLayout(PackUtilMacroEditorOverlay.StepPickerCategory category, int headerY, List<PackUtilMacroEditorOverlay.StepPickerButtonLayout> buttons, int bottomY) {
        this.category = category;
        this.headerY = headerY;
        this.buttons = buttons;
        this.bottomY = bottomY;
    }
}
