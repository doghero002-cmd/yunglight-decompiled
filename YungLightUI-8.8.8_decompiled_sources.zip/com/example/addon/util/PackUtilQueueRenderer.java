/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiHudPanelRenderer;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilSharedState;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUtilQueueRenderer {
    private static final PackUiTheme THEME = new PackUiTheme();
    private static final long CACHE_REFRESH_NANOS = 50000000L;
    private static final int ENTRY_COLOR = -1581859;
    private static final int ENTRY_SENDING_COLOR = -601459;
    private static final int STATUS_COLOR = -6366544;
    private static final int ACTIVE_ACCENT_COLOR = -9184882;
    private static final class_2960 MUTED_FONT = THEME.fontFor(PackUiTone.MUTED);
    private static final class_2960 BODY_FONT = THEME.fontFor(PackUiTone.BODY);
    private static final class_2960 LABEL_FONT = THEME.fontFor(PackUiTone.LABEL);
    private static final int MUTED_COLOR = THEME.color(PackUiTone.MUTED);
    private static final int HEADER_COLOR = THEME.color(PackUiTone.BODY);
    private static boolean cachedSending;
    private static String cachedModeStr = null;
    private static int cachedMaxLines = -2147483648;
    private static int cachedPanelWidth = -2147483648;
    private static int cachedPacketCount = -2147483648;
    private static int cachedQueueRevision = -2147483648;
    private static String cachedTitle = "";
    private static int cachedAccentColor;
    private static List<PackUiHudPanelRenderer.Row> cachedRows = List.of();
    private static long lastCacheBuildNanos;

    private PackUtilQueueRenderer() {
    }

    public static void render(class_332 context, class_327 textRenderer, int x, int y, int width, int maxLines) {
        if (textRenderer == null) {
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean isSending = shared.hasStaggeredPackets();
        String modeStr = shared.getQueueDisplayDelayMode() == PackUtilSharedState.DelayMode.MS ? "ms" : "t";
        int panelWidth = width + 12;
        int queueRevision = shared.getQueueRenderRevision();
        long now = System.nanoTime();
        if (PackUtilQueueRenderer.shouldRebuildCache(isSending, modeStr, maxLines, panelWidth, queueRevision, now)) {
            PackUtilQueueRenderer.rebuildCache(textRenderer, shared.getQueueRenderSnapshot(isSending, maxLines), isSending, modeStr, maxLines, panelWidth, queueRevision, now);
        }
        PackUiHudPanelRenderer.renderPreTrimmed(context, textRenderer, x - 6, y - 8, panelWidth, cachedTitle, cachedRows, cachedAccentColor);
    }

    private static boolean shouldRebuildCache(boolean isSending, String modeStr, int maxLines, int panelWidth, int queueRevision, long now) {
        boolean layoutChanged = cachedSending != isSending || !Objects.equals(cachedModeStr, modeStr) || cachedMaxLines != maxLines || cachedPanelWidth != panelWidth;
        if (layoutChanged) {
            return true;
        }
        if (cachedRows.isEmpty()) {
            return true;
        }
        if (cachedQueueRevision == queueRevision) {
            return false;
        }
        return now - lastCacheBuildNanos >= 50000000L;
    }

    private static void rebuildCache(class_327 textRenderer, PackUtilSharedState.QueueRenderSnapshot snapshot, boolean isSending, String modeStr, int maxLines, int panelWidth, int queueRevision, long now) {
        List<PackUtilSharedState.QueuedPacket> packets = snapshot.packets();
        int totalCount = snapshot.totalCount();
        int visibleCount = Math.min(packets.size(), maxLines);
        int contentWidth = panelWidth - 12;
        ArrayList<PackUiHudPanelRenderer.Row> rows = new ArrayList(visibleCount + 2);
        rows.add(new PackUiHudPanelRenderer.Row(PackUiText.trimToWidth(textRenderer, isSending ? "Sending " + totalCount + " left [" + modeStr + "]" : totalCount + " queued [" + modeStr + "]", contentWidth, BODY_FONT, -6366544), BODY_FONT, -6366544));
        if (packets.isEmpty()) {
            rows.add(new PackUiHudPanelRenderer.Row(PackUiText.trimToWidth(textRenderer, "Queue empty", contentWidth, MUTED_FONT, MUTED_COLOR), MUTED_FONT, MUTED_COLOR));
        } else {
            for (int i = 0; i < visibleCount; i++) {
                QueuedPacket qp = (PackUtilSharedState.QueuedPacket)packets.get(i);
                String simpleName = PackUtilPacketNamer.getFriendlyName(qp.packet);
                String delayStr = qp.getDelay() > 0 ? " +" + qp.getDelay() + modeStr : "";
                String label = "#" + qp.getId() + " " + simpleName + delayStr;
                int color = isSending && i == 0 ? -601459 : -1581859;
                rows.add(new PackUiHudPanelRenderer.Row(PackUiText.trimToWidth(textRenderer, label, contentWidth, BODY_FONT, color), BODY_FONT, color));
            }
        }
        cachedSending = isSending;
        cachedModeStr = modeStr;
        cachedMaxLines = maxLines;
        cachedPanelWidth = panelWidth;
        cachedPacketCount = totalCount;
        cachedQueueRevision = queueRevision;
        cachedTitle = PackUiText.trimToWidth(textRenderer, "PACKET QUEUE", contentWidth, LABEL_FONT, HEADER_COLOR);
        cachedAccentColor = isSending ? -9184882 : THEME.headerAccent();
        cachedRows = rows;
        lastCacheBuildNanos = now;
    }
}
