/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilPacketLoggerOverlay;

static class PackUtilPacketLoggerOverlay.DisplayRow {
    PackUtilPacketLoggerOverlay.RowType type;
    PackUtilPacketLoggerOverlay.LogEntry entry;
    String groupKey;
    int groupCount;
    String direction;
    Class<?> packetClass;

    PackUtilPacketLoggerOverlay.DisplayRow() {
    }
}
