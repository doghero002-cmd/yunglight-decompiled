/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public final class PackUtilRegistryLabels {
    private static final Map<String, String> ITEM_CACHE = new ConcurrentHashMap();
    private static final Map<String, String> BLOCK_CACHE = new ConcurrentHashMap();
    private static final Map<String, String> ENTITY_CACHE = new ConcurrentHashMap();
    private static final Map<String, String> IDENTIFIER_CACHE = new ConcurrentHashMap();

    private PackUtilRegistryLabels() {
    }

    public static String item(String rawId) {
        String key = PackUtilRegistryLabels.normalizedKey(rawId);
        return (String)ITEM_CACHE.computeIfAbsent(key, PackUtilRegistryLabels::lambda$item$1);
    }

    public static String block(String rawId) {
        String key = PackUtilRegistryLabels.normalizedKey(rawId);
        return (String)BLOCK_CACHE.computeIfAbsent(key, PackUtilRegistryLabels::lambda$block$3);
    }

    public static String entity(String rawId) {
        String key = PackUtilRegistryLabels.normalizedKey(rawId);
        return (String)ENTITY_CACHE.computeIfAbsent(key, PackUtilRegistryLabels::lambda$entity$5);
    }

    public static String sound(String rawId) {
        return PackUtilRegistryLabels.identifier(rawId);
    }

    public static String identifier(String rawId) {
        String key = PackUtilRegistryLabels.normalizedKey(rawId);
        return (String)IDENTIFIER_CACHE.computeIfAbsent(key, PackUtilRegistryLabels::humanizeIdentifier);
    }

    public static String stripNamespace(String rawId) {
        String key = PackUtilRegistryLabels.normalizedKey(rawId);
        if (key.isEmpty()) {
            return "";
        }
        class_2960 parsed = class_2960.method_12829(key);
        return parsed == null ? key : parsed.method_12832();
    }

    public static boolean looksLikeRawIdentifierLabel(String text, String rawId) {
        String trimmed = text == null ? "" : text.trim();
        String key = PackUtilRegistryLabels.normalizedKey(rawId);
        if (trimmed.isEmpty()) {
            return true;
        }
        return trimmed.equalsIgnoreCase(key) || trimmed.equalsIgnoreCase(PackUtilRegistryLabels.stripNamespace(key)) || trimmed.equalsIgnoreCase(PackUtilRegistryLabels.identifier(key));
    }

    private static <T> String registryLabel(String rawId, class_2378<T> registry, Function<T, String> nameProvider) {
        if (rawId.isEmpty()) {
            return "";
        }
        class_2960 parsed = class_2960.method_12829(rawId);
        String fallback = PackUtilRegistryLabels.humanizeIdentifier(rawId);
        if (parsed == null || !registry.method_10250(parsed)) {
            return fallback;
        }
        T value = registry.method_63535(parsed);
        if (value == null) {
            return fallback;
        }
        String resolved = (String)nameProvider.apply(value);
        return resolved == null || resolved.isBlank() ? fallback : resolved;
    }

    private static String humanizeIdentifier(String rawId) {
        if (rawId.isEmpty()) {
            return "";
        }
        class_2960 parsed = class_2960.method_12829(rawId);
        if (parsed == null) {
            return PackUtilRegistryLabels.humanizeWords(rawId);
        }
        String pathLabel = PackUtilRegistryLabels.humanizeWords(parsed.method_12832());
        if ("minecraft".equals(parsed.method_12836())) {
            return pathLabel;
        }
        String namespaceLabel = PackUtilRegistryLabels.humanizeWords(parsed.method_12836());
        return namespaceLabel.isEmpty() ? pathLabel : namespaceLabel + ": " + pathLabel;
    }

    private static String humanizeWords(String raw) {
        if (raw == null || raw.isBlank()) {
            return "";
        }
        String cleaned = raw.trim().replaceAll("[:_/.-]+", " ").replaceAll("\\s+", " ");
        if (cleaned.isEmpty()) {
            return raw.trim();
        }
        StringBuilder out = new StringBuilder(cleaned.length());
        var var3 = cleaned.split(" ");
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String part = var3[var5];
            if (part.isEmpty()) {
            } else {
                if (!out.length() > 0) continue;
                out.append(32);
                out.append(PackUtilRegistryLabels.humanizeToken(part));
            }
        }
        return out.toString();
    }

    private static String humanizeToken(String token) {
        if (token.isEmpty()) {
            return token;
        }
        if (token.length() <= 3 && token.equals(token.toUpperCase(Locale.ROOT))) {
            return token;
        }
        return Character.toUpperCase(token.charAt(0)) + token.substring(1).toLowerCase(Locale.ROOT);
    }

    private static String normalizedKey(String rawId) {
        return rawId == null ? "" : rawId.trim();
    }
}
