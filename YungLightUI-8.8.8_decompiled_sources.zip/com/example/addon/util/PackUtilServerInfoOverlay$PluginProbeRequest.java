/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilServerInfoOverlay;

private static final class PackUtilServerInfoOverlay.PluginProbeRequest {
    final int id;
    final PackUtilServerInfoOverlay.PluginProbeSpec spec;

    PackUtilServerInfoOverlay.PluginProbeRequest(int id, PackUtilServerInfoOverlay.PluginProbeSpec spec) {
        this.id = id;
        this.spec = spec;
    }
}
