/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final class PackUtilMacroListOverlay.ClickRegion {
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private final Runnable action;

    private PackUtilMacroListOverlay.ClickRegion(int x, int y, int width, int height, Runnable action) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.action = action;
    }

    private boolean contains(float mouseX, float mouseY) {
        return mouseX >= (float)this.x && mouseX <= (float)(this.x + this.width) && mouseY >= (float)this.y && mouseY <= (float)(this.y + this.height);
    }
}
