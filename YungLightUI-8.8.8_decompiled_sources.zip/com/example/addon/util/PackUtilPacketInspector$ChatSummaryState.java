/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final record PackUtilPacketInspector.ChatSummaryState {
    private final boolean wroteAny;
    private final boolean complete;

    private PackUtilPacketInspector.ChatSummaryState(boolean wroteAny, boolean complete) {
        this.wroteAny = wroteAny;
        this.complete = complete;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public boolean wroteAny() {
        return this.wroteAny;
    }

    public boolean complete() {
        return this.complete;
    }
}
