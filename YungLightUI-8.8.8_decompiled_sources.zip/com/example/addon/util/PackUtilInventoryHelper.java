/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.macro.ItemTarget;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2868;
import net.minecraft.class_310;

public final class PackUtilInventoryHelper {
    public static final int PLAYER_VISIBLE_SLOT_COUNT = 41;
    public static final int FIRST_GUI_SLOT = 100;

    private PackUtilInventoryHelper() {
    }

    public static void selectHotbarSlot(class_310 mc, int slot) {
        if (mc == null || mc.field_1724 == null || mc.method_1562() == null) {
            return;
        }
        int clampedSlot = Math.max(0, Math.min(8, slot));
        if (mc.field_1724.method_31548().method_67532() == clampedSlot) {
            return;
        }
        mc.field_1724.method_31548().method_61496(clampedSlot);
        mc.method_1562().method_52787(new class_2868(clampedSlot));
    }

    public static boolean swapInventorySlots(class_310 mc, int fromSlot, int toSlot) {
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        if (fromSlot == toSlot) {
            return true;
        }
        if (fromSlot < 0 || fromSlot >= 41 || toSlot < 0 || toSlot >= 41) {
            return false;
        }
        if (!mc.field_1724.field_7512.method_34255().method_7960()) {
            return false;
        }
        int fromScreenSlot = PackUtilInventoryHelper.toHandlerSlot(mc, fromSlot);
        int toScreenSlot = PackUtilInventoryHelper.toHandlerSlot(mc, toSlot);
        if (fromScreenSlot < 0 || toScreenSlot < 0) {
            return false;
        }
        return PackUtilInventoryHelper.swapHandlerSlots(mc, fromScreenSlot, toScreenSlot);
    }

    public static int findPlayerInventorySlotByName(class_310 mc, String itemName) {
        return PackUtilInventoryHelper.findPlayerInventorySlot(mc, ItemTarget.fromLegacyEntry(itemName));
    }

    public static int findPlayerInventorySlot(class_310 mc, ItemTarget target) {
        if (mc == null || mc.field_1724 == null || target == null || !target.hasIdentity()) {
            return -1;
        }
        int bestSlot = -1;
        int bestScore = -1;
        for (int slot = 0; slot < 36; slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            int score = target.score(stack, slot);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }
        return bestScore >= 0 ? bestSlot : -1;
    }

    public static int findUserVisibleSlotByName(class_310 mc, String itemName) {
        return PackUtilInventoryHelper.findUserVisibleSlot(mc, ItemTarget.fromLegacyEntry(itemName));
    }

    public static int findUserVisibleSlot(class_310 mc, ItemTarget target) {
        if (mc == null || mc.field_1724 == null || target == null || !target.hasIdentity()) {
            return -1;
        }
        int bestSlot = -1;
        int bestScore = -1;
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null) { /* goto L121; */ }
        var var5 = handler.field_7761.iterator();
        while (var5.hasNext()) {
            class_1735 slot = (class_1735)var5.next();
            while (slot == null) {
            }
            int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(mc, slot.field_7874);
            int score = target.score(slot.method_7677(), visibleSlot);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = visibleSlot;
            }
        }
        if (bestScore >= 0) {
            return bestSlot;
        }
        return PackUtilInventoryHelper.findPlayerInventorySlot(mc, target);
    }

    public static int selectHotbarItemByName(class_310 mc, String itemName, int preferredHotbarSlot) {
        return PackUtilInventoryHelper.selectHotbarItem(mc, ItemTarget.fromLegacyEntry(itemName), preferredHotbarSlot);
    }

    public static int selectHotbarItem(class_310 mc, ItemTarget target, int preferredHotbarSlot) {
        if (mc == null || mc.field_1724 == null || target == null || !target.hasIdentity()) {
            return -1;
        }
        int bestHotbarSlot = -1;
        int bestHotbarScore = -1;
        for (int slot = 0; slot < 9; slot++) {
            int score = target.score(mc.field_1724.method_31548().method_5438(slot), slot);
            if (score > bestHotbarScore) {
                bestHotbarScore = score;
                bestHotbarSlot = slot;
            }
        }
        if (bestHotbarScore >= 0) {
            PackUtilInventoryHelper.selectHotbarSlot(mc, bestHotbarSlot);
            return bestHotbarSlot;
        }
        bestInventorySlot = -1;
        bestInventoryScore = -1;
        for (int slot = 9; slot < 36; slot++) {
            int score = target.score(mc.field_1724.method_31548().method_5438(slot), slot);
            if (score > bestInventoryScore) {
                bestInventoryScore = score;
                bestInventorySlot = slot;
            }
        }
        if (bestInventoryScore < 0) {
            return -1;
        }
        targetHotbarSlot = Math.max(0, Math.min(8, preferredHotbarSlot));
        if (!PackUtilInventoryHelper.swapInventorySlots(mc, bestInventorySlot, targetHotbarSlot)) {
            return -1;
        }
        PackUtilInventoryHelper.selectHotbarSlot(mc, targetHotbarSlot);
        return targetHotbarSlot;
    }

    public static int toUserVisibleSlot(class_310 mc, int handlerSlotId) {
        if (mc == null || mc.field_1724 == null || mc.field_1724.field_7512 == null) {
            return handlerSlotId;
        }
        class_1703 handler = mc.field_1724.field_7512;
        if (handlerSlotId < 0 || handlerSlotId >= handler.field_7761.size()) {
            return handlerSlotId;
        }
        class_1735 slot = (class_1735)handler.field_7761.get(handlerSlotId);
        int playerSlot = PackUtilInventoryHelper.getPlayerInventorySlot(mc, slot);
        if (playerSlot >= 0) {
            return playerSlot;
        }
        int extraOrdinal = 0;
        var var6 = handler.field_7761.iterator();
        while (var6.hasNext()) {
            class_1735 currentSlot = (class_1735)var6.next();
            if (currentSlot == null) continue;
            while (PackUtilInventoryHelper.isPlayerInventorySlot(mc, currentSlot)) {
            }
            if (currentSlot.field_7874 != handlerSlotId) continue;
            return 100 + extraOrdinal;
            extraOrdinal++;
        }
        return handlerSlotId;
    }

    public static int toHandlerSlot(class_310 mc, int userVisibleSlot) {
        if (mc == null || mc.field_1724 == null || mc.field_1724.field_7512 == null) {
            return -1;
        }
        class_1703 handler = mc.field_1724.field_7512;
        if (userVisibleSlot < 0) { /* goto L96; */ }
        if (userVisibleSlot >= mc.field_1724.method_31548().method_5439()) { /* goto L96; */ }
        int extraOrdinal = handler.field_7761.iterator();
        while (extraOrdinal.hasNext()) {
            class_1735 slot = (class_1735)extraOrdinal.next();
            if (PackUtilInventoryHelper.getPlayerInventorySlot(mc, slot) != userVisibleSlot) continue;
            return slot.field_7874;
        }
        if (userVisibleSlot < 100) { /* goto L171; */ }
        extraOrdinal = userVisibleSlot - 100;
        slot = handler.field_7761.iterator();
        while (slot.hasNext()) {
            class_1735 slot = (class_1735)slot.next();
            if (slot == null) continue;
            while (PackUtilInventoryHelper.isPlayerInventorySlot(mc, slot)) {
            }
            if (extraOrdinal != 0) continue;
            return slot.field_7874;
            extraOrdinal--;
        }
        return -1;
    }

    public static int resolveConfiguredHandlerSlot(class_310 mc, int configuredSlot) {
        return PackUtilInventoryHelper.toHandlerSlot(mc, configuredSlot);
    }

    public static boolean isPlayerInventorySlot(class_310 mc, class_1735 slot) {
        return PackUtilInventoryHelper.getPlayerInventorySlot(mc, slot) >= 0;
    }

    public static boolean swapHandlerSlots(class_310 mc, int fromScreenSlot, int toScreenSlot) {
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        if (fromScreenSlot == toScreenSlot) {
            return true;
        }
        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null) {
            return false;
        }
        if (fromScreenSlot < 0 || fromScreenSlot >= handler.field_7761.size()) {
            return false;
        }
        if (toScreenSlot < 0 || toScreenSlot >= handler.field_7761.size()) {
            return false;
        }
        if (!handler.method_34255().method_7960()) {
            return false;
        }
        int syncId = handler.field_7763;
        mc.field_1761.method_2906(syncId, fromScreenSlot, 0, class_1713.field_7790, mc.field_1724);
        mc.field_1761.method_2906(syncId, toScreenSlot, 0, class_1713.field_7790, mc.field_1724);
        mc.field_1761.method_2906(syncId, fromScreenSlot, 0, class_1713.field_7790, mc.field_1724);
        return true;
    }

    private static int getPlayerInventorySlot(class_310 mc, class_1735 slot) {
        if (mc == null || mc.field_1724 == null || slot == null || slot.field_7871 != mc.field_1724.method_31548()) {
            return -1;
        }
        int index = slot.method_34266();
        return index >= 0 && index < mc.field_1724.method_31548().method_5439() ? index : -1;
    }
}
