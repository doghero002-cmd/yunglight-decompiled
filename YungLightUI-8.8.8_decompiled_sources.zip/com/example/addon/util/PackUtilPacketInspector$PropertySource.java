/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilPacketInspector.PropertySource {
    public static final PackUtilPacketInspector.PropertySource RECORD = new PackUtilPacketInspector.PropertySource("RECORD", 0);
    public static final PackUtilPacketInspector.PropertySource METHOD = new PackUtilPacketInspector.PropertySource("METHOD", 1);
    private static final /* synthetic */ PackUtilPacketInspector.PropertySource[] $VALUES;

    public static PackUtilPacketInspector.PropertySource[] values() {
        return (PackUtilPacketInspector.PropertySource[])$VALUES.clone();
    }

    public static PackUtilPacketInspector.PropertySource valueOf(String name) {
        return (PackUtilPacketInspector.PropertySource)Enum.valueOf(PackUtilPacketInspector.PropertySource.class, name);
    }

    private PackUtilPacketInspector.PropertySource() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilPacketInspector.PropertySource.$values();
    }
}
