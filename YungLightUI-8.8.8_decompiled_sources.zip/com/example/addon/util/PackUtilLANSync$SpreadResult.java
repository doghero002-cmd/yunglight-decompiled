/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static class PackUtilLANSync.SpreadResult {
    public final long spreadNanos;
    public final String lateClient;
    public final int clientCount;

    public PackUtilLANSync.SpreadResult(long spreadNanos, String lateClient, int clientCount) {
        this.spreadNanos = spreadNanos;
        this.lateClient = lateClient;
        this.clientCount = clientCount;
    }

    public double getSpreadMs() {
        return (double)this.spreadNanos / 1000000;
    }
}
