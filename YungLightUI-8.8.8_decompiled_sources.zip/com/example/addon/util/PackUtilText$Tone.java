/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilText.Tone {
    public static final PackUtilText.Tone TITLE = new PackUtilText.Tone("TITLE", 0);
    public static final PackUtilText.Tone LABEL = new PackUtilText.Tone("LABEL", 1);
    public static final PackUtilText.Tone BODY = new PackUtilText.Tone("BODY", 2);
    public static final PackUtilText.Tone MUTED = new PackUtilText.Tone("MUTED", 3);
    public static final PackUtilText.Tone ACCENT = new PackUtilText.Tone("ACCENT", 4);
    private static final /* synthetic */ PackUtilText.Tone[] $VALUES;

    public static PackUtilText.Tone[] values() {
        return (PackUtilText.Tone[])$VALUES.clone();
    }

    public static PackUtilText.Tone valueOf(String name) {
        return (PackUtilText.Tone)Enum.valueOf(PackUtilText.Tone.class, name);
    }

    private PackUtilText.Tone() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilText.Tone.$values();
    }
}
