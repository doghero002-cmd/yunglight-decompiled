/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiButton;

private static final class PackUtilMacroListOverlay.RowButton {
    private final String label;
    private final PackUiButton.Variant variant;
    private final int width;
    private final Runnable action;

    private PackUtilMacroListOverlay.RowButton(String label, PackUiButton.Variant variant, int width, Runnable action) {
        this.label = label;
        this.variant = variant;
        this.width = width;
        this.action = action;
    }
}
