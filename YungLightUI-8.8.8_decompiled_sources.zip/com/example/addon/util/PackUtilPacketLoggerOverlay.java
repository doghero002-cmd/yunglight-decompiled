/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiControlGlyphs;
import com.example.addon.gui.packui.PackUiLegacyLayout;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilChatField;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketEntryActions;
import com.example.addon.util.PackUtilPacketInspectOverlay;
import com.example.addon.util.PackUtilPacketInspector;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketSender;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.PacketRegenerator;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2815;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_7923;

public class PackUtilPacketLoggerOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss.SSS").withZone(ZoneId.systemDefault());
    private static final int HEADER_H = 16;
    private static final int GROUP_THRESHOLD = 10;
    private static final int CAP_ALL = 800;
    private static final int CAP_INVENTORY = 400;
    private static final int CAP_MOVEMENT = 200;
    private static final long UI_FLUSH_INTERVAL_MS = 500L;
    private static final Set<String> IGNORED_PACKET_KEYS;
    private static final Set<String> INVENTORY_NAMES;
    private static final Set<String> MOVEMENT_NAMES;
    private final class_327 textRenderer;
    private final PackUtilPacketInspectOverlay inspectOverlay;
    private final PackUiTheme theme = new PackUiTheme();
    private int PANEL_WIDTH = 323;
    private int PANEL_HEIGHT = 250;
    private int currentPanelHeight = 250;
    private int panelX = 200;
    private int panelY = 40;
    private boolean visible;
    private boolean collapsed;
    private boolean paused = true;
    private boolean isDragging;
    private boolean isResizing;
    private double dragOffX;
    private double dragOffY;
    private double headerPressMouseX;
    private double headerPressMouseY;
    private int headerPressPanelX;
    private int headerPressPanelY;
    private boolean headerDragMoved;
    private double resizeStartMouseX;
    private double resizeStartMouseY;
    private int resizeStartWidth;
    private int resizeStartHeight;
    private int scrollOffset;
    private final PackUiSmoothScroll contentScrollState = new PackUiSmoothScroll();
    private boolean scrollbarDragging;
    private int scrollbarGrabOffset;
    private String searchFilter = "";
    private final PackUtilChatField searchField;
    private PackUtilPacketLoggerOverlay.Category activeTab = PackUtilPacketLoggerOverlay.Category.ALL;
    private boolean groupingEnabled = true;
    private int dirFilter = 0;
    private final Set<Class<?>> blockedClasses = new LinkedHashSet();
    private boolean blockedExpanded;
    private final List<PackUtilPacketLoggerOverlay.LogEntry> bufAll = new CopyOnWriteArrayList();
    private final List<PackUtilPacketLoggerOverlay.LogEntry> bufInventory = new CopyOnWriteArrayList();
    private final List<PackUtilPacketLoggerOverlay.LogEntry> bufMovement = new CopyOnWriteArrayList();
    private final List<PackUtilPacketLoggerOverlay.LogEntry> pendingEntries = new ArrayList();
    private int gameTick;
    private long lastUiFlushMs;
    private List<PackUtilPacketLoggerOverlay.DisplayRow> displayRows = new ArrayList();
    private boolean dirty = true;
    private boolean ctxMenuOpen;
    private int ctxMenuX;
    private int ctxMenuY;
    private PackUtilPacketLoggerOverlay.LogEntry ctxMenuEntry;
    private final Set<String> expandedGroups = new HashSet();
    private static long idCounter;

    public PackUtilPacketLoggerOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.PANEL_WIDTH = this.defaultPanelWidth();
        this.PANEL_HEIGHT = this.defaultPanelHeight();
        this.currentPanelHeight = this.PANEL_HEIGHT;
        this.searchField = new PackUtilChatField(MC, textRenderer, 0, 0, this.searchFieldWidth(), this.filterRowHeight(), false);
        this.searchField.setPlaceholder(class_2561.method_43470("Search..."));
        this.searchField.setMaxLength(160);
        this.searchField.setChangedListener(this::lambda$new$0);
        this.inspectOverlay = new PackUtilPacketInspectOverlay(textRenderer);
        PackUtilOverlayManager.get().register(this.inspectOverlay);
    }

    public int getMinWidth() {
        return this.defaultPanelWidth();
    }

    public int getMinHeight() {
        return this.defaultPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = Math.max(this.getMinWidth(), clamped.width);
        this.PANEL_HEIGHT = Math.max(this.getMinHeight(), clamped.height);
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
    }

    public void setGameTick(int t) {
        this.gameTick = t;
    }

    public boolean isPaused() {
        return this.paused;
    }

    public synchronized void setPaused(boolean paused) {
        if (this.paused == paused) {
            return;
        }
        if (paused) {
            this.flushPendingLocked();
        } else {
            this.lastUiFlushMs = System.currentTimeMillis();
        }
        this.paused = paused;
        this.dirty = true;
    }

    public synchronized void logPacket(class_2596<?> packet, String direction) {
        if (this.paused) {
            return;
        }
        Class<?> cls = packet.getClass();
        if (this.blockedClasses.contains(cls)) {
            return;
        }
        String name = PackUtilPacketNamer.getFriendlyName(packet, direction);
        if (PackUtilPacketLoggerOverlay.shouldIgnorePacket(cls, name)) {
            return;
        }
        boolean isInventory = PackUtilPacketLoggerOverlay.matchesAny(name, INVENTORY_NAMES);
        boolean isMovement = PackUtilPacketLoggerOverlay.matchesAny(name, MOVEMENT_NAMES);
        LogCaptureContext captureContext = PackUtilPacketLoggerOverlay.captureLogContext(packet);
        LogEntry e = new PackUtilPacketLoggerOverlay.LogEntry(System.currentTimeMillis(), this.gameTick, direction, name, cls, packet, isInventory, isMovement, captureContext.blockStateSummary(), captureContext.screenSummary());
        this.pendingEntries.add(e);
        this.maybeFlushPendingLocked(false);
    }

    private static PackUtilPacketLoggerOverlay.LogCaptureContext captureLogContext(class_2596<?> packet) {
        if (packet == null || MC == null || !MC.method_18854()) {
            return PackUtilPacketLoggerOverlay.LogCaptureContext.EMPTY;
        }
        try {
            if (packet instanceof class_2846) {
                class_2846 actionPacket = (class_2846)packet;
                return new PackUtilPacketLoggerOverlay.LogCaptureContext(PackUtilPacketLoggerOverlay.snapshotBlockState(actionPacket.method_12362()), null);
            }
        }
        catch (Throwable interactBlockPacket) {
            return PackUtilPacketLoggerOverlay.LogCaptureContext.EMPTY;
        }
        try {
            if (packet instanceof class_2885) {
                interactBlockPacket = (class_2885)packet;
                return new PackUtilPacketLoggerOverlay.LogCaptureContext(PackUtilPacketLoggerOverlay.snapshotBlockState(interactBlockPacket.method_12543().method_17777()), null);
            }
        }
        catch (Throwable interactBlockPacket) {
            return PackUtilPacketLoggerOverlay.LogCaptureContext.EMPTY;
        }
        try {
            if (packet instanceof class_2815) {
                return new PackUtilPacketLoggerOverlay.LogCaptureContext(null, PackUtilPacketLoggerOverlay.snapshotCurrentScreen());
            }
        }
        catch (Throwable interactBlockPacket) {
            return PackUtilPacketLoggerOverlay.LogCaptureContext.EMPTY;
        }
    }

    private static String snapshotBlockState(class_2338 pos) {
        if (pos == null || MC.field_1687 == null) {
            return null;
        }
        try {
            class_2680 state = MC.field_1687.method_8320(pos);
            if (state == null) {
                return null;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            return String.valueOf(class_7923.field_41175.method_10221(state.method_26204())) + " " + String.valueOf(state);
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    private static String snapshotCurrentScreen() {
        if (MC.field_1755 == null) {
            return null;
        }
        try {
            String title = MC.field_1755.method_25440() == null ? "" : MC.field_1755.method_25440().getString().trim();
            String className = MC.field_1755.getClass().getSimpleName();
            if (title.isEmpty()) {
                return className;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            if (className == null || className.isBlank()) {
                return title;
            }
        }
        catch (Throwable ignored) {
            return null;
        }
        try {
            return title + " [" + className + "]";
        }
        catch (Throwable ignored) {
            return null;
        }
    }

    public boolean isPacketBlocked(Class<?> cls) {
        return this.blockedClasses.contains(cls);
    }

    public Set<Class<?>> getBlockedPacketClasses() {
        return this.blockedClasses;
    }

    private static boolean matchesAny(String name, Set<String> set) {
        var var2 = set.iterator();
        while (var2.hasNext()) {
            String s = (String)var2.next();
            if (!name.contains(s)) continue;
            return true;
        }
        return false;
    }

    private static String normalizePacketKey(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        String lower = value.toLowerCase(Locale.ROOT);
        StringBuilder normalized = new StringBuilder(lower.length());
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if (c < 97 || c > 122) {
                if (c < 48) { /* goto @86; */ }
            }
            normalized.append(c);
            L86: ;
        }
        return normalized.toString();
    }

    private static boolean shouldIgnorePacket(Class<?> cls, String friendlyName) {
        String normalizedFriendly = PackUtilPacketLoggerOverlay.normalizePacketKey(friendlyName);
        String normalizedSimple = PackUtilPacketLoggerOverlay.normalizePacketKey(cls.getSimpleName());
        String normalizedClass = PackUtilPacketLoggerOverlay.normalizePacketKey(cls.getName());
        String normalizedResolvedClass = "";
        if (class_2596.class.isAssignableFrom(cls)) {
            Class<? extends class_2596<?>> packetClass = cls;
            normalizedResolvedClass = PackUtilPacketLoggerOverlay.normalizePacketKey(PackUtilPacketNamer.getFriendlyName(packetClass));
        }
        return IGNORED_PACKET_KEYS.contains(normalizedFriendly) || IGNORED_PACKET_KEYS.contains(normalizedResolvedClass) || IGNORED_PACKET_KEYS.contains(normalizedSimple) || IGNORED_PACKET_KEYS.contains(normalizedClass);
    }

    private static void addCapped(List<PackUtilPacketLoggerOverlay.LogEntry> buf, PackUtilPacketLoggerOverlay.LogEntry e, int cap) {
        buf.add(e);
        int excess = buf.size() - cap;
        if (excess > 0) {
            buf.subList(0, excess).clear();
        }
    }

    private void maybeFlushPending() {
        var var1 = this;
        synchronized (this) {
        this.maybeFlushPendingLocked(false);
        }
    }

    private void maybeFlushPendingLocked(boolean force) {
        long now = System.currentTimeMillis();
        if (!force) {
            if (this.pendingEntries.isEmpty()) {
                return;
            }
            if (this.lastUiFlushMs != 0L) {
                if (now - this.lastUiFlushMs < 500L) {
                    return;
                }
            }
        }
        this.flushPendingLocked();
        this.lastUiFlushMs = now;
    }

    private void flushPending() {
        var var1 = this;
        synchronized (this) {
        this.flushPendingLocked();
        this.lastUiFlushMs = System.currentTimeMillis();
        }
    }

    private void flushPendingLocked() {
        if (this.pendingEntries.isEmpty()) {
            return;
        }
        var var1 = this.pendingEntries.iterator();
        while (var1.hasNext()) {
            LogEntry e = (PackUtilPacketLoggerOverlay.LogEntry)var1.next();
            PackUtilPacketLoggerOverlay.addCapped(this.bufAll, e, 800);
            if (!e.isInventory) continue;
            PackUtilPacketLoggerOverlay.addCapped(this.bufInventory, e, 400);
            if (!e.isMovement) continue;
            PackUtilPacketLoggerOverlay.addCapped(this.bufMovement, e, 200);
        }
        this.pendingEntries.clear();
        this.dirty = true;
    }

    public void setVisible(boolean v) {
        this.visible = v;
        if (v) {
            this.scrollOffset = 0;
            this.contentScrollState.jumpTo(0, 0);
            this.dirty = true;
            this.ctxMenuOpen = false;
            PackUtilOverlayManager.get().bringToFront(this);
        } else {
            this.inspectOverlay.close();
        }
        this.saveLayout();
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean c) {
        this.collapsed = c;
        this.isDragging = false;
        this.isResizing = false;
        this.headerDragMoved = false;
        this.scrollbarDragging = false;
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean hasTextFieldFocused() {
        return this.searchField != null && this.searchField.isFocused();
    }

    public void clearTextFieldFocus() {
        if (this.searchField != null) {
            this.searchField.setFocused(false);
        }
    }

    public int getZLevel() {
        return 10;
    }

    private void drawUiText(class_332 context, String text, PackUiTone tone, int color, int x, int y) {
        PackUiText.draw(context, this.textRenderer, text, this.theme.fontFor(tone), color, x, y, false);
    }

    public boolean isMouseOver(double mx, double my) {
        if (!this.visible) {
            return false;
        }
        int panelHeight = this.collapsed ? 16 : this.currentPanelHeight;
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, panelHeight, this.visible, this.collapsed);
        int h = this.getRenderedFrameHeight(bounds, this.collapsed);
        boolean overPanel = mx >= (double)this.panelX && mx <= (double)(this.panelX + this.PANEL_WIDTH) && my >= (double)this.panelY && my <= (double)(this.panelY + h);
        if (!this.ctxMenuOpen) { /* goto L230; */ }
        if (this.ctxMenuEntry == null) { /* goto L230; */ }
        String[] items = this.getCtxItems(this.ctxMenuEntry.direction.equals("C2S"));
        int mw = this.ctxMenuWidth(items);
        int mh = this.ctxMenuHeight(items);
        overPanel = overPanel | (mx >= (double)this.ctxMenuX && mx < (double)(this.ctxMenuX + mw) && my >= (double)this.ctxMenuY && my < (double)(this.ctxMenuY + mh) ? 1 : 0);
        return overPanel;
    }

    public boolean isOverDragBar(double mx, double my) {
        if (!this.visible) {
            return false;
        }
        return mx >= (double)this.panelX && mx <= (double)(this.panelX + this.PANEL_WIDTH) && my >= (double)this.panelY && my <= (double)(this.panelY + 16) && !this.isOverWindowControl(mx, my, this.getBounds());
    }

    public void render(class_332 ctx, int mx, int my, float delta) {
        if (!this.visible) {
            return;
        }
        this.maybeFlushPending();
        if (this.dirty) {
            this.rebuildDisplay();
            this.dirty = false;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.calcPanelH(), this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = clamped.width;
        this.currentPanelHeight = clamped.height;
        int ph = this.currentPanelHeight;
        int total = 0;
        String title = this.displayRows.iterator();
        while (title.hasNext()) {
            DisplayRow r = (PackUtilPacketLoggerOverlay.DisplayRow)title.next();
            total = total + (r.type == PackUtilPacketLoggerOverlay.RowType.GROUP ? r.groupCount : 1);
        }
        title = "Packet Logger";
        bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, ph, this.visible, this.collapsed);
        this.renderWindowFrame(ctx, mx, my, bounds, title, this.collapsed, this.isDragging);
        boolean clipBody = this.beginWindowBodyClip(ctx, bounds, this.collapsed);
        if (!clipBody) {
            this.renderWindowInactiveOverlay(ctx, bounds, this.collapsed, this.isDragging);
            return;
        }
        try {
            int tabY = this.panelY + 16 + 2;
            this.renderTabs(ctx, mx, my, tabY, total);
            int filterY = tabY + this.tabHeight() + 2;
            this.renderFilterBar(ctx, mx, my, filterY);
            int contentY = filterY + this.filterHeight() + 2;
            int contentEndY = contentY + this.contentAreaHeight();
            if (this.displayRows.isEmpty()) {
                this.drawUiText(ctx, "No packets matching filters", PackUiTone.MUTED, PackUtilColors.textDim(), this.panelX + 10, contentY + 6);
            } else {
                int contentHeight = this.displayRows.size() * this.lineHeight();
                int viewHeight = this.contentAreaHeight();
                int maxScroll = Math.max(0, contentHeight - viewHeight);
                this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset, this.lineHeight(), maxScroll);
                this.contentScrollState.setTarget(this.scrollOffset, maxScroll);
                int drawScroll = this.contentScrollState.tick(delta, maxScroll);
                PackUtilUiScale.enableOverlayScissor(ctx, this.panelX, contentY, this.panelX + this.PANEL_WIDTH, contentEndY);
                int drawBase = contentY - drawScroll;
                for (int i = 0; i < this.displayRows.size(); i++) {
                    int ey = drawBase + i * this.lineHeight();
                    if (ey + this.lineHeight() <= contentY) { /* goto L572; */ }
                    if (ey >= contentEndY) { /* goto L572; */ }
                    DisplayRow row = (PackUtilPacketLoggerOverlay.DisplayRow)this.displayRows.get(i);
                    if (row.type == PackUtilPacketLoggerOverlay.RowType.GROUP) {
                        this.renderGroup(ctx, row, ey, mx, my);
                    } else {
                        this.renderEntry(ctx, row.entry, ey, mx, my);
                    }
                }
                ctx.method_44380();
                scrollbarMetrics = this.getContentScrollbarMetrics();
                PackUiScrollbar.draw(ctx, scrollbarMetrics, scrollbarMetrics.contains((double)mx, (double)my), this.scrollbarDragging);
            }
            if (!this.blockedClasses.isEmpty()) {
                this.renderBlocked(ctx, mx, my, contentEndY, this.panelY + ph - 2);
            }
        }
        finally {
            this.endWindowBodyClip(ctx, clipBody);
            this.renderWindowInactiveOverlay(ctx, bounds, this.collapsed, this.isDragging);
            throw var23;
        }
        PackUiText.interOverlayFlush(ctx);
        if (this.ctxMenuOpen && this.ctxMenuEntry != null) {
            this.renderCtxMenu(ctx, mx, my);
        }
    }

    private void renderTabs(class_332 ctx, int mx, int my, int y, int total) {
        int x = this.panelX + 4;
        String summary = PackUtilPacketLoggerOverlay.Category.values();
        int summaryColor = summary.length;
        for (int summaryWidth = 0; summaryWidth < summaryColor; summaryWidth++) {
            Category cat = summary[summaryWidth];
            int w = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, cat.label, 5, 32, 64);
            if (this.activeTab == cat) {
                this.drawOverlayButton(ctx, x, y, w, this.tabHeight(), cat.label, PackUiOverlayButton.Variant.PRIMARY, true, mx, my);
            } else {
                this.drawOverlayButton(ctx, x, y, w, this.tabHeight(), cat.label, PackUiOverlayButton.Variant.GHOST, true, mx, my);
            }
            x = x + (w + 2);
        }
        summary = this.paused ? "Paused  " + total : Integer.toString(total);
        summaryColor = this.paused ? this.theme.color(PackUiTone.MUTED) : PackUtilColors.textSecondary();
        summaryWidth = PackUiText.width(this.textRenderer, summary, this.theme.fontFor(PackUiTone.MUTED), summaryColor);
        summaryX = this.panelX + this.PANEL_WIDTH - 6 - summaryWidth;
        minSummaryX = x + 4;
        if (summaryX >= minSummaryX) {
            int summaryY = PackUiSizing.alignTextY(y, this.tabHeight(), this.theme.fontHeight(PackUiTone.MUTED), this.theme.bodyTextNudge());
            this.drawUiText(ctx, summary, PackUiTone.MUTED, summaryColor, summaryX, summaryY);
        }
    }

    private int contentAreaY() {
        return this.panelY + 16 + 2 + this.tabHeight() + 2 + this.filterHeight() + 2;
    }

    private int contentAreaHeight() {
        int rawHeight = Math.max(0, this.currentPanelHeight - 16 - this.tabHeight() - this.filterHeight() - 8 - this.blockedH());
        return this.alignViewportHeight(rawHeight, this.lineHeight());
    }

    private PackUiScrollbar.Metrics getContentScrollbarMetrics() {
        int contentHeight = this.displayRows.size() * this.lineHeight();
        int viewHeight = this.contentAreaHeight();
        int maxScroll = Math.max(0, contentHeight - viewHeight);
        return PackUiScrollbar.compute(contentHeight, viewHeight, this.panelX + this.PANEL_WIDTH - 5, this.contentAreaY(), 3, viewHeight, this.contentScrollState.tick(0f, maxScroll));
    }

    private void renderFilterBar(class_332 ctx, int mx, int my, int y) {
        int gap = 2;
        int row1Y = y;
        int row2Y = y + this.filterRowHeight() + this.filterRowGap();
        int x = this.panelX + 4;
        String captureLabel = this.paused ? "Start" : "Stop";
        int captureW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, captureLabel, 5, 38, 54);
        if (this.paused) {
            this.drawOverlayButton(ctx, x, row1Y, captureW, this.filterRowHeight(), captureLabel, PackUiOverlayButton.Variant.SUCCESS, true, mx, my);
        } else {
            this.drawOverlayButton(ctx, x, row1Y, captureW, this.filterRowHeight(), captureLabel, PackUiOverlayButton.Variant.DANGER, true, mx, my);
        }
        x = x + (captureW + gap);
        int clearW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, "Clear", 5, 34, 54);
        this.drawOverlayButton(ctx, x, row1Y, clearW, this.filterRowHeight(), "Clear", PackUiOverlayButton.Variant.GHOST, true, mx, my);
        x = x + (clearW + gap);
        int copyW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, "Copy", 5, 34, 52);
        this.drawOverlayButton(ctx, x, row1Y, copyW, this.filterRowHeight(), "Copy", PackUiOverlayButton.Variant.GHOST, true, mx, my);
        x = x + (copyW + gap);
        String grpLabel = this.groupingEnabled ? "Group" : "Ungrp";
        int groupW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, grpLabel, 5, 38, 58);
        this.drawOverlayButton(ctx, x, row1Y, groupW, this.filterRowHeight(), grpLabel, PackUiOverlayButton.Variant.GHOST, true, mx, my);
        x = x + (groupW + gap);
        if (!this.blockedClasses.isEmpty()) {
            String bt = this.blockedClasses.size() + "blk";
            int blockedW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, bt, 5, 34, 52);
            this.drawOverlayButton(ctx, x, row1Y, blockedW, this.filterRowHeight(), bt, PackUiOverlayButton.Variant.GHOST, true, mx, my);
        }
        x = this.panelX + 4;
        sw = this.searchFieldWidth();
        this.searchField.setX(x);
        this.searchField.setY(row2Y);
        this.searchField.setWidth(sw);
        this.searchField.setHeight(this.filterRowHeight());
        if (!Objects.equals(this.searchField.getText(), this.searchFilter)) {
            this.searchField.setText(this.searchFilter);
        }
        this.searchField.render(ctx, mx, my, 0f);
        x = x + (sw + 3);
        String[] tmp0 = new String[3];
        tmp0[0] = "Both";
        tmp0[1] = "C2S";
        tmp0[2] = "S2C";
        dirLabels = tmp0;
        for (int d = 0; d < 3; d++) {
            int bw = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, dirLabels[d], 4, 30, 48);
            if (this.dirFilter == d) {
                this.drawOverlayButton(ctx, x, row2Y, bw, this.filterRowHeight(), dirLabels[d], PackUiOverlayButton.Variant.PRIMARY, true, mx, my);
            } else {
                this.drawOverlayButton(ctx, x, row2Y, bw, this.filterRowHeight(), dirLabels[d], PackUiOverlayButton.Variant.GHOST, true, mx, my);
            }
            x = x + (bw + gap);
        }
    }

    private void drawOverlayButton(class_332 ctx, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean active, int mx, int my) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), PackUtilPacketLoggerOverlay::lambda$drawOverlayButton$1);
        button.setWidth(w);
        button.setVariant(variant);
        button.active = active;
        PackUiOverlayButton.renderStyled(ctx, this.textRenderer, button, mx, my);
    }

    private void renderGroup(class_332 ctx, PackUtilPacketLoggerOverlay.DisplayRow row, int y, int mx, int my) {
        int x = this.panelX + 4;
        boolean exp = this.expandedGroups.contains(row.groupKey);
        boolean hov = mx >= this.panelX && mx <= this.panelX + this.PANEL_WIDTH && my >= y && my < y + this.lineHeight();
        if (hov) {
            ctx.method_25294(this.panelX + 2, y, this.panelX + this.PANEL_WIDTH - 2, y + this.lineHeight(), 553648127);
        }
        PackUiControlGlyphs.drawChevron(ctx, x, y + 2, 8, exp ? PackUiControlGlyphs.ChevronDirection.DOWN : PackUiControlGlyphs.ChevronDirection.RIGHT, hov ? -659730 : -1582374, -1204153320, 1f);
        x += 10;
        String arrow = row.direction.equals("C2S") ? ">" : "<";
        int color = row.direction.equals("C2S") ? -12268289 : -21948;
        this.drawUiText(ctx, arrow, PackUiTone.BODY, color, x, y + 1);
        x += 12;
        String displayName = row.groupKey.contains(":") ? row.groupKey.substring(row.groupKey.indexOf(58) + 1) : row.groupKey;
        this.drawUiText(ctx, displayName + " (x" + row.groupCount + ")", PackUiTone.BODY, color, x, y + 1);
        int bx = this.panelX + this.PANEL_WIDTH - 28;
        boolean hb = mx >= bx && mx <= bx + 24 && my >= y && my < y + this.lineHeight();
        this.drawUiText(ctx, "BLK", PackUiTone.MUTED, hb ? -48060 : PackUtilColors.textDim(), bx, y + 1);
    }

    private void renderEntry(class_332 ctx, PackUtilPacketLoggerOverlay.LogEntry e, int y, int mx, int my) {
        int x = this.panelX + 4;
        boolean hov = mx >= this.panelX && mx <= this.panelX + this.PANEL_WIDTH && my >= y && my < y + this.lineHeight();
        if (hov) {
            ctx.method_25294(this.panelX + 2, y, this.panelX + this.PANEL_WIDTH - 2, y + this.lineHeight(), 419430399);
        }
        int color = e.direction.equals("C2S") ? -12268289 : -21948;
        this.drawUiText(ctx, e.direction.equals("C2S") ? ">" : "<", PackUiTone.BODY, color, x, y + 1);
        x += 12;
        String time = TIME_FMT.format(Instant.ofEpochMilli(e.timestampMs));
        this.drawUiText(ctx, time, PackUiTone.MUTED, PackUtilColors.textDim(), x, y + 1);
        x = x + (PackUiText.width(this.textRenderer, time, this.theme.fontFor(PackUiTone.MUTED), PackUtilColors.textDim()) + 4);
        this.drawUiText(ctx, "T" + e.gameTick, PackUiTone.MUTED, PackUtilColors.textDim(), x, y + 1);
        x = x + (PackUiText.width(this.textRenderer, "T" + e.gameTick, this.theme.fontFor(PackUiTone.MUTED), PackUtilColors.textDim()) + 4);
        int maxW = this.PANEL_WIDTH - (x - this.panelX) - 30;
        String name = e.shortName;
        if (PackUiText.width(this.textRenderer, name, this.theme.fontFor(PackUiTone.BODY), PackUtilColors.textPrimary()) > maxW) {
            name = PackUiText.trimToWidth(this.textRenderer, name, Math.max(1, maxW), this.theme.fontFor(PackUiTone.BODY), PackUtilColors.textPrimary());
        }
        this.drawUiText(ctx, name, PackUiTone.BODY, color, x, y + 1);
        int bx = this.panelX + this.PANEL_WIDTH - 16;
        boolean hb = mx >= bx && mx <= bx + 12 && my >= y && my < y + this.lineHeight();
        this.drawUiText(ctx, "=", PackUiTone.MUTED, hb ? -8875 : PackUtilColors.textDim(), bx, y + 1);
    }

    private void renderBlocked(class_332 ctx, int mx, int my, int startY, int endY) {
        ctx.method_25294(this.panelX + 4, startY, this.panelX + this.PANEL_WIDTH - 4, startY + 1, PackUtilColors.secondary());
        int y = startY + 3;
        boolean hh = mx >= this.panelX + 4 && mx <= this.panelX + 150 && my >= y && my < y + this.lineHeight();
        this.drawUiText(ctx, this.blockedExpanded ? "v" : ">" + " Blocked (" + this.blockedClasses.size() + ")", PackUiTone.LABEL, hh ? -30584 : -39322, this.panelX + 6, y + 1);
        int ubX = this.panelX + this.PANEL_WIDTH - 58;
        boolean hua = mx >= ubX && mx <= ubX + 54 && my >= y && my < y + this.lineHeight();
        this.drawUiText(ctx, "CLR ALL", PackUiTone.MUTED, hua ? -12255420 : PackUtilColors.textSecondary(), ubX, y + 1);
        if (!this.blockedExpanded) {
            return;
        }
        y = y + this.lineHeight();
        var var10 = this.blockedClasses.iterator();
        while (var10.hasNext()) {
            Class<?> cls = (Class)var10.next();
            if (y + this.lineHeight() > endY) {
            } else {
                String n = PackUtilPacketNamer.getFriendlyName(cls);
                this.drawUiText(ctx, "  " + PackUiText.trimToWidth(this.textRenderer, n, Math.max(1, this.PANEL_WIDTH - 50), this.theme.fontFor(PackUiTone.BODY), -5609882), PackUiTone.BODY, -5609882, this.panelX + 8, y + 1);
                int ux = this.panelX + this.PANEL_WIDTH - 28;
                boolean hu = mx >= ux && mx <= ux + 24 && my >= y && my < y + this.lineHeight();
                this.drawUiText(ctx, "UB", PackUiTone.MUTED, hu ? -12255420 : PackUtilColors.textSecondary(), ux, y + 1);
                y = y + this.lineHeight();
            }
        }
    }

    private String[] getCtxItems(boolean isC2S) {
        String[] tmp0 = new String[8];
        tmp0[0] = "Block";
        tmp0[1] = "Queue";
        tmp0[2] = "Replay";
        tmp0[3] = "+SEND";
        tmp0[4] = "+WAIT";
        tmp0[5] = "+ Filter";
        tmp0[6] = "Copy";
        tmp0[7] = "Inspect";
        String[] tmp0 = new String[5];
        tmp0[0] = "Block";
        tmp0[1] = "+WAIT";
        tmp0[2] = "+ Filter";
        tmp0[3] = "Copy";
        tmp0[4] = "Inspect";
        return isC2S ? tmp0 : tmp0;
    }

    private int ctxMenuWidth(String[] items) {
        int maxW = 0;
        var var3 = items;
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String s = var3[var5];
            maxW = Math.max(maxW, PackUiText.width(this.textRenderer, s, this.theme.fontFor(PackUiTone.BODY), PackUtilColors.textPrimary()));
        }
        return maxW + 12;
    }

    private int ctxMenuHeight(String[] items) {
        return items.length * this.lineHeight() + 4;
    }

    private void clampCtxMenuToScreen() {
        if (this.ctxMenuEntry == null) {
            return;
        }
        String[] items = this.getCtxItems(this.ctxMenuEntry.direction.equals("C2S"));
        int menuW = this.ctxMenuWidth(items);
        int menuH = this.ctxMenuHeight(items);
        int screenW = Math.max(menuW + 4, PackUtilUiScale.getVirtualScreenWidth());
        int screenH = Math.max(menuH + 4, PackUtilUiScale.getVirtualScreenHeight());
        this.ctxMenuX = Math.max(2, Math.min(this.ctxMenuX, screenW - menuW - 2));
        this.ctxMenuY = Math.max(2, Math.min(this.ctxMenuY, screenH - menuH - 2));
    }

    private void openCtxMenu(PackUtilPacketLoggerOverlay.LogEntry entry, int mouseX, int mouseY) {
        this.ctxMenuEntry = entry;
        this.ctxMenuX = mouseX;
        this.ctxMenuY = mouseY;
        this.ctxMenuOpen = true;
        this.clampCtxMenuToScreen();
    }

    private void renderCtxMenu(class_332 ctx, int mx, int my) {
        this.clampCtxMenuToScreen();
        boolean isC2S = this.ctxMenuEntry.direction.equals("C2S");
        String[] items = this.getCtxItems(isC2S);
        int w = this.ctxMenuWidth(items);
        int itemH = this.lineHeight();
        int menuH = this.ctxMenuHeight(items);
        ctx.method_25294(this.ctxMenuX - 1, this.ctxMenuY - 1, this.ctxMenuX + w + 1, this.ctxMenuY + menuH + 1, PackUtilColors.primary());
        ctx.method_25294(this.ctxMenuX, this.ctxMenuY, this.ctxMenuX + w, this.ctxMenuY + menuH, PackUtilColors.background());
        for (int i = 0; i < items.length; i++) {
            int iy = this.ctxMenuY + 2 + i * itemH;
            boolean hov = mx >= this.ctxMenuX && mx < this.ctxMenuX + w && my >= iy && my < iy + itemH;
            if (!hov) continue;
            ctx.method_25294(this.ctxMenuX + 1, iy, this.ctxMenuX + w - 1, iy + itemH, 822083583);
            this.drawUiText(ctx, items[i], PackUiTone.BODY, hov ? -1 : PackUtilColors.textLight(), this.ctxMenuX + 4, iy + 2);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        if (this.ctxMenuOpen) {
            if (button == 0) {
                boolean consumed = this.handleCtxMenuClick(mouseX, mouseY);
                this.ctxMenuOpen = false;
                if (consumed) {
                    return true;
                }
            }
        }
        if (this.ctxMenuOpen) {
            this.ctxMenuOpen = false;
            return true;
        }
        if (button != 0 && button != 1) {
            return false;
        }
        if (mouseY >= (double)this.panelY) {
            if (mouseY <= (double)(this.panelY + 16)) {
                if (mouseX >= (double)this.panelX) {
                    if (mouseX <= (double)(this.panelX + this.PANEL_WIDTH)) {
                        bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.calcPanelH(), this.visible, this.collapsed);
                        if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
                            this.setVisible(false);
                            return true;
                        }
                        if (button == 0) {
                            this.isDragging = true;
                            this.headerDragMoved = false;
                            this.dragOffX = mouseX - (double)this.panelX;
                            this.dragOffY = mouseY - (double)this.panelY;
                            this.headerPressMouseX = mouseX;
                            this.headerPressMouseY = mouseY;
                            this.headerPressPanelX = this.panelX;
                            this.headerPressPanelY = this.panelY;
                        }
                        return true;
                    }
                }
            }
        }
        if (this.collapsed) {
            return false;
        }
        tabY = this.panelY + 16 + 2;
        int filterY = tabY + this.tabHeight() + 2;
        int contentY = filterY + this.filterHeight() + 2;
        if (mouseY < (double)tabY) { /* goto L415; */ }
        if (mouseY >= (double)(tabY + this.tabHeight())) { /* goto L415; */ }
        if (button != 0) { /* goto L415; */ }
        int x = this.panelX + 4;
        Metrics scrollbarMetrics = PackUtilPacketLoggerOverlay.Category.values();
        var var11 = scrollbarMetrics.length;
        for (int var12 = 0; var12 < var11; var12++) {
            Category cat = scrollbarMetrics[var12];
            int w = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, cat.label, 5, 32, 64);
            this.activeTab = cat;
            if (mouseX >= (double)x && mouseX < (double)(x + w)) {
                this.dirty = true;
                this.scrollOffset = 0;
                return true;
            }
            x = x + (w + 2);
        }
        return true;
        L415: ;
        if (mouseY >= (double)filterY && mouseY < (double)(filterY + this.filterHeight()) && button == 0) {
            return this.handleFilterClick(mouseX, mouseY, filterY);
        }
        if (this.searchField.isFocused()) {
            this.searchField.setFocused(false);
        }
        contentEndY = contentY + this.contentAreaHeight();
        if (mouseY >= (double)contentY) {
            if (mouseY < (double)contentEndY) {
                if (button == 0) {
                    scrollbarMetrics = this.getContentScrollbarMetrics();
                    if (scrollbarMetrics.hasScroll()) {
                        if (scrollbarMetrics.contains((double)(int)mouseX, (double)(int)mouseY)) {
                            this.scrollbarDragging = true;
                            this.scrollbarGrabOffset = Math.max(0, (int)mouseY - scrollbarMetrics.thumbY());
                            this.scrollOffset = this.quantizeScrollOffset(PackUiScrollbar.scrollFromThumb(scrollbarMetrics, (double)(int)mouseY, this.scrollbarGrabOffset), this.lineHeight(), scrollbarMetrics.maxScroll());
                            this.contentScrollState.jumpTo(this.scrollOffset, scrollbarMetrics.maxScroll());
                            return true;
                        }
                    }
                }
                return this.handleContentClick(mouseX, mouseY, contentY, button);
            }
        }
        if (!this.blockedClasses.isEmpty() && button == 0) {
            return this.handleBlockedClick(mouseX, mouseY, contentEndY);
        }
        return false;
    }

    private boolean handleFilterClick(double mouseX, double mouseY, int y) {
        int gap = 2;
        int row1Y = y;
        int row2Y = y + this.filterRowHeight() + this.filterRowGap();
        int x = this.panelX + 4;
        String captureLabel = this.paused ? "Start" : "Stop";
        int captureW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, captureLabel, 5, 38, 54);
        if (mouseY < (double)row1Y) { /* goto L128; */ }
        if (mouseY >= (double)(row1Y + this.filterRowHeight())) { /* goto L128; */ }
        if (mouseX < (double)x) { /* goto L128; */ }
        if (mouseX >= (double)(x + captureW)) { /* goto L128; */ }
        this.setPaused(!this.paused);
        return true;
        x = x + (captureW + gap);
        int clrW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, "Clear", 5, 34, 54);
        this.clearAll();
        if (mouseY >= (double)row1Y && mouseY < (double)(row1Y + this.filterRowHeight()) && mouseX >= (double)x && mouseX < (double)(x + clrW)) {
            return true;
        }
        x = x + (clrW + gap);
        int cpW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, "Copy", 5, 34, 52);
        this.copyToClipboard();
        if (mouseY >= (double)row1Y && mouseY < (double)(row1Y + this.filterRowHeight()) && mouseX >= (double)x && mouseX < (double)(x + cpW)) {
            return true;
        }
        x = x + (cpW + gap);
        int grpW = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, this.groupingEnabled ? "Group" : "Ungrp", 5, 38, 58);
        if (mouseY < (double)row1Y) { /* goto L398; */ }
        if (mouseY >= (double)(row1Y + this.filterRowHeight())) { /* goto L398; */ }
        if (mouseX < (double)x) { /* goto L398; */ }
        if (mouseX >= (double)(x + grpW)) { /* goto L398; */ }
        this.groupingEnabled = !this.groupingEnabled;
        this.dirty = true;
        return true;
        x = x + (grpW + gap);
        if (this.blockedClasses.isEmpty()) { /* goto L517; */ }
        String bt = this.blockedClasses.size() + "blk";
        int bw = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, bt, 5, 34, 52);
        if (mouseY < (double)row1Y) { /* goto L517; */ }
        if (mouseY >= (double)(row1Y + this.filterRowHeight())) { /* goto L517; */ }
        if (mouseX < (double)x) { /* goto L517; */ }
        if (mouseX >= (double)(x + bw)) { /* goto L517; */ }
        this.blockedExpanded = !this.blockedExpanded;
        return true;
        x = this.panelX + 4;
        sw = 148;
        this.searchField.mouseClicked(mouseX, mouseY, 0);
        if (mouseY >= (double)row2Y && mouseY < (double)(row2Y + this.filterRowHeight()) && mouseX >= (double)x && mouseX < (double)(x + sw)) {
            return true;
        }
        x = x + (sw + 3);
        String[] tmp0 = new String[3];
        tmp0[0] = "Both";
        tmp0[1] = "C2S";
        tmp0[2] = "S2C";
        dirLabels = tmp0;
        for (int d = 0; d < 3; d++) {
            int bw = PackUiLegacyLayout.fitOverlayButtonWidth(this.textRenderer, this.theme, PackUiTone.BODY, dirLabels[d], 4, 30, 48);
            this.dirFilter = d;
            if (mouseY >= (double)row2Y && mouseY < (double)(row2Y + this.filterRowHeight()) && mouseX >= (double)x && mouseX < (double)(x + bw)) {
                this.dirty = true;
                return true;
            }
            x = x + (bw + gap);
        }
        this.searchField.setFocused(false);
        return true;
    }

    private boolean handleContentClick(double mouseX, double mouseY, int contentY, int button) {
        int idx = (int)((mouseY - (double)contentY + (double)this.contentScrollState.tick(0f, Math.max(0, this.displayRows.size() * this.lineHeight() - this.contentAreaHeight()))) / (double)this.lineHeight());
        if (idx < 0 || idx >= this.displayRows.size()) {
            return false;
        }
        DisplayRow row = (PackUtilPacketLoggerOverlay.DisplayRow)this.displayRows.get(idx);
        if (row.type != PackUtilPacketLoggerOverlay.RowType.GROUP) { /* goto L225; */ }
        int bx = this.panelX + this.PANEL_WIDTH - 28;
        this.blockedClasses.add(row.packetClass);
        if (button == 0 && mouseX >= (double)bx && mouseX <= (double)(bx + 24) && row.packetClass != null) {
            this.dirty = true;
            return true;
        }
        if (button != 0) { /* goto L225; */ }
        if (this.expandedGroups.contains(row.groupKey)) {
            this.expandedGroups.remove(row.groupKey);
        } else {
            this.expandedGroups.add(row.groupKey);
        }
        this.dirty = true;
        return true;
        L225: ;
        if (row.type == PackUtilPacketLoggerOverlay.RowType.ENTRY) {
            if (row.entry != null) {
                menuIconX = this.panelX + this.PANEL_WIDTH - 16;
                if (button != 1) {
                    if (button != 0) { /* goto @292; */ }
                }
                this.openCtxMenu(row.entry, (int)mouseX, (int)mouseY);
                return true;
            }
        }
        return false;
    }

    private boolean handleCtxMenuClick(double mouseX, double mouseY) {
        if (this.ctxMenuEntry == null) {
            return false;
        }
        this.clampCtxMenuToScreen();
        boolean isC2S = this.ctxMenuEntry.direction.equals("C2S");
        String[] items = this.getCtxItems(isC2S);
        int w = this.ctxMenuWidth(items);
        if (mouseX < (double)this.ctxMenuX || mouseX >= (double)(this.ctxMenuX + w)) {
            return false;
        }
        for (int i = 0; i < items.length; i++) {
            int iy = this.ctxMenuY + 2 + i * this.lineHeight();
            this.executeCtxAction(items[i], this.ctxMenuEntry);
            if (!mouseY >= (double)iy && mouseY < (double)(iy + this.lineHeight())) continue;
            return true;
        }
        return false;
    }

    private void executeCtxAction(String action, PackUtilPacketLoggerOverlay.LogEntry e) {
        var var3 = action;
        int var4 = -1;
        switch (var3.hashCode()) {
            case 64279661::
                if (!var3.equals("Block")) { /* goto @211; */ }
                var4 = 0;
                /* goto @211; */
            case 78391537::
                if (!var3.equals("Queue")) { /* goto @211; */ }
                var4 = 1;
                /* goto @211; */
            case 42252851::
                if (!var3.equals("+SEND")) { /* goto @211; */ }
                var4 = 2;
                /* goto @211; */
            case 42368032::
                if (!var3.equals("+WAIT")) { /* goto @211; */ }
                var4 = 3;
                /* goto @211; */
            case -1928877779::
                if (!var3.equals("+ Filter")) { /* goto @211; */ }
                var4 = 4;
                /* goto @211; */
            case -1850657785::
                if (!var3.equals("Replay")) { /* goto @211; */ }
                var4 = 5;
                /* goto @211; */
            case 2106261::
                if (!var3.equals("Copy")) { /* goto @211; */ }
                var4 = 6;
                /* goto @211; */
            case -672859660::
                if (var3.equals("Inspect")) {
                    var4 = 7;
                }
            default:
                switch (var4) {
                    case 0::
                        this.blockedClasses.add(e.packetClass);
                        this.dirty = true;
                        PackUtilClientMessaging.sendPrefixed("Blocked: " + e.shortName);
                        /* goto @589; */
                    case 1::
                        PackUtilPacketEntryActions.queue(e);
                        /* goto @589; */
                    case 2::
                        PackUtilPacketEntryActions.addSendActionToVisibleMacro(e);
                        /* goto @589; */
                    case 3::
                        PackUtilPacketEntryActions.addWaitActionToVisibleMacro(e);
                        /* goto @589; */
                    case 4::
                        PackUtilSharedState shared = PackUtilSharedState.get();
                        Class<? extends class_2596<?>> pktCls = e.packetClass;
                        if (e.direction.equals("C2S")) {
                            shared.getC2SPackets().add(pktCls);
                        } else {
                            shared.getS2CPackets().add(pktCls);
                        }
                        shared.setUseCustomPackets(true);
                        PackUtilClientMessaging.sendPrefixed("Added to custom " + e.direction + " filter: " + e.shortName);
                        /* goto @589; */
                    case 5::
                        if (e.packetRef == null) { /* goto @589; */ }
                        if (!e.direction.equals("C2S")) { /* goto @589; */ }
                        regenerated = PacketRegenerator.regenerate(e.packetRef);
                        if (regenerated != null) {
                            PackUtilPacketSender.sendPacket(regenerated);
                            if (MC.field_1724 != null) {
                                if (MC.field_1724.field_7512 != null) {
                                    MC.field_1724.field_7512.method_37422();
                                }
                            }
                            PackUtilClientMessaging.sendPrefixed("Replayed: " + e.shortName);
                        } else {
                            PackUtilClientMessaging.sendPrefixed("§cCannot replay: " + e.shortName);
                        }
                        /* goto @589; */
                    case 6::
                        line = e.direction + " " + TIME_FMT.format(Instant.ofEpochMilli(e.timestampMs)) + " T" + e.gameTick + " " + e.shortName;
                        MC.field_1774.method_1455(line);
                        PackUtilClientMessaging.sendPrefixed("Copied packet info.");
                        /* goto @589; */
                    case 7::
                        inspection = PackUtilPacketInspector.inspectSafe(e);
                        this.inspectOverlay.open(inspection, e, this.panelX + this.PANEL_WIDTH + 10, this.panelY + 8);
                        /* goto @589; */
                    default:
                        return;
                }
        }
    }

    private boolean handleBlockedClick(double mouseX, double mouseY, int contentEndY) {
        int y = contentEndY + 3;
        if (mouseY < (double)y) { /* goto L94; */ }
        if (mouseY >= (double)(y + this.lineHeight())) { /* goto L94; */ }
        int ubX = this.panelX + this.PANEL_WIDTH - 58;
        this.blockedClasses.clear();
        if (mouseX >= (double)ubX && mouseX <= (double)(ubX + 54)) {
            this.dirty = true;
            return true;
        }
        this.blockedExpanded = !this.blockedExpanded;
        return true;
        if (!this.blockedExpanded) { /* goto L233; */ }
        ey = y + this.lineHeight();
        int ux = this.panelX + this.PANEL_WIDTH - 28;
        var var9 = new ArrayList(this.blockedClasses).iterator();
        while (var9.hasNext()) {
            Class<?> cls = (Class)var9.next();
            this.blockedClasses.remove(cls);
            if (mouseX >= (double)ux && mouseX <= (double)(ux + 24) && mouseY >= (double)ey && mouseY < (double)(ey + this.lineHeight())) {
                this.dirty = true;
                return true;
            }
            ey = ey + this.lineHeight();
        }
        return false;
    }

    public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        Metrics scrollbarMetrics = this.getContentScrollbarMetrics();
        if (this.scrollbarDragging && b == 0) {
            this.scrollOffset = this.quantizeScrollOffset(PackUiScrollbar.scrollFromThumb(scrollbarMetrics, (double)(int)my, this.scrollbarGrabOffset), this.lineHeight(), scrollbarMetrics.maxScroll());
            this.contentScrollState.jumpTo(this.scrollOffset, scrollbarMetrics.maxScroll());
            return true;
        }
        nextBounds = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.resizeStartWidth + (int)Math.round(mx - this.resizeStartMouseX), this.resizeStartHeight + (int)Math.round(my - this.resizeStartMouseY), this.visible, this.collapsed));
        if (this.isResizing && b == 0) {
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.PANEL_WIDTH = nextBounds.width;
            this.PANEL_HEIGHT = nextBounds.height;
            return true;
        }
        if (this.isDragging) {
            if (b == 0) {
                nextBounds = this.clampToScreen(this, new PackUtilWindowLayout((int)(mx - this.dragOffX), (int)(my - this.dragOffY), this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed));
                if (nextBounds.x != this.panelX || nextBounds.y != this.panelY) {
                    this.headerDragMoved = true;
                }
                this.panelX = nextBounds.x;
                this.panelY = nextBounds.y;
                return true;
            }
        }
        return false;
    }

    public boolean mouseReleased(double mx, double my, int b) {
        this.scrollbarDragging = false;
        if (b == 0 && this.scrollbarDragging) {
            return true;
        }
        if (b != 0) { /* goto L228; */ }
        if (!this.isDragging) { /* goto L228; */ }
        boolean moved = this.headerDragMoved || Math.abs(mx - this.headerPressMouseX) >= 3 || Math.abs(my - this.headerPressMouseY) >= 3 || this.panelX != this.headerPressPanelX || this.panelY != this.headerPressPanelY;
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.calcPanelH(), this.visible, this.collapsed);
        this.isDragging = false;
        this.headerDragMoved = false;
        if (moved) { /* goto L222; */ }
        if (mx < (double)this.panelX) { /* goto L222; */ }
        if (mx > (double)(this.panelX + this.PANEL_WIDTH)) { /* goto L222; */ }
        if (my < (double)this.panelY) { /* goto L222; */ }
        if (my > (double)(this.panelY + 16)) { /* goto L222; */ }
        if (this.isOverCloseButton(mx, my, bounds)) { /* goto L222; */ }
        this.setCollapsed(!this.collapsed);
        this.saveLayout();
        return true;
        this.isResizing = false;
        if (b == 0 && this.isResizing) {
            this.saveLayout();
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mx, double my, double amt) {
        if (!this.visible || this.collapsed) {
            return false;
        }
        int totalH = this.displayRows.size() * this.lineHeight();
        int visH = this.contentAreaHeight();
        int maxScroll = Math.max(0, totalH - visH);
        this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset - (int)Math.round(amt * (double)this.lineHeight() * 3), this.lineHeight(), maxScroll);
        return true;
    }

    public boolean keyPressed(int key, int scan, int mods) {
        return this.searchField.isFocused() && this.searchField.keyPressed(new class_11908(key, scan, mods));
    }

    public boolean charTyped(char c, int mods) {
        return this.searchField.isFocused() && this.searchField.charTyped(new class_11905(c, mods));
    }

    private List<PackUtilPacketLoggerOverlay.LogEntry> getActiveBuffer() {
        switch (this.activeTab.ordinal()) {
            case 1::
                return this.bufInventory;
            case 2::
                return this.bufMovement;
            case 0::
            default:
                return this.bufAll;
        }
    }

    private void rebuildDisplay() {
        List<PackUtilPacketLoggerOverlay.LogEntry> source = this.getActiveBuffer();
        if (source == null) {
            source = new ArrayList();
        }
        String ls = this.searchFilter.toLowerCase(Locale.ROOT);
        List<PackUtilPacketLoggerOverlay.LogEntry> filtered = new ArrayList();
        Map<String, Integer> counts = source.iterator();
        while (counts.hasNext()) {
            LogEntry e = (PackUtilPacketLoggerOverlay.LogEntry)counts.next();
            while (this.blockedClasses.contains(e.packetClass)) {
            }
            while (!ls.isEmpty()) {
                if (e.searchKey.contains(ls)) break;
            }
            while (this.dirFilter == 1) {
                if (e.direction.equals("C2S")) break;
            }
            while (this.dirFilter == 2) {
                if (e.direction.equals("S2C")) break;
            }
            filtered.add(e);
        }
        counts = new LinkedHashMap();
        dirs = new LinkedHashMap();
        Map<String, Class<?>> classes = new LinkedHashMap();
        Set<String> groupedKeys = filtered.iterator();
        while (groupedKeys.hasNext()) {
            LogEntry e = (PackUtilPacketLoggerOverlay.LogEntry)groupedKeys.next();
            String key = e.groupKey;
            counts.merge(key, 1, Integer::sum);
            dirs.put(key, e.direction);
            classes.put(key, e.packetClass);
        }
        groupedKeys = new HashSet();
        if (!this.groupingEnabled) { /* goto L377; */ }
        reversed = counts.entrySet().iterator();
        while (reversed.hasNext()) {
            entry = (Map.Entry)reversed.next();
            if (!((Integer)entry.getValue()).intValue() >= 10) continue;
            groupedKeys.add((String)entry.getKey());
        }
        reversed = new ArrayList(filtered);
        Collections.reverse(reversed);
        rows = new ArrayList();
        Set<String> added = new LinkedHashSet();
        var var11 = reversed.iterator();
        while (var11.hasNext()) {
            LogEntry e = (PackUtilPacketLoggerOverlay.LogEntry)var11.next();
            String key = e.groupKey;
            if (!groupedKeys.contains(key)) { /* goto @655; */ }
            if (!added.add(key)) { /* goto @655; */ }
            DisplayRow h = new PackUtilPacketLoggerOverlay.DisplayRow();
            h.type = PackUtilPacketLoggerOverlay.RowType.GROUP;
            h.groupKey = key;
            h.groupCount = ((Integer)counts.get(key)).intValue();
            h.direction = (String)dirs.get(key);
            h.packetClass = (Class)classes.get(key);
            rows.add(h);
            if (!this.expandedGroups.contains(key)) { /* goto @655; */ }
            var var15 = reversed.iterator();
            while (var15.hasNext()) {
                LogEntry child = (PackUtilPacketLoggerOverlay.LogEntry)var15.next();
                if (child.groupKey.equals(key)) {
                    DisplayRow r = new PackUtilPacketLoggerOverlay.DisplayRow();
                    r.type = PackUtilPacketLoggerOverlay.RowType.ENTRY;
                    r.entry = child;
                    rows.add(r);
                }
            }
        }
        var11 = reversed.iterator();
        while (var11.hasNext()) {
            e = (PackUtilPacketLoggerOverlay.LogEntry)var11.next();
            if (!groupedKeys.contains(e.groupKey)) {
                r = new PackUtilPacketLoggerOverlay.DisplayRow();
                r.type = PackUtilPacketLoggerOverlay.RowType.ENTRY;
                r.entry = e;
                rows.add(r);
            }
        }
        this.displayRows = rows;
        this.clampScrollOffset();
    }

    private void clampScrollOffset() {
        int totalH = this.displayRows.size() * this.lineHeight();
        int visH = this.currentPanelHeight - 16 - this.tabHeight() - this.filterHeight() - 8 - this.blockedH();
        int maxScroll = Math.max(0, totalH - visH);
        this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset, this.lineHeight(), maxScroll);
    }

    private int calcPanelH() {
        int rc = Math.min(this.displayRows.size(), this.maxVisibleRows());
        return Math.max(this.PANEL_HEIGHT, 16 + this.tabHeight() + this.filterHeight() + 8 + Math.max(rc * this.lineHeight(), 24) + this.blockedH() + 4);
    }

    private int blockedH() {
        if (this.blockedClasses.isEmpty()) {
            return 0;
        }
        int h = this.lineHeight() + 4;
        if (this.blockedExpanded) {
            h = h + this.blockedClasses.size() * this.lineHeight();
        }
        return h;
    }

    private void clearAll() {
        this.pendingEntries.clear();
        this.bufAll.clear();
        this.bufInventory.clear();
        this.bufMovement.clear();
        this.displayRows.clear();
        this.scrollOffset = 0;
        this.contentScrollState.jumpTo(0, 0);
        this.expandedGroups.clear();
        this.dirty = true;
    }

    private void copyToClipboard() {
        this.flushPending();
        StringBuilder sb = new StringBuilder();
        sb.append("=== Packet Logger [").append(this.activeTab.label).append("] ===\n");
        if (!this.searchFilter.isEmpty()) {
            sb.append("Search: \"").append(this.searchFilter).append("\"\n");
        }
        sb.append(String.format("%-5s %-14s %-8s %s%n", "DIR", "TIME", "TICK", "PACKET"));
        sb.append("----------------------------------------------\n");
        List<PackUtilPacketLoggerOverlay.LogEntry> source = this.getActiveBuffer();
        if (source == null) {
            source = new ArrayList();
        }
        String ls = this.searchFilter.toLowerCase(Locale.ROOT);
        int count = 0;
        var var5 = source.iterator();
        while (var5.hasNext()) {
            LogEntry e = (PackUtilPacketLoggerOverlay.LogEntry)var5.next();
            while (this.blockedClasses.contains(e.packetClass)) {
            }
            while (!ls.isEmpty()) {
                if (e.searchKey.contains(ls)) break;
            }
            while (this.dirFilter == 1) {
                if (e.direction.equals("C2S")) break;
            }
            while (this.dirFilter == 2) {
                if (e.direction.equals("S2C")) break;
            }
            sb.append(String.format("%-5s %-14s %-8s %s%n", e.direction.equals("C2S") ? "->" : "<-", TIME_FMT.format(Instant.ofEpochMilli(e.timestampMs)), "T" + e.gameTick, e.shortName));
            count++;
        }
        sb.append("----------------------------------------------\n");
        sb.append("Total: ").append(count).append(" packets\n");
        MC.field_1774.method_1455(sb.toString());
        PackUtilClientMessaging.sendPrefixed("Copied " + count + " packets to clipboard.");
    }

    private int defaultPanelWidth() {
        return 323;
    }

    private int defaultPanelHeight() {
        return 250;
    }

    private int lineHeight() {
        return 12;
    }

    private int tabHeight() {
        return 16;
    }

    private int filterRowHeight() {
        return 16;
    }

    private int filterRowGap() {
        return 2;
    }

    private int filterHeight() {
        return this.filterRowHeight() * 2 + this.filterRowGap();
    }

    private int searchFieldWidth() {
        return 148;
    }

    private int maxVisibleRows() {
        return 22;
    }

    static {
        IGNORED_PACKET_KEYS = new HashSet(Arrays.asList("clienttickendc2s", "clienttickends2c", "bundles2cpacket", "bundles2c", "lightupdates2c", "lightupdates2cpacket", "commonpongc2s", "commonpongc2spacket", "commonpings2c", "commonpings2cpacket", "keepalivec2s", "keepalivec2spacket", "keepalives2c", "keepalives2cpacket", "entitypositions2c", "entitypositions2cpacket", "playerlistheaders2c", "playerlistheaders2cpacket", "teams2c", "teams2cpacket", "entitypositionsyncs2c", "entitypositionsync", "entitys2cpacketmoverelative", "moverelative", "entityvelocityupdates2c", "entityvelocityupdate", "entitys2cpacketrotateandmoverelative", "rotateandmoverelative", "entitysetheadyaws2c", "entitysetheadyaw", "entitytrackerupdates2c", "entitytrackerupdate", "playermovec2spacketlookandonground", "lookandonground", "playermovec2spacketpositionandonground", "positionandonground", "entitiesdestroys2c", "entitiesdestroy", "entitystatuss2c", "entitystatus", "entityspawns2c", "entityspawn", "entitydamages2c", "entitydamage", "entityanimations2c", "entityanimation", "entityattributess2c", "entityattributes", "playsounds2c", "playsound", "worldevents2c", "worldevent", "worldtimeupdates2c", "worldtimeupdate", "overlaymessages2c", "overlaymessages2cpacket", "overlaymessage", "overlaymessagepacket", "blockupdates2c", "blockupdates", "entitys2cpacketrotate", "chunkdeltaupdates2c", "gamestatechanges2c", "chunkdatas2c", "unloadchunks2c", "playermovec2spacketfull", "playerlists2c", "acknowledgechunksc2s", "chunksents2c", "startchunksends2c", "chunkrenderdistancecenters2c", "clientcommandc2s", "playerinputc2s"));
        INVENTORY_NAMES = new HashSet(Arrays.asList("ClickSlot", "CloseHandledScreen", "OpenScreen", "ScreenHandler", "CreativeInventoryAction", "PickFromInventory", "PlayerAction", "InventoryS2C", "ScreenHandlerSlotUpdate", "ScreenHandlerProperty", "SetTradeOffers", "OpenHorseScreen", "CraftRequest", "ButtonClick", "RecipeBookData", "UpdateSelectedSlot", "HandSwing", "PlayerInteractBlock", "PlayerInteractItem", "PlayerInteractEntity", "ItemPickupAnimation"));
        MOVEMENT_NAMES = new HashSet(Arrays.asList("PlayerMove", "PlayerMoveFull", "PlayerMovePositionAndOnGround", "PlayerMoveLookAndOnGround", "PlayerMoveOnGroundOnly", "EntityPosition", "EntityPositionSync", "EntitySetHead", "EntityVelocityUpdate", "VehicleMove", "MoveRelative", "PacketMoveRelative", "RotateRelative", "PacketRotateRelative", "EntityPacketRotate", "EntityMoveRelative", "EntityRotate", "TeleportConfirm", "ClientTickEnd"));
        idCounter = 0L;
    }
}
