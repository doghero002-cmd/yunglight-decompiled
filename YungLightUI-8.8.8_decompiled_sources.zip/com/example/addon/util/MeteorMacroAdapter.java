/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroManager;
import java.util.List;

public class MeteorMacroAdapter {
    public static List<PackUtilMacro> getMeteorMacros() {
        return PackUtilCompatManager.getMeteorMacros();
    }

    public static void importToMeteor(PackUtilMacro packUtilMacro) {
        if (PackUtilCompatManager.importToMeteor(packUtilMacro)) {
            PackUtilClientMessaging.sendPrefixed("§aImported to Meteor: " + packUtilMacro.name);
        } else {
            PackUtilClientMessaging.sendPrefixed("§cFailed to import to Meteor");
        }
    }

    public static boolean importToPackUtil(String macroName) {
        PackUtilMacro packUtilMacro = PackUtilCompatManager.getMeteorMacro(macroName);
        if (packUtilMacro == null) {
            PackUtilClientMessaging.sendPrefixed("§cMeteor macro not found: " + macroName);
            return false;
        }
        PackUtilMacro imported = PackUtilMacroManager.get().addImportedCopy(packUtilMacro, packUtilMacro.name);
        if (imported == null) {
            return false;
        }
        if (!imported.name.equals(packUtilMacro.name)) {
            PackUtilClientMessaging.sendPrefixed("§eImported Meteor macro as: " + imported.name);
        }
        return true;
    }
}
