/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilServerInfoOverlay.PluginEvidence {
    public static final PackUtilServerInfoOverlay.PluginEvidence COMMAND_TREE = new PackUtilServerInfoOverlay.PluginEvidence("COMMAND_TREE", 0);
    public static final PackUtilServerInfoOverlay.PluginEvidence NAMESPACE = new PackUtilServerInfoOverlay.PluginEvidence("NAMESPACE", 1);
    public static final PackUtilServerInfoOverlay.PluginEvidence ROOT_HINT = new PackUtilServerInfoOverlay.PluginEvidence("ROOT_HINT", 2);
    public static final PackUtilServerInfoOverlay.PluginEvidence HELP_HINT = new PackUtilServerInfoOverlay.PluginEvidence("HELP_HINT", 3);
    public static final PackUtilServerInfoOverlay.PluginEvidence PLUGIN_LIST = new PackUtilServerInfoOverlay.PluginEvidence("PLUGIN_LIST", 4);
    public static final PackUtilServerInfoOverlay.PluginEvidence VERSION_HINT = new PackUtilServerInfoOverlay.PluginEvidence("VERSION_HINT", 5);
    public static final PackUtilServerInfoOverlay.PluginEvidence UNKNOWN = new PackUtilServerInfoOverlay.PluginEvidence("UNKNOWN", 6);
    private static final /* synthetic */ PackUtilServerInfoOverlay.PluginEvidence[] $VALUES;

    public static PackUtilServerInfoOverlay.PluginEvidence[] values() {
        return (PackUtilServerInfoOverlay.PluginEvidence[])$VALUES.clone();
    }

    public static PackUtilServerInfoOverlay.PluginEvidence valueOf(String name) {
        return (PackUtilServerInfoOverlay.PluginEvidence)Enum.valueOf(PackUtilServerInfoOverlay.PluginEvidence.class, name);
    }

    private PackUtilServerInfoOverlay.PluginEvidence() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilServerInfoOverlay.PluginEvidence.$values();
    }
}
