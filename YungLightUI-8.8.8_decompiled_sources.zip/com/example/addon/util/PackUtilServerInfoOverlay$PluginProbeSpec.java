/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilServerInfoOverlay;

private static final class PackUtilServerInfoOverlay.PluginProbeSpec {
    final String query;
    final PackUtilServerInfoOverlay.PluginProbeKind kind;
    final String hint;

    PackUtilServerInfoOverlay.PluginProbeSpec(String query, PackUtilServerInfoOverlay.PluginProbeKind kind, String hint) {
        this.query = query;
        this.kind = kind;
        this.hint = hint;
    }
}
