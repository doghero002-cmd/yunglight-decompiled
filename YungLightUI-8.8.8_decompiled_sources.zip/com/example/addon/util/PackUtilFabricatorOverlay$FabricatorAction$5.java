/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilFabricatorOverlay;

final class PackUtilFabricatorOverlay.FabricatorAction.5
extends PackUtilFabricatorOverlay.FabricatorAction {
    boolean usesDropToggle() {
        return true;
    }

    PackUtilDropAction toPacketAction(boolean dropWholeStack) {
        return dropWholeStack ? PackUtilDropAction.DROP_STACK : PackUtilDropAction.DROP_ITEM;
    }

    String getDescription(boolean dropWholeStack) {
        return dropWholeStack ? "Drops the whole stack from the selected slot." : "Drops one item at a time from the selected slot.";
    }
}
