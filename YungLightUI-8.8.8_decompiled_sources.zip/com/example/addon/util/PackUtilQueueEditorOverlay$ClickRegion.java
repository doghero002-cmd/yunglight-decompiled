/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static class PackUtilQueueEditorOverlay.ClickRegion {
    final int x;
    final int y;
    final int width;
    final int height;
    final Runnable action;

    private PackUtilQueueEditorOverlay.ClickRegion(int x, int y, int width, int height, Runnable action) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.action = action;
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }
}
