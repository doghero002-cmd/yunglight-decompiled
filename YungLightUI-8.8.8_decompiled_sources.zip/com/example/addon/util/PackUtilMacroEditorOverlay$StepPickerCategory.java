/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final class PackUtilMacroEditorOverlay.StepPickerCategory {
    private final String id;
    private final String label;
    private final int color;

    private PackUtilMacroEditorOverlay.StepPickerCategory(String id, String label, int color) {
        this.id = id;
        this.label = label;
        this.color = color;
    }
}
