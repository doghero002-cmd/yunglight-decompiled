/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

private static class PackUtilKeybindOverlay.KeybindEntry {
    final String label;
    final String tooltip;
    final IntSupplier getter;
    final IntConsumer setter;

    PackUtilKeybindOverlay.KeybindEntry(String label, String tooltip, IntSupplier getter, IntConsumer setter) {
        this.label = label;
        this.tooltip = tooltip;
        this.getter = getter;
        this.setter = setter;
    }
}
