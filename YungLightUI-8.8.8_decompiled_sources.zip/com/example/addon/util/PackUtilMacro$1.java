/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.macro.MacroActionType;

static class PackUtilMacro.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$MacroActionType;

    static {
        $SwitchMap$com$example$addon$util$macro$MacroActionType = new int[MacroActionType.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DELAY.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.PACKET.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.PACKET.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_PACKET.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_PACKET.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_HEALTH.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_HEALTH.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_ITEM.ordinal()] = 5;
            /* goto @84; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_ITEM.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_BLOCK.ordinal()] = 6;
            /* goto @100; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_BLOCK.ordinal()] = 6;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_GUI.ordinal()] = 7;
            /* goto @116; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_GUI.ordinal()] = 7;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CLICK.ordinal()] = 8;
            /* goto @132; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CLICK.ordinal()] = 8;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.ROTATE.ordinal()] = 9;
            /* goto @148; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.ROTATE.ordinal()] = 9;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.USE_ITEM.ordinal()] = 10;
            /* goto @164; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.USE_ITEM.ordinal()] = 10;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.INVENTORY.ordinal()] = 11;
            /* goto @180; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.INVENTORY.ordinal()] = 11;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_PACKET.ordinal()] = 12;
            /* goto @196; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_PACKET.ordinal()] = 12;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CRAFT.ordinal()] = 13;
            /* goto @212; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CRAFT.ordinal()] = 13;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SELECT_SLOT.ordinal()] = 14;
            /* goto @228; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SELECT_SLOT.ordinal()] = 14;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.XCARRY.ordinal()] = 15;
            /* goto @244; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.XCARRY.ordinal()] = 15;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DROP.ordinal()] = 16;
            /* goto @260; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DROP.ordinal()] = 16;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.ITEM.ordinal()] = 17;
            /* goto @276; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.ITEM.ordinal()] = 17;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.TICK_SYNC.ordinal()] = 18;
            /* goto @292; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.TICK_SYNC.ordinal()] = 18;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.REVISION_SYNC.ordinal()] = 19;
            /* goto @308; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.REVISION_SYNC.ordinal()] = 19;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SERVER_TICK_SYNC.ordinal()] = 20;
            /* goto @324; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SERVER_TICK_SYNC.ordinal()] = 20;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CLOSE_GUI.ordinal()] = 21;
            /* goto @340; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CLOSE_GUI.ordinal()] = 21;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SWAP_SLOTS.ordinal()] = 22;
            /* goto @356; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SWAP_SLOTS.ordinal()] = 22;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_COOLDOWN.ordinal()] = 23;
            /* goto @372; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_COOLDOWN.ordinal()] = 23;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.GO_TO.ordinal()] = 24;
            /* goto @388; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.GO_TO.ordinal()] = 24;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_POS.ordinal()] = 25;
            /* goto @404; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_POS.ordinal()] = 25;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DISCONNECT.ordinal()] = 26;
            /* goto @420; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DISCONNECT.ordinal()] = 26;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.TOGGLE_MODULE.ordinal()] = 27;
            /* goto @436; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.TOGGLE_MODULE.ordinal()] = 27;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.STOP_MACRO.ordinal()] = 28;
            /* goto @452; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.STOP_MACRO.ordinal()] = 28;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SNEAK.ordinal()] = 29;
            /* goto @468; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SNEAK.ordinal()] = 29;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.JUMP.ordinal()] = 30;
            /* goto @484; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.JUMP.ordinal()] = 30;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SPRINT.ordinal()] = 31;
            /* goto @500; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SPRINT.ordinal()] = 31;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.MOVE.ordinal()] = 32;
            /* goto @516; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.MOVE.ordinal()] = 32;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.LOOK_AT_BLOCK.ordinal()] = 33;
            /* goto @532; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.LOOK_AT_BLOCK.ordinal()] = 33;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.REPEAT.ordinal()] = 34;
            /* goto @548; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.REPEAT.ordinal()] = 34;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_CHAT.ordinal()] = 35;
            /* goto @564; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_CHAT.ordinal()] = 35;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_ENTITY.ordinal()] = 36;
            /* goto @580; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_ENTITY.ordinal()] = 36;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_SLOT_CHANGE.ordinal()] = 37;
            /* goto @596; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_SLOT_CHANGE.ordinal()] = 37;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.OPEN_CONTAINER.ordinal()] = 38;
            /* goto @612; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.OPEN_CONTAINER.ordinal()] = 38;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DESYNC.ordinal()] = 39;
            /* goto @628; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DESYNC.ordinal()] = 39;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.RESTORE_GUI.ordinal()] = 40;
            /* goto @644; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.RESTORE_GUI.ordinal()] = 40;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SAVE_GUI.ordinal()] = 41;
            /* goto @660; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SAVE_GUI.ordinal()] = 41;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_TOGGLE.ordinal()] = 42;
            /* goto @676; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_TOGGLE.ordinal()] = 42;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DELAY_PACKETS.ordinal()] = 43;
            /* goto @692; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DELAY_PACKETS.ordinal()] = 43;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.INVENTORY_AUDIT.ordinal()] = 44;
            /* goto @708; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.INVENTORY_AUDIT.ordinal()] = 44;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.STORE_ITEM.ordinal()] = 45;
            /* goto @724; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.STORE_ITEM.ordinal()] = 45;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_SOUND.ordinal()] = 46;
            /* goto @740; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_SOUND.ordinal()] = 46;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.MINE.ordinal()] = 47;
            /* goto @756; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.MINE.ordinal()] = 47;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.PAY.ordinal()] = 48;
            /* goto @772; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.PAY.ordinal()] = 48;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.NBT_BOOK.ordinal()] = 49;
            /* goto @788; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.NBT_BOOK.ordinal()] = 49;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_CHAT.ordinal()] = 50;
            /* goto @804; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_CHAT.ordinal()] = 50;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_LAN_STEP.ordinal()] = 51;
            /* goto L820; */
            var0 = null;
            L820: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_LAN_STEP.ordinal()] = 51;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
