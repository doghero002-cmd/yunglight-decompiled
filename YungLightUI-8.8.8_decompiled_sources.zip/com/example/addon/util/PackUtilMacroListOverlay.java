/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiLabel;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiRow;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiSurface;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.gui.packui.PackUiViewportSlot;
import com.example.addon.gui.packui.PackUiWindowNode;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.MeteorMacroAdapter;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilClipboardHelper;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroEditorOverlay;
import com.example.addon.util.PackUtilMacroManager;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.macro.MacroExecutor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilMacroListOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final int MIN_PANEL_WIDTH = 258;
    private static final int ROW_HEIGHT = 18;
    private static final int MAX_VISIBLE_ROWS = 6;
    private static final int PAD = 6;
    private static final int HEADER_CONTROL = 12;
    private static final int HEADER_ARROW_WIDTH = 10;
    private static final int HEADER_ARROW_GAP = 3;
    private static final float HEADER_CLICK_DRAG_THRESHOLD = 3f;
    private static final long METEOR_CACHE_MS = 2000L;
    private static final int ROW_BUTTON_HEIGHT = 14;
    private static final int DELETE_BUTTON_WIDTH = 16;
    private static final int ROW_BUTTON_GAP = 4;
    private static final int ROW_BUTTON_PADDING = 2;
    private static final int VIEWPORT_BORDER = 1;
    private final class_327 textRenderer;
    private final PackUtilMacroEditorOverlay activeEditor;
    private final PackUiTheme theme;
    private final PackUiWindowNode windowNode;
    private final PackUiSurface surface;
    private final PackUiTextField searchField;
    private final PackUiTextField pasteNameField;
    private final PackUiViewportSlot listSlot;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private boolean visible;
    private boolean collapsed;
    private boolean dragging;
    private float dragOffsetX;
    private float dragOffsetY;
    private float pressStartUiX;
    private float pressStartUiY;
    private int pressStartPanelX;
    private int pressStartPanelY;
    private boolean dragMoved;
    private final PackUiSmoothScroll listScroll;
    private boolean pasteMode;
    private float closeHover;
    private float closeVisibility;
    private int contentHeight;
    private boolean scrollbarDragging;
    private int scrollbarGrabOffset;
    private int lastKnownMacroCount;
    private boolean lastKnownPasteMode;
    private boolean needsUiRebuild;
    private final List<PackUtilMacroListOverlay.ClickRegion> clickRegions;
    private List<PackUtilMacroListOverlay.DisplayItem> currentItems;
    private List<PackUtilMacro> cachedMeteorMacros;
    private long meteorMacroCacheTime;

    public PackUtilMacroListOverlay(class_327 textRenderer) {
        this(textRenderer, null);
    }

    public PackUtilMacroListOverlay(class_327 textRenderer, PackUtilMacroEditorOverlay activeEditor) {
        this.theme = new PackUiTheme();
        this.windowNode = new PackUiWindowNode("Macro Library");
        this.surface = new PackUiSurface(this.theme, this.windowNode);
        this.searchField = new PackUiTextField();
        this.pasteNameField = new PackUiTextField();
        this.listSlot = new PackUiViewportSlot();
        this.panelX = 500;
        this.panelY = 250;
        this.panelWidth = 258;
        this.panelHeight = 220;
        this.visible = false;
        this.collapsed = false;
        this.dragging = false;
        this.dragMoved = false;
        this.listScroll = new PackUiSmoothScroll();
        this.pasteMode = false;
        this.closeHover = 0f;
        this.closeVisibility = 1f;
        this.contentHeight = 0;
        this.scrollbarDragging = false;
        this.scrollbarGrabOffset = 0;
        this.lastKnownMacroCount = -1;
        this.lastKnownPasteMode = false;
        this.needsUiRebuild = true;
        this.clickRegions = new ArrayList();
        this.currentItems = List.of();
        this.cachedMeteorMacros = Collections.emptyList();
        this.meteorMacroCacheTime = 0L;
        this.textRenderer = textRenderer;
        this.activeEditor = activeEditor;
        this.buildUi();
    }

    private void buildUi() {
        this.panelWidth = this.panelMinimumWidth();
        this.windowNode.setCenterTitle(false);
        this.windowNode.setTitleTone(PackUiTone.LABEL);
        this.windowNode.setTitleAreaInsets(this.panelPadding() + 2, this.panelPadding() + this.headerControlSize() + this.headerArrowWidth() + this.headerArrowGap() + 12);
        this.windowNode.content().setGap(this.windowContentGap()).setPadding(PackUiInsets.all(this.panelPadding()));
        this.searchField.setPlaceholder("Search macros...").setFieldHeight(this.searchFieldHeight()).setGrowX(true).setOnChange(this::lambda$buildUi$0);
        this.pasteNameField.setPlaceholder("New macro name...").setFieldHeight(this.searchFieldHeight()).setGrowX(true).setOnSubmit(this::lambda$buildUi$1);
        this.rebuildUi();
    }

    private void rebuildData() {
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        this.currentItems = this.buildDisplayItems(PackUtilMacroManager.get().getAll(), this.getCachedMeteorMacros(), sync.getAllRemoteMacros(), sync.getAllRemoteMeteorMacros(), sync);
        this.contentHeight = this.currentItems.size() * this.rowHeight();
    }

    private void rebuildUi() {
        this.windowNode.content().clearChildren();
        this.rebuildData();
        this.windowNode.setTitle("Macro Library [" + PackUtilMacroManager.get().getAll().size() + "]");
        this.windowNode.content().add(this.searchField);
        if (this.currentItems.isEmpty()) {
            this.windowNode.content().add(new PackUiLabel("No macros match the current filter.", PackUiTone.MUTED).setTrimToBounds(true));
        } else {
            this.listSlot.setPreferredHeight((float)this.computeViewportHeight(this.currentItems.size()));
            this.windowNode.content().add(this.listSlot);
        }
        if (this.pasteMode) {
            this.windowNode.content().add(this.pasteNameField);
            PackUiRow actions = new PackUiRow().setGap(this.actionRowGap());
            actions.add(new PackUiButton("Paste", PackUiButton.Variant.SUCCESS, this::pasteMacroFromClipboard).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
            actions.add(new PackUiButton("Cancel", PackUiButton.Variant.SECONDARY, this::cancelPasteMode).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
            this.windowNode.content().add(actions);
            this.windowNode.content().add(new PackUiLabel("Paste a copied macro under a new name.", PackUiTone.MUTED).setTrimToBounds(true));
        } else {
            PackUiRow actions = new PackUiRow().setGap(this.actionRowGap());
            actions.add(new PackUiButton("Create New", PackUiButton.Variant.SECONDARY, this::openCreateNew).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
            actions.add(new PackUiButton("Paste", PackUiButton.Variant.SECONDARY, this::beginPasteMode).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
            this.windowNode.content().add(actions);
        }
    }

    private int computeViewportHeight(int itemCount) {
        int visibleRows = Math.max(3, Math.min(this.maxVisibleRows(), itemCount));
        return visibleRows * this.rowHeight() + 2;
    }

    private List<PackUtilMacro> getCachedMeteorMacros() {
        long now = System.currentTimeMillis();
        if (now - this.meteorMacroCacheTime > 2000L) {
            this.cachedMeteorMacros = MeteorMacroAdapter.getMeteorMacros();
            this.meteorMacroCacheTime = now;
        }
        return this.cachedMeteorMacros;
    }

    public PackUtilMacroEditorOverlay getActiveEditor() {
        return this.activeEditor;
    }

    public void saveState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setMacroListOverlayVisible(this.visible);
        shared.setMacroListOverlayX(this.panelX);
        shared.setMacroListOverlayY(this.panelY);
        shared.setMacroListOverlayScrollOffset(this.listScroll.targetOffset());
        shared.setMacroListOverlaySearch(this.searchField.text());
        this.saveLayout();
    }

    public void restoreState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.restoreLayout();
        this.visible = shared.isMacroListOverlayVisible();
        this.panelX = shared.getMacroListOverlayX();
        this.panelY = shared.getMacroListOverlayY();
        this.listScroll.restore(shared.getMacroListOverlayScrollOffset());
        this.searchField.setText(shared.getMacroListOverlaySearch());
        this.needsUiRebuild = true;
        this.windowNode.restoreShowBody(!this.collapsed);
    }

    public String getOverlayId() {
        return "packutil-macrolist";
    }

    public int getMinWidth() {
        return this.panelMinimumWidth();
    }

    public int getMinHeight() {
        return this.theme.headerHeight() + this.searchFieldHeight() + this.actionButtonHeight() + this.panelPadding() * 2 + this.windowContentGap();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToViewport(bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
    }

    public void setVisible(boolean visible) {
        this.visible = false;
        if (visible && this.activeEditor != null && this.activeEditor.isVisible()) {
            this.saveState();
            PackUtilOverlayManager.get().bringToFront(this.activeEditor);
            return;
        }
        this.visible = visible;
        if (!visible) {
            this.surface.clearFocusedTextInputs();
            this.dragging = false;
            this.dragMoved = false;
        } else {
            this.needsUiRebuild = true;
            this.windowNode.restoreShowBody(!this.collapsed);
            PackUtilOverlayManager.get().bringToFront(this);
        }
        this.saveState();
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.dragging = false;
        this.dragMoved = false;
        if (collapsed) {
            this.surface.clearFocusedTextInputs();
        }
        this.saveState();
    }

    public boolean hasTextFieldFocused() {
        return this.surface.hasFocusedTextInput();
    }

    public void clearTextFieldFocus() {
        this.surface.clearFocusedTextInputs();
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiX = viewport.toUiX(mouseX);
        float uiY = viewport.toUiY(mouseY);
        return uiX >= (float)this.panelX && uiX <= (float)(this.panelX + this.panelWidth) && uiY >= (float)this.panelY && uiY <= (float)(this.panelY + this.panelHeight);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiX = viewport.toUiX(mouseX);
        float uiY = viewport.toUiY(mouseY);
        return this.isOverHeaderUi(uiX, uiY) && !this.isOverCloseButton(uiX, uiY);
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible || MC == null || MC.field_1772 == null) {
            return;
        }
        int currentMacroCount = PackUtilMacroManager.get().getAll().size();
        if (this.needsUiRebuild || currentMacroCount != this.lastKnownMacroCount || this.pasteMode != this.lastKnownPasteMode) {
            this.rebuildUi();
            this.lastKnownMacroCount = currentMacroCount;
            this.lastKnownPasteMode = this.pasteMode;
            this.needsUiRebuild = false;
        } else {
            this.windowNode.setTitle("Macro Library [" + currentMacroCount + "]");
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX((double)mouseX);
        float uiMouseY = viewport.toUiY((double)mouseY);
        boolean active = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        boolean headerHovered = this.isOverHeaderUi(uiMouseX, uiMouseY);
        PackUiRenderContext metrics = new PackUiRenderContext(context, MC.field_1772, viewport, this.theme, uiMouseX, uiMouseY, delta);
        this.windowNode.setShowBody(!this.collapsed);
        this.windowNode.setActive(active);
        this.windowNode.setHeaderHovered(headerHovered);
        this.panelHeight = Math.round(this.windowNode.preferredHeight(metrics, (float)this.panelWidth));
        this.panelHeight = Math.max(this.theme.headerHeight(), this.panelHeight);
        this.windowNode.setBounds((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight);
        this.surface.render(context, mouseX, mouseY, delta);
        this.renderListViewport(context, viewport, uiMouseX, uiMouseY, delta, active);
        if (this.panelHeight > this.theme.headerHeight() + 1 && !this.currentItems.isEmpty()) {
        } else {
            this.clickRegions.clear();
        }
        this.renderHeaderControls(context, viewport, uiMouseX, uiMouseY, delta, active);
    }

    private void renderHeaderControls(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta, boolean active) {
        this.closeVisibility = this.animate(this.closeVisibility, 1f, delta);
        this.closeHover = this.animate(this.closeHover, this.isOverCloseButton(uiMouseX, uiMouseY) ? 1f : 0f, delta);
        viewport.push(context);
        try {
            int arrowX = this.collapseArrowX();
            int closeX = this.closeButtonX();
            int controlY = this.controlButtonY();
            this.drawCollapseArrow(context, arrowX, controlY, active);
            this.drawCloseButton(context, closeX, controlY, this.headerControlSize(), this.headerControlSize(), this.closeHover, active, this.closeVisibility);
        }
        finally {
            viewport.pop(context);
            throw var10;
        }
    }

    private void renderListViewport(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta, boolean active) {
        this.clickRegions.clear();
        int viewX = Math.round(this.listSlot.x());
        int viewY = Math.round(this.listSlot.y());
        int viewW = Math.round(this.listSlot.width());
        int viewH = Math.round(this.listSlot.height());
        if (viewW <= 2 || viewH <= 2) {
            return;
        }
        int maxScroll = Math.max(0, this.contentHeight - Math.max(0, viewH - 2));
        int drawScroll = this.listScroll.tick(delta, maxScroll);
        float alpha = active ? 1f : 0.56f;
        context.method_25294(viewX, viewY, viewX + viewW, viewY + viewH, PackUiRenderContext.applyAlpha(905969664, alpha));
        context.method_25294(viewX, viewY, viewX + viewW, viewY + 1, PackUiRenderContext.applyAlpha(this.theme.borderSoft(), alpha));
        context.method_25294(viewX, viewY + viewH - 1, viewX + viewW, viewY + viewH, PackUiRenderContext.applyAlpha(this.theme.borderSoft(), alpha));
        context.method_25294(viewX, viewY, viewX + 1, viewY + viewH, PackUiRenderContext.applyAlpha(this.theme.borderSoft(), alpha));
        context.method_25294(viewX + viewW - 1, viewY, viewX + viewW, viewY + viewH, PackUiRenderContext.applyAlpha(this.theme.borderSoft(), alpha));
        viewport.enableScissor(context, (float)(viewX + 1), (float)(viewY + 1), (float)(viewX + viewW - 1), (float)(viewY + viewH - 1));
        try {
            PackUiRenderContext rowContext = new PackUiRenderContext(context, this.textRenderer, viewport, this.theme, uiMouseX, uiMouseY, delta, alpha);
            int baseY = viewY + 1 - drawScroll;
            for (int i = 0; i < this.currentItems.size(); i++) {
                int rowY = baseY + i * this.rowHeight();
                if (rowY + this.rowHeight() <= viewY + 1) { /* goto L462; */ }
                if (rowY >= viewY + viewH - 1) {
                } else {
                    DisplayItem item = (PackUtilMacroListOverlay.DisplayItem)this.currentItems.get(i);
                    if (item.type == PackUtilMacroListOverlay.ItemType.SECTION_HEADER) {
                        this.renderSectionHeader(context, rowContext, item, viewX + 1, rowY, viewW - 2);
                    } else {
                        this.renderMacroRow(context, rowContext, item, viewX + 1, rowY, viewW - 2);
                    }
                }
            }
        }
        finally {
            viewport.disableScissor(context);
            throw var19;
        }
        this.renderScrollbar(context, viewX, viewY, viewW, viewH, uiMouseX, uiMouseY, active ? 1f : 0.56f);
    }

    private PackUiScrollbar.Metrics getScrollbarMetrics(int viewX, int viewY, int viewW, int viewH) {
        return PackUiScrollbar.compute(this.contentHeight, Math.max(0, viewH - 2), viewX + viewW - 5, viewY + 1, 3, Math.max(0, viewH - 2), this.listScroll.tick(0f, Math.max(0, this.contentHeight - Math.max(0, viewH - 2))));
    }

    private void renderScrollbar(class_332 context, int viewX, int viewY, int viewW, int viewH, float uiMouseX, float uiMouseY, float alpha) {
        Metrics metrics = this.getScrollbarMetrics(viewX, viewY, viewW, viewH);
        if (!metrics.hasScroll()) {
            return;
        }
        PackUiScrollbar.draw(context, metrics, metrics.contains((double)uiMouseX, (double)uiMouseY), this.scrollbarDragging);
    }

    private void renderSectionHeader(class_332 context, PackUiRenderContext rowContext, PackUtilMacroListOverlay.DisplayItem item, int x, int y, int width) {
        int textY = PackUiSizing.alignTextY(y, this.rowHeight(), this.theme.fontHeight(PackUiTone.LABEL), this.theme.bodyTextNudge());
        context.method_25294(x + this.sectionHeaderInset(), y + this.rowHeight() - 2, x + width - this.sectionHeaderInset(), y + this.rowHeight() - 1, rowContext.applyAlpha(1124073471));
        PackUiText.draw(context, this.textRenderer, item.label, this.theme.fontFor(PackUiTone.LABEL), rowContext.applyAlpha(item.color), x + this.sectionHeaderInset(), textY, false);
    }

    private void renderMacroRow(class_332 context, PackUiRenderContext rowContext, PackUtilMacroListOverlay.DisplayItem item, int x, int y, int width) {
        boolean hovered = this.uiContains((float)x, (float)y, (float)width, (float)this.rowHeight(), rowContext.mouseX(), rowContext.mouseY());
        if (hovered) {
            context.method_25294(x, y, x + width, y + this.rowHeight(), rowContext.applyAlpha(452938314));
        }
        List<PackUtilMacroListOverlay.RowButton> buttons = this.buildRowButtons(item);
        int buttonCursor = x + width - this.rowTextInset();
        int buttonY = y + this.rowButtonTopInset();
        for (int i = buttons.size() - 1; i >= 0; i--) {
            RowButton button = (PackUtilMacroListOverlay.RowButton)buttons.get(i);
            buttonCursor = buttonCursor - button.width;
            this.drawRowButton(context, rowContext, buttonCursor, buttonY, button.width, button);
            this.clickRegions.add(new PackUtilMacroListOverlay.ClickRegion(buttonCursor, buttonY, button.width, this.rowButtonHeight(), button.action));
            buttonCursor = buttonCursor - this.rowButtonGap();
        }
        textLeft = x + this.rowTextInset();
        if (item.type != PackUtilMacroListOverlay.ItemType.LOCAL_MACRO) { /* goto L325; */ }
        running = MacroExecutor.isRunning() && MacroExecutor.getCurrentMacroName() != null && MacroExecutor.getCurrentMacroName().equals(item.macro.name);
        int dotColor = running ? rowContext.applyAlpha(-13379224) : rowContext.applyAlpha(-10132123);
        int dotTop = y + PackUiSizing.alignMiddle(0, this.rowHeight(), this.rowDotSize());
        context.method_25294(textLeft, dotTop, textLeft + this.rowDotSize(), dotTop + this.rowDotSize(), dotColor);
        textLeft = textLeft + (this.rowTextInset() + 2);
        L325: ;
        rightLimit = Math.max(textLeft + 20, buttonCursor - 2);
        labelWidth = Math.max(20, rightLimit - textLeft);
        switch (item.type.ordinal()) {
            case 1::
                primaryText = item.macro.name;
                break;
            case 2::
                primaryText = item.label;
                break;
            case 3::
                primaryText = "Meteor: " + item.macro.name;
                break;
            default:
                primaryText = item.label;
                break;
        }
        switch (item.type.ordinal()) {
            case 1::
                String secondaryText = item.macro.actions.size() + " steps";
                break;
            case 2::
                if (item.remoteSource == null) { /* goto L493; */ }
                secondaryText = item.remoteSource.isBlank() ? "" : item.remoteSource;
                break;
            case 3::
                secondaryText = item.macro.actions.size() + " steps";
                break;
            default:
                secondaryText = "";
                break;
        }
        switch (item.type.ordinal()) {
            case 1::
                int primaryColor = rowContext.applyAlpha(-791321);
                break;
            case 2::
                primaryColor = rowContext.applyAlpha(item.remoteMeteor ? -2698497 : -12122);
                break;
            case 3::
                primaryColor = rowContext.applyAlpha(-2562305);
                break;
            default:
                primaryColor = rowContext.applyAlpha(this.theme.color(PackUiTone.BODY));
                break;
        }
        int secondaryColor = rowContext.applyAlpha(this.theme.color(PackUiTone.MUTED));
        int textY = PackUiSizing.alignTextY(y, this.rowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
        if (item.type == PackUtilMacroListOverlay.ItemType.LOCAL_MACRO) {
            int secondaryWidth = PackUiText.width(this.textRenderer, secondaryText, this.theme.fontFor(PackUiTone.BODY), secondaryColor);
            int secondaryX = Math.max(textLeft + 10, rightLimit - secondaryWidth);
            int primaryMaxWidth = Math.max(20, secondaryX - textLeft - 8);
            String trimmedPrimary = PackUiText.trimToWidth(this.textRenderer, primaryText, primaryMaxWidth, this.theme.fontFor(PackUiTone.BODY), primaryColor);
            PackUiText.draw(context, this.textRenderer, trimmedPrimary, this.theme.fontFor(PackUiTone.BODY), primaryColor, textLeft, textY, false);
            PackUiText.draw(context, this.textRenderer, secondaryText, this.theme.fontFor(PackUiTone.BODY), secondaryColor, secondaryX, textY, false);
        } else {
            String trimmedPrimary = PackUiText.trimToWidth(this.textRenderer, primaryText, labelWidth, this.theme.fontFor(PackUiTone.BODY), primaryColor);
            PackUiText.draw(context, this.textRenderer, trimmedPrimary, this.theme.fontFor(PackUiTone.BODY), primaryColor, textLeft, textY, false);
            if (!secondaryText.isEmpty()) {
                int secondaryX = textLeft + Math.min(labelWidth - 10, Math.max(PackUiText.width(this.textRenderer, trimmedPrimary, this.theme.fontFor(PackUiTone.BODY), primaryColor) + 10, labelWidth - 90));
                int secondaryWidth = Math.max(0, rightLimit - secondaryX);
                if (secondaryWidth > 18) {
                    String trimmedSecondary = PackUiText.trimToWidth(this.textRenderer, secondaryText, secondaryWidth, this.theme.fontFor(PackUiTone.BODY), secondaryColor);
                    PackUiText.draw(context, this.textRenderer, trimmedSecondary, this.theme.fontFor(PackUiTone.BODY), secondaryColor, secondaryX, textY, false);
                }
            }
        }
    }

    private void drawRowButton(class_332 context, PackUiRenderContext rowContext, int x, int y, int width, PackUtilMacroListOverlay.RowButton button) {
        PackUiButton node = new PackUiButton(button.label, button.variant, button.action).setButtonHeight(this.rowButtonHeight()).setPreferredWidth((float)width).setHorizontalPadding(this.rowButtonPadding()).setTextYOffset("X".equals(button.label) ? -1 : 0);
        node.setBounds((float)x, (float)y, (float)width, (float)this.rowButtonHeight());
        node.render(rowContext);
    }

    private int measureRowButtonWidth(String label, int minWidth, int maxWidth) {
        return PackUiSizing.fitTextWidthInt(this.textRenderer, label, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY), this.rowButtonPadding(), minWidth, maxWidth);
    }

    private List<PackUtilMacroListOverlay.RowButton> buildRowButtons(PackUtilMacroListOverlay.DisplayItem item) {
        List<PackUtilMacroListOverlay.RowButton> buttons = new ArrayList();
        switch (item.type.ordinal()) {
            case 1::
                boolean running = MacroExecutor.isRunning() && MacroExecutor.getCurrentMacroName() != null && MacroExecutor.getCurrentMacroName().equals(item.macro.name);
                String runLabel = running ? "STOP" : "RUN";
                buttons.add(new PackUtilMacroListOverlay.RowButton(runLabel, running ? PackUiButton.Variant.DANGER : PackUiButton.Variant.SUCCESS, this.measureRowButtonWidth(runLabel, 22, 46), PackUtilMacroListOverlay::lambda$buildRowButtons$2 /* captured: running, item */));
                buttons.add(new PackUtilMacroListOverlay.RowButton("EDIT", PackUiButton.Variant.SECONDARY, this.measureRowButtonWidth("EDIT", 24, 42), this::lambda$buildRowButtons$3 /* captured: item */));
                buttons.add(new PackUtilMacroListOverlay.RowButton("COPY", PackUiButton.Variant.SECONDARY, this.measureRowButtonWidth("COPY", 26, 44), PackUtilMacroListOverlay::lambda$buildRowButtons$4 /* captured: item */));
                buttons.add(new PackUtilMacroListOverlay.RowButton("X", PackUiButton.Variant.DANGER, this.deleteButtonWidth(), PackUtilMacroListOverlay::lambda$buildRowButtons$5 /* captured: item */));
                /* goto @325; */
            case 2::
                buttons.add(new PackUtilMacroListOverlay.RowButton("IMPORT", PackUiButton.Variant.SECONDARY, this.measureRowButtonWidth("IMPORT", 34, 58), this::lambda$buildRowButtons$6 /* captured: item */));
                /* goto @325; */
            case 3::
                buttons.add(new PackUtilMacroListOverlay.RowButton("REFACTOR", PackUiButton.Variant.SECONDARY, this.measureRowButtonWidth("REFACTOR", 42, 70), this::lambda$buildRowButtons$7 /* captured: item */));
                /* goto @325; */
            default:
                return buttons;
        }
    }

    private void importRemoteMacro(PackUtilMacroListOverlay.DisplayItem item) {
        if (item.remoteSource == null || item.remoteSource.isBlank()) {
            return;
        }
        PackUtilLANSync sync = PackUtilLANSync.getInstance();
        Map<String, Map<String, PackUtilMacro>> allRemote = item.remoteMeteor ? sync.getAllRemoteMeteorMacros() : sync.getAllRemoteMacros();
        Map<String, PackUtilMacro> remoteMacros = (Map)allRemote.get(item.remoteSource);
        PackUtilMacro source = remoteMacros != null ? (PackUtilMacro)remoteMacros.get(item.label) : null;
        if (source == null) {
            PackUtilClientMessaging.sendPrefixed("Â§cRemote macro is no longer available: " + item.label);
            return;
        }
        PackUtilMacro imported = PackUtilMacroManager.get().addImportedCopy(source, source.name);
        if (imported == null) {
            PackUtilClientMessaging.sendPrefixed("Â§cFailed to import macro: " + item.label);
            return;
        }
        String sourceType = item.remoteMeteor ? "Meteor macro" : "macro";
        PackUtilClientMessaging.sendPrefixed("Â§aImported " + sourceType + " as: " + imported.name);
        this.rebuildData();
    }

    private void importMeteorMacro(PackUtilMacroListOverlay.DisplayItem item) {
        if (item.macro == null) {
            return;
        }
        PackUtilMacro imported = PackUtilMacroManager.get().addImportedCopy(item.macro, item.macro.name);
        if (imported == null) {
            PackUtilClientMessaging.sendPrefixed("Â§cFailed to import from Meteor.");
            return;
        }
        PackUtilClientMessaging.sendPrefixed("Â§aImported Meteor macro as: " + imported.name);
        this.rebuildData();
    }

    private void openCreateNew() {
        this.setVisible(false);
        PackUtilMacroEditorOverlay.getSharedOverlay().open(null, true);
    }

    private void beginPasteMode() {
        this.pasteMode = true;
        this.pasteNameField.setText("");
        this.listScroll.jumpTo(0, 0);
        this.needsUiRebuild = true;
    }

    private void cancelPasteMode() {
        this.pasteMode = false;
        this.pasteNameField.setText("");
        this.pasteNameField.setFocused(false);
        this.needsUiRebuild = true;
    }

    private boolean pasteMacroFromClipboard() {
        String name = this.pasteNameField.text().trim();
        if (name.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("Â§cEnter a name for the pasted macro.");
            return true;
        }
        if (PackUtilMacroManager.get().get(name) != null) {
            PackUtilClientMessaging.sendPrefixed("Â§cA macro with that name already exists.");
            return true;
        }
        PackUtilMacro pasted = PackUtilClipboardHelper.pasteMacroFromClipboard();
        if (pasted == null) {
            PackUtilClientMessaging.sendPrefixed("Â§cClipboard does not contain a valid copied macro.");
            return true;
        }
        pasted.name = name;
        PackUtilMacroManager.get().add(pasted);
        PackUtilClientMessaging.sendPrefixed("Â§aPasted macro: " + pasted.name);
        this.cancelPasteMode();
        return true;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        this.setVisible(false);
        if (button == 0 && this.isOverCloseButton(uiMouseX, uiMouseY) && this.closeVisibility > 0.01f) {
            return true;
        }
        this.dragging = true;
        if (button == 0 && this.isOverHeaderUi(uiMouseX, uiMouseY)) {
            this.dragMoved = false;
            this.dragOffsetX = uiMouseX - (float)this.panelX;
            this.dragOffsetY = uiMouseY - (float)this.panelY;
            this.pressStartUiX = uiMouseX;
            this.pressStartUiY = uiMouseY;
            this.pressStartPanelX = this.panelX;
            this.pressStartPanelY = this.panelY;
            return true;
        }
        if (!this.collapsed && this.surface.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (this.collapsed) { /* goto L352; */ }
        if (button != 0) { /* goto L352; */ }
        if (!this.uiContains(this.listSlot.x(), this.listSlot.y(), this.listSlot.width(), this.listSlot.height(), uiMouseX, uiMouseY)) { /* goto L352; */ }
        Metrics metrics = this.getScrollbarMetrics(Math.round(this.listSlot.x()), Math.round(this.listSlot.y()), Math.round(this.listSlot.width()), Math.round(this.listSlot.height()));
        if (!metrics.hasScroll()) { /* goto L352; */ }
        if (!metrics.contains((double)uiMouseX, (double)uiMouseY)) { /* goto L352; */ }
        this.scrollbarDragging = true;
        this.scrollbarGrabOffset = metrics.overThumb((double)uiMouseX, (double)uiMouseY) ? Math.round(uiMouseY) - metrics.thumbY() : metrics.thumbHeight() / 2;
        this.listScroll.setFromThumb(metrics, (double)uiMouseY, this.scrollbarGrabOffset);
        return true;
        if (this.collapsed) { /* goto L428; */ }
        if (button != 0) { /* goto L428; */ }
        for (i = this.clickRegions.size() - 1; i >= 0; i--) {
            ClickRegion region = (PackUtilMacroListOverlay.ClickRegion)this.clickRegions.get(i);
            if (region.contains(uiMouseX, uiMouseY)) {
                region.action.run();
                return true;
            }
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        if (button != 0) { /* goto L164; */ }
        if (!this.dragging) { /* goto L164; */ }
        boolean moved = this.dragMoved || Math.abs(uiMouseX - this.pressStartUiX) >= 3f || Math.abs(uiMouseY - this.pressStartUiY) >= 3f || this.panelX != this.pressStartPanelX || this.panelY != this.pressStartPanelY;
        this.dragging = false;
        this.dragMoved = false;
        if (moved) { /* goto L158; */ }
        if (!this.isOverHeaderUi(uiMouseX, uiMouseY)) { /* goto L158; */ }
        if (this.isOverCloseButton(uiMouseX, uiMouseY)) { /* goto L158; */ }
        this.setCollapsed(!this.collapsed);
        this.saveState();
        return true;
        this.scrollbarDragging = false;
        if (button == 0 && this.scrollbarDragging) {
            this.saveState();
            return true;
        }
        if (!this.collapsed && this.surface.mouseReleased(mouseX, mouseY, button)) {
            return true;
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        if (this.dragging) {
            if (button == 0) {
                int nextX = Math.round(uiMouseX - this.dragOffsetX);
                int nextY = Math.round(uiMouseY - this.dragOffsetY);
                if (nextX != this.panelX || nextY != this.panelY) {
                    this.dragMoved = true;
                }
                PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(nextX, nextY, this.panelWidth, this.panelHeight, this.visible, this.collapsed));
                this.panelX = clamped.x;
                this.panelY = clamped.y;
                return true;
            }
        }
        metrics = this.getScrollbarMetrics(Math.round(this.listSlot.x()), Math.round(this.listSlot.y()), Math.round(this.listSlot.width()), Math.round(this.listSlot.height()));
        if (this.scrollbarDragging && button == 0) {
            this.listScroll.setFromThumb(metrics, (double)uiMouseY, this.scrollbarGrabOffset);
            return true;
        }
        if (!this.collapsed && this.surface.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible || this.collapsed) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        if (this.surface.mouseScrolled(mouseX, mouseY, amount)) {
            return true;
        }
        if (this.uiContains(this.listSlot.x(), this.listSlot.y(), this.listSlot.width(), this.listSlot.height(), uiMouseX, uiMouseY)) {
            int visibleHeight = Math.max(0, Math.round(this.listSlot.height()) - 2);
            int maxScroll = Math.max(0, this.contentHeight - visibleHeight);
            this.listScroll.nudge(amount, (float)this.rowHeight(), maxScroll);
            return true;
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (this.surface.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        this.cancelPasteMode();
        if (keyCode == 256 && this.pasteMode) {
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        return this.visible && this.surface.charTyped(chr, modifiers);
    }

    private List<PackUtilMacroListOverlay.DisplayItem> buildDisplayItems(List<PackUtilMacro> localMacros, List<PackUtilMacro> meteorMacros, Map<String, Map<String, PackUtilMacro>> remoteMacros, Map<String, Map<String, PackUtilMacro>> remoteMeteorMacros, PackUtilLANSync sync) {
        String filter = this.searchField.text().trim().toLowerCase(Locale.ROOT);
        List<PackUtilMacroListOverlay.DisplayItem> items = new ArrayList();
        List<PackUtilMacroListOverlay.DisplayItem> localSection = new ArrayList();
        List<PackUtilMacroListOverlay.DisplayItem> remoteSection = localMacros.iterator();
        while (remoteSection.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)remoteSection.next();
            while (!this.matchesFilter(macro.name, filter)) {
            }
            localSection.add(PackUtilMacroListOverlay.DisplayItem.localMacro(macro));
        }
        if (!localSection.isEmpty()) {
            items.add(PackUtilMacroListOverlay.DisplayItem.section("YungLight Macros", -43691));
            items.addAll(localSection);
        }
        remoteSection = new ArrayList();
        if (!sync.isInSession()) { /* goto L299; */ }
        meteorSection = remoteMacros.entrySet().iterator();
        while (meteorSection.hasNext()) {
            Map.Entry<String, Map<String, PackUtilMacro>> entry = (Map.Entry)meteorSection.next();
            PackUtilMacro macro = ((Map)entry.getValue()).values().iterator();
            while (macro.hasNext()) {
                PackUtilMacro macro = (PackUtilMacro)macro.next();
                while (PackUtilMacroManager.get().get(macro.name) != null) {
                }
                while (!this.matchesFilter(macro.name, filter)) {
                }
                remoteSection.add(PackUtilMacroListOverlay.DisplayItem.remoteMacro(macro.name, (String)entry.getKey(), false));
            }
        }
        if (!remoteSection.isEmpty()) {
            if (localSection.isEmpty()) {
                items.add(PackUtilMacroListOverlay.DisplayItem.section("YungLight Macros", -43691));
            }
            items.addAll(remoteSection);
        }
        if (!PackUtilCompatManager.isMeteorAvailable()) {
            return items;
        }
        meteorSection = new ArrayList();
        entry = meteorMacros.iterator();
        while (entry.hasNext()) {
            macro = (PackUtilMacro)entry.next();
            while (!this.matchesFilter(macro.name, filter)) {
            }
            meteorSection.add(PackUtilMacroListOverlay.DisplayItem.meteorMacro(macro));
        }
        if (!sync.isInSession()) { /* goto L631; */ }
        entry = remoteMeteorMacros.entrySet().iterator();
        while (entry.hasNext()) {
            entry = (Map.Entry)entry.next();
            macro = ((Map)entry.getValue()).values().iterator();
            while (macro.hasNext()) {
                PackUtilMacro macro = (PackUtilMacro)macro.next();
                boolean alreadyLocalMeteor = false;
                var var16 = meteorMacros.iterator();
                while (var16.hasNext()) {
                    PackUtilMacro localMeteor = (PackUtilMacro)var16.next();
                    if (!localMeteor.name.equals(macro.name)) { /* goto @570; */ }
                    alreadyLocalMeteor = true;
                    break;
                }
                while (alreadyLocalMeteor) {
                }
                while (!this.matchesFilter(macro.name, filter)) {
                }
                meteorSection.add(PackUtilMacroListOverlay.DisplayItem.remoteMacro(macro.name, (String)entry.getKey(), true));
            }
        }
        if (!meteorSection.isEmpty()) {
            items.add(PackUtilMacroListOverlay.DisplayItem.section("Meteor Macros", -2562305));
            items.addAll(meteorSection);
        }
        return items;
    }

    private boolean matchesFilter(String name, String filter) {
        if (!filter.isEmpty()) {
            if (name == null) { /* goto @29; */ }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L30; */
        L29: ;
        L30: ;
        return false;
    }

    private float animate(float current, float target, float delta) {
        return PackUiHeaderControls.animate(current, target, delta);
    }

    private void drawCollapseArrow(class_332 context, int x, int y, boolean active) {
        PackUiHeaderControls.drawAnimatedArrow(context, x, y + 1, this.headerArrowWidth(), this.collapsed ? 0f : 1f, active ? 1f : 0.56f);
    }

    private void drawCloseButton(class_332 context, int x, int y, int width, int height, float hover, boolean active, float visibility) {
        PackUiHeaderControls.drawCloseButton(context, x, y, width, height, hover, active, visibility);
    }

    private boolean isOverHeaderUi(float uiMouseX, float uiMouseY) {
        return uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.panelWidth) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
    }

    private boolean isOverCloseButton(float uiMouseX, float uiMouseY) {
        return PackUiHeaderControls.isCloseHit(this.closeVisibility, (double)uiMouseX, (double)uiMouseY, this.closeButtonX(), this.controlButtonY(), this.headerControlSize());
    }

    private int controlButtonY() {
        return PackUiHeaderControls.controlY(this.panelY, this.theme.headerHeight(), this.headerControlSize());
    }

    private int closeButtonX() {
        return PackUiHeaderControls.closeX(this.panelX, this.panelWidth, this.headerControlSize(), 2);
    }

    private int collapseArrowX() {
        return PackUiHeaderControls.expandedArrowX(this.closeButtonX(), this.headerArrowGap(), this.headerArrowWidth());
    }

    private PackUtilWindowLayout clampToViewport(PackUtilWindowLayout bounds) {
        PackUiViewport viewport = this.surface.viewport();
        int width = Math.max(this.getMinWidth(), Math.min(bounds.width, Math.round(viewport.uiWidth())));
        int minHeight = bounds.collapsed ? this.theme.headerHeight() : this.getMinHeight();
        int height = Math.max(minHeight, Math.min(bounds.height, Math.round(viewport.uiHeight())));
        int x = Math.max(0, Math.min(bounds.x, Math.max(0, Math.round(viewport.uiWidth()) - width)));
        int y = Math.max(0, Math.min(bounds.y, Math.max(0, Math.round(viewport.uiHeight()) - this.theme.headerHeight())));
        return new PackUtilWindowLayout(x, y, width, height, bounds.visible, bounds.collapsed);
    }

    private boolean uiContains(float x, float y, float width, float height, float mouseX, float mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    private int panelMinimumWidth() {
        return 258;
    }

    private int rowHeight() {
        return 18;
    }

    private int maxVisibleRows() {
        return 6;
    }

    private int panelPadding() {
        return 6;
    }

    private int windowContentGap() {
        return 4;
    }

    private int searchFieldHeight() {
        return 16;
    }

    private int actionRowGap() {
        return 4;
    }

    private int actionButtonHeight() {
        return 16;
    }

    private int headerControlSize() {
        return 12;
    }

    private int headerArrowWidth() {
        return 10;
    }

    private int headerArrowGap() {
        return 3;
    }

    private int rowButtonHeight() {
        return 14;
    }

    private int deleteButtonWidth() {
        return 16;
    }

    private int rowButtonGap() {
        return 4;
    }

    private int rowButtonPadding() {
        return 2;
    }

    private int rowButtonTopInset() {
        return Math.max(1, (this.rowHeight() - this.rowButtonHeight()) / 2);
    }

    private int rowTextInset() {
        return 8;
    }

    private int sectionHeaderInset() {
        return 4;
    }

    private int rowDotSize() {
        return 4;
    }
}
