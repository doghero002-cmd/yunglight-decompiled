/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilFabricatorOverlay;

public class PackUtilFabricatorRegistry {
    private static volatile PackUtilFabricatorOverlay activeOverlay = null;

    public static void setActiveOverlay(PackUtilFabricatorOverlay overlay) {
        activeOverlay = overlay;
    }

    public static PackUtilFabricatorOverlay getActiveOverlay() {
        return activeOverlay;
    }
}
