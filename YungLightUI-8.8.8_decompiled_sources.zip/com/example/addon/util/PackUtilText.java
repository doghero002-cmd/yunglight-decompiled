/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.util.PackUtilColors;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;

public final class PackUtilText {
    private static final Map<class_2960, class_11719> FONT_CACHE = new ConcurrentHashMap();

    private PackUtilText() {
    }

    public static int colorFor(PackUtilText.Tone tone) {
        switch (tone.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
            case 1::
            case 2::
                return PackUtilColors.textPrimary();
            case 3::
                return PackUtilColors.textMuted();
            case 4::
                return PackUtilColors.accent();
        }
    }

    public static class_5250 literal(String value, PackUtilText.Tone tone) {
        return class_2561.method_43470(value == null ? "" : value).method_10862(PackUtilText.styleFor(tone));
    }

    public static class_5250 literal(String value, int color) {
        class_2960 fontId = PackUtilText.fontIdFor(PackUtilText.Tone.BODY);
        return class_2561.method_43470(value == null ? "" : value).method_10862(class_2583.field_24360.method_27704(PackUtilText.fontSource(fontId)).method_36139(color));
    }

    public static String sanitizeUiLabel(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return value.replace("Ã¢Å“â€œ", "X").replace("âœ“", "X").replace("✓", "X").replace("✔", "X").replace("✓", "X").replace("Ã—", "X").replace("×", "X").replace("✕", "X").replace("✖", "X").replace("✕", "X").replace("â†’", "->").replace("→", "->").replace("→", "->").replace("â†\u{90}", "<-").replace("←", "<-").replace("←", "<-").replace("â€”", "-").replace("—", "-").replace("–", "-").replace("·", "-").replace("·", "-").replace("â–¼", "v").replace("▼", "v").replace("▼", "v").replace("â–²", "^").replace("▲", "^").replace("▲", "^").replace("â–¾", "v").replace("▾", "v").replace("▾", "v").replace("â–´", "^").replace("▴", "^").replace("▴", "^").replace("â—\u{8f}", "X").replace("●", "X").replace("●", "X").replace("â—‹", "O").replace("○", "O").replace("○", "O").replace("≡", "=").replace("≡", "=").replace("★", "*").replace("★", "*").replace("∞", "INF").replace("∞", "INF").replace("⚠", "WARN").replace("⚡", "BURST").trim();
    }

    public static class_2583 styleFor(PackUtilText.Tone tone) {
        int color = PackUtilText.colorFor(tone);
        return class_2583.field_24360.method_27704(PackUtilText.fontSource(PackUtilText.fontIdFor(tone))).method_36139(color);
    }

    public static int width(class_327 renderer, String value, PackUtilText.Tone tone) {
        return PackUiText.width(renderer, value, PackUtilText.fontIdFor(tone), PackUtilText.colorFor(tone));
    }

    public static String trimToWidth(class_327 renderer, String value, int maxWidth, PackUtilText.Tone tone) {
        return PackUiText.trimToWidth(renderer, value, maxWidth, PackUtilText.fontIdFor(tone), PackUtilText.colorFor(tone));
    }

    public static void draw(class_332 context, class_327 renderer, String value, PackUtilText.Tone tone, int x, int y, boolean shadow) {
        PackUiText.draw(context, renderer, value, PackUtilText.fontIdFor(tone), PackUtilText.colorFor(tone), x, y, shadow);
    }

    public static void draw(class_332 context, class_327 renderer, String value, int color, int x, int y, boolean shadow) {
        PackUiText.draw(context, renderer, value, PackUiAssets.FONT_BODY, color, x, y, shadow);
    }

    private static class_2960 fontIdFor(PackUtilText.Tone tone) {
        switch (tone.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return PackUiAssets.FONT_TITLE;
            case 1::
                return PackUiAssets.FONT_LABEL;
            case 2::
            case 3::
            case 4::
                return PackUiAssets.FONT_BODY;
        }
    }

    private static class_11719 fontSource(class_2960 fontId) {
        return (class_11719)FONT_CACHE.computeIfAbsent(fontId, class_11719.class_11721::new);
    }
}
