/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final record PackUtilCustomFilterPresetOverlay.ActionButton {
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private final Runnable action;
    private final boolean enabled;

    private PackUtilCustomFilterPresetOverlay.ActionButton(int x, int y, int width, int height, Runnable action, boolean enabled) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.action = action;
        this.enabled = enabled;
    }

    boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int x() {
        return this.x;
    }

    public int y() {
        return this.y;
    }

    public int width() {
        return this.width;
    }

    public int height() {
        return this.height;
    }

    public Runnable action() {
        return this.action;
    }

    public boolean enabled() {
        return this.enabled;
    }
}
