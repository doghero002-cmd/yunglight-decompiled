/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1856;

static final class PackUtilLocalCraftingRegistry.LocalCraftingRecipe {
    final String recipeKey;
    final class_1799 result;
    final int width;
    final int height;
    final boolean shaped;
    final List<class_1856> gridIngredients;
    final List<class_1856> requirements;
    final String signature;

    PackUtilLocalCraftingRegistry.LocalCraftingRecipe(String recipeKey, class_1799 result, int width, int height, boolean shaped, List<class_1856> gridIngredients, List<class_1856> requirements, String signature) {
        this.recipeKey = recipeKey;
        this.result = result.method_7972();
        this.width = width;
        this.height = height;
        this.shaped = shaped;
        this.gridIngredients = List.copyOf(gridIngredients);
        this.requirements = List.copyOf(requirements);
        this.signature = signature;
    }

    boolean fits(int gridWidth, int gridHeight) {
        if (!this.shaped) { /* goto L29; */ }
        return this.width <= gridWidth && this.height <= gridHeight;
        return this.requirements.size() <= gridWidth * gridHeight;
    }
}
