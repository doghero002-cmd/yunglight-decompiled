/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilColors;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class PackUtilClientMessaging {
    private static final class_310 MC = class_310.method_1551();
    private static final long DUPLICATE_WINDOW_MS = 600L;
    private static final String PREFIX_TEXT = "[PackUtil] ";
    private static String lastMessageKey = "";
    private static long lastMessageAtMs = 0L;

    private PackUtilClientMessaging() {
    }

    public static void send(String message) {
        PackUtilClientMessaging.send(PackUtilClientMessaging.buildBodyText(message));
    }

    public static void sendPrefixed(String message) {
        class_5250 text = class_2561.method_43473().method_10852(PackUtilClientMessaging.styled("[", PackUtilColors.textMuted())).method_10852(PackUtilClientMessaging.styled("PackUtil", PackUtilColors.accent(), true)).method_10852(PackUtilClientMessaging.styled("] ", PackUtilColors.textMuted())).method_10852(PackUtilClientMessaging.buildBodyText(message));
        PackUtilClientMessaging.send(text);
    }

    public static void send(class_2561 text) {
        if (MC == null || text == null) {
            return;
        }
        String key = PackUtilClientMessaging.normalizeDuplicateKey(text.getString());
        long now = System.currentTimeMillis();
        var var4 = PackUtilClientMessaging.class;
        synchronized (PackUtilClientMessaging.class) {
        if (!key.isEmpty()) {
            if (key.equals(lastMessageKey)) {
                if (now - lastMessageAtMs <= 600L) {
                    }
                    return;
                }
            }
        }
        MC.execute(PackUtilClientMessaging::lambda$send$0 /* captured: text */);
    }

    private static class_5250 buildBodyText(String message) {
        String normalized = PackUtilClientMessaging.normalizeLegacyFormatting(message);
        class_5250 lanChat = PackUtilClientMessaging.tryBuildLanChatText(normalized);
        if (lanChat != null) {
            return lanChat;
        }
        int defaultColor = PackUtilClientMessaging.inferDefaultColor(PackUtilClientMessaging.stripLegacyCodes(normalized));
        if (normalized.indexOf(167) >= 0) {
            return PackUtilClientMessaging.parseLegacyStyled(normalized, defaultColor);
        }
        return PackUtilClientMessaging.colorizeStructuredText(normalized, defaultColor);
    }

    private static class_5250 tryBuildLanChatText(String message) {
        if (message == null || !message.startsWith("[LAN] <")) {
            return null;
        }
        int close = message.indexOf("> ");
        if (close <= 7) {
            return null;
        }
        String sender = message.substring(7, close);
        String body = message.substring(close + 2);
        return class_2561.method_43473().method_10852(PackUtilClientMessaging.styled("[", PackUtilColors.textMuted())).method_10852(PackUtilClientMessaging.styled("LAN", PackUtilColors.packetCyan(), true)).method_10852(PackUtilClientMessaging.styled("] ", PackUtilColors.textMuted())).method_10852(PackUtilClientMessaging.styled("<", PackUtilColors.textMuted())).method_10852(PackUtilClientMessaging.styled(sender, PackUtilColors.packetPink(), true)).method_10852(PackUtilClientMessaging.styled("> ", PackUtilColors.textMuted())).method_10852(PackUtilClientMessaging.colorizeTokenStream(body, PackUtilColors.textPrimary()));
    }

    private static class_5250 colorizeStructuredText(String message, int defaultColor) {
        if (message == null || message.isEmpty()) {
            return class_2561.method_43473();
        }
        int colon = message.indexOf(58);
        if (colon > 0) {
            if (colon < 24) {
                if (PackUtilClientMessaging.isLikelyLabel(message.substring(0, colon))) {
                    String label = message.substring(0, colon);
                    String rest = message.substring(colon + 1);
                    class_5250 root = class_2561.method_43473().method_10852(PackUtilClientMessaging.styled(label, PackUtilColors.packetGray(), true)).method_10852(PackUtilClientMessaging.styled(":", PackUtilColors.textMuted()));
                    if (!rest.isEmpty()) {
                        root.method_10852(PackUtilClientMessaging.styled(PackUtilClientMessaging.leadingWhitespace(rest), PackUtilColors.textMuted()));
                        root.method_10852(PackUtilClientMessaging.colorizeTokenStream(rest.stripLeading(), PackUtilClientMessaging.inferDefaultColor(rest.trim())));
                    }
                    return root;
                }
            }
        }
        return PackUtilClientMessaging.colorizeTokenStream(message, defaultColor);
    }

    private static class_5250 colorizeTokenStream(String message, int defaultColor) {
        class_5250 root = class_2561.method_43473();
        if (message == null || message.isEmpty()) {
            return root;
        }
        StringBuilder token = new StringBuilder();
        for (int i = 0; i < message.length(); i++) {
            char ch = message.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == 95 || ch == 45 || ch == 35 || ch == 46 || ch == 47) {
                token.append(ch);
            } else {
                if (token.length() > 0) {
                    String word = token.toString();
                    root.method_10852(PackUtilClientMessaging.styled(word, PackUtilClientMessaging.colorForToken(word, defaultColor), PackUtilClientMessaging.isEmphasizedToken(word)));
                    token.setLength(0);
                }
                root.method_10852(PackUtilClientMessaging.styled(String.valueOf(ch), PackUtilClientMessaging.punctuationColor(ch, defaultColor)));
            }
        }
        if (token.length() > 0) {
            word = token.toString();
            root.method_10852(PackUtilClientMessaging.styled(word, PackUtilClientMessaging.colorForToken(word, defaultColor), PackUtilClientMessaging.isEmphasizedToken(word)));
        }
        return root;
    }

    private static boolean isLikelyLabel(String value) {
        if (value == null || value.isBlank()) {
            return false;
        }
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (Character.isLetterOrDigit(ch) && !Character.isWhitespace(ch) && ch != 91 && ch != 93 && ch != 43 && ch != 45 && ch != 47 && ch != 35) continue;
            return false;
        }
        return true;
    }

    private static String leadingWhitespace(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        for (int i = 0; i < value.length(); i++) {
            if (!Character.isWhitespace(value.charAt(i))) break;
        }
        return value.substring(0, i);
    }

    private static int punctuationColor(char ch, int defaultColor) {
        switch (ch) {
            case 40::
            case 41::
            case 44::
            case 58::
            case 60::
            case 62::
            case 91::
            case 93::
            case 124::
                return PackUtilColors.textMuted();
            case 34::
                return PackUtilColors.packetLightYellow();
            default:
                return defaultColor;
        }
    }

    private static boolean isEmphasizedToken(String token) {
        String normalized = PackUtilClientMessaging.normalizeToken(token);
        return normalized.equals("enabled") || normalized.equals("disabled") || normalized.equals("started") || normalized.equals("stopped") || normalized.equals("failed") || normalized.equals("error") || normalized.equals("queue") || normalized.equals("packet") || normalized.equals("packets") || normalized.equals("gui") || normalized.equals("macro") || normalized.equals("macros") || normalized.equals("sync") || normalized.equals("lan");
    }

    private static int colorForToken(String token, int defaultColor) {
        String normalized = PackUtilClientMessaging.normalizeToken(token);
        if (normalized.isEmpty()) {
            return defaultColor;
        }
        if (PackUtilClientMessaging.isNumericToken(normalized)) {
            return PackUtilColors.packetLightYellow();
        }
        if (normalized.equals("enabled") || normalized.equals("started") || normalized.equals("joined") || normalized.equals("restored") || normalized.equals("saved") || normalized.equals("loaded") || normalized.equals("copied") || normalized.equals("imported") || normalized.equals("received") || normalized.equals("executed") || normalized.equals("finished") || normalized.equals("reconnected") || normalized.equals("host") || normalized.equals("sent") || normalized.equals("on") || normalized.equals("true")) {
            return PackUtilColors.successText();
        }
        if (normalized.equals("disabled") || normalized.equals("stopped") || normalized.equals("empty") || normalized.equals("already") || normalized.equals("requested") || normalized.equals("left") || normalized.equals("attempting") || normalized.equals("timeout") || normalized.equals("timed") || normalized.equals("out") || normalized.equals("off") || normalized.equals("false")) {
            return PackUtilColors.packetYellow();
        }
        if (normalized.equals("failed") || normalized.equals("error") || normalized.equals("errors") || normalized.equals("denied") || normalized.equals("blocked") || normalized.equals("crashed") || normalized.equals("cannot") || normalized.equals("missing") || normalized.equals("unavailable") || normalized.equals("invalid") || normalized.equals("not") || normalized.equals("null")) {
            return PackUtilColors.dangerText();
        }
        if (normalized.equals("queue") || normalized.equals("packet") || normalized.equals("packets") || normalized.equals("sync") || normalized.equals("lan") || normalized.equals("session") || normalized.equals("tcp")) {
            return PackUtilColors.packetCyan();
        }
        if (normalized.equals("gui") || normalized.equals("screen") || normalized.equals("inventory") || normalized.equals("slot") || normalized.equals("slots")) {
            return PackUtilColors.packetOrange();
        }
        if (normalized.equals("macro") || normalized.equals("macros") || normalized.equals("preset") || normalized.equals("presets")) {
            return PackUtilColors.packetPink();
        }
        return defaultColor;
    }

    private static boolean isNumericToken(String token) {
        int start = token.startsWith("-") ? 1 : 0;
        if (start >= token.length()) {
            return false;
        }
        for (int i = start; i < token.length(); i++) {
            char ch = token.charAt(i);
            if (Character.isDigit(ch) && ch != 46 && ch != 47 && ch != 35) continue;
            return false;
        }
        return true;
    }

    private static String normalizeToken(String token) {
        if (token == null || token.isEmpty()) {
            return "";
        }
        int start = 0;
        int end = token.length();
        while (start < end) {
            if (Character.isLetterOrDigit(token.charAt(start))) break;
            start++;
        }
        while (end > start) {
            if (Character.isLetterOrDigit(token.charAt(end - 1))) break;
            end--;
        }
        if (start >= end) {
            return "";
        }
        return token.substring(start, end).toLowerCase();
    }

    private static class_5250 parseLegacyStyled(String message, int defaultColor) {
        class_5250 root = class_2561.method_43473();
        if (message == null || message.isEmpty()) {
            return root;
        }
        StringBuilder buffer = new StringBuilder();
        int currentColor = defaultColor;
        boolean bold = false;
        for (int i = 0; i < message.length(); i++) {
            char ch = message.charAt(i);
            if (ch == 167) {
                if (i + 1 >= message.length()) { /* goto @181; */ }
                if (buffer.length() > 0) {
                    root.method_10852(PackUtilClientMessaging.styled(buffer.toString(), currentColor, bold));
                    buffer.setLength(0);
                }
                i++;
                char code = Character.toLowerCase(message.charAt(i));
                Integer mapped = PackUtilClientMessaging.mapLegacyColor(code);
                if (mapped != null) {
                    currentColor = mapped.intValue();
                    if (PackUtilClientMessaging.isColorCode(code)) { /* goto L146; */ }
                    if (code != 114) continue;
                    bold = false;
                } else {
                    if (code == 108) {
                        bold = true;
                    } else {
                        if (code == 114) {
                            currentColor = defaultColor;
                            bold = false;
                        }
                    }
                }
            } else {
                buffer.append(ch);
            }
        }
        if (buffer.length() > 0) {
            root.method_10852(PackUtilClientMessaging.styled(buffer.toString(), currentColor, bold));
        }
        return root;
    }

    private static class_5250 styled(String value, int color) {
        return PackUtilClientMessaging.styled(value, color, false);
    }

    private static class_5250 styled(String value, int color, boolean bold) {
        class_2583 style = class_2583.field_24360.method_36139(color);
        if (bold) {
            style = style.method_10982(true);
        }
        return class_2561.method_43470(value).method_10862(style);
    }

    private static boolean isColorCode(char code) {
        if (code < 48 || code > 57) {
            if (code < 97) { /* goto @28; */ }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L29; */
        L28: ;
        L29: ;
        return false;
    }

    private static Integer mapLegacyColor(char code) {
        switch (code) {
            case 48::
                return -10597554;
            case 49::
                return -9727272;
            case 50::
                return -10897036;
            case 51::
                return PackUtilColors.packetCyan();
            case 52::
                return PackUtilColors.dangerText();
            case 53::
                return -1602869;
            case 54::
                return PackUtilColors.packetOrange();
            case 55::
                return PackUtilColors.packetGray();
            case 56::
                return PackUtilColors.textMuted();
            case 57::
                return PackUtilColors.packetBlue();
            case 97::
                return PackUtilColors.successText();
            case 98::
                return PackUtilColors.packetCyan();
            case 99::
                return PackUtilColors.dangerText();
            case 100::
                return PackUtilColors.packetPink();
            case 101::
                return PackUtilColors.packetYellow();
            case 102::
                return PackUtilColors.textSecondary();
            case 114::
                return null;
            case 58::
            case 59::
            case 60::
            case 61::
            case 62::
            case 63::
            case 64::
            case 65::
            case 66::
            case 67::
            case 68::
            case 69::
            case 70::
            case 71::
            case 72::
            case 73::
            case 74::
            case 75::
            case 76::
            case 77::
            case 78::
            case 79::
            case 80::
            case 81::
            case 82::
            case 83::
            case 84::
            case 85::
            case 86::
            case 87::
            case 88::
            case 89::
            case 90::
            case 91::
            case 92::
            case 93::
            case 94::
            case 95::
            case 96::
            case 103::
            case 104::
            case 105::
            case 106::
            case 107::
            case 108::
            case 109::
            case 110::
            case 111::
            case 112::
            case 113::
            default:
                return null;
        }
    }

    private static String normalizeLegacyFormatting(String message) {
        if (message == null) {
            return "";
        }
        return message.replace("Ã‚Â§", "Â§").replace("Â§", "§");
    }

    private static String stripLegacyCodes(String message) {
        if (message == null || message.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder(message.length());
        for (int i = 0; i < message.length(); i++) {
            char ch = message.charAt(i);
            i++;
            if (ch == 167 && i + 1 < message.length()) {
            } else {
                sb.append(ch);
            }
        }
        return sb.toString().trim();
    }

    private static int inferDefaultColor(String message) {
        String lower = message == null ? "" : message.trim().toLowerCase();
        if (lower.isEmpty()) {
            return PackUtilColors.textSecondary();
        }
        if (lower.contains("failed") || lower.contains("error") || lower.startsWith("no ") || lower.startsWith("not ") || lower.contains(" not ") || lower.contains("cannot") || lower.contains("denied") || lower.contains("blocked") || lower.contains("crashed")) {
            return PackUtilColors.dangerText();
        }
        if (lower.contains("enabled") || lower.contains("started") || lower.contains("joined") || lower.contains("restored") || lower.contains("saved") || lower.contains("loaded") || lower.contains("copied") || lower.contains("imported") || lower.contains("received") || lower.contains("executed") || lower.contains("finished") || lower.startsWith("sent ") || lower.startsWith("signed ") || lower.startsWith("deleted ") || lower.startsWith("broadcasted ") || lower.startsWith("queue sent")) {
            return PackUtilColors.successText();
        }
        if (lower.contains("disabled") || lower.contains("stopped") || lower.contains("empty") || lower.contains("already") || lower.contains("requested") || lower.contains("left") || lower.contains("attempting") || lower.contains("timed out")) {
            return PackUtilColors.packetYellow();
        }
        if (lower.startsWith("[lan] <")) {
            return PackUtilColors.textPrimary();
        }
        return PackUtilColors.textSecondary();
    }

    private static String normalizeDuplicateKey(String message) {
        if (message == null) {
            return "";
        }
        return PackUtilClientMessaging.stripLegacyCodes(PackUtilClientMessaging.normalizeLegacyFormatting(message)).replace("[PackUtil] ", "").replaceAll("\\s+", " ").trim().toLowerCase();
    }
}
