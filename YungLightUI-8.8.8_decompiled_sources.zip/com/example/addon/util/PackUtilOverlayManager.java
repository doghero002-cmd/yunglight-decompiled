/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiText;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilCustomFilterOverlay;
import com.example.addon.util.PackUtilLauncherOverlay;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class PackUtilOverlayManager {
    private static final PackUtilOverlayManager INSTANCE = new PackUtilOverlayManager();
    public static final int HOVER_BLOCKED_MOUSE = -10000;
    private static final double HEADER_CLICK_DRAG_THRESHOLD = 3;
    private final List<IPackUtilOverlay> overlays = new CopyOnWriteArrayList();
    private IPackUtilOverlay focusedOverlay = null;
    private IPackUtilOverlay draggingOverlay = null;
    private IPackUtilOverlay resizingOverlay = null;
    private IPackUtilOverlay headerCollapseOverlay = null;
    private int lastScreenWidth = -1;
    private int lastScreenHeight = -1;
    private boolean headerCollapseMoved = false;
    private boolean inventoryMouseDown = false;
    private PackUtilWindowLayout headerCollapseStartBounds = null;
    private PackUtilWindowLayout resizeStartBounds = null;
    private double headerCollapseStartMouseX = 0;
    private double headerCollapseStartMouseY = 0;
    private double resizeStartMouseX = 0;
    private double resizeStartMouseY = 0;

    private PackUtilOverlayManager() {
    }

    public static PackUtilOverlayManager get() {
        return INSTANCE;
    }

    public List<IPackUtilOverlay> getOverlays() {
        return this.overlays;
    }

    public void register(IPackUtilOverlay overlay) {
        if (overlay == null) {
            return;
        }
        if (!this.overlays.contains(overlay)) {
            this.overlays.add(overlay);
        }
        this.restoreSavedOverlayOrder();
        this.normalizeOverlayStack();
        if (overlay instanceof PackUtilLauncherOverlay || "packutil-launcher".equals(overlay.getOverlayId())) {
            this.reclampAllOverlays();
        }
    }

    public void unregister(IPackUtilOverlay overlay) {
        if (overlay == null) {
            return;
        }
        this.overlays.remove(overlay);
        if (this.focusedOverlay == overlay) {
            this.focusedOverlay = null;
        }
        this.saveOverlayOrder();
    }

    public void clear() {
        this.overlays.clear();
        this.draggingOverlay = null;
        this.resizingOverlay = null;
        this.headerCollapseOverlay = null;
        this.focusedOverlay = null;
        this.headerCollapseMoved = false;
        this.headerCollapseStartBounds = null;
        this.resizeStartBounds = null;
        this.inventoryMouseDown = false;
    }

    public void bringToFront(IPackUtilOverlay overlay) {
        if (overlay == null) {
            return;
        }
        this.overlays.remove(overlay);
        this.overlays.add(overlay);
        this.focusedOverlay = overlay;
        PackUtilSharedState.get().setFocusedOverlayId(overlay.getOverlayId());
        this.normalizeOverlayStack();
        this.saveOverlayOrder();
    }

    public void bringToFrontParent(Object childComponent) {
        if (childComponent == null) {
            return;
        }
        var var2 = this.overlays.iterator();
        while (var2.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var2.next();
            if (overlay instanceof PackUtilCustomFilterOverlay) {
                PackUtilCustomFilterOverlay filterOverlay = (PackUtilCustomFilterOverlay)overlay;
                if (filterOverlay.getPacketSelectorOverlay() == childComponent) {
                    this.bringToFront(overlay);
                    return;
                }
            }
        }
    }

    private void restoreSavedOverlayOrder() {
        if (this.overlays.size() < 2) {
            this.restoreFocusedOverlay();
            this.normalizeOverlayStack();
            return;
        }
        List<String> savedOrder = PackUtilSharedState.get().getOverlayOrder();
        if (savedOrder.isEmpty()) {
            this.restoreFocusedOverlay();
            this.normalizeOverlayStack();
            return;
        }
        String focusedId = PackUtilSharedState.get().getFocusedOverlayId();
        Map<String, Integer> positions = new HashMap();
        for (int i = 0; i < savedOrder.size(); i++) {
            positions.putIfAbsent((String)savedOrder.get(i), i);
        }
        ordered = new ArrayList(this.overlays);
        ordered.sort(Comparator.comparingInt(PackUtilOverlayManager::lambda$restoreSavedOverlayOrder$0 /* captured: positions */).thenComparingInt(PackUtilOverlayManager::lambda$restoreSavedOverlayOrder$1 /* captured: focusedId */));
        this.overlays.clear();
        this.overlays.addAll(ordered);
        this.restoreFocusedOverlay();
        this.normalizeOverlayStack();
    }

    private void restoreFocusedOverlay() {
        String focusedId = PackUtilSharedState.get().getFocusedOverlayId();
        if (focusedId.isEmpty()) {
            this.focusedOverlay = null;
            return;
        }
        this.focusedOverlay = null;
        int i = this.overlays.size() - 1;
        while (i >= 0) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)this.overlays.get(i);
            if (overlay != null) {
                if (focusedId.equals(overlay.getOverlayId())) {
                    if (!overlay.isVisible()) continue;
                    this.focusedOverlay = overlay;
                }
            } else {
                i--;
            }
        }
    }

    private void saveOverlayOrder() {
        List<String> order = new ArrayList(this.overlays.size());
        var var2 = this.overlays.iterator();
        while (var2.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var2.next();
            String id = overlay.getOverlayId();
            if (id == null) continue;
            if (id.isEmpty()) continue;
            if (order.contains(id)) continue;
            while (this.isLauncherOverlay(overlay)) {
            }
            order.add(id);
        }
        PackUtilSharedState.get().setOverlayOrder(order);
    }

    private void normalizeOverlayStack() {
        if (this.overlays.isEmpty()) {
            return;
        }
        List<IPackUtilOverlay> launchers = new ArrayList();
        List<IPackUtilOverlay> others = new ArrayList();
        var var3 = this.overlays.iterator();
        while (var3.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var3.next();
            if (this.isLauncherOverlay(overlay)) {
                launchers.add(overlay);
            } else {
                others.add(overlay);
            }
        }
        if (launchers.isEmpty()) {
            return;
        }
        this.overlays.clear();
        this.overlays.addAll(launchers);
        this.overlays.addAll(others);
    }

    private boolean isLauncherOverlay(IPackUtilOverlay overlay) {
        if (!(overlay instanceof PackUtilLauncherOverlay)) {
            if (overlay == null) { /* goto @29; */ }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L30; */
        L29: ;
        L30: ;
        return false;
    }

    public void reclampAllOverlays() {
        var var1 = this.overlays.iterator();
        while (var1.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var1.next();
            while (overlay == null) {
            }
            overlay.setBounds(overlay.getBounds());
        }
    }

    public void renderAll(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc == null) { /* goto L108; */ }
        if (mc.method_22683() == null) { /* goto L108; */ }
        int sw = PackUtilUiScale.getVirtualScreenWidth();
        int sh = PackUtilUiScale.getVirtualScreenHeight();
        if (sw != this.lastScreenWidth) { /* goto L46; */ }
        if (sh == this.lastScreenHeight) { /* goto L108; */ }
        L46: ;
        this.lastScreenWidth = sw;
        this.lastScreenHeight = sh;
        List<IPackUtilOverlay> ordered = this.overlays.iterator();
        while (ordered.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)ordered.next();
            overlay.setBounds(overlay.getBounds());
        }
        virtualMouseX = (int)Math.round(PackUtilUiScale.toVirtual((double)mouseX));
        virtualMouseY = (int)Math.round(PackUtilUiScale.toVirtual((double)mouseY));
        ordered = new ArrayList(this.overlays);
        hoveredOverlayIndex = -1;
        int i = ordered.size() - 1;
        while (i >= 0) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)ordered.get(i);
            if (overlay.isVisible()) {
                if (!overlay.isMouseOver((double)virtualMouseX, (double)virtualMouseY)) continue;
                hoveredOverlayIndex = i;
            } else {
                i--;
            }
        }
        PackUiText.beginManagedLayer(context);
        PackUtilUiScale.pushOverlayScale(context);
        try {
            for (i = 0; i < ordered.size(); i++) {
                overlay = (IPackUtilOverlay)ordered.get(i);
                if (!overlay.isVisible()) { /* goto L316; */ }
                boolean hoverBlocked = hoveredOverlayIndex > i;
                overlay.render(context, hoverBlocked ? -10000 : virtualMouseX, hoverBlocked ? -10000 : virtualMouseY, delta);
                PackUiText.interOverlayFlush(context);
                L316: ;
            }
        }
        finally {
            PackUtilUiScale.popOverlayScale(context);
            PackUiText.endManagedLayer(context);
            throw var13;
        }
    }

    public boolean isMouseOverAnyOverlay(double mouseX, double mouseY) {
        return this.isMouseOverAnyOverlayVirtual(PackUtilUiScale.toVirtual(mouseX), PackUtilUiScale.toVirtual(mouseY));
    }

    private boolean isMouseOverAnyOverlayVirtual(double mouseX, double mouseY) {
        var var5 = this.overlays.iterator();
        while (var5.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var5.next();
            if (overlay.isVisible()) {
                if (!overlay.isMouseOver(mouseX, mouseY)) continue;
                return true;
            }
        }
        return false;
    }

    public boolean shouldBlockUnderlyingHover(double mouseX, double mouseY) {
        return this.isMouseOverAnyOverlayVirtual(PackUtilUiScale.toVirtual(mouseX), PackUtilUiScale.toVirtual(mouseY));
    }

    private void clearFocusedTextFields() {
        var var1 = this.overlays.iterator();
        while (var1.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var1.next();
            if (overlay != null) {
                if (overlay.isVisible()) {
                    if (!overlay.hasTextFieldFocused()) continue;
                    overlay.clearTextFieldFocus();
                }
            }
        }
    }

    private IPackUtilOverlay getTopmostOverlayAt(double mouseX, double mouseY) {
        for (int i = this.overlays.size() - 1; i >= 0; i--) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)this.overlays.get(i);
            if (!overlay.isVisible() && overlay.isMouseOver(mouseX, mouseY)) continue;
            return overlay;
        }
        return null;
    }

    public boolean isTopOverlay(IPackUtilOverlay overlay) {
        if (overlay == null || this.overlays.isEmpty()) {
            return false;
        }
        for (int i = this.overlays.size() - 1; i >= 0; i--) {
            IPackUtilOverlay candidate = (IPackUtilOverlay)this.overlays.get(i);
            if (candidate == null) { /* goto L72; */ }
            if (!candidate.isVisible()) { /* goto L72; */ }
            return candidate == overlay;
        }
        return false;
    }

    public boolean isFocusedOverlay(IPackUtilOverlay overlay) {
        return overlay != null && overlay == this.focusedOverlay;
    }

    public boolean handleMouseClicked(double mouseX, double mouseY, int button) {
        this.inventoryMouseDown = false;
        class_310 _mc = class_310.method_1551();
        this.inventoryMouseDown = true;
        if (_mc != null && _mc.field_1724 != null && _mc.field_1724.field_7512 != null && !_mc.field_1724.field_7512.method_34255().method_7960()) {
            return false;
        }
        this.clearFocusedTextFields();
        mouseX = PackUtilUiScale.toVirtual(mouseX);
        mouseY = PackUtilUiScale.toVirtual(mouseY);
        IPackUtilOverlay topOverlay = this.getTopmostOverlayAt(mouseX, mouseY);
        if (topOverlay == null) {
            this.focusedOverlay = null;
            PackUtilSharedState.get().setFocusedOverlayId("");
            this.headerCollapseOverlay = null;
            this.headerCollapseMoved = false;
            this.headerCollapseStartBounds = null;
            this.inventoryMouseDown = true;
            return false;
        }
        if (button != 0) { /* goto L271; */ }
        if (topOverlay.isOverResizeHandle(mouseX, mouseY)) {
            this.resizingOverlay = topOverlay;
            this.resizeStartBounds = topOverlay.getBounds();
            this.resizeStartMouseX = mouseX;
            this.resizeStartMouseY = mouseY;
            this.bringToFront(topOverlay);
            return true;
        }
        if (!topOverlay.isOverDragBar(mouseX, mouseY)) { /* goto L271; */ }
        this.draggingOverlay = topOverlay;
        if (topOverlay.usesSharedHeaderClickCollapse()) {
            this.headerCollapseOverlay = topOverlay;
            this.headerCollapseMoved = false;
            this.headerCollapseStartMouseX = mouseX;
            this.headerCollapseStartMouseY = mouseY;
            this.headerCollapseStartBounds = topOverlay.getBounds();
        } else {
            this.headerCollapseOverlay = null;
            this.headerCollapseMoved = false;
            this.headerCollapseStartBounds = null;
        }
        this.bringToFront(topOverlay);
        topOverlay.mouseClicked(mouseX, mouseY, button);
        return true;
        L271: ;
        this.headerCollapseOverlay = null;
        this.headerCollapseMoved = false;
        this.headerCollapseStartBounds = null;
        this.bringToFront(topOverlay);
        if (topOverlay.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        return true;
    }

    public boolean handleMouseReleased(double mouseX, double mouseY, int button) {
        mouseX = PackUtilUiScale.toVirtual(mouseX);
        mouseY = PackUtilUiScale.toVirtual(mouseY);
        boolean wasDraggingOrResizing = this.draggingOverlay != null || this.resizingOverlay != null;
        IPackUtilOverlay prevDragging = this.draggingOverlay;
        IPackUtilOverlay prevResizing = this.resizingOverlay;
        boolean shouldToggleHeaderCollapse = button == 0 && prevDragging != null && prevDragging == this.headerCollapseOverlay && prevDragging.usesSharedHeaderClickCollapse() && !this.headerCollapseMoved;
        PackUtilWindowLayout headerStartBounds = this.headerCollapseStartBounds;
        if (button == 0) {
            this.draggingOverlay = null;
            if (this.resizingOverlay != null) {
                this.resizingOverlay.saveLayout();
            }
            this.resizingOverlay = null;
            this.resizeStartBounds = null;
            this.headerCollapseOverlay = null;
            this.headerCollapseMoved = false;
            this.headerCollapseStartBounds = null;
        }
        if (prevDragging != null) {
            prevDragging.mouseReleased(mouseX, mouseY, button);
        }
        if (prevResizing != null) {
            if (prevResizing != prevDragging) {
                prevResizing.mouseReleased(mouseX, mouseY, button);
            }
        }
        if (shouldToggleHeaderCollapse) {
            if (prevDragging != null) {
                if (prevDragging.isVisible()) {
                    if (headerStartBounds != null) {
                        PackUtilWindowLayout current = prevDragging.getBounds();
                        prevDragging.setBounds(new PackUtilWindowLayout(headerStartBounds.x, headerStartBounds.y, current.width, current.height, current.visible, current.collapsed));
                    }
                    prevDragging.toggleCollapsed();
                    prevDragging.saveLayout();
                    return true;
                }
            }
        }
        if (wasDraggingOrResizing) {
            return true;
        }
        if (this.inventoryMouseDown) {
            this.inventoryMouseDown = false;
            return false;
        }
        for (i = this.overlays.size() - 1; i >= 0; i--) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)this.overlays.get(i);
            if (!overlay.isVisible() && overlay.mouseReleased(mouseX, mouseY, button)) continue;
            return true;
        }
        return this.isMouseOverAnyOverlayVirtual(mouseX, mouseY);
    }

    public boolean handleMouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        mouseX = PackUtilUiScale.toVirtual(mouseX);
        mouseY = PackUtilUiScale.toVirtual(mouseY);
        deltaX = PackUtilUiScale.toVirtual(deltaX);
        deltaY = PackUtilUiScale.toVirtual(deltaY);
        PackUtilWindowLayout current = this.resizingOverlay.getBounds();
        if (this.resizingOverlay != null && this.resizeStartBounds != null && this.resizingOverlay.isVisible()) {
            PackUtilWindowLayout resized = new PackUtilWindowLayout(this.resizeStartBounds.x, this.resizeStartBounds.y, Math.max(this.resizingOverlay.getMinWidth(), this.resizeStartBounds.width + (int)Math.round(mouseX - this.resizeStartMouseX)), Math.max(this.resizingOverlay.getMinHeight(), this.resizeStartBounds.height + (int)Math.round(mouseY - this.resizeStartMouseY)), current.visible, current.collapsed);
            this.resizingOverlay.setBounds(resized);
            return true;
        }
        if (this.draggingOverlay != null) {
            if (this.draggingOverlay.isVisible()) {
                if (this.draggingOverlay == this.headerCollapseOverlay) {
                    if (!this.headerCollapseMoved) {
                        if (Math.abs(mouseX - this.headerCollapseStartMouseX) >= 3 || Math.abs(mouseY - this.headerCollapseStartMouseY) >= 3) {
                            this.headerCollapseMoved = true;
                        }
                    }
                }
                return this.draggingOverlay.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
            }
        }
        if (this.inventoryMouseDown) {
            return false;
        }
        for (i = this.overlays.size() - 1; i >= 0; i--) {
            overlay = (IPackUtilOverlay)this.overlays.get(i);
            if (!overlay.isVisible() && overlay.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) continue;
            return true;
        }
        return this.isMouseOverAnyOverlayVirtual(mouseX, mouseY);
    }

    public boolean handleMouseScrolled(double mouseX, double mouseY, double amount) {
        mouseX = PackUtilUiScale.toVirtual(mouseX);
        mouseY = PackUtilUiScale.toVirtual(mouseY);
        for (int i = this.overlays.size() - 1; i >= 0; i--) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)this.overlays.get(i);
            if (overlay.isVisible()) {
                if (overlay.isMouseOver(mouseX, mouseY)) {
                    this.bringToFront(overlay);
                    if (!overlay.mouseScrolled(mouseX, mouseY, amount)) continue;
                    return true;
                    return true;
                }
            }
        }
        return false;
    }

    public boolean handleKeyPressed(int keyCode, int scanCode, int modifiers) {
        for (int i = this.overlays.size() - 1; i >= 0; i--) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)this.overlays.get(i);
            this.bringToFront(overlay);
            if (!overlay.isVisible() && overlay.wantsKeyboardCapture() && overlay.keyPressed(keyCode, scanCode, modifiers)) continue;
            return true;
        }
        keyboardTarget = this.getKeyboardTargetOverlay();
        if (keyboardTarget != null && keyboardTarget.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        return this.isAnyTextFieldFocused();
    }

    public boolean handleCharTyped(char chr, int modifiers) {
        IPackUtilOverlay keyboardTarget = this.getKeyboardTargetOverlay();
        if (keyboardTarget != null && keyboardTarget.charTyped(chr, modifiers)) {
            return true;
        }
        return this.isAnyTextFieldFocused();
    }

    private IPackUtilOverlay getKeyboardTargetOverlay() {
        if (this.focusedOverlay != null && this.focusedOverlay.isVisible()) {
            return this.focusedOverlay;
        }
        for (int i = this.overlays.size() - 1; i >= 0; i--) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)this.overlays.get(i);
            if (!overlay != null && overlay.isVisible()) continue;
            return overlay;
        }
        return null;
    }

    public boolean isAnyTextFieldFocused() {
        var var1 = this.overlays.iterator();
        while (var1.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var1.next();
            if (overlay.isVisible()) {
                if (!overlay.hasTextFieldFocused()) continue;
                return true;
            }
        }
        return false;
    }
}
