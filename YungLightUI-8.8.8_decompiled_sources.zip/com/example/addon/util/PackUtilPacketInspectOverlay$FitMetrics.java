/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final record PackUtilPacketInspectOverlay.FitMetrics {
    private final int contentWidth;
    private final int lineCount;
    private final int longestWrappedLineWidth;

    private PackUtilPacketInspectOverlay.FitMetrics(int contentWidth, int lineCount, int longestWrappedLineWidth) {
        this.contentWidth = contentWidth;
        this.lineCount = lineCount;
        this.longestWrappedLineWidth = longestWrappedLineWidth;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int contentWidth() {
        return this.contentWidth;
    }

    public int lineCount() {
        return this.lineCount;
    }

    public int longestWrappedLineWidth() {
        return this.longestWrappedLineWidth;
    }
}
