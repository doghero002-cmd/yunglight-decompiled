/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiInfoRow;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiLabel;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiProgressBar;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiRow;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSlider;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiSpacer;
import com.example.addon.gui.packui.PackUiSurface;
import com.example.addon.gui.packui.PackUiTabStrip;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.gui.packui.PackUiViewportSlot;
import com.example.addon.gui.packui.PackUiWindowNode;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;
import net.minecraft.class_2639;
import net.minecraft.class_2805;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_640;
import net.minecraft.class_642;

public class PackUtilServerInfoOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final int COMPLETION_ID = 1337;
    private static final int HEADER_CONTROL = 12;
    private static final int HEADER_ARROW_WIDTH = 10;
    private static final int HEADER_ARROW_GAP = 3;
    private static final float HEADER_CLICK_DRAG_THRESHOLD = 3f;
    private int panelX = 350;
    private int panelY = 30;
    private int panelW = 236;
    private int panelH = 246;
    private static final int ROW_H = 16;
    private static final int PAD = 8;
    private boolean visible = false;
    private boolean collapsed = false;
    private boolean isDragging = false;
    private boolean isResizing = false;
    private double dragOffsetX;
    private double dragOffsetY;
    private double resizeStartMouseX;
    private double resizeStartMouseY;
    private int resizeStartW;
    private int resizeStartH;
    private float pressStartUiX;
    private float pressStartUiY;
    private int pressStartPanelX;
    private int pressStartPanelY;
    private boolean dragMoved = false;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiWindowNode windowNode = new PackUiWindowNode("Server Info");
    private final PackUiSurface surface = new PackUiSurface(this.theme, this.windowNode);
    private final PackUiTabStrip tabStrip = new PackUiTabStrip();
    private final PackUiTextField searchField = new PackUiTextField();
    private final PackUiSlider probeDelaySlider = new PackUiSlider();
    private final PackUiProgressBar scanProgressBar = new PackUiProgressBar();
    private final PackUiViewportSlot pluginListSlot = new PackUiViewportSlot();
    private float closeHover = 0f;
    private float closeVisibility = 1f;
    private boolean pluginScrollbarDragging = false;
    private int pluginScrollbarGrabOffset = 0;
    private static final String[] TAB_NAMES;
    private int activeTab = 0;
    private final List<PackUtilServerInfoOverlay.ClickRegion> clickRegions = new ArrayList();
    private volatile String resolvedIp = null;
    private String lastResolvedAddress = null;
    private volatile boolean resolvingIp = false;
    private final List<String> detectedPlugins = new ArrayList();
    private final Map<String, List<String>> pluginCommands = new LinkedHashMap();
    private final PackUiSmoothScroll pluginScrollState = new PackUiSmoothScroll();
    private int pluginContentHeight = 0;
    private String selectedPlugin = null;
    private int pluginProbeDelayMs = 50;
    private boolean pluginScanDone = false;
    private boolean pluginScanInProgress = false;
    private long pluginScanStartedAt = 0L;
    private long pluginScanLastResponseAt = 0L;
    private final Set<Integer> pendingPluginProbeIds = new HashSet();
    private final Map<Integer, PackUtilServerInfoOverlay.PluginProbeSpec> pluginProbes = new HashMap();
    private final Set<String> observedPluginCommands = new TreeSet(String.CASE_INSENSITIVE_ORDER);
    private final Deque<PackUtilServerInfoOverlay.PluginProbeRequest> queuedPluginProbes = new ArrayDeque();
    private final Map<String, PackUtilServerInfoOverlay.PluginEvidence> pluginEvidence = new TreeMap(String.CASE_INSENSITIVE_ORDER);
    private final Map<String, PackUtilServerInfoOverlay.PluginScanEntry> scanWorkingEntries = new TreeMap(String.CASE_INSENSITIVE_ORDER);
    private long nextPluginProbeSendAt = 0L;
    private int pluginScanTotalSteps = 0;
    private boolean pluginScanCompletionAnnounced = false;
    private String scannedServerAddress = null;
    private String scannedPluginContextSignature = "";
    private String cachedPluginContextServerAddress = "";
    private String cachedPluginContextBrand = "";
    private String cachedPluginContextSignature = "";
    private boolean pluginContextSignatureDirty = true;
    private static final long PLUGIN_SCAN_IDLE_MS = 700L;
    private static final long PLUGIN_SCAN_TIMEOUT_MS = 12000L;
    private static final int DEFAULT_PLUGIN_PROBE_DELAY_MS = 50;
    private static final int MIN_PLUGIN_PROBE_DELAY_MS = 10;
    private static final int MAX_PLUGIN_PROBE_DELAY_MS = 500;
    private static final long PLUGIN_SCAN_SETTLE_MS = 450L;
    private static final int PLUGIN_HEADER_H = 14;
    private static final int SHARED_PANEL_WIDTH = 200;
    private static final int PLUGIN_SETUP_WIDTH = 200;
    private static final int PLUGIN_SETUP_HEIGHT = 126;
    private static final int PLUGIN_SCANNING_WIDTH = 200;
    private static final int PLUGIN_SCANNING_HEIGHT = 92;
    private static final int INFO_MIN_WIDTH = 200;
    private static final int INFO_MIN_HEIGHT = 258;
    private static final int PLUGIN_RESULTS_MIN_WIDTH = 200;
    private static final int PLUGIN_RESULTS_MIN_HEIGHT = 280;
    private int infoPreferredWidth = 200;
    private int infoPreferredHeight = 258;
    private int pluginPreferredWidth = 200;
    private int pluginPreferredHeight = 280;
    private static final String[] COMMON_PLUGIN_NAMESPACES;
    private static final String[] PLUGIN_LIST_PROBE_COMMANDS;
    private static final String[] VERSION_PROBE_COMMANDS;
    private static final String[] HELP_PROBE_COMMANDS;
    private static final String ROOT_PROBE_PREFIXES = "abcdefghijklmnopqrstuvwxyz0123456789";
    private static final Map<String, String> ROOT_COMMAND_PLUGIN_ALIASES;
    private static final Set<String> ANTICHEATS;
    private static final Set<String> VANILLA_NAMESPACES;

    public PackUtilServerInfoOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.buildUi();
    }

    private void buildUi() {
        this.windowNode.setCenterTitle(false);
        this.windowNode.setTitleTone(PackUiTone.LABEL);
        this.windowNode.setTitleAreaInsets(this.panelPadding() + 1, this.panelPadding() + this.headerControlSize() + this.headerArrowWidth() + this.headerArrowGap() + 12);
        this.windowNode.content().setGap(this.contentGap()).setPadding(PackUiInsets.all(this.panelPadding()));
        this.tabStrip.setTabs(TAB_NAMES).setActiveIndex(this.activeTab).setOnSelect(this::selectTab);
        this.searchField.setPlaceholder("Search plugins...").setPreferredWidth((float)this.pluginSearchWidth()).setFieldHeight(this.searchFieldHeight()).setOnChange(this::lambda$buildUi$0);
        this.probeDelaySlider.setRange(10f, 500f).setStep(10f).setValue((float)this.pluginProbeDelayMs).setOnChange(this::lambda$buildUi$1);
        this.scanProgressBar.setProgress(0f);
    }

    public void saveState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.rememberCurrentTabSize();
        String stateAddress = this.currentServerAddress();
        if (stateAddress.isEmpty()) {
            if (this.scannedServerAddress != null) {
                stateAddress = this.scannedServerAddress;
            }
        }
        shared.setServerInfoOverlayActiveTab(this.activeTab);
        shared.setServerInfoOverlayPluginScrollOffset(this.pluginScrollState.targetOffset());
        shared.setServerInfoOverlaySelectedPlugin(this.selectedPlugin);
        shared.setServerInfoOverlayStateAddress(stateAddress);
        shared.setServerInfoOverlayProbeDelayMs(this.pluginProbeDelayMs);
        shared.setServerInfoOverlayInfoWidth(this.infoPreferredWidth);
        shared.setServerInfoOverlayInfoHeight(this.infoPreferredHeight);
        shared.setServerInfoOverlayPluginWidth(this.pluginPreferredWidth);
        shared.setServerInfoOverlayPluginHeight(this.pluginPreferredHeight);
        this.cacheCurrentScan();
        this.saveLayout();
    }

    public void restoreState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.restoreLayout();
        this.activeTab = Math.max(0, Math.min(TAB_NAMES.length - 1, shared.getServerInfoOverlayActiveTab()));
        this.pluginProbeDelayMs = Math.max(10, Math.min(500, shared.getServerInfoOverlayProbeDelayMs()));
        this.infoPreferredWidth = Math.max(this.infoMinWidth(), shared.getServerInfoOverlayInfoWidth());
        this.infoPreferredHeight = Math.max(this.infoMinHeight(), shared.getServerInfoOverlayInfoHeight());
        this.pluginPreferredWidth = Math.max(this.pluginResultsMinWidth(), shared.getServerInfoOverlayPluginWidth());
        this.pluginPreferredHeight = Math.max(this.pluginResultsMinHeightPreset(), shared.getServerInfoOverlayPluginHeight());
        this.syncScanStateForCurrentServer();
        String stateAddress = this.currentServerAddress();
        if (stateAddress.isEmpty()) {
            if (this.scannedServerAddress != null) {
                stateAddress = this.scannedServerAddress;
            }
        }
        if (!stateAddress.isEmpty()) {
            if (stateAddress.equals(shared.getServerInfoOverlayStateAddress())) {
                this.pluginScrollState.restore(shared.getServerInfoOverlayPluginScrollOffset());
                this.selectedPlugin = shared.getServerInfoOverlaySelectedPlugin();
                if (this.selectedPlugin != null) {
                    if (this.selectedPlugin.isBlank()) {
                        this.selectedPlugin = null;
                    }
                }
                if (this.selectedPlugin != null) {
                    if (!this.detectedPlugins.contains(this.selectedPlugin)) {
                        this.selectedPlugin = null;
                    }
                }
            }
        } else {
            this.pluginScrollState.jumpTo(0, 0);
            this.selectedPlugin = null;
        }
        if (this.activeTab == 0) {
            this.applyInfoLayout();
        } else {
            if (this.pluginScanInProgress) {
                this.applyPluginScanningLayout();
            } else {
                if (!this.pluginScanDone) {
                    this.applyPluginSetupLayout();
                }
            }
        }
        this.tabStrip.setActiveIndex(this.activeTab);
        this.probeDelaySlider.setValue((float)this.pluginProbeDelayMs);
    }

    private void selectTab(int tabIdx) {
        this.rememberCurrentTabSize();
        this.activeTab = Math.max(0, Math.min(TAB_NAMES.length - 1, tabIdx));
        this.tabStrip.setActiveIndex(this.activeTab);
        this.pluginScrollState.jumpTo(0, 0);
        this.selectedPlugin = null;
        if (this.activeTab == 0) {
            this.applyInfoLayout();
        } else {
            if (this.pluginScanInProgress) {
                this.applyPluginScanningLayout();
            } else {
                if (!this.pluginScanDone) {
                    this.applyPluginSetupLayout();
                } else {
                    this.applyPluginResultsLayout();
                }
            }
        }
        this.saveState();
    }

    private void rebuildUi() {
        this.windowNode.content().clearChildren();
        this.tabStrip.setActiveIndex(this.activeTab);
        this.probeDelaySlider.setValue((float)this.pluginProbeDelayMs);
        this.scanProgressBar.setProgress(this.getPluginScanProgress());
        if (!this.pluginScanInProgress) {
            this.windowNode.content().add(this.tabStrip);
        }
        if (this.activeTab == 0) {
            this.buildInfoUi();
            return;
        }
        this.buildPluginSetupUi();
        if (!this.pluginScanDone && !this.pluginScanInProgress) {
            return;
        }
        if (this.pluginScanInProgress) {
            this.buildPluginScanningUi();
            return;
        }
        this.buildPluginResultsUi();
    }

    private void buildInfoUi() {
        class_642 entry = MC.method_1558();
        String displayedAddress = this.getDisplayedServerAddress();
        String realIp = this.getDisplayedRealIp(displayedAddress);
        String software = this.getSoftwareGuess(entry);
        String versionNote = this.getVersionNote(entry);
        String ping = entry != null ? entry.field_3758 + " ms" : "--";
        String players = "--";
        if (MC.method_1562() == null) { /* goto L118; */ }
        int online = MC.method_1562().method_2880().size();
        players = entry != null && entry.field_41861 != null ? online + " / " + entry.field_41861.comp_1279() : String.valueOf(online);
        proto = entry != null ? String.valueOf(entry.field_3756) : "--";
        String diff = MC.field_1687 != null ? MC.field_1687.method_8407().method_5460() : "--";
        String time = "--";
        if (MC.field_1687 != null) {
            long dayCount = MC.field_1687.method_8532() / 24000L;
            long timeOfDay = MC.field_1687.method_8532() % 24000L;
            int hours = (int)((timeOfDay / 1000L + 6L) % 24L);
            int minutes = (int)(timeOfDay % 1000L * 60L / 1000L);
            time = "Day " + dayCount + " (" + String.format("%02d:%02d", hours, minutes) + ")";
        }
        estimatedTps = PackUtilSharedState.get().getEstimatedTps();
        tps = estimatedTps > 0 ? String.format("%.1f", Math.min(20, estimatedTps)) : "--";
        this.addInfoRow("IP:", displayedAddress, null, this::lambda$buildInfoUi$2 /* captured: displayedAddress */);
        String host = this.extractLookupHost(displayedAddress);
        if (!host.isBlank()) {
            if (!host.equals(realIp) || this.resolvingIp) {
                this.addInfoRow("Real IP:", realIp, null, this::copyResolvedServerIp);
            }
        }
        this.addInfoRow("Version:", this.getReportedVersion(entry), null);
        this.addInfoRow("Brand:", this.getLiveBrand(), null);
        if (!"--".equals(software)) {
            this.addInfoRow("Software:", software, null);
        }
        this.addInfoRow("Ping:", ping, null);
        this.addInfoRow("Players:", players, null);
        this.addInfoRow("Protocol:", proto, null);
        if (!"--".equals(versionNote)) {
            this.addInfoRow("Version Note:", versionNote, PackUtilColors.packetYellow());
        }
        this.addInfoRow("Difficulty:", diff, null);
        this.addInfoRow("World:", this.getCurrentWorldName(), null);
        this.addInfoRow("Time:", time, null);
        this.addInfoRow("TPS:", tps, null);
        detectedAcs = this.getDetectedAnticheats();
        if (this.pluginScanInProgress) {
            this.addInfoRow("AntiCheats:", "Scanning...", -48060);
        } else {
            if (!this.pluginScanDone) {
                this.addInfoRow("AntiCheats:", "Probe Plugins First", -48060);
            } else {
                if (detectedAcs.isEmpty()) {
                    this.addInfoRow("AntiCheats:", "None detected", null);
                } else {
                    this.addInfoRow("AntiCheats:", String.join(", ", detectedAcs), -48060);
                }
            }
        }
        this.windowNode.content().add(new PackUiSpacer(0f, 2f));
        this.windowNode.content().add(new PackUiButton("Copy Report", PackUiButton.Variant.SECONDARY, this::copyServerInfo).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
    }

    private void addInfoRow(String label, String value, Integer valueColor) {
        this.addInfoRow(label, value, valueColor, null);
    }

    private void addInfoRow(String label, String value, Integer valueColor, Runnable onPress) {
        this.windowNode.content().add(new PackUiInfoRow(label, value).setLabelWidth((float)this.infoLabelWidth()).setValueColorOverride(valueColor).setOnPress(onPress));
    }

    private void buildPluginSetupUi() {
        this.windowNode.content().add(new PackUiLabel("Start probing manually", PackUiTone.MUTED));
        this.windowNode.content().add(new PackUiInfoRow("Delay:", this.pluginProbeDelayMs + " ms").setLabelWidth((float)this.pluginSetupLabelWidth()));
        this.windowNode.content().add(this.probeDelaySlider);
        this.windowNode.content().add(new PackUiLabel("Default: 50 ms", PackUiTone.MUTED));
        this.windowNode.content().add(new PackUiLabel("If you get kicked increase the delay.", PackUiTone.MUTED));
        this.windowNode.content().add(new PackUiButton("Start Probing", PackUiButton.Variant.SECONDARY, this::lambda$buildPluginSetupUi$3).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
    }

    private void buildPluginScanningUi() {
        int progressPercent = Math.max(0, Math.min(100, Math.round(this.getPluginScanProgress() * 100f)));
        this.windowNode.content().add(new PackUiInfoRow("State:", this.getPluginScanPhaseLabel()).setLabelWidth((float)this.pluginScanLabelWidth()).setValueColorOverride(this.getPluginScanPhaseColor()));
        this.windowNode.content().add(new PackUiInfoRow("Detail:", this.getPluginScanPhaseDetail()).setLabelWidth((float)this.pluginScanLabelWidth()).setValueColorOverride(this.getPluginScanPhaseColor()));
        int foundCount = this.getDisplayedPluginCount();
        this.windowNode.content().add(new PackUiInfoRow("Found:", foundCount + " plugin" + foundCount == 1 ? "" : "s").setLabelWidth((float)this.pluginScanLabelWidth()));
        this.windowNode.content().add(new PackUiInfoRow("Progress:", progressPercent + "%").setLabelWidth((float)this.pluginScanLabelWidth()).setValueColorOverride(this.getPluginScanPhaseColor()));
        this.windowNode.content().add(this.scanProgressBar);
    }

    private void buildPluginResultsUi() {
        this.searchField.setPreferredWidth((float)Math.max(this.pluginSearchWidth(), this.panelW - this.pluginSearchReserveWidth()));
        this.windowNode.content().add(this.searchField);
        PackUiRow buttons = new PackUiRow().setGap(this.buttonRowGap());
        buttons.add(new PackUiButton("Rescan", PackUiButton.Variant.SECONDARY, this::lambda$buildPluginResultsUi$4).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
        buttons.add(new PackUiButton("Copy Plugins", PackUiButton.Variant.SECONDARY, this::copyPluginList).setGrowX(true).setButtonHeight(this.actionButtonHeight()));
        this.windowNode.content().add(buttons);
        String query = this.searchField.text().toLowerCase(Locale.ROOT);
        int filteredCount = 0;
        String header = this.detectedPlugins.iterator();
        while (header.hasNext()) {
            String plugin = (String)header.next();
            if (!query.isEmpty() || plugin.toLowerCase(Locale.ROOT).contains(query)) continue;
            filteredCount++;
        }
        header = this.detectedPlugins.isEmpty() ? "No plugins detected" : "Detected: " + filteredCount + " plugin" + filteredCount == 1 ? "" : "s";
        this.windowNode.content().add(new PackUiLabel(header, PackUiTone.MUTED));
        viewportHeight = Math.max(this.pluginViewportMinHeight(), (float)(this.panelH - this.getPluginResultsReservedHeight()));
        this.pluginListSlot.setPreferredHeight(viewportHeight);
        this.windowNode.content().add(this.pluginListSlot);
    }

    private String currentServerAddress() {
        class_642 entry = MC.method_1558();
        if (entry != null && entry.field_3761 != null && !entry.field_3761.isBlank()) {
            return entry.field_3761.trim().toLowerCase(Locale.ROOT);
        }
        if (MC.method_1562() == null) { /* goto L204; */ }
        if (MC.method_1562().method_48296() == null) { /* goto L204; */ }
        SocketAddress address = MC.method_1562().method_48296().method_10755();
        if (address instanceof InetSocketAddress) {
            InetSocketAddress inet = (InetSocketAddress)address;
            String host = inet.getHostString();
            if (host == null || host.isBlank()) {
                if (inet.getAddress() != null) {
                    host = inet.getAddress().getHostAddress();
                }
            }
            if (host != null) {
                if (!host.isBlank()) {
                    return host + ":" + inet.getPort().trim().toLowerCase(Locale.ROOT);
                }
            }
        } else {
            if (address != null) {
                String raw = address.toString();
                if (raw != null) {
                    if (!raw.isBlank()) {
                        return raw.replaceFirst("^/", "").trim().toLowerCase(Locale.ROOT);
                    }
                }
            }
        }
        return "";
    }

    private String normalizePluginContextSignature(String signature) {
        return signature == null ? "" : signature.trim().toLowerCase(Locale.ROOT);
    }

    private String currentPluginContextSignature() {
        if (MC.method_1562() == null) {
            return "";
        }
        String currentAddress = this.currentServerAddress();
        String brand = MC.method_1562().method_52790();
        String normalizedBrand = brand == null ? "" : brand.trim().toLowerCase(Locale.ROOT);
        if (!this.pluginContextSignatureDirty && currentAddress.equals(this.cachedPluginContextServerAddress) && normalizedBrand.equals(this.cachedPluginContextBrand)) {
            return this.cachedPluginContextSignature;
        }
        List<String> parts = new ArrayList();
        if (brand != null) {
            if (!brand.isBlank()) {
                parts.add("brand=" + normalizedBrand);
            }
        }
        try {
            CommandDispatcher<?> dispatcher = MC.method_1562().method_2886();
            if (dispatcher == null) { /* goto @284; */ }
            RootCommandNode<?> root = dispatcher.getRoot();
            if (root == null) { /* goto @284; */ }
            if (root.getChildren().isEmpty()) { /* goto @284; */ }
            List<String> rootCommands = new ArrayList();
            var var8 = root.getChildren().iterator();
            while (var8.hasNext()) {
                CommandNode<?> child = (CommandNode)var8.next();
                String name = child.getName();
                if (name != null) {
                    if (name.isBlank()) continue;
                    rootCommands.add(name.trim().toLowerCase(Locale.ROOT));
                }
            }
            rootCommands.sort(String.CASE_INSENSITIVE_ORDER);
            if (!rootCommands.isEmpty()) {
                parts.add("cmd=" + String.join(",", rootCommands));
            }
        }
        catch (Exception dispatcher) {
            this.cachedPluginContextServerAddress = currentAddress;
            this.cachedPluginContextBrand = normalizedBrand;
            this.cachedPluginContextSignature = this.normalizePluginContextSignature(String.join("|", parts));
            this.pluginContextSignatureDirty = false;
            return this.cachedPluginContextSignature;
        }
        this.cachedPluginContextServerAddress = currentAddress;
        this.cachedPluginContextBrand = normalizedBrand;
        this.cachedPluginContextSignature = this.normalizePluginContextSignature(String.join("|", parts));
        this.pluginContextSignatureDirty = false;
        return this.cachedPluginContextSignature;
    }

    private void invalidatePluginContextSignature() {
        this.pluginContextSignatureDirty = true;
    }

    private void setPluginProbeDelayMs(int delayMs) {
        this.pluginProbeDelayMs = Math.max(10, Math.min(500, delayMs));
        PackUtilSharedState.get().setServerInfoOverlayProbeDelayMs(this.pluginProbeDelayMs);
    }

    private void applyClampedBounds() {
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(this.panelX, this.panelY, this.panelW, this.panelH, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelW = clamped.width;
        this.panelH = clamped.height;
    }

    private void applyPluginSetupLayout() {
        this.panelW = this.getSharedPanelWidth();
        this.panelH = this.getPluginSetupPanelHeight();
        this.applyClampedBounds();
    }

    private void applyPluginScanningLayout() {
        this.panelW = this.getSharedPanelWidth();
        this.panelH = this.getPluginScanningPanelHeight();
        this.applyClampedBounds();
    }

    private void applyPluginResultsLayout() {
        this.panelW = this.getSharedPanelWidth();
        this.panelH = Math.max(this.getPluginResultsMinHeight(), Math.min(this.getSharedPanelHeight(), this.getPluginResultsMaxHeight()));
        this.applyClampedBounds();
    }

    private void applyInfoLayout() {
        this.panelW = this.getSharedPanelWidth();
        this.panelH = this.getSharedPanelHeight();
        this.applyClampedBounds();
    }

    private int getSharedPanelWidth() {
        PackUiViewport viewport = this.surface.viewport();
        return Math.max(this.infoMinWidth(), Math.min(this.sharedPanelWidth(), Math.round(viewport.uiWidth())));
    }

    private int getPluginResultsMinHeight() {
        return this.getSharedPanelHeight();
    }

    private int getPluginResultsMaxHeight() {
        PackUiViewport viewport = this.surface.viewport();
        int viewportHeight = Math.round(viewport.uiHeight());
        return Math.max(this.getPluginResultsMinHeight(), viewportHeight - 28);
    }

    private int getSharedPanelHeight() {
        PackUiViewport viewport = this.surface.viewport();
        int measured = Math.max(this.infoMinHeight(), Math.max(this.infoPreferredHeight, this.measurePreferredInfoPanelHeight()));
        return Math.max(this.infoMinHeight(), Math.min(measured, Math.max(this.infoMinHeight(), Math.round(viewport.uiHeight()) - this.viewportHeightMargin())));
    }

    private int getPluginSetupPanelHeight() {
        PackUiViewport viewport = this.surface.viewport();
        int measured = Math.max(this.pluginSetupHeight(), this.measurePreferredHeightForState(1, false, false, Math.max(this.panelW, this.pluginSetupWidth())));
        return Math.min(measured, Math.max(this.pluginSetupHeight(), Math.round(viewport.uiHeight()) - this.viewportHeightMargin()));
    }

    private int getPluginScanningPanelHeight() {
        PackUiViewport viewport = this.surface.viewport();
        int measured = Math.max(this.pluginScanningHeight(), this.measurePreferredHeightForState(1, false, true, Math.max(this.panelW, this.pluginScanningWidth())));
        return Math.min(measured, Math.max(this.pluginScanningHeight(), Math.round(viewport.uiHeight()) - this.viewportHeightMargin()));
    }

    private int getPluginResultsReservedHeight() {
        int contentPadding = this.panelPadding() * 2;
        int contentGap = this.contentGap() * 3;
        int searchHeight = this.searchFieldHeight();
        int buttonRowHeight = this.actionButtonHeight();
        int headerLabelHeight = 13;
        return this.theme.headerHeight() + contentPadding + contentGap + searchHeight + buttonRowHeight + headerLabelHeight;
    }

    private int measurePreferredInfoPanelHeight() {
        return Math.max(this.infoMinHeight(), this.measurePreferredHeightForState(0, this.pluginScanDone, this.pluginScanInProgress, Math.max(this.infoMinWidth(), this.panelW)));
    }

    private int measurePreferredHeightForState(int tab, boolean scanDone, boolean scanInProgress, int measureWidth) {
        int previousTab = this.activeTab;
        boolean previousScanDone = this.pluginScanDone;
        boolean previousScanInProgress = this.pluginScanInProgress;
        this.activeTab = tab;
        this.pluginScanDone = scanDone;
        this.pluginScanInProgress = scanInProgress;
        this.rebuildUi();
        int measured = Math.round(this.surface.measurePreferredHeight((float)measureWidth));
        this.activeTab = previousTab;
        this.pluginScanDone = previousScanDone;
        this.pluginScanInProgress = previousScanInProgress;
        this.rebuildUi();
        return measured;
    }

    private int getInfoRequiredHeight() {
        int rowCount = 11;
        String displayedAddress = this.getDisplayedServerAddress();
        String host = this.extractLookupHost(displayedAddress);
        String realIp = this.getDisplayedRealIp(displayedAddress);
        if (!host.isBlank()) {
            if (!host.equals(realIp) || this.resolvingIp) {
                rowCount++;
            }
        }
        class_642 entry = MC.method_1558();
        String software = this.getSoftwareGuess(entry);
        if (!"--".equals(software)) {
            rowCount++;
        }
        String versionNote = this.getVersionNote(entry);
        if (!"--".equals(versionNote)) {
            rowCount++;
        }
        int contentHeight = 5 + rowCount * 13 + 11 + this.actionButtonHeight();
        return this.theme.headerHeight() + this.panelPadding() * 2 + this.contentGap() * 2 + contentHeight;
    }

    private void rememberCurrentTabSize() {
        if (this.activeTab == 0) {
            this.infoPreferredWidth = Math.max(this.infoMinWidth(), this.panelW);
            this.infoPreferredHeight = Math.max(this.getInfoRequiredHeight(), this.panelH);
            this.pluginPreferredWidth = Math.max(this.pluginPreferredWidth, this.infoPreferredWidth);
            return;
        }
        this.pluginPreferredWidth = Math.max(this.pluginResultsMinWidth(), this.panelW);
        if (this.pluginScanDone && !this.pluginScanInProgress) {
            this.pluginPreferredHeight = Math.max(this.getPluginResultsMinHeight(), Math.min(this.getPluginResultsMaxHeight(), this.panelH));
            this.infoPreferredWidth = Math.max(this.infoPreferredWidth, this.pluginPreferredWidth);
        }
    }

    private void clearLocalScanState(String address, String contextSignature) {
        this.pluginScanDone = false;
        this.pluginScanInProgress = false;
        this.pluginScanCompletionAnnounced = false;
        this.pluginScanStartedAt = 0L;
        this.pluginScanLastResponseAt = 0L;
        this.pendingPluginProbeIds.clear();
        this.pluginProbes.clear();
        this.observedPluginCommands.clear();
        this.queuedPluginProbes.clear();
        this.pluginEvidence.clear();
        this.scanWorkingEntries.clear();
        this.nextPluginProbeSendAt = 0L;
        this.pluginScanTotalSteps = 0;
        this.scannedServerAddress = address;
        this.scannedPluginContextSignature = this.normalizePluginContextSignature(contextSignature);
        this.detectedPlugins.clear();
        this.pluginCommands.clear();
        this.pluginScrollState.jumpTo(0, 0);
        this.selectedPlugin = null;
        this.invalidatePluginContextSignature();
    }

    private boolean loadCachedScan(String address, String contextSignature) {
        ServerPluginScan cached = PackUtilSharedState.get().getServerPluginScan(address, contextSignature);
        if (cached == null) {
            return false;
        }
        this.detectedPlugins.clear();
        this.detectedPlugins.addAll(cached.getPlugins());
        this.pluginCommands.clear();
        this.pluginCommands.putAll(cached.getPluginCommands());
        this.pluginScrollState.jumpTo(0, 0);
        this.selectedPlugin = null;
        this.pluginScanDone = true;
        this.pluginScanInProgress = false;
        this.pluginScanStartedAt = 0L;
        this.pluginScanLastResponseAt = 0L;
        this.pendingPluginProbeIds.clear();
        this.pluginProbes.clear();
        this.observedPluginCommands.clear();
        this.queuedPluginProbes.clear();
        this.pluginEvidence.clear();
        this.scanWorkingEntries.clear();
        this.nextPluginProbeSendAt = 0L;
        this.pluginScanTotalSteps = 0;
        this.scannedServerAddress = cached.getAddress();
        this.scannedPluginContextSignature = this.normalizePluginContextSignature(cached.getContextSignature());
        Map<String, String> cachedEvidence = cached.getPluginEvidence();
        var var5 = this.detectedPlugins.iterator();
        while (var5.hasNext()) {
            String plugin = (String)var5.next();
            String key = this.normalizePluginKey(plugin);
            this.pluginEvidence.put(key, this.parseEvidenceName((String)cachedEvidence.get(key)));
        }
        return true;
    }

    private void cacheCurrentScan() {
        if (this.scannedServerAddress == null || this.scannedServerAddress.isBlank()) {
            return;
        }
        if (!this.pluginScanDone || this.pluginScanInProgress) {
            return;
        }
        Map<String, String> evidenceSnapshot = new LinkedHashMap();
        var var2 = this.pluginEvidence.entrySet().iterator();
        while (var2.hasNext()) {
            Map.Entry<String, PackUtilServerInfoOverlay.PluginEvidence> entry = (Map.Entry)var2.next();
            if (entry.getKey() == null) continue;
            if (((String)entry.getKey()).isBlank()) continue;
            while (entry.getValue() == null) {
            }
            evidenceSnapshot.put((String)entry.getKey(), ((PackUtilServerInfoOverlay.PluginEvidence)entry.getValue()).name());
        }
        PackUtilSharedState.get().setServerPluginScan(this.scannedServerAddress, this.scannedPluginContextSignature, this.detectedPlugins, this.pluginCommands, evidenceSnapshot);
    }

    private void syncScanStateForCurrentServer() {
        String currentAddress = this.currentServerAddress();
        if (currentAddress.isEmpty()) {
            return;
        }
        String currentContextSignature = this.currentPluginContextSignature();
        boolean sameAddress = currentAddress.equals(this.scannedServerAddress);
        boolean hasCurrentSignature = !currentContextSignature.isEmpty();
        boolean sameContext = sameAddress && currentContextSignature.equals(this.scannedPluginContextSignature);
        if (sameContext) {
            if (this.pluginScanDone || this.pluginScanInProgress) {
                return;
            }
        }
        if (sameAddress) {
            if (!hasCurrentSignature) {
                if (this.pluginScanDone || this.pluginScanInProgress) {
                    return;
                }
            }
        }
        if (!this.loadCachedScan(currentAddress, currentContextSignature)) {
            this.clearLocalScanState(currentAddress, currentContextSignature);
        }
    }

    private String normalizePluginKey(String plugin) {
        return plugin == null ? "" : plugin.trim().toLowerCase(Locale.ROOT);
    }

    private int evidenceRank(PackUtilServerInfoOverlay.PluginEvidence evidence) {
        switch (evidence.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return 0;
            case 1::
                return 1;
            case 2::
                return 2;
            case 3::
                return 3;
            case 4::
                return 4;
            case 5::
                return 5;
            case 6::
                return 6;
        }
    }

    private PackUtilServerInfoOverlay.PluginEvidence mergeEvidence(PackUtilServerInfoOverlay.PluginEvidence current, PackUtilServerInfoOverlay.PluginEvidence candidate) {
        if (current != null) { /* goto L16; */ }
        return candidate == null ? PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN : candidate;
        if (candidate == null) {
            return current;
        }
        return this.evidenceRank(candidate) < this.evidenceRank(current) ? candidate : current;
    }

    private PackUtilServerInfoOverlay.PluginEvidence parseEvidenceName(String value) {
        if (value == null || value.isBlank()) {
            return PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN;
        }
        try {
            return PackUtilServerInfoOverlay.PluginEvidence.valueOf(value);
        }
        catch (IllegalArgumentException ignored) {
            return PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN;
        }
    }

    private String getEvidenceTitle(PackUtilServerInfoOverlay.PluginEvidence evidence) {
        switch (evidence.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return "Command Tree";
            case 1::
                return "Namespace Probe";
            case 2::
                return "Command Root Hint";
            case 3::
                return "Help Hint";
            case 4::
                return "Plugin Command Hint";
            case 5::
                return "Version Command Hint";
            case 6::
                return "Other";
        }
    }

    private int getEvidenceColor(PackUtilServerInfoOverlay.PluginEvidence evidence, boolean hovered) {
        switch (evidence.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int base = PackUtilColors.packetGreen();
                break;
            case 1::
                base = PackUtilColors.packetCyan();
                break;
            case 2::
                base = PackUtilColors.packetBlue();
                break;
            case 3::
                base = PackUtilColors.packetLightYellow();
                break;
            case 4::
                base = PackUtilColors.packetYellow();
                break;
            case 5::
                base = PackUtilColors.packetOrange();
                break;
            case 6::
                base = PackUtilColors.packetWhite();
                break;
        }
        return hovered ? PackUtilColors.packetWhite() : base;
    }

    private Map<String, PackUtilServerInfoOverlay.PluginScanEntry> buildCurrentPluginEntries() {
        Map<String, PackUtilServerInfoOverlay.PluginScanEntry> entries = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        var var2 = this.detectedPlugins.iterator();
        while (var2.hasNext()) {
            String plugin = (String)var2.next();
            if (plugin == null) continue;
            while (plugin.isBlank()) {
            }
            List<String> existing = (List)this.pluginCommands.getOrDefault(plugin, List.of());
            PluginEvidence evidence = (PackUtilServerInfoOverlay.PluginEvidence)this.pluginEvidence.getOrDefault(this.normalizePluginKey(plugin), existing != null && !existing.isEmpty() ? PackUtilServerInfoOverlay.PluginEvidence.ROOT_HINT : PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN);
            this.mergePluginEntry(entries, plugin, existing, existing != null && !existing.isEmpty(), evidence);
        }
        return entries;
    }

    private void mergePluginEntry(Map<String, PackUtilServerInfoOverlay.PluginScanEntry> entries, String pluginName, Collection<String> commands, boolean commandBacked, PackUtilServerInfoOverlay.PluginEvidence evidence) {
        if (pluginName == null || pluginName.isBlank()) {
            return;
        }
        String cleanName = pluginName.trim();
        String key = this.normalizePluginKey(cleanName);
        if (key.isEmpty() || VANILLA_NAMESPACES.contains(key)) {
            return;
        }
        PluginScanEntry entry = (PackUtilServerInfoOverlay.PluginScanEntry)entries.computeIfAbsent(key, PackUtilServerInfoOverlay::lambda$mergePluginEntry$5);
        if (entry.displayName != null) {
            if (!entry.displayName.isBlank()) {
                if (!commandBacked) { /* goto @105; */ }
            }
        }
        entry.displayName = cleanName;
        L105: ;
        if (commandBacked) {
            entry.commandBacked = true;
        }
        entry.evidence = this.mergeEvidence(entry.evidence, evidence);
        this.pluginEvidence.put(key, this.mergeEvidence((PackUtilServerInfoOverlay.PluginEvidence)this.pluginEvidence.get(key), evidence));
        if (commands == null) { /* goto L237; */ }
        var var9 = commands.iterator();
        while (var9.hasNext()) {
            String command = (String)var9.next();
            while (command == null) {
            }
            String cleanCommand = command.trim();
            if (cleanCommand.isEmpty()) continue;
            entry.commands.add(cleanCommand);
        }
    }

    private void applyPluginEntries(Map<String, PackUtilServerInfoOverlay.PluginScanEntry> entries, boolean resetSelection) {
        this.detectedPlugins.clear();
        this.pluginCommands.clear();
        List<PackUtilServerInfoOverlay.PluginScanEntry> sortedEntries = new ArrayList(entries.values());
        sortedEntries.removeIf(PackUtilServerInfoOverlay::lambda$applyPluginEntries$6);
        sortedEntries.sort(PackUtilServerInfoOverlay::lambda$applyPluginEntries$7);
        var var4 = sortedEntries.iterator();
        while (var4.hasNext()) {
            PluginScanEntry entry = (PackUtilServerInfoOverlay.PluginScanEntry)var4.next();
            String plugin = entry.displayName;
            List<String> commands = new ArrayList(entry.commands);
            commands.removeIf(PackUtilServerInfoOverlay::lambda$applyPluginEntries$8);
            commands.sort(String.CASE_INSENSITIVE_ORDER);
            this.detectedPlugins.add(plugin);
            this.pluginCommands.put(plugin, commands);
        }
        if (resetSelection) {
            this.pluginScrollState.jumpTo(0, 0);
            this.selectedPlugin = null;
        } else {
            if (this.selectedPlugin != null) {
                if (!this.detectedPlugins.contains(this.selectedPlugin)) {
                    this.selectedPlugin = null;
                }
            }
        }
    }

    private boolean isKnownPluginNamespace(String key) {
        var var2 = COMMON_PLUGIN_NAMESPACES;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            String namespace = var2[var4];
            if (!namespace.equalsIgnoreCase(key)) continue;
            return true;
        }
        return false;
    }

    private String normalizeCommandToken(String raw) {
        if (raw == null) {
            return "";
        }
        String token = raw.trim();
        if (token.isEmpty()) {
            return "";
        }
        while (token.startsWith("/")) {
            token = token.substring(1).trim();
        }
        int spaceIndex = token.indexOf(32);
        if (spaceIndex >= 0) {
            token = token.substring(0, spaceIndex).trim();
        }
        while (token.endsWith(":")) {
            token = token.substring(0, token.length() - 1).trim();
        }
        return token.toLowerCase(Locale.ROOT);
    }

    private Set<String> getOnlinePlayerNames() {
        if (MC.method_1562() == null) {
            return Set.of();
        }
        Set<String> names = new HashSet();
        var var2 = MC.method_1562().method_2880().iterator();
        while (var2.hasNext()) {
            class_640 player = (class_640)var2.next();
            if (player == null) continue;
            while (player.method_2966() == null) {
            }
            String name = player.method_2966().name();
            if (name != null) {
                if (name.isBlank()) continue;
                names.add(name.trim().toLowerCase(Locale.ROOT));
            }
        }
        return names;
    }

    private boolean isLikelyPluginNameCandidate(String candidate, PackUtilServerInfoOverlay.PluginProbeKind kind) {
        if (candidate == null) {
            return false;
        }
        String clean = candidate.trim();
        String key = this.normalizePluginKey(clean);
        if (key.isEmpty()) {
            return false;
        }
        if (key.length() < 2) {
            return false;
        }
        if (clean.contains(" ") || clean.contains("/") || clean.contains(":")) {
            return false;
        }
        if (VANILLA_NAMESPACES.contains(key)) {
            return false;
        }
        if (this.getOnlinePlayerNames().contains(key)) {
            return false;
        }
        if (kind == PackUtilServerInfoOverlay.PluginProbeKind.PLUGIN_LIST || kind == PackUtilServerInfoOverlay.PluginProbeKind.VERSION) {
            if (key.equals("plugins") || key.equals("plugin") || key.equals("version") || key.equals("about")) {
                return false;
            }
        }
        return key.chars().allMatch(PackUtilServerInfoOverlay::lambda$isLikelyPluginNameCandidate$9);
    }

    private void addObservedPluginCommand(String raw) {
        String token = this.normalizeCommandToken(raw);
        if (token.isEmpty()) {
            return;
        }
        if (!token.chars().allMatch(PackUtilServerInfoOverlay::lambda$addObservedPluginCommand$10)) {
            return;
        }
        if (VANILLA_NAMESPACES.contains(token)) {
            return;
        }
        this.observedPluginCommands.add(token);
    }

    private void inferPluginsFromObservedCommands(Map<String, PackUtilServerInfoOverlay.PluginScanEntry> entries) {
        if (this.observedPluginCommands.isEmpty()) {
            return;
        }
        Map<String, Set<String>> inferredMatches = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        var var3 = this.observedPluginCommands.iterator();
        while (var3.hasNext()) {
            String command = (String)var3.next();
            String plugin = null;
            if (this.isKnownPluginNamespace(command)) {
                plugin = command;
            } else {
                if (!ROOT_COMMAND_PLUGIN_ALIASES.containsKey(command)) continue;
                plugin = (String)ROOT_COMMAND_PLUGIN_ALIASES.get(command);
            }
            if (plugin != null) {
                if (plugin.isBlank()) continue;
                ((Set)inferredMatches.computeIfAbsent(plugin, PackUtilServerInfoOverlay::lambda$inferPluginsFromObservedCommands$11)).add(command);
            }
        }
        var3 = inferredMatches.entrySet().iterator();
        while (var3.hasNext()) {
            inferred = (Map.Entry)var3.next();
            this.mergePluginEntry(entries, (String)inferred.getKey(), (Collection)inferred.getValue(), true, PackUtilServerInfoOverlay.PluginEvidence.ROOT_HINT);
        }
    }

    private int addProbeVariants(Map<Integer, PackUtilServerInfoOverlay.PluginProbeSpec> probes, int nextId, PackUtilServerInfoOverlay.PluginProbeKind kind, String ... baseCommands) {
        var var5 = baseCommands;
        var var6 = var5.length;
        for (int var7 = 0; var7 < var6; var7++) {
            String base = var5[var7];
            if (base == null) { /* goto L104; */ }
            if (base.isBlank()) {
            } else {
                String trimmed = base.trim();
                probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec(trimmed, kind, null));
                probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec(trimmed + " ", kind, null));
            }
        }
        return nextId;
    }

    private Map<Integer, PackUtilServerInfoOverlay.PluginProbeSpec> buildPluginProbes() {
        Map<Integer, PackUtilServerInfoOverlay.PluginProbeSpec> probes = new LinkedHashMap();
        int nextId = 1337;
        probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec("/", PackUtilServerInfoOverlay.PluginProbeKind.ROOT, null));
        probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec("/ ", PackUtilServerInfoOverlay.PluginProbeKind.ROOT, null));
        nextId = this.addProbeVariants(probes, nextId, PackUtilServerInfoOverlay.PluginProbeKind.PLUGIN_LIST, "/plugins", "/pl", "/bukkit:plugins", "/bukkit:pl");
        nextId = this.addProbeVariants(probes, nextId, PackUtilServerInfoOverlay.PluginProbeKind.VERSION, "/ver", "/version", "/about", "/icanhasbukkit", "/bukkit:ver", "/bukkit:version");
        nextId = this.addProbeVariants(probes, nextId, PackUtilServerInfoOverlay.PluginProbeKind.HELP, "/help", "/?", "/bukkit:help", "/minecraft:help");
        for (int i = 0; i < "abcdefghijklmnopqrstuvwxyz0123456789".length(); i++) {
            char prefix = "abcdefghijklmnopqrstuvwxyz0123456789".charAt(i);
            String rootProbe = "/" + prefix;
            probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec(rootProbe, PackUtilServerInfoOverlay.PluginProbeKind.ROOT, String.valueOf(prefix)));
            probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec("/help " + prefix, PackUtilServerInfoOverlay.PluginProbeKind.HELP, String.valueOf(prefix)));
            probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec("/? " + prefix, PackUtilServerInfoOverlay.PluginProbeKind.HELP, String.valueOf(prefix)));
        }
        i = COMMON_PLUGIN_NAMESPACES;
        prefix = i.length;
        for (rootProbe = 0; rootProbe < prefix; rootProbe++) {
            String namespace = i[rootProbe];
            probes.put(nextId++, new PackUtilServerInfoOverlay.PluginProbeSpec("/" + namespace + ":", PackUtilServerInfoOverlay.PluginProbeKind.NAMESPACE, namespace));
        }
        return probes;
    }

    private void finalizePluginScan() {
        if (!this.pluginScanInProgress && this.pluginScanDone) {
            return;
        }
        this.applyPluginEntries(this.scanWorkingEntries, true);
        this.pluginScanInProgress = false;
        this.pluginScanDone = true;
        this.pendingPluginProbeIds.clear();
        this.pluginProbes.clear();
        this.observedPluginCommands.clear();
        this.queuedPluginProbes.clear();
        this.nextPluginProbeSendAt = 0L;
        this.scanWorkingEntries.clear();
        this.pluginScanStartedAt = 0L;
        this.pluginScanLastResponseAt = 0L;
        this.pluginScanTotalSteps = 0;
        this.scanWorkingEntries.clear();
        this.applyPluginResultsLayout();
        this.cacheCurrentScan();
        this.announcePluginScanComplete();
    }

    private void dispatchQueuedPluginProbes() {
        if (!this.pluginScanInProgress || MC.method_1562() == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now < this.nextPluginProbeSendAt) {
            return;
        }
        PluginProbeRequest request = (PackUtilServerInfoOverlay.PluginProbeRequest)this.queuedPluginProbes.pollFirst();
        if (request == null) {
            return;
        }
        try {
            class_2805 packet = new class_2805(request.id, request.spec.query);
            MC.method_1562().method_52787(packet);
            this.nextPluginProbeSendAt = now + (long)this.pluginProbeDelayMs;
        }
        catch (Exception ignored) {
            this.pendingPluginProbeIds.remove(request.id);
            this.pluginProbes.remove(request.id);
            L130: ;
            return;
        }
    }

    private int getTotalPluginProbeCount() {
        return Math.max(0, this.pluginScanTotalSteps - 1);
    }

    private long getPluginScanSendWindowMs() {
        return Math.max((long)this.pluginProbeDelayMs, (long)this.getTotalPluginProbeCount() * (long)this.pluginProbeDelayMs);
    }

    private long getPluginScanFinishedSendingAt() {
        if (this.pluginScanStartedAt <= 0L) {
            return 0L;
        }
        if (!this.queuedPluginProbes.isEmpty()) {
            return 0L;
        }
        long candidate = this.nextPluginProbeSendAt - (long)this.pluginProbeDelayMs;
        return Math.max(this.pluginScanStartedAt, candidate);
    }

    private long getPluginScanHardTimeoutMs() {
        return Math.max(12000L, this.getPluginScanSendWindowMs() + 450L + 600L);
    }

    private int lerpColor(int from, int to, float t) {
        float clamped = Math.max(0f, Math.min(1f, t));
        int a1 = from >>> 24 & 255;
        int r1 = from >>> 16 & 255;
        int g1 = from >>> 8 & 255;
        int b1 = from & 255;
        int a2 = to >>> 24 & 255;
        int r2 = to >>> 16 & 255;
        int g2 = to >>> 8 & 255;
        int b2 = to & 255;
        int a = Math.round((float)a1 + (float)(a2 - a1) * clamped);
        int r = Math.round((float)r1 + (float)(r2 - r1) * clamped);
        int g = Math.round((float)g1 + (float)(g2 - g1) * clamped);
        int b = Math.round((float)b1 + (float)(b2 - b1) * clamped);
        return a << 24 | r << 16 | g << 8 | b;
    }

    private int getSentPluginProbeCount() {
        int total = this.getTotalPluginProbeCount();
        return Math.max(0, Math.min(total, total - this.queuedPluginProbes.size()));
    }

    private int getAnsweredPluginProbeCount() {
        int total = this.getTotalPluginProbeCount();
        return Math.max(0, Math.min(total, total - this.pendingPluginProbeIds.size()));
    }

    private float getPluginScanProgress() {
        if (this.pluginScanDone) {
            return 1f;
        }
        int total = this.getTotalPluginProbeCount();
        if (total <= 0) {
            return 0f;
        }
        float sentRatio = (float)this.getSentPluginProbeCount() / (float)total;
        float answeredRatio = (float)this.getAnsweredPluginProbeCount() / (float)total;
        if (!this.queuedPluginProbes.isEmpty()) {
            float progress = 0.8f * sentRatio;
            progress = progress + 0.05f * answeredRatio;
            return Math.max(0f, Math.min(0.85f, progress));
        }
        progress = 0.85f;
        long finishedSendingAt = this.getPluginScanFinishedSendingAt();
        long waitWindow = this.pendingPluginProbeIds.isEmpty() ? 700L : 450L;
        long now = System.currentTimeMillis();
        if (finishedSendingAt > 0L && waitWindow > 0L) {
            float settle = Math.max(0f, Math.min(1f, (float)(now - finishedSendingAt) / (float)waitWindow));
            progress = progress + 0.14f * settle;
        }
        return Math.max(0f, Math.min(0.99f, progress));
    }

    private int getWorkingPluginCount() {
        return (int)this.scanWorkingEntries.values().stream().filter(PackUtilServerInfoOverlay::lambda$getWorkingPluginCount$12).count();
    }

    private int getDisplayedPluginCount() {
        if (this.pluginScanInProgress) {
            return this.getWorkingPluginCount();
        }
        return this.detectedPlugins.size();
    }

    private String getPluginScanStatusLabel() {
        int foundCount = this.getDisplayedPluginCount();
        if (foundCount > 0) {
            return "Scanning plugins | found " + foundCount;
        }
        return "Scanning plugins";
    }

    private String getPluginScanPhaseLabel() {
        return this.queuedPluginProbes.isEmpty() ? "Analyzing replies" : "Sending probes";
    }

    private int getPluginScanPhaseColor() {
        return this.queuedPluginProbes.isEmpty() ? PackUtilColors.packetCyan() : PackUtilColors.packetYellow();
    }

    private String getPluginScanPhaseDetail() {
        int total = Math.max(1, this.getTotalPluginProbeCount());
        return this.queuedPluginProbes.isEmpty() ? this.getAnsweredPluginProbeCount() + "/" + total : this.getSentPluginProbeCount() + "/" + total;
    }

    private void announcePluginScanComplete() {
        if (this.pluginScanCompletionAnnounced) {
            return;
        }
        this.pluginScanCompletionAnnounced = true;
        int count = this.detectedPlugins.size();
        if (count <= 0) {
            PackUtilClientMessaging.sendPrefixed("Plugin probing finished: no plugins found.");
        } else {
            if (count == 1) {
                PackUtilClientMessaging.sendPrefixed("Plugin probing finished: found 1 plugin.");
            } else {
                PackUtilClientMessaging.sendPrefixed("Plugin probing finished: found " + count + " plugins.");
            }
        }
    }

    public boolean shouldRenderBackgroundProbeBanner() {
        return this.pluginScanInProgress;
    }

    public void renderBackgroundProbeBanner(class_332 ctx) {
        if (!this.shouldRenderBackgroundProbeBanner() || MC == null || MC.method_22683() == null || this.textRenderer == null) {
            return;
        }
        PackUiViewport viewport = this.surface.viewport();
        String status = this.getPluginScanStatusLabel();
        String phase = this.getPluginScanPhaseLabel();
        String detail = this.getPluginScanPhaseDetail();
        int progressPercent = Math.max(0, Math.min(100, Math.round(this.getPluginScanProgress() * 100f)));
        String percentText = progressPercent + "%";
        int screenW = Math.round(viewport.uiWidth());
        int statusWidth = PackUiText.width(this.textRenderer, status, this.theme.fontFor(PackUiTone.MUTED), this.theme.color(PackUiTone.MUTED));
        int phaseWidth = PackUiText.width(this.textRenderer, phase, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY));
        int detailWidth = PackUiText.width(this.textRenderer, detail, this.theme.fontFor(PackUiTone.MUTED), this.getPluginScanPhaseColor());
        int percentWidth = PackUiText.width(this.textRenderer, percentText, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY));
        int contentW = Math.max(180, Math.max(statusWidth, Math.max(phaseWidth + 12 + detailWidth, percentWidth + 150)));
        int boxW = Math.min(screenW - 16, Math.max(236, contentW + 24));
        int boxH = 42;
        int boxX = Math.max(8, (screenW - boxW) / 2);
        int boxY = 8;
        int innerX = boxX + 8;
        int barY = boxY + 17;
        int barW = boxW - 16;
        int barH = 10;
        viewport.push(ctx);
        try {
            PackUiRenderContext bannerContext = new PackUiRenderContext(ctx, this.textRenderer, viewport, this.theme, 0f, 0f, 0f);
            int border = this.theme.borderColor();
            int headerAccent = this.theme.headerAccent();
            ctx.method_25294(boxX, boxY, boxX + boxW, boxY + boxH, bannerContext.applyAlpha(this.theme.windowFill()));
            ctx.method_25294(boxX + 1, boxY + 1, boxX + boxW - 1, boxY + 13, bannerContext.applyAlpha(this.theme.headerFill()));
            ctx.method_25294(boxX, boxY, boxX + boxW, boxY + 1, bannerContext.applyAlpha(border));
            ctx.method_25294(boxX, boxY + boxH - 1, boxX + boxW, boxY + boxH, bannerContext.applyAlpha(border));
            ctx.method_25294(boxX, boxY, boxX + 1, boxY + boxH, bannerContext.applyAlpha(border));
            ctx.method_25294(boxX + boxW - 1, boxY, boxX + boxW, boxY + boxH, bannerContext.applyAlpha(border));
            ctx.method_25294(boxX, boxY + 13, boxX + boxW, boxY + 14, bannerContext.applyAlpha(headerAccent));
            PackUiText.draw(ctx, this.textRenderer, status, this.theme.fontFor(PackUiTone.MUTED), this.theme.color(PackUiTone.MUTED), innerX, boxY + 3, false);
            PackUiText.draw(ctx, this.textRenderer, percentText, this.theme.fontFor(PackUiTone.BODY), this.getPluginScanPhaseColor(), boxX + boxW - 8 - percentWidth, boxY + 3, false);
            ctx.method_25294(innerX, barY, innerX + barW, barY + barH, bannerContext.applyAlpha(2081032460));
            ctx.method_25294(innerX, barY, innerX + barW, barY + 1, bannerContext.applyAlpha(-7392975));
            ctx.method_25294(innerX, barY + barH - 1, innerX + barW, barY + barH, bannerContext.applyAlpha(-7392975));
            ctx.method_25294(innerX, barY, innerX + 1, barY + barH, bannerContext.applyAlpha(-7392975));
            ctx.method_25294(innerX + barW - 1, barY, innerX + barW, barY + barH, bannerContext.applyAlpha(-7392975));
            int fillW = Math.max(0, Math.min(barW - 2, Math.round((float)(barW - 2) * this.getPluginScanProgress())));
            if (fillW > 0) {
                int fillColor = PackUiSizing.lerpColor(-42406, -10035062, this.getPluginScanProgress());
                ctx.method_25294(innerX + 1, barY + 1, innerX + 1 + fillW, barY + barH - 1, bannerContext.applyAlpha(fillColor));
            }
            PackUiText.draw(ctx, this.textRenderer, phase, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY), innerX, barY + 13, false);
            PackUiText.draw(ctx, this.textRenderer, detail, this.theme.fontFor(PackUiTone.MUTED), this.getPluginScanPhaseColor(), boxX + boxW - 8 - detailWidth, barY + 13, false);
        }
        finally {
            viewport.pop(ctx);
            throw var27;
        }
    }

    private void updatePluginScanLifecycle() {
        if (!this.pluginScanInProgress) {
            return;
        }
        this.dispatchQueuedPluginProbes();
        long now = System.currentTimeMillis();
        boolean allProbesSent = this.queuedPluginProbes.isEmpty();
        boolean allResponsesReceived = this.pendingPluginProbeIds.isEmpty();
        boolean idle = this.pluginScanLastResponseAt > 0L && now - this.pluginScanLastResponseAt >= 700L;
        long finishedSendingAt = this.getPluginScanFinishedSendingAt();
        if (finishedSendingAt <= 0L) { /* goto @109; */ }
        if (now - finishedSendingAt < allResponsesReceived ? 700L : 450L) { /* goto @109; */ }
        boolean settledAfterSend = allProbesSent;
        boolean timedOut = this.pluginScanStartedAt > 0L && now - this.pluginScanStartedAt >= this.getPluginScanHardTimeoutMs();
        if (!allProbesSent || !allResponsesReceived) {
            if (!allProbesSent) { /* goto L160; */ }
            if (settledAfterSend || timedOut) {
                this.finalizePluginScan();
            }
        }
        this.finalizePluginScan();
        L169: ;
    }

    public void tickBackground() {
        this.syncScanStateForCurrentServer();
        if (this.pluginScanInProgress) {
            this.updatePluginScanLifecycle();
        }
    }

    private void parseCommandTree(RootCommandNode<?> root) {
        Map<String, PackUtilServerInfoOverlay.PluginScanEntry> entries = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        entries.putAll(this.scanWorkingEntries);
        var var3 = root.getChildren().iterator();
        while (var3.hasNext()) {
            CommandNode<?> child = (CommandNode)var3.next();
            String name = child.getName();
            if (name.contains(":")) {
                String[] parts = name.split(":", 2);
                String ns = parts[0].toLowerCase();
                String cmd = parts[1];
                if (!VANILLA_NAMESPACES.contains(ns)) {
                    this.mergePluginEntry(entries, ns, List.of(cmd), true, PackUtilServerInfoOverlay.PluginEvidence.COMMAND_TREE);
                    this.addObservedPluginCommand(cmd);
                }
            } else {
                this.addObservedPluginCommand(name);
            }
        }
        this.inferPluginsFromObservedCommands(entries);
        this.scanWorkingEntries.clear();
        this.scanWorkingEntries.putAll(entries);
    }

    public void resetScan() {
        this.clearLocalScanState(null, "");
        this.searchField.setText("");
        this.searchField.setFocused(false);
        this.resolvedIp = null;
        this.lastResolvedAddress = null;
        this.invalidatePluginContextSignature();
    }

    private void scanPlugins() {
        this.syncScanStateForCurrentServer();
        if (this.pluginScanDone || this.pluginScanInProgress) {
            return;
        }
        if (MC.method_1562() == null) {
            this.pluginScanDone = true;
            this.cacheCurrentScan();
            return;
        }
        this.scannedServerAddress = this.currentServerAddress();
        this.scannedPluginContextSignature = this.currentPluginContextSignature();
        this.activeTab = 1;
        this.pluginScanInProgress = true;
        this.pluginScanDone = false;
        this.pluginScanStartedAt = System.currentTimeMillis();
        this.pluginScanLastResponseAt = this.pluginScanStartedAt;
        this.pendingPluginProbeIds.clear();
        this.pluginProbes.clear();
        this.observedPluginCommands.clear();
        this.queuedPluginProbes.clear();
        this.pluginEvidence.clear();
        this.scanWorkingEntries.clear();
        this.nextPluginProbeSendAt = this.pluginScanStartedAt + (long)this.pluginProbeDelayMs;
        this.applyPluginScanningLayout();
        try {
            CommandDispatcher<?> dispatcher = MC.method_1562().method_2886();
            if (dispatcher != null) {
                RootCommandNode<?> root = dispatcher.getRoot();
                if (root != null) {
                    if (!root.getChildren().isEmpty()) {
                        this.parseCommandTree(root);
                    }
                }
            }
            probes = this.buildPluginProbes();
            this.pluginScanTotalSteps = probes.size() + 1;
            var var3 = probes.entrySet().iterator();
            while (var3.hasNext()) {
                Map.Entry<Integer, PackUtilServerInfoOverlay.PluginProbeSpec> probe = (Map.Entry)var3.next();
                this.pendingPluginProbeIds.add((Integer)probe.getKey());
                this.pluginProbes.put((Integer)probe.getKey(), (PackUtilServerInfoOverlay.PluginProbeSpec)probe.getValue());
                this.queuedPluginProbes.addLast(new PackUtilServerInfoOverlay.PluginProbeRequest(((Integer)probe.getKey()).intValue(), (PackUtilServerInfoOverlay.PluginProbeSpec)probe.getValue()));
            }
            this.updatePluginScanLifecycle();
        }
        catch (Exception ignored) {
            this.finalizePluginScan();
            L349: ;
            return;
        }
    }

    public void onCommandSuggestions(int id, class_2639 packet) {
        PluginProbeSpec probe = (PackUtilServerInfoOverlay.PluginProbeSpec)this.pluginProbes.get(id);
        if (probe == null && !this.pendingPluginProbeIds.contains(id)) {
            return;
        }
        MC.execute(this::lambda$onCommandSuggestions$13 /* captured: packet, id, probe */);
    }

    public void onCommandTreeChanged() {
        this.invalidatePluginContextSignature();
        MC.execute(this::lambda$onCommandTreeChanged$14);
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public void setVisible(boolean v) {
        this.visible = v;
        if (!v) { /* goto L86; */ }
        this.windowNode.syncShowBody(!this.collapsed);
        PackUtilOverlayManager.get().bringToFront(this);
        this.syncScanStateForCurrentServer();
        if (this.activeTab == 0) {
            this.applyInfoLayout();
        } else {
            if (this.pluginScanInProgress) {
                this.applyPluginScanningLayout();
            } else {
                if (!this.pluginScanDone) {
                    this.applyPluginSetupLayout();
                } else {
                    this.applyPluginResultsLayout();
                }
            }
        }
        this.saveState();
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean c) {
        this.collapsed = c;
        this.windowNode.syncShowBody(!this.collapsed);
    }

    public String getOverlayId() {
        return "packutil-serverinfo";
    }

    public boolean isMouseOver(double mx, double my) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiX = viewport.toUiX(mx);
        float uiY = viewport.toUiY(my);
        return uiX >= (float)this.panelX && uiX <= (float)(this.panelX + this.panelW) && uiY >= (float)this.panelY && uiY <= (float)(this.panelY + this.panelH);
    }

    public boolean isOverDragBar(double mx, double my) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        return this.isOverHeaderUi(viewport.toUiX(mx), viewport.toUiY(my));
    }

    public boolean hasTextFieldFocused() {
        return this.surface.hasFocusedTextInput();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelW, this.panelH, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout b) {
        if (b == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToViewport(b);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelW = clamped.width;
        this.panelH = clamped.height;
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
        this.windowNode.syncShowBody(!this.collapsed);
        this.rememberCurrentTabSize();
    }

    public int getMinWidth() {
        return this.getSharedPanelWidth();
    }

    public int getMinHeight() {
        if (this.activeTab == 1) {
            if (this.pluginScanInProgress) {
                return this.getPluginScanningPanelHeight();
            }
            if (!this.pluginScanDone) {
                return this.getPluginSetupPanelHeight();
            }
            return this.getPluginResultsMinHeight();
        }
        return this.measurePreferredInfoPanelHeight();
    }

    public void render(class_332 ctx, int mx, int my, float delta) {
        if (!this.visible) {
            return;
        }
        this.syncScanStateForCurrentServer();
        this.updatePluginScanLifecycle();
        this.clickRegions.clear();
        this.rebuildUi();
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX((double)mx);
        float uiMouseY = viewport.toUiY((double)my);
        boolean active = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        boolean headerHovered = this.isOverHeaderUi(uiMouseX, uiMouseY);
        PackUiRenderContext metrics = new PackUiRenderContext(ctx, this.textRenderer, viewport, this.theme, uiMouseX, uiMouseY, delta);
        this.windowNode.setShowBody(!this.collapsed);
        this.windowNode.setActive(active);
        this.windowNode.setHeaderHovered(headerHovered);
        int preferredHeight = Math.round(this.windowNode.preferredHeight(metrics, (float)this.panelW));
        if (this.collapsed) {
            this.panelH = preferredHeight;
        } else {
            if (this.activeTab == 0) {
                this.panelH = this.getSharedPanelHeight();
            } else {
                if (this.pluginScanInProgress) {
                    this.panelH = this.getPluginScanningPanelHeight();
                } else {
                    if (!this.pluginScanDone) {
                        this.panelH = this.getPluginSetupPanelHeight();
                    } else {
                        this.panelH = Math.max(this.getPluginResultsMinHeight(), Math.min(this.getPluginResultsMaxHeight(), this.getSharedPanelHeight()));
                    }
                }
            }
        }
        this.panelW = Math.max(this.getMinWidth(), this.panelW);
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(this.panelX, this.panelY, this.panelW, this.panelH, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelW = clamped.width;
        this.panelH = clamped.height;
        this.windowNode.setBounds((float)this.panelX, (float)this.panelY, (float)this.panelW, (float)this.panelH);
        this.surface.render(ctx, mx, my, delta);
        this.renderHeaderControls(ctx, viewport, uiMouseX, uiMouseY, delta, active);
        if (!this.collapsed) {
            if (this.activeTab == 1) {
                if (this.pluginScanDone) {
                    if (!this.pluginScanInProgress) {
                        this.renderPluginResultsViewport(ctx, viewport, uiMouseX, uiMouseY, delta);
                    }
                }
            }
        }
    }

    private String getReportedVersion(class_642 entry) {
        return entry != null && entry.field_3760 != null ? entry.field_3760.getString() : "--";
    }

    private void renderHeaderControls(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta, boolean active) {
        this.closeVisibility = this.animate(this.closeVisibility, 1f, delta);
        this.closeHover = this.animate(this.closeHover, this.isOverCloseButton(uiMouseX, uiMouseY) ? 1f : 0f, delta);
        viewport.push(context);
        try {
            int arrowX = this.collapseArrowX();
            int closeX = this.closeButtonX();
            int controlY = this.controlButtonY();
            this.drawCollapseArrow(context, arrowX, controlY, active);
            this.drawCloseButton(context, closeX, controlY, this.headerControlSize(), this.headerControlSize(), this.closeHover, active, this.closeVisibility);
        }
        finally {
            viewport.pop(context);
            throw var10;
        }
    }

    private float animate(float current, float target, float delta) {
        return PackUiHeaderControls.animate(current, target, delta);
    }

    private void drawCollapseArrow(class_332 context, int x, int y, boolean active) {
        PackUiHeaderControls.drawAnimatedArrow(context, x, y + 1, this.headerArrowWidth(), this.collapsed ? 0f : 1f, active ? 1f : 0.56f);
    }

    private void drawCloseButton(class_332 context, int x, int y, int width, int height, float hover, boolean active, float visibility) {
        PackUiHeaderControls.drawCloseButton(context, x, y, width, height, hover, active, visibility);
    }

    private void renderPluginResultsViewport(class_332 ctx, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta) {
        int x = Math.round(this.pluginListSlot.x());
        int y = Math.round(this.pluginListSlot.y());
        int rowW = Math.round(this.pluginListSlot.width());
        int bodyBottom = this.panelY + this.panelH - 10;
        int rawViewH = Math.max(0, Math.min(Math.round(this.pluginListSlot.height()), bodyBottom - y));
        int viewH = this.getPluginListViewportHeight(rawViewH);
        int listTop = y;
        int listBottom = listTop + viewH;
        if (rowW <= 0 || viewH <= 0) {
            return;
        }
        int clipLeft = x + 1;
        int clipTop = listTop + 1;
        int clipRight = x + rowW - 1;
        int clipBottom = listBottom - 1;
        int innerViewH = this.getPluginListInnerHeight(viewH);
        if (innerViewH <= 0) {
            return;
        }
        String query = this.searchField.text().toLowerCase(Locale.ROOT);
        List<String> filtered = (List)this.detectedPlugins.stream().filter(PackUtilServerInfoOverlay::lambda$renderPluginResultsViewport$15 /* captured: query */).collect(Collectors.toList());
        List<PackUtilServerInfoOverlay.PluginListRow> rows = this.buildPluginRows(filtered);
        int estimatedContentHeight = this.estimatePluginContentHeight(rows);
        int maxScroll = Math.max(0, estimatedContentHeight - innerViewH);
        int quantizedTarget = this.quantizeScrollOffset(this.pluginScrollState.targetOffset(), this.pluginListRowStep(), maxScroll);
        this.pluginScrollState.setTarget(quantizedTarget, maxScroll);
        int visualScroll = this.quantizeScrollOffset(this.pluginScrollState.tick(delta, maxScroll), this.pluginListRowStep(), maxScroll);
        this.pluginContentHeight = estimatedContentHeight;
        Metrics scrollbarMetrics = this.getPluginScrollbarMetrics(x, listTop, rowW, viewH);
        int rowContentW = Math.max(48, clipRight - clipLeft - (scrollbarMetrics.hasScroll() ? 10 : 0));
        boolean active = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        viewport.push(ctx);
        PackUiListRenderer.drawFrame(ctx, x, listTop, rowW, viewH, active);
        viewport.enableScissor(ctx, (float)clipLeft, (float)clipTop, (float)clipRight, (float)clipBottom);
        int cy = clipTop - visualScroll;
        var var30 = rows.iterator();
        while (var30.hasNext()) {
            PluginListRow row = (PackUtilServerInfoOverlay.PluginListRow)var30.next();
            while (row.header) {
                int headerTop = cy;
                int headerBottom = cy + this.pluginHeaderHeight();
                boolean headerVisible = headerTop >= clipTop && headerBottom <= clipBottom;
                if (headerVisible) {
                    ctx.method_25294(clipLeft, headerTop, clipRight, headerBottom, PackUiRenderContext.applyAlpha(1008210453, 1f));
                    int headerTextY = PackUiSizing.alignTextY(cy, this.pluginHeaderHeight(), this.theme.fontHeight(PackUiTone.MUTED), this.theme.bodyTextNudge());
                    PackUiText.draw(ctx, this.textRenderer, row.title, this.theme.fontFor(PackUiTone.MUTED), -4743522, clipLeft + this.rowTextInset(), headerTextY, false);
                }
                cy = cy + this.pluginHeaderHeight();
            }
            plugin = row.plugin;
            selected = plugin.equals(this.selectedPlugin);
            cmds = (List)this.pluginCommands.get(plugin);
            isAnticheat = ANTICHEATS.contains(plugin.toLowerCase(Locale.ROOT));
            int rowY = cy;
            int rowTop = rowY;
            int rowBottom = rowY + this.pluginRowHeight();
            boolean rowVisible = rowTop >= clipTop && rowBottom <= clipBottom;
            boolean hovered = rowVisible && uiMouseX >= (float)clipLeft && uiMouseX < (float)(clipLeft + rowContentW) && uiMouseY >= (float)rowTop && uiMouseY < (float)rowBottom;
            int rowBg = selected ? 1258240827 : hovered ? 788482634 : 369098752;
            if (!rowVisible) continue;
            ctx.method_25294(clipLeft, rowTop, clipLeft + rowContentW, rowBottom, rowBg);
            boolean hasCommands = cmds != null && !cmds.isEmpty();
            int rowTextY = PackUiSizing.alignTextY(rowY, this.pluginRowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
            if (!hasCommands) { /* goto L878; */ }
            if (!rowVisible) { /* goto L878; */ }
            String arrow = selected ? "v" : ">";
            int arrowColor = hovered || selected ? -791321 : -4743522;
            PackUiText.draw(ctx, this.textRenderer, arrow, this.theme.fontFor(PackUiTone.BODY), arrowColor, clipLeft + 2, rowTextY, false);
            L878: ;
            nameColor = isAnticheat ? -43691 : this.getEvidenceColor(row.evidence, hovered);
            label = isAnticheat ? "! " + plugin : plugin;
            int labelX = clipLeft + 13;
            int labelMaxWidth = Math.max(40, rowContentW - 18);
            if (cmds == null) { /* goto L1100; */ }
            if (cmds.isEmpty()) { /* goto L1100; */ }
            String countStr = cmds.size() + " cmd" + cmds.size() != 1 ? "s" : "";
            int cw = PackUiText.width(this.textRenderer, countStr, this.theme.fontFor(PackUiTone.MUTED), -4743522);
            int countX = clipLeft + rowContentW - cw - 4;
            labelMaxWidth = Math.max(36, countX - labelX - 4);
            int countTextY = PackUiSizing.alignTextY(rowY, this.pluginRowHeight(), this.theme.fontHeight(PackUiTone.MUTED), this.theme.bodyTextNudge());
            if (rowVisible) {
                PackUiText.draw(ctx, this.textRenderer, countStr, this.theme.fontFor(PackUiTone.MUTED), -4743522, countX, countTextY, false);
            }
            displayLabel = PackUiText.trimToWidth(this.textRenderer, label, labelMaxWidth, this.theme.fontFor(PackUiTone.BODY), nameColor);
            if (rowVisible) {
                PackUiText.draw(ctx, this.textRenderer, displayLabel, this.theme.fontFor(PackUiTone.BODY), nameColor, labelX, rowTextY, false);
            }
            clickedPlugin = plugin;
            if (rowVisible && hasCommands) {
                this.clickRegions.add(new PackUtilServerInfoOverlay.ClickRegion(clipLeft, rowTop, rowContentW, rowBottom - rowTop, this::lambda$renderPluginResultsViewport$16 /* captured: clickedPlugin */));
            }
            cy = cy + this.pluginRowHeight();
            if (!selected) { /* goto @1601; */ }
            if (cmds == null) { /* goto @1601; */ }
            if (cmds.isEmpty()) { /* goto @1601; */ }
            clickedPlugin = cmds.iterator();
            while (clickedPlugin.hasNext()) {
                cmd = (String)clickedPlugin.next();
                cmdY = cy;
                String cmdText = "/" + cmd;
                int cmdTop = cmdY;
                int cmdBottom = cmdY + this.pluginDetailRowHeight();
                boolean cmdVisible = cmdTop >= clipTop && cmdBottom <= clipBottom;
                boolean cmdHovered = cmdVisible && uiMouseX >= (float)(clipLeft + 9) && uiMouseX < (float)(clipLeft + rowContentW - 6) && uiMouseY >= (float)cmdTop && uiMouseY < (float)cmdBottom;
                if (cmdHovered) {
                    ctx.method_25294(clipLeft + 5, cmdTop, clipLeft + rowContentW - 4, cmdBottom, 788482634);
                } else {
                    if (!cmdVisible) continue;
                    ctx.method_25294(clipLeft + 5, cmdTop, clipLeft + rowContentW - 4, cmdBottom, 1141508364);
                }
                if (!cmdVisible) continue;
                ctx.method_25294(clipLeft + 5, cmdTop, clipLeft + 6, cmdBottom, -50373);
                int cmdColor = cmdHovered ? -791321 : -1716016;
                int cmdTextY = PackUiSizing.alignTextY(cmdY, this.pluginDetailRowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
                if (!cmdVisible) continue;
                PackUiText.draw(ctx, this.textRenderer, cmdText, this.theme.fontFor(PackUiTone.BODY), cmdColor, clipLeft + 11, cmdTextY, false);
                if (cmdVisible) {
                    String fullCmd = "/" + cmd;
                    this.clickRegions.add(new PackUtilServerInfoOverlay.ClickRegion(clipLeft + 9, cmdTop, Math.max(1, rowContentW - 15), cmdBottom - cmdTop, PackUtilServerInfoOverlay::lambda$renderPluginResultsViewport$17 /* captured: fullCmd */));
                }
                cy = cy + this.pluginDetailRowHeight();
            }
        }
        viewport.disableScissor(ctx);
        /* goto L1622; */
        var var60 = null;
        viewport.disableScissor(ctx);
        throw var60;
        L1622: ;
        viewport.pop(ctx);
        /* goto L1640; */
        var var61 = null;
        viewport.pop(ctx);
        throw var61;
        L1640: ;
        PackUiScrollbar.draw(ctx, scrollbarMetrics, scrollbarMetrics.contains((double)uiMouseX, (double)uiMouseY), this.pluginScrollbarDragging);
    }

    private PackUiScrollbar.Metrics getPluginScrollbarMetrics(int x, int y, int width, int height) {
        int innerHeight = this.getPluginListInnerHeight(height);
        int maxScroll = Math.max(0, this.pluginContentHeight - innerHeight);
        return PackUiScrollbar.compute(this.pluginContentHeight, Math.max(1, innerHeight), x + width - 5, y + 1, 3, Math.max(1, innerHeight), this.quantizeScrollOffset(this.pluginScrollState.tick(0f, maxScroll), this.pluginListRowStep(), maxScroll));
    }

    private String getLiveBrand() {
        if (MC.method_1562() == null) {
            return "--";
        }
        String brand = MC.method_1562().method_52790();
        return brand != null && !brand.isBlank() ? brand : "--";
    }

    private boolean isOverHeaderUi(float uiMouseX, float uiMouseY) {
        return uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.panelW) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
    }

    private boolean isOverCloseButton(float uiMouseX, float uiMouseY) {
        return PackUiHeaderControls.isCloseHit(this.closeVisibility, (double)uiMouseX, (double)uiMouseY, this.closeButtonX(), this.controlButtonY(), this.headerControlSize());
    }

    private int controlButtonY() {
        return PackUiHeaderControls.controlY(this.panelY, this.theme.headerHeight(), this.headerControlSize());
    }

    private int closeButtonX() {
        return PackUiHeaderControls.closeX(this.panelX, this.panelW, this.headerControlSize(), 2);
    }

    private int collapseArrowX() {
        return PackUiHeaderControls.expandedArrowX(this.closeButtonX(), this.headerArrowGap(), this.headerArrowWidth());
    }

    private int panelPadding() {
        return 5;
    }

    private int contentGap() {
        return 3;
    }

    private int searchFieldHeight() {
        return 15;
    }

    private int actionButtonHeight() {
        return 15;
    }

    private int buttonRowGap() {
        return 2;
    }

    private int infoLabelWidth() {
        return 64;
    }

    private int pluginSetupLabelWidth() {
        return 46;
    }

    private int pluginScanLabelWidth() {
        return 40;
    }

    private int pluginSearchWidth() {
        return 128;
    }

    private int pluginSearchReserveWidth() {
        return 28;
    }

    private float pluginViewportMinHeight() {
        return 66f;
    }

    private int sharedPanelWidth() {
        return 204;
    }

    private int pluginSetupWidth() {
        return this.sharedPanelWidth();
    }

    private int pluginScanningWidth() {
        return this.sharedPanelWidth();
    }

    private int infoMinWidth() {
        return this.sharedPanelWidth();
    }

    private int infoMinHeight() {
        return 246;
    }

    private int pluginResultsMinWidth() {
        return this.sharedPanelWidth();
    }

    private int pluginResultsMinHeightPreset() {
        return 266;
    }

    private int pluginSetupHeight() {
        return 120;
    }

    private int pluginScanningHeight() {
        return 92;
    }

    private int viewportHeightMargin() {
        return 24;
    }

    private int pluginHeaderHeight() {
        return this.pluginListRowStep();
    }

    private int pluginRowHeight() {
        return 15;
    }

    private int pluginDetailRowHeight() {
        return this.pluginListRowStep();
    }

    private int pluginDetailPadding() {
        return 0;
    }

    private int headerControlSize() {
        return 12;
    }

    private int headerArrowWidth() {
        return 10;
    }

    private int headerArrowGap() {
        return 3;
    }

    private int rowTextInset() {
        return 3;
    }

    private int pluginListRowStep() {
        return this.pluginRowHeight();
    }

    private int getPluginListViewportHeight(int rawHeight) {
        if (rawHeight <= 0) {
            return 0;
        }
        return Math.min(rawHeight, this.getPluginListInnerHeight(rawHeight) + 2);
    }

    private int getPluginListInnerHeight(int viewHeight) {
        return Math.max(0, this.alignViewportHeight(Math.max(0, viewHeight - 2), this.pluginListRowStep()));
    }

    private PackUtilWindowLayout clampToViewport(PackUtilWindowLayout bounds) {
        PackUiViewport viewport = this.surface.viewport();
        int viewportWidth = Math.round(viewport.uiWidth());
        int viewportHeight = Math.round(viewport.uiHeight());
        int minWidth = Math.min(this.getMinWidth(), viewportWidth);
        int width = Math.max(minWidth, Math.min(bounds.width, viewportWidth));
        int minHeight = bounds.collapsed ? this.theme.headerHeight() : Math.min(this.getMinHeight(), viewportHeight);
        int height = Math.max(minHeight, Math.min(bounds.height, viewportHeight));
        int x = Math.max(0, Math.min(bounds.x, Math.max(0, Math.round(viewport.uiWidth()) - width)));
        int y = Math.max(0, Math.min(bounds.y, Math.max(0, Math.round(viewport.uiHeight()) - this.theme.headerHeight())));
        return new PackUtilWindowLayout(x, y, width, height, bounds.visible, bounds.collapsed);
    }

    private String getSoftwareGuess(class_642 entry) {
        LinkedHashSet<String> guesses = new LinkedHashSet();
        String brand = this.getLiveBrand().toLowerCase(Locale.ROOT);
        if (brand.contains("purpur")) {
            guesses.add("Purpur");
        } else {
            if (brand.contains("pufferfish")) {
                guesses.add("Pufferfish");
            } else {
                if (brand.contains("folia")) {
                    guesses.add("Folia");
                } else {
                    if (brand.contains("paper")) {
                        guesses.add("Paper");
                    } else {
                        if (brand.contains("spigot")) {
                            guesses.add("Spigot");
                        } else {
                            if (brand.contains("craftbukkit")) { /* goto L144; */ }
                            if (brand.contains("bukkit")) {
                                guesses.add("Bukkit");
                            } else {
                                if (brand.contains("waterfall")) {
                                    guesses.add("Waterfall");
                                } else {
                                    if (brand.contains("velocity")) {
                                        guesses.add("Velocity");
                                    } else {
                                        if (brand.contains("bungeecord") || brand.contains("bungee")) {
                                            guesses.add("Bungee");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.detectedPlugins.stream().anyMatch(PackUtilServerInfoOverlay::lambda$getSoftwareGuess$18)) {
            guesses.add("ViaVersion");
        }
        if (this.detectedPlugins.stream().anyMatch(PackUtilServerInfoOverlay::lambda$getSoftwareGuess$19)) {
            guesses.add("Bedrock Bridge");
        }
        return guesses.isEmpty() ? "--" : String.join(" + ", guesses);
    }

    private String getVersionNote(class_642 entry) {
        String brand = this.getLiveBrand();
        String reportedVersion = this.getReportedVersion(entry);
        String brandLower = brand.toLowerCase(Locale.ROOT);
        String versionLower = reportedVersion.toLowerCase(Locale.ROOT);
        if (entry != null && entry.field_3756 == 0) {
            return "Ping Spoof";
        }
        if (!"--".equals(brand)) {
            if (versionLower.contains("paper") || versionLower.contains("spigot") || versionLower.contains("purpur") || versionLower.contains("velocity") || versionLower.contains("bungee")) {
                if (!brandLower.contains("paper") || versionLower.contains("paper")) {
                    if (!brandLower.contains("spigot") || versionLower.contains("spigot")) {
                        if (!brandLower.contains("purpur") || versionLower.contains("purpur")) {
                            if (!brandLower.contains("velocity") || versionLower.contains("velocity")) {
                                if (!brandLower.contains("bungee")) { /* goto @223; */ }
                            }
                        }
                    }
                }
                return "Brand Mismatch";
            }
        }
        if (this.detectedPlugins.stream().anyMatch(PackUtilServerInfoOverlay::lambda$getVersionNote$20)) {
            return "Protocol Bridge";
        }
        return "--";
    }

    private String getDisplayedServerAddress() {
        class_642 entry = MC.method_1558();
        if (entry != null && entry.field_3761 != null && !entry.field_3761.isBlank()) {
            return entry.field_3761.trim();
        }
        if (MC.method_1562() == null) { /* goto L183; */ }
        if (MC.method_1562().method_48296() == null) { /* goto L183; */ }
        SocketAddress address = MC.method_1562().method_48296().method_10755();
        if (address instanceof InetSocketAddress) {
            InetSocketAddress inet = (InetSocketAddress)address;
            String host = inet.getHostString();
            if (host == null || host.isBlank()) {
                if (inet.getAddress() != null) {
                    host = inet.getAddress().getHostAddress();
                }
            }
            if (host != null) {
                if (!host.isBlank()) {
                    return host + ":" + inet.getPort();
                }
            }
        } else {
            if (address != null) {
                String raw = address.toString();
                if (raw != null) {
                    if (!raw.isBlank()) {
                        return raw.replaceFirst("^/", "").trim();
                    }
                }
            }
        }
        return "--";
    }

    private String extractLookupHost(String rawAddress) {
        if (rawAddress == null || rawAddress.isBlank() || "--".equals(rawAddress)) {
            return "";
        }
        String trimmed = rawAddress.trim();
        if (trimmed.startsWith("[") && trimmed.contains("]")) {
            return trimmed.substring(1, trimmed.indexOf(93));
        }
        int colonCount = 0;
        for (int i = 0; i < trimmed.length(); i++) {
            if (trimmed.charAt(i) != 58) continue;
            colonCount++;
        }
        if (colonCount == 1 && trimmed.contains(":")) {
            return trimmed.substring(0, trimmed.lastIndexOf(58));
        }
        return trimmed;
    }

    private String getLiveSocketIp() {
        if (MC.method_1562() == null || MC.method_1562().method_48296() == null) {
            return "";
        }
        SocketAddress address = MC.method_1562().method_48296().method_10755();
        if (!address instanceof InetSocketAddress) { /* goto L80; */ }
        InetSocketAddress inet = (InetSocketAddress)address;
        if (inet.getAddress() == null) { /* goto L80; */ }
        String hostAddress = inet.getAddress().getHostAddress();
        return hostAddress == null ? "" : hostAddress.trim();
        return "";
    }

    private Integer extractPort(String rawAddress) {
        if (rawAddress == null || rawAddress.isBlank() || "--".equals(rawAddress)) {
            return null;
        }
        String trimmed = rawAddress.trim();
        if (trimmed.startsWith("[")) {
            if (trimmed.contains("]")) {
                int closing = trimmed.indexOf(93);
                if (closing >= 0) {
                    if (closing + 1 >= trimmed.length()) { /* goto @99; */ }
                }
            }
        }
        try {
            return Integer.parseInt(trimmed.substring(closing + 2));
        }
        catch (NumberFormatException ignored) {
            return null;
        }
        return null;
        L101: ;
        firstColon = trimmed.indexOf(58);
        lastColon = trimmed.lastIndexOf(58);
        if (firstColon < 0) { /* goto @145; */ }
        try {
            return Integer.parseInt(trimmed.substring(lastColon + 1));
        }
        catch (NumberFormatException ignored) {
            return null;
        }
        return null;
    }

    private String appendPortIfPresent(String host, Integer port) {
        if (host == null || host.isBlank() || port == null) {
            return host;
        }
        if (host.indexOf(58) >= 0 && !host.startsWith("[") && !host.endsWith("]")) {
            return "[" + host + "]:" + port;
        }
        return host + ":" + port;
    }

    private void copyClipboardValue(String value, String successMessage, String unavailableMessage) {
        String trimmed = value == null ? "" : value.trim();
        if (trimmed.isEmpty() || "--".equals(trimmed) || "Resolving...".equalsIgnoreCase(trimmed) || "Failed".equalsIgnoreCase(trimmed)) {
            PackUtilClientMessaging.sendPrefixed(unavailableMessage);
            return;
        }
        MC.field_1774.method_1455(trimmed);
        PackUtilClientMessaging.sendPrefixed(successMessage);
    }

    private void copyResolvedServerIp() {
        String displayedAddress = this.getDisplayedServerAddress();
        String realIp = this.getDisplayedRealIp(displayedAddress);
        String resolvedWithPort = this.appendPortIfPresent(realIp, this.extractPort(displayedAddress));
        this.copyClipboardValue(resolvedWithPort, "Real IP copied.", "Real IP unavailable.");
    }

    private void ensureResolvedIpLookup(String rawAddress) {
        String host = this.extractLookupHost(rawAddress);
        if (host.isEmpty()) {
            return;
        }
        if (!host.equals(this.lastResolvedAddress)) {
            this.resolvedIp = null;
            this.lastResolvedAddress = host;
            this.resolvingIp = false;
        }
        this.resolvingIp = true;
        if (this.resolvedIp == null && !this.resolvingIp) {
            Thread t = new Thread(this::lambda$ensureResolvedIpLookup$21 /* captured: host */, "PackUtil-DNS");
            t.setDaemon(true);
            t.start();
        }
    }

    private String getDisplayedRealIp(String rawAddress) {
        this.ensureResolvedIpLookup(rawAddress);
        String socketIp = this.getLiveSocketIp();
        if (!socketIp.isBlank()) {
            return socketIp;
        }
        if (this.resolvedIp != null) {
            return this.resolvedIp;
        }
        if (this.resolvingIp) {
            return "Resolving...";
        }
        return "--";
    }

    private List<String> getDetectedAnticheats() {
        return (List)this.detectedPlugins.stream().filter(Objects::nonNull).filter(PackUtilServerInfoOverlay::lambda$getDetectedAnticheats$22).sorted(String.CASE_INSENSITIVE_ORDER).collect(Collectors.toList());
    }

    private String getCurrentWorldName() {
        if (MC.field_1687 == null) {
            return "--";
        }
        class_2960 worldId = MC.field_1687.method_27983().method_29177();
        if (worldId == null) {
            return "--";
        }
        String namespace = worldId.method_12836();
        String path = worldId.method_12832();
        if (!"minecraft".equals(namespace)) { /* goto L196; */ }
        var var4 = path;
        int var5 = -1;
        switch (var4.hashCode()) {
            case -745159874::
                if (!var4.equals("overworld")) { /* goto @148; */ }
                var5 = 0;
                /* goto @148; */
            case 1272296422::
                if (!var4.equals("the_nether")) { /* goto @148; */ }
                var5 = 1;
                /* goto @148; */
            case -1350117363::
                if (var4.equals("the_end")) {
                    var5 = 2;
                }
            default:
                switch (var5) {
                    case 0::
                        return "Overworld";
                    case 1::
                        return "The Nether";
                    case 2::
                        return "The End";
                    default:
                        return path;
                }
                return namespace + ":" + path;
        }
    }

    private List<PackUtilServerInfoOverlay.PluginListRow> buildPluginRows(List<String> filteredPlugins) {
        Map<PackUtilServerInfoOverlay.PluginEvidence, List<String>> grouped = new LinkedHashMap();
        List<PackUtilServerInfoOverlay.PluginListRow> rows = List.of(PackUtilServerInfoOverlay.PluginEvidence.COMMAND_TREE, PackUtilServerInfoOverlay.PluginEvidence.NAMESPACE, PackUtilServerInfoOverlay.PluginEvidence.ROOT_HINT, PackUtilServerInfoOverlay.PluginEvidence.HELP_HINT, PackUtilServerInfoOverlay.PluginEvidence.PLUGIN_LIST, PackUtilServerInfoOverlay.PluginEvidence.VERSION_HINT, PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN).iterator();
        while (rows.hasNext()) {
            PluginEvidence evidence = (PackUtilServerInfoOverlay.PluginEvidence)rows.next();
            grouped.put(evidence, new ArrayList());
        }
        rows = filteredPlugins.iterator();
        while (rows.hasNext()) {
            plugin = (String)rows.next();
            PluginEvidence evidence = (PackUtilServerInfoOverlay.PluginEvidence)this.pluginEvidence.getOrDefault(this.normalizePluginKey(plugin), ((List)this.pluginCommands.getOrDefault(plugin, List.of())).isEmpty() ? PackUtilServerInfoOverlay.PluginEvidence.UNKNOWN : PackUtilServerInfoOverlay.PluginEvidence.ROOT_HINT);
            ((List)grouped.get(evidence)).add(plugin);
        }
        rows = new ArrayList();
        plugin = grouped.entrySet().iterator();
        while (plugin.hasNext()) {
            group = (Map.Entry)plugin.next();
            while (((List)group.getValue()).isEmpty()) {
            }
            ((List)group.getValue()).sort(String.CASE_INSENSITIVE_ORDER);
            rows.add(PackUtilServerInfoOverlay.PluginListRow.header(this.getEvidenceTitle((PackUtilServerInfoOverlay.PluginEvidence)group.getKey())));
            var var6 = ((List)group.getValue()).iterator();
            while (var6.hasNext()) {
                String plugin = (String)var6.next();
                rows.add(PackUtilServerInfoOverlay.PluginListRow.plugin(plugin, (PackUtilServerInfoOverlay.PluginEvidence)group.getKey()));
            }
        }
        return rows;
    }

    private int estimatePluginContentHeight(List<PackUtilServerInfoOverlay.PluginListRow> rows) {
        int total = 0;
        var var3 = rows.iterator();
        while (var3.hasNext()) {
            PluginListRow row = (PackUtilServerInfoOverlay.PluginListRow)var3.next();
            total = total + (row.header ? this.pluginHeaderHeight() : this.pluginRowHeight());
            if (!row.header) {
                if (row.plugin != null) {
                    if (row.plugin.equals(this.selectedPlugin)) {
                        List<String> cmds = (List)this.pluginCommands.get(row.plugin);
                        if (cmds != null) {
                            if (cmds.isEmpty()) continue;
                            total = total + (cmds.size() * this.pluginDetailRowHeight() + this.pluginDetailPadding());
                        }
                    }
                }
            }
        }
        return total;
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mx);
        float uiMouseY = viewport.toUiY(my);
        if (this.isOverCloseButton(uiMouseX, uiMouseY)) {
            this.setVisible(false);
            this.isDragging = false;
            this.dragMoved = false;
            return true;
        }
        this.isDragging = true;
        if (button == 0 && this.isOverHeaderUi(uiMouseX, uiMouseY)) {
            this.dragMoved = false;
            this.dragOffsetX = (double)(uiMouseX - (float)this.panelX);
            this.dragOffsetY = (double)(uiMouseY - (float)this.panelY);
            this.pressStartUiX = uiMouseX;
            this.pressStartUiY = uiMouseY;
            this.pressStartPanelX = this.panelX;
            this.pressStartPanelY = this.panelY;
            return true;
        }
        if (this.collapsed) {
            return false;
        }
        if (button != 0) {
            return this.isMouseOver(mx, my);
        }
        if (this.activeTab == 1) {
            if (this.pluginScanDone) {
                if (!this.pluginScanInProgress) {
                    Metrics scrollbarMetrics = this.getPluginScrollbarMetrics(Math.round(this.pluginListSlot.x()), Math.round(this.pluginListSlot.y()), Math.round(this.pluginListSlot.width()), this.getPluginListViewportHeight(Math.max(0, Math.min(Math.round(this.pluginListSlot.height()), this.panelY + this.panelH - 10 - Math.round(this.pluginListSlot.y())))));
                    if (scrollbarMetrics.hasScroll()) {
                        if (scrollbarMetrics.contains((double)uiMouseX, (double)uiMouseY)) {
                            this.pluginScrollbarDragging = true;
                            this.pluginScrollbarGrabOffset = Math.max(0, Math.round(uiMouseY) - scrollbarMetrics.thumbY());
                            this.pluginScrollState.setFromThumbStepped(scrollbarMetrics, (double)Math.round(uiMouseY), this.pluginScrollbarGrabOffset, this.pluginListRowStep());
                            this.saveState();
                            return true;
                        }
                    }
                }
            }
        }
        if (this.surface.mouseClicked(mx, my, button)) {
            return true;
        }
        this.surface.clearFocusedTextInputs();
        scrollbarMetrics = this.clickRegions.iterator();
        while (scrollbarMetrics.hasNext()) {
            ClickRegion region = (PackUtilServerInfoOverlay.ClickRegion)scrollbarMetrics.next();
            if (region.contains((double)uiMouseX, (double)uiMouseY)) {
                region.action.run();
                return true;
            }
        }
        return this.isMouseOver(mx, my);
    }

    public boolean mouseReleased(double mx, double my, int button) {
        this.pluginScrollbarDragging = false;
        if (button == 0 && this.pluginScrollbarDragging) {
            this.saveState();
            return true;
        }
        if (this.isDragging) { /* goto L37; */ }
        if (!this.isResizing) { /* goto L148; */ }
        L37: ;
        boolean shouldCollapse = this.isDragging && !this.dragMoved;
        this.isDragging = false;
        this.isResizing = false;
        if (!shouldCollapse) { /* goto L142; */ }
        this.collapsed = !this.collapsed;
        if (this.collapsed) { /* goto L142; */ }
        if (this.activeTab == 0) {
            this.applyInfoLayout();
        } else {
            if (this.pluginScanInProgress) {
                this.applyPluginScanningLayout();
            } else {
                if (!this.pluginScanDone) {
                    this.applyPluginSetupLayout();
                } else {
                    this.applyPluginResultsLayout();
                }
            }
        }
        this.saveState();
        return true;
        L148: ;
        return this.surface.mouseReleased(mx, my, button);
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        PackUiViewport viewport = this.surface.viewport();
        if (this.pluginScrollbarDragging && button == 0) {
            float uiMouseY = viewport.toUiY(my);
            Metrics scrollbarMetrics = this.getPluginScrollbarMetrics(Math.round(this.pluginListSlot.x()), Math.round(this.pluginListSlot.y()), Math.round(this.pluginListSlot.width()), this.getPluginListViewportHeight(Math.max(0, Math.min(Math.round(this.pluginListSlot.height()), this.panelY + this.panelH - 10 - Math.round(this.pluginListSlot.y())))));
            this.pluginScrollState.setFromThumbStepped(scrollbarMetrics, (double)Math.round(uiMouseY), this.pluginScrollbarGrabOffset, this.pluginListRowStep());
            return true;
        }
        if (!this.isDragging) { /* goto L307; */ }
        viewport = this.surface.viewport();
        uiMouseX = viewport.toUiX(mx);
        uiMouseY = viewport.toUiY(my);
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(Math.round(uiMouseX - (float)this.dragOffsetX), Math.round(uiMouseY - (float)this.dragOffsetY), this.panelW, this.panelH, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        if (this.dragMoved) { /* goto L297; */ }
        if (Math.abs(uiMouseX - this.pressStartUiX) >= 3f) { /* goto L297; */ }
        if (Math.abs(uiMouseY - this.pressStartUiY) >= 3f) { /* goto L297; */ }
        if (this.panelX != this.pressStartPanelX) { /* goto L297; */ }
        this.dragMoved = this.panelY != this.pressStartPanelY;
        return true;
        if (this.isResizing) {
            viewport = this.surface.viewport();
            uiMouseX = viewport.toUiX(mx);
            uiMouseY = viewport.toUiY(my);
            this.panelW = Math.max(this.getMinWidth(), this.resizeStartW + Math.round(uiMouseX - (float)this.resizeStartMouseX));
            this.panelH = Math.max(this.getMinHeight(), this.resizeStartH + Math.round(uiMouseY - (float)this.resizeStartMouseY));
            this.rememberCurrentTabSize();
            return true;
        }
        return this.surface.mouseDragged(mx, my, button, dx, dy);
    }

    public boolean mouseScrolled(double mx, double my, double amount) {
        if (!this.visible || this.collapsed || !this.isMouseOver(mx, my)) {
            return false;
        }
        int slotY = Math.round(this.pluginListSlot.y());
        if (this.activeTab == 1 && this.pluginScanDone && !this.pluginScanInProgress) {
            int slotH = Math.round(this.pluginListSlot.height());
            int rawViewH = Math.max(0, Math.min(slotH, this.panelY + this.panelH - 10 - slotY));
            int viewH = this.getPluginListViewportHeight(rawViewH);
            int maxScroll = Math.max(0, this.pluginContentHeight - this.getPluginListInnerHeight(viewH));
            this.pluginScrollState.nudge(amount, (float)this.pluginListRowStep(), maxScroll);
            return true;
        }
        return this.surface.mouseScrolled(mx, my, amount);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return this.visible && this.surface.keyPressed(keyCode, scanCode, modifiers);
    }

    public boolean charTyped(char chr, int modifiers) {
        return this.visible && this.surface.charTyped(chr, modifiers);
    }

    private void copyServerInfo() {
        StringBuilder sb = new StringBuilder();
        class_642 entry = MC.method_1558();
        String ip = this.getDisplayedServerAddress();
        String realIp = this.getDisplayedRealIp(ip);
        List<String> detectedAcs = this.getDetectedAnticheats();
        String software = this.getSoftwareGuess(entry);
        String versionNote = this.getVersionNote(entry);
        sb.append("=== Server Info ===\n");
        sb.append("IP:         ").append(ip).append("\n");
        if (!realIp.equals("--")) {
            sb.append("Real IP:    ").append(realIp).append("\n");
        }
        sb.append("Version:    ").append(this.getReportedVersion(entry)).append("\n");
        sb.append("Brand:      ").append(this.getLiveBrand()).append("\n");
        if (!"--".equals(software)) {
            sb.append("Software:   ").append(software).append("\n");
        }
        sb.append("Ping:       ").append(entry != null ? entry.field_3758 + " ms" : "--").append("\n");
        if (MC.method_1562() != null) {
            sb.append("Players:    ").append(MC.method_1562().method_2880().size());
            if (entry != null) {
                if (entry.field_41861 != null) {
                    sb.append(" / ").append(entry.field_41861.comp_1279());
                }
            }
            sb.append("\n");
        } else {
            sb.append("Players:    --\n");
        }
        sb.append("Protocol:   ").append(entry != null ? entry.field_3756 : "--").append("\n");
        if (!"--".equals(versionNote)) {
            sb.append("VersionNote: ").append(versionNote).append("\n");
        }
        sb.append("Difficulty: ").append(MC.field_1687 != null ? MC.field_1687.method_8407().method_5460() : "--").append("\n");
        sb.append("World:      ").append(this.getCurrentWorldName()).append("\n");
        if (MC.field_1687 != null) {
            long dayCount = MC.field_1687.method_8532() / 24000L;
            long timeOfDay = MC.field_1687.method_8532() % 24000L;
            int hours = (int)((timeOfDay / 1000L + 6L) % 24L);
            int minutes = (int)(timeOfDay % 1000L * 60L / 1000L);
            sb.append("Time:       Day ").append(dayCount).append(" (").append(String.format("%02d:%02d", hours, minutes)).append(")\n");
        } else {
            sb.append("Time:       --\n");
        }
        double tps = PackUtilSharedState.get().getEstimatedTps();
        sb.append("TPS:        ").append(tps > 0 ? String.format("%.1f", Math.min(20, tps)) : "--").append("\n");
        if (this.pluginScanInProgress) {
            sb.append("AntiCheats: Scanning...\n");
        } else {
            if (!this.pluginScanDone) {
                sb.append("AntiCheats: Probe Plugins First\n");
            } else {
                if (detectedAcs.isEmpty()) {
                    sb.append("AntiCheats: None detected\n");
                } else {
                    sb.append("AntiCheats: ").append(String.join(", ", detectedAcs)).append("\n");
                }
            }
        }
        MC.field_1774.method_1455(sb.toString());
        PackUtilClientMessaging.sendPrefixed("Server info copied to clipboard.");
    }

    private void copyPluginList() {
        if (this.detectedPlugins.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("No plugins detected.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Plugins (").append(this.detectedPlugins.size()).append("):\n");
        List<PackUtilServerInfoOverlay.PluginListRow> rows = this.buildPluginRows(new ArrayList(this.detectedPlugins));
        var var3 = rows.iterator();
        while (var3.hasNext()) {
            PluginListRow row = (PackUtilServerInfoOverlay.PluginListRow)var3.next();
            while (row.header) {
                sb.append("\n[").append(row.title).append("]\n");
            }
            boolean ac = ANTICHEATS.contains(row.plugin.toLowerCase(Locale.ROOT));
            List<String> commands = (List)this.pluginCommands.getOrDefault(row.plugin, List.of());
            sb.append(ac ? "[AC] " : "- ").append(row.plugin);
            if (commands.isEmpty()) continue;
            sb.append(" (").append(commands.size()).append(" cmds)");
            sb.append("\n");
        }
        MC.field_1774.method_1455(sb.toString());
        PackUtilClientMessaging.sendPrefixed("Plugin list copied to clipboard.");
    }

    static {
        String[] tmp0 = new String[2];
        tmp0[0] = "Info";
        tmp0[1] = "Plugins";
        TAB_NAMES = tmp0;
        String[] tmp1 = new String[41];
        tmp1[0] = "essentials";
        tmp1[1] = "essentialsx";
        tmp1[2] = "worldedit";
        tmp1[3] = "worldguard";
        tmp1[4] = "luckperms";
        tmp1[5] = "vault";
        tmp1[6] = "citizens";
        tmp1[7] = "cmi";
        tmp1[8] = "cmilib";
        tmp1[9] = "multiverse-core";
        tmp1[10] = "multiverse";
        tmp1[11] = "viaversion";
        tmp1[12] = "viabackwards";
        tmp1[13] = "viarewind";
        tmp1[14] = "geysermc";
        tmp1[15] = "geyser";
        tmp1[16] = "floodgate";
        tmp1[17] = "protocollib";
        tmp1[18] = "coreprotect";
        tmp1[19] = "griefprevention";
        tmp1[20] = "shopkeepers";
        tmp1[21] = "dynmap";
        tmp1[22] = "placeholderapi";
        tmp1[23] = "skinsrestorer";
        tmp1[24] = "skript";
        tmp1[25] = "advancedanticheat";
        tmp1[26] = "vulcan";
        tmp1[27] = "grimac";
        tmp1[28] = "matrix";
        tmp1[29] = "spartan";
        tmp1[30] = "aac";
        tmp1[31] = "karhu";
        tmp1[32] = "verus";
        tmp1[33] = "nocheatplus";
        tmp1[34] = "authme";
        tmp1[35] = "deluxemenus";
        tmp1[36] = "plotsquared";
        tmp1[37] = "supervanish";
        tmp1[38] = "packetevents";
        tmp1[39] = "oraxen";
        tmp1[40] = "itemsadder";
        COMMON_PLUGIN_NAMESPACES = tmp1;
        String[] tmp2 = new String[4];
        tmp2[0] = "/plugins ";
        tmp2[1] = "/pl ";
        tmp2[2] = "/bukkit:plugins ";
        tmp2[3] = "/bukkit:pl ";
        PLUGIN_LIST_PROBE_COMMANDS = tmp2;
        String[] tmp3 = new String[6];
        tmp3[0] = "/ver ";
        tmp3[1] = "/version ";
        tmp3[2] = "/about ";
        tmp3[3] = "/icanhasbukkit ";
        tmp3[4] = "/bukkit:ver ";
        tmp3[5] = "/bukkit:version ";
        VERSION_PROBE_COMMANDS = tmp3;
        String[] tmp4 = new String[4];
        tmp4[0] = "/help ";
        tmp4[1] = "/? ";
        tmp4[2] = "/bukkit:help ";
        tmp4[3] = "/minecraft:help ";
        HELP_PROBE_COMMANDS = tmp4;
        Map.Entry[] tmp5 = new Map.Entry[17];
        tmp5[0] = Map.entry("lp", "luckperms");
        tmp5[1] = Map.entry("we", "worldedit");
        tmp5[2] = Map.entry("rg", "worldguard");
        tmp5[3] = Map.entry("mv", "multiverse-core");
        tmp5[4] = Map.entry("npc", "citizens");
        tmp5[5] = Map.entry("papi", "placeholderapi");
        tmp5[6] = Map.entry("cmi", "cmi");
        tmp5[7] = Map.entry("co", "coreprotect");
        tmp5[8] = Map.entry("grim", "grimac");
        tmp5[9] = Map.entry("geyser", "geysermc");
        tmp5[10] = Map.entry("floodgate", "floodgate");
        tmp5[11] = Map.entry("viaver", "viaversion");
        tmp5[12] = Map.entry("sr", "skinsrestorer");
        tmp5[13] = Map.entry("authme", "authme");
        tmp5[14] = Map.entry("dm", "deluxemenus");
        tmp5[15] = Map.entry("plots", "plotsquared");
        tmp5[16] = Map.entry("sv", "supervanish");
        ROOT_COMMAND_PLUGIN_ALIASES = Map.ofEntries(tmp5);
        String[] tmp6 = new String[22];
        tmp6[0] = "nocheatplus";
        tmp6[1] = "aac";
        tmp6[2] = "spartan";
        tmp6[3] = "matrix";
        tmp6[4] = "vulcan";
        tmp6[5] = "grim";
        tmp6[6] = "grimac";
        tmp6[7] = "intave";
        tmp6[8] = "karhu";
        tmp6[9] = "verus";
        tmp6[10] = "polar";
        tmp6[11] = "negativity";
        tmp6[12] = "themis";
        tmp6[13] = "fairfight";
        tmp6[14] = "wraith";
        tmp6[15] = "horizon";
        tmp6[16] = "reflex";
        tmp6[17] = "antiaura";
        tmp6[18] = "guardian";
        tmp6[19] = "hac";
        tmp6[20] = "thotpatrol";
        tmp6[21] = "alice";
        ANTICHEATS = Set.of(tmp6);
        VANILLA_NAMESPACES = Set.of("minecraft", "brigadier", "bukkit", "spigot", "paper", "purpur", "velocity", "bungeecord", "waterfall");
    }
}
