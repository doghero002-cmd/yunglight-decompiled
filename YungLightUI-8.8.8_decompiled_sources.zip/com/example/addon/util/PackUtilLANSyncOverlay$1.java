/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilLANSync;

static class PackUtilLANSyncOverlay.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState;

    static {
        $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState = new int[PackUtilLANSync.SyncState.values().length];
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.IDLE.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.PREPARING.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.PREPARING.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.ALL_READY.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.ALL_READY.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.DISPATCHING_GO.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.DISPATCHING_GO.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.EXECUTING.ordinal()] = 5;
            /* goto @84; */
        }
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.EXECUTING.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.REPORTING.ordinal()] = 6;
            /* goto @100; */
        }
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.REPORTING.ordinal()] = 6;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.DONE.ordinal()] = 7;
            /* goto L116; */
            var0 = null;
            L116: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$PackUtilLANSync$SyncState[PackUtilLANSync.SyncState.DONE.ordinal()] = 7;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
