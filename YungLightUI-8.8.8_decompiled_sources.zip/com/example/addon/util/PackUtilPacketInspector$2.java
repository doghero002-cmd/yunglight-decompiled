/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_2846;

static class PackUtilPacketInspector.2 {
    static final /* synthetic */ int[] $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action;

    static {
        $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action = new int[class_2846.class_2847.values().length];
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12968.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12971.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12971.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12973.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12973.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12970.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12970.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12975.ordinal()] = 5;
            /* goto @84; */
        }
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12975.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12974.ordinal()] = 6;
            /* goto @100; */
        }
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12974.ordinal()] = 6;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12969.ordinal()] = 7;
            /* goto L116; */
            var0 = null;
            L116: ;
            return;
        }
        try {
            $SwitchMap$net$minecraft$network$packet$c2s$play$PlayerActionC2SPacket$Action[class_2846.class_2847.field_12969.ordinal()] = 7;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
