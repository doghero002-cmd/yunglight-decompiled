/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilPacketInspectOverlay.FooterAction {
    public static final PackUtilPacketInspectOverlay.FooterAction WAIT = new PackUtilPacketInspectOverlay.FooterAction("WAIT", 0, "Wait");
    public static final PackUtilPacketInspectOverlay.FooterAction SEND = new PackUtilPacketInspectOverlay.FooterAction("SEND", 1, "Send");
    public static final PackUtilPacketInspectOverlay.FooterAction QUEUE = new PackUtilPacketInspectOverlay.FooterAction("QUEUE", 2, "Queue");
    public static final PackUtilPacketInspectOverlay.FooterAction COPY = new PackUtilPacketInspectOverlay.FooterAction("COPY", 3, "Copy");
    private final String label;
    private static final /* synthetic */ PackUtilPacketInspectOverlay.FooterAction[] $VALUES;

    public static PackUtilPacketInspectOverlay.FooterAction[] values() {
        return (PackUtilPacketInspectOverlay.FooterAction[])$VALUES.clone();
    }

    public static PackUtilPacketInspectOverlay.FooterAction valueOf(String name) {
        return (PackUtilPacketInspectOverlay.FooterAction)Enum.valueOf(PackUtilPacketInspectOverlay.FooterAction.class, name);
    }

    private PackUtilPacketInspectOverlay.FooterAction(String var1) {
        super(var1, var2);
        this.label = label;
    }

    static {
        $VALUES = PackUtilPacketInspectOverlay.FooterAction.$values();
    }
}
