/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_2596;

public static class PackUtilSharedState.QueuedPacket {
    private static final AtomicInteger ID_COUNTER = new AtomicInteger(1);
    public final class_2596<?> packet;
    public final int id;
    private volatile int delay;
    private volatile boolean sent;

    public PackUtilSharedState.QueuedPacket(class_2596<?> packet, int delay) {
        this.packet = packet;
        this.id = ID_COUNTER.getAndIncrement();
        this.delay = delay;
        this.sent = false;
    }

    public PackUtilSharedState.QueuedPacket(class_2596<?> packet, int delay, int existingId) {
        this.packet = packet;
        this.id = existingId;
        this.delay = delay;
        this.sent = false;
    }

    public int getId() {
        return this.id;
    }

    public int getDelay() {
        return this.delay;
    }

    public synchronized void setDelay(int newDelay) {
        if (!this.sent) {
            this.delay = newDelay;
        }
    }

    public boolean isSent() {
        return this.sent;
    }

    synchronized void markAsSent() {
        this.sent = true;
    }

    public static void resetIdCounter() {
        ID_COUNTER.set(1);
    }
}
