/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilPacketLoggerOverlay.Category {
    public static final PackUtilPacketLoggerOverlay.Category ALL = new PackUtilPacketLoggerOverlay.Category("ALL", 0, "All");
    public static final PackUtilPacketLoggerOverlay.Category INVENTORY = new PackUtilPacketLoggerOverlay.Category("INVENTORY", 1, "INV");
    public static final PackUtilPacketLoggerOverlay.Category MOVEMENT = new PackUtilPacketLoggerOverlay.Category("MOVEMENT", 2, "Move");
    public final String label;
    private static final /* synthetic */ PackUtilPacketLoggerOverlay.Category[] $VALUES;

    public static PackUtilPacketLoggerOverlay.Category[] values() {
        return (PackUtilPacketLoggerOverlay.Category[])$VALUES.clone();
    }

    public static PackUtilPacketLoggerOverlay.Category valueOf(String name) {
        return (PackUtilPacketLoggerOverlay.Category)Enum.valueOf(PackUtilPacketLoggerOverlay.Category.class, name);
    }

    private PackUtilPacketLoggerOverlay.Category(String var1) {
        super(var1, var2);
        this.label = l;
    }

    static {
        $VALUES = PackUtilPacketLoggerOverlay.Category.$values();
    }
}
