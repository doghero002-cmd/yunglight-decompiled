/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.PackUtilColors;
import net.minecraft.class_327;

private static final record PackUtilPacketInspectOverlay.WrappedInspectionLine {
    private final String prefixText;
    private final int prefixColor;
    private final String valueText;
    private final int valueColor;
    private final int valueOffset;

    private PackUtilPacketInspectOverlay.WrappedInspectionLine(String prefixText, int prefixColor, String valueText, int valueColor, int valueOffset) {
        this.prefixText = prefixText;
        this.prefixColor = prefixColor;
        this.valueText = valueText;
        this.valueColor = valueColor;
        this.valueOffset = valueOffset;
    }

    static PackUtilPacketInspectOverlay.WrappedInspectionLine plain(String text, int offset, int color) {
        return new PackUtilPacketInspectOverlay.WrappedInspectionLine(null, color, text, color, offset);
    }

    int renderedWidth(class_327 textRenderer) {
        int width = this.valueOffset + PackUiText.width(textRenderer, this.valueText, new PackUiTheme().fontFor(PackUiTone.BODY), PackUtilColors.packetWhite());
        if (this.prefixText != null) {
            if (!this.prefixText.isEmpty()) {
                width = Math.max(width, PackUiText.width(textRenderer, this.prefixText, new PackUiTheme().fontFor(PackUiTone.BODY), PackUtilColors.packetWhite()));
            }
        }
        return width;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String prefixText() {
        return this.prefixText;
    }

    public int prefixColor() {
        return this.prefixColor;
    }

    public String valueText() {
        return this.valueText;
    }

    public int valueColor() {
        return this.valueColor;
    }

    public int valueOffset() {
        return this.valueOffset;
    }
}
