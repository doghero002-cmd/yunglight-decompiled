/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static enum PackUtilMacroListOverlay.ItemType {
    public static final PackUtilMacroListOverlay.ItemType SECTION_HEADER = new PackUtilMacroListOverlay.ItemType("SECTION_HEADER", 0);
    public static final PackUtilMacroListOverlay.ItemType LOCAL_MACRO = new PackUtilMacroListOverlay.ItemType("LOCAL_MACRO", 1);
    public static final PackUtilMacroListOverlay.ItemType REMOTE_MACRO = new PackUtilMacroListOverlay.ItemType("REMOTE_MACRO", 2);
    public static final PackUtilMacroListOverlay.ItemType METEOR_MACRO = new PackUtilMacroListOverlay.ItemType("METEOR_MACRO", 3);
    private static final /* synthetic */ PackUtilMacroListOverlay.ItemType[] $VALUES;

    public static PackUtilMacroListOverlay.ItemType[] values() {
        return (PackUtilMacroListOverlay.ItemType[])$VALUES.clone();
    }

    public static PackUtilMacroListOverlay.ItemType valueOf(String name) {
        return (PackUtilMacroListOverlay.ItemType)Enum.valueOf(PackUtilMacroListOverlay.ItemType.class, name);
    }

    private PackUtilMacroListOverlay.ItemType() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilMacroListOverlay.ItemType.$values();
    }
}
