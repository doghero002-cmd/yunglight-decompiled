/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilCraftingHelper.CraftSource {
    public static final PackUtilCraftingHelper.CraftSource PLAYER_2X2 = new PackUtilCraftingHelper.CraftSource("PLAYER_2X2", 0);
    public static final PackUtilCraftingHelper.CraftSource TABLE_3X3 = new PackUtilCraftingHelper.CraftSource("TABLE_3X3", 1);
    private static final /* synthetic */ PackUtilCraftingHelper.CraftSource[] $VALUES;

    public static PackUtilCraftingHelper.CraftSource[] values() {
        return (PackUtilCraftingHelper.CraftSource[])$VALUES.clone();
    }

    public static PackUtilCraftingHelper.CraftSource valueOf(String name) {
        return (PackUtilCraftingHelper.CraftSource)Enum.valueOf(PackUtilCraftingHelper.CraftSource.class, name);
    }

    private PackUtilCraftingHelper.CraftSource() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilCraftingHelper.CraftSource.$values();
    }
}
