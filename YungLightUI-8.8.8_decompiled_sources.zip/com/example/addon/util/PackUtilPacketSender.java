/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_2596;
import net.minecraft.class_310;

public class PackUtilPacketSender {
    public static void sendPacket(class_2596<?> packet) {
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_52787(packet);
    }

    public static void sendPacketDirect(class_2596<?> packet) {
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_52787(packet);
    }
}
