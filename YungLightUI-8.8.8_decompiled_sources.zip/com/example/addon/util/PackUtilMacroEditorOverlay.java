/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.macro.editor.ActionEditorOverlay;
import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiBannerRenderer;
import com.example.addon.gui.packui.PackUiButtonFeedback;
import com.example.addon.gui.packui.PackUiControlGlyphs;
import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSurface;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.gui.packui.PackUiViewportSlot;
import com.example.addon.gui.packui.PackUiWindowNode;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilChatField;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroListOverlay;
import com.example.addon.util.PackUtilMacroManager;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.macro.DelayPacketsAction;
import com.example.addon.util.macro.InventoryAction;
import com.example.addon.util.macro.InventoryAuditAction;
import com.example.addon.util.macro.LookAtBlockAction;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroExecutor;
import com.example.addon.util.macro.OpenContainerAction;
import com.example.addon.util.macro.RevisionSyncAction;
import com.example.addon.util.macro.RotateAction;
import com.example.addon.util.macro.ServerTickSyncAction;
import com.example.addon.util.macro.TickSyncAction;
import com.example.addon.util.macro.WaitForBlockAction;
import com.example.addon.util.macro.WaitForChatAction;
import com.example.addon.util.macro.WaitForCooldownAction;
import com.example.addon.util.macro.WaitForEntityAction;
import com.example.addon.util.macro.WaitForGuiAction;
import com.example.addon.util.macro.WaitForHealthAction;
import com.example.addon.util.macro.WaitForPacketAction;
import com.example.addon.util.macro.WaitForSlotChangeAction;
import com.example.addon.util.macro.WaitForSoundAction;
import com.example.addon.util.macro.WaitPosAction;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_1735;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_640;
import org.lwjgl.glfw.GLFW;

public class PackUtilMacroEditorOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static PackUtilMacroEditorOverlay sharedOverlay;
    private static final int DEFAULT_PANEL_WIDTH = 252;
    private static final int HISTORY_LIMIT = 30;
    private static final int PACKUI_HEADER_CONTROL = 12;
    private static final int PACKUI_HEADER_ARROW_WIDTH = 10;
    private static final int PACKUI_HEADER_ARROW_GAP = 3;
    private static final float HEADER_CLICK_DRAG_THRESHOLD = 3f;
    private static final int STEP_ROW_CONTROL_SIZE = 12;
    private static final int STEP_ROW_CONTROL_GAP = 4;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiWindowNode windowNode = new PackUiWindowNode("Macro Editor");
    private final PackUiSurface surface = new PackUiSurface(this.theme, this.windowNode);
    private final PackUiViewportSlot shellBody = new PackUiViewportSlot();
    private boolean visible = false;
    private PackUtilMacro macro;
    private boolean isNew = false;
    private boolean reopenMacroListOnClose = false;
    private int panelX;
    private int panelY;
    private int PANEL_WIDTH = 258;
    private int PANEL_HEIGHT = 308;
    private List<String> btnLabels = new ArrayList();
    private List<int[]> btnBounds = new ArrayList();
    private List<Runnable> btnActions = new ArrayList();
    private List<Boolean> btnEnabled = new ArrayList();
    private int runBtnIndex = -1;
    private PackUtilChatField nameField;
    private PackUtilChatField loopCountField;
    private boolean isBindingKey = false;
    private int loopMode = 0;
    private int scrollOffset = 0;
    private static final int ACTION_HEIGHT = 18;
    private static final float STEP_DRAG_THRESHOLD = 3f;
    private static final int STEP_DRAG_AUTO_SCROLL_EDGE = 18;
    private static final int STEP_DRAG_AUTO_SCROLL_MAX_SPEED = 12;
    private int draggingIndex = -1;
    private int pressedStepIndex = -1;
    private int stepDragTargetIndex = -1;
    private int stepDragGrabOffsetY = 0;
    private int stepDragMouseY = 0;
    private double stepPressMouseX = 0;
    private double stepPressMouseY = 0;
    private boolean isWindowDragging = false;
    private boolean isWindowResizing = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    private double headerPressMouseX = 0;
    private double headerPressMouseY = 0;
    private int headerPressPanelX = 0;
    private int headerPressPanelY = 0;
    private boolean headerDragMoved = false;
    private double resizeStartMouseX = 0;
    private double resizeStartMouseY = 0;
    private int resizeStartWidth = 0;
    private int resizeStartHeight = 0;
    private float closeHover = 0f;
    private float closeVisibility = 1f;
    private boolean collapsed = false;
    private static final int MOD_LIST_ROWS = 8;
    private static final int MOD_LIST_ROW_H = 14;
    private String lastModuleSearch = "";
    private List<String> entityRegistryCache = null;
    private PackUtilMacroEditorOverlay.StepPickerMode stepPickerMode = null;
    private List<PackUtilMacroEditorOverlay.StepPickerCategory> stepPickerCategories = Collections.emptyList();
    private List<PackUtilMacroEditorOverlay.StepPickerEntry> stepPickerEntries = Collections.emptyList();
    private int stepPickerScrollOffset = 0;
    private int activeScrollbarDrag = 0;
    private int scrollbarGrabOffset = 0;
    private static final int SCROLLBAR_NONE = 0;
    private static final int SCROLLBAR_STEP_LIST = 1;
    private static final int SCROLLBAR_STEP_PICKER = 2;
    private static final float STEP_ROW_ENTER_SECONDS = 0.14f;
    private static final float STEP_ROW_MOVE_SECONDS = 0.14f;
    private static final float STEP_ROW_EXIT_SECONDS = 0.12f;
    private static final int STEP_ROW_ENTER_OFFSET = 18;
    private static final int STEP_ROW_EXIT_OFFSET = 20;
    private String hoveredTooltip = null;
    private int tooltipX;
    private int tooltipY;
    private final Deque<class_2487> undoHistory = new ArrayDeque();
    private final Deque<class_2487> redoHistory = new ArrayDeque();
    private PackUtilMacro originalMacro;
    private boolean tempSavedForRun = false;
    private class_2487 originalMacroSnapshot = null;
    private boolean saveBtnDirty = false;
    private final IdentityHashMap<MacroAction, Integer> stepRowStableIds = new IdentityHashMap();
    private final List<PackUtilMacroEditorOverlay.StepRowSnapshot> lastStepRowSnapshots = new ArrayList();
    private final List<PackUtilMacroEditorOverlay.StepRowMotion> stepRowMotions = new ArrayList();
    private int nextStepRowStableId = 1;
    private long stepRowAnimationClockNanos = System.nanoTime();

    public static PackUtilMacroEditorOverlay getSharedOverlay() {
        if (sharedOverlay == null) {
            sharedOverlay = new PackUtilMacroEditorOverlay(class_310.method_1551().field_1772);
            sharedOverlay.restoreLayout();
            PackUtilOverlayManager.get().register(sharedOverlay);
        }
        sharedOverlay.restorePosition();
        return sharedOverlay;
    }

    private PackUiOverlayButton createOverlayButton(int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean enabled, Runnable action) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), PackUtilMacroEditorOverlay::lambda$createOverlayButton$0 /* captured: action */);
        button.setWidth(w);
        button.setVariant(variant);
        button.active = enabled;
        return button;
    }

    private PackUiOverlayButton createStepRowControlButtonView(int x, int y, int width, int height, boolean danger, String label) {
        return this.createOverlayButton(x, y, width, height, label == null ? "" : label, danger ? PackUiOverlayButton.Variant.DANGER : PackUiOverlayButton.Variant.SECONDARY, true, null);
    }

    private void drawOverlayButton(class_332 context, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean enabled, int mouseX, int mouseY) {
        PackUiOverlayButton button = this.createOverlayButton(x, y, w, h, label, variant, enabled, null);
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, mouseX, mouseY);
    }

    public PackUtilMacroEditorOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.PANEL_WIDTH = this.defaultPanelWidth();
        this.PANEL_HEIGHT = this.defaultPanelHeight();
        this.windowNode.setCenterTitle(false);
        this.windowNode.setTitleTone(PackUiTone.LABEL);
        this.windowNode.setTitleAreaInsets(this.titleLeftInset(), this.titleRightInset());
        this.windowNode.content().setGap(0).setPadding(PackUiInsets.NONE);
        this.windowNode.content().add(this.shellBody);
    }

    private int getStepBuilderLabelY() {
        return this.getTopControlsBottomY() + this.stepBuilderLabelOffset();
    }

    private int getStepBuilderButtonY() {
        return this.getStepBuilderLabelY() + this.theme.lineHeight(PackUiTone.LABEL, 1) + this.stepBuilderLabelGap();
    }

    private int getStepListLabelY() {
        return this.getStepBuilderButtonY() + this.editorButtonHeight() + this.stepBuilderSectionGap();
    }

    private int getStepListY() {
        return this.getStepListLabelY() + this.theme.lineHeight(PackUiTone.LABEL, 1) + 1;
    }

    private int getStepListFrameX() {
        return this.panelX + 8;
    }

    private int getStepListFrameWidth() {
        return this.PANEL_WIDTH - 16;
    }

    private int getStepListContentLeft() {
        return this.getStepListFrameX() + 1;
    }

    private int getActionRowControlsWidth(MacroAction action) {
        int count = action != null && this.hasActionEditor(action) ? 5 : 4;
        return count * this.stepRowControlSize() + (count - 1) * this.stepRowControlGap();
    }

    private int getActionRowControlsX(MacroAction action) {
        return this.getStepListContentRight() - this.getActionRowControlsWidth(action) - 1;
    }

    private int getFooterButtonsY() {
        return this.panelY + this.PANEL_HEIGHT - this.footerBottomInset();
    }

    private int getFooterTopY() {
        return this.getFooterButtonsY() - this.footerSectionGap();
    }

    private int getStepListAvailableHeight() {
        return Math.max(0, this.getFooterTopY() - this.getStepListY());
    }

    private int getStepListHeight() {
        return Math.max(0, this.getStepListViewportHeight() + 2);
    }

    private int getStepListViewportHeight() {
        return this.alignViewportHeight(Math.max(0, this.getStepListAvailableHeight() - 2), this.actionRowHeight());
    }

    private int getStepListClipTop() {
        return this.getStepListY() + 1;
    }

    private int getStepListClipBottom() {
        return this.getStepListClipTop() + this.getStepListViewportHeight();
    }

    private int getMaxStepListScroll() {
        return this.macro == null ? 0 : Math.max(0, this.macro.actions.size() * this.actionRowHeight() - this.getStepListViewportHeight());
    }

    private boolean isStepRowFullyVisible(int rowY) {
        return rowY >= this.getStepListY() && rowY + this.actionRowHeight() <= this.getStepListClipBottom();
    }

    private int defaultPanelWidth() {
        return 258;
    }

    private int defaultPanelHeight() {
        return 308;
    }

    private int minimumPanelHeight() {
        return 272;
    }

    private int titleLeftInset() {
        return 10;
    }

    private int titleRightInset() {
        return 39;
    }

    private int stepBuilderLabelOffset() {
        return 5;
    }

    private int stepBuilderLabelGap() {
        return 1;
    }

    private int stepBuilderSectionGap() {
        return 5;
    }

    private int stepRowControlSize() {
        return 13;
    }

    private int stepRowControlGap() {
        return 2;
    }

    private int stepListScrollbarGutter() {
        return 6;
    }

    private int getStepListContentRight() {
        return this.getStepListFrameX() + this.getStepListFrameWidth() - this.stepListScrollbarGutter() - 1;
    }

    private int getStepListContentRightForAction(MacroAction action) {
        int buttonsX = this.getActionRowControlsX(action);
        return buttonsX - 1;
    }

    private int getStepListScrollbarX() {
        return this.getStepListFrameX() + this.getStepListFrameWidth() - 4;
    }

    private PackUiScrollbar.Metrics getStepListScrollbarMetrics() {
        this.clampStepListScrollOffset();
        int listHeight = this.getStepListHeight();
        int viewHeight = Math.max(1, this.getStepListViewportHeight());
        return PackUiScrollbar.compute(this.macro.actions.size() * this.actionRowHeight(), viewHeight, this.getStepListScrollbarX(), this.getStepListClipTop(), 3, Math.max(1, listHeight - 2), this.scrollOffset);
    }

    private int contentInsetX() {
        return 8;
    }

    private int footerBottomInset() {
        return 16;
    }

    private int footerSectionGap() {
        return 12;
    }

    private int actionRowHeight() {
        return 18;
    }

    private int defaultScreenInsetX() {
        return 16;
    }

    private int defaultScreenInsetY() {
        return 30;
    }

    private int editorButtonHeight() {
        return 14;
    }

    private int editorControlGap() {
        return 3;
    }

    private int deleteButtonWidth() {
        return 48;
    }

    private int textFieldHeight() {
        return 13;
    }

    private int secondRowGap() {
        return 15;
    }

    private int buttonTextPadding() {
        return 9;
    }

    private int runButtonWidth() {
        return 34;
    }

    private int lanButtonWidth() {
        return 28;
    }

    private int loopCountFieldWidth() {
        return 36;
    }

    private int loopCountFieldHeight() {
        return 13;
    }

    private int builderButtonGap() {
        return 2;
    }

    private int footerPrimaryButtonWidth() {
        return 49;
    }

    private int footerSecondaryButtonWidth() {
        return 44;
    }

    private int footerButtonGap() {
        return 3;
    }

    private int topRowOffset() {
        return 20;
    }

    private int getTopControlsBottomY() {
        return this.panelY + this.topRowOffset() + this.secondRowGap() + this.editorButtonHeight();
    }

    private int warningTextOffset() {
        return 32;
    }

    private int builderLabelTextOffset() {
        return 3;
    }

    private int stepsHeaderOffset() {
        return 9;
    }

    private int actionTextOffset() {
        return 7;
    }

    private int actionControlOffset() {
        return 5;
    }

    private int stepRowControlStride() {
        return this.stepRowControlSize() + this.stepRowControlGap();
    }

    private int stepRowTextY(int rowY) {
        return PackUiSizing.alignTextY(rowY, this.actionRowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
    }

    private int stepRowControlY(int rowY) {
        return PackUiSizing.alignMiddle(rowY, this.actionRowHeight(), this.stepRowControlSize());
    }

    private int stepRowStableId(MacroAction action) {
        if (action == null) {
            return -1;
        }
        Integer existing = (Integer)this.stepRowStableIds.get(action);
        if (existing != null) {
            return existing.intValue();
        }
        this.nextStepRowStableId = this.nextStepRowStableId + 1;
        int created = this.nextStepRowStableId;
        this.stepRowStableIds.put(action, created);
        return created;
    }

    private List<PackUtilMacroEditorOverlay.StepRowSnapshot> captureCurrentStepRowSnapshots() {
        List<PackUtilMacroEditorOverlay.StepRowSnapshot> snapshots = new ArrayList();
        if (this.macro == null) {
            return snapshots;
        }
        for (int index = 0; index < this.macro.actions.size(); index++) {
            MacroAction action = (MacroAction)this.macro.actions.get(index);
            snapshots.add(new PackUtilMacroEditorOverlay.StepRowSnapshot(action, this.stepRowStableId(action), action.getDisplayName(), this.isConditionalAction(action), index));
        }
        return snapshots;
    }

    private PackUtilMacroEditorOverlay.StepRowSnapshot findStepRowSnapshot(List<PackUtilMacroEditorOverlay.StepRowSnapshot> snapshots, int stableId) {
        var var3 = snapshots.iterator();
        while (var3.hasNext()) {
            StepRowSnapshot snapshot = (PackUtilMacroEditorOverlay.StepRowSnapshot)var3.next();
            if (snapshot.stableId != stableId) continue;
            return snapshot;
        }
        return null;
    }

    private PackUtilMacroEditorOverlay.StepRowMotion findStepRowMotion(int stableId) {
        var var2 = this.stepRowMotions.iterator();
        while (var2.hasNext()) {
            StepRowMotion motion = (PackUtilMacroEditorOverlay.StepRowMotion)var2.next();
            if (motion.stableId != stableId) continue;
            return motion;
        }
        return null;
    }

    private void removeStepRowMotion(int stableId) {
        this.stepRowMotions.removeIf(PackUtilMacroEditorOverlay::lambda$removeStepRowMotion$1 /* captured: stableId */);
    }

    private void syncStepRowAnimations(boolean animateChanges) {
        List<PackUtilMacroEditorOverlay.StepRowSnapshot> current = this.captureCurrentStepRowSnapshots();
        if (!animateChanges) {
            this.stepRowMotions.clear();
            this.lastStepRowSnapshots.clear();
            this.lastStepRowSnapshots.addAll(current);
            this.stepRowAnimationClockNanos = System.nanoTime();
            return;
        }
        this.stepRowMotions.clear();
        var var3 = current.iterator();
        while (var3.hasNext()) {
            StepRowSnapshot snapshot = (PackUtilMacroEditorOverlay.StepRowSnapshot)var3.next();
            StepRowSnapshot previous = this.findStepRowSnapshot(this.lastStepRowSnapshots, snapshot.stableId);
            if (previous == null) {
                this.removeStepRowMotion(snapshot.stableId);
                this.stepRowMotions.add(new PackUtilMacroEditorOverlay.StepRowMotion(snapshot.stableId, snapshot.label, snapshot.conditional, snapshot.index, snapshot.index, PackUtilMacroEditorOverlay.StepRowMotionKind.ENTER));
            } else {
                if (previous.index != snapshot.index) {
                    this.removeStepRowMotion(snapshot.stableId);
                    this.stepRowMotions.add(new PackUtilMacroEditorOverlay.StepRowMotion(snapshot.stableId, snapshot.label, snapshot.conditional, previous.index, snapshot.index, PackUtilMacroEditorOverlay.StepRowMotionKind.MOVE));
                }
            }
        }
        var3 = this.lastStepRowSnapshots.iterator();
        while (var3.hasNext()) {
            snapshot = (PackUtilMacroEditorOverlay.StepRowSnapshot)var3.next();
            if (this.findStepRowSnapshot(current, snapshot.stableId) == null) {
                this.removeStepRowMotion(snapshot.stableId);
                this.stepRowMotions.add(new PackUtilMacroEditorOverlay.StepRowMotion(snapshot.stableId, snapshot.label, snapshot.conditional, snapshot.index, snapshot.index, PackUtilMacroEditorOverlay.StepRowMotionKind.EXIT));
            }
        }
        this.lastStepRowSnapshots.clear();
        this.lastStepRowSnapshots.addAll(current);
    }

    private void resetStepRowAnimationState() {
        this.stepRowStableIds.clear();
        this.lastStepRowSnapshots.clear();
        this.stepRowMotions.clear();
        this.nextStepRowStableId = 1;
        this.stepRowAnimationClockNanos = System.nanoTime();
        if (this.macro != null) {
            this.lastStepRowSnapshots.addAll(this.captureCurrentStepRowSnapshots());
        }
    }

    private float tickStepRowAnimations() {
        long now = System.nanoTime();
        float delta = Math.max(0f, Math.min(0.05f, (float)(now - this.stepRowAnimationClockNanos) / 1000000000f));
        this.stepRowAnimationClockNanos = now;
        if (this.stepRowMotions.isEmpty()) {
            return delta;
        }
        this.stepRowMotions.removeIf(PackUtilMacroEditorOverlay::lambda$tickStepRowAnimations$2 /* captured: delta */);
        return delta;
    }

    private float getStepRowEnterProgress(int stableId) {
        StepRowMotion motion = this.findStepRowMotion(stableId);
        if (motion != null && motion.kind == PackUtilMacroEditorOverlay.StepRowMotionKind.ENTER) {
            return this.easeOutCubic(motion.progress);
        }
        return 1f;
    }

    private int getAnimatedStepRowY(PackUtilMacroEditorOverlay.StepRowMotion motion, int baseListY) {
        float eased = this.easeOutCubic(motion.progress);
        int fromY = baseListY + motion.fromRowIndex * this.actionRowHeight();
        int toY = baseListY + motion.toRowIndex * this.actionRowHeight();
        return Math.round((float)fromY + (float)(toY - fromY) * eased);
    }

    private int getStepRowMoveOffsetX(PackUtilMacroEditorOverlay.StepRowMotion motion) {
        if (motion == null) {
            return 0;
        }
        float eased = this.easeOutCubic(motion.progress);
        switch (motion.kind.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return Math.round((1f - eased) * -18f);
            case 2::
                return Math.round(eased * 20f);
            case 1::
                return 0;
        }
    }

    private float getStepRowAlpha(PackUtilMacroEditorOverlay.StepRowMotion motion) {
        if (motion == null) {
            return 1f;
        }
        float eased = this.easeOutCubic(motion.progress);
        switch (motion.kind.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return 0.45f + 0.55f * eased;
            case 2::
                return Math.max(0f, 1f - eased);
            case 1::
                return 1f;
        }
    }

    private float easeOutCubic(float value) {
        float clamped = Math.max(0f, Math.min(1f, value));
        return 1f - (float)Math.pow((double)(1f - clamped), 3);
    }

    private void clampStepListScrollOffset() {
        this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset, this.actionRowHeight(), this.getMaxStepListScroll());
    }

    private int getDraggedRowTop() {
        return this.stepDragMouseY - this.stepDragGrabOffsetY;
    }

    private int getStepInsertSlotForTarget(int sourceIndex, int targetIndex) {
        if (sourceIndex < 0 || targetIndex < 0) {
            return -1;
        }
        return targetIndex > sourceIndex ? targetIndex + 1 : targetIndex;
    }

    private int getShiftedVisualIndex(int index, int sourceIndex, int targetIndex) {
        if (sourceIndex < 0 || targetIndex < 0 || sourceIndex == targetIndex) {
            return index;
        }
        if (sourceIndex >= targetIndex) { /* goto L38; */ }
        return index > sourceIndex && index <= targetIndex ? index - 1 : index;
        return index >= targetIndex && index < sourceIndex ? index + 1 : index;
    }

    private void beginStepDragPress(int index, double mouseX, double mouseY) {
        this.pressedStepIndex = index;
        this.stepDragTargetIndex = index;
        this.stepDragGrabOffsetY = (int)Math.round(mouseY) - (this.getStepListY() - this.scrollOffset + index * this.actionRowHeight());
        this.stepDragMouseY = (int)Math.round(mouseY);
        this.stepPressMouseX = mouseX;
        this.stepPressMouseY = mouseY;
    }

    private void tryStartStepDrag(double mouseX, double mouseY) {
        if (this.draggingIndex >= 0) { /* goto L83; */ }
        if (this.pressedStepIndex < 0) { /* goto L83; */ }
        boolean movedEnough = Math.abs(mouseX - this.stepPressMouseX) >= 3 || Math.abs(mouseY - this.stepPressMouseY) >= 3;
        if (movedEnough) {
            this.draggingIndex = this.pressedStepIndex;
            this.stepDragTargetIndex = this.pressedStepIndex;
            this.stepDragMouseY = (int)Math.round(mouseY);
        }
    }

    private void updateStepDrag(double mouseY) {
        this.stepDragMouseY = (int)Math.round(mouseY);
        if (this.draggingIndex >= 0 && this.macro != null && !this.macro.actions.isEmpty()) {
            this.applyStepDragAutoScroll(mouseY);
            double draggedRowTop = mouseY - (double)this.stepDragGrabOffsetY;
            double draggedRowCenter = draggedRowTop - (double)this.getStepListY() + (double)this.scrollOffset + (double)this.actionRowHeight() / 2;
            this.stepDragTargetIndex = this.computeStepDragTargetIndex(draggedRowCenter);
        }
    }

    private int computeStepDragTargetIndex(double draggedRowCenter) {
        if (this.draggingIndex < 0 || this.macro == null || this.macro.actions.isEmpty()) {
            return -1;
        }
        int rowHeight = this.actionRowHeight();
        int targetIndex = this.draggingIndex;
        double sourceCenter = (double)(this.draggingIndex * rowHeight) + (double)rowHeight / 2;
        if (draggedRowCenter >= sourceCenter) { /* goto L99; */ }
        L65: ;
        if (targetIndex <= 0) { /* goto L158; */ }
        double previousCenter = (double)((targetIndex - 1) * rowHeight) + (double)rowHeight / 2;
        if (draggedRowCenter >= previousCenter) { /* goto L158; */ }
        targetIndex--;
        /* goto L65; */
        L99: ;
        if (draggedRowCenter <= sourceCenter) { /* goto L158; */ }
        maxIndex = this.macro.actions.size() - 1;
        while (targetIndex < maxIndex) {
            double nextCenter = (double)((targetIndex + 1) * rowHeight) + (double)rowHeight / 2;
            if (draggedRowCenter <= nextCenter) break;
            targetIndex++;
        }
        return targetIndex;
    }

    private void applyStepDragAutoScroll(double mouseY) {
        int maxScroll = this.getMaxStepListScroll();
        if (maxScroll <= 0) { /* goto L139; */ }
        int listTop = this.getStepListY();
        int listBottom = listTop + this.getStepListHeight();
        int delta = 0;
        if (mouseY < (double)(listTop + 18)) {
            double depth = (double)(listTop + 18) - mouseY;
            delta = -Math.min(12, Math.max(1, (int)Math.ceil(depth / 3)));
        } else {
            if (mouseY > (double)(listBottom - 18)) {
                double depth = mouseY - (double)(listBottom - 18);
                delta = Math.min(12, Math.max(1, (int)Math.ceil(depth / 3)));
            }
        }
        if (delta != 0) {
            this.scrollOffset = Math.max(0, Math.min(maxScroll, this.scrollOffset + delta));
        }
    }

    private void clearStepDragState() {
        this.draggingIndex = -1;
        this.pressedStepIndex = -1;
        this.stepDragTargetIndex = -1;
        this.stepDragGrabOffsetY = 0;
        this.stepDragMouseY = 0;
        this.stepPressMouseX = 0;
        this.stepPressMouseY = 0;
    }

    private void moveAction(int fromIndex, int toIndex) {
        MacroAction moved = (MacroAction)this.macro.actions.remove(fromIndex);
        if (this.macro != null && fromIndex >= 0 && toIndex >= 0 && fromIndex < this.macro.actions.size() && toIndex < this.macro.actions.size() && fromIndex != toIndex) {
            int targetIndex = Math.max(0, Math.min(toIndex, this.macro.actions.size()));
            this.macro.actions.add(targetIndex, moved);
            this.handleMacroActionsChanged();
        }
    }

    private void finishStepDrag() {
        int sourceIndex = this.draggingIndex;
        int targetIndex = this.stepDragTargetIndex;
        this.clearStepDragState();
        this.pushStructuralHistoryStep();
        if (this.macro != null && sourceIndex >= 0 && targetIndex >= 0 && sourceIndex != targetIndex) {
            this.moveAction(sourceIndex, targetIndex);
        }
    }

    private int getStepPickerWidth() {
        return this.getStepPickerViewportWidth() + 12;
    }

    private int getStepPickerViewportWidth() {
        int screenW = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenWidth() : 320;
        int screenH = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenHeight() : 320;
        int minViewportWidth = 118;
        int maxViewportWidth = Math.max(minViewportWidth, Math.min(220, screenW - 20));
        int maxContentHeight = Math.max(80, screenH - 36);
        List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> fallbackLayouts = null;
        int fallbackOverflow = 2147483647;
        int fallbackWidth = maxViewportWidth;
        for (int candidateWidth = minViewportWidth; candidateWidth <= maxViewportWidth; candidateWidth += 6) {
            List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> layouts = this.buildStepPickerLayouts(0, 0, candidateWidth);
            int contentHeight = this.getStepPickerContentHeight(layouts);
            if (!contentHeight <= maxContentHeight) continue;
            return this.widenStepPickerViewportWidth(this.getStepPickerUsedWidth(layouts), minViewportWidth, maxViewportWidth);
            int overflow = contentHeight - maxContentHeight;
            if (overflow < fallbackOverflow) {
                fallbackOverflow = overflow;
                fallbackLayouts = layouts;
                fallbackWidth = candidateWidth;
            }
        }
        return fallbackLayouts != null ? this.widenStepPickerViewportWidth(this.getStepPickerUsedWidth(fallbackLayouts), minViewportWidth, fallbackWidth) : maxViewportWidth;
    }

    private int widenStepPickerViewportWidth(int width, int minViewportWidth, int maxViewportWidth) {
        int widenedWidth = width + 8;
        return Math.max(minViewportWidth, Math.min(maxViewportWidth, widenedWidth));
    }

    private int getStepPickerContentHeight() {
        List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> layouts = this.buildStepPickerLayouts(0, 0, this.getStepPickerViewportWidth());
        return this.getStepPickerContentHeight(layouts);
    }

    private int getStepPickerHeight() {
        int screenH = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenHeight() : 320;
        int desiredHeight = 28 + this.getStepPickerContentHeight();
        return Math.max(78, Math.min(desiredHeight, screenH - 8));
    }

    private int getStepPickerX() {
        int pickerW = this.getStepPickerWidth();
        int screenW = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenWidth() : this.panelX + this.PANEL_WIDTH + pickerW + 8;
        if (this.panelX + this.PANEL_WIDTH + pickerW + 5 <= screenW) {
            return this.panelX + this.PANEL_WIDTH + 5;
        }
        return this.panelX - pickerW - 5 >= 0 ? this.panelX - pickerW - 5 : Math.max(4, Math.min(screenW - pickerW - 4, this.panelX + (this.PANEL_WIDTH - pickerW) / 2));
    }

    private int getStepPickerY() {
        int pickerH = this.getStepPickerHeight();
        int screenH = MC.method_22683() != null ? PackUtilUiScale.getVirtualScreenHeight() : this.panelY + pickerH + 8;
        int preferredY = this.panelY + 42;
        return Math.max(4, Math.min(screenH - pickerH - 4, preferredY));
    }

    private int getStepPickerCloseX() {
        return this.getStepPickerX() + this.getStepPickerWidth() - 16;
    }

    private int getStepPickerCloseY() {
        return PackUiHeaderControls.controlY(this.getStepPickerY(), 16, 12);
    }

    private PackUiScrollbar.Metrics getStepPickerScrollbarMetrics() {
        int pickerX = this.getStepPickerX();
        int pickerY = this.getStepPickerY();
        int pickerW = this.getStepPickerWidth();
        int pickerH = this.getStepPickerHeight();
        int gridX = pickerX + 6;
        int gridY = pickerY + 22;
        int gridW = pickerW - 12;
        int gridH = pickerH - 28;
        return PackUiScrollbar.compute(this.getStepPickerContentHeight(), gridH, gridX + gridW - 5, gridY, 3, gridH, this.stepPickerScrollOffset);
    }

    private boolean isMouseOverStepPicker(int mouseX, int mouseY) {
        if (!this.isStepPickerOpen()) {
            return false;
        }
        int pickerX = this.getStepPickerX();
        int pickerY = this.getStepPickerY();
        int pickerW = this.getStepPickerWidth();
        int pickerH = this.getStepPickerHeight();
        return mouseX >= pickerX && mouseX < pickerX + pickerW && mouseY >= pickerY && mouseY < pickerY + pickerH;
    }

    private boolean isStepPickerOpen() {
        return this.stepPickerMode != null;
    }

    private void closeStepPicker() {
        this.stepPickerMode = null;
        this.stepPickerCategories = Collections.emptyList();
        this.stepPickerEntries = Collections.emptyList();
        this.stepPickerScrollOffset = 0;
    }

    private void addStepPickerEntry(List<PackUtilMacroEditorOverlay.StepPickerEntry> entries, String categoryId, String label, String description, Runnable action) {
        entries.add(new PackUtilMacroEditorOverlay.StepPickerEntry(categoryId, label, description, action));
    }

    private void addDefaultRotateAction() {
        if (MC.field_1724 != null) {
            this.addAction(new RotateAction(MC.field_1724.method_36454(), MC.field_1724.method_36455(), false, 6));
        } else {
            this.addAction(new RotateAction(0f, 0f, false, 6));
        }
    }

    private void addDefaultLookAtAction() {
        LookAtBlockAction action = new LookAtBlockAction();
        if (MC.field_1765 != null) {
            if (MC.field_1765.method_17783() == class_239.class_240.field_1331) {
                if (MC.field_1692 != null) {
                    action.targetMode = LookAtBlockAction.TargetMode.ENTITY;
                    action.entityIds.add(LookAtBlockAction.toSpecificEntityEntry(MC.field_1692));
                }
            }
        } else {
            if (MC.field_1765 != null) {
                if (MC.field_1765.method_17783() == class_239.class_240.field_1332) {
                    class_3965 hit = (class_3965)MC.field_1765;
                    action.targetMode = LookAtBlockAction.TargetMode.SPECIFIC;
                    action.blockX = hit.method_17777().method_10263();
                    action.blockY = hit.method_17777().method_10264();
                    action.blockZ = hit.method_17777().method_10260();
                }
            }
        }
        this.addAction(action);
    }

    private boolean hasActionEditor(MacroAction action) {
        return ActionEditorOverlay.supportsActionEditor(action);
    }

    private boolean isConditionalAction(MacroAction action) {
        return action instanceof WaitForHealthAction || action instanceof WaitForBlockAction || action instanceof WaitForPacketAction || action instanceof WaitForGuiAction || action instanceof TickSyncAction || action instanceof RevisionSyncAction || action instanceof ServerTickSyncAction || action instanceof WaitForCooldownAction || action instanceof WaitPosAction || action instanceof WaitForChatAction || action instanceof WaitForEntityAction || action instanceof WaitForSlotChangeAction || action instanceof WaitForSoundAction;
    }

    private void addDefaultOpenContainerAction() {
        OpenContainerAction action = new OpenContainerAction();
        var var3 = MC.field_1765;
        if (var3 instanceof class_3965) {
            class_3965 hit = (class_3965)var3;
            action.blockPos = hit.method_17777();
        }
        this.addAction(action);
    }

    private void addDefaultInventoryAction() {
        InventoryAction action = new InventoryAction();
        action.mode = InventoryAction.InvMode.OPEN;
        this.addAction(action);
    }

    private void addDefaultDelayPacketsAction() {
        DelayPacketsAction action = new DelayPacketsAction();
        if (PackUtilSharedState.get().shouldUseCustomPackets()) {
            action.applyModulePreset();
        } else {
            action.applyDefaultPreset();
        }
        this.addAction(action);
    }

    private void addDefaultWaitBlockAction() {
        WaitForBlockAction action = new WaitForBlockAction();
        class_3965 hit = (class_3965)MC.field_1765;
        if (MC.field_1765 != null && MC.field_1765.method_17783() == class_239.class_240.field_1332) {
            action.blockPos = hit.method_17777();
        }
        this.addAction(action);
    }

    private void addDefaultWaitEntityAction() {
        WaitForEntityAction action = new WaitForEntityAction();
        if (MC.field_1724 != null) {
            action.x = (double)Math.round(MC.field_1724.method_23317());
            action.y = (double)Math.round(MC.field_1724.method_23318());
            action.z = (double)Math.round(MC.field_1724.method_23321());
        }
        this.addAction(action);
    }

    private List<PackUtilMacroEditorOverlay.StepPickerEntry> buildStepPickerEntries(PackUtilMacroEditorOverlay.StepPickerMode mode) {
        List<PackUtilMacroEditorOverlay.StepPickerEntry> entries = new ArrayList();
        if (mode == PackUtilMacroEditorOverlay.StepPickerMode.ACTION) {
            this.addStepPickerEntry(entries, "flow", "Chat", "Send a chat message or slash command.", this::lambda$buildStepPickerEntries$3);
            this.addStepPickerEntry(entries, "flow", "Delay", "Pause for a time in ms or ticks.", this::lambda$buildStepPickerEntries$4);
            this.addStepPickerEntry(entries, "flow", "Repeat", "Repeat the next steps a chosen number of times.", this::lambda$buildStepPickerEntries$5);
            this.addStepPickerEntry(entries, "flow", "Stop", "Stop the macro immediately.", this::lambda$buildStepPickerEntries$6);
            this.addStepPickerEntry(entries, "flow", "Send Toggle", "Turn packet sending on or off.", this::lambda$buildStepPickerEntries$7);
            this.addStepPickerEntry(entries, "flow", "Delay Packets", "Queue packets until you flush them.", this::addDefaultDelayPacketsAction);
            this.addStepPickerEntry(entries, "flow", "Save GUI", "Remember the current GUI for later restore.", this::lambda$buildStepPickerEntries$8);
            this.addStepPickerEntry(entries, "flow", "Restore GUI", "Reopen the last saved GUI state.", this::lambda$buildStepPickerEntries$9);
            this.addStepPickerEntry(entries, "movement", "Rotate", "Set player yaw and pitch.", this::addDefaultRotateAction);
            this.addStepPickerEntry(entries, "movement", "Look At", "Face a specific position, nearest block, or nearest entity.", this::addDefaultLookAtAction);
            this.addStepPickerEntry(entries, "movement", "Sneak", "Hold or release sneak.", this::lambda$buildStepPickerEntries$10);
            this.addStepPickerEntry(entries, "movement", "Jump", "Press jump for a chosen duration.", this::lambda$buildStepPickerEntries$11);
            this.addStepPickerEntry(entries, "movement", "Sprint", "Toggle sprint state.", this::lambda$buildStepPickerEntries$12);
            this.addStepPickerEntry(entries, "movement", "Move", "Walk in a direction for N ticks.", this::lambda$buildStepPickerEntries$13);
            if (PackUtilCompatManager.isBaritoneAvailable()) {
                this.addStepPickerEntry(entries, "movement", "Go To", "Use Baritone to path to a target.", this::lambda$buildStepPickerEntries$14);
                this.addStepPickerEntry(entries, "movement", "Mine", "Mine blocks with Baritone rules.", this::lambda$buildStepPickerEntries$15);
            }
            this.addStepPickerEntry(entries, "inventory", "Item Click", "Click configured inventory slots.", this::lambda$buildStepPickerEntries$16);
            this.addStepPickerEntry(entries, "inventory", "Use Item", "Use the held item or select one by name.", this::lambda$buildStepPickerEntries$17);
            this.addStepPickerEntry(entries, "inventory", "Open Inventory", "Open the player inventory screen.", this::addDefaultInventoryAction);
            this.addStepPickerEntry(entries, "inventory", "Slot", "Select a hotbar slot or item by name.", this::lambda$buildStepPickerEntries$18);
            this.addStepPickerEntry(entries, "inventory", "XCarry", "Store up to four items in the player crafting grid.", this::lambda$buildStepPickerEntries$19);
            this.addStepPickerEntry(entries, "inventory", "Drop", "Drop items from chosen slots.", this::lambda$buildStepPickerEntries$20);
            this.addStepPickerEntry(entries, "inventory", "Swap", "Swap two inventory slots.", this::lambda$buildStepPickerEntries$21);
            this.addStepPickerEntry(entries, "inventory", "Open Container", "Open a targeted container block.", this::addDefaultOpenContainerAction);
            this.addStepPickerEntry(entries, "inventory", "Store", "Move items between player and containers.", this::lambda$buildStepPickerEntries$22);
            this.addStepPickerEntry(entries, "inventory", "Inventory Audit", "Snapshot slots, compare after reopen, or run automated dupe tests.", this::lambda$buildStepPickerEntries$23);
            this.addStepPickerEntry(entries, "inventory", "Craft", "Craft one or more recipes.", this::lambda$buildStepPickerEntries$24);
            this.addStepPickerEntry(entries, "inventory", "Mouse Click", "Simulate mouse clicks in world.", this::lambda$buildStepPickerEntries$25);
            this.addStepPickerEntry(entries, "network", "Packet", "Send captured packets from the queue.", this::lambda$buildStepPickerEntries$26);
            this.addStepPickerEntry(entries, "network", "Close GUI", "Close the current screen with optional no-packet mode.", this::lambda$buildStepPickerEntries$27);
            this.addStepPickerEntry(entries, "network", "Desync", "Create GUI desync without closing locally.", this::lambda$buildStepPickerEntries$28);
            this.addStepPickerEntry(entries, "network", "NBT Book", "Write large custom books.", this::lambda$buildStepPickerEntries$29);
            this.addStepPickerEntry(entries, "network", "Disconnect", "Disconnect or kick using selected mode.", this::lambda$buildStepPickerEntries$30);
            if (PackUtilCompatManager.isMeteorAvailable()) {
                this.addStepPickerEntry(entries, "automation", "Module", "Toggle a Meteor module.", this::lambda$buildStepPickerEntries$31);
            }
            this.addStepPickerEntry(entries, "automation", "Pay", "Send payments to a player list.", this::lambda$buildStepPickerEntries$32);
        } else {
            this.addStepPickerEntry(entries, "player", "Wait Health", "Pause until your health drops below or rises above a target.", this::lambda$buildStepPickerEntries$33);
            this.addStepPickerEntry(entries, "player", "Wait Cooldown", "Pause until an item cooldown is ready.", this::lambda$buildStepPickerEntries$34);
            this.addStepPickerEntry(entries, "player", "Wait Slot or Item", "Pause until slots or inventory contents change.", this::lambda$buildStepPickerEntries$35);
            this.addStepPickerEntry(entries, "world", "Wait Position", "Pause until you reach a position or rotation.", this::lambda$buildStepPickerEntries$36);
            this.addStepPickerEntry(entries, "world", "Wait Block", "Pause until a block is placed or broken.", this::addDefaultWaitBlockAction);
            this.addStepPickerEntry(entries, "world", "Wait Entity", "Pause until a matching entity appears.", this::addDefaultWaitEntityAction);
            this.addStepPickerEntry(entries, "world", "Wait Sound", "Pause until a matching sound plays.", this::lambda$buildStepPickerEntries$37);
            this.addStepPickerEntry(entries, "events", "WaitGUI", "Pause until a GUI opens or closes.", this::lambda$buildStepPickerEntries$38);
            this.addStepPickerEntry(entries, "events", "Wait Chat", "Pause until chat matches a pattern.", this::lambda$buildStepPickerEntries$39);
            this.addStepPickerEntry(entries, "events", "Wait LAN", "Pause until a LAN peer reaches a step.", this::lambda$buildStepPickerEntries$40);
            this.addStepPickerEntry(entries, "sync", "Wait Packet", "Pause until a chosen C2S or S2C packet appears.", this::lambda$buildStepPickerEntries$41);
            this.addStepPickerEntry(entries, "sync", "Tick Sync", "Wait for the next client tick.", this::lambda$buildStepPickerEntries$42);
            this.addStepPickerEntry(entries, "sync", "Revision Sync", "Wait for handler revision sync.", this::lambda$buildStepPickerEntries$43);
            this.addStepPickerEntry(entries, "sync", "Server Sync", "Wait for the server tick tracker.", this::lambda$buildStepPickerEntries$44);
        }
        return entries;
    }

    private List<PackUtilMacroEditorOverlay.StepPickerCategory> buildStepPickerCategories(PackUtilMacroEditorOverlay.StepPickerMode mode, List<PackUtilMacroEditorOverlay.StepPickerEntry> entries) {
        List<PackUtilMacroEditorOverlay.StepPickerCategory> categories = new ArrayList();
        Consumer<PackUtilMacroEditorOverlay.StepPickerCategory> addCategory = PackUtilMacroEditorOverlay::lambda$buildStepPickerCategories$45 /* captured: entries, categories */;
        if (mode == PackUtilMacroEditorOverlay.StepPickerMode.ACTION) {
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("flow", "Flow", -11352981));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("movement", "Movement", -42406));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("inventory", "Inventory", -11182));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("network", "Network", -10835457));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("automation", "Automation", -4555521));
        } else {
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("player", "Player", -42406));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("world", "World", -11352981));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("events", "Events", -11182));
            addCategory.accept(new PackUtilMacroEditorOverlay.StepPickerCategory("sync", "Sync", -10835457));
        }
        return categories;
    }

    private void openStepPicker(PackUtilMacroEditorOverlay.StepPickerMode mode) {
        if (mode != null) {
            this.clearStepDragState();
            this.stepPickerMode = mode;
            this.stepPickerEntries = this.buildStepPickerEntries(mode);
            this.stepPickerCategories = this.buildStepPickerCategories(mode, this.stepPickerEntries);
            this.stepPickerScrollOffset = 0;
            this.isBindingKey = false;
            if (this.nameField != null) {
                this.nameField.setFocused(false);
            }
            if (this.loopCountField != null) {
                this.loopCountField.setFocused(false);
            }
        }
    }

    private List<PackUtilMacroEditorOverlay.StepPickerEntry> getVisibleStepPickerEntries() {
        if (!this.isStepPickerOpen()) {
            return Collections.emptyList();
        }
        return new ArrayList(this.stepPickerEntries);
    }

    private List<PackUtilMacroEditorOverlay.StepPickerEntry> getStepPickerEntriesForCategory(String categoryId) {
        List<PackUtilMacroEditorOverlay.StepPickerEntry> filtered = new ArrayList();
        if (categoryId == null) { /* goto L75; */ }
        if (categoryId.isEmpty()) { /* goto L75; */ }
        var var3 = this.stepPickerEntries.iterator();
        while (var3.hasNext()) {
            StepPickerEntry entry = (PackUtilMacroEditorOverlay.StepPickerEntry)var3.next();
            if (!categoryId.equals(entry.categoryId)) continue;
            filtered.add(entry);
        }
        return filtered;
        L75: ;
        return filtered;
    }

    private List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> buildStepPickerLayouts(int gridX, int startY, int gridW) {
        int cardGap = 4;
        int rowGap = 3;
        int cardH = 16;
        int sectionLabelH = this.stepPickerSectionLabelHeight();
        int sectionGap = 5;
        int labelPadding = 10;
        int minButtonW = 22;
        class_2960 pickerFont = this.theme.fontFor(PackUiTone.BODY);
        int pickerColor = this.theme.color(PackUiTone.BODY);
        List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> layouts = new ArrayList();
        int sectionY = startY;
        var var15 = this.stepPickerCategories.iterator();
        while (var15.hasNext()) {
            StepPickerCategory category = (PackUtilMacroEditorOverlay.StepPickerCategory)var15.next();
            List<PackUtilMacroEditorOverlay.StepPickerEntry> categoryEntries = this.getStepPickerEntriesForCategory(category.id);
            if (categoryEntries.isEmpty()) { /* goto @346; */ }
            List<PackUtilMacroEditorOverlay.StepPickerButtonLayout> buttons = new ArrayList();
            int buttonX = gridX;
            int buttonY = sectionY + sectionLabelH + 2;
            int bottomY = categoryEntries.iterator();
            while (bottomY.hasNext()) {
                StepPickerEntry entry = (PackUtilMacroEditorOverlay.StepPickerEntry)bottomY.next();
                int buttonW = Math.max(minButtonW, Math.min(gridW, PackUiText.width(this.textRenderer, entry.label, pickerFont, pickerColor) + labelPadding));
                buttonX = gridX;
                if (buttons.isEmpty() && buttonX + buttonW > gridX + gridW) continue;
                buttonY = buttonY + (cardH + rowGap);
                buttons.add(new PackUtilMacroEditorOverlay.StepPickerButtonLayout(entry, buttonX, buttonY, buttonW, cardH));
                buttonX = buttonX + (buttonW + cardGap);
            }
            bottomY = buttons.isEmpty() ? sectionY + sectionLabelH : ((PackUtilMacroEditorOverlay.StepPickerButtonLayout)buttons.get(buttons.size() - 1)).y + cardH;
            layouts.add(new PackUtilMacroEditorOverlay.StepPickerSectionLayout(category, sectionY, buttons, bottomY));
            sectionY = bottomY + sectionGap;
        }
        return layouts;
    }

    private int getStepPickerContentHeight(List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> layouts) {
        return layouts != null && !layouts.isEmpty() ? Math.max(0, ((PackUtilMacroEditorOverlay.StepPickerSectionLayout)layouts.get(layouts.size() - 1)).bottomY) : 0;
    }

    private int getStepPickerUsedWidth(List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> layouts) {
        if (layouts == null) { /* goto L187; */ }
        if (layouts.isEmpty()) { /* goto L187; */ }
        int maxRight = 0;
        int minLeft = 2147483647;
        class_2960 pickerFont = this.theme.fontFor(PackUiTone.LABEL);
        int pickerColor = this.theme.color(PackUiTone.BODY);
        var var6 = layouts.iterator();
        while (var6.hasNext()) {
            StepPickerSectionLayout section = (PackUtilMacroEditorOverlay.StepPickerSectionLayout)var6.next();
            minLeft = Math.min(minLeft, 0);
            maxRight = Math.max(maxRight, PackUiText.width(this.textRenderer, section.category.label, pickerFont, pickerColor));
            var var8 = section.buttons.iterator();
            while (var8.hasNext()) {
                StepPickerButtonLayout button = (PackUtilMacroEditorOverlay.StepPickerButtonLayout)var8.next();
                minLeft = Math.min(minLeft, button.x);
                maxRight = Math.max(maxRight, button.x + button.width);
            }
        }
        if (minLeft == 2147483647) {
            minLeft = 0;
        }
        return Math.max(118, maxRight - minLeft);
        L187: ;
        return 118;
    }

    public int getMinWidth() {
        return this.defaultPanelWidth();
    }

    public int getMinHeight() {
        return this.minimumPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) { /* goto L119; */ }
        int requestedWidth = bounds.width == 408 ? this.defaultPanelWidth() : bounds.width;
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(bounds.x, bounds.y, requestedWidth, bounds.height, bounds.visible, bounds.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = clamped.width;
        this.PANEL_HEIGHT = clamped.height;
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
        if (this.macro != null) {
            this.recreateComponents();
        }
    }

    private class_2487 captureMacroSnapshot() {
        return this.macro == null ? null : this.macro.toTag();
    }

    private static boolean snapshotsEqual(class_2487 a, class_2487 b) {
        if (a == b) {
            return true;
        }
        return a != null && b != null ? a.equals(b) : false;
    }

    private void pushSnapshot(Deque<class_2487> history, class_2487 snapshot) {
        if (history == null) { /* goto L54; */ }
        if (snapshot == null) { /* goto L54; */ }
        class_2487 head = (class_2487)history.peekFirst();
        if (PackUtilMacroEditorOverlay.snapshotsEqual(head, snapshot)) { /* goto L54; */ }
        history.addFirst(snapshot);
        while (history.size() > 30) {
            history.removeLast();
        }
    }

    private void resetHistoryState() {
        this.undoHistory.clear();
        this.redoHistory.clear();
    }

    private void pushStructuralHistoryStep() {
        this.pushSnapshot(this.undoHistory, this.captureMacroSnapshot());
        this.redoHistory.clear();
    }

    private boolean canUndoHistory() {
        return this.macro != null && !this.undoHistory.isEmpty();
    }

    private boolean canRedoHistory() {
        return this.macro != null && !this.redoHistory.isEmpty();
    }

    private void restoreHistorySnapshot(class_2487 snapshot) {
        this.macro.fromTag(snapshot);
        if (this.macro != null && snapshot != null) {
            this.handleMacroActionsChanged();
        }
    }

    private void performUndo() {
        if (this.canUndoHistory()) {
            class_2487 previous = (class_2487)this.undoHistory.pollFirst();
            if (previous != null) {
                this.pushSnapshot(this.redoHistory, this.captureMacroSnapshot());
                this.restoreHistorySnapshot(previous);
            }
        }
    }

    private void performRedo() {
        if (this.canRedoHistory()) {
            class_2487 next = (class_2487)this.redoHistory.pollFirst();
            if (next != null) {
                this.pushSnapshot(this.undoHistory, this.captureMacroSnapshot());
                this.restoreHistorySnapshot(next);
            }
        }
    }

    public void open(PackUtilMacro macroToEdit) {
        this.open(macroToEdit, false);
    }

    public void open(PackUtilMacro macroToEdit, boolean reopenMacroListOnClose) {
        if (this.visible) {
            this.closeStepPicker();
            this.isBindingKey = false;
        }
        var var3 = PackUtilOverlayManager.get().getOverlays().iterator();
        while (var3.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var3.next();
            if (overlay instanceof PackUtilMacroListOverlay) {
                PackUtilMacroListOverlay macroListOverlay = (PackUtilMacroListOverlay)overlay;
                macroListOverlay.setVisible(false);
            }
        }
        this.originalMacro = null;
        this.macro = null;
        this.reopenMacroListOnClose = reopenMacroListOnClose;
        this.visible = true;
        PackUtilSharedState.get().setMacroEditorVisible(true);
        if (macroToEdit == null) {
            this.macro = new PackUtilMacro("");
            this.originalMacro = null;
            this.isNew = true;
        } else {
            this.originalMacro = macroToEdit;
            this.macro = new PackUtilMacro();
            this.macro.fromTag(macroToEdit.toTag());
            this.isNew = false;
        }
        PackUtilSharedState.get().setEditingMacro(this.macro);
        this.tempSavedForRun = false;
        this.originalMacroSnapshot = null;
        this.resetHistoryState();
        this.clearStepDragState();
        this.scrollOffset = 0;
        if (!this.macro.loop) {
            this.loopMode = 0;
        } else {
            if (this.macro.loopCount == -1) {
                this.loopMode = 2;
            } else {
                this.loopMode = 1;
            }
        }
        this.resetStepRowAnimationState();
        this.init();
        this.windowNode.restoreShowBody(!this.collapsed);
        PackUtilOverlayManager.get().bringToFront(this);
    }

    public void cancel() {
        if (!this.tempSavedForRun) { /* goto L110; */ }
        if (this.originalMacro == null) {
            PackUtilMacro savedMacro = PackUtilMacroManager.get().get(this.macro.name);
            if (savedMacro != null) {
                if (MacroExecutor.isRunning()) {
                    if (MacroExecutor.getCurrentMacroName() != null) {
                        if (MacroExecutor.getCurrentMacroName().equals(this.macro.name)) {
                            MacroExecutor.stop();
                        }
                    }
                }
                PackUtilMacroManager.get().getAll().remove(savedMacro);
                PackUtilMacroManager.get().save();
            }
        } else {
            if (this.originalMacroSnapshot != null) {
                this.originalMacro.fromTag(this.originalMacroSnapshot);
                PackUtilMacroManager.get().save();
            }
        }
        this.close();
    }

    public void close() {
        boolean shouldReopenMacroList = this.reopenMacroListOnClose;
        this.visible = false;
        PackUtilSharedState.get().setMacroEditorVisible(false);
        PackUtilSharedState.get().setEditingMacro(null);
        this.macro = null;
        this.originalMacro = null;
        this.tempSavedForRun = false;
        this.originalMacroSnapshot = null;
        this.reopenMacroListOnClose = false;
        this.closeStepPicker();
        this.isBindingKey = false;
        this.resetHistoryState();
        this.clearStepDragState();
        this.resetStepRowAnimationState();
        if (!shouldReopenMacroList) { /* goto L138; */ }
        var var2 = PackUtilOverlayManager.get().getOverlays().iterator();
        while (var2.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var2.next();
            if (!overlay instanceof PackUtilMacroListOverlay) { /* goto @135; */ }
            PackUtilMacroListOverlay macroListOverlay = (PackUtilMacroListOverlay)overlay;
            macroListOverlay.setVisible(true);
            PackUtilOverlayManager.get().bringToFront(macroListOverlay);
            break;
        }
    }

    private boolean isEditingRunningMacro() {
        if (!MacroExecutor.isRunning()) { /* goto L101; */ }
        if (this.macro == null) { /* goto L101; */ }
        PackUtilMacro runningMacro = MacroExecutor.getCurrentMacro();
        if (runningMacro == null) {
            return false;
        }
        if (runningMacro == this.macro) { /* goto L99; */ }
        if (runningMacro == this.originalMacro) { /* goto L99; */ }
        String runningName = MacroExecutor.getCurrentMacroName();
        if (runningName.isBlank()) { /* goto @97; */ }
        if (!runningName.equals(this.macro.name)) {
            if (this.originalMacro == null) { /* goto @93; */ }
        }
        /* note: clearing non-empty stack before goto */
        /* goto @98; */
        L93: ;
        return runningName != null ? false : false;
        return true;
        L101: ;
        return false;
    }

    private void handleMacroActionsChanged() {
        if (this.macro != null) {
            if (this.macro.actions.isEmpty()) {
                if (this.isEditingRunningMacro()) {
                    MacroExecutor.stop();
                }
            }
            this.syncStepRowAnimations(true);
            this.clampStepListScrollOffset();
            this.clearStepDragState();
            this.recreateComponents();
        }
    }

    private static String getPlayerListEntryName(class_640 entry) {
        if (entry == null) { /* goto L34; */ }
        if (entry.method_2966() == null) { /* goto L34; */ }
        String name = entry.method_2966().name();
        return name == null ? "" : name.trim();
        return "";
    }

    private static <E extends Enum<E>> E cycleEnum(E current, int step) {
        E[] values = (Enum[])current.getDeclaringClass().getEnumConstants();
        int index = (current.ordinal() + step) % values.length;
        if (index < 0) {
            index = index + values.length;
        }
        return values[index];
    }

    private static double cycleRotateSpeed(double current, int step) {
        double[] tmp0 = new double[5];
        tmp0[0] = 1;
        tmp0[1] = 2;
        tmp0[2] = 3;
        tmp0[3] = 5;
        tmp0[4] = 10;
        double[] speeds = tmp0;
        int index = 0;
        int i = 0;
        while (i < speeds.length) {
            if (current <= speeds[i] + 0.0001) {
                index = i;
            } else {
                index = speeds.length - 1;
                i++;
            }
        }
        index = (index + step) % speeds.length;
        if (index < 0) {
            index = index + speeds.length;
        }
        return speeds[index];
    }

    public boolean isEditingMacro(PackUtilMacro macroToCheck) {
        if (this.originalMacro == null) { /* goto @54; */ }
        if (this.originalMacro != macroToCheck) {
            if (this.originalMacro.name == null) { /* goto @50; */ }
        }
        /* note: clearing non-empty stack before goto */
        /* goto @55; */
        L50: ;
        return macroToCheck != null ? false : false;
    }

    public void restorePosition() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.panelX = shared.getMacroEditorPanelX();
        this.panelY = shared.getMacroEditorPanelY();
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        PackUtilSharedState.get().setMacroEditorVisible(visible);
        if (!visible) { /* goto L43; */ }
        this.windowNode.restoreShowBody(!this.collapsed);
        PackUtilOverlayManager.get().bringToFront(this);
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.isWindowDragging = false;
        this.headerDragMoved = false;
        this.clearStepDragState();
        if (this.nameField != null) {
            this.nameField.setFocused(false);
        }
        if (this.loopCountField != null) {
            this.loopCountField.setFocused(false);
        }
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        int height = this.getRenderedPanelHeight();
        if (mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + height)) {
            return true;
        }
        if (this.isStepPickerOpen()) {
            int pickerX = this.getStepPickerX();
            int pickerY = this.getStepPickerY();
            int pickerW = this.getStepPickerWidth();
            int pickerH = this.getStepPickerHeight();
            if (mouseX >= (double)pickerX) {
                if (mouseX <= (double)(pickerX + pickerW)) {
                    if (mouseY >= (double)pickerY) {
                        if (mouseY <= (double)(pickerY + pickerH)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + this.theme.headerHeight()) && !this.isOverCloseButtonUi(mouseX, mouseY);
    }

    public boolean hasTextFieldFocused() {
        if (!this.visible) {
            return false;
        }
        if (this.nameField != null && this.nameField.isFocused()) {
            return true;
        }
        return this.loopCountField != null && this.loopCountField.isFocused();
    }

    public boolean wantsKeyboardCapture() {
        return this.visible && this.isBindingKey;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (this.draggingIndex >= 0 || this.pressedStepIndex >= 0) {
                this.finishStepDrag();
                return true;
            }
        }
        this.activeScrollbarDrag = 0;
        if (button == 0 && this.activeScrollbarDrag != 0) {
            this.saveState();
            return true;
        }
        if (button != 0) {
            return false;
        }
        boolean moved = this.headerDragMoved || Math.abs(mouseX - this.headerPressMouseX) >= 3 || Math.abs(mouseY - this.headerPressMouseY) >= 3 || this.panelX != this.headerPressPanelX || this.panelY != this.headerPressPanelY;
        this.isWindowDragging = false;
        this.isWindowResizing = false;
        if (moved) { /* goto L172; */ }
        if (!this.isOverHeaderUi(mouseX, mouseY)) { /* goto L172; */ }
        if (this.isOverCloseButtonUi(mouseX, mouseY)) { /* goto L172; */ }
        this.setCollapsed(!this.collapsed);
        this.saveState();
        this.headerDragMoved = false;
        return true;
    }

    public void saveState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setMacroEditorVisible(this.visible);
        shared.setMacroEditorPanelX(this.panelX);
        shared.setMacroEditorPanelY(this.panelY);
        shared.setEditingMacro(this.macro);
        this.saveLayout();
    }

    public void restoreState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.restoreLayout();
        this.visible = shared.isMacroEditorVisible();
        this.panelX = shared.getMacroEditorPanelX();
        this.panelY = shared.getMacroEditorPanelY();
        this.macro = shared.getEditingMacro();
        this.windowNode.restoreShowBody(!this.collapsed);
        this.resetStepRowAnimationState();
        if (this.visible && this.macro != null) {
            this.recreateComponents();
        }
    }

    private void init() {
        if (MC.method_22683() != null) {
            int screenWidth = PackUtilUiScale.getVirtualScreenWidth();
            int screenHeight = PackUtilUiScale.getVirtualScreenHeight();
            this.panelX = screenWidth - this.PANEL_WIDTH - this.defaultScreenInsetX();
            if (this.panelX == 0 && this.panelY == 0) {
                this.panelY = this.defaultScreenInsetY();
            }
            this.recreateComponents();
        }
    }

    private boolean isValidName(String name) {
        if (name == null) { /* goto L65; */ }
        if (name.trim().isEmpty()) { /* goto L65; */ }
        if (!name.equals(PackUtilMacroManager.get().get(name) != null ? name : "")) { /* goto @49; */ }
        return !this.isNew ? true : PackUtilMacroManager.get().get(name) == null;
        return false;
    }

    private void recreateComponents() {
        this.btnLabels.clear();
        this.btnBounds.clear();
        this.btnActions.clear();
        this.btnEnabled.clear();
        this.runBtnIndex = -1;
        int bh = this.editorButtonHeight();
        int gap = this.editorControlGap();
        int row1Y = this.panelY + this.topRowOffset();
        int deleteTopW = !this.isNew ? this.deleteButtonWidth() : 0;
        int nameFieldW = this.PANEL_WIDTH - this.contentInsetX() * 2 - (deleteTopW > 0 ? deleteTopW + gap : 0);
        if (this.nameField == null) {
            this.nameField = new PackUtilChatField(MC, this.textRenderer, this.panelX + this.contentInsetX(), row1Y, nameFieldW, this.textFieldHeight(), false);
            this.nameField.setPlaceholder(class_2561.method_43470("Macro Name"));
            this.nameField.setChangedListener(this::lambda$recreateComponents$46);
        }
        this.nameField.setX(this.panelX + this.contentInsetX());
        this.nameField.setY(row1Y);
        this.nameField.setWidth(nameFieldW);
        this.nameField.setText(this.macro.name);
        if (!this.isNew) {
            this.addBtn("Delete", this.panelX + this.PANEL_WIDTH - this.contentInsetX() - deleteTopW, row1Y, deleteTopW, bh, this::lambda$recreateComponents$47);
        }
        int row2Y = row1Y + this.secondRowGap();
        int bx = this.panelX + this.contentInsetX();
        String keyText = this.macro.keyCode == -1 ? "Bind Key" : "Key: " + GLFW.glfwGetKeyName(this.macro.keyCode, 0);
        if (keyText.equals("Key: null")) {
            keyText = "Key: " + this.macro.keyCode;
        }
        if (this.isBindingKey) {
            keyText = "Press Key...";
        }
        int keyW = PackUiText.width(this.textRenderer, keyText, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY)) + this.buttonTextPadding();
        this.addBtn(keyText, bx, row2Y, keyW, bh, this::lambda$recreateComponents$48);
        bx = bx + (keyW + gap);
        if (MacroExecutor.isRunning()) { /* goto L448; */ }
        this.addBtn("Run", bx, row2Y, this.runButtonWidth(), bh, this::handleRunButton, this.canRunMacro());
        this.runBtnIndex = this.btnLabels.size() - 1;
        bx = bx + (this.runButtonWidth() + gap);
        this.addBtn("LAN", bx, row2Y, this.lanButtonWidth(), bh, this::lambda$recreateComponents$49);
        if (PackUtilLANSync.getInstance().isInSession() && !this.isNew && this.macro != null) {
            bx = bx + (this.lanButtonWidth() + gap);
        }
        String loopText = "Once";
        if (this.loopMode == 1) {
            loopText = "Loop #";
        }
        if (this.loopMode == 2) {
            loopText = "Loop Inf";
        }
        int loopW = PackUiText.width(this.textRenderer, loopText, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY)) + this.buttonTextPadding();
        this.addBtn(loopText, bx, row2Y, loopW, bh, this::lambda$recreateComponents$50);
        bx = bx + (loopW + gap);
        if (this.loopMode != 1) { /* goto L757; */ }
        if (this.loopCountField == null) {
            this.loopCountField = new PackUtilChatField(MC, this.textRenderer, bx, row2Y + 1, this.loopCountFieldWidth(), this.loopCountFieldHeight(), false);
            this.loopCountField.setChangedListener(this::lambda$recreateComponents$51);
        }
        this.loopCountField.setX(bx);
        this.loopCountField.setY(row2Y + 1);
        this.loopCountField.setWidth(this.loopCountFieldWidth());
        this.loopCountField.setText(String.valueOf(this.macro.loopCount == -1 ? 1 : this.macro.loopCount));
        int builderButtonY = this.getStepBuilderButtonY();
        int builderGap = this.builderButtonGap();
        int builderWidth = (this.PANEL_WIDTH - this.contentInsetX() * 2 - builderGap) / 2;
        this.addBtn("Add Action", this.panelX + this.contentInsetX(), builderButtonY, builderWidth, bh, this::lambda$recreateComponents$52);
        this.addBtn("Add Conditional", this.panelX + this.contentInsetX() + builderWidth + builderGap, builderButtonY, builderWidth, bh, this::lambda$recreateComponents$53);
        int bottomY = this.getFooterButtonsY();
        bx = this.panelX + this.contentInsetX();
        boolean validName = this.isValidName(this.macro.name);
        this.addBtn("Save", bx, bottomY, this.footerPrimaryButtonWidth(), bh, this::lambda$recreateComponents$54, validName);
        bx = bx + (this.footerPrimaryButtonWidth() + this.footerButtonGap());
        this.addBtn("Cancel", bx, bottomY, this.footerPrimaryButtonWidth(), bh, this::cancel);
        bx = bx + (this.footerPrimaryButtonWidth() + this.footerButtonGap());
        this.addBtn("Undo", bx, bottomY, this.footerSecondaryButtonWidth(), bh, this::performUndo, this.canUndoHistory());
        bx = bx + (this.footerSecondaryButtonWidth() + this.footerButtonGap());
        this.addBtn("Redo", bx, bottomY, this.footerSecondaryButtonWidth(), bh, this::performRedo, this.canRedoHistory());
    }

    private void addBtn(String label, int x, int y, int w, int h, Runnable action) {
        this.addBtn(label, x, y, w, h, action, true);
    }

    private void addBtn(String label, int x, int y, int w, int h, Runnable action, boolean enabled) {
        this.btnLabels.add(label);
        int[] tmp0 = new int[4];
        tmp0[0] = x;
        tmp0[1] = y;
        tmp0[2] = w;
        tmp0[3] = h;
        this.btnBounds.add(tmp0);
        this.btnActions.add(action);
        this.btnEnabled.add(enabled);
    }

    private void updateHistoryButtonState() {
        for (int i = 0; i < this.btnLabels.size(); i++) {
            String label = (String)this.btnLabels.get(i);
            if ("Undo".equals(label)) {
                this.btnEnabled.set(i, this.canUndoHistory());
            } else {
                if (!"Redo".equals(label)) continue;
                this.btnEnabled.set(i, this.canRedoHistory());
            }
        }
    }

    private void updateRunButtonState() {
        if (this.runBtnIndex < 0 || this.runBtnIndex >= this.btnEnabled.size()) {
            return;
        }
        if (MacroExecutor.isRunning()) { /* goto L45; */ }
        this.btnEnabled.set(this.runBtnIndex, this.canRunMacro());
    }

    private void handleRunButton() {
        if (this.macro == null) {
            PackUtilClientMessaging.sendPrefixed("No macro to run!");
        } else {
            if (MacroExecutor.isRunning()) {
                MacroExecutor.stop();
                this.recreateComponents();
            } else {
                if (this.macro.actions.isEmpty()) {
                    PackUtilClientMessaging.sendPrefixed("Macro has no actions!");
                    this.recreateComponents();
                } else {
                    if (!this.canRunMacro()) {
                        PackUtilClientMessaging.sendPrefixed(this.getRunBlockedReason());
                        this.recreateComponents();
                    } else {
                        boolean hasValidName = this.macro.name != null && !this.macro.name.trim().isEmpty();
                        if (hasValidName) {
                            PackUtilMacro existingWithName = PackUtilMacroManager.get().get(this.macro.name);
                            boolean isNameConflict = this.isNew && existingWithName != null;
                            if (isNameConflict) {
                                PackUtilClientMessaging.sendPrefixed("Name already exists: " + this.macro.name);
                                return;
                            }
                            if (this.isNew) {
                                PackUtilMacroManager.get().add(this.macro);
                                this.originalMacro = PackUtilMacroManager.get().get(this.macro.name);
                                this.isNew = false;
                                this.tempSavedForRun = true;
                            } else {
                                if (!this.tempSavedForRun) {
                                    if (this.originalMacro != null) {
                                        this.originalMacroSnapshot = this.originalMacro.toTag();
                                    }
                                }
                                if (this.originalMacro != null) {
                                    this.originalMacro.fromTag(this.macro.toTag());
                                }
                                PackUtilMacroManager.get().save();
                                this.tempSavedForRun = true;
                            }
                            PackUtilMacro savedMacro = PackUtilMacroManager.get().get(this.macro.name);
                            if (savedMacro != null) {
                                savedMacro.execute();
                            } else {
                                this.macro.execute();
                            }
                        } else {
                            String originalName = this.macro.name;
                            this.macro.name = "(Unsaved)";
                            this.macro.execute();
                            this.macro.name = originalName;
                        }
                        this.recreateComponents();
                    }
                }
            }
        }
    }

    private boolean canRunMacro() {
        return this.getRunBlockedReason() == null;
    }

    private String getRunBlockedReason() {
        if (this.macro == null) {
            return "No macro to run!";
        }
        var var1 = this.macro.actions.iterator();
        while (var1.hasNext()) {
            MacroAction action = (MacroAction)var1.next();
            if (action instanceof InventoryAuditAction) {
                InventoryAuditAction auditAction = (InventoryAuditAction)action;
                if (auditAction.hasValidTargetSelection()) continue;
                return "Inventory Audit needs at least one target.";
            }
        }
        return null;
    }

    private void updateSaveButtonState() {
        this.saveBtnDirty = true;
    }

    private void updateLoopState() {
        if (this.loopMode == 0) {
            this.macro.loop = false;
        } else {
            if (this.loopMode == 1) {
                this.macro.loop = true;
            }
        }
        try {
            if (this.loopCountField != null) {
                this.macro.loopCount = Integer.parseInt(this.loopCountField.getText());
            }
        }
        catch (Exception e1) {
            this.macro.loopCount = 1;
            /* goto L89; */
            L73: ;
            this.macro.loop = true;
            this.macro.loopCount = -1;
            L89: ;
            return;
        }
    }

    public void addAction(MacroAction action) {
        this.pushStructuralHistoryStep();
        this.macro.actions.add(action);
        this.handleMacroActionsChanged();
        if (this.hasActionEditor(action)) {
            ActionEditorOverlay.getSharedOverlay().open(action, this::pushStructuralHistoryStep, this::handleMacroActionsChanged);
        }
    }

    private void save() {
        if (!this.isValidName(this.macro.name)) { /* goto L153; */ }
        if (this.isNew) {
            PackUtilMacroManager.get().add(this.macro);
        } else {
            if (this.originalMacro != null) {
                this.originalMacro.name = this.macro.name;
                this.originalMacro.description = this.macro.description;
                this.originalMacro.loop = this.macro.loop;
                this.originalMacro.loopCount = this.macro.loopCount;
                this.originalMacro.keyCode = this.macro.keyCode;
                this.originalMacro.actions.clear();
                this.originalMacro.actions.addAll(this.macro.actions);
            }
            PackUtilMacroManager.get().save();
        }
        this.close();
        L153: ;
    }

    private MacroAction createActionCopy(MacroAction original) {
        if (original == null) {
            return null;
        }
        try {
            return PackUtilMacro.createActionFromTag(original.toTag());
        }
        catch (Exception e2) {
            return null;
        }
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.saveBtnDirty) {
            this.saveBtnDirty = false;
            this.recreateComponents();
        }
        this.updateHistoryButtonState();
        this.updateRunButtonState();
        if (!this.visible) { /* goto L2256; */ }
        int panelMouseX = mouseX;
        int panelMouseY = mouseY;
        if (this.isMouseOverStepPicker(mouseX, mouseY)) {
            panelMouseX = -10000;
            panelMouseY = -10000;
        }
        String editorTitle = this.isNew ? "Create Macro" : "Edit Macro";
        boolean isRunning = !this.isNew && this.macro != null && MacroExecutor.isRunning() && MacroExecutor.getCurrentMacroName() != null && MacroExecutor.getCurrentMacroName().equals(this.macro.name);
        if (isRunning) {
            editorTitle = editorTitle + " [RUN]";
        }
        if (this.macro != null) {
            editorTitle = editorTitle + " (" + this.macro.actions.size() + " steps)";
        }
        PackUiViewport viewport = this.surface.viewport();
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed));
        if (clamped.x != this.panelX || clamped.y != this.panelY || clamped.width != this.PANEL_WIDTH || clamped.height != this.PANEL_HEIGHT) {
            this.panelX = clamped.x;
            this.panelY = clamped.y;
            this.PANEL_WIDTH = clamped.width;
            this.PANEL_HEIGHT = clamped.height;
            this.recreateComponents();
        }
        float uiMouseX = viewport.toUiX((double)mouseX);
        float uiMouseY = viewport.toUiY((double)mouseY);
        boolean active = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        boolean headerHovered = uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.PANEL_WIDTH) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
        this.windowNode.setTitle(editorTitle);
        this.windowNode.setShowBody(!this.collapsed);
        this.windowNode.setActive(active);
        this.windowNode.setHeaderHovered(headerHovered);
        int frameHeight = this.getRenderedPanelHeight();
        this.shellBody.setPreferredHeight((float)Math.max(0, frameHeight - this.theme.headerHeight()));
        this.windowNode.setBounds((float)this.panelX, (float)this.panelY, (float)this.PANEL_WIDTH, (float)frameHeight);
        this.surface.render(context, mouseX, mouseY, delta);
        this.renderPackUiHeaderControls(context, viewport, uiMouseX, uiMouseY, delta, active);
        int bodyClipTop = this.panelY + this.theme.headerHeight();
        int bodyClipBottom = this.panelY + frameHeight;
        if (bodyClipBottom <= bodyClipTop + 1) { /* goto L2256; */ }
        viewport.enableScissor(context, (float)this.panelX, (float)bodyClipTop, (float)(this.panelX + this.PANEL_WIDTH), (float)bodyClipBottom);
        this.nameField.render(context, panelMouseX, panelMouseY, delta);
        if (this.loopMode == 1) {
            if (this.loopCountField != null) {
                this.loopCountField.render(context, panelMouseX, panelMouseY, delta);
            }
        }
        if (this.isValidName(this.macro.name)) { /* goto L719; */ }
        String warning = this.macro.name.isEmpty() ? "Name Required" : "Name Taken";
        PackUiText.draw(context, this.textRenderer, warning, this.theme.fontFor(PackUiTone.BODY), -43691, this.panelX + 10, this.getFooterButtonsY() - 10, false);
        L719: ;
        builderLabelY = this.getStepBuilderLabelY();
        PackUiText.draw(context, this.textRenderer, "Step Builder", this.theme.fontFor(PackUiTone.LABEL), PackUtilColors.textSecondary(), this.panelX + 10, PackUiSizing.alignTextY(builderLabelY, this.theme.lineHeight(PackUiTone.LABEL, 1), this.theme.fontHeight(PackUiTone.LABEL), this.theme.bodyTextNudge()), false);
        int listLabelY = this.getStepListLabelY();
        int listY = this.getStepListY();
        int listHeight = this.getStepListHeight();
        int listClipTop = this.getStepListClipTop();
        int listClipBottom = this.getStepListClipBottom();
        PackUiText.draw(context, this.textRenderer, "Steps (" + this.macro.actions.size() + ")", this.theme.fontFor(PackUiTone.LABEL), PackUtilColors.textSecondary(), this.panelX + 12, PackUiSizing.alignTextY(listLabelY, this.theme.lineHeight(PackUiTone.LABEL, 1), this.theme.fontHeight(PackUiTone.LABEL), this.theme.bodyTextNudge()), false);
        this.clampStepListScrollOffset();
        PackUtilColors.drawInsetPanel(context, this.getStepListFrameX(), listY, this.getStepListFrameWidth(), listHeight, false);
        PackUtilUiScale.enableOverlayScissor(context, this.getStepListContentLeft(), listClipTop, this.getStepListContentRight(), listClipBottom);
        this.tickStepRowAnimations();
        int y = listY - this.scrollOffset;
        int activeDragIndex = this.draggingIndex;
        int activeDragTarget = this.stepDragTargetIndex;
        for (int i = 0; i < this.macro.actions.size(); i++) {
            if (i == activeDragIndex) {
            } else {
                MacroAction action = (MacroAction)this.macro.actions.get(i);
                int visualIndex = this.getShiftedVisualIndex(i, activeDragIndex, activeDragTarget);
                int actionY = y + visualIndex * this.actionRowHeight();
                if (!this.isStepRowFullyVisible(actionY)) { /* goto @1136; */ }
                StepRowMotion motion = this.findStepRowMotion(this.stepRowStableId(action));
                int animatedY = motion != null && motion.kind == PackUtilMacroEditorOverlay.StepRowMotionKind.MOVE ? this.getAnimatedStepRowY(motion, y) : actionY;
                int enterOffset = this.getStepRowMoveOffsetX(motion);
                float enterAlpha = this.getStepRowAlpha(motion);
                this.renderStepListRow(context, action, action.getDisplayName(), this.isConditionalAction(action), i, animatedY, panelMouseX, panelMouseY, enterOffset, enterAlpha, true);
            }
        }
        insertSlot = this.stepRowMotions.iterator();
        while (insertSlot.hasNext()) {
            motion = (PackUtilMacroEditorOverlay.StepRowMotion)insertSlot.next();
            if (motion.kind == PackUtilMacroEditorOverlay.StepRowMotionKind.EXIT) {
                actionY = this.getAnimatedStepRowY(motion, y);
                if (!this.isStepRowFullyVisible(actionY)) continue;
                this.renderStepListRow(context, null, motion.label, motion.conditional, motion.fromRowIndex, actionY, -10000, -10000, this.getStepRowMoveOffsetX(motion), this.getStepRowAlpha(motion), false);
            }
        }
        if (activeDragIndex < 0) { /* goto L1595; */ }
        if (activeDragIndex >= this.macro.actions.size()) { /* goto L1595; */ }
        insertSlot = this.getStepInsertSlotForTarget(activeDragIndex, activeDragTarget);
        if (insertSlot >= 0) {
            insertY = y + insertSlot * this.actionRowHeight();
            if (insertY >= listClipTop - 2) {
                if (insertY <= listClipBottom + 2) {
                    context.method_25294(this.panelX + 10, insertY - 1, this.getStepListContentRight() - 1, insertY + 1, this.theme.headerAccent());
                }
            }
        }
        draggedAction = (MacroAction)this.macro.actions.get(activeDragIndex);
        dragRowTop = this.getDraggedRowTop();
        if (!this.isStepRowFullyVisible(dragRowTop)) { /* goto L1595; */ }
        context.method_25294(this.panelX + 9, dragRowTop + 1, this.getStepListContentRight(), dragRowTop + this.actionRowHeight() - 1, -532263590);
        badgeColor = this.isConditionalAction(draggedAction) ? -30720 : -12268476;
        context.method_25294(this.panelX + 10, dragRowTop + 3, this.panelX + 13, dragRowTop + this.actionRowHeight() - 3, badgeColor);
        PackUiText.draw(context, this.textRenderer, String.valueOf(activeDragIndex + 1), this.theme.fontFor(PackUiTone.BODY), PackUtilColors.textDim(), this.panelX + 16, this.stepRowTextY(dragRowTop), false);
        nameX = this.panelX + 30;
        controlsX = this.getActionRowControlsX(draggedAction);
        maxNameW = controlsX - nameX - 8;
        displayName = PackUiText.trimToWidth(this.textRenderer, draggedAction.getDisplayName(), maxNameW, this.theme.fontFor(PackUiTone.BODY), -1);
        PackUiText.draw(context, this.textRenderer, displayName, this.theme.fontFor(PackUiTone.BODY), -1, nameX, this.stepRowTextY(dragRowTop), false);
        L1595: ;
        context.method_44380();
        /* goto L1611; */
        var var35 = null;
        context.method_44380();
        throw var35;
        L1611: ;
        this.renderWindowBodyFadeCover(context, bodyClipTop, bodyClipBottom);
        stepListScrollbar = this.getStepListScrollbarMetrics();
        PackUiScrollbar.draw(context, stepListScrollbar, stepListScrollbar.contains((double)panelMouseX, (double)panelMouseY), this.activeScrollbarDrag == 1);
        this.hoveredTooltip = null;
        if (!MacroExecutor.isRunning()) { /* goto @1727; */ }
        if (MacroExecutor.getCurrentMacro() != this.macro) {
            if (this.macro.name != null) {
                if (this.macro.name.isEmpty()) { /* goto @1727; */ }
            }
        }
        macroCurrentlyRunning = this.macro != null;
        for (ix = 0; ix < this.btnLabels.size(); ix++) {
            b = (int[])this.btnBounds.get(ix);
            enabled = ((Boolean)this.btnEnabled.get(ix)).booleanValue();
            lbl = ix == this.runBtnIndex ? macroCurrentlyRunning ? "Stop" : "Run" : (String)this.btnLabels.get(ix);
            variant = PackUiOverlayButton.Variant.SECONDARY;
            if (ix != this.runBtnIndex) { /* goto L1854; */ }
            variant = macroCurrentlyRunning ? PackUiOverlayButton.Variant.DANGER : PackUiOverlayButton.Variant.SUCCESS;
            this.drawOverlayButton(context, b[0], b[1], b[2], b[3], lbl, variant, enabled, panelMouseX, panelMouseY);
            if (panelMouseX >= b[0]) {
                if (panelMouseX < b[0] + b[2]) {
                    if (panelMouseY >= b[1]) {
                        if (panelMouseY < b[1] + b[3]) {
                            tip = this.getTooltipFor(lbl);
                            if (tip != null) {
                                this.hoveredTooltip = tip;
                                this.tooltipX = panelMouseX + 8;
                                this.tooltipY = panelMouseY + 12;
                            }
                        }
                    }
                }
            }
        }
        viewport.disableScissor(context);
        /* goto L1994; */
        var var36 = null;
        viewport.disableScissor(context);
        throw var36;
        L1994: ;
        if (!this.collapsed) {
            if (this.isStepPickerOpen()) {
                this.renderStepPicker(context, mouseX, mouseY);
            }
            if (this.hoveredTooltip != null) {
                PackUiText.interOverlayFlush(context);
                tooltipFont = this.theme.fontFor(PackUiTone.BODY);
                tw = PackUiText.width(this.textRenderer, this.hoveredTooltip, tooltipFont, PackUtilColors.textLight()) + 6;
                th = 12;
                drawX = Math.min(this.tooltipX, PackUtilUiScale.getVirtualScreenWidth() - tw - 4);
                drawY = Math.min(this.tooltipY, PackUtilUiScale.getVirtualScreenHeight() - th - 4);
                context.method_25294(drawX - 2, drawY - 2, drawX + tw, drawY + th, PackUtilColors.tooltipBg());
                context.method_25294(drawX - 3, drawY - 3, drawX + tw + 1, drawY - 2, PackUtilColors.subPanelBorder());
                context.method_25294(drawX - 3, drawY + th, drawX + tw + 1, drawY + th + 1, PackUtilColors.subPanelBorder());
                context.method_25294(drawX - 3, drawY - 2, drawX - 2, drawY + th, PackUtilColors.subPanelBorder());
                context.method_25294(drawX + tw, drawY - 2, drawX + tw + 1, drawY + th, PackUtilColors.subPanelBorder());
                PackUiText.draw(context, this.textRenderer, this.hoveredTooltip, tooltipFont, PackUtilColors.textLight(), drawX + 2, drawY + 1, false);
            }
        }
    }

    private void renderPackUiHeaderControls(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta, boolean active) {
        this.closeVisibility = this.animateHeader(this.closeVisibility, 1f, delta);
        this.closeHover = this.animateHeader(this.closeHover, this.isOverCloseButtonUi((double)uiMouseX, (double)uiMouseY) ? 1f : 0f, delta);
        viewport.push(context);
        try {
            int arrowX = this.collapseArrowX();
            int closeX = this.closeButtonX();
            int controlY = this.controlButtonY();
            this.drawPackUiCollapseArrow(context, arrowX, controlY, active);
            this.drawPackUiCloseButton(context, closeX, controlY, 12, 12, this.closeHover, active, this.closeVisibility);
        }
        finally {
            viewport.pop(context);
            throw var10;
        }
    }

    private float animateHeader(float current, float target, float delta) {
        return PackUiHeaderControls.animate(current, target, delta);
    }

    private void drawPackUiPopupFrame(class_332 context, int x, int y, int width, int height) {
        PackUiBannerRenderer.drawPopupFrame(context, this.theme, x, y, width, height);
    }

    private void drawPackUiCollapseArrow(class_332 context, int x, int y, boolean active) {
        PackUiHeaderControls.drawAnimatedArrow(context, x, y + 1, 10, this.collapsed ? 0f : 1f, active ? 1f : 0.56f);
    }

    private void drawPackUiCloseButton(class_332 context, int x, int y, int width, int height, float hover, boolean active, float visibility) {
        PackUiHeaderControls.drawCloseButton(context, x, y, width, height, hover, active, visibility);
    }

    private void drawStepRowControlButton(class_332 context, int x, int y, int width, int height, boolean hovered, boolean danger, class_2960 icon, String label) {
        PackUiOverlayButton button = this.createStepRowControlButtonView(x, y, width, height, danger, icon == null ? label : "");
        PackUiOverlayButton.renderStyled(context, this.textRenderer, button, hovered ? x + width / 2 : -1000, hovered ? y + height / 2 : -1000);
        if (icon == null) { /* goto L211; */ }
        int iconSize = Math.max(8, Math.min(10, Math.min(width, height) - 4));
        int iconX = x + Math.max(1, (width - iconSize) / 2);
        int iconY = y + Math.max(1, (height - iconSize) / 2);
        if (PackUiControlGlyphs.isCloseIcon(icon) || PackUiControlGlyphs.isChevronIcon(icon)) {
            PackUiControlGlyphs.drawKnownIcon(context, icon, iconX, iconY, iconSize, danger ? -16449 : -726037, danger ? -867558881 : -1254484968, 1f);
        } else {
            context.method_70845(icon, iconX, iconY, iconX + iconSize, iconY + iconSize, 0f, 1f, 0f, 1f);
        }
    }

    private String stepPickerFeedbackKey(PackUtilMacroEditorOverlay.StepPickerCategory category, PackUtilMacroEditorOverlay.StepPickerEntry entry) {
        String modeKey = this.stepPickerMode == null ? "none" : this.stepPickerMode.name();
        return "macro-step-picker:" + modeKey + ":" + category.id + ":" + entry.label;
    }

    private void drawStepPickerCard(class_332 context, PackUtilMacroEditorOverlay.StepPickerCategory category, PackUtilMacroEditorOverlay.StepPickerEntry entry, int x, int y, int width, int height, boolean hovered, int mouseX, int mouseY) {
        PackUiButtonFeedback feedback = PackUiButtonFeedback.forKey(this.stepPickerFeedbackKey(category, entry));
        float hover = feedback.update(hovered, hovered && PackUiButtonFeedback.isPrimaryPointerDown(), (float)(mouseX - x), (float)(mouseY - y), (float)width, (float)height);
        float clickGlow = feedback.clickGlowProgress();
        float emphasis = Math.min(1f, hover * 0.85f + clickGlow * 0.55f);
        int categoryRgb = category.color & 16777215;
        int fillColor = PackUiSizing.lerpColor(134217728, 570425344 | categoryRgb, emphasis);
        int borderColor = PackUiSizing.lerpColor(category.color, -1, Math.min(0.22f, hover * 0.1f + clickGlow * 0.18f));
        int textColor = PackUiSizing.lerpColor(this.theme.color(PackUiTone.BODY), -1, Math.min(0.32f, hover * 0.12f + clickGlow * 0.2f));
        context.method_25294(x, y, x + width, y + height, fillColor);
        context.method_25294(x, y, x + width, y + 1, borderColor);
        context.method_25294(x, y + height - 1, x + width, y + height, borderColor);
        context.method_25294(x, y, x + 1, y + height, borderColor);
        context.method_25294(x + width - 1, y, x + width, y + height, borderColor);
        if (emphasis > 0f) {
            int hoverTint = (int)Math.min(30f, hover * 18f + clickGlow * 10f) << 24 | categoryRgb;
            context.method_25294(x + 1, y + 1, x + width - 1, y + height - 1, hoverTint);
        }
        feedback.render(context, x + 1, y + 1, Math.max(0, width - 2), Math.max(0, height - 2), categoryRgb, PackUiSizing.lerpColor(category.color, -1, 0.55f) & 16777215, 1f);
        label = PackUiText.trimToWidth(this.textRenderer, entry.label, Math.max(0, width - 8), this.theme.fontFor(PackUiTone.BODY), textColor);
        int labelW = PackUiText.width(this.textRenderer, label, this.theme.fontFor(PackUiTone.BODY), textColor);
        int labelX = x + Math.max(3, (width - labelW) / 2);
        int labelY = PackUiSizing.alignTextY(y, height, this.theme.fontHeight(PackUiTone.BODY), this.theme.buttonTextNudge());
        PackUiText.draw(context, this.textRenderer, label, this.theme.fontFor(PackUiTone.BODY), textColor, labelX, labelY, false);
    }

    private void renderStepListRow(class_332 context, MacroAction action, String label, boolean conditional, int actionIndex, int actionY, int mouseX, int mouseY, int xOffset, float alpha, boolean interactive) {
        int rowLeft = this.panelX + 9 + xOffset;
        int rowRight = this.getStepListContentRight() + xOffset;
        boolean hoverRow = interactive && mouseX >= rowLeft - 1 && mouseX <= rowRight + 1 && mouseY >= actionY && mouseY < actionY + this.actionRowHeight();
        int bgColor = hoverRow ? PackUtilColors.rowHover() : PackUtilColors.rowNormal();
        context.method_25294(rowLeft, actionY + 1, rowRight, actionY + this.actionRowHeight() - 1, PackUiRenderContext.applyAlpha(bgColor, alpha));
        int badgeColor = conditional ? -30720 : -12268476;
        context.method_25294(this.panelX + 10 + xOffset, actionY + 3, this.panelX + 13 + xOffset, actionY + this.actionRowHeight() - 3, PackUiRenderContext.applyAlpha(badgeColor, alpha));
        PackUiText.draw(context, this.textRenderer, String.valueOf(actionIndex + 1), this.theme.fontFor(PackUiTone.BODY), PackUiRenderContext.applyAlpha(PackUtilColors.textDim(), alpha), this.panelX + 16 + xOffset, this.stepRowTextY(actionY), false);
        int nameX = this.panelX + 30 + xOffset;
        int controlsX = this.getActionRowControlsX(action) + xOffset;
        int contentRight = this.getStepListContentRightForAction(action) + xOffset;
        int maxNameW = Math.max(1, contentRight - nameX - 8);
        String displayName = PackUiText.trimToWidth(this.textRenderer, label, maxNameW, this.theme.fontFor(PackUiTone.BODY), PackUiRenderContext.applyAlpha(-1, alpha));
        PackUiText.draw(context, this.textRenderer, displayName, this.theme.fontFor(PackUiTone.BODY), PackUiRenderContext.applyAlpha(-1, alpha), nameX, this.stepRowTextY(actionY), false);
        if (!interactive) { /* goto L723; */ }
        if (action == null) { /* goto L723; */ }
        int controlY = this.stepRowControlY(actionY);
        this.drawStepRowControlButton(context, controlsX, controlY, this.stepRowControlSize(), this.stepRowControlSize(), mouseX >= controlsX && mouseX < controlsX + this.stepRowControlSize() && mouseY >= controlY && mouseY < controlY + this.stepRowControlSize(), false, PackUiAssets.ICON_WINDOW_CHEVRON_UP, null);
        int cx = controlsX + this.stepRowControlStride();
        this.drawStepRowControlButton(context, cx, controlY, this.stepRowControlSize(), this.stepRowControlSize(), mouseX >= cx && mouseX < cx + this.stepRowControlSize() && mouseY >= controlY && mouseY < controlY + this.stepRowControlSize(), false, PackUiAssets.ICON_WINDOW_CHEVRON_DOWN, null);
        cx = cx + this.stepRowControlStride();
        this.drawStepRowControlButton(context, cx, controlY, this.stepRowControlSize(), this.stepRowControlSize(), mouseX >= cx && mouseX < cx + this.stepRowControlSize() && mouseY >= controlY && mouseY < controlY + this.stepRowControlSize(), false, null, "D");
        cx = cx + this.stepRowControlStride();
        boolean hasEditor = this.hasActionEditor(action);
        if (!hasEditor) { /* goto L658; */ }
        this.drawStepRowControlButton(context, cx, controlY, this.stepRowControlSize(), this.stepRowControlSize(), mouseX >= cx && mouseX < cx + this.stepRowControlSize() && mouseY >= controlY && mouseY < controlY + this.stepRowControlSize(), false, null, "E");
        cx = cx + this.stepRowControlStride();
        L658: ;
        this.drawStepRowControlButton(context, cx, controlY, this.stepRowControlSize(), this.stepRowControlSize(), mouseX >= cx && mouseX < cx + this.stepRowControlSize() && mouseY >= controlY && mouseY < controlY + this.stepRowControlSize(), true, PackUiAssets.ICON_WINDOW_CLOSE, null);
    }

    private void triggerStepRowIconPress(double mouseX, double mouseY, int button, int x, int y, int size, boolean danger, class_2960 icon) {
        PackUiOverlayButton preview = this.createStepRowControlButtonView(x, y, size, size, danger, "");
        PackUiOverlayButton.fireIfHit(preview, mouseX, mouseY, button);
    }

    private void triggerStepRowTextPress(double mouseX, double mouseY, int button, int x, int y, int width, int height, boolean danger, String label) {
        PackUiOverlayButton preview = this.createStepRowControlButtonView(x, y, width, height, danger, label);
        PackUiOverlayButton.fireIfHit(preview, mouseX, mouseY, button);
    }

    private void drawEditorListText(class_332 context, String text, int x, int y, int color) {
        PackUiText.draw(context, this.textRenderer, text, this.theme.fontFor(PackUiTone.BODY), color, x, y, false);
    }

    private void drawEditorListLabel(class_332 context, String text, int x, int y, int color) {
        PackUiText.draw(context, this.textRenderer, text, this.theme.fontFor(PackUiTone.LABEL), color, x, y, false);
    }

    private void drawEditorListDeleteButton(class_332 context, int x, int y, boolean hovered) {
        this.drawStepRowControlButton(context, x, y, 14, 12, hovered, true, PackUiAssets.ICON_WINDOW_CLOSE, null);
    }

    private void drawEditorSelectableRegistryRow(class_332 context, int x, int y, int width, String label, boolean hovered, boolean selected) {
        int bg = selected ? -14534613 : hovered ? PackUtilColors.rowHover() : PackUtilColors.rowNormal();
        context.method_25294(x, y, x + width, y + 12, bg);
        int textX = x + 3;
        this.drawEditorListText(context, label, textX, y + 2, selected ? PackUtilColors.rowSelectedText() : PackUtilColors.textLight());
    }

    private boolean isOverHeaderUi(double mouseX, double mouseY) {
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + this.theme.headerHeight());
    }

    private boolean isOverCloseButtonUi(double mouseX, double mouseY) {
        return PackUiHeaderControls.isCloseHit(this.closeVisibility, mouseX, mouseY, this.closeButtonX(), this.controlButtonY(), 12);
    }

    private int controlButtonY() {
        return PackUiHeaderControls.controlY(this.panelY, this.theme.headerHeight(), 12);
    }

    private int closeButtonX() {
        return PackUiHeaderControls.closeX(this.panelX, this.PANEL_WIDTH, 12, 2);
    }

    private int collapseArrowX() {
        return PackUiHeaderControls.expandedArrowX(this.closeButtonX(), 3, 10);
    }

    private int getRenderedPanelHeight() {
        this.shellBody.setPreferredHeight((float)Math.max(0, this.PANEL_HEIGHT - this.theme.headerHeight()));
        this.windowNode.setShowBody(!this.collapsed);
        PackUiRenderContext metrics = this.surface.measurementContext();
        if (metrics != null) { /* goto L79; */ }
        return this.collapsed ? this.theme.headerHeight() : this.PANEL_HEIGHT;
        return Math.max(this.theme.headerHeight(), Math.round(this.windowNode.preferredHeight(metrics, (float)this.PANEL_WIDTH)));
    }

    private void renderWindowBodyFadeCover(class_332 context, int bodyClipTop, int bodyClipBottom) {
        if (bodyClipBottom <= bodyClipTop) {
            return;
        }
        float coverAlpha = 1f - this.windowNode.bodyFadeAlpha();
        if (coverAlpha <= 0.001f) {
            return;
        }
        float easedCover = 1f - (float)Math.pow((double)(1f - coverAlpha), 2);
        float fadeAlpha = Math.min(0.96f, 0.1f + easedCover * 0.86f);
        context.method_25294(this.panelX + 1, bodyClipTop, this.panelX + this.PANEL_WIDTH - 1, bodyClipBottom, PackUiRenderContext.applyAlpha(-704050933, fadeAlpha));
    }

    private void renderStepPicker(class_332 context, int mouseX, int mouseY) {
        int pickerX = this.getStepPickerX();
        int pickerY = this.getStepPickerY();
        int pickerW = this.getStepPickerWidth();
        int pickerH = this.getStepPickerHeight();
        int closeX = this.getStepPickerCloseX();
        int closeY = this.getStepPickerCloseY();
        boolean hoverClose = mouseX >= closeX - 2 && mouseX <= closeX + 10 && mouseY >= closeY - 2 && mouseY <= closeY + 10;
        this.drawPackUiPopupFrame(context, pickerX, pickerY, pickerW, pickerH);
        String title = this.stepPickerMode == PackUtilMacroEditorOverlay.StepPickerMode.ACTION ? "Add Action" : "Add Conditional";
        int pickerTitleY = PackUiSizing.alignTextY(pickerY, 16, this.theme.fontHeight(PackUiTone.LABEL), this.theme.bodyTextNudge());
        PackUiText.draw(context, this.textRenderer, title, this.theme.fontFor(PackUiTone.LABEL), this.theme.color(PackUiTone.BODY), pickerX + 10, pickerTitleY, false);
        this.drawPackUiCloseButton(context, closeX, closeY, 12, 12, hoverClose ? 1f : 0f, true, 1f);
        int contentX = pickerX + 6;
        int contentY = pickerY + 22;
        int contentW = pickerW - 12;
        int contentH = pickerH - 28;
        int gridX = contentX;
        int gridY = contentY;
        int gridH = contentH;
        List<PackUtilMacroEditorOverlay.StepPickerSectionLayout> layouts = this.buildStepPickerLayouts(contentX, contentY - this.stepPickerScrollOffset, contentW);
        int contentHeight = this.getStepPickerContentHeight();
        int maxScroll = Math.max(0, contentHeight - contentH);
        this.stepPickerScrollOffset = Math.max(0, Math.min(this.stepPickerScrollOffset, maxScroll));
        PackUtilUiScale.enableOverlayScissor(context, contentX, contentY, contentX + contentW, contentY + contentH);
        try {
            Metrics stepPickerScrollbar = layouts.iterator();
            while (stepPickerScrollbar.hasNext()) {
                StepPickerSectionLayout section = (PackUtilMacroEditorOverlay.StepPickerSectionLayout)stepPickerScrollbar.next();
                int sectionTop = section.headerY;
                int sectionBottom = section.bottomY;
                if (sectionBottom >= gridY) {
                    if (!sectionTop <= gridY + gridH) continue;
                    PackUiText.draw(context, this.textRenderer, section.category.label, this.theme.fontFor(PackUiTone.LABEL), section.category.color, gridX, PackUiSizing.alignTextY(sectionTop, this.stepPickerSectionLabelHeight(), this.theme.fontHeight(PackUiTone.LABEL), 0), false);
                }
                int hintY = section.buttons.iterator();
                while (hintY.hasNext()) {
                    StepPickerButtonLayout button = (PackUtilMacroEditorOverlay.StepPickerButtonLayout)hintY.next();
                    int cardX = button.x;
                    int cardY = button.y;
                    int cardW = button.width;
                    int cardH = button.height;
                    if (cardY + cardH < gridY) { /* goto @607; */ }
                    if (cardY > gridY + gridH) { /* goto @607; */ }
                    boolean hovered = mouseX >= cardX && mouseX < cardX + cardW && mouseY >= cardY && mouseY < cardY + cardH;
                    this.drawStepPickerCard(context, section.category, button.entry, cardX, cardY, cardW, cardH, hovered, mouseX, mouseY);
                    if (hovered) {
                        this.hoveredTooltip = button.entry.description;
                        this.tooltipX = mouseX + 8;
                        this.tooltipY = mouseY + 12;
                    }
                }
            }
        }
        finally {
            context.method_44380();
            throw var34;
        }
        stepPickerScrollbar = this.getStepPickerScrollbarMetrics();
        PackUiScrollbar.draw(context, stepPickerScrollbar, stepPickerScrollbar.contains((double)mouseX, (double)mouseY), this.activeScrollbarDrag == 2);
        if (maxScroll > 0) {
            hint = "Scroll for more";
            hintW = PackUiText.width(this.textRenderer, hint, this.theme.fontFor(PackUiTone.BODY), PackUtilColors.textDim());
            hintX = Math.max(pickerX + 72, pickerX + pickerW - hintW - 28);
            hintY = pickerY + 8;
            PackUiText.draw(context, this.textRenderer, hint, this.theme.fontFor(PackUiTone.BODY), PackUtilColors.textDim(), hintX, hintY + 1, false);
        }
    }

    private int stepPickerSectionLabelHeight() {
        return Math.max(12, this.theme.fontHeight(PackUiTone.LABEL));
    }

    private boolean handleStepPickerClick(double mouseX, double mouseY, int button) {
        int pickerX = this.getStepPickerX();
        int pickerY = this.getStepPickerY();
        int pickerW = this.getStepPickerWidth();
        int pickerH = this.getStepPickerHeight();
        int closeX = this.getStepPickerCloseX();
        int closeY = this.getStepPickerCloseY();
        boolean inside = mouseX >= (double)pickerX && mouseX < (double)(pickerX + pickerW) && mouseY >= (double)pickerY && mouseY < (double)(pickerY + pickerH);
        if (!inside) {
            this.closeStepPicker();
            return true;
        }
        if (button != 0) {
            return true;
        }
        this.closeStepPicker();
        if (mouseX >= (double)closeX && mouseX < (double)(closeX + 12) && mouseY >= (double)closeY && mouseY < (double)(closeY + 12)) {
            return true;
        }
        int contentX = pickerX + 6;
        int contentY = pickerY + 22;
        int contentW = pickerW - 12;
        int contentH = pickerH - 28;
        if (mouseX < (double)contentX) { /* goto L485; */ }
        if (mouseX >= (double)(contentX + contentW)) { /* goto L485; */ }
        if (mouseY < (double)contentY) { /* goto L485; */ }
        if (mouseY >= (double)(contentY + contentH)) { /* goto L485; */ }
        Metrics stepPickerScrollbar = this.getStepPickerScrollbarMetrics();
        this.activeScrollbarDrag = 2;
        if (stepPickerScrollbar.hasScroll() && stepPickerScrollbar.contains((double)(int)mouseX, (double)(int)mouseY)) {
            this.scrollbarGrabOffset = Math.max(0, (int)mouseY - stepPickerScrollbar.thumbY());
            this.stepPickerScrollOffset = PackUiScrollbar.scrollFromThumb(stepPickerScrollbar, (double)(int)mouseY, this.scrollbarGrabOffset);
            return true;
        }
        var var18 = this.buildStepPickerLayouts(contentX, contentY - this.stepPickerScrollOffset, contentW).iterator();
        while (var18.hasNext()) {
            StepPickerSectionLayout section = (PackUtilMacroEditorOverlay.StepPickerSectionLayout)var18.next();
            var var20 = section.buttons.iterator();
            while (var20.hasNext()) {
                StepPickerButtonLayout buttonLayout = (PackUtilMacroEditorOverlay.StepPickerButtonLayout)var20.next();
                int cardX = buttonLayout.x;
                int cardY = buttonLayout.y;
                int cardW = buttonLayout.width;
                int cardH = buttonLayout.height;
                if (mouseX >= (double)cardX) {
                    if (mouseX < (double)(cardX + cardW)) {
                        if (mouseY >= (double)cardY) {
                            if (mouseY < (double)(cardY + cardH)) {
                                PackUiButtonFeedback.forKey(this.stepPickerFeedbackKey(section.category, buttonLayout.entry)).triggerPress((float)(mouseX - (double)cardX), (float)(mouseY - (double)cardY), (float)cardW, (float)cardH);
                                this.closeStepPicker();
                                buttonLayout.entry.action.run();
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return true;
        L485: ;
        return true;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        if (button == 0) {
            if (this.isOverHeaderUi(mouseX, mouseY)) {
                this.close();
                if (this.isOverCloseButtonUi(mouseX, mouseY) && this.closeVisibility > 0.01f) {
                    return true;
                }
                this.isWindowDragging = true;
                this.headerDragMoved = false;
                this.dragOffsetX = mouseX - (double)this.panelX;
                this.dragOffsetY = mouseY - (double)this.panelY;
                this.headerPressMouseX = mouseX;
                this.headerPressMouseY = mouseY;
                this.headerPressPanelX = this.panelX;
                this.headerPressPanelY = this.panelY;
                return true;
            }
        }
        if (this.collapsed) {
            return false;
        }
        if (this.isStepPickerOpen()) {
            return this.handleStepPickerClick(mouseX, mouseY, button);
        }
        class_11910 mouseInput = new class_11910(button, 0);
        class_11909 click = new class_11909(mouseX, mouseY, mouseInput);
        boolean fieldClicked = false;
        if (this.nameField.mouseClicked(click, false)) {
            this.nameField.setFocused(true);
            if (this.loopCountField != null) {
                this.loopCountField.setFocused(false);
            }
            fieldClicked = true;
        } else {
            if (this.loopMode == 1) {
                if (this.loopCountField != null) {
                    if (this.loopCountField.mouseClicked(click, false)) {
                        this.loopCountField.setFocused(true);
                        this.nameField.setFocused(false);
                        fieldClicked = true;
                    }
                }
            }
        }
        if (fieldClicked) {
            return true;
        }
        this.nameField.setFocused(false);
        if (this.loopCountField != null) {
            this.loopCountField.setFocused(false);
        }
        this.updateHistoryButtonState();
        for (int i = 0; i < this.btnLabels.size(); i++) {
            int[] b = (int[])this.btnBounds.get(i);
            if (mouseX < (double)b[0]) { /* goto L582; */ }
            if (mouseX >= (double)(b[0] + b[2])) { /* goto L582; */ }
            if (mouseY < (double)b[1]) { /* goto L582; */ }
            if (mouseY >= (double)(b[1] + b[3])) { /* goto L582; */ }
            boolean enabled = ((Boolean)this.btnEnabled.get(i)).booleanValue();
            if (!MacroExecutor.isRunning()) { /* goto @453; */ }
            if (MacroExecutor.getCurrentMacro() != this.macro) {
                if (this.macro.name != null) {
                    if (this.macro.name.isEmpty()) { /* goto @453; */ }
                }
            }
            boolean macroCurrentlyRunning = this.macro != null;
            String label = i == this.runBtnIndex ? macroCurrentlyRunning ? "Stop" : "Run" : (String)this.btnLabels.get(i);
            Variant variant = PackUiOverlayButton.Variant.SECONDARY;
            if (i != this.runBtnIndex) { /* goto L528; */ }
            variant = macroCurrentlyRunning ? PackUiOverlayButton.Variant.DANGER : PackUiOverlayButton.Variant.SUCCESS;
            PackUiOverlayButton buttonView = this.createOverlayButton(b[0], b[1], b[2], b[3], label, variant, enabled, (Runnable)this.btnActions.get(i));
            PackUiOverlayButton.fireIfHit(buttonView, mouseX, mouseY, button);
            return true;
        }
        listY = this.getStepListY();
        listHeight = this.getStepListHeight();
        if (mouseY >= (double)listY) {
            if (mouseY <= (double)(listY + listHeight)) {
                if (mouseX >= (double)this.getStepListFrameX()) {
                    if (mouseX <= (double)(this.getStepListFrameX() + this.getStepListFrameWidth())) {
                        stepListScrollbar = this.getStepListScrollbarMetrics();
                        this.activeScrollbarDrag = 1;
                        if (button == 0 && stepListScrollbar.hasScroll() && stepListScrollbar.contains((double)(int)mouseX, (double)(int)mouseY)) {
                            this.scrollbarGrabOffset = Math.max(0, (int)mouseY - stepListScrollbar.thumbY());
                            this.scrollOffset = this.quantizeScrollOffset(PackUiScrollbar.scrollFromThumb(stepListScrollbar, (double)(int)mouseY, this.scrollbarGrabOffset), this.actionRowHeight(), stepListScrollbar.maxScroll());
                            return true;
                        }
                        y = listY - this.scrollOffset;
                        controlSize = this.stepRowControlSize();
                        controlStride = this.stepRowControlStride();
                        index = (int)((mouseY - (double)y) / (double)this.actionRowHeight());
                        if (index >= 0) {
                            if (index < this.macro.actions.size()) {
                                MacroAction action = (MacroAction)this.macro.actions.get(index);
                                int actionY = y + index * this.actionRowHeight();
                                if (!this.isStepRowFullyVisible(actionY)) {
                                    return true;
                                }
                                int controlY = this.stepRowControlY(actionY);
                                int cx = this.getActionRowControlsX(action);
                                if (mouseX >= (double)cx) {
                                    if (mouseX < (double)(cx + controlSize)) {
                                        this.triggerStepRowIconPress(mouseX, mouseY, button, cx, controlY, controlSize, false, PackUiAssets.ICON_WINDOW_CHEVRON_UP);
                                        if (index > 0) {
                                            this.pushStructuralHistoryStep();
                                            Collections.swap(this.macro.actions, index, index - 1);
                                            this.handleMacroActionsChanged();
                                        }
                                        return true;
                                    }
                                }
                                cx = cx + controlStride;
                                if (mouseX >= (double)cx) {
                                    if (mouseX < (double)(cx + controlSize)) {
                                        this.triggerStepRowIconPress(mouseX, mouseY, button, cx, controlY, controlSize, false, PackUiAssets.ICON_WINDOW_CHEVRON_DOWN);
                                        if (index < this.macro.actions.size() - 1) {
                                            this.pushStructuralHistoryStep();
                                            Collections.swap(this.macro.actions, index, index + 1);
                                            this.handleMacroActionsChanged();
                                        }
                                        return true;
                                    }
                                }
                                cx = cx + controlStride;
                                this.triggerStepRowTextPress(mouseX, mouseY, button, cx, controlY, controlSize, controlSize, false, "D");
                                if (mouseX >= (double)cx && mouseX < (double)(cx + controlSize)) {
                                    this.duplicateAction(index);
                                    return true;
                                }
                                cx = cx + controlStride;
                                this.triggerStepRowTextPress(mouseX, mouseY, button, cx, controlY, controlSize, controlSize, false, "E");
                                if (mouseX >= (double)cx && mouseX < (double)(cx + controlSize) && this.hasActionEditor(action)) {
                                    MacroAction editTarget = action;
                                    ActionEditorOverlay.getSharedOverlay().open(editTarget, this::pushStructuralHistoryStep, this::handleMacroActionsChanged);
                                    return true;
                                }
                                if (this.hasActionEditor(action)) {
                                    cx = cx + controlStride;
                                }
                                this.triggerStepRowIconPress(mouseX, mouseY, button, cx, controlY, controlSize, true, PackUiAssets.ICON_WINDOW_CLOSE);
                                if (mouseX >= (double)cx && mouseX < (double)(cx + controlSize)) {
                                    this.pushStructuralHistoryStep();
                                    this.macro.actions.remove(index);
                                    this.handleMacroActionsChanged();
                                    return true;
                                }
                                if (button == 0) {
                                    if (mouseX < (double)this.getStepListContentRight()) {
                                        this.beginStepDragPress(index, mouseX, mouseY);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private void duplicateAction(int index) {
        if (index >= 0) {
            if (index < this.macro.actions.size()) {
                MacroAction original = (MacroAction)this.macro.actions.get(index);
                this.pushStructuralHistoryStep();
                class_2487 tag = original.toTag();
                MacroAction copy = PackUtilMacro.createActionFromTag(tag);
                if (copy != null) {
                    this.macro.actions.add(index + 1, copy);
                    this.handleMacroActionsChanged();
                }
            }
        }
    }

    private String getTooltipFor(String label) {
        String clean = label.replaceAll("Ã‚Â§.", "");
        var var3 = clean;
        int var4 = -1;
        switch (var3.hashCode()) {
            case 2569629::
                if (!var3.equals("Save")) { /* goto @1398; */ }
                var4 = 0;
                /* goto @1398; */
            case 82539::
                if (!var3.equals("Run")) { /* goto @1398; */ }
                var4 = 1;
                /* goto @1398; */
            case 2587682::
                if (!var3.equals("Stop")) { /* goto @1398; */ }
                var4 = 2;
                /* goto @1398; */
            case -1766691115::
                if (!var3.equals("Add Action")) { /* goto @1398; */ }
                var4 = 3;
                /* goto @1398; */
            case -668452537::
                if (!var3.equals("Add Conditional")) { /* goto @1398; */ }
                var4 = 4;
                /* goto @1398; */
            case 2641156::
                if (!var3.equals("Undo")) { /* goto @1398; */ }
                var4 = 5;
                /* goto @1398; */
            case 2543134::
                if (!var3.equals("Redo")) { /* goto @1398; */ }
                var4 = 6;
                /* goto @1398; */
            case 2099064::
                if (!var3.equals("Chat")) { /* goto @1398; */ }
                var4 = 7;
                /* goto @1398; */
            case 65915235::
                if (!var3.equals("Delay")) { /* goto @1398; */ }
                var4 = 8;
                /* goto @1398; */
            case -1911998296::
                if (!var3.equals("Packet")) { /* goto @1398; */ }
                var4 = 9;
                /* goto @1398; */
            case -1806735813::
                if (!var3.equals("Item Click")) { /* goto @1398; */ }
                var4 = 10;
                /* goto @1398; */
            case -1706223897::
                if (!var3.equals("Mouse Clk")) { /* goto @1398; */ }
                var4 = 11;
                /* goto @1398; */
            case -1841313413::
                if (!var3.equals("Rotate")) { /* goto @1398; */ }
                var4 = 12;
                /* goto @1398; */
            case -277882292::
                if (!var3.equals("Use Item")) { /* goto @1398; */ }
                var4 = 13;
                /* goto @1398; */
            case -441581285::
                if (!var3.equals("Open Inv")) { /* goto @1398; */ }
                var4 = 14;
                /* goto @1398; */
            case 2579998::
                if (!var3.equals("Slot")) { /* goto @1398; */ }
                var4 = 15;
                /* goto @1398; */
            case 2138895::
                if (!var3.equals("Drop")) { /* goto @1398; */ }
                var4 = 16;
                /* goto @1398; */
            case 1519903443::
                if (!var3.equals("Close GUI")) { /* goto @1398; */ }
                var4 = 17;
                /* goto @1398; */
            case 2590131::
                if (!var3.equals("Swap")) { /* goto @1398; */ }
                var4 = 18;
                /* goto @1398; */
            case -1514072205::
                if (!var3.equals("Wait HP")) { /* goto @1398; */ }
                var4 = 19;
                /* goto @1398; */
            case 16886306::
                if (!var3.equals("Wait Block")) { /* goto @1398; */ }
                var4 = 20;
                /* goto @1398; */
            case 308410542::
                if (!var3.equals("Wait Pkt")) { /* goto @1398; */ }
                var4 = 21;
                /* goto @1398; */
            case 970591966::
                if (!var3.equals("Wait Item")) { /* goto @1398; */ }
                var4 = 22;
                /* goto @1398; */
            case -1514034330::
                if (!var3.equals("WaitGUI")) { /* goto @1398; */ }
                var4 = 23;
                /* goto @1398; */
            case 308401168::
                if (!var3.equals("Wait GUI")) { /* goto @1398; */ }
                var4 = 24;
                /* goto @1398; */
            case 1868154686::
                if (!var3.equals("Tick Sync")) { /* goto @1398; */ }
                var4 = 25;
                /* goto @1398; */
            case -264497096::
                if (!var3.equals("Rev Sync")) { /* goto @1398; */ }
                var4 = 26;
                /* goto @1398; */
            case 130959204::
                if (!var3.equals("Srv Sync")) { /* goto @1398; */ }
                var4 = 27;
                /* goto @1398; */
            case 68910259::
                if (!var3.equals("Go To")) { /* goto @1398; */ }
                var4 = 28;
                /* goto @1398; */
            case -958933862::
                if (!var3.equals("Disconn")) { /* goto @1398; */ }
                var4 = 29;
                /* goto @1398; */
            case -617568759::
                if (!var3.equals("NBT Book")) { /* goto @1398; */ }
                var4 = 30;
                /* goto @1398; */
            case 308405358::
                if (!var3.equals("Wait LAN")) { /* goto @1398; */ }
                var4 = 31;
                /* goto @1398; */
            case -1984916852::
                if (!var3.equals("Module")) { /* goto @1398; */ }
                var4 = 32;
                /* goto @1398; */
            case 80029428::
                if (!var3.equals("Sneak")) { /* goto @1398; */ }
                var4 = 33;
                /* goto @1398; */
            case 2320462::
                if (!var3.equals("Jump")) { /* goto @1398; */ }
                var4 = 34;
                /* goto @1398; */
            case -1811812806::
                if (!var3.equals("Sprint")) { /* goto @1398; */ }
                var4 = 35;
                /* goto @1398; */
            case 2404337::
                if (!var3.equals("Move")) { /* goto @1398; */ }
                var4 = 36;
                /* goto @1398; */
            case 2014370132::
                if (!var3.equals("Look At")) { /* goto @1398; */ }
                var4 = 37;
                /* goto @1398; */
            case -1850664517::
                if (!var3.equals("Repeat")) { /* goto @1398; */ }
                var4 = 38;
                /* goto @1398; */
            case -804295864::
                if (!var3.equals("Open Cont")) { /* goto @1398; */ }
                var4 = 39;
                /* goto @1398; */
            case 2043603644::
                if (!var3.equals("Desync")) { /* goto @1398; */ }
                var4 = 40;
                /* goto @1398; */
            case -1960885798::
                if (!var3.equals("Cls w/o Pkt")) { /* goto @1398; */ }
                var4 = 41;
                /* goto @1398; */
            case 1996235881::
                if (!var3.equals("Restore GUI")) { /* goto @1398; */ }
                var4 = 42;
                /* goto @1398; */
            case -2009546728::
                if (!var3.equals("Save GUI")) { /* goto @1398; */ }
                var4 = 43;
                /* goto @1398; */
            case 585621228::
                if (!var3.equals("Send Toggle")) { /* goto @1398; */ }
                var4 = 44;
                /* goto @1398; */
            case 287345271::
                if (!var3.equals("Delay Pkts")) { /* goto @1398; */ }
                var4 = 45;
                /* goto @1398; */
            case 80218305::
                if (!var3.equals("Store")) { /* goto @1398; */ }
                var4 = 46;
                /* goto @1398; */
            case -1514072372::
                if (!var3.equals("Wait CD")) { /* goto @1398; */ }
                var4 = 47;
                /* goto @1398; */
            case 308410665::
                if (!var3.equals("Wait Pos")) { /* goto @1398; */ }
                var4 = 48;
                /* goto @1398; */
            case 970401571::
                if (!var3.equals("Wait Chat")) { /* goto @1398; */ }
                var4 = 49;
                /* goto @1398; */
            case 308400064::
                if (!var3.equals("Wait Ent")) { /* goto @1398; */ }
                var4 = 50;
                /* goto @1398; */
            case 970882505::
                if (!var3.equals("Wait Slot")) { /* goto @1398; */ }
                var4 = 51;
                /* goto @1398; */
            case 308413502::
                if (!var3.equals("Wait Snd")) { /* goto @1398; */ }
                var4 = 52;
                /* goto @1398; */
            case 2398323::
                if (!var3.equals("Mine")) { /* goto @1398; */ }
                var4 = 53;
                /* goto @1398; */
            case 80008::
                if (var3.equals("Pay")) {
                    var4 = 54;
                }
            default:
                switch (var4) {
                    case 0::
                        String name = this.macro.name == null ? "" : this.macro.name.trim();
                        return this.macro == null ? "Save this macro" : name.isEmpty() ? "Give the macro a name first" : !this.isValidName(this.macro.name) ? "Pick a unique macro name before saving" : "Save this macro";
                    case 1::
                        blockedReason = this.getRunBlockedReason();
                        return blockedReason != null ? blockedReason : "Run this macro";
                    case 2::
                        return "Stop the running macro";
                    case 3::
                        return "Open categorized action picker";
                    case 4::
                        return "Open categorized wait/condition picker";
                    case 5::
                        return "Undo the last macro edit";
                    case 6::
                        return "Redo the last undone macro edit";
                    case 7::
                        return "Send a chat message or /command";
                    case 8::
                        return "Wait N milliseconds or ticks";
                    case 9::
                        return "Send a captured network packet";
                    case 10::
                        return "Click an inventory slot";
                    case 11::
                        return "Simulate L/R/M click in world";
                    case 12::
                        return "Set player yaw & pitch";
                    case 13::
                        return "Use held item (right-click action)";
                    case 14::
                        return "Open player inventory screen";
                    case 15::
                        return "Select a hotbar slot (1-9)";
                    case 16::
                        return "Drop items from slot";
                    case 17::
                        return "Close the current screen/GUI";
                    case 18::
                        return "Swap two inventory slots";
                    case 19::
                        return "Pause until health crosses the selected threshold";
                    case 20::
                        return "Pause until block changes";
                    case 21::
                        return "Pause until packet received";
                    case 22::
                        return "Pause until item in inventory";
                    case 23::
                    case 24::
                        return "Pause until screen opens";
                    case 25::
                        return "Wait for next client tick";
                    case 26::
                        return "Sync handler revision";
                    case 27::
                        return "Wait for server tick timing";
                    case 28::
                        return "Send Baritone goto command";
                    case 29::
                        return "Disconnect / Kick (lag+kick) / Kick Dupe (lag+bundle/action+kick)";
                    case 30::
                        return "Sign large-data books (random/custom text, multi-book, delay)";
                    case 31::
                        return "Wait for LAN sync peer to reach a macro step";
                    case 32::
                        return "Toggle a Meteor module";
                    case 33::
                        return "Hold or release sneak key";
                    case 34::
                        return "Press jump key for N ticks";
                    case 35::
                        return "Toggle sprint on/off";
                    case 36::
                        return "Walk in direction for N ticks";
                    case 37::
                        return "Look at a block position";
                    case 38::
                        return "Repeat next N steps M times";
                    case 39::
                        return "Open a container at a block position";
                    case 40::
                        return "Send close packet without closing GUI (desync server state)";
                    case 41::
                        return "Close GUI locally without sending close packet to server";
                    case 42::
                        return "Restore a previously saved GUI screen and handler";
                    case 43::
                        return "Save the current GUI screen and handler for later restore";
                    case 44::
                        return "Toggle whether packets are sent to server (on/off)";
                    case 45::
                        return "Toggle packet delay mode (queues outgoing packets)";
                    case 46::
                        return "Loot/store items between container and player, or move slotÃ¢â€\u{a0}â€™slot";
                    case 47::
                        return "Pause until cooldown expires";
                    case 48::
                        return "Pause until position reached";
                    case 49::
                        return "Pause until chat message received";
                    case 50::
                        return "Pause until entity appears nearby";
                    case 51::
                        return "Pause until slot content changes";
                    case 52::
                        return "Pause until a matching sound plays";
                    case 53::
                        return "Mine target blocks via Baritone until stop conditions are met";
                    case 54::
                        return "Pay a list of players with a configurable command, amount, and delay";
                    default:
                        return null;
                }
        }
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (!this.isBindingKey) { /* goto L53; */ }
        if (keyCode == 256) {
            this.macro.keyCode = -1;
        } else {
            this.macro.keyCode = keyCode;
        }
        this.isBindingKey = false;
        this.recreateComponents();
        return true;
        L53: ;
        class_11908 keyInput = new class_11908(keyCode, scanCode, modifiers);
        if (this.isStepPickerOpen()) {
            if (keyCode == 256 || keyCode == 257) {
                this.closeStepPicker();
            }
            return true;
        }
        if (keyCode != 256) { /* goto L200; */ }
        if (!this.nameField.isFocused()) {
            if (this.loopMode == 1) {
                if (this.loopCountField == null) { /* goto @138; */ }
            }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L139; */
        L138: ;
        L139: ;
        boolean anyFocused = false;
        if (anyFocused) {
            this.nameField.setFocused(false);
            if (this.loopCountField != null) {
                this.loopCountField.setFocused(false);
            }
            return true;
        }
        if (MC.field_1755 != null) {
            MC.execute(PackUtilMacroEditorOverlay::lambda$keyPressed$55);
        } else {
            this.close();
        }
        return true;
        L200: ;
        if (keyCode == 257) {
            if (this.nameField.isFocused()) {
                this.nameField.setFocused(false);
                return true;
            }
            if (this.loopMode == 1) {
                if (this.loopCountField != null) {
                    if (this.loopCountField.isFocused()) {
                        this.loopCountField.setFocused(false);
                        return true;
                    }
                }
            }
        }
        if (this.nameField.keyPressed(keyInput)) {
            return true;
        }
        if (this.loopMode == 1 && this.loopCountField != null && this.loopCountField.keyPressed(keyInput)) {
            return true;
        }
        if (!this.nameField.isFocused()) {
            if (this.loopMode == 1) {
                if (this.loopCountField == null) { /* goto @346; */ }
            }
        }
        /* note: clearing non-empty stack before goto */
        /* goto L347; */
        L346: ;
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (this.isStepPickerOpen()) {
            return true;
        }
        class_11905 charInput = new class_11905(chr, modifiers);
        if (this.nameField.charTyped(charInput)) {
            return true;
        }
        if (this.nameField.isFocused()) {
            this.nameField.write(String.valueOf(chr));
            return true;
        }
        if (this.loopMode == 1) {
            if (this.loopCountField != null) {
                if (this.loopCountField.charTyped(charInput)) {
                    return true;
                }
                if (this.loopCountField.isFocused()) {
                    this.loopCountField.write(String.valueOf(chr));
                    return true;
                }
            }
        }
        return true;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible) {
            return false;
        }
        if (this.isStepPickerOpen()) {
            int pickerX = this.getStepPickerX();
            int pickerY = this.getStepPickerY();
            int pickerW = this.getStepPickerWidth();
            int pickerH = this.getStepPickerHeight();
            int contentX = pickerX + 6;
            int contentY = pickerY + 22;
            int contentW = pickerW - 12;
            int contentH = pickerH - 28;
            int contentHeight = this.getStepPickerContentHeight();
            if (mouseX >= (double)contentX && mouseX < (double)(contentX + contentW) && mouseY >= (double)contentY && mouseY < (double)(contentY + contentH)) {
                int maxScroll = Math.max(0, contentHeight - contentH);
                this.stepPickerScrollOffset = Math.max(0, Math.min(maxScroll, this.stepPickerScrollOffset - (int)(Math.signum(amount) * 36)));
                return true;
            }
            return true;
        }
        listY = this.getStepListY();
        listHeight = this.getStepListHeight();
        maxScroll = this.getMaxStepListScroll();
        if (mouseY >= (double)listY && mouseY <= (double)(listY + listHeight) && mouseX >= (double)(this.panelX + 10) && mouseX <= (double)(this.panelX + this.PANEL_WIDTH - 10)) {
            this.scrollOffset = this.quantizeScrollOffset(this.scrollOffset - (int)(Math.signum(amount) * (double)this.actionRowHeight()), this.actionRowHeight(), maxScroll);
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.activeScrollbarDrag == 2) {
            this.stepPickerScrollOffset = PackUiScrollbar.scrollFromThumb(this.getStepPickerScrollbarMetrics(), (double)(int)mouseY, this.scrollbarGrabOffset);
            return true;
        }
        if (this.activeScrollbarDrag == 1) {
            Metrics metrics = this.getStepListScrollbarMetrics();
            this.scrollOffset = this.quantizeScrollOffset(PackUiScrollbar.scrollFromThumb(metrics, (double)(int)mouseY, this.scrollbarGrabOffset), this.actionRowHeight(), metrics.maxScroll());
            return true;
        }
        if (button == 0) {
            if (this.draggingIndex >= 0 || this.pressedStepIndex >= 0) {
                this.tryStartStepDrag(mouseX, mouseY);
                if (this.draggingIndex >= 0) {
                    this.updateStepDrag(mouseY);
                }
                return true;
            }
        }
        nextWidth = this.resizeStartWidth + (int)Math.round(mouseX - this.resizeStartMouseX);
        if (this.isWindowResizing && button == 0) {
            int nextHeight = this.resizeStartHeight + (int)Math.round(mouseY - this.resizeStartMouseY);
            PackUtilWindowLayout nextBounds = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, nextWidth, nextHeight, this.visible, this.collapsed));
            this.PANEL_WIDTH = nextBounds.width;
            this.PANEL_HEIGHT = nextBounds.height;
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.recreateComponents();
            this.saveState();
            return true;
        }
        if (this.isWindowDragging) {
            if (button == 0) {
                this.panelX = (int)(mouseX - this.dragOffsetX);
                this.panelY = (int)(mouseY - this.dragOffsetY);
                screenW = PackUtilUiScale.getVirtualScreenWidth();
                screenH = PackUtilUiScale.getVirtualScreenHeight();
                minVisibleWidth = Math.min(this.PANEL_WIDTH, 96);
                this.panelX = Math.max(Math.min(0, screenW - this.PANEL_WIDTH), Math.min(this.panelX, Math.max(0, screenW - minVisibleWidth)));
                this.panelY = Math.max(0, Math.min(screenH - 16, this.panelY));
                if (this.panelX != this.headerPressPanelX || this.panelY != this.headerPressPanelY || Math.abs(mouseX - this.headerPressMouseX) >= 3 || Math.abs(mouseY - this.headerPressMouseY) >= 3) {
                    this.headerDragMoved = true;
                }
                this.recreateComponents();
                this.saveState();
                return true;
            }
        }
        return false;
    }

    public boolean shouldRenderHandledScreenCaptureBanner() {
        return false;
    }

    public String getHandledScreenCaptureTitle() {
        return "";
    }

    public String getHandledScreenCaptureInstruction() {
        return "";
    }

    public String getHandledScreenCaptureHoverText(class_1735 slot, String itemName, String registryId) {
        return "";
    }

    public boolean wantsSlotCapture() {
        return false;
    }

    public boolean onSlotRightClick(class_1735 slot, String itemName, String registryId) {
        return false;
    }
}
