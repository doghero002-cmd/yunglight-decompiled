/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public final class PackUtilYarnMappings {
    private static final String RESOURCE_PATH = "/packutil-inspector-mappings.tsv";
    private static final Map<String, String> CLASS_ALIASES = new HashMap();
    private static final Map<String, String> SIMPLE_CLASS_ALIASES = new HashMap();
    private static final Map<String, String> METHOD_ALIASES = new HashMap();
    private static final Map<String, String> FIELD_ALIASES = new HashMap();
    private static volatile boolean loaded;

    private PackUtilYarnMappings() {
    }

    public static String lookupClassAlias(Class<?> type) {
        return type == null ? null : PackUtilYarnMappings.lookupClassAlias(type.getName());
    }

    public static String lookupClassAlias(String className) {
        if (className == null || className.isBlank()) {
            return null;
        }
        PackUtilYarnMappings.ensureLoaded();
        return (String)CLASS_ALIASES.get(className.replace(47, 46));
    }

    public static String lookupSimpleClassAlias(String simpleName) {
        if (simpleName == null || simpleName.isBlank()) {
            return null;
        }
        PackUtilYarnMappings.ensureLoaded();
        String alias = (String)SIMPLE_CLASS_ALIASES.get(simpleName);
        return alias == null || alias.isBlank() ? null : alias;
    }

    public static String lookupMethodLabel(Method method) {
        if (method == null) {
            return null;
        }
        PackUtilYarnMappings.ensureLoaded();
        return (String)METHOD_ALIASES.get(PackUtilYarnMappings.memberKey(method.getDeclaringClass().getName(), method.getName(), PackUtilYarnMappings.descriptor(method)));
    }

    public static String lookupFieldLabel(Field field) {
        if (field == null) {
            return null;
        }
        PackUtilYarnMappings.ensureLoaded();
        return (String)FIELD_ALIASES.get(PackUtilYarnMappings.memberKey(field.getDeclaringClass().getName(), field.getName(), PackUtilYarnMappings.descriptor(field.getType())));
    }

    private static void ensureLoaded() {
        if (loaded) {
            return;
        }
        var var0 = PackUtilYarnMappings.class;
        synchronized (PackUtilYarnMappings.class) {
        if (loaded) {
            }
            return;
        }
    }

    private static void loadMappings() {
        InputStream stream = PackUtilYarnMappings.class.getResourceAsStream("/packutil-inspector-mappings.tsv");
        if (stream == null) {
            if (stream != null) {
                stream.close();
            }
            return;
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        L40: ;
        var tmp0 = reader.readLine();
        String line = tmp0;
        while (tmp0 != null) {
            PackUtilYarnMappings.parseLine(line);
        }
        reader.close();
        /* goto L79; */
        line = null;
        reader.close();
        /* goto L77; */
        var var3 = null;
        line.addSuppressed(var3);
        L77: ;
        throw line;
        L79: ;
        if (stream == null) { /* goto L110; */ }
        stream.close();
        /* goto L110; */
        reader = null;
        if (stream == null) { /* goto L108; */ }
        stream.close();
        /* goto L108; */
        line = null;
        reader.addSuppressed(line);
        L108: ;
        throw reader;
        L110: ;
        /* goto L114; */
        stream = null;
        L114: ;
    }

    private static void parseLine(String line) {
        if (line == null) {
            return;
        }
        String trimmed = line.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("#")) {
            return;
        }
        String[] parts = trimmed.split("\t");
        if (parts.length < 3) {
            return;
        }
        var var3 = parts[0];
        int var4 = -1;
        switch (var3.hashCode()) {
            case 67::
                if (!var3.equals("C")) { /* goto @130; */ }
                var4 = 0;
                /* goto @130; */
            case 77::
                if (!var3.equals("M")) { /* goto @130; */ }
                var4 = 1;
                /* goto @130; */
            case 70::
                if (var3.equals("F")) {
                    var4 = 2;
                }
            default:
                switch (var4) {
                    case 0::
                        String owner = parts[1];
                        String alias = parts[2];
                        if (owner.isBlank() || alias.isBlank()) {
                            return;
                        }
                        CLASS_ALIASES.put(owner, alias);
                        String simpleOwner = owner.substring(owner.lastIndexOf(46) + 1);
                        PackUtilYarnMappings.registerSimpleAlias(simpleOwner, alias);
                        /* goto @294; */
                    case 1::
                        if (parts.length < 5) {
                            return;
                        }
                        METHOD_ALIASES.put(PackUtilYarnMappings.memberKey(parts[1], parts[2], parts[3]), parts[4]);
                        /* goto @294; */
                    case 2::
                        if (parts.length < 5) {
                            return;
                        }
                        FIELD_ALIASES.put(PackUtilYarnMappings.memberKey(parts[1], parts[2], parts[3]), parts[4]);
                        /* goto @294; */
                    default:
                        return;
                }
        }
    }

    private static void registerSimpleAlias(String simpleOwner, String alias) {
        if (simpleOwner == null || simpleOwner.isBlank() || alias == null || alias.isBlank()) {
            return;
        }
        String existing = (String)SIMPLE_CLASS_ALIASES.get(simpleOwner);
        if (existing == null) {
            SIMPLE_CLASS_ALIASES.put(simpleOwner, alias);
            return;
        }
        if (!existing.equals(alias)) {
            SIMPLE_CLASS_ALIASES.put(simpleOwner, "");
        }
    }

    private static String memberKey(String owner, String name, String descriptor) {
        return owner + "#" + name + "#" + descriptor;
    }

    private static String descriptor(Method method) {
        StringBuilder builder = new StringBuilder();
        builder.append(40);
        var var2 = method.getParameterTypes();
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            Class<?> parameterType = var2[var4];
            builder.append(PackUtilYarnMappings.descriptor(parameterType));
        }
        builder.append(41).append(PackUtilYarnMappings.descriptor(method.getReturnType()));
        return builder.toString();
    }

    private static String descriptor(Class<?> type) {
        if (type.isPrimitive()) {
            if (type == Void.TYPE) {
                return "V";
            }
            if (type == Boolean.TYPE) {
                return "Z";
            }
            if (type == Byte.TYPE) {
                return "B";
            }
            if (type == Character.TYPE) {
                return "C";
            }
            if (type == Short.TYPE) {
                return "S";
            }
            if (type == Integer.TYPE) {
                return "I";
            }
            if (type == Long.TYPE) {
                return "J";
            }
            if (type == Float.TYPE) {
                return "F";
            }
            if (type == Double.TYPE) {
                return "D";
            }
        }
        if (type.isArray()) {
            return type.getName().replace(46, 47);
        }
        return "L" + type.getName().replace(46, 47) + ";";
    }
}
