/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilChatField;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilCraftingHelper;
import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilMacroEditorOverlay;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketSender;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilText;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.PacketRegenerator;
import com.example.addon.util.macro.CraftAction;
import com.example.addon.util.macro.ItemAction;
import com.example.addon.util.macro.ItemTarget;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10938;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_124;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_634;
import net.minecraft.class_9884;

public class PackUtilFabricatorOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static PackUtilFabricatorOverlay sharedOverlay;
    private int DEFAULT_PANEL_WIDTH = 236;
    private int LINE_HEIGHT = 14;
    private int CRAFT_LIST_HEIGHT = 84;
    private static final int CRAFT_LIST_ROWS = 6;
    private int CRAFT_PLAN_HEIGHT = 52;
    private static final int CRAFT_PLAN_ROWS = 4;
    private static final int SCROLLBAR_GUTTER = 8;
    private int panelX = 220;
    private int panelY = 5;
    private int PANEL_WIDTH = this.DEFAULT_PANEL_WIDTH;
    private int PANEL_HEIGHT = 392;
    private int FIELD_WIDTH = 100;
    private int BUTTON_HEIGHT = 20;
    private int LABEL_WIDTH = 64;
    private boolean isDragging = false;
    private boolean isResizing = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    private double resizeStartMouseX = 0;
    private double resizeStartMouseY = 0;
    private int resizeStartWidth = 0;
    private int resizeStartHeight = 0;
    private boolean collapsed = false;
    private boolean visible = false;
    private class_465<?> parentScreen;
    private final List<PackUtilChatField> textFields = new ArrayList();
    private PackUtilChatField slotField;
    private PackUtilChatField itemNameField;
    private PackUtilChatField timesField;
    private PackUtilChatField craftSearchField;
    private int currentActionIndex = 0;
    private final PackUtilFabricatorOverlay.FabricatorAction[] actions = PackUtilFabricatorOverlay.FabricatorAction.values();
    private int currentButtonIndex = 0;
    private final String[] buttonTypes;
    private boolean dropWholeStack;
    private Integer selectedSlotId;
    private String statusMessage;
    private class_124 statusColor;
    private long statusExpiresAtMs;
    private final List<PackUtilCraftingHelper.CraftableRecipeOption> craftableRecipes;
    private List<PackUtilCraftingHelper.CraftableRecipeOption> filteredCraftableRecipes;
    private int craftScrollOffset;
    private final PackUiSmoothScroll craftListScrollState;
    private PackUtilCraftingHelper.CraftableRecipeOption selectedCraftOption;
    private class_1799 selectedCraftResult;
    private final List<CraftAction.CraftEntry> plannedCraftEntries;
    private int craftPlanSelectedIndex;
    private int craftPlanScrollOffset;
    private final PackUiSmoothScroll craftPlanScrollState;
    private long lastCraftRefreshAt;
    private volatile boolean craftExecutionInProgress;
    private boolean craftUseMaxAmount;
    private int activeScrollbarDrag;
    private int scrollbarGrabOffset;
    private static final int SCROLLBAR_NONE = 0;
    private static final int SCROLLBAR_CRAFT_PLAN = 1;
    private static final int SCROLLBAR_CRAFT_LIST = 2;
    private String savedSlotValue;
    private String savedItemNameValue;
    private String savedTimesValue;
    private String savedCraftSearchValue;
    private int savedCraftSelectedRecipeId;
    private String savedCraftSelectedRecipeKey;
    private PackUtilFabricatorOverlay.FabricatorAction currentAction;

    private int getFieldWidth() {
        return Math.max(108, this.PANEL_WIDTH - this.LABEL_WIDTH - 26);
    }

    private int getBottomButtonY() {
        return this.panelY + this.PANEL_HEIGHT - this.BUTTON_HEIGHT - 24;
    }

    private int getStatusY() {
        return this.getBottomButtonY() - 34;
    }

    private int getActionInfoY() {
        return this.getBottomButtonY() - 18;
    }

    private boolean isCraftMode() {
        return this.currentAction.isCraftAction();
    }

    private boolean showsTargetFields() {
        return !this.isCraftMode();
    }

    private int getActionRowY() {
        return this.panelY + 30;
    }

    private int getSlotRowY() {
        return this.getActionRowY() + 28;
    }

    private int getItemRowY() {
        return this.getSlotRowY() + 28;
    }

    private int getOptionRowY() {
        return this.getItemRowY() + 28;
    }

    private int getStandardTimesRowY() {
        return this.isClickSelectorRelevant() || this.isDropModeRelevant() ? this.getOptionRowY() + 28 : this.getItemRowY() + 28;
    }

    private int getCraftSearchY() {
        return this.getCraftSearchLabelY() + 12;
    }

    private int getCraftAmountRowY() {
        return this.getCraftSummaryY() + 16;
    }

    private int getCraftAmountToggleWidth() {
        return 78;
    }

    private int getCraftAmountFieldX() {
        return this.panelX + this.LABEL_WIDTH + 15;
    }

    private int getCraftAmountToggleX() {
        return this.getCraftAmountFieldX() + this.getCraftAmountFieldWidth() + 4;
    }

    private int getCraftAddButtonWidth() {
        return 44;
    }

    private int getCraftAmountFieldWidth() {
        return Math.max(48, this.getFieldWidth() - this.getCraftAmountToggleWidth() - this.getCraftAddButtonWidth() - 8);
    }

    private int getCraftAddButtonX() {
        return this.getCraftAmountToggleX() + this.getCraftAmountToggleWidth() + 4;
    }

    private int getCraftPlanHeaderY() {
        return this.getSlotRowY() + 3;
    }

    private int getCraftPlanListY() {
        return this.getSlotRowY() + 16;
    }

    private int getCraftSummaryY() {
        return this.getCraftPlanListY() + this.CRAFT_PLAN_HEIGHT + 4;
    }

    private int getCraftSearchLabelY() {
        return this.getCraftAmountRowY() + 24;
    }

    private boolean isClickSelectorRelevant() {
        return this.currentAction.usesClickSelector();
    }

    private boolean isDropModeRelevant() {
        return this.currentAction.usesDropToggle();
    }

    private int getEffectiveButton() {
        if (!this.currentAction.usesDropToggle()) { /* goto L23; */ }
        return this.dropWholeStack ? 1 : 0;
        PackUtilDropAction packetAction = this.currentAction.toPacketAction(this.dropWholeStack);
        return packetAction.usesFixedButton() ? packetAction.getButton() : this.currentButtonIndex;
    }

    private String getClickSelectorLabel() {
        if (this.isClickSelectorRelevant()) {
            return this.buttonTypes[this.currentButtonIndex];
        }
        if (!this.isDropModeRelevant()) { /* goto L41; */ }
        return this.dropWholeStack ? "Whole Stack" : "Single Item";
        return "Auto";
    }

    private void drawOverlayButton(class_332 context, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean enabled, int mouseX, int mouseY) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), PackUtilFabricatorOverlay::lambda$drawOverlayButton$0);
        button.setWidth(w);
        button.setVariant(variant);
        button.active = enabled;
        PackUiOverlayButton.renderStyled(context, MC.field_1772, button, mouseX, mouseY);
    }

    public PackUtilFabricatorOverlay(class_465<?> parentScreen) {
        String[] tmp0 = new String[2];
        tmp0[0] = "Left Click";
        tmp0[1] = "Right Click";
        this.buttonTypes = tmp0;
        this.dropWholeStack = false;
        this.selectedSlotId = null;
        this.statusMessage = "";
        this.statusColor = class_124.field_1080;
        this.statusExpiresAtMs = 0L;
        this.craftableRecipes = new ArrayList();
        this.filteredCraftableRecipes = new ArrayList();
        this.craftScrollOffset = 0;
        this.craftListScrollState = new PackUiSmoothScroll();
        this.selectedCraftOption = null;
        this.selectedCraftResult = class_1799.field_8037;
        this.plannedCraftEntries = new ArrayList();
        this.craftPlanSelectedIndex = -1;
        this.craftPlanScrollOffset = 0;
        this.craftPlanScrollState = new PackUiSmoothScroll();
        this.lastCraftRefreshAt = 0L;
        this.craftExecutionInProgress = false;
        this.craftUseMaxAmount = false;
        this.activeScrollbarDrag = 0;
        this.scrollbarGrabOffset = 0;
        this.savedSlotValue = "0";
        this.savedItemNameValue = "";
        this.savedTimesValue = "1";
        this.savedCraftSearchValue = "";
        this.savedCraftSelectedRecipeId = -1;
        this.savedCraftSelectedRecipeKey = "";
        this.currentAction = PackUtilFabricatorOverlay.FabricatorAction.CLICK;
        this.parentScreen = parentScreen;
        this.applyPresetMetrics();
        this.PANEL_WIDTH = this.DEFAULT_PANEL_WIDTH;
        this.PANEL_HEIGHT = this.craftModePanelHeight();
    }

    public static synchronized PackUtilFabricatorOverlay getSharedOverlay(class_465<?> parentScreen) {
        if (sharedOverlay == null) {
            sharedOverlay = new PackUtilFabricatorOverlay(parentScreen);
            sharedOverlay.restoreState();
        } else {
            sharedOverlay.parentScreen = parentScreen;
        }
        return sharedOverlay;
    }

    public int getMinWidth() {
        return this.DEFAULT_PANEL_WIDTH;
    }

    public int getMinHeight() {
        return this.standardPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.PANEL_WIDTH = this.DEFAULT_PANEL_WIDTH;
        this.PANEL_HEIGHT = Math.max(this.getMinHeight(), clamped.height);
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
        if (this.visible) {
            this.initWidgets();
        }
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visible) {
            this.initWidgets();
            PackUtilOverlayManager.get().bringToFront(this);
        } else {
            this.clearWidgets();
        }
        this.saveState();
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.saveLayout();
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        int panelHeight = this.collapsed ? 18 : this.PANEL_HEIGHT;
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + panelHeight);
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.PANEL_WIDTH) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + 18) && !this.isOverWindowControl(mouseX, mouseY, bounds);
    }

    public boolean hasTextFieldFocused() {
        var var1 = this.textFields.iterator();
        while (var1.hasNext()) {
            PackUtilChatField field = (PackUtilChatField)var1.next();
            if (!field.isFocused()) continue;
            return true;
        }
        return false;
    }

    public void saveState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setFabricatorOverlayVisible(this.visible);
        shared.setFabricatorOverlayX(this.panelX);
        shared.setFabricatorOverlayY(this.panelY);
        shared.setFabricatorSlotValue(this.savedSlotValue);
        shared.setFabricatorItemNameValue(this.savedItemNameValue);
        shared.setFabricatorTimesValue(this.savedTimesValue);
        shared.setFabricatorActionIndex(this.currentActionIndex);
        shared.setFabricatorButtonIndex(this.currentButtonIndex);
        shared.setFabricatorDropWholeStack(this.dropWholeStack);
        shared.setFabricatorCraftUseMaxAmount(this.craftUseMaxAmount);
        shared.setFabricatorCraftSearchValue(this.savedCraftSearchValue);
        shared.setFabricatorCraftSelectedRecipeId(this.savedCraftSelectedRecipeId);
        shared.setFabricatorCraftSelectedRecipeKey(this.savedCraftSelectedRecipeKey);
        shared.setFabricatorCraftScrollOffset(this.craftScrollOffset);
        shared.setFabricatorCraftPlanEntries(this.plannedCraftEntries);
        shared.setFabricatorCraftPlanSelectedIndex(this.craftPlanSelectedIndex);
        shared.setFabricatorCraftPlanScrollOffset(this.craftPlanScrollOffset);
        this.saveLayout();
    }

    public void restoreState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.restoreLayout();
        this.visible = shared.isFabricatorOverlayVisible();
        this.panelX = shared.getFabricatorOverlayX();
        this.panelY = shared.getFabricatorOverlayY();
        this.savedSlotValue = shared.getFabricatorSlotValue();
        this.savedItemNameValue = shared.getFabricatorItemNameValue();
        this.savedTimesValue = shared.getFabricatorTimesValue();
        this.currentActionIndex = shared.getFabricatorActionIndex();
        this.currentButtonIndex = shared.getFabricatorButtonIndex();
        this.dropWholeStack = shared.isFabricatorDropWholeStack();
        this.craftUseMaxAmount = shared.isFabricatorCraftUseMaxAmount();
        this.savedCraftSearchValue = shared.getFabricatorCraftSearchValue();
        this.savedCraftSelectedRecipeId = shared.getFabricatorCraftSelectedRecipeId();
        this.savedCraftSelectedRecipeKey = shared.getFabricatorCraftSelectedRecipeKey();
        this.craftScrollOffset = shared.getFabricatorCraftScrollOffset();
        this.craftListScrollState.restore(this.craftScrollOffset * this.LINE_HEIGHT);
        this.plannedCraftEntries.clear();
        this.plannedCraftEntries.addAll(shared.getFabricatorCraftPlanEntries());
        this.craftPlanSelectedIndex = shared.getFabricatorCraftPlanSelectedIndex();
        this.craftPlanScrollOffset = shared.getFabricatorCraftPlanScrollOffset();
        this.craftPlanScrollState.restore(this.craftPlanScrollOffset * 13);
        this.selectedCraftOption = null;
        this.selectedCraftResult = class_1799.field_8037;
        if (this.currentActionIndex < 0 || this.currentActionIndex >= this.actions.length) {
            this.currentActionIndex = 0;
        }
        this.currentAction = this.actions[this.currentActionIndex];
        if (this.currentButtonIndex < 0 || this.currentButtonIndex >= this.buttonTypes.length) {
            this.currentButtonIndex = 0;
        }
        if (this.visible) {
            this.initWidgets();
        }
    }

    private void initWidgets() {
        this.clearWidgets();
        if (this.isResizing) { /* goto L40; */ }
        if (this.isDragging) { /* goto L40; */ }
        this.PANEL_HEIGHT = this.isCraftMode() ? this.craftModePanelHeight() : this.standardPanelHeight();
        int fieldX = this.panelX + this.LABEL_WIDTH + 15;
        int fieldWidth = this.getFieldWidth();
        this.currentAction = this.actions[this.currentActionIndex];
        this.slotField = new PackUtilChatField(MC, MC.field_1772, fieldX, this.getSlotRowY(), fieldWidth, 16, false);
        this.slotField.setPlaceholder(class_2561.method_43470("Optional slot - right-click to fill"));
        this.slotField.setText(this.savedSlotValue);
        this.slotField.setMaxLength(5);
        this.slotField.setChangedListener(this::lambda$initWidgets$1);
        if (this.showsTargetFields()) {
            this.textFields.add(this.slotField);
        }
        this.itemNameField = new PackUtilChatField(MC, MC.field_1772, fieldX, this.getItemRowY(), fieldWidth, 16, false);
        this.itemNameField.setPlaceholder(class_2561.method_43470("Optional item match").method_27694(PackUtilFabricatorOverlay::lambda$initWidgets$2));
        this.itemNameField.setText(this.savedItemNameValue);
        this.itemNameField.setMaxLength(50);
        this.itemNameField.setChangedListener(this::lambda$initWidgets$3);
        if (this.showsTargetFields()) {
            this.textFields.add(this.itemNameField);
        }
        int timesY = this.isCraftMode() ? this.getCraftAmountRowY() : this.getStandardTimesRowY();
        int timesX = this.isCraftMode() ? this.getCraftAmountFieldX() : fieldX;
        int timesWidth = this.isCraftMode() ? this.getCraftAmountFieldWidth() : fieldWidth;
        this.timesField = new PackUtilChatField(MC, MC.field_1772, timesX, timesY, timesWidth, 16, false);
        this.timesField.setPlaceholder(class_2561.method_43470("1"));
        this.timesField.setText(this.savedTimesValue);
        this.timesField.setMaxLength(5);
        if (!this.isCraftMode()) { /* goto L401; */ }
        this.timesField.setEditable(!this.craftUseMaxAmount);
        this.timesField.setChangedListener(this::lambda$initWidgets$4);
        this.textFields.add(this.timesField);
        if (this.isCraftMode()) {
            int searchY = this.getCraftSearchY();
            this.craftSearchField = new PackUtilChatField(MC, MC.field_1772, this.panelX + 10, searchY, this.PANEL_WIDTH - 20, 16, false);
            this.craftSearchField.setPlaceholder(class_2561.method_43470("Search crafting recipes..."));
            this.craftSearchField.setText(this.savedCraftSearchValue);
            this.craftSearchField.setChangedListener(this::lambda$initWidgets$5);
            this.textFields.add(this.craftSearchField);
            this.refreshCraftableRecipes(true);
        } else {
            this.craftSearchField = null;
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        if (button != 0) { /* goto L213; */ }
        if (mouseX < (double)this.panelX) { /* goto L213; */ }
        if (mouseX > (double)(this.panelX + this.PANEL_WIDTH)) { /* goto L213; */ }
        if (mouseY < (double)this.panelY) { /* goto L213; */ }
        if (mouseY > (double)(this.panelY + 20)) { /* goto L213; */ }
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, this.collapsed ? 18 : this.PANEL_HEIGHT, this.visible, this.collapsed);
        if (this.isOverCollapseButton(mouseX, mouseY, bounds)) {
            this.toggleCollapsed();
            return true;
        }
        if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
            this.setVisible(false);
            return true;
        }
        this.isDragging = true;
        this.dragOffsetX = mouseX - (double)this.panelX;
        this.dragOffsetY = mouseY - (double)this.panelY;
        class_11909 click = this.textFields.iterator();
        while (click.hasNext()) {
            PackUtilChatField field = (PackUtilChatField)click.next();
            field.setFocused(false);
        }
        return true;
        L213: ;
        if (this.collapsed) {
            return false;
        }
        mouseInput = new class_11910(button, 0);
        click = new class_11909(mouseX, mouseY, mouseInput);
        clickedField = false;
        int listX = this.textFields.iterator();
        while (listX.hasNext()) {
            PackUtilChatField field = (PackUtilChatField)listX.next();
            boolean wasClicked = field.mouseClicked(click, false);
            if (wasClicked) {
                field.setFocused(true);
                field.setSelectionEnd(field.getText().length());
                clickedField = true;
            } else {
                field.setFocused(false);
            }
        }
        if (clickedField) {
            return true;
        }
        if (!this.isCraftMode()) { /* goto L1435; */ }
        this.refreshCraftableRecipes(false);
        listX = this.getCraftListX();
        listWidth = this.getCraftListWidth();
        planContentWidth = this.getCraftPlanContentWidth();
        int recipeContentWidth = this.getCraftListContentWidth();
        int planHeaderY = this.getCraftPlanHeaderY();
        int planListY = this.getCraftPlanListY();
        int listY = this.getCraftListY();
        if (button == 0) {
            Metrics craftPlanScrollbar = this.getCraftPlanScrollbarMetrics();
            this.activeScrollbarDrag = 1;
            if (craftPlanScrollbar.hasScroll() && craftPlanScrollbar.contains((double)(int)mouseX, (double)(int)mouseY)) {
                this.scrollbarGrabOffset = Math.max(0, (int)mouseY - craftPlanScrollbar.thumbY());
                this.craftPlanScrollOffset = this.toRowScroll(craftPlanScrollbar, (int)mouseY, this.scrollbarGrabOffset, 13, Math.max(0, this.plannedCraftEntries.size() - 4));
                this.craftPlanScrollState.jumpTo(this.craftPlanScrollOffset * 13, Math.max(0, this.plannedCraftEntries.size() * 13 - this.CRAFT_PLAN_HEIGHT));
                this.saveState();
                return true;
            }
            Metrics craftListScrollbar = this.getCraftListScrollbarMetrics();
            if (craftListScrollbar.hasScroll()) {
                if (craftListScrollbar.contains((double)(int)mouseX, (double)(int)mouseY)) {
                    this.activeScrollbarDrag = 2;
                    this.scrollbarGrabOffset = Math.max(0, (int)mouseY - craftListScrollbar.thumbY());
                    this.craftScrollOffset = this.toRowScroll(craftListScrollbar, (int)mouseY, this.scrollbarGrabOffset, this.LINE_HEIGHT, Math.max(0, this.filteredCraftableRecipes.size() - 6));
                    this.craftListScrollState.jumpTo(this.craftScrollOffset * this.LINE_HEIGHT, Math.max(0, this.filteredCraftableRecipes.size() * this.LINE_HEIGHT - this.CRAFT_LIST_HEIGHT));
                    this.saveState();
                    return true;
                }
            }
        }
        this.plannedCraftEntries.clear();
        if (!this.plannedCraftEntries.isEmpty() && mouseX >= (double)(this.panelX + this.PANEL_WIDTH - 74) && mouseX < (double)(this.panelX + this.PANEL_WIDTH - 10) && mouseY >= (double)(planHeaderY - 2) && mouseY < (double)(planHeaderY + 10) && button == 0) {
            this.craftPlanSelectedIndex = -1;
            this.craftPlanScrollOffset = 0;
            this.craftPlanScrollState.jumpTo(0, 0);
            this.clearStatus();
            this.saveState();
            return true;
        }
        if (mouseX < (double)listX) { /* goto L1110; */ }
        if (mouseX > (double)(listX + listWidth)) { /* goto L1110; */ }
        if (mouseY < (double)planListY) { /* goto L1110; */ }
        if (mouseY > (double)(planListY + this.CRAFT_PLAN_HEIGHT)) { /* goto L1110; */ }
        if (button != 0) { /* goto L1110; */ }
        maxPlanScrollPx = Math.max(0, this.plannedCraftEntries.size() * 13 - this.CRAFT_PLAN_HEIGHT);
        drawPlanScroll = this.craftPlanScrollState.tick(0f, maxPlanScrollPx);
        int firstIndex = drawPlanScroll / 13;
        int rowY = planListY - drawPlanScroll % 13;
        int index = firstIndex;
        while (index < this.plannedCraftEntries.size()) {
            if (rowY >= planListY + this.CRAFT_PLAN_HEIGHT) break;
            if (mouseY < (double)rowY) { /* goto L1033; */ }
            if (mouseY >= (double)(rowY + 12)) {
            } else {
                this.removePlannedCraftEntry(index);
                if (mouseX >= (double)(listX + planContentWidth - 16) && mouseX < (double)(listX + planContentWidth - 2)) {
                    return true;
                }
                if (mouseX < (double)listX) { /* goto @1033; */ }
                if (mouseX >= (double)(listX + planContentWidth)) { /* goto @1033; */ }
                if (this.craftPlanSelectedIndex == index) {
                    this.selectCraftPlanEntry(-1);
                } else {
                    this.selectCraftPlanEntry(index);
                }
                PackUtilChatField field = this.textFields.iterator();
                while (field.hasNext()) {
                    PackUtilChatField field = (PackUtilChatField)field.next();
                    field.setFocused(false);
                }
                return true;
            }
            index++;
            rowY += 13;
        }
        if (mouseX < (double)listX) { /* goto L1110; */ }
        if (mouseX >= (double)(listX + planContentWidth)) { /* goto L1110; */ }
        this.selectCraftPlanEntry(-1);
        index = this.textFields.iterator();
        while (index.hasNext()) {
            field = (PackUtilChatField)index.next();
            field.setFocused(false);
        }
        return true;
        L1110: ;
        if (mouseX < (double)listX) { /* goto L1435; */ }
        if (mouseX > (double)(listX + listWidth)) { /* goto L1435; */ }
        if (mouseY < (double)listY) { /* goto L1435; */ }
        if (mouseY > (double)(listY + this.CRAFT_LIST_HEIGHT)) { /* goto L1435; */ }
        if (button != 0) { /* goto L1435; */ }
        maxRecipeScrollPx = Math.max(0, this.filteredCraftableRecipes.size() * this.LINE_HEIGHT - this.CRAFT_LIST_HEIGHT);
        drawRecipeScroll = this.craftListScrollState.tick(0f, maxRecipeScrollPx);
        firstIndex = drawRecipeScroll / this.LINE_HEIGHT;
        rowY = listY - drawRecipeScroll % this.LINE_HEIGHT;
        index = firstIndex;
        while (index < this.filteredCraftableRecipes.size()) {
            if (rowY >= listY + this.CRAFT_LIST_HEIGHT) break;
            if (mouseX < (double)listX) { /* goto L1349; */ }
            if (mouseX >= (double)(listX + recipeContentWidth)) { /* goto L1349; */ }
            if (mouseY < (double)rowY) { /* goto L1349; */ }
            if (mouseY >= (double)(rowY + this.LINE_HEIGHT)) { /* goto L1349; */ }
            this.selectCraftRecipe((PackUtilCraftingHelper.CraftableRecipeOption)this.filteredCraftableRecipes.get(index));
            this.addOrUpdatePlannedCraftEntry();
            field = this.textFields.iterator();
            while (field.hasNext()) {
                field = (PackUtilChatField)field.next();
                field.setFocused(false);
            }
            return true;
            L1349: ;
            index++;
            rowY = rowY + this.LINE_HEIGHT;
        }
        if (mouseX < (double)listX) { /* goto L1435; */ }
        if (mouseX >= (double)(listX + recipeContentWidth)) { /* goto L1435; */ }
        this.clearCraftRecipeSelection();
        field = this.textFields.iterator();
        while (field.hasNext()) {
            field = (PackUtilChatField)field.next();
            field.setFocused(false);
        }
        this.saveState();
        return true;
        L1435: ;
        fieldXR = this.panelX + this.LABEL_WIDTH + 15;
        fieldWidth = this.getFieldWidth();
        cycleY1 = this.getOptionRowY();
        cycleY2 = this.getActionRowY();
        cycleBtnH = 16;
        if (this.isCraftMode()) { /* goto L1764; */ }
        if (this.isClickSelectorRelevant()) { /* goto L1492; */ }
        if (!this.isDropModeRelevant()) { /* goto L1764; */ }
        L1492: ;
        if (mouseY < (double)cycleY1) { /* goto L1764; */ }
        if (mouseY >= (double)(cycleY1 + cycleBtnH)) { /* goto L1764; */ }
        if (mouseX < (double)fieldXR) { /* goto L1764; */ }
        if (mouseX >= (double)(fieldXR + fieldWidth)) { /* goto L1764; */ }
        halfWidth = (fieldWidth - 2) / 2;
        if (!this.isClickSelectorRelevant()) { /* goto L1628; */ }
        if (button == 0) { /* goto L1556; */ }
        if (button != 1) { /* goto L1584; */ }
        L1556: ;
        this.currentButtonIndex = mouseX < (double)(fieldXR + halfWidth) ? 0 : 1;
        this.clearStatus();
        this.saveState();
        L1584: ;
        field = this.textFields.iterator();
        while (field.hasNext()) {
            field = (PackUtilChatField)field.next();
            field.setFocused(false);
        }
        return true;
        L1628: ;
        if (!this.isDropModeRelevant()) { /* goto L1720; */ }
        if (button == 0) { /* goto L1646; */ }
        if (button != 1) { /* goto L1676; */ }
        L1646: ;
        this.dropWholeStack = mouseX >= (double)(fieldXR + halfWidth + 2);
        this.clearStatus();
        this.saveState();
        L1676: ;
        field = this.textFields.iterator();
        while (field.hasNext()) {
            field = (PackUtilChatField)field.next();
            field.setFocused(false);
        }
        return true;
        L1720: ;
        field = this.textFields.iterator();
        while (field.hasNext()) {
            field = (PackUtilChatField)field.next();
            field.setFocused(false);
        }
        return true;
        L1764: ;
        if (mouseY < (double)cycleY2) { /* goto L1863; */ }
        if (mouseY >= (double)(cycleY2 + cycleBtnH)) { /* goto L1863; */ }
        if (mouseX < (double)fieldXR) { /* goto L1863; */ }
        if (mouseX >= (double)(fieldXR + fieldWidth)) { /* goto L1863; */ }
        if (button == 1) {
            this.cycleActionBackwards();
        } else {
            this.cycleAction();
        }
        toggleX = this.textFields.iterator();
        while (toggleX.hasNext()) {
            field = (PackUtilChatField)toggleX.next();
            field.setFocused(false);
        }
        return true;
        L1863: ;
        if (!this.isCraftMode()) { /* goto L2077; */ }
        toggleX = this.getCraftAmountToggleX();
        toggleY = this.getCraftAmountRowY();
        toggleW = this.getCraftAmountToggleWidth();
        if (mouseY < (double)toggleY) { /* goto L2077; */ }
        if (mouseY >= (double)(toggleY + 16)) { /* goto L2077; */ }
        if (mouseX < (double)toggleX) { /* goto L2077; */ }
        if (mouseX >= (double)(toggleX + toggleW)) { /* goto L2077; */ }
        if (button == 0) { /* goto L1937; */ }
        if (button != 1) { /* goto L2077; */ }
        L1937: ;
        this.craftUseMaxAmount = !this.craftUseMaxAmount;
        if (this.timesField == null) { /* goto L1979; */ }
        this.timesField.setEditable(!this.craftUseMaxAmount);
        if (this.craftPlanSelectedIndex >= 0) {
            if (this.craftPlanSelectedIndex < this.plannedCraftEntries.size()) {
                (CraftAction.CraftEntry)this.plannedCraftEntries.get(this.craftPlanSelectedIndex).useMaxAmount = this.craftUseMaxAmount;
            }
        }
        this.clearStatus();
        this.saveState();
        bw = this.textFields.iterator();
        while (bw.hasNext()) {
            field = (PackUtilChatField)bw.next();
            field.setFocused(false);
        }
        return true;
        L2077: ;
        btnY = this.getBottomButtonY();
        btnArea = this.PANEL_WIDTH - 20;
        gap = 2;
        bw = (btnArea - gap * 2) / 3;
        bx = this.panelX + 10;
        if (mouseY < (double)btnY) { /* goto L2451; */ }
        if (mouseY >= (double)(btnY + this.BUTTON_HEIGHT)) { /* goto L2451; */ }
        if (button != 0) { /* goto L2451; */ }
        if (mouseX < (double)bx) { /* goto L2209; */ }
        if (mouseX >= (double)(bx + bw)) { /* goto L2209; */ }
        this.sendPacket(false);
        macroEditor = this.textFields.iterator();
        while (macroEditor.hasNext()) {
            field = (PackUtilChatField)macroEditor.next();
            field.setFocused(false);
        }
        return true;
        L2209: ;
        bx = bx + (bw + gap);
        if (mouseX < (double)bx) { /* goto L2287; */ }
        if (mouseX >= (double)(bx + bw)) { /* goto L2287; */ }
        this.sendPacket(true);
        macroEditor = this.textFields.iterator();
        while (macroEditor.hasNext()) {
            field = (PackUtilChatField)macroEditor.next();
            field.setFocused(false);
        }
        return true;
        L2287: ;
        bx = bx + (bw + gap);
        if (mouseX < (double)bx) { /* goto L2451; */ }
        if (mouseX >= (double)(bx + bw)) { /* goto L2451; */ }
        macroEditor = null;
        field = PackUtilOverlayManager.get().getOverlays().iterator();
        while (field.hasNext()) {
            ov = (IPackUtilOverlay)field.next();
            if (!ov instanceof PackUtilMacroEditorOverlay) { /* goto @2372; */ }
            macroEditor = (PackUtilMacroEditorOverlay)ov;
            break;
        }
        this.sendToMacro(macroEditor);
        if (macroEditor != null && macroEditor.isVisible()) {
        } else {
            this.setStatus("Â§cOpen a macro editor first!", class_124.field_1061);
        }
        field = this.textFields.iterator();
        while (field.hasNext()) {
            field = (PackUtilChatField)field.next();
            field.setFocused(false);
        }
        return true;
        L2451: ;
        return false;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.activeScrollbarDrag = 0;
        if (button == 0 && this.activeScrollbarDrag != 0) {
            this.saveState();
            return true;
        }
        if (button == 0) {
            if (this.isDragging || this.isResizing) {
                this.saveState();
            }
            this.isDragging = false;
            this.isResizing = false;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.activeScrollbarDrag == 1) {
            this.craftPlanScrollOffset = this.toRowScroll(this.getCraftPlanScrollbarMetrics(), (int)mouseY, this.scrollbarGrabOffset, 13, Math.max(0, this.plannedCraftEntries.size() - 4));
            this.craftPlanScrollState.jumpTo(this.craftPlanScrollOffset * 13, Math.max(0, this.plannedCraftEntries.size() * 13 - this.CRAFT_PLAN_HEIGHT));
            return true;
        }
        if (this.activeScrollbarDrag == 2) {
            this.craftScrollOffset = this.toRowScroll(this.getCraftListScrollbarMetrics(), (int)mouseY, this.scrollbarGrabOffset, this.LINE_HEIGHT, Math.max(0, this.filteredCraftableRecipes.size() - 6));
            this.craftListScrollState.jumpTo(this.craftScrollOffset * this.LINE_HEIGHT, Math.max(0, this.filteredCraftableRecipes.size() * this.LINE_HEIGHT - this.CRAFT_LIST_HEIGHT));
            return true;
        }
        if (this.isResizing) {
            PackUtilWindowLayout nextBounds = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.resizeStartWidth + (int)Math.round(mouseX - this.resizeStartMouseX), this.resizeStartHeight + (int)Math.round(mouseY - this.resizeStartMouseY), this.visible, this.collapsed));
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.PANEL_WIDTH = nextBounds.width;
            this.PANEL_HEIGHT = nextBounds.height;
            this.initWidgets();
            return true;
        }
        if (this.isDragging) {
            nextBounds = this.clampToScreen(this, new PackUtilWindowLayout((int)(mouseX - this.dragOffsetX), (int)(mouseY - this.dragOffsetY), this.PANEL_WIDTH, this.PANEL_HEIGHT, this.visible, this.collapsed));
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.initWidgets();
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible || this.collapsed) {
            return false;
        }
        if (this.isCraftMode()) {
            int planX = this.getCraftListX();
            int planY = this.getCraftPlanListY();
            int listWidth = this.getCraftListWidth();
            int maxPlanScroll = Math.max(0, this.plannedCraftEntries.size() - 4);
            if (mouseX >= (double)planX && mouseX <= (double)(planX + listWidth) && mouseY >= (double)planY && mouseY <= (double)(planY + this.CRAFT_PLAN_HEIGHT)) {
                this.craftPlanScrollOffset = Math.max(0, Math.min(maxPlanScroll, this.craftPlanScrollOffset - (int)Math.signum(amount)));
                this.craftPlanScrollState.setTarget(this.craftPlanScrollOffset * 13, Math.max(0, this.plannedCraftEntries.size() * 13 - this.CRAFT_PLAN_HEIGHT));
                this.saveState();
                return true;
            }
            listX = this.getCraftListX();
            int listY = this.getCraftListY();
            if (mouseX >= (double)listX) {
                if (mouseX <= (double)(listX + listWidth)) {
                    if (mouseY >= (double)listY) {
                        if (mouseY <= (double)(listY + this.CRAFT_LIST_HEIGHT)) {
                            int maxScroll = Math.max(0, this.filteredCraftableRecipes.size() - 6);
                            this.craftScrollOffset = Math.max(0, Math.min(maxScroll, this.craftScrollOffset - (int)Math.signum(amount)));
                            this.craftListScrollState.setTarget(this.craftScrollOffset * this.LINE_HEIGHT, Math.max(0, this.filteredCraftableRecipes.size() * this.LINE_HEIGHT - this.CRAFT_LIST_HEIGHT));
                            this.saveState();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private String getItemNameFromSlot(int slotId) {
        class_1703 handler = this.getActiveHandler();
        if (handler == null || slotId < 0 || slotId >= handler.field_7761.size()) {
            return "";
        }
        class_1735 slot = (class_1735)handler.field_7761.get(slotId);
        if (slot == null || slot.method_7677().method_7960()) {
            return "";
        }
        return slot.method_7677().method_7964().getString();
    }

    private void refreshCraftableRecipes(boolean force) {
        if (!this.isCraftMode() || MC.field_1724 == null || MC.field_1687 == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (!force && now - this.lastCraftRefreshAt < 350L) {
            return;
        }
        this.lastCraftRefreshAt = now;
        this.craftableRecipes.clear();
        this.filteredCraftableRecipes = new ArrayList();
        this.craftableRecipes.addAll(PackUtilCraftingHelper.getCraftableRecipes(MC));
        this.updateCraftRecipeFilter(this.craftSearchField != null ? this.craftSearchField.getText() : this.savedCraftSearchValue, false);
        this.clearSelectedCraftIfInvalid();
        this.restoreSelectedCraftIfNeeded();
    }

    private void updateCraftRecipeFilter(String query, boolean resetScroll) {
        this.savedCraftSearchValue = query == null ? "" : query;
        this.filteredCraftableRecipes = PackUtilCraftingHelper.filterRecipes(this.craftableRecipes, query);
        int maxScroll = Math.max(0, this.filteredCraftableRecipes.size() - 6);
        this.craftScrollOffset = resetScroll ? 0 : Math.max(0, Math.min(maxScroll, this.craftScrollOffset));
    }

    private void clearSelectedCraftIfInvalid() {
        if (this.selectedCraftOption == null) {
            return;
        }
        var var1 = this.craftableRecipes.iterator();
        while (var1.hasNext()) {
            CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)var1.next();
            if (option.recipeKey.isBlank() || !option.recipeKey.equalsIgnoreCase(this.selectedCraftOption.recipeKey)) {
                if (option.recipeId < 0 || option.recipeId != this.selectedCraftOption.recipeId) {
                    if (option.syncedRecipeId < 0) { /* goto @139; */ }
                }
            }
            this.selectedCraftOption = option;
            this.selectedCraftResult = option.result.method_7972();
            this.savedCraftSelectedRecipeId = option.recipeId;
            this.savedCraftSelectedRecipeKey = option.recipeKey;
            return;
        }
        this.selectedCraftOption = null;
        this.selectedCraftResult = class_1799.field_8037;
        this.savedCraftSelectedRecipeId = -1;
        this.savedCraftSelectedRecipeKey = "";
    }

    private void restoreSelectedCraftIfNeeded() {
        if (this.savedCraftSelectedRecipeKey == null || this.savedCraftSelectedRecipeKey.isBlank()) {
            if (this.savedCraftSelectedRecipeId < 0) {
                return;
            }
        }
        if (this.selectedCraftOption != null) {
            if (!this.savedCraftSelectedRecipeKey.isBlank() && this.savedCraftSelectedRecipeKey.equalsIgnoreCase(this.selectedCraftOption.recipeKey)) {
                return;
            }
            if (this.savedCraftSelectedRecipeId >= 0) {
                if (this.selectedCraftOption.recipeId == this.savedCraftSelectedRecipeId || this.selectedCraftOption.syncedRecipeId == this.savedCraftSelectedRecipeId) {
                    return;
                }
            }
        }
        var var1 = this.craftableRecipes.iterator();
        while (var1.hasNext()) {
            CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)var1.next();
            if (this.savedCraftSelectedRecipeKey.isBlank() || !this.savedCraftSelectedRecipeKey.equalsIgnoreCase(option.recipeKey)) {
                if (this.savedCraftSelectedRecipeId < 0 || option.recipeId != this.savedCraftSelectedRecipeId) {
                    if (this.savedCraftSelectedRecipeId < 0) { /* goto @244; */ }
                }
            }
            this.selectedCraftOption = option;
            this.selectedCraftResult = option.result.method_7972();
            this.savedItemNameValue = option.label;
            this.savedCraftSelectedRecipeKey = option.recipeKey;
            this.savedCraftSelectedRecipeId = option.recipeId;
            if (this.itemNameField == null) continue;
            this.itemNameField.setText(this.savedItemNameValue);
            return;
        }
    }

    private int getCraftListY() {
        return this.getCraftSearchY() + 24;
    }

    private int getCraftListX() {
        return this.panelX + 10;
    }

    private int getCraftListWidth() {
        return this.PANEL_WIDTH - 20;
    }

    private int getCraftPlanContentWidth() {
        return Math.max(40, this.getCraftListWidth() - (this.getCraftPlanScrollbarMetrics().hasScroll() ? 8 : 0));
    }

    private int getCraftListContentWidth() {
        return Math.max(40, this.getCraftListWidth() - (this.getCraftListScrollbarMetrics().hasScroll() ? 8 : 0));
    }

    private PackUiScrollbar.Metrics getCraftPlanScrollbarMetrics() {
        int listX = this.getCraftListX();
        int listY = this.getCraftPlanListY();
        int listWidth = this.getCraftListWidth();
        int contentHeight = this.plannedCraftEntries.size() * 13;
        int maxScroll = Math.max(0, contentHeight - this.CRAFT_PLAN_HEIGHT);
        return PackUiScrollbar.compute(contentHeight, this.CRAFT_PLAN_HEIGHT, listX + listWidth - 5, listY, 3, this.CRAFT_PLAN_HEIGHT, this.craftPlanScrollState.tick(0f, maxScroll));
    }

    private PackUiScrollbar.Metrics getCraftListScrollbarMetrics() {
        int listX = this.getCraftListX();
        int listY = this.getCraftListY();
        int listWidth = this.getCraftListWidth();
        int contentHeight = this.filteredCraftableRecipes.size() * this.LINE_HEIGHT;
        int maxScroll = Math.max(0, contentHeight - this.CRAFT_LIST_HEIGHT);
        return PackUiScrollbar.compute(contentHeight, this.CRAFT_LIST_HEIGHT, listX + listWidth - 5, listY, 3, this.CRAFT_LIST_HEIGHT, this.craftListScrollState.tick(0f, maxScroll));
    }

    private int toRowScroll(PackUiScrollbar.Metrics metrics, int mouseY, int grabOffset, int rowHeight, int maxScrollRows) {
        int pixelScroll = PackUiScrollbar.scrollFromThumb(metrics, (double)mouseY, grabOffset);
        return Math.max(0, Math.min(maxScrollRows, Math.round((float)pixelScroll / (float)rowHeight)));
    }

    private void selectCraftRecipe(PackUtilCraftingHelper.CraftableRecipeOption option) {
        if (option == null) {
            return;
        }
        this.selectedCraftOption = option;
        this.selectedCraftResult = option.result.method_7972();
        this.savedItemNameValue = option.label;
        this.savedCraftSelectedRecipeId = option.recipeId;
        this.savedCraftSelectedRecipeKey = option.recipeKey;
        if (this.itemNameField != null) {
            this.itemNameField.setText(this.savedItemNameValue);
        }
        this.setStatus("Selected craft: " + option.label + option.craftableNow ? " (x" + option.maxCraftsNow + ")" : "", option.craftableNow ? class_124.field_1060 : class_124.field_1065);
        this.saveState();
    }

    private void clearCraftRecipeSelection() {
        this.craftPlanSelectedIndex = -1;
        this.selectedCraftOption = null;
        this.selectedCraftResult = class_1799.field_8037;
        this.savedCraftSelectedRecipeId = -1;
        this.savedCraftSelectedRecipeKey = "";
    }

    private PackUtilCraftingHelper.CraftableRecipeOption resolveCraftOption(CraftAction.CraftEntry entry) {
        if (entry == null) {
            return null;
        }
        return PackUtilCraftingHelper.findInList(this.craftableRecipes, entry.recipeKey, entry.recipeId);
    }

    private CraftAction.CraftEntry buildConfiguredCraftEntry() {
        if (this.selectedCraftOption == null || this.selectedCraftResult.method_7960()) {
            return null;
        }
        int configuredAmount = this.parseConfiguredCraftAmount();
        if (configuredAmount <= 0) {
            return null;
        }
        return CraftAction.CraftEntry.fromOption(this.selectedCraftOption, configuredAmount, this.craftUseMaxAmount);
    }

    private CraftAction.CraftEntry getSelectedPlannedEntry() {
        if (this.craftPlanSelectedIndex < 0 || this.craftPlanSelectedIndex >= this.plannedCraftEntries.size()) {
            return null;
        }
        return (CraftAction.CraftEntry)this.plannedCraftEntries.get(this.craftPlanSelectedIndex);
    }

    private void selectCraftPlanEntry(int index) {
        if (index < 0 || index >= this.plannedCraftEntries.size()) {
            this.craftPlanSelectedIndex = -1;
            this.selectedCraftOption = null;
            this.selectedCraftResult = class_1799.field_8037;
            this.savedCraftSelectedRecipeId = -1;
            this.savedCraftSelectedRecipeKey = "";
            this.saveState();
            return;
        }
        this.craftPlanSelectedIndex = index;
        CraftEntry entry = (CraftAction.CraftEntry)this.plannedCraftEntries.get(index);
        if (entry == null) { /* goto L180; */ }
        this.craftUseMaxAmount = entry.useMaxAmount;
        this.savedTimesValue = String.valueOf(Math.max(1, entry.amount));
        if (this.timesField == null) { /* goto L134; */ }
        this.timesField.setText(this.savedTimesValue);
        this.timesField.setEditable(!this.craftUseMaxAmount);
        CraftableRecipeOption option = this.resolveCraftOption(entry);
        if (option != null) {
            this.selectCraftRecipe(option);
        } else {
            this.savedCraftSelectedRecipeId = entry.recipeId;
            this.savedCraftSelectedRecipeKey = entry.recipeKey;
            this.selectedCraftOption = null;
            this.selectedCraftResult = class_1799.field_8037;
        }
        this.saveState();
    }

    private void addOrUpdatePlannedCraftEntry() {
        CraftEntry draft = this.buildConfiguredCraftEntry();
        if (draft == null) {
            this.setStatus("Select a recipe and amount first", class_124.field_1061);
            return;
        }
        int existingIndex = -1;
        for (int i = 0; i < this.plannedCraftEntries.size(); i++) {
            CraftEntry existing = (CraftAction.CraftEntry)this.plannedCraftEntries.get(i);
            if (existing == null) {
            } else {
                if (draft.recipeKey.isBlank() || !draft.recipeKey.equalsIgnoreCase(existing.recipeKey)) {
                    if (draft.recipeId < 0) { /* goto @109; */ }
                }
                existingIndex = i;
                /* goto @115; */
            }
        }
        if (this.craftPlanSelectedIndex >= 0) {
            if (this.craftPlanSelectedIndex < this.plannedCraftEntries.size()) {
                this.plannedCraftEntries.set(this.craftPlanSelectedIndex, draft);
            }
        } else {
            if (existingIndex >= 0) {
                this.plannedCraftEntries.set(existingIndex, draft);
                this.craftPlanSelectedIndex = existingIndex;
            } else {
                this.plannedCraftEntries.add(draft);
                this.craftPlanSelectedIndex = this.plannedCraftEntries.size() - 1;
            }
        }
        maxPlanScroll = Math.max(0, this.plannedCraftEntries.size() - 4);
        this.craftPlanScrollOffset = Math.max(0, Math.min(maxPlanScroll, this.craftPlanSelectedIndex));
        this.saveState();
    }

    private void removePlannedCraftEntry(int index) {
        if (index < 0 || index >= this.plannedCraftEntries.size()) {
            return;
        }
        this.plannedCraftEntries.remove(index);
        if (this.craftPlanSelectedIndex == index) {
            this.craftPlanSelectedIndex = -1;
        } else {
            if (this.craftPlanSelectedIndex > index) {
                this.craftPlanSelectedIndex = this.craftPlanSelectedIndex - 1;
            }
        }
        this.craftPlanScrollOffset = Math.max(0, Math.min(Math.max(0, this.plannedCraftEntries.size() - 4), this.craftPlanScrollOffset));
        this.saveState();
    }

    private List<CraftAction.CraftEntry> getActiveCraftEntries() {
        if (this.plannedCraftEntries.isEmpty()) { /* goto L85; */ }
        List<CraftAction.CraftEntry> copies = new ArrayList(this.plannedCraftEntries.size());
        var var2 = this.plannedCraftEntries.iterator();
        while (var2.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)var2.next();
            if (entry != null) {
                if (!entry.hasRecipe()) continue;
                copies.add(entry.copy());
            }
        }
        return copies;
        L85: ;
        draft = this.buildConfiguredCraftEntry();
        return draft == null ? List.of() : List.of(draft);
    }

    private CraftAction buildCraftPlanAction() {
        List<CraftAction.CraftEntry> activeEntries = this.getActiveCraftEntries();
        if (activeEntries.isEmpty()) {
            return null;
        }
        CraftAction action = new CraftAction();
        action.setEntries(activeEntries);
        return action;
    }

    private class_2561 getCraftPlanRowLabel(CraftAction.CraftEntry entry) {
        if (entry == null || !entry.hasRecipe()) {
            return class_2561.method_43470("(empty)");
        }
        CraftableRecipeOption option = this.resolveCraftOption(entry);
        String amount = entry.useMaxAmount ? "Max" : "x" + Math.max(1, entry.amount);
        class_2561 resultName = option != null ? option.result.method_7964().method_27661() : class_2561.method_43470(entry.resultName);
        return class_2561.method_43473().method_10852(resultName).method_10852(class_2561.method_43470(" | " + amount + option != null && option.craftableNow ? " | x" + option.maxCraftsNow : ""));
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        boolean anyFocused = false;
        class_11908 input = this.textFields.iterator();
        while (input.hasNext()) {
            PackUtilChatField field = (PackUtilChatField)input.next();
            if (!field.isFocused()) { /* goto @59; */ }
            anyFocused = true;
            break;
        }
        if (!anyFocused) { /* goto L184; */ }
        if (keyCode != 256) { /* goto L118; */ }
        input = this.textFields.iterator();
        while (input.hasNext()) {
            field = (PackUtilChatField)input.next();
            field.setFocused(false);
        }
        return true;
        L118: ;
        input = new class_11908(keyCode, scanCode, modifiers);
        field = this.textFields.iterator();
        while (field.hasNext()) {
            PackUtilChatField field = (PackUtilChatField)field.next();
            if (field.isFocused()) {
                field.keyPressed(input);
                return true;
            }
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        int codepoint = chr;
        if (!this.visible) {
            return false;
        }
        class_11905 input = new class_11905((char)codepoint, modifiers);
        var var5 = this.textFields.iterator();
        while (var5.hasNext()) {
            PackUtilChatField field = (PackUtilChatField)var5.next();
            if (field.isFocused()) {
                if (!field.charTyped(input)) continue;
                return true;
            }
        }
        return false;
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        this.expireTransientStatus();
        int panelHeight = this.PANEL_HEIGHT;
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.PANEL_WIDTH, panelHeight, this.visible, this.collapsed);
        this.renderWindowFrame(context, mouseX, mouseY, bounds, "Fabricator", this.collapsed, this.isDragging);
        boolean clipBody = this.beginWindowBodyClip(context, bounds, this.collapsed);
        if (!clipBody) {
            this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.isDragging);
            return;
        }
        try {
            int labelX = this.panelX + 10;
            int fieldX = this.panelX + this.LABEL_WIDTH + 15;
            int fieldWidth = this.getFieldWidth();
            PackUtilText.draw(context, MC.field_1772, "Action", PackUtilText.Tone.MUTED, labelX, this.getActionRowY() + 3, false);
            PackUtilText.draw(context, MC.field_1772, "Cycle", PackUtilText.Tone.MUTED, labelX + 36, this.getActionRowY() + 3, false);
            this.drawOverlayButton(context, fieldX, this.getActionRowY(), fieldWidth, 16, this.currentAction.displayName, PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
            int halfWidth = this.textFields.iterator();
            while (halfWidth.hasNext()) {
                PackUtilChatField field = (PackUtilChatField)halfWidth.next();
                field.render(context, mouseX, mouseY, delta);
            }
            if (this.showsTargetFields()) {
                PackUtilText.draw(context, MC.field_1772, "Slot", PackUtilText.Tone.MUTED, labelX, this.getSlotRowY() + 3, false);
                PackUtilText.draw(context, MC.field_1772, "Item", PackUtilText.Tone.MUTED, labelX, this.getItemRowY() + 3, false);
                if (this.isClickSelectorRelevant()) { /* goto L330; */ }
                if (!this.isDropModeRelevant()) { /* goto L555; */ }
                L330: ;
                PackUtilText.draw(context, MC.field_1772, this.isDropModeRelevant() ? "Drop Mode" : "Click", PackUtilText.Tone.MUTED, labelX, this.getOptionRowY() + 3, false);
                halfWidth = (fieldWidth - 2) / 2;
                if (this.isClickSelectorRelevant()) {
                    this.drawOverlayButton(context, fieldX, this.getOptionRowY(), halfWidth, 16, "Left", this.currentButtonIndex == 0 ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
                    this.drawOverlayButton(context, fieldX + halfWidth + 2, this.getOptionRowY(), fieldWidth - halfWidth - 2, 16, "Right", this.currentButtonIndex == 1 ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
                } else {
                    this.drawOverlayButton(context, fieldX, this.getOptionRowY(), halfWidth, 16, "Single", !this.dropWholeStack ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
                    this.drawOverlayButton(context, fieldX + halfWidth + 2, this.getOptionRowY(), fieldWidth - halfWidth - 2, 16, "Stack", this.dropWholeStack ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
                }
                PackUtilText.draw(context, MC.field_1772, this.getTimesLabel(), PackUtilText.Tone.MUTED, labelX, this.getStandardTimesRowY() + 3, false);
            } else {
                this.refreshCraftableRecipes(false);
                listX = this.getCraftListX();
                listWidth = this.getCraftListWidth();
                PackUiListRenderer.drawHeader(context, MC.field_1772, "Craft Plan", labelX, this.getCraftPlanHeaderY());
                if (!this.plannedCraftEntries.isEmpty()) {
                    PackUiListRenderer.drawHeaderAction(context, MC.field_1772, "Clear All", true, listX, listWidth, this.getCraftPlanHeaderY(), mouseX, mouseY);
                }
                int planListY = this.getCraftPlanListY();
                int planContentWidth = this.getCraftPlanContentWidth();
                PackUiListRenderer.drawFrame(context, listX, planListY, listWidth, this.CRAFT_PLAN_HEIGHT, this.craftPlanSelectedIndex >= 0);
                if (this.plannedCraftEntries.isEmpty()) {
                    PackUiListRenderer.drawEmptyState(context, MC.field_1772, "(no plan - pick recipe and Add)", listX, planListY + 2, planContentWidth);
                } else {
                    int maxPlanScrollPx = Math.max(0, this.plannedCraftEntries.size() * 13 - this.CRAFT_PLAN_HEIGHT);
                    this.craftPlanScrollOffset = Math.max(0, Math.min(this.craftPlanScrollOffset, Math.max(0, this.plannedCraftEntries.size() - 4)));
                    this.craftPlanScrollState.setTarget(this.craftPlanScrollOffset * 13, maxPlanScrollPx);
                    int drawPlanScroll = this.craftPlanScrollState.tick(delta, maxPlanScrollPx);
                    PackUtilUiScale.enableOverlayScissor(context, listX + 1, planListY + 1, listX + listWidth - 1, planListY + this.CRAFT_PLAN_HEIGHT - 1);
                    int startIndex = drawPlanScroll / 13;
                    int rowY = planListY - drawPlanScroll % 13;
                    int index = startIndex;
                    while (index < this.plannedCraftEntries.size()) {
                        if (rowY >= planListY + this.CRAFT_PLAN_HEIGHT) break;
                        boolean hovered = mouseX >= listX && mouseX < listX + planContentWidth && mouseY >= rowY && mouseY < rowY + 12;
                        boolean selected = index == this.craftPlanSelectedIndex;
                        PackUiListRenderer.drawRow(context, MC.field_1772, this.getCraftPlanRowLabel((CraftAction.CraftEntry)this.plannedCraftEntries.get(index)), listX, rowY, planContentWidth, 12, hovered, selected, PackUiListRenderer.RowTone.NORMAL, true);
                        boolean removeHovered = mouseX >= listX + planContentWidth - 16 && mouseX < listX + planContentWidth - 2 && mouseY >= rowY && mouseY < rowY + 12;
                        PackUiListRenderer.drawIconButton(context, listX + planContentWidth - 14, rowY, 12, PackUiAssets.ICON_WINDOW_CLOSE, removeHovered, true);
                        index++;
                        rowY += 13;
                    }
                    context.method_44380();
                }
                craftPlanScrollbar = this.getCraftPlanScrollbarMetrics();
                PackUiScrollbar.draw(context, craftPlanScrollbar, craftPlanScrollbar.contains((double)mouseX, (double)mouseY), this.activeScrollbarDrag == 1);
                if (this.selectedCraftResult.method_7960()) {
                    PackUtilText.draw(context, MC.field_1772, "Recipe: none selected", PackUtilText.Tone.MUTED, listX, this.getCraftSummaryY(), false);
                } else {
                    summaryText = class_2561.method_43473().method_10852(this.selectedCraftResult.method_7964().method_27661()).method_10852(class_2561.method_43470(" x" + this.selectedCraftResult.method_7947() + this.selectedCraftOption != null && this.selectedCraftOption.craftableNow ? " | x" + this.selectedCraftOption.maxCraftsNow : ""));
                    context.method_51439(MC.field_1772, summaryText, listX, this.getCraftSummaryY(), -5592406, false);
                }
                PackUtilText.draw(context, MC.field_1772, "Amount", PackUtilText.Tone.MUTED, labelX, this.getCraftAmountRowY() + 3, false);
                if (this.craftUseMaxAmount) {
                    this.drawOverlayButton(context, this.getCraftAmountToggleX(), this.getCraftAmountRowY(), this.getCraftAmountToggleWidth(), 16, "Use Max", PackUiOverlayButton.Variant.PRIMARY, true, mouseX, mouseY);
                } else {
                    this.drawOverlayButton(context, this.getCraftAmountToggleX(), this.getCraftAmountRowY(), this.getCraftAmountToggleWidth(), 16, "Use Max", PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
                }
                PackUiListRenderer.drawHeader(context, MC.field_1772, "Recipes", listX, this.getCraftSearchLabelY());
                listY = this.getCraftListY();
                recipeContentWidth = this.getCraftListContentWidth();
                PackUiListRenderer.drawFrame(context, listX, listY, listWidth, this.CRAFT_LIST_HEIGHT, this.selectedCraftOption != null);
                PackUtilUiScale.enableOverlayScissor(context, listX + 1, listY + 1, listX + listWidth - 1, listY + this.CRAFT_LIST_HEIGHT - 1);
                if (this.filteredCraftableRecipes.isEmpty()) {
                    emptyText = MC.field_1724 != null && MC.field_1724.field_7512 instanceof class_9884 ? "No crafting recipes match this search." : "Open inventory or stand near a table to load recipes.";
                    PackUiListRenderer.drawEmptyState(context, MC.field_1772, emptyText, listX, listY + 4, recipeContentWidth);
                } else {
                    maxRecipeScrollPx = Math.max(0, this.filteredCraftableRecipes.size() * this.LINE_HEIGHT - this.CRAFT_LIST_HEIGHT);
                    this.craftScrollOffset = Math.max(0, Math.min(this.craftScrollOffset, Math.max(0, this.filteredCraftableRecipes.size() - 6)));
                    this.craftListScrollState.setTarget(this.craftScrollOffset * this.LINE_HEIGHT, maxRecipeScrollPx);
                    drawRecipeScroll = this.craftListScrollState.tick(delta, maxRecipeScrollPx);
                    startIndex = drawRecipeScroll / this.LINE_HEIGHT;
                    rowY = listY - drawRecipeScroll % this.LINE_HEIGHT;
                    index = startIndex;
                    while (index < this.filteredCraftableRecipes.size()) {
                        if (rowY >= listY + this.CRAFT_LIST_HEIGHT) break;
                        CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)this.filteredCraftableRecipes.get(index);
                        boolean hovered = mouseX >= listX && mouseX <= listX + recipeContentWidth && mouseY >= rowY && mouseY < rowY + this.LINE_HEIGHT;
                        boolean selected = this.selectedCraftOption != null && option.recipeKey.equalsIgnoreCase(this.selectedCraftOption.recipeKey);
                        class_2561 richLabel = class_2561.method_43473().method_10852(option.result.method_7964().method_27661()).method_10852(class_2561.method_43470(" x" + option.result.method_7947() + option.craftableNow ? " | x" + option.maxCraftsNow : ""));
                        PackUiListRenderer.drawRow(context, MC.field_1772, richLabel, listX + 2, rowY, recipeContentWidth - 2, this.LINE_HEIGHT, hovered, selected, option.craftableNow ? PackUiListRenderer.RowTone.READY : PackUiListRenderer.RowTone.WARNING, true);
                        PackUiListRenderer.drawDivider(context, listX + 2, rowY + this.LINE_HEIGHT - 1, recipeContentWidth - 2);
                        index++;
                        rowY = rowY + this.LINE_HEIGHT;
                    }
                }
                context.method_44380();
                craftListScrollbar = this.getCraftListScrollbarMetrics();
                PackUiScrollbar.draw(context, craftListScrollbar, craftListScrollbar.contains((double)mouseX, (double)mouseY), this.activeScrollbarDrag == 2);
                readyCount = this.craftableRecipes.stream().filter(PackUtilFabricatorOverlay::lambda$render$6).count();
                recipeCountLine = PackUtilText.trimToWidth(MC.field_1772, readyCount + " ready / " + this.craftableRecipes.size() + " total", listWidth, PackUtilText.Tone.MUTED);
                PackUtilText.draw(context, MC.field_1772, recipeCountLine, PackUtilText.Tone.MUTED, listX, listY + this.CRAFT_LIST_HEIGHT + 2, false);
            }
            btnY = this.getBottomButtonY();
            btnArea = this.PANEL_WIDTH - 20;
            gap = 2;
            bw = (btnArea - gap * 2) / 3;
            bx = this.panelX + 10;
            sendLabel = this.isCraftMode() ? this.craftExecutionInProgress ? "Crafting..." : "Craft" : "Send";
            this.drawOverlayButton(context, bx, btnY, bw, this.BUTTON_HEIGHT, sendLabel, PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
            bx = bx + (bw + gap);
            this.drawOverlayButton(context, bx, btnY, bw, this.BUTTON_HEIGHT, "Queue", PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
            bx = bx + (bw + gap);
            this.drawOverlayButton(context, bx, btnY, bw, this.BUTTON_HEIGHT, "Macro", PackUiOverlayButton.Variant.SECONDARY, true, mouseX, mouseY);
            infoWidth = this.PANEL_WIDTH - 20;
            if (!this.statusMessage.isEmpty()) {
                trimmedStatus = PackUtilText.trimToWidth(MC.field_1772, this.statusMessage, infoWidth, PackUtilText.Tone.BODY);
                colorInt = this.statusColor.method_532();
                color = colorInt != null ? colorInt.intValue() | -16777216 : -1;
                PackUtilText.draw(context, MC.field_1772, trimmedStatus, color, this.panelX + 10, this.getStatusY(), true);
            } else {
                summary = PackUtilText.trimToWidth(MC.field_1772, this.getTargetSummary(), infoWidth, PackUtilText.Tone.MUTED);
                PackUtilText.draw(context, MC.field_1772, summary, PackUtilText.Tone.MUTED, this.panelX + 10, this.getStatusY(), false);
            }
            actionLine = PackUtilText.trimToWidth(MC.field_1772, this.currentAction.getDescription(this.dropWholeStack), infoWidth, PackUtilText.Tone.MUTED);
            PackUtilText.draw(context, MC.field_1772, actionLine, PackUtilText.Tone.MUTED, this.panelX + 10, this.getActionInfoY(), false);
            tipLine = this.isCraftMode() ? "Tip: Pick a recipe, set an amount or enable Max Amount, then Craft, Queue, or Add Macro." : "Tip: Slot + item = exact match. Item only = best match. Right-click a slot to fill both.";
            tipLine = PackUtilText.trimToWidth(MC.field_1772, tipLine, infoWidth, PackUtilText.Tone.MUTED);
            PackUtilText.draw(context, MC.field_1772, tipLine, PackUtilText.Tone.MUTED, this.panelX + 10, this.panelY + panelHeight - 15, false);
        }
        finally {
            this.endWindowBodyClip(context, clipBody);
            this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.isDragging);
            throw var27;
        }
    }

    private void cycleAction() {
        this.currentActionIndex = (this.currentActionIndex + 1) % this.actions.length;
        this.currentAction = this.actions[this.currentActionIndex];
        this.clearStatus();
        this.initWidgets();
        this.saveState();
    }

    private void cycleActionBackwards() {
        this.currentActionIndex = (this.currentActionIndex - 1 + this.actions.length) % this.actions.length;
        this.currentAction = this.actions[this.currentActionIndex];
        this.clearStatus();
        this.initWidgets();
        this.saveState();
    }

    private void clearWidgets() {
        this.textFields.clear();
        this.craftSearchField = null;
    }

    public void onSlotClick(class_1735 slot, int button) {
        if (slot == null) {
            return;
        }
        if (this.isCraftMode()) {
            return;
        }
        int stableSlotId = PackUtilInventoryHelper.toUserVisibleSlot(MC, slot.field_7874);
        this.selectedSlotId = stableSlotId;
        this.savedSlotValue = String.valueOf(stableSlotId);
        if (this.slotField != null) {
            this.slotField.setText(this.savedSlotValue);
        }
        String itemName = this.getItemNameFromSlot(slot.field_7874);
        this.savedSlotValue = String.valueOf(stableSlotId);
        if (this.slotField != null) {
            this.slotField.setText(this.savedSlotValue);
        }
        if (!itemName.isEmpty()) {
            this.savedItemNameValue = itemName;
            if (this.itemNameField != null) {
                this.itemNameField.setText(itemName);
            }
            this.setStatus("Selected slot " + stableSlotId + ": " + itemName, class_124.field_1060);
        } else {
            this.savedItemNameValue = "";
            if (this.itemNameField != null) {
                this.itemNameField.setText("");
            }
            this.setStatus("Selected slot " + stableSlotId + " (Empty)", class_124.field_1054);
        }
        this.saveState();
    }

    private void sendToMacro(PackUtilMacroEditorOverlay macroEditor) {
        try {
            if (this.isCraftMode()) {
                CraftAction craftAction = this.buildCraftPlanAction();
                if (craftAction == null || !craftAction.hasEntries()) {
                    this.setStatus("§cSelect a recipe or add a craft entry first!", class_124.field_1061);
                    return;
                }
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("§cInvalid value", class_124.field_1061);
            L315: ;
            return;
        }
        try {
            macroEditor.addAction(craftAction);
            return;
        }
        catch (NumberFormatException e) {
            this.setStatus("§cInvalid value", class_124.field_1061);
            L315: ;
            return;
        }
        try {
            enteredSlot = this.parseEnteredSlot();
            String itemName = this.getEnteredItemName();
            int repeats = this.resolveRepeatCount(-1);
            if (repeats <= 0) {
                return;
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("§cInvalid value", class_124.field_1061);
            L315: ;
            return;
        }
        try {
            if (enteredSlot == null) {
                if (itemName.isEmpty()) {
                    this.setStatus("§cPick a slot or enter an item name first!", class_124.field_1061);
                    return;
                }
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("§cInvalid value", class_124.field_1061);
            L315: ;
            return;
        }
        try {
            class_1703 handler = this.getActiveHandler();
            int resolvedSlot = enteredSlot == null ? -1 : PackUtilInventoryHelper.resolveConfiguredHandlerSlot(MC, enteredSlot.intValue());
            if (enteredSlot != null) {
                if (!this.isValidHandlerSlot(handler, resolvedSlot)) {
                    this.setStatus("§cSlot " + enteredSlot + " is not available in this screen!", class_124.field_1061);
                    return;
                }
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("§cInvalid value", class_124.field_1061);
            L315: ;
            return;
        }
        try {
            ItemAction itemAction = new ItemAction();
            itemAction.actionIndex = this.currentAction.toPacketAction(this.dropWholeStack).ordinal();
            itemAction.button = this.getEffectiveButton();
            itemAction.times = repeats;
            if (enteredSlot != null) {
                itemAction.useSlot = true;
                itemAction.targetSlot = enteredSlot.intValue();
            }
            if (!itemName.isEmpty()) {
                itemAction.itemNames.add(itemName);
                itemAction.itemTimes.add(repeats);
                itemAction.itemActionIdx.add(itemAction.actionIndex);
                itemAction.itemButtons.add(itemAction.button);
            }
            macroEditor.addAction(itemAction);
            this.setStatus("§aAdded " + this.currentAction.displayName + " action to macro!", class_124.field_1060);
        }
        catch (NumberFormatException e) {
            this.setStatus("§cInvalid value", class_124.field_1061);
            L315: ;
            return;
        }
    }

    private class_2596<?> buildFabricatedPacket(int slot) {
        if (MC.field_1724 == null) {
            return null;
        }
        class_1703 handler = MC.field_1724.field_7512;
        if (handler == null) {
            return null;
        }
        class_1713 actionType = this.currentAction.toPacketAction(this.dropWholeStack).toSlotActionType();
        return new class_2813(handler.field_7763, handler.method_37421(), (short)slot, (byte)this.getEffectiveButton(), actionType, new Int2ObjectArrayMap(), class_10938.field_58176);
    }

    private void sendPacket(boolean queue) {
        if (this.isCraftMode()) {
            this.sendCraft(queue);
            return;
        }
        try {
            int slot = this.resolveTargetSlotForBuild();
            if (slot < 0) {
                return;
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("Invalid number format", class_124.field_1061);
            L71: ;
            return;
        }
        try {
            int repeats = this.resolveRepeatCount(slot);
            if (repeats <= 0) {
                return;
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("Invalid number format", class_124.field_1061);
            L71: ;
            return;
        }
        try {
            class_634 handler = MC.method_1562();
            if (handler == null) {
                return;
            }
        }
        catch (NumberFormatException e) {
            this.setStatus("Invalid number format", class_124.field_1061);
            L71: ;
            return;
        }
        try {
            this.sendFabricatedPackets(slot, repeats, queue, handler);
        }
        catch (NumberFormatException e) {
            this.setStatus("Invalid number format", class_124.field_1061);
            L71: ;
            return;
        }
    }

    private void sendCraft(boolean queue) {
        List<CraftAction.CraftEntry> entries = this.getActiveCraftEntries();
        if (entries.isEmpty()) {
            this.setStatus("Select a recipe or add a craft entry first", class_124.field_1061);
            return;
        }
        if (!queue) { /* goto L307; */ }
        Thread craftThread = entries.iterator();
        while (craftThread.hasNext()) {
            CraftEntry entry = (CraftAction.CraftEntry)craftThread.next();
            CraftableRecipeOption option = PackUtilCraftingHelper.findCraftableRecipe(MC, entry.recipeKey);
            if (option != null) continue;
            option = PackUtilCraftingHelper.findCraftableRecipe(MC, entry.recipeId);
            if (option == null) {
                String msg = "Recipe not found: " + entry.resultName;
                this.setStatus(msg, class_124.field_1061);
                PackUtilClientMessaging.sendPrefixed("Â§c" + msg);
                return;
            }
            desiredAmount = PackUtilCraftingHelper.getEffectiveRequestedOutput(option, entry.amount, entry.useMaxAmount);
            if (desiredAmount <= 0) {
                String msg = "No space or materials for " + entry.resultName;
                this.setStatus(msg, class_124.field_1061);
                PackUtilClientMessaging.sendPrefixed("Â§c" + msg);
                return;
            }
            packets = PackUtilCraftingHelper.buildCraftSequence(MC, entry.recipeKey, entry.recipeId, desiredAmount);
            if (!packets.isEmpty()) { /* goto L261; */ }
            String msg = option.hasSyncedRecipe() ? "Failed to build craft queue for " + entry.resultName : "Queue craft needs a synced recipe for " + entry.resultName;
            this.setStatus(msg, class_124.field_1061);
            PackUtilClientMessaging.sendPrefixed("Â§c" + msg);
            return;
            msg = packets.iterator();
            while (msg.hasNext()) {
                class_2596<?> packet = (class_2596)msg.next();
                PackUtilSharedState.get().enqueuePacket(packet);
            }
        }
        return;
        L307: ;
        if (this.craftExecutionInProgress) {
            this.setStatus("A craft is already running", class_124.field_1054);
            return;
        }
        this.craftExecutionInProgress = true;
        craftThread = new Thread(this::lambda$sendCraft$8 /* captured: entries */, "PackUtil-Fabricator-Craft");
        craftThread.setDaemon(true);
        craftThread.start();
    }

    private void sendFabricatedPackets(int slot, int repeats, boolean queue, class_634 handler) {
        List<class_2596<?>> packets = this.buildFabricatedSequence(slot, repeats);
        if (packets.isEmpty()) {
            this.setStatus("Failed to build packet", class_124.field_1061);
            return;
        }
        if (!queue) { /* goto L95; */ }
        int queuedCount = packets.iterator();
        while (queuedCount.hasNext()) {
            class_2596<?> packet = (class_2596)queuedCount.next();
            PackUtilSharedState.get().enqueuePacket(packet);
        }
        this.setStatus("Queued " + packets.size() + " packet(s)", class_124.field_1060);
        return;
        L95: ;
        queuedCount = PackUtilSharedState.get().flushDelayedPackets(handler);
        packet = packets.iterator();
        while (packet.hasNext()) {
            class_2596<?> packet = (class_2596)packet.next();
            PackUtilPacketSender.sendPacket(packet);
        }
        if (queuedCount > 0) {
            this.setStatus("Sent " + queuedCount + " queued + " + packets.size() + " new packet(s)", class_124.field_1060);
        } else {
            this.setStatus("Sent " + packets.size() + " packet(s)", class_124.field_1060);
        }
    }

    private void setStatus(String message, class_124 color) {
        this.statusMessage = message;
        this.statusColor = color;
        this.statusExpiresAtMs = 0L;
    }

    private void clearStatus() {
        this.statusMessage = "";
        this.statusColor = class_124.field_1080;
        this.statusExpiresAtMs = 0L;
    }

    private void expireTransientStatus() {
        if (this.statusExpiresAtMs <= 0L) {
            return;
        }
        if (System.currentTimeMillis() >= this.statusExpiresAtMs) {
            this.clearStatus();
        }
    }

    private String getTimesLabel() {
        if (this.isCraftMode()) {
            return "Amount";
        }
        if (this.isDropModeRelevant() && !this.dropWholeStack) {
            return "Items";
        }
        return "Times";
    }

    private String getTargetSummary() {
        if (!this.isCraftMode()) { /* goto L181; */ }
        String planInfo = this.plannedCraftEntries.isEmpty() ? "Plan: none" : "Plan: " + this.plannedCraftEntries.size() + " entr" + this.plannedCraftEntries.size() == 1 ? "y" : "ies";
        if (this.selectedCraftResult.method_7960()) {
            return planInfo + " | Recipe: none selected";
        }
        String source = this.selectedCraftOption != null && this.selectedCraftOption.craftSource == PackUtilCraftingHelper.CraftSource.TABLE_3X3 ? "Table" : "2x2";
        String availability = this.selectedCraftOption != null ? PackUtilCraftingHelper.getAvailabilityLabel(this.selectedCraftOption) : "Unavailable";
        String amountMode = this.craftUseMaxAmount ? "Max" : "x" + Math.max(1, this.parseConfiguredCraftAmount());
        return planInfo + " | Recipe: " + this.selectedCraftResult.method_7964().getString() + " | " + source + " | " + availability + " | " + amountMode;
        slot = this.parseEnteredSlot();
        itemName = this.getEnteredItemName();
        if (slot != null && !itemName.isEmpty()) {
            return "Target: '" + itemName + "' in exact slot " + slot;
        }
        if (slot != null) {
            return "Target: exact slot " + slot;
        }
        if (!itemName.isEmpty()) {
            return "Target: best matching '" + itemName + "'";
        }
        return "Target: choose a slot or enter an item name";
    }

    private class_1703 getActiveHandler() {
        if (MC.field_1724 != null && MC.field_1724.field_7512 != null) {
            return MC.field_1724.field_7512;
        }
        return this.parentScreen != null ? this.parentScreen.method_17577() : null;
    }

    private Integer parseEnteredSlot() {
        if (this.slotField == null) {
            return null;
        }
        String text = this.slotField.getText().trim();
        if (text.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(text);
        }
        catch (NumberFormatException ignored) {
            return null;
        }
    }

    private String getEnteredItemName() {
        return this.itemNameField == null ? "" : this.itemNameField.getText().trim();
    }

    private boolean isValidHandlerSlot(class_1703 handler, int slotId) {
        return handler != null && slotId >= 0 && slotId < handler.field_7761.size();
    }

    private boolean stackMatchesQuery(class_1799 stack, String query) {
        if (stack == null || stack.method_7960() || query == null || query.isBlank()) {
            return false;
        }
        return ItemTarget.fromLegacyEntry(query).score(stack, -1) >= 0;
    }

    private boolean slotMatchesItemQuery(class_1703 handler, int slotId, String itemQuery) {
        if (!this.isValidHandlerSlot(handler, slotId)) {
            return false;
        }
        class_1735 slot = (class_1735)handler.field_7761.get(slotId);
        return slot != null && this.stackMatchesQuery(slot.method_7677(), itemQuery);
    }

    private int resolveTargetSlotForBuild() {
        class_1703 handler = this.getActiveHandler();
        if (handler == null) {
            this.setStatus("No screen is open right now", class_124.field_1061);
            return -1;
        }
        Integer enteredSlot = this.parseEnteredSlot();
        String itemName = this.getEnteredItemName();
        int resolvedSlot = enteredSlot == null ? -1 : PackUtilInventoryHelper.resolveConfiguredHandlerSlot(MC, enteredSlot.intValue());
        this.setStatus("Slot " + enteredSlot + " is not available in this screen", class_124.field_1061);
        if (enteredSlot != null && !this.isValidHandlerSlot(handler, resolvedSlot)) {
            return -1;
        }
        if (enteredSlot != null) {
            if (!itemName.isEmpty()) {
                if (this.slotMatchesItemQuery(handler, resolvedSlot, itemName)) {
                    return resolvedSlot;
                }
                this.setStatus("Slot " + enteredSlot + " does not contain '" + itemName + "'", class_124.field_1061);
                return -1;
            }
        }
        if (enteredSlot != null) {
            return resolvedSlot;
        }
        if (!itemName.isEmpty()) {
            Integer foundSlot = this.findSlotByItemName(itemName);
            if (foundSlot == null) {
                this.setStatus("No item matching '" + itemName + "' found", class_124.field_1061);
                return -1;
            }
            return foundSlot.intValue();
        }
        this.setStatus("Pick a slot or enter an item name first", class_124.field_1061);
        return -1;
    }

    private int resolveRepeatCount(int slot) {
        try {
            int value = Integer.parseInt(this.timesField.getText().trim());
        }
        catch (NumberFormatException e) {
            this.setStatus(this.currentAction.isCraftAction() ? "Invalid amount" : "Invalid repeat count", class_124.field_1061);
            return -1;
        }
        if (value > 0) { /* goto L78; */ }
        this.setStatus(this.currentAction.isCraftAction() ? "Amount must be at least 1" : "Repeat count must be at least 1", class_124.field_1061);
        return -1;
        if (!this.currentAction.isCraftAction()) {
            return value;
        }
        if (this.selectedCraftOption == null || this.selectedCraftResult.method_7960()) {
            this.setStatus("Select a recipe first", class_124.field_1061);
            return -1;
        }
        if (MC.field_1724 != null) {
            int outputPerCraft = MC.field_1724.field_7512;
            if (outputPerCraft instanceof class_9884) {
                craftingHandler = (class_9884)outputPerCraft;
            }
        } else {
            this.setStatus("Open a crafting screen first", class_124.field_1061);
            return -1;
        }
        int outputPerCraft = Math.max(1, this.selectedCraftResult.method_7947());
        int repeats = Math.max(1, (int)Math.ceil((double)value / (double)outputPerCraft));
        return repeats;
    }

    private int resolveCraftAmount() {
        if (this.selectedCraftOption == null || this.selectedCraftResult.method_7960()) {
            this.setStatus("Select a recipe first", class_124.field_1061);
            return -1;
        }
        if (!this.craftUseMaxAmount) { /* goto L78; */ }
        int maxAmount = this.selectedCraftOption.maxOutputNow;
        if (maxAmount > 0) { /* goto L76; */ }
        this.setStatus(this.selectedCraftOption.hasMaterialsNow ? "No room to store crafted items" : "Missing materials", class_124.field_1061);
        return -1;
        return maxAmount;
        L78: ;
        value = this.parseConfiguredCraftAmount();
        if (value <= 0) {
            this.setStatus("Invalid craft amount", class_124.field_1061);
            return -1;
        }
        return value;
    }

    private int parseConfiguredCraftAmount() {
        if (this.timesField == null) {
            return 1;
        }
        try {
            int value = Integer.parseInt(this.timesField.getText().trim());
            return Math.max(1, value);
        }
        catch (NumberFormatException e) {
            return -1;
        }
    }

    private List<class_2596<?>> buildFabricatedSequence(int slot, int repeats) {
        List<class_2596<?>> packets = new ArrayList();
        for (int i = 0; i < repeats; i++) {
            class_2596<?> built = this.buildFabricatedPacket(slot);
            if (built != null) continue;
            return List.of();
            packets.add(this.normalizeFabricatorPacket(built));
        }
        return packets;
    }

    private class_2596<?> normalizeFabricatorPacket(class_2596<?> packet) {
        if (packet instanceof class_2813) {
            class_2813 clickSlotPacket = (class_2813)packet;
            return PacketRegenerator.regenerate(clickSlotPacket);
        }
        return packet;
    }

    private Integer findSlotByItemName(String searchName) {
        if (searchName == null || searchName.trim().isEmpty()) {
            return null;
        }
        class_1703 handler = this.getActiveHandler();
        if (handler == null) {
            return null;
        }
        ItemTarget target = ItemTarget.fromLegacyEntry(searchName);
        Integer bestMatch = null;
        int bestScore = -1;
        var var6 = handler.field_7761.iterator();
        while (var6.hasNext()) {
            class_1735 slot = (class_1735)var6.next();
            if (slot == null) continue;
            while (slot.method_7677().method_7960()) {
            }
            int score = target.score(slot.method_7677(), -1);
            if (score > bestScore) {
                bestScore = score;
                bestMatch = slot.field_7874;
            }
        }
        return bestScore >= 0 ? bestMatch : null;
    }

    private void applyPresetMetrics() {
        this.DEFAULT_PANEL_WIDTH = 236;
        this.LINE_HEIGHT = 14;
        this.CRAFT_LIST_HEIGHT = 84;
        this.CRAFT_PLAN_HEIGHT = 52;
        this.FIELD_WIDTH = 100;
        this.BUTTON_HEIGHT = 20;
        this.LABEL_WIDTH = 64;
    }

    private int standardPanelHeight() {
        return 240;
    }

    private int craftModePanelHeight() {
        return 384;
    }
}
