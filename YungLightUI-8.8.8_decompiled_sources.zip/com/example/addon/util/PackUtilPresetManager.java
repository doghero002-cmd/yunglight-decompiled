/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.YungLightAddon;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketPreset;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilSharedState;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2596;

public class PackUtilPresetManager {
    private static final File PRESETS_FOLDER = new File(YungLightAddon.FOLDER, "presets");
    private static final PackUtilPresetManager INSTANCE = new PackUtilPresetManager();
    private static final String USER_PRESET_PREFIX = "User Preset ";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private PackUtilPresetManager() {
        if (!PRESETS_FOLDER.exists()) {
            PRESETS_FOLDER.mkdirs();
        }
    }

    public static PackUtilPresetManager get() {
        return INSTANCE;
    }

    public boolean savePreset(String name) {
        String sanitized = this.sanitizePresetName(name);
        if (sanitized == null) {
            PackUtilClientMessaging.sendPrefixed("§ePreset name cannot be empty.");
            return false;
        }
        if (this.isReservedPresetName(sanitized)) {
            PackUtilClientMessaging.sendPrefixed("§cThat preset name is reserved for developer templates.");
            return false;
        }
        this.savePresetObject(this.captureCurrentPreset(sanitized), true);
        return true;
    }

    public String saveCurrentAsUserPreset() {
        String name = this.nextAvailableUserPresetName();
        this.savePresetObject(this.captureCurrentPreset(name), true);
        return name;
    }

    public boolean overwriteUserPreset(String name) {
        String sanitized = this.sanitizePresetName(name);
        if (sanitized == null) {
            PackUtilClientMessaging.sendPrefixed("§eSelect a user preset first.");
            return false;
        }
        if (this.isReservedPresetName(sanitized)) {
            PackUtilClientMessaging.sendPrefixed("§cDeveloper presets cannot be overwritten.");
            return false;
        }
        File file = new File(PRESETS_FOLDER, sanitized + ".json");
        if (!file.exists()) {
            PackUtilClientMessaging.sendPrefixed("§cUser preset not found: " + sanitized);
            return false;
        }
        this.savePresetObject(this.captureCurrentPreset(sanitized), true);
        return true;
    }

    public boolean loadPreset(String name) {
        PresetEntry entry = this.getPresetEntry(name);
        if (entry == null) {
            PackUtilClientMessaging.sendPrefixed("§cPreset not found: " + name);
            return false;
        }
        this.applyPreset(entry.preset());
        PackUtilClientMessaging.sendPrefixed("§aLoaded preset: " + entry.name());
        return true;
    }

    public boolean deleteUserPreset(String name) {
        String sanitized = this.sanitizePresetName(name);
        if (sanitized == null) {
            PackUtilClientMessaging.sendPrefixed("§eSelect a user preset first.");
            return false;
        }
        if (this.isReservedPresetName(sanitized)) {
            PackUtilClientMessaging.sendPrefixed("§cDeveloper presets cannot be deleted.");
            return false;
        }
        File file = new File(PRESETS_FOLDER, sanitized + ".json");
        if (!file.exists()) {
            PackUtilClientMessaging.sendPrefixed("§cUser preset not found: " + sanitized);
            return false;
        }
        if (!file.delete()) {
            PackUtilClientMessaging.sendPrefixed("§cFailed to delete preset: " + sanitized);
            return false;
        }
        PackUtilClientMessaging.sendPrefixed("§aDeleted preset: " + sanitized);
        return true;
    }

    public boolean isReservedPresetName(String name) {
        String normalized = this.normalizePresetName(name);
        if (normalized.isEmpty()) {
            return false;
        }
        var var3 = this.getBuiltInPresetEntries().iterator();
        while (var3.hasNext()) {
            PresetEntry entry = (PackUtilPresetManager.PresetEntry)var3.next();
            if (!this.normalizePresetName(entry.name()).equals(normalized)) continue;
            return true;
        }
        return false;
    }

    public PackUtilPresetManager.PresetEntry getPresetEntry(String name) {
        String normalized = this.normalizePresetName(name);
        if (normalized.isEmpty()) {
            return null;
        }
        var var3 = this.getBuiltInPresetEntries().iterator();
        while (var3.hasNext()) {
            PresetEntry entry = (PackUtilPresetManager.PresetEntry)var3.next();
            if (!this.normalizePresetName(entry.name()).equals(normalized)) continue;
            return entry;
        }
        var3 = this.getUserPresetEntries().iterator();
        while (var3.hasNext()) {
            entry = (PackUtilPresetManager.PresetEntry)var3.next();
            if (!this.normalizePresetName(entry.name()).equals(normalized)) continue;
            return entry;
        }
        return null;
    }

    public List<PackUtilPresetManager.PresetEntry> getBuiltInPresetEntries() {
        PackUtilModule module = PackUtilModule.get();
        List<PackUtilPresetManager.PresetEntry> entries = new ArrayList();
        entries.add(new PackUtilPresetManager.PresetEntry(this.presetFromClasses("Default", module.defaultC2SPackets(), module.defaultS2CPackets()), true));
        String[] tmp0 = new String[12];
        tmp0[0] = "HandSwingC2SPacket";
        tmp0[1] = "PlayerActionC2SPacket";
        tmp0[2] = "PlayerInteractBlockC2SPacket";
        tmp0[3] = "PlayerInteractEntityC2SPacket";
        tmp0[4] = "PlayerInteractItemC2SPacket";
        tmp0[5] = "PlayerMoveC2SPacket";
        tmp0[6] = "PlayerMoveC2SPacket.Full";
        tmp0[7] = "PlayerMoveC2SPacket.LookAndOnGround";
        tmp0[8] = "PlayerMoveC2SPacket.OnGroundOnly";
        tmp0[9] = "PlayerMoveC2SPacket.PositionAndOnGround";
        tmp0[10] = "TeleportConfirmC2SPacket";
        tmp0[11] = "VehicleMoveC2SPacket";
        entries.add(new PackUtilPresetManager.PresetEntry(this.presetFromPacketNames("Movement & World", Set.of(tmp0), Set.of("BlockEventS2CPacket", "BlockUpdateS2CPacket", "EntityPositionSyncS2CPacket", "EntityVelocityUpdateS2CPacket", "PlayerPositionLookS2CPacket", "PlayerRotationS2CPacket", "VehicleMoveS2CPacket", "WorldEventS2CPacket")), true));
        String[] tmp1 = new String[14];
        tmp1[0] = "ButtonClickC2SPacket";
        tmp1[1] = "ChatMessageC2SPacket";
        tmp1[2] = "CommandExecutionC2SPacket";
        tmp1[3] = "CraftRequestC2SPacket";
        tmp1[4] = "ClickSlotC2SPacket";
        tmp1[5] = "CreativeInventoryActionC2SPacket";
        tmp1[6] = "PickItemFromBlockC2SPacket";
        tmp1[7] = "PickItemFromEntityC2SPacket";
        tmp1[8] = "PlayerActionC2SPacket";
        tmp1[9] = "RecipeBookDataC2SPacket";
        tmp1[10] = "RenameItemC2SPacket";
        tmp1[11] = "RequestCommandCompletionsC2SPacket";
        tmp1[12] = "ChatCommandSignedC2SPacket";
        tmp1[13] = "UpdateSignC2SPacket";
        String[] tmp2 = new String[13];
        tmp2[0] = "ChatMessageS2CPacket";
        tmp2[1] = "CloseScreenS2CPacket";
        tmp2[2] = "CommandSuggestionsS2CPacket";
        tmp2[3] = "CommandTreeS2CPacket";
        tmp2[4] = "GameMessageS2CPacket";
        tmp2[5] = "InventoryS2CPacket";
        tmp2[6] = "OpenMountScreenS2CPacket";
        tmp2[7] = "OpenScreenS2CPacket";
        tmp2[8] = "ScreenHandlerPropertyUpdateS2CPacket";
        tmp2[9] = "ScreenHandlerSlotUpdateS2CPacket";
        tmp2[10] = "SetCursorItemS2CPacket";
        tmp2[11] = "SetPlayerInventoryS2CPacket";
        tmp2[12] = "SetTradeOffersS2CPacket";
        entries.add(new PackUtilPresetManager.PresetEntry(this.presetFromPacketNames("Inventory, Chat & Commands", Set.of(tmp1), Set.of(tmp2)), true));
        String[] tmp3 = new String[12];
        tmp3[0] = "BlockEventS2CPacket";
        tmp3[1] = "BlockUpdateS2CPacket";
        tmp3[2] = "ChunkDataS2CPacket";
        tmp3[3] = "ChunkDeltaUpdateS2CPacket";
        tmp3[4] = "ChunkLoadDistanceS2CPacket";
        tmp3[5] = "ChunkRenderDistanceCenterS2CPacket";
        tmp3[6] = "ChunkSentS2CPacket";
        tmp3[7] = "GameStateChangeS2CPacket";
        tmp3[8] = "LightUpdateS2CPacket";
        tmp3[9] = "StartChunkSendS2CPacket";
        tmp3[10] = "UnloadChunkS2CPacket";
        tmp3[11] = "WorldEventS2CPacket";
        entries.add(new PackUtilPresetManager.PresetEntry(this.presetFromPacketNames("Chunk Freeze & Blocks", Set.of("AcknowledgeChunksC2SPacket", "ClientCommandC2SPacket", "HandSwingC2SPacket", "PlayerActionC2SPacket", "PlayerInputC2SPacket", "PlayerInteractBlockC2SPacket", "PlayerInteractItemC2SPacket", "PlayerMoveC2SPacket.Full"), Set.of(tmp3)), true));
        return entries;
    }

    public List<PackUtilPresetManager.PresetEntry> getUserPresetEntries() {
        List<PackUtilPresetManager.PresetEntry> entries = new ArrayList();
        File[] files = PRESETS_FOLDER.listFiles(PackUtilPresetManager::lambda$getUserPresetEntries$0);
        if (files == null) {
            return entries;
        }
        var var3 = files;
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            File file = var3[var5];
            FileReader reader = new FileReader(file);
            PackUtilPacketPreset preset = (PackUtilPacketPreset)this.gson.fromJson(reader, PackUtilPacketPreset.class);
            if (preset == null) {
                reader.close();
            } else {
                if (!preset.name == null || preset.name.isBlank()) continue;
                preset.name = file.getName().replace(".json", "");
                if (this.isReservedPresetName(preset.name)) {
                    YungLightAddon.LOG.warn("Ignoring user preset with reserved built-in name: {}", preset.name);
                    reader.close();
                } else {
                    if (preset.c2sPackets != null) continue;
                    preset.c2sPackets = new LinkedHashSet();
                    if (preset.s2cPackets != null) continue;
                    preset.s2cPackets = new LinkedHashSet();
                    entries.add(new PackUtilPresetManager.PresetEntry(preset, false));
                    reader.close();
                    /* goto L250; */
                    preset = null;
                    reader.close();
                    /* goto L247; */
                    var var9 = null;
                    preset.addSuppressed(var9);
                    L247: ;
                    throw preset;
                    L250: ;
                    /* goto @273; */
                    e = null;
                    YungLightAddon.LOG.error("Failed to read preset file {}", file.getName(), e);
                }
            }
        }
        entries.sort(Comparator.comparing(PackUtilPresetManager::lambda$getUserPresetEntries$1));
        return entries;
    }

    public List<String> getPresetNames() {
        List<String> names = new ArrayList();
        var var2 = this.getBuiltInPresetEntries().iterator();
        while (var2.hasNext()) {
            PresetEntry entry = (PackUtilPresetManager.PresetEntry)var2.next();
            names.add(entry.name());
        }
        var2 = this.getUserPresetEntries().iterator();
        while (var2.hasNext()) {
            entry = (PackUtilPresetManager.PresetEntry)var2.next();
            names.add(entry.name());
        }
        return names;
    }

    private PackUtilPacketPreset captureCurrentPreset(String name) {
        PackUtilSharedState shared = PackUtilSharedState.get();
        Set<String> c2s = this.encodePacketNames(shared.getC2SPackets());
        Set<String> s2c = this.encodePacketNames(shared.getS2CPackets());
        return new PackUtilPacketPreset(name, c2s, s2c);
    }

    private PackUtilPacketPreset presetFromClasses(String name, Collection<Class<? extends class_2596<?>>> c2sPackets, Collection<Class<? extends class_2596<?>>> s2cPackets) {
        return new PackUtilPacketPreset(name, this.encodePacketNames(c2sPackets), this.encodePacketNames(s2cPackets));
    }

    private PackUtilPacketPreset presetFromPacketNames(String name, Set<String> c2sNames, Set<String> s2cNames) {
        return new PackUtilPacketPreset(name, (Set)this.resolvePacketNames(c2sNames, true).stream().map(this::encodePacketName).collect(Collectors.toCollection(LinkedHashSet::new)), (Set)this.resolvePacketNames(s2cNames, false).stream().map(this::encodePacketName).collect(Collectors.toCollection(LinkedHashSet::new)));
    }

    private Set<String> encodePacketNames(Collection<Class<? extends class_2596<?>>> packets) {
        return (Set)packets.stream().map(this::encodePacketName).filter(PackUtilPresetManager::lambda$encodePacketNames$2).collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private String encodePacketName(Class<? extends class_2596<?>> packetClass) {
        String name = PackUtilPacketRegistry.getName(packetClass);
        return name != null ? name : packetClass.getName();
    }

    private Set<Class<? extends class_2596<?>>> resolvePacketNames(Collection<String> names, boolean c2s) {
        Set<Class<? extends class_2596<?>>> resolved = new LinkedHashSet();
        Set<Class<? extends class_2596<?>>> pool = c2s ? PackUtilPacketRegistry.getC2SPackets() : PackUtilPacketRegistry.getS2CPackets();
        var var5 = names.iterator();
        while (var5.hasNext()) {
            String packetName = (String)var5.next();
            if (packetName == null) { /* goto @31; */ }
            while (packetName.isBlank()) {
            }
            Class<? extends class_2596<?>> packetClass = PackUtilPacketRegistry.getPacket(packetName);
            if (packetClass == null) {
                packetClass = PackUtilPacketRegistry.getPacket(PackUtilPacketNamer.getFriendlyName(packetName));
            }
            try {
                Class<?> direct = Class.forName(packetName);
                if (class_2596.class.isAssignableFrom(direct)) {
                    packetClass = direct;
                }
            }
            catch (ClassNotFoundException direct) {
                if (packetClass == null) { /* goto @152; */ }
                if (!pool.contains(packetClass)) { /* goto @152; */ }
                resolved.add(packetClass);
                /* goto @165; */
            }
            resolved.add(packetClass);
            if (packetClass != null && pool.contains(packetClass)) {
            } else {
                YungLightAddon.LOG.warn("Unknown packet name in preset: {}", packetName);
            }
        }
        return resolved;
    }

    private void savePresetObject(PackUtilPacketPreset preset, boolean notify) {
        File file = new File(PRESETS_FOLDER, preset.name + ".json");
        FileWriter writer = new FileWriter(file);
        this.gson.toJson(preset, writer);
        if (notify) {
            PackUtilClientMessaging.sendPrefixed("§aSaved preset: " + preset.name);
        }
        writer.close();
        /* goto L86; */
        var var5 = null;
        writer.close();
        /* goto L83; */
        var var6 = null;
        var5.addSuppressed(var6);
        L83: ;
        throw var5;
        L86: ;
        /* goto L117; */
        e = null;
        YungLightAddon.LOG.error("Failed to save preset", e);
        PackUtilClientMessaging.sendPrefixed("§cFailed to save preset: " + e.getMessage());
        L117: ;
    }

    private void applyPreset(PackUtilPacketPreset preset) {
        PackUtilModule module = PackUtilModule.get();
        module.setC2SPackets(this.resolvePacketNames(preset.c2sPackets, true));
        module.setS2CPackets(this.resolvePacketNames(preset.s2cPackets, false));
    }

    private String nextAvailableUserPresetName() {
        int index = 1;
        L2: ;
        String candidate = "User Preset " + index;
        if (this.getPresetEntry(candidate) == null) {
            return candidate;
        }
        index++;
        /* goto L2; */
    }

    private String sanitizePresetName(String name) {
        if (name == null) {
            return null;
        }
        String sanitized = name.trim();
        return sanitized.isEmpty() ? null : sanitized;
    }

    private String normalizePresetName(String name) {
        return name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
    }
}
