/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiLabel;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiScrollViewport;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiSurface;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.gui.packui.PackUiViewportSlot;
import com.example.addon.gui.packui.PackUiWindowNode;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilPacketSelectorOverlay
extends PackUtilWindow {
    private static final class_310 MC = class_310.method_1551();
    private static final int MIN_PANEL_WIDTH = 230;
    private static final int ROW_HEIGHT = 16;
    private static final int MAX_VISIBLE_ROWS = 12;
    private static final int PAD = 6;
    private static final int VIEWPORT_BORDER = 1;
    private static final int HEADER_CONTROL = 12;
    private static final int HEADER_ARROW_WIDTH = 10;
    private static final int HEADER_ARROW_GAP = 3;
    private static final float HEADER_CLICK_DRAG_THRESHOLD = 3f;
    private static final int PACKET_LIST_SCROLLBAR_WIDTH = 6;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiWindowNode windowNode = new PackUiWindowNode("Select Packet");
    private final PackUiSurface surface = new PackUiSurface(this.theme, this.windowNode);
    private final PackUiTextField searchField = new PackUiTextField();
    private final PackUiLabel summaryLabel = new PackUiLabel("", PackUiTone.MUTED).setTrimToBounds(true);
    private final PackUiViewportSlot listSlot = new PackUiViewportSlot();
    private PackUiScrollViewport listViewport = null;
    private final List<Class<? extends class_2596<?>>> allPackets = new ArrayList();
    private List<Class<? extends class_2596<?>>> activePool = List.of();
    private List<Class<? extends class_2596<?>>> filteredPackets = List.of();
    private Set<Class<? extends class_2596<?>>> excludedPackets = Set.of();
    private Set<Class<? extends class_2596<?>>> selectedPackets = Set.of();
    private boolean visible = false;
    private boolean collapsed = false;
    private boolean dragging = false;
    private boolean dragMoved = false;
    private float dragOffsetX;
    private float dragOffsetY;
    private float pressStartUiX;
    private float pressStartUiY;
    private int pressStartPanelX;
    private int pressStartPanelY;
    private float closeHover = 0f;
    private float closeVisibility = 1f;
    private int panelX;
    private int panelY;
    private int panelWidth = 230;
    private int panelHeight = 0;
    private final PackUiSmoothScroll listScroll = new PackUiSmoothScroll();
    private int contentHeight = 0;
    private boolean scrollbarDragging = false;
    private int scrollbarGrabOffset = 0;
    private Consumer<Class<? extends class_2596<?>>> onSelect;
    private BiConsumer<Class<? extends class_2596<?>>, Boolean> onToggleSelect;
    private boolean closeOnSelect = true;
    private boolean toggleMode = false;

    public PackUtilPacketSelectorOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.allPackets.addAll(PackUtilPacketRegistry.getC2SPackets());
        this.allPackets.addAll(PackUtilPacketRegistry.getS2CPackets());
        this.allPackets.sort(Comparator.comparing(PackUtilPacketNamer::getFriendlyName, String.CASE_INSENSITIVE_ORDER));
        this.activePool = List.copyOf(this.allPackets);
        this.filteredPackets = List.copyOf(this.allPackets);
        this.buildUi();
    }

    private void buildUi() {
        this.panelWidth = this.panelMinimumWidth();
        this.windowNode.setCenterTitle(false);
        this.windowNode.setTitleTone(PackUiTone.LABEL);
        this.windowNode.setTitleAreaInsets(this.panelPadding() + 2, this.panelPadding() + this.headerControlSize() + this.headerArrowWidth() + this.headerArrowGap() + 12);
        this.windowNode.content().setGap(this.windowContentGap()).setPadding(PackUiInsets.all(this.panelPadding()));
        this.searchField.setPlaceholder("Search packets...").setFieldHeight(this.searchFieldHeight()).setGrowX(true).setOnChange(this::lambda$buildUi$0);
        this.rebuildUi();
    }

    private void rebuildUi() {
        this.windowNode.content().clearChildren();
        this.windowNode.setTitle(this.toggleMode ? "Packet Selector [Toggle]" : "Packet Selector");
        this.windowNode.content().add(this.searchField);
        this.listSlot.setPreferredHeight((float)this.computeViewportHeight(this.filteredPackets.size()));
        this.windowNode.content().add(this.listSlot);
        this.summaryLabel.setText(this.toggleMode ? this.filteredPackets.size() + " packets | Selected " + this.selectedPackets.size() : this.filteredPackets.size() + " packets");
        this.windowNode.content().add(this.summaryLabel);
        this.contentHeight = this.filteredPackets.size() * this.rowHeight();
    }

    private int computeViewportHeight(int itemCount) {
        int visibleRows = Math.max(5, Math.min(this.maxVisibleRows(), Math.max(1, itemCount)));
        return visibleRows * this.rowHeight() + 2;
    }

    public void open(Consumer<Class<? extends class_2596<?>>> onSelect) {
        this.openWith(onSelect, this.allPackets, Set.of(), true);
    }

    public void openC2S(Consumer<Class<? extends class_2596<?>>> onSelect) {
        this.openC2S(onSelect, Set.of(), true);
    }

    public void openC2S(Consumer<Class<? extends class_2596<?>>> onSelect, Collection<Class<? extends class_2596<?>>> excludedPackets, boolean closeOnSelect) {
        List<Class<? extends class_2596<?>>> c2s = new ArrayList(PackUtilPacketRegistry.getC2SPackets());
        c2s.sort(Comparator.comparing(PackUtilPacketNamer::getFriendlyName, String.CASE_INSENSITIVE_ORDER));
        this.openWith(onSelect, c2s, excludedPackets, closeOnSelect);
    }

    public void openS2C(Consumer<Class<? extends class_2596<?>>> onSelect) {
        this.openS2C(onSelect, Set.of(), true);
    }

    public void openS2C(Consumer<Class<? extends class_2596<?>>> onSelect, Collection<Class<? extends class_2596<?>>> excludedPackets, boolean closeOnSelect) {
        List<Class<? extends class_2596<?>>> s2c = new ArrayList(PackUtilPacketRegistry.getS2CPackets());
        s2c.sort(Comparator.comparing(PackUtilPacketNamer::getFriendlyName, String.CASE_INSENSITIVE_ORDER));
        this.openWith(onSelect, s2c, excludedPackets, closeOnSelect);
    }

    public void openToggleC2S(BiConsumer<Class<? extends class_2596<?>>, Boolean> onToggleSelect, Collection<Class<? extends class_2596<?>>> selectedPackets) {
        List<Class<? extends class_2596<?>>> c2s = new ArrayList(PackUtilPacketRegistry.getC2SPackets());
        c2s.sort(Comparator.comparing(PackUtilPacketNamer::getFriendlyName, String.CASE_INSENSITIVE_ORDER));
        this.openToggleWith(onToggleSelect, c2s, selectedPackets);
    }

    public void openToggleS2C(BiConsumer<Class<? extends class_2596<?>>, Boolean> onToggleSelect, Collection<Class<? extends class_2596<?>>> selectedPackets) {
        List<Class<? extends class_2596<?>>> s2c = new ArrayList(PackUtilPacketRegistry.getS2CPackets());
        s2c.sort(Comparator.comparing(PackUtilPacketNamer::getFriendlyName, String.CASE_INSENSITIVE_ORDER));
        this.openToggleWith(onToggleSelect, s2c, selectedPackets);
    }

    private void openWith(Consumer<Class<? extends class_2596<?>>> onSelect, List<Class<? extends class_2596<?>>> pool, Collection<Class<? extends class_2596<?>>> excludedPackets, boolean closeOnSelect) {
        this.visible = true;
        this.collapsed = false;
        this.onSelect = onSelect;
        this.onToggleSelect = null;
        this.closeOnSelect = closeOnSelect;
        this.toggleMode = false;
        this.excludedPackets = excludedPackets == null ? Set.of() : new LinkedHashSet(excludedPackets);
        this.selectedPackets = Set.of();
        this.activePool = this.filterExcluded(pool);
        this.updateFilter("");
        this.finishOpen();
    }

    private void openToggleWith(BiConsumer<Class<? extends class_2596<?>>, Boolean> onToggleSelect, List<Class<? extends class_2596<?>>> pool, Collection<Class<? extends class_2596<?>>> selectedPackets) {
        this.visible = true;
        this.collapsed = false;
        this.onSelect = null;
        this.onToggleSelect = onToggleSelect;
        this.closeOnSelect = false;
        this.toggleMode = true;
        this.excludedPackets = Set.of();
        this.selectedPackets = selectedPackets == null ? new LinkedHashSet() : new LinkedHashSet(selectedPackets);
        this.activePool = new ArrayList(pool);
        this.updateFilter("");
        this.finishOpen();
    }

    private void finishOpen() {
        this.listScroll.jumpTo(0, 0);
        this.rebuildUi();
        PackUiRenderContext metrics = this.surface.measurementContext();
        if (metrics != null) {
            this.panelHeight = Math.round(this.windowNode.preferredHeight(metrics, (float)this.panelWidth));
        }
        PackUiViewport viewport = this.surface.viewport();
        this.panelX = Math.max(8, Math.round((viewport.uiWidth() - (float)this.panelWidth) / 2f));
        this.panelY = Math.max(8, Math.round((viewport.uiHeight() - (float)this.panelHeight) / 2f));
        PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        this.searchField.setText("");
        this.searchField.setFocused(true);
        this.windowNode.syncShowBody(true);
        PackUtilOverlayManager.get().bringToFrontParent(this);
    }

    public void close() {
        this.visible = false;
        this.collapsed = false;
        this.dragging = false;
        this.dragMoved = false;
        this.onSelect = null;
        this.onToggleSelect = null;
        this.excludedPackets = Set.of();
        this.selectedPackets = Set.of();
        this.closeOnSelect = true;
        this.toggleMode = false;
        this.surface.clearFocusedTextInputs();
        this.windowNode.syncShowBody(true);
    }

    public boolean isVisible() {
        return this.visible;
    }

    private void updateFilter(String query) {
        String filter = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (filter.isEmpty()) {
            this.filteredPackets = new ArrayList(this.filterExcluded(this.activePool));
        } else {
            this.filteredPackets = (List)this.filterExcluded(this.activePool).stream().filter(PackUtilPacketSelectorOverlay::lambda$updateFilter$1 /* captured: filter */).collect(Collectors.toList());
        }
        this.contentHeight = this.filteredPackets.size() * this.rowHeight();
        this.rebuildUi();
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible || MC == null || MC.field_1772 == null) {
            return;
        }
        this.rebuildUi();
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX((double)mouseX);
        float uiMouseY = viewport.toUiY((double)mouseY);
        boolean headerHovered = this.isOverHeaderUi(uiMouseX, uiMouseY);
        PackUiRenderContext metrics = new PackUiRenderContext(context, MC.field_1772, viewport, this.theme, uiMouseX, uiMouseY, delta);
        this.windowNode.setShowBody(!this.collapsed);
        this.windowNode.setActive(true);
        this.windowNode.setHeaderHovered(headerHovered);
        this.panelHeight = Math.round(this.windowNode.preferredHeight(metrics, (float)this.panelWidth));
        this.panelHeight = Math.max(this.theme.headerHeight(), this.panelHeight);
        this.windowNode.setBounds((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight);
        this.surface.render(context, mouseX, mouseY, delta);
        PackUiText.interOverlayFlush(context);
        if (!this.collapsed) {
            this.renderListViewport(context, viewport, uiMouseX, uiMouseY, delta);
        }
        this.renderHeaderControls(context, viewport, uiMouseX, uiMouseY, delta);
    }

    private void renderListViewport(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta) {
        int viewX = Math.round(this.listSlot.x());
        int viewY = Math.round(this.listSlot.y());
        int viewW = Math.round(this.listSlot.width());
        int viewH = Math.round(this.listSlot.height());
        if (viewW <= 2 || viewH <= 2) {
            return;
        }
        int contentHeight = this.filteredPackets.size() * this.rowHeight();
        if (this.listViewport == null || this.listViewport.getX() != viewX || this.listViewport.getY() != viewY || this.listViewport.getWidth() != viewW || this.listViewport.getHeight() != viewH) {
            this.listViewport = new PackUiScrollViewport(viewX, viewY, viewW, viewH, this.rowHeight(), 6);
        }
        this.listViewport.setContentHeight(contentHeight);
        this.listViewport.beginRender(context, this.theme.borderSoft(), 905969664);
        try {
            this.listViewport.renderSimple(context, this.filteredPackets.size(), this::lambda$renderListViewport$2 /* captured: context */);
        }
        finally {
            this.listViewport.endRender(context);
            throw var11;
        }
        this.renderScrollbar(context, viewX, viewY, viewW, viewH, uiMouseX, uiMouseY);
    }

    private void renderPacketRowSimple(class_332 context, Class<? extends class_2596<?>> packetClass, int x, int y, int width, int index) {
        boolean c2s = PackUtilPacketRegistry.getC2SPackets().contains(packetClass);
        boolean selected = this.toggleMode && this.selectedPackets.contains(packetClass);
        int rowColor = selected ? PackUtilColors.packetRowSelectedBg(false) : PackUtilColors.packetRowBg(c2s, index, false);
        int color = selected ? PackUtilColors.packetRowSelectedText() : PackUtilColors.packetRowText(c2s, index);
        context.method_25294(x, y, x + width, y + this.rowHeight(), rowColor);
        String name = PackUtilPacketNamer.getFriendlyName(packetClass);
        int textWidth = width - 10;
        String trimmed = PackUiText.trimToWidth(this.textRenderer, name, textWidth, this.theme.fontFor(PackUiTone.BODY), color);
        int textY = PackUiSizing.alignTextY(y, this.rowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
        PackUiText.draw(context, this.textRenderer, trimmed, this.theme.fontFor(PackUiTone.BODY), color, x + 6, textY, false);
        context.method_25294(x + 4, y + this.rowHeight() - 1, x + width - 4, y + this.rowHeight(), PackUtilColors.packetRowDivider());
    }

    private void renderPacketRow(class_332 context, PackUiRenderContext rowContext, Class<? extends class_2596<?>> packetClass, int x, int y, int width, int index) {
        boolean c2s = PackUtilPacketRegistry.getC2SPackets().contains(packetClass);
        boolean hovered = this.uiContains((float)x, (float)y, (float)width, (float)this.rowHeight(), rowContext.mouseX(), rowContext.mouseY());
        boolean selected = this.toggleMode && this.selectedPackets.contains(packetClass);
        int rowColor = selected ? PackUtilColors.packetRowSelectedBg(hovered) : PackUtilColors.packetRowBg(c2s, index, hovered);
        int color = selected ? PackUtilColors.packetRowSelectedText() : PackUtilColors.packetRowText(c2s, index);
        context.method_25294(x + 2, y, x + width - 2, y + this.rowHeight(), rowColor);
        String name = PackUtilPacketNamer.getFriendlyName(packetClass);
        String trimmed = PackUiText.trimToWidth(this.textRenderer, name, width - this.markerReserveWidth(), this.theme.fontFor(PackUiTone.BODY), color);
        int textY = PackUiSizing.alignTextY(y, this.rowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
        PackUiText.draw(context, this.textRenderer, trimmed, this.theme.fontFor(PackUiTone.BODY), color, x + 6, textY, false);
        context.method_25294(x + 4, y + this.rowHeight() - 1, x + width - 4, y + this.rowHeight(), PackUtilColors.packetRowDivider());
    }

    private void renderScrollbar(class_332 context, int viewX, int viewY, int viewW, int viewH, float uiMouseX, float uiMouseY) {
        if (this.listViewport != null) {
            this.listViewport.renderScrollbar(context, (double)uiMouseX, (double)uiMouseY);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        this.close();
        if (button == 0 && this.isOverCloseButton(uiMouseX, uiMouseY) && this.closeVisibility > 0.01f) {
            return true;
        }
        this.dragging = true;
        if (button == 0 && this.isOverHeaderUi(uiMouseX, uiMouseY)) {
            this.dragMoved = false;
            this.dragOffsetX = uiMouseX - (float)this.panelX;
            this.dragOffsetY = uiMouseY - (float)this.panelY;
            this.pressStartUiX = uiMouseX;
            this.pressStartUiY = uiMouseY;
            this.pressStartPanelX = this.panelX;
            this.pressStartPanelY = this.panelY;
            return true;
        }
        if (!this.collapsed && this.surface.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (!this.collapsed && button == 0 && this.uiContains(this.listSlot.x(), this.listSlot.y(), this.listSlot.width(), this.listSlot.height(), uiMouseX, uiMouseY) && this.listViewport != null && this.listViewport.mouseClicked((double)uiMouseX, (double)uiMouseY, button)) {
            return true;
        }
        if (this.collapsed) { /* goto L561; */ }
        if (button != 0) { /* goto L561; */ }
        if (!this.uiContains(this.listSlot.x(), this.listSlot.y(), this.listSlot.width(), this.listSlot.height(), uiMouseX, uiMouseY)) { /* goto L561; */ }
        int index = (int)((uiMouseY - this.listSlot.y() + (float)this.listViewport.getScrollOffset()) / (float)this.rowHeight());
        if (index < 0) { /* goto L561; */ }
        if (index >= this.filteredPackets.size()) { /* goto L561; */ }
        Class<? extends class_2596<?>> selectedPacket = (Class)this.filteredPackets.get(index);
        if (this.toggleMode) {
            this.selectedPackets = new LinkedHashSet(this.selectedPackets);
            if (this.selectedPackets.contains(selectedPacket)) {
                this.selectedPackets.remove(selectedPacket);
                boolean nowSelected = false;
            } else {
                this.selectedPackets.add(selectedPacket);
                boolean nowSelected = true;
            }
            if (this.onToggleSelect != null) {
                this.onToggleSelect.accept(selectedPacket, nowSelected);
            }
            this.rebuildUi();
            this.searchField.setFocused(true);
        } else {
            if (this.onSelect != null) {
                this.onSelect.accept(selectedPacket);
            }
            if (this.closeOnSelect) {
                this.close();
            } else {
                this.excludedPackets = new LinkedHashSet(this.excludedPackets);
                this.excludedPackets.add(selectedPacket);
                this.activePool = this.filterExcluded(this.activePool);
                this.updateFilter(this.searchField.text());
                this.searchField.setFocused(true);
            }
        }
        return true;
        L561: ;
        if (!this.uiContains((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight, uiMouseX, uiMouseY)) {
            this.close();
            return true;
        }
        return true;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        if (button != 0) { /* goto L194; */ }
        if (!this.dragging) { /* goto L194; */ }
        boolean moved = this.dragMoved || Math.abs(uiMouseX - this.pressStartUiX) >= 3f || Math.abs(uiMouseY - this.pressStartUiY) >= 3f || this.panelX != this.pressStartPanelX || this.panelY != this.pressStartPanelY;
        this.dragging = false;
        this.dragMoved = false;
        if (moved) { /* goto L192; */ }
        if (!this.isOverHeaderUi(uiMouseX, uiMouseY)) { /* goto L192; */ }
        if (this.isOverCloseButton(uiMouseX, uiMouseY)) { /* goto L192; */ }
        this.collapsed = !this.collapsed;
        if (this.collapsed) {
            this.surface.clearFocusedTextInputs();
        }
        this.windowNode.setShowBody(!this.collapsed);
        return true;
        if (button == 0) {
            if (this.listViewport != null) {
                this.listViewport.mouseReleased();
            }
        }
        if (!this.collapsed && this.surface.mouseReleased(mouseX, mouseY, button)) {
            return true;
        }
        return this.visible && this.uiContains((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight, uiMouseX, uiMouseY);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        if (this.dragging) {
            if (button == 0) {
                int nextX = Math.round(uiMouseX - this.dragOffsetX);
                int nextY = Math.round(uiMouseY - this.dragOffsetY);
                if (nextX != this.panelX || nextY != this.panelY) {
                    this.dragMoved = true;
                }
                PackUtilWindowLayout clamped = this.clampToViewport(new PackUtilWindowLayout(nextX, nextY, this.panelWidth, this.panelHeight, this.visible, this.collapsed));
                this.panelX = clamped.x;
                this.panelY = clamped.y;
                return true;
            }
        }
        this.listViewport.mouseDragged((double)uiMouseX, (double)uiMouseY);
        if (!this.collapsed && this.uiContains(this.listSlot.x(), this.listSlot.y(), this.listSlot.width(), this.listSlot.height(), uiMouseX, uiMouseY) && this.listViewport != null && this.listViewport.isScrollbarDragging()) {
            return true;
        }
        if (!this.collapsed && this.surface.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        return this.visible && this.uiContains((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight, uiMouseX, uiMouseY);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (keyCode == 256) {
            if (this.searchField.isFocused()) {
                this.searchField.setFocused(false);
                return true;
            }
            this.close();
            return true;
        }
        this.surface.keyPressed(keyCode, scanCode, modifiers);
        if (this.searchField.isFocused()) {
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        return this.visible && this.surface.charTyped(chr, modifiers);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.visible) {
            return false;
        }
        PackUiViewport viewport = this.surface.viewport();
        float uiMouseX = viewport.toUiX(mouseX);
        float uiMouseY = viewport.toUiY(mouseY);
        this.listViewport.mouseScrolled((double)uiMouseX, (double)uiMouseY, amount);
        if (!this.collapsed && this.uiContains(this.listSlot.x(), this.listSlot.y(), this.listSlot.width(), this.listSlot.height(), uiMouseX, uiMouseY) && this.listViewport != null) {
            return true;
        }
        if (this.searchField.isFocused()) {
            return false;
        }
        return this.uiContains((float)this.panelX, (float)this.panelY, (float)this.panelWidth, (float)this.panelHeight, uiMouseX, uiMouseY);
    }

    private List<Class<? extends class_2596<?>>> filterExcluded(List<Class<? extends class_2596<?>>> packets) {
        if (this.excludedPackets.isEmpty()) {
            return new ArrayList(packets);
        }
        return (List)packets.stream().filter(this::lambda$filterExcluded$3).collect(Collectors.toList());
    }

    public boolean hasTextFieldFocused() {
        return this.visible && this.surface.hasFocusedTextInput();
    }

    private float animate(float current, float target, float delta) {
        return PackUiHeaderControls.animate(current, target, delta);
    }

    private void renderHeaderControls(class_332 context, PackUiViewport viewport, float uiMouseX, float uiMouseY, float delta) {
        this.closeVisibility = this.animate(this.closeVisibility, 1f, delta);
        this.closeHover = this.animate(this.closeHover, this.isOverCloseButton(uiMouseX, uiMouseY) ? 1f : 0f, delta);
        viewport.push(context);
        try {
            int arrowX = this.collapseArrowX();
            int closeX = this.closeButtonX();
            int controlY = this.controlButtonY();
            this.drawCollapseArrow(context, arrowX, controlY);
            this.drawCloseButton(context, closeX, controlY, this.headerControlSize(), this.headerControlSize(), this.closeHover, this.closeVisibility);
        }
        finally {
            viewport.pop(context);
            throw var9;
        }
    }

    private void drawCollapseArrow(class_332 context, int x, int y) {
        PackUiHeaderControls.drawAnimatedArrow(context, x, y + 1, this.headerArrowWidth(), this.collapsed ? 0f : 1f, 1f);
    }

    private void drawCloseButton(class_332 context, int x, int y, int width, int height, float hover, float visibility) {
        PackUiHeaderControls.drawCloseButton(context, x, y, width, height, hover, true, visibility);
    }

    private boolean isOverHeaderUi(float uiMouseX, float uiMouseY) {
        return uiMouseX >= (float)this.panelX && uiMouseX < (float)(this.panelX + this.panelWidth) && uiMouseY >= (float)this.panelY && uiMouseY < (float)(this.panelY + this.theme.headerHeight());
    }

    private boolean isOverCloseButton(float uiMouseX, float uiMouseY) {
        return PackUiHeaderControls.isCloseHit(this.closeVisibility, (double)uiMouseX, (double)uiMouseY, this.closeButtonX(), this.controlButtonY(), this.headerControlSize());
    }

    private int controlButtonY() {
        return PackUiHeaderControls.controlY(this.panelY, this.theme.headerHeight(), this.headerControlSize());
    }

    private int closeButtonX() {
        return PackUiHeaderControls.closeX(this.panelX, this.panelWidth, this.headerControlSize(), 2);
    }

    private int collapseArrowX() {
        return PackUiHeaderControls.expandedArrowX(this.closeButtonX(), this.headerArrowGap(), this.headerArrowWidth());
    }

    private PackUtilWindowLayout clampToViewport(PackUtilWindowLayout bounds) {
        PackUiViewport viewport = this.surface.viewport();
        int width = Math.max(this.panelMinimumWidth(), Math.min(bounds.width, Math.round(viewport.uiWidth())));
        int minHeight = bounds.collapsed ? this.theme.headerHeight() : this.theme.headerHeight() + 20;
        int height = Math.max(minHeight, Math.min(bounds.height, Math.round(viewport.uiHeight())));
        int x = Math.max(0, Math.min(bounds.x, Math.max(0, Math.round(viewport.uiWidth()) - width)));
        int y = Math.max(0, Math.min(bounds.y, Math.max(0, Math.round(viewport.uiHeight()) - this.theme.headerHeight())));
        return new PackUtilWindowLayout(x, y, width, height, bounds.visible, bounds.collapsed);
    }

    private boolean uiContains(float x, float y, float width, float height, float mouseX, float mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    private int panelMinimumWidth() {
        return 230;
    }

    private int rowHeight() {
        return 16;
    }

    private int maxVisibleRows() {
        return 12;
    }

    private int panelPadding() {
        return 6;
    }

    private int windowContentGap() {
        return 4;
    }

    private int searchFieldHeight() {
        return 16;
    }

    private int markerReserveWidth() {
        return 10;
    }

    private int headerControlSize() {
        return 12;
    }

    private int headerArrowWidth() {
        return 10;
    }

    private int headerArrowGap() {
        return 3;
    }
}
