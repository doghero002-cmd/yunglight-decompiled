/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilLocalCraftingRegistry;
import com.example.addon.util.PacketRegenerator;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_10297;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_10302;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_10938;
import net.minecraft.class_1661;
import net.minecraft.class_1662;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2840;
import net.minecraft.class_2960;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import net.minecraft.class_516;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9884;

public final class PackUtilCraftingHelper {
    private static Field recipeBookRecipesField;
    public static final long CRAFT_REFRESH_DEBOUNCE_MS = 350L;

    private PackUtilCraftingHelper() {
    }

    public static List<PackUtilCraftingHelper.CraftableRecipeOption> getCraftableRecipes(class_310 mc) {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
            return List.of();
        }
        List<PackUtilCraftingHelper.RecipeListingContext> contexts = mc.field_1724.field_7512;
        class_9884 handler = (class_9884)contexts;
        class_9884 activeCrafting = contexts instanceof class_9884 ? handler : null;
        class_2338 nearbyTablePos = PackUtilCraftingHelper.findReachableCraftingTable(mc);
        contexts = new ArrayList();
        if (activeCrafting != null) {
            contexts.add(PackUtilCraftingHelper.createActiveListingContext(mc, activeCrafting));
            if (PackUtilCraftingHelper.isPlayerCraftingHandler(mc, activeCrafting)) {
                contexts.add(PackUtilCraftingHelper.createVirtualTableContext());
            }
        } else {
            contexts.add(PackUtilCraftingHelper.createVirtualTableContext());
        }
        if (contexts.isEmpty()) {
            return List.of();
        }
        Map<String, PackUtilCraftingHelper.CraftableRecipeOption> optionsByKey = new HashMap();
        List<PackUtilCraftingHelper.CraftableRecipeOption> options = contexts.iterator();
        while (options.hasNext()) {
            RecipeListingContext context = (PackUtilCraftingHelper.RecipeListingContext)options.next();
            var var7 = PackUtilLocalCraftingRegistry.getRecipes(mc).iterator();
            while (var7.hasNext()) {
                LocalCraftingRecipe localRecipe = (PackUtilLocalCraftingRegistry.LocalCraftingRecipe)var7.next();
                while (!localRecipe.fits(context.gridWidth, context.gridHeight)) {
                }
                while (localRecipe.result.method_7960()) {
                }
                int maxCraftsByMaterials = PackUtilCraftingHelper.computeMaxCraftsByMaterials(localRecipe, context.gridWidth, context.gridHeight, context.inputStacks, mc.field_1724.method_31548());
                int maxCraftsByStorage = PackUtilCraftingHelper.computeMaxCraftsByStorage(localRecipe, context.inputStacks, mc.field_1724.method_31548(), maxCraftsByMaterials);
                class_10297 syncedEntry = (class_10297)context.syncedBySignature.get(localRecipe.signature);
                CraftableRecipeOption option = new PackUtilCraftingHelper.CraftableRecipeOption(localRecipe, syncedEntry, maxCraftsByMaterials, maxCraftsByStorage, context.source);
                PackUtilCraftingHelper.mergeRecipeOption(optionsByKey, option);
            }
        }
        options = new ArrayList(optionsByKey.values());
        options.sort(Comparator.comparing(PackUtilCraftingHelper::lambda$getCraftableRecipes$0).thenComparing(PackUtilCraftingHelper::lambda$getCraftableRecipes$1).thenComparing(PackUtilCraftingHelper::lambda$getCraftableRecipes$2).thenComparing(PackUtilCraftingHelper::lambda$getCraftableRecipes$3, String.CASE_INSENSITIVE_ORDER).thenComparing(PackUtilCraftingHelper::lambda$getCraftableRecipes$4, String.CASE_INSENSITIVE_ORDER));
        return options;
    }

    private static PackUtilCraftingHelper.RecipeListingContext createActiveListingContext(class_310 mc, class_9884 craftingHandler) {
        class_10352 params = class_10363.method_65008(mc.field_1687);
        List<class_10297> syncedEntries = PackUtilCraftingHelper.getSyncedCraftingEntries(mc, craftingHandler);
        Map<String, class_10297> syncedBySignature = PackUtilCraftingHelper.buildSyncedSignatureMap(syncedEntries, params, craftingHandler);
        return new PackUtilCraftingHelper.RecipeListingContext(PackUtilCraftingHelper.isPlayerCraftingHandler(mc, craftingHandler) ? PackUtilCraftingHelper.CraftSource.PLAYER_2X2 : PackUtilCraftingHelper.CraftSource.TABLE_3X3, craftingHandler.method_61629(), craftingHandler.method_61630(), PackUtilCraftingHelper.getInputStacks(craftingHandler), syncedBySignature);
    }

    private static PackUtilCraftingHelper.RecipeListingContext createVirtualTableContext() {
        return new PackUtilCraftingHelper.RecipeListingContext(PackUtilCraftingHelper.CraftSource.TABLE_3X3, 3, 3, List.of(), Map.of());
    }

    private static boolean isPlayerCraftingHandler(class_310 mc, class_9884 craftingHandler) {
        return mc != null && mc.field_1724 != null && craftingHandler == mc.field_1724.field_7498;
    }

    private static List<class_1799> getInputStacks(class_9884 craftingHandler) {
        List<class_1799> inputStacks = new ArrayList();
        var var2 = craftingHandler.method_61628().iterator();
        while (var2.hasNext()) {
            class_1735 slot = (class_1735)var2.next();
            if (slot == null) continue;
            while (slot.method_7677().method_7960()) {
            }
            inputStacks.add(slot.method_7677().method_7972());
        }
        return inputStacks;
    }

    private static void mergeRecipeOption(Map<String, PackUtilCraftingHelper.CraftableRecipeOption> optionsByKey, PackUtilCraftingHelper.CraftableRecipeOption candidate) {
        String mergeKey = candidate.registryId.isEmpty() ? candidate.recipeKey : candidate.registryId;
        CraftableRecipeOption existing = (PackUtilCraftingHelper.CraftableRecipeOption)optionsByKey.get(mergeKey);
        if (existing == null) {
            optionsByKey.put(mergeKey, candidate);
            return;
        }
        boolean preferCandidate = false;
        if (candidate.result.method_7947() != existing.result.method_7947()) {
            preferCandidate = candidate.result.method_7947() > existing.result.method_7947();
        } else {
            if (candidate.craftableNow != existing.craftableNow) {
                preferCandidate = candidate.craftableNow;
            } else {
                if (candidate.craftSource != existing.craftSource) {
                    preferCandidate = candidate.craftSource == PackUtilCraftingHelper.CraftSource.PLAYER_2X2;
                } else {
                    if (candidate.maxCraftsNow != existing.maxCraftsNow) {
                        preferCandidate = candidate.maxCraftsNow > existing.maxCraftsNow;
                    } else {
                        if (!existing.hasSyncedRecipe()) {
                            if (candidate.hasSyncedRecipe()) {
                                preferCandidate = true;
                            }
                        }
                    }
                }
            }
        }
        if (preferCandidate) {
            optionsByKey.put(mergeKey, candidate);
        }
    }

    public static PackUtilCraftingHelper.CraftableRecipeOption findCraftableRecipe(class_310 mc, int recipeId) {
        var var2 = PackUtilCraftingHelper.getCraftableRecipes(mc).iterator();
        while (var2.hasNext()) {
            CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)var2.next();
            if (!option.recipeId == recipeId || option.syncedRecipeId == recipeId) continue;
            return option;
        }
        return null;
    }

    public static PackUtilCraftingHelper.CraftableRecipeOption findCraftableRecipe(class_310 mc, String recipeKey) {
        if (recipeKey == null || recipeKey.isBlank()) {
            return null;
        }
        var var2 = PackUtilCraftingHelper.getCraftableRecipes(mc).iterator();
        while (var2.hasNext()) {
            CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)var2.next();
            if (!recipeKey.equalsIgnoreCase(option.recipeKey)) continue;
            return option;
        }
        return null;
    }

    public static PackUtilCraftingHelper.CraftableRecipeOption findRecipeMatchingOutput(class_310 mc, class_1799 output) {
        if (output == null || output.method_7960()) {
            return null;
        }
        CraftableRecipeOption best = null;
        var var3 = PackUtilCraftingHelper.getCraftableRecipes(mc).iterator();
        while (var3.hasNext()) {
            CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)var3.next();
            while (!PackUtilCraftingHelper.sameResult(option.result, output)) {
            }
            while (best == null) {
                best = option;
            }
            while (option.craftableNow) {
                if (best.craftableNow) break;
                best = option;
            }
            if (option.craftableNow == best.craftableNow) {
                if (!option.maxCraftsNow > best.maxCraftsNow) continue;
                best = option;
            }
        }
        return best;
    }

    public static class_1799 getCurrentCraftOutput(class_310 mc) {
        if (mc == null || mc.field_1724 == null) {
            return class_1799.field_8037;
        }
        var var2 = mc.field_1724.field_7512;
        if (var2 instanceof class_9884) {
            class_9884 craftingHandler = (class_9884)var2;
        } else {
            return class_1799.field_8037;
        }
        return craftingHandler.method_61627().method_7677().method_7972();
    }

    public static int getRequiredCraftClicks(int outputPerCraft, int desiredAmount) {
        int safeOutput = Math.max(1, outputPerCraft);
        int safeDesired = Math.max(1, desiredAmount);
        return Math.max(1, (int)Math.ceil((double)safeDesired / (double)safeOutput));
    }

    public static int getRoundedCraftOutput(int outputPerCraft, int desiredAmount) {
        int safeOutput = Math.max(1, outputPerCraft);
        return PackUtilCraftingHelper.getRequiredCraftClicks(safeOutput, desiredAmount) * safeOutput;
    }

    public static int getRoundedCraftOutput(PackUtilCraftingHelper.CraftableRecipeOption option, int desiredAmount) {
        if (option == null) {
            return PackUtilCraftingHelper.getRoundedCraftOutput(1, desiredAmount);
        }
        int desiredCrafts = Math.min(option.maxCraftsNow, PackUtilCraftingHelper.getRequiredCraftClicks(option.result.method_7947(), desiredAmount));
        return Math.max(0, desiredCrafts * Math.max(1, option.result.method_7947()));
    }

    public static int getEffectiveRequestedOutput(PackUtilCraftingHelper.CraftableRecipeOption option, int desiredAmount, boolean useMaxAmount) {
        if (option != null) { /* goto L18; */ }
        return useMaxAmount ? 0 : Math.max(1, desiredAmount);
        if (useMaxAmount) {
            return option.maxOutputNow;
        }
        return Math.max(1, desiredAmount);
    }

    public static String getAvailabilityLabel(PackUtilCraftingHelper.CraftableRecipeOption option) {
        if (option == null) {
            return "No recipe";
        }
        if (option.craftableNow) {
            return "Crafts x" + option.maxCraftsNow;
        }
        if (option.hasMaterialsNow && !option.hasInventoryRoomNow) {
            return "No Room";
        }
        return "Need Mats";
    }

    public static List<class_2596<?>> buildCraftSequence(class_310 mc, int recipeId, int desiredAmount) {
        return PackUtilCraftingHelper.buildCraftSequence(mc, null, recipeId, desiredAmount);
    }

    public static List<class_2596<?>> buildCraftSequence(class_310 mc, String recipeKey, int recipeId, int desiredAmount) {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
            return List.of();
        }
        CraftableRecipeOption option = mc.field_1724.field_7512;
        if (option instanceof class_9884) {
            class_9884 craftingHandler = (class_9884)option;
        } else {
            return List.of();
        }
        option = PackUtilCraftingHelper.resolveCraftOption(mc, recipeKey, recipeId);
        if (option == null || option.maxCraftsNow <= 0 || !option.hasSyncedRecipe()) {
            return List.of();
        }
        int remainingCrafts = Math.min(option.maxCraftsNow, PackUtilCraftingHelper.getRequiredCraftClicks(option.result.method_7947(), desiredAmount));
        if (remainingCrafts <= 0) {
            return List.of();
        }
        CraftPhasePlan phasePlan = PackUtilCraftingHelper.createSyncedCraftPhasePlan(mc, option, craftingHandler);
        if (phasePlan.maxCraftsPerPhase <= 0) {
            return List.of();
        }
        List<class_2596<?>> packets = new ArrayList();
        int availableCraftsLeft = phasePlan.totalCraftsAvailable;
        while (remainingCrafts > 0) {
            int phaseCrafts = Math.min(remainingCrafts, phasePlan.maxCraftsPerPhase);
            boolean useCraftAll = PackUtilCraftingHelper.shouldUseCraftAll(phaseCrafts, availableCraftsLeft, phasePlan.maxCraftsPerPhase);
            int fillRequests = useCraftAll ? 1 : phaseCrafts;
            for (int i = 0; i < fillRequests; i++) {
                packets.add(new class_2840(craftingHandler.field_7763, option.syncedEntry.comp_3262(), useCraftAll));
            }
            click = new class_2813(craftingHandler.field_7763, craftingHandler.method_37421(), (short)craftingHandler.method_61627().field_7874, 0, class_1713.field_7794, new Int2ObjectArrayMap(), class_10938.field_58176);
            packets.add(PacketRegenerator.regenerate(click));
            remainingCrafts = remainingCrafts - phaseCrafts;
            availableCraftsLeft = Math.max(0, availableCraftsLeft - phaseCrafts);
        }
        return packets;
    }

    public static PackUtilCraftingHelper.CraftExecutionResult executeCraftImmediately(class_310 mc, int recipeId, int desiredAmount) {
        return PackUtilCraftingHelper.executeCraftImmediately(mc, null, recipeId, desiredAmount);
    }

    public static PackUtilCraftingHelper.CraftExecutionResult executeCraftImmediately(class_310 mc, String recipeKey, int recipeId, int desiredAmount) {
        if (mc == null || mc.field_1724 == null || mc.method_1562() == null) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("No network connection.");
        }
        CraftableRecipeOption requestedOption = PackUtilCraftingHelper.resolveCraftOption(mc, recipeKey, recipeId);
        if (requestedOption == null) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("That recipe is not available right now.");
        }
        if (!requestedOption.craftableNow || requestedOption.maxCraftsNow <= 0) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("Missing materials for " + requestedOption.label + ".");
        }
        PreparedCraftContext preparedContext = PackUtilCraftingHelper.prepareCraftExecution(mc, requestedOption);
        if (preparedContext == null) { /* goto L96; */ }
        if (preparedContext.handler != null) { /* goto @123; */ }
        L96: ;
        return requestedOption.craftSource == PackUtilCraftingHelper.CraftSource.TABLE_3X3 ? PackUtilCraftingHelper.CraftExecutionResult.failure("No reachable crafting table is available.") : PackUtilCraftingHelper.CraftExecutionResult.failure("Open your inventory or a crafting screen first.");
        try {
            CraftableRecipeOption option = PackUtilCraftingHelper.resolveCraftOption(mc, recipeKey, recipeId);
            if (option == null) {
                option = requestedOption;
            }
            if (!option.craftableNow || option.maxCraftsNow <= 0) {
                CraftExecutionResult fastResult = PackUtilCraftingHelper.CraftExecutionResult.failure("Missing materials for " + option.label + ".");
                PackUtilCraftingHelper.finishPreparedCraftContext(mc, preparedContext);
                return fastResult;
            }
        }
        finally {
            PackUtilCraftingHelper.finishPreparedCraftContext(mc, preparedContext);
            throw var9;
        }
    }

    private static PackUtilCraftingHelper.CraftableRecipeOption resolveCraftOption(class_310 mc, String recipeKey, int recipeId) {
        CraftableRecipeOption byKey = recipeKey == null || recipeKey.isBlank() ? null : PackUtilCraftingHelper.findCraftableRecipe(mc, recipeKey);
        if (byKey != null) {
            return byKey;
        }
        return PackUtilCraftingHelper.findCraftableRecipe(mc, recipeId);
    }

    private static PackUtilCraftingHelper.PreparedCraftContext prepareCraftExecution(class_310 mc, PackUtilCraftingHelper.CraftableRecipeOption option) {
        if (mc == null || mc.field_1724 == null || option == null) {
            return null;
        }
        class_437 restoreScreen = mc.field_1724.field_7512;
        if (restoreScreen instanceof class_9884) {
            class_9884 activeHandler = (class_9884)restoreScreen;
            if (option.localRecipe.fits(activeHandler.method_61629(), activeHandler.method_61630())) {
                return new PackUtilCraftingHelper.PreparedCraftContext(activeHandler, false, null);
            }
        }
        if (option.craftSource == PackUtilCraftingHelper.CraftSource.PLAYER_2X2 && mc.field_1724.field_7512 == mc.field_1724.field_7498) {
            return new PackUtilCraftingHelper.PreparedCraftContext(mc.field_1724.field_7498, false, null);
        }
        tablePos = PackUtilCraftingHelper.findReachableCraftingTable(mc);
        if (tablePos == null) {
            return null;
        }
        restoreScreen = mc.field_1724.field_7512 == mc.field_1724.field_7498 ? mc.field_1755 : null;
        if (!PackUtilCraftingHelper.openCraftingTable(mc, tablePos)) {
            return null;
        }
        class_9884 openedHandler = PackUtilCraftingHelper.waitForCraftingHandler(mc, 3, 3, 1500L);
        if (openedHandler == null) {
            return null;
        }
        return new PackUtilCraftingHelper.PreparedCraftContext(openedHandler, true, restoreScreen);
    }

    private static void finishPreparedCraftContext(class_310 mc, PackUtilCraftingHelper.PreparedCraftContext context) {
        if (mc == null || mc.field_1724 == null || context == null || !context.closeAfter) {
            return;
        }
        PackUtilCraftingHelper.runClientTask(mc, PackUtilCraftingHelper::lambda$finishPreparedCraftContext$5 /* captured: mc, context */);
    }

    private static boolean openCraftingTable(class_310 mc, class_2338 tablePos) {
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null || tablePos == null) {
            return false;
        }
        class_3965 hitResult = PackUtilCraftingHelper.createCraftingTableHitResult(mc, tablePos);
        if (hitResult == null) {
            return false;
        }
        return PackUtilCraftingHelper.runClientTask(mc, PackUtilCraftingHelper::lambda$openCraftingTable$6 /* captured: mc, hitResult */);
    }

    private static class_9884 waitForCraftingHandler(class_310 mc, int requiredWidth, int requiredHeight, long timeoutMs) {
        long deadline = System.nanoTime() + timeoutMs * 1000000L;
        L11: ;
        if (System.nanoTime() < deadline) {
            if (mc.field_1724 != null) {
                var var8 = mc.field_1724.field_7512;
                if (var8 instanceof class_9884) {
                    class_9884 craftingHandler = (class_9884)var8;
                    if (craftingHandler.method_61629() >= requiredWidth) {
                        if (craftingHandler.method_61630() >= requiredHeight) {
                            if (craftingHandler.method_37421() > 0) {
                                return craftingHandler;
                            }
                        }
                    }
                }
            }
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
        return null;
    }

    private static class_2338 findReachableCraftingTable(class_310 mc) {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
            return null;
        }
        double reach = Math.max(4.5, mc.field_1724.method_55754());
        double reachSq = reach * reach;
        int radius = (int)Math.ceil(reach);
        class_2338 origin = mc.field_1724.method_24515();
        class_2338 bestPos = null;
        double bestDistanceSq = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        var var10 = class_2338.method_10097(origin.method_10069(-radius, -radius, -radius), origin.method_10069(radius, radius, radius)).iterator();
        while (var10.hasNext()) {
            class_2338 pos = (class_2338)var10.next();
            while (!mc.field_1687.method_8320(pos).method_27852(class_2246.field_9980)) {
            }
            class_243 center = pos.method_46558();
            double distanceSq = mc.field_1724.method_5707(center);
            if (distanceSq > reachSq) continue;
            while (distanceSq >= bestDistanceSq) {
            }
            class_3965 hitResult = PackUtilCraftingHelper.createCraftingTableHitResult(mc, pos);
            while (hitResult == null) {
            }
            bestPos = pos.method_10062();
            bestDistanceSq = distanceSq;
        }
        return bestPos;
    }

    private static class_3965 createCraftingTableHitResult(class_310 mc, class_2338 tablePos) {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || tablePos == null) {
            return null;
        }
        class_243 center = tablePos.method_46558();
        double reach = Math.max(4.5, mc.field_1724.method_55754());
        if (mc.field_1724.method_5707(center) > reach * reach) {
            return null;
        }
        class_3959 context = new class_3959(mc.field_1724.method_33571(), center, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, mc.field_1724);
        class_3965 result = mc.field_1687.method_17742(context);
        if (result.method_17783() == class_239.class_240.field_1332 && result.method_17777().equals(tablePos)) {
            return result;
        }
        return new class_3965(center, class_2350.field_11036, tablePos, false);
    }

    private static PackUtilCraftingHelper.CraftExecutionResult executeCraftViaSyncedRecipe(class_310 mc, class_9884 craftingHandler, PackUtilCraftingHelper.CraftableRecipeOption option, int desiredAmount) {
        if (mc.field_1761 == null) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("Crafting interaction manager is unavailable.");
        }
        int safeDesiredAmount = Math.max(1, desiredAmount);
        int outputPerCraft = Math.max(1, option.result.method_7947());
        int desiredCrafts = Math.min(option.maxCraftsNow, PackUtilCraftingHelper.getRequiredCraftClicks(outputPerCraft, safeDesiredAmount));
        int roundedTarget = Math.min(option.maxOutputNow, desiredCrafts * outputPerCraft);
        int syncId = craftingHandler.field_7763;
        int outputSlotId = craftingHandler.method_61627().field_7874;
        int beforeCount = PackUtilCraftingHelper.countInventoryItems(mc, option.result);
        AtomicInteger remainingCrafts = new AtomicInteger(desiredCrafts);
        AtomicInteger dispatchedCrafts = new AtomicInteger(0);
        if (!PackUtilCraftingHelper.runClientTask(mc, PackUtilCraftingHelper::lambda$executeCraftViaSyncedRecipe$7 /* captured: mc, syncId, remainingCrafts, option, outputSlotId, dispatchedCrafts */)) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("Crafting interaction manager is unavailable.");
        }
        int expectedCount = beforeCount + Math.min(roundedTarget, dispatchedCrafts.get() * outputPerCraft);
        PackUtilCraftingHelper.waitForInventoryCount(mc, option.result, expectedCount, 700L);
        int craftedAmount = Math.max(0, PackUtilCraftingHelper.countInventoryItems(mc, option.result) - beforeCount);
        if (craftedAmount <= 0) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("Craft failed or your inventory had no room.");
        }
        return PackUtilCraftingHelper.buildCraftResult(option, craftedAmount, roundedTarget);
    }

    private static PackUtilCraftingHelper.CraftExecutionResult executeCraftManually(class_310 mc, class_9884 craftingHandler, PackUtilCraftingHelper.CraftableRecipeOption option, int desiredAmount) {
        int outputPerCraft = Math.max(1, option.result.method_7947());
        int desiredCrafts = Math.min(option.maxCraftsNow, PackUtilCraftingHelper.getRequiredCraftClicks(outputPerCraft, desiredAmount));
        if (desiredCrafts <= 0) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("Missing materials for " + option.label + ".");
        }
        int beforeCount = PackUtilCraftingHelper.countInventoryItems(mc, option.result);
        int craftedCrafts = 0;
        int syncId = craftingHandler.field_7763;
        int outputSlotId = craftingHandler.method_61627().field_7874;
        int roundedTarget = Math.min(option.maxOutputNow, desiredCrafts * outputPerCraft);
        while (craftedCrafts < desiredCrafts) {
            CraftableRecipeOption currentOption = PackUtilCraftingHelper.resolveCraftOption(mc, option.recipeKey, option.recipeId);
            if (currentOption == null) break;
            if (currentOption.maxCraftsNow <= 0) {
            } else {
                int phaseLimit = PackUtilCraftingHelper.computeManualMaxCraftsPerPhase(currentOption.localRecipe, craftingHandler, mc.field_1724.method_31548());
                if (phaseLimit <= 0) {
                } else {
                    int phaseCrafts = Math.min(desiredCrafts - craftedCrafts, Math.min(currentOption.maxCraftsNow, phaseLimit));
                    if (!PackUtilCraftingHelper.clearCraftGrid(mc, craftingHandler, syncId)) {
                    } else {
                        if (!PackUtilCraftingHelper.placeRecipeCrafts(mc, craftingHandler, currentOption.localRecipe, syncId, phaseCrafts)) {
                        } else {
                            if (!PackUtilCraftingHelper.waitForOutput(mc, syncId, currentOption.result, 400L)) {
                            } else {
                                if (!PackUtilCraftingHelper.runClientTask(mc, PackUtilCraftingHelper::lambda$executeCraftManually$8 /* captured: mc, syncId, outputSlotId */)) {
                                } else {
                                    craftedCrafts = craftedCrafts + phaseCrafts;
                                    PackUtilCraftingHelper.waitForInventoryCount(mc, option.result, beforeCount + craftedCrafts * outputPerCraft, 500L);
                                }
                            }
                        }
                    }
                }
            }
        }
        craftedAmount = Math.max(0, PackUtilCraftingHelper.countInventoryItems(mc, option.result) - beforeCount);
        if (craftedAmount <= 0) {
            return PackUtilCraftingHelper.CraftExecutionResult.failure("Craft failed or your inventory had no room.");
        }
        return PackUtilCraftingHelper.buildCraftResult(option, craftedAmount, roundedTarget);
    }

    private static boolean clearCraftGrid(class_310 mc, class_9884 craftingHandler, int syncId) {
        var var3 = craftingHandler.method_61628().iterator();
        while (var3.hasNext()) {
            class_1735 inputSlot = (class_1735)var3.next();
            if (inputSlot == null) continue;
            while (inputSlot.method_7677().method_7960()) {
            }
            if (PackUtilCraftingHelper.runClientTask(mc, PackUtilCraftingHelper::lambda$clearCraftGrid$9 /* captured: mc, syncId, inputSlot */)) continue;
            return false;
        }
        return PackUtilCraftingHelper.waitForInputGridClear(mc, syncId, 300L);
    }

    private static boolean placeRecipeOnce(class_310 mc, class_9884 craftingHandler, PackUtilLocalCraftingRegistry.LocalCraftingRecipe recipe, int syncId) {
        return PackUtilCraftingHelper.placeRecipeCrafts(mc, craftingHandler, recipe, syncId, 1);
    }

    private static boolean placeRecipeCrafts(class_310 mc, class_9884 craftingHandler, PackUtilLocalCraftingRegistry.LocalCraftingRecipe recipe, int syncId, int craftCount) {
        if (mc.field_1724 == null) {
            return false;
        }
        int requiredPerSlot = Math.max(1, craftCount);
        List<class_1735> inputSlots = craftingHandler.method_61628();
        if (!recipe.shaped) { /* goto L195; */ }
        for (int row = 0; row < recipe.height; row++) {
            for (int col = 0; col < recipe.width; col++) {
                int recipeIndex = row * recipe.width + col;
                if (recipeIndex < 0) { /* goto L181; */ }
                if (recipeIndex >= recipe.gridIngredients.size()) {
                } else {
                    class_1856 ingredient = (class_1856)recipe.gridIngredients.get(recipeIndex);
                    if (ingredient == null) { /* goto @181; */ }
                    if (ingredient.method_65799()) {
                    } else {
                        int gridIndex = row * craftingHandler.method_61629() + col;
                        if (!gridIndex < 0 || gridIndex >= inputSlots.size()) continue;
                        return false;
                        if (PackUtilCraftingHelper.placeIngredientCountIntoSlot(mc, craftingHandler, syncId, ((class_1735)inputSlots.get(gridIndex)).field_7874, ingredient, requiredPerSlot)) continue;
                        return false;
                    }
                }
            }
        }
        return true;
        L195: ;
        for (i = 0; i < recipe.requirements.size(); i++) {
            if (!i < 0 || i >= inputSlots.size()) continue;
            return false;
            ingredient = (class_1856)recipe.requirements.get(i);
            if (ingredient == null) { /* goto L293; */ }
            if (ingredient.method_65799()) {
            } else {
                if (!PackUtilCraftingHelper.placeIngredientCountIntoSlot(mc, craftingHandler, syncId, ((class_1735)inputSlots.get(i)).field_7874, ingredient, requiredPerSlot)) {
                    return false;
                }
            }
        }
        return true;
    }

    private static boolean placeIngredientIntoSlot(class_310 mc, class_9884 craftingHandler, int syncId, int targetSlotId, class_1856 ingredient) {
        return PackUtilCraftingHelper.placeIngredientCountIntoSlot(mc, craftingHandler, syncId, targetSlotId, ingredient, 1);
    }

    private static boolean placeIngredientCountIntoSlot(class_310 mc, class_9884 craftingHandler, int syncId, int targetSlotId, class_1856 ingredient, int requiredCount) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        int remaining = Math.max(1, requiredCount);
        while (remaining > 0) {
            Integer sourceSlotId = PackUtilCraftingHelper.findBestMatchingInventorySlot(craftingHandler, mc.field_1724.method_31548(), ingredient, remaining);
            if (sourceSlotId != null) continue;
            return false;
            class_1735 sourceSlot = craftingHandler.method_7611(sourceSlotId.intValue());
            if (!sourceSlot == null || sourceSlot.method_7677().method_7960()) continue;
            return false;
            int sourceCount = sourceSlot.method_7677().method_7947();
            int placeCount = Math.min(sourceCount, remaining);
            if (PackUtilCraftingHelper.runClientTask(mc, PackUtilCraftingHelper::lambda$placeIngredientCountIntoSlot$10 /* captured: mc, syncId, sourceSlotId, placeCount, sourceCount, targetSlotId */)) continue;
            return false;
            remaining = remaining - placeCount;
        }
        return PackUtilCraftingHelper.waitForTargetIngredientCount(mc, syncId, targetSlotId, ingredient, requiredCount, 300L);
    }

    private static void clickSlot(class_310 mc, int syncId, int slotId, int button, class_1713 actionType) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        mc.field_1761.method_2906(syncId, slotId, button, actionType, mc.field_1724);
    }

    private static Integer findMatchingInventorySlot(class_9884 craftingHandler, class_1661 inventory, class_1856 ingredient) {
        Integer exactOne = null;
        Integer fallback = null;
        int fallbackCount = 2147483647;
        var var6 = craftingHandler.field_7761.iterator();
        while (var6.hasNext()) {
            class_1735 slot = (class_1735)var6.next();
            if (slot == null) continue;
            if (slot.field_7871 != inventory) continue;
            while (slot.method_7677().method_7960()) {
            }
            class_1799 stack = slot.method_7677();
            while (!ingredient.method_8093(stack)) {
            }
            if (stack.method_7947() == 1) {
                exactOne = slot.field_7874;
            } else {
                if (stack.method_7947() < fallbackCount) {
                    fallback = slot.field_7874;
                    fallbackCount = stack.method_7947();
                }
            }
        }
        return exactOne != null ? exactOne : fallback;
    }

    private static Integer findBestMatchingInventorySlot(class_9884 craftingHandler, class_1661 inventory, class_1856 ingredient, int desiredCount) {
        Integer exact = null;
        Integer bestWhole = null;
        int bestWholeCount = -1;
        Integer bestPartial = null;
        int bestPartialCount = 2147483647;
        var var9 = craftingHandler.field_7761.iterator();
        while (var9.hasNext()) {
            class_1735 slot = (class_1735)var9.next();
            if (slot == null) continue;
            if (slot.field_7871 != inventory) continue;
            while (slot.method_7677().method_7960()) {
            }
            class_1799 stack = slot.method_7677();
            while (!ingredient.method_8093(stack)) {
            }
            int count = stack.method_7947();
            if (count == desiredCount) {
                exact = slot.field_7874;
            } else {
                if (count < desiredCount) {
                    if (count > bestWholeCount) {
                        bestWhole = slot.field_7874;
                        bestWholeCount = count;
                    }
                } else {
                    if (count > desiredCount) {
                        if (count < bestPartialCount) {
                            bestPartial = slot.field_7874;
                            bestPartialCount = count;
                        }
                    }
                }
            }
        }
        if (exact != null) {
            return exact;
        }
        if (bestWhole != null) {
            return bestWhole;
        }
        return bestPartial != null ? bestPartial : PackUtilCraftingHelper.findMatchingInventorySlot(craftingHandler, inventory, ingredient);
    }

    private static boolean waitForInputGridClear(class_310 mc, int syncId, long timeoutMs) {
        long deadline = System.nanoTime() + timeoutMs * 1000000L;
        L11: ;
        if (System.nanoTime() >= deadline) { /* goto @150; */ }
        if (mc.field_1724 == null) { /* goto @131; */ }
        boolean anyInput = mc.field_1724.field_7512;
        if (!anyInput instanceof class_9884) { /* goto @131; */ }
        class_9884 craftingHandler = (class_9884)anyInput;
        if (craftingHandler.field_7763 != syncId) {
            return false;
        }
        anyInput = false;
        var var8 = craftingHandler.method_61628().iterator();
        while (var8.hasNext()) {
            class_1735 inputSlot = (class_1735)var8.next();
            if (inputSlot == null) { /* goto @121; */ }
            if (inputSlot.method_7677().method_7960()) { /* goto @121; */ }
            anyInput = true;
            break;
        }
        if (!anyInput) {
            return true;
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return false;
    }

    private static boolean waitForTargetIngredient(class_310 mc, int syncId, int targetSlotId, class_1856 ingredient, long timeoutMs) {
        return PackUtilCraftingHelper.waitForTargetIngredientCount(mc, syncId, targetSlotId, ingredient, 1, timeoutMs);
    }

    private static boolean waitForTargetIngredientCount(class_310 mc, int syncId, int targetSlotId, class_1856 ingredient, int requiredCount, long timeoutMs) {
        long deadline = System.nanoTime() + timeoutMs * 1000000L;
        L12: ;
        if (System.nanoTime() < deadline) {
            if (mc.field_1724 != null) {
                class_1735 slot = mc.field_1724.field_7512;
                if (slot instanceof class_1703) {
                    class_1703 handler = slot;
                    if (handler.field_7763 != syncId) {
                        return false;
                    }
                    slot = handler.method_7611(targetSlotId);
                    if (slot != null) {
                        class_1799 stack = slot.method_7677();
                        if (stack != null) {
                            if (!stack.method_7960()) {
                                if (ingredient.method_8093(stack)) {
                                    if (stack.method_7947() >= requiredCount) {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return false;
    }

    private static boolean waitForOutput(class_310 mc, int syncId, class_1799 expectedResult, long timeoutMs) {
        long deadline = System.nanoTime() + timeoutMs * 1000000L;
        L11: ;
        if (System.nanoTime() < deadline) {
            if (mc.field_1724 != null) {
                class_1799 output = mc.field_1724.field_7512;
                if (output instanceof class_9884) {
                    class_9884 craftingHandler = (class_9884)output;
                    if (craftingHandler.field_7763 != syncId) {
                        return false;
                    }
                    output = craftingHandler.method_61627().method_7677();
                    if (!output.method_7960()) {
                        if (output.method_7909() == expectedResult.method_7909()) {
                            return true;
                        }
                    }
                }
            }
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return false;
    }

    private static Map<String, class_10297> buildSyncedSignatureMap(List<class_10297> entries, class_10352 params, class_9884 craftingHandler) {
        Map<String, class_10297> signatures = new HashMap();
        var var4 = entries.iterator();
        while (var4.hasNext()) {
            class_10297 entry = (class_10297)var4.next();
            String signature = PackUtilCraftingHelper.buildSyncedSignature(entry, params, craftingHandler);
            if (signature != null) {
                if (signatures.containsKey(signature)) continue;
                signatures.put(signature, entry);
            }
        }
        return signatures;
    }

    private static String buildSyncedSignature(class_10297 entry, class_10352 params, class_9884 craftingHandler) {
        if (entry == null || entry.comp_3263() == null) {
            return null;
        }
        class_1799 result = entry.comp_3263().comp_3258().method_64742(params);
        if (result == null || result.method_7960()) {
            return null;
        }
        class_2960 resultId = result.method_7909() == null ? null : class_7923.field_41178.method_10221(result.method_7909());
        if (resultId == null) {
            return null;
        }
        List<String> parts = new ArrayList();
        boolean shaped = entry.comp_3263() instanceof class_10300;
        int width = shaped ? ((class_10300)entry.comp_3263()).comp_3268() : Math.min(entry.method_64730(params).size(), craftingHandler.method_61629() * craftingHandler.method_61630());
        int height = shaped ? ((class_10300)entry.comp_3263()).comp_3269() : 1;
        if (entry.comp_3266().isPresent()) {
            if (((List)entry.comp_3266().get()).isEmpty()) { /* goto @329; */ }
            List<class_1856> ingredients = (List)entry.comp_3266().get();
            if (!shaped) {
                List<String> shapeless = new ArrayList();
                class_1856 ingredient = ingredients.iterator();
                while (ingredient.hasNext()) {
                    class_1856 ingredient = (class_1856)ingredient.next();
                    shapeless.add(PackUtilCraftingHelper.signatureForIngredient(ingredient));
                }
                shapeless.sort(String.CASE_INSENSITIVE_ORDER);
                parts.addAll(shapeless);
            } else {
                List<String> shapeless = ingredients.iterator();
                while (shapeless.hasNext()) {
                    class_1856 ingredient = (class_1856)shapeless.next();
                    parts.add(PackUtilCraftingHelper.signatureForIngredient(ingredient));
                }
            }
        } else {
            List<class_10302> displays = PackUtilCraftingHelper.getIngredientDisplays(entry);
            if (!shaped) {
                List<String> shapeless = new ArrayList();
                class_10302 slotDisplay = displays.iterator();
                while (slotDisplay.hasNext()) {
                    class_10302 slotDisplay = (class_10302)slotDisplay.next();
                    while (slotDisplay == null) {
                    }
                    shapeless.add(PackUtilCraftingHelper.signatureForStacks(slotDisplay.method_64738(params)));
                }
                shapeless.sort(String.CASE_INSENSITIVE_ORDER);
                parts.addAll(shapeless);
            } else {
                var shapeless = displays.iterator();
                while (shapeless.hasNext()) {
                    class_10302 slotDisplay = (class_10302)shapeless.next();
                    if (slotDisplay == null) { /* goto L478; */ }
                    if (PackUtilCraftingHelper.isEmptySlotDisplay(slotDisplay, params)) {
                        parts.add("_");
                    } else {
                        parts.add(PackUtilCraftingHelper.signatureForStacks(slotDisplay.method_64738(params)));
                    }
                }
            }
        }
        return String.valueOf(resultId) + "|" + result.method_7947() + "|" + shaped ? "shaped" : "shapeless" + "|" + width + "x" + height + "|" + String.join(";", parts);
    }

    private static String signatureForIngredient(class_1856 ingredient) {
        if (ingredient == null || ingredient.method_65799()) {
            return "_";
        }
        Objects.requireNonNull(class_7923.field_41178);
        List<String> ids = ingredient.method_8105().map(class_6880::comp_349).filter(Objects::nonNull).map(class_7923.field_41178::method_10221).filter(Objects::nonNull).map(class_2960::toString).sorted(String.CASE_INSENSITIVE_ORDER).toList();
        return ids.isEmpty() ? "_" : String.join(",", ids);
    }

    private static String signatureForStacks(List<class_1799> stacks) {
        if (stacks == null || stacks.isEmpty()) {
            return "_";
        }
        Set<String> ids = new HashSet();
        List<String> ordered = stacks.iterator();
        while (ordered.hasNext()) {
            class_1799 stack = (class_1799)ordered.next();
            if (stack == null) continue;
            if (stack.method_7960()) continue;
            while (stack.method_7909() == null) {
            }
            class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
            if (id == null) continue;
            ids.add(id.toString());
        }
        if (ids.isEmpty()) {
            return "_";
        }
        ordered = new ArrayList(ids);
        ordered.sort(String.CASE_INSENSITIVE_ORDER);
        return String.join(",", ordered);
    }

    private static int computeMaxCraftsByMaterials(PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe, class_9884 craftingHandler, class_1661 playerInventory) {
        return PackUtilCraftingHelper.computeMaxCraftsByMaterials(localRecipe, craftingHandler == null ? 0 : craftingHandler.method_61629(), craftingHandler == null ? 0 : craftingHandler.method_61630(), PackUtilCraftingHelper.getInputStacks(craftingHandler), playerInventory);
    }

    private static int computeMaxCraftsByMaterials(PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe, int gridWidth, int gridHeight, List<class_1799> inputStacks, class_1661 playerInventory) {
        if (localRecipe == null || localRecipe.requirements.isEmpty()) {
            return 0;
        }
        if (!localRecipe.fits(gridWidth, gridHeight)) {
            return 0;
        }
        class_1662<class_6880<class_1792>> matcher = new class_1662();
        PackUtilCraftingHelper.addInventoryToMatcher(matcher, playerInventory);
        PackUtilCraftingHelper.addInputStacksToMatcher(matcher, inputStacks);
        return matcher.method_65796(localRecipe.requirements);
    }

    private static int computeMaxCraftsByStorage(PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe, List<class_1799> inputStacks, class_1661 playerInventory, int maxCraftsByMaterials) {
        if (localRecipe == null || localRecipe.result.method_7960() || playerInventory == null) {
            return 0;
        }
        int craftLimit = Math.max(0, maxCraftsByMaterials);
        if (craftLimit <= 0) {
            return 0;
        }
        List<class_1799> inventorySlots = new ArrayList(36);
        int playerSlotCount = Math.min(36, playerInventory.method_5439());
        for (int i = 0; i < playerSlotCount; i++) {
            class_1799 stack = playerInventory.method_5438(i);
            inventorySlots.add(stack == null ? class_1799.field_8037 : stack.method_7972());
        }
        gridPools = new ArrayList();
        if (inputStacks == null) { /* goto L176; */ }
        crafted = inputStacks.iterator();
        while (crafted.hasNext()) {
            class_1799 stack = (class_1799)crafted.next();
            if (stack != null) {
                if (stack.method_7960()) continue;
                gridPools.add(stack.method_7972());
            }
        }
        crafted = 0;
        while (crafted < craftLimit) {
            if (!PackUtilCraftingHelper.consumeOneCraftFromPools(localRecipe, inventorySlots, gridPools)) {
            } else {
                if (!PackUtilCraftingHelper.storeCraftResult(localRecipe.result, inventorySlots)) {
                } else {
                    crafted++;
                }
            }
        }
        return crafted;
    }

    private static boolean consumeOneCraftFromPools(PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe, List<class_1799> inventorySlots, List<class_1799> gridPools) {
        if (localRecipe == null || localRecipe.requirements.isEmpty()) {
            return false;
        }
        var var3 = localRecipe.requirements.iterator();
        L28: ;
        if (!var3.hasNext()) { /* goto L92; */ }
        class_1856 ingredient = (class_1856)var3.next();
        if (ingredient == null) { /* goto L28; */ }
        while (ingredient.method_65799()) {
        }
        while (PackUtilCraftingHelper.consumeMatchingIngredient(inventorySlots, ingredient, true)) {
        }
        while (PackUtilCraftingHelper.consumeMatchingIngredient(gridPools, ingredient, false)) {
        }
        return false;
        L92: ;
        return true;
    }

    private static boolean consumeMatchingIngredient(List<class_1799> stacks, class_1856 ingredient, boolean preferSmallestStack) {
        if (stacks == null || stacks.isEmpty() || ingredient == null || ingredient.method_65799()) {
            return false;
        }
        int bestIndex = -1;
        int bestCount = 2147483647;
        int i = 0;
        while (i < stacks.size()) {
            class_1799 stack = (class_1799)stacks.get(i);
            if (stack != null) {
                if (stack.method_7960()) { /* goto @127; */ }
                if (!ingredient.method_8093(stack)) {
                } else {
                    int count = stack.method_7947();
                    if (bestIndex >= 0) {
                        if (!preferSmallestStack) { /* goto @127; */ }
                    }
                    bestIndex = i;
                    bestCount = count;
                    if (!preferSmallestStack) { /* goto @127; */ }
                }
            } else {
                i++;
            }
        }
        if (bestIndex < 0) {
            return false;
        }
        chosen = (class_1799)stacks.get(bestIndex);
        chosen.method_7934(1);
        if (chosen.method_7960()) {
            stacks.set(bestIndex, class_1799.field_8037);
        }
        return true;
    }

    private static boolean storeCraftResult(class_1799 resultStack, List<class_1799> inventorySlots) {
        if (resultStack == null || resultStack.method_7960() || inventorySlots == null) {
            return false;
        }
        int remaining = resultStack.method_7947();
        int maxStackSize = Math.max(1, resultStack.method_7914());
        for (int i = 0; i < inventorySlots.size(); i++) {
            if (remaining <= 0) break;
            class_1799 existing = (class_1799)inventorySlots.get(i);
            if (existing == null) { /* goto L147; */ }
            if (existing.method_7960()) {
            } else {
                if (existing.method_7909() != resultStack.method_7909()) {
                } else {
                    int existingMax = Math.max(1, Math.min(existing.method_7914(), maxStackSize));
                    if (existing.method_7947() >= existingMax) {
                    } else {
                        int add = Math.min(existingMax - existing.method_7947(), remaining);
                        existing.method_7933(add);
                        remaining = remaining - add;
                    }
                }
            }
        }
        for (i = 0; i < inventorySlots.size(); i++) {
            if (remaining <= 0) break;
            existing = (class_1799)inventorySlots.get(i);
            if (existing != null && !existing.method_7960()) {
            } else {
                add = Math.min(maxStackSize, remaining);
                placed = resultStack.method_7972();
                placed.method_7939(add);
                inventorySlots.set(i, placed);
                remaining = remaining - add;
            }
        }
        return remaining <= 0;
    }

    private static int computeManualMaxCraftsPerPhase(PackUtilLocalCraftingRegistry.LocalCraftingRecipe localRecipe, class_9884 craftingHandler, class_1661 playerInventory) {
        if (localRecipe == null || playerInventory == null) {
            return 0;
        }
        int maxCrafts = 2147483647;
        List<class_1856> ingredients = localRecipe.shaped ? localRecipe.gridIngredients : localRecipe.requirements;
        var var5 = ingredients.iterator();
        while (var5.hasNext()) {
            class_1856 ingredient = (class_1856)var5.next();
            if (ingredient == null) continue;
            while (ingredient.method_65799()) {
            }
            int slotLimit = PackUtilCraftingHelper.findMaxIngredientStackSize(craftingHandler, playerInventory, ingredient);
            if (!slotLimit <= 0) continue;
            return 0;
            maxCrafts = Math.min(maxCrafts, slotLimit);
        }
        return maxCrafts == 2147483647 ? 0 : Math.max(1, maxCrafts);
    }

    private static void addInventoryToMatcher(class_1662<class_6880<class_1792>> matcher, class_1661 playerInventory) {
        if (matcher == null || playerInventory == null) {
            return;
        }
        for (int i = 0; i < playerInventory.method_5439(); i++) {
            class_1799 stack = playerInventory.method_5438(i);
            if (stack == null) { /* goto L51; */ }
            if (stack.method_7960()) {
            } else {
                matcher.method_61501(stack.method_41409(), stack.method_7947());
            }
        }
    }

    private static int findMaxIngredientStackSize(class_9884 craftingHandler, class_1661 playerInventory, class_1856 ingredient) {
        int best = 0;
        var var4 = craftingHandler.field_7761.iterator();
        while (var4.hasNext()) {
            class_1735 slot = (class_1735)var4.next();
            if (slot == null) continue;
            if (slot.field_7871 != playerInventory) continue;
            while (slot.method_7677().method_7960()) {
            }
            class_1799 stack = slot.method_7677();
            while (!ingredient.method_8093(stack)) {
            }
            best = Math.max(best, Math.min(stack.method_7914(), slot.method_7676(stack)));
        }
        return best;
    }

    private static void addInputGridToMatcher(class_1662<class_6880<class_1792>> matcher, class_9884 craftingHandler) {
        if (matcher == null || craftingHandler == null) {
            return;
        }
        var var2 = craftingHandler.method_61628().iterator();
        while (var2.hasNext()) {
            class_1735 slot = (class_1735)var2.next();
            while (slot == null) {
            }
            class_1799 stack = slot.method_7677();
            if (stack == null) continue;
            while (stack.method_7960()) {
            }
            matcher.method_61501(stack.method_41409(), stack.method_7947());
        }
    }

    private static void addInputStacksToMatcher(class_1662<class_6880<class_1792>> matcher, List<class_1799> inputStacks) {
        if (matcher == null || inputStacks == null) {
            return;
        }
        var var2 = inputStacks.iterator();
        while (var2.hasNext()) {
            class_1799 stack = (class_1799)var2.next();
            if (stack == null) continue;
            while (stack.method_7960()) {
            }
            matcher.method_61501(stack.method_41409(), stack.method_7947());
        }
    }

    private static List<class_10297> getSyncedCraftingEntries(class_310 mc, class_9884 craftingHandler) {
        List<class_10297> entries = new ArrayList();
        var var3 = PackUtilCraftingHelper.getRawSyncedRecipeEntries(mc).iterator();
        while (var3.hasNext()) {
            class_10297 entry = (class_10297)var3.next();
            if (!PackUtilCraftingHelper.isSupportedCraftingEntry(entry, craftingHandler)) continue;
            entries.add(entry);
        }
        return entries;
    }

    private static Collection<class_10297> getRawSyncedRecipeEntries(class_310 mc) {
        if (mc == null || mc.field_1724 == null) {
            return List.of();
        }
        Object raw = mc.field_1724.method_3130();
        if (raw instanceof class_299) {
            class_299 recipeBook = raw;
        } else {
            return List.of();
        }
        try {
            if (recipeBookRecipesField == null) {
                recipeBookRecipesField = class_299.class.getDeclaredField("recipes");
                recipeBookRecipesField.setAccessible(true);
            }
            raw = recipeBookRecipesField.get(recipeBook);
            if (!raw instanceof Map) { /* goto @172; */ }
            Map<?, ?> recipeMap = (Map)raw;
            List<class_10297> entries = new ArrayList(recipeMap.size());
            var var5 = recipeMap.values().iterator();
            while (var5.hasNext()) {
                Object value = var5.next();
                if (value instanceof class_10297) {
                    class_10297 entry = (class_10297)value;
                    entries.add(entry);
                }
            }
            if (!entries.isEmpty()) {
                return entries;
            }
        }
        catch (Exception fallback) {
            recipeBook.method_64853();
            fallback = new ArrayList();
            recipeMap = recipeBook.method_1393().iterator();
            while (recipeMap.hasNext()) {
                collection = (class_516)recipeMap.next();
                fallback.addAll(collection.method_2650());
            }
        }
        return fallback;
    }

    private static boolean isSupportedCraftingEntry(class_10297 entry, class_9884 craftingHandler) {
        if (entry == null || entry.comp_3263() == null) {
            return false;
        }
        var var3 = entry.comp_3263();
        if (!var3 instanceof class_10300) { /* goto L58; */ }
        class_10300 shaped = (class_10300)var3;
        return shaped.comp_3268() <= craftingHandler.method_61629() && shaped.comp_3269() <= craftingHandler.method_61630();
        var3 = entry.comp_3263();
        if (!var3 instanceof class_10301) { /* goto L102; */ }
        shapeless = (class_10301)var3;
        return shapeless.comp_3271().size() <= craftingHandler.method_61629() * craftingHandler.method_61630();
        return false;
    }

    private static PackUtilCraftingHelper.CraftPhasePlan createSyncedCraftPhasePlan(class_310 mc, PackUtilCraftingHelper.CraftableRecipeOption option, class_9884 craftingHandler) {
        if (mc.field_1687 == null || option == null || option.maxCraftsNow <= 0 || option.syncedEntry == null) {
            return new PackUtilCraftingHelper.CraftPhasePlan(0, 0);
        }
        class_10352 params = class_10363.method_65008(mc.field_1687);
        int maxCraftsPerPhase = PackUtilCraftingHelper.computeMaxCraftsPerPhase(option.syncedEntry, craftingHandler, params, option.maxCraftsNow);
        return new PackUtilCraftingHelper.CraftPhasePlan(option.maxCraftsNow, maxCraftsPerPhase);
    }

    private static int computeMaxCraftsPerPhase(class_10297 entry, class_9884 craftingHandler, class_10352 params, int totalCraftsAvailable) {
        int safeTotal = Math.max(0, totalCraftsAvailable);
        if (safeTotal <= 0) {
            return 0;
        }
        int phaseCrafts = safeTotal;
        List<class_1856> ingredients = PackUtilCraftingHelper.getPlanningIngredients(entry, params);
        if (ingredients.isEmpty()) {
            return Math.min(phaseCrafts, 64);
        }
        var var7 = ingredients.iterator();
        while (var7.hasNext()) {
            class_1856 ingredient = (class_1856)var7.next();
            int bestMaxCount = 0;
            var var10 = craftingHandler.field_7761.iterator();
            while (var10.hasNext()) {
                class_1735 slot = (class_1735)var10.next();
                while (slot == null) {
                }
                class_1799 stack = slot.method_7677();
                if (stack != null) {
                    if (!stack.method_7960()) {
                        if (!ingredient.method_8093(stack)) continue;
                        bestMaxCount = Math.max(bestMaxCount, stack.method_7914());
                    }
                }
            }
            if (!bestMaxCount <= 0) continue;
            return 0;
            phaseCrafts = Math.min(phaseCrafts, bestMaxCount);
        }
        return Math.max(1, phaseCrafts);
    }

    private static List<class_1856> getPlanningIngredients(class_10297 entry, class_10352 params) {
        if (entry.comp_3266().isPresent() && !((List)entry.comp_3266().get()).isEmpty()) {
            return new ArrayList((Collection)entry.comp_3266().get());
        }
        List<class_1856> derived = new ArrayList();
        var var3 = PackUtilCraftingHelper.getIngredientDisplays(entry).iterator();
        while (var3.hasNext()) {
            class_10302 slotDisplay = (class_10302)var3.next();
            while (slotDisplay == null) {
            }
            List<class_1799> displayStacks = slotDisplay.method_64738(params);
            List<class_1792> items = new ArrayList();
            var var7 = displayStacks.iterator();
            while (var7.hasNext()) {
                class_1799 stack = (class_1799)var7.next();
                if (stack != null) {
                    if (!stack.method_7960()) {
                        if (stack.method_7909() == null) continue;
                        items.add(stack.method_7909());
                    }
                }
            }
            if (items.isEmpty()) continue;
            derived.add(class_1856.method_26964(items.stream()));
        }
        return derived;
    }

    private static List<PackUtilCraftingHelper.ExpectedGridSlot> buildExpectedGridSlots(class_10297 entry, class_9884 craftingHandler, class_10352 params, int craftCount) {
        List<PackUtilCraftingHelper.ExpectedGridSlot> expected = new ArrayList();
        List<class_1856> ingredients = PackUtilCraftingHelper.getPlanningIngredients(entry, params);
        if (ingredients.isEmpty()) {
            return expected;
        }
        List<class_1735> inputSlots = craftingHandler.method_61628();
        int ingredientIndex = 0;
        int row = entry.comp_3263();
        if (!row instanceof class_10300) { /* goto L255; */ }
        class_10300 shaped = (class_10300)row;
        for (row = 0; row < shaped.comp_3269(); row++) {
            for (int col = 0; col < shaped.comp_3268(); col++) {
                int shapedIndex = row * shaped.comp_3268() + col;
                if (shapedIndex < 0) { /* goto L240; */ }
                if (shapedIndex >= shaped.comp_3270().size()) {
                } else {
                    class_10302 slotDisplay = (class_10302)shaped.comp_3270().get(shapedIndex);
                    if (PackUtilCraftingHelper.isEmptySlotDisplay(slotDisplay, params)) {
                    } else {
                        int gridIndex = row * craftingHandler.method_61629() + col;
                        if (gridIndex < 0) { /* goto @240; */ }
                        if (gridIndex >= inputSlots.size()) { /* goto @240; */ }
                        if (ingredientIndex >= ingredients.size()) {
                        } else {
                            expected.add(new PackUtilCraftingHelper.ExpectedGridSlot(((class_1735)inputSlots.get(gridIndex)).field_7874, (class_1856)ingredients.get(ingredientIndex), craftCount));
                            ingredientIndex++;
                        }
                    }
                }
            }
        }
        return expected;
        L255: ;
        row = entry.comp_3263();
        if (!row instanceof class_10301) { /* goto L395; */ }
        shapeless = (class_10301)row;
        row = shapeless.comp_3271().iterator();
        while (row.hasNext()) {
            slotDisplay = (class_10302)row.next();
            if (PackUtilCraftingHelper.isEmptySlotDisplay(slotDisplay, params)) continue;
            if (ingredientIndex >= ingredients.size()) continue;
            while (ingredientIndex >= inputSlots.size()) {
            }
            expected.add(new PackUtilCraftingHelper.ExpectedGridSlot(((class_1735)inputSlots.get(ingredientIndex)).field_7874, (class_1856)ingredients.get(ingredientIndex), craftCount));
            ingredientIndex++;
        }
        return expected;
    }

    private static boolean isEmptySlotDisplay(class_10302 slotDisplay, class_10352 params) {
        return slotDisplay == null || slotDisplay.method_64738(params).stream().noneMatch(PackUtilCraftingHelper::lambda$isEmptySlotDisplay$11);
    }

    private static List<class_10302> getIngredientDisplays(class_10297 entry) {
        var var2 = entry.comp_3263();
        if (var2 instanceof class_10300) {
            class_10300 shaped = (class_10300)var2;
            return shaped.comp_3270();
        }
        var2 = entry.comp_3263();
        if (var2 instanceof class_10301) {
            shapeless = (class_10301)var2;
            return shapeless.comp_3271();
        }
        return List.of();
    }

    private static boolean shouldUseCraftAll(int phaseCrafts, int totalCraftsAvailable, int maxCraftsPerPhase) {
        if (phaseCrafts >= totalCraftsAvailable) { /* goto L14; */ }
        if (phaseCrafts < maxCraftsPerPhase) { /* goto @18; */ }
        L14: ;
        return phaseCrafts > 0;
    }

    private static boolean sameResult(class_1799 left, class_1799 right) {
        return left != null && right != null && !left.method_7960() && !right.method_7960() && left.method_7947() == right.method_7947() && class_1799.method_31577(left, right);
    }

    private static int countInventoryItems(class_310 mc, class_1799 template) {
        if (mc.field_1724 == null || template == null || template.method_7960()) {
            return 0;
        }
        int total = 0;
        for (int slot = 0; slot < mc.field_1724.method_31548().method_5439(); slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            if (!stack.method_7960()) {
                if (stack.method_7909() != template.method_7909()) continue;
                total = total + stack.method_7947();
            }
        }
        return total;
    }

    private static boolean waitForCraftGridState(class_310 mc, int syncId, List<PackUtilCraftingHelper.ExpectedGridSlot> expectedSlots, class_1799 expectedResult, long timeoutMs) {
        long deadline = System.nanoTime() + timeoutMs * 1000000L;
        L12: ;
        if (System.nanoTime() < deadline) {
            if (mc.field_1724 != null) {
                var var9 = mc.field_1724.field_7512;
                if (var9 instanceof class_9884) {
                    class_9884 craftingHandler = (class_9884)var9;
                    if (craftingHandler.field_7763 != syncId) {
                        return false;
                    }
                    if (PackUtilCraftingHelper.matchesExpectedCraftGrid(craftingHandler, expectedSlots, expectedResult)) {
                        return true;
                    }
                }
            }
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return false;
    }

    private static boolean matchesExpectedCraftGrid(class_9884 craftingHandler, List<PackUtilCraftingHelper.ExpectedGridSlot> expectedSlots, class_1799 expectedResult) {
        if (expectedResult == null || expectedResult.method_7960()) {
            return false;
        }
        class_1799 output = craftingHandler.method_61627().method_7677();
        if (output.method_7960() || output.method_7909() != expectedResult.method_7909()) {
            return false;
        }
        Set<Integer> expectedSlotIds = new HashSet();
        var var5 = expectedSlots.iterator();
        while (var5.hasNext()) {
            ExpectedGridSlot expectedSlot = (PackUtilCraftingHelper.ExpectedGridSlot)var5.next();
            expectedSlotIds.add(expectedSlot.slotId);
            class_1735 slot = craftingHandler.method_7611(expectedSlot.slotId);
            if (slot != null) continue;
            return false;
            class_1799 stack = slot.method_7677();
            if (!stack == null || stack.method_7960() || stack.method_7947() < expectedSlot.expectedCount) continue;
            return false;
            if (expectedSlot.ingredient != null) {
                if (expectedSlot.ingredient.method_8093(stack)) continue;
                return false;
            }
        }
        var5 = craftingHandler.method_61628().iterator();
        while (var5.hasNext()) {
            inputSlot = (class_1735)var5.next();
            if (inputSlot == null) continue;
            while (expectedSlotIds.contains(inputSlot.field_7874)) {
            }
            if (inputSlot.method_7677().method_7960()) continue;
            return false;
        }
        return true;
    }

    private static boolean waitForInventoryCount(class_310 mc, class_1799 expectedResult, int requiredCount, long timeoutMs) {
        long deadline = System.nanoTime() + timeoutMs * 1000000L;
        L11: ;
        if (System.nanoTime() < deadline) {
            if (PackUtilCraftingHelper.countInventoryItems(mc, expectedResult) >= requiredCount) {
                return true;
            }
        }
        try {
            Thread.sleep(5L);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return false;
    }

    private static PackUtilCraftingHelper.CraftExecutionResult buildCraftResult(PackUtilCraftingHelper.CraftableRecipeOption option, int craftedAmount, int roundedTarget) {
        if (craftedAmount < roundedTarget) {
            return PackUtilCraftingHelper.CraftExecutionResult.success("Crafted " + craftedAmount + "/" + roundedTarget + " " + option.label + ".", craftedAmount);
        }
        return PackUtilCraftingHelper.CraftExecutionResult.success("Crafted " + craftedAmount + " " + option.label + ".", craftedAmount);
    }

    private static boolean runClientTask(class_310 mc, Runnable task) {
        if (mc.method_18854()) {
            task.run();
            return true;
        }
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean ran = new AtomicBoolean(false);
        AtomicReference<RuntimeException> runtimeError = new AtomicReference();
        mc.execute(PackUtilCraftingHelper::lambda$runClientTask$12 /* captured: task, ran, runtimeError, latch */);
        try {
            if (!latch.await(2L, TimeUnit.SECONDS)) {
                return false;
            }
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        if (runtimeError.get() != null) {
            throw (RuntimeException)runtimeError.get();
        }
        return ran.get();
    }

    public static List<PackUtilCraftingHelper.CraftableRecipeOption> filterRecipes(List<PackUtilCraftingHelper.CraftableRecipeOption> all, String query) {
        if (query == null || query.isBlank()) {
            return new ArrayList(all);
        }
        String lower = query.toLowerCase();
        return all.stream().filter(PackUtilCraftingHelper::lambda$filterRecipes$13 /* captured: lower */).toList();
    }

    public static PackUtilCraftingHelper.CraftableRecipeOption findInList(List<PackUtilCraftingHelper.CraftableRecipeOption> recipes, String recipeKey, int recipeId) {
        if (recipes == null) {
            return null;
        }
        var var3 = recipes.iterator();
        while (var3.hasNext()) {
            CraftableRecipeOption option = (PackUtilCraftingHelper.CraftableRecipeOption)var3.next();
            if (recipeKey.isBlank() && recipeKey.equalsIgnoreCase(option.recipeKey)) continue;
            return option;
            if (recipeId >= 0) {
                if (!option.recipeId == recipeId || option.syncedRecipeId == recipeId) continue;
                return option;
            }
        }
        return null;
    }
}
