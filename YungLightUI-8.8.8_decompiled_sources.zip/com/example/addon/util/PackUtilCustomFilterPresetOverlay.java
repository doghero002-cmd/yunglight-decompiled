/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiTextField;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiViewport;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPresetManager;
import com.example.addon.util.PackUtilText;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class PackUtilCustomFilterPresetOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUiTextField nameField;
    private final List<PackUtilCustomFilterPresetOverlay.ActionButton> buttons = new ArrayList();
    private final PackUtilCustomFilterPresetOverlay.PresetListState presetListState = new PackUtilCustomFilterPresetOverlay.PresetListState(this);
    private int panelX = 570;
    private int panelY = 48;
    private int panelWidth;
    private int panelHeight;
    private boolean visible = false;
    private boolean collapsed = false;
    private boolean dragging = false;
    private boolean resizing = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    private double resizeStartMouseX = 0;
    private double resizeStartMouseY = 0;
    private int resizeStartWidth = 0;
    private int resizeStartHeight = 0;
    private boolean presetScrollbarDragging = false;
    private int presetScrollbarGrabOffset = 0;
    private String selectedPresetName;

    public PackUtilCustomFilterPresetOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.panelWidth = this.defaultPanelWidth();
        this.panelHeight = this.defaultPanelHeight();
        this.nameField = new PackUiTextField().setPlaceholder("Preset name").setFieldHeight(this.inputHeight()).setMinWidth(120f).setPreferredWidth(120f).setTextTone(PackUiTone.BODY).setPlaceholderTone(PackUiTone.MUTED);
    }

    public String getOverlayId() {
        return "packutil-custom-filter-presets";
    }

    public int getMinWidth() {
        return this.defaultPanelWidth();
    }

    public int getMinHeight() {
        return this.minimumPanelHeight();
    }

    public PackUtilWindowLayout getBounds() {
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
    }

    public void setBounds(PackUtilWindowLayout bounds) {
        if (bounds == null) {
            return;
        }
        PackUtilWindowLayout clamped = this.clampToScreen(this, bounds);
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = this.defaultPanelWidth();
        this.panelHeight = Math.max(this.getMinHeight(), clamped.height);
        this.visible = clamped.visible;
        this.collapsed = clamped.collapsed;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visible) {
            PackUtilOverlayManager.get().bringToFront(this);
        } else {
            this.clearFocus();
        }
        this.saveLayout();
    }

    public void toggle() {
        this.setVisible(!this.visible);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isCollapsed() {
        return this.collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
        this.saveLayout();
    }

    public boolean usesSharedHeaderClickCollapse() {
        return true;
    }

    public boolean isOverDragBar(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        return mouseX >= (double)this.panelX && mouseX <= (double)(this.panelX + this.panelWidth) && mouseY >= (double)this.panelY && mouseY <= (double)(this.panelY + 16) && !this.isOverWindowControl(mouseX, mouseY, bounds);
    }

    public boolean hasTextFieldFocused() {
        return this.nameField.isFocused();
    }

    public void clearTextFieldFocus() {
        this.clearFocus();
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        this.buttons.clear();
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelWidth = clamped.width;
        this.panelHeight = clamped.height;
        PackUtilWindowLayout bounds = new PackUtilWindowLayout(this.panelX, this.panelY, this.panelWidth, this.panelHeight, this.visible, this.collapsed);
        if (this.dragging) { /* goto L151; */ }
        this.renderWindowFrame(context, mouseX, mouseY, bounds, "Preset Manager", this.collapsed, this.resizing);
        boolean clipBody = this.beginWindowBodyClip(context, bounds, this.collapsed);
        if (clipBody) { /* goto @208; */ }
        if (this.dragging) { /* goto L199; */ }
        this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.resizing);
        return;
        try {
            int x = this.panelX + this.panelInset();
            int y = this.panelY + 16 + this.topInset();
            int width = this.panelWidth - this.panelInset() * 2;
            PackUtilModule module = PackUtilModule.get();
            PackUtilText.draw(context, this.textRenderer, "C2S " + module.getC2SPackets().size() + " | S2C " + module.getS2CPackets().size(), PackUtilText.Tone.MUTED, x, y, false);
            y = y + this.infoLineHeight();
            PackUiListRenderer.drawHeader(context, this.textRenderer, "Preset Name", x, y);
            y = y + this.sectionHeaderHeight();
            this.nameField.setBounds((float)x, (float)y, (float)width, (float)this.inputHeight());
            this.nameField.render(this.renderContext(context, mouseX, mouseY, delta));
            y = y + (this.inputHeight() + this.actionGap());
            int halfWidth = (width - this.actionGap()) / 2;
            y = this.drawActionRow(context, mouseX, mouseY, x, y, halfWidth, "Save", this::saveNamedPreset, this.canSaveNamed(), "Load", this::loadSelectedPreset, this.canLoadSelected());
            y = this.drawActionRow(context, mouseX, mouseY, x, y, halfWidth, "Overwrite", this::overwriteSelectedPreset, this.canOverwriteSelected(), "Delete", this::deleteSelectedPreset, this.canDeleteSelected());
            y = this.drawAction(context, mouseX, mouseY, x, y, width, "Reset To Default", this::resetDefaults, true);
            y = y + (this.sectionGap() - this.actionGap());
            y = this.renderPresetSection(context, mouseX, mouseY, delta, x, y, width, Math.max(this.listMinimumHeight(), this.panelHeight - (y - this.panelY) - this.contentBottomPadding()));
        }
        finally {
            this.endWindowBodyClip(context, clipBody);
            if (this.dragging) { /* goto L621; */ }
            this.renderWindowInactiveOverlay(context, bounds, this.collapsed, this.resizing);
            throw var13;
        }
    }

    private int renderPresetSection(class_332 context, int mouseX, int mouseY, float delta, int x, int y, int width, int sectionHeight) {
        PackUiListRenderer.drawHeader(context, this.textRenderer, "Saved Presets", x, y);
        y = y + this.sectionHeaderHeight();
        List<PackUtilCustomFilterPresetOverlay.PresetRow> rows = this.buildPresetRows();
        this.presetListState.rows = rows;
        int listHeight = Math.max(this.listMinimumHeight(), sectionHeight - this.sectionHeaderHeight() - this.footerHeight() - this.footerGap());
        int viewHeight = Math.max(1, this.alignViewportHeight(Math.max(1, listHeight - 4), this.presetRowStep()));
        int contentHeight = rows.size() * this.presetRowStep();
        int maxScroll = Math.max(0, contentHeight - viewHeight);
        int visualScroll = this.presetListState.scroll.tick(delta, maxScroll);
        Metrics scrollbar = this.computePresetScrollbarMetrics(x, y, width, listHeight, contentHeight, visualScroll);
        int contentWidth = Math.max(40, width - 4 - (scrollbar.hasScroll() ? this.scrollbarGutter() : 0));
        this.presetListState.setBounds(x, y, width, listHeight, scrollbar);
        boolean focused = PackUtilOverlayManager.get().isFocusedOverlay(this) || PackUtilOverlayManager.get().isTopOverlay(this);
        PackUiListRenderer.drawFrame(context, x, y, width, listHeight, focused);
        if (rows.isEmpty()) {
            PackUiListRenderer.drawEmptyState(context, this.textRenderer, "No presets", x, y, contentWidth);
        } else {
            PackUiViewport viewport = PackUiViewport.current(1f);
            viewport.enableScissor(context, (float)(x + 2), (float)(y + 2), (float)(x + 2 + contentWidth), (float)(y + 2 + viewHeight));
        }
        try {
            int scrollPixels = visualScroll;
            int firstVisible = scrollPixels / this.presetRowStep();
            int rowY = y + 2 - scrollPixels % this.presetRowStep();
            for (int i = firstVisible; i < rows.size(); i++) {
                if (rowY >= y + 2 + viewHeight) break;
                PresetRow row = (PackUtilCustomFilterPresetOverlay.PresetRow)rows.get(i);
                if (rowY + this.presetRowHeight() <= y + 2) { /* goto L793; */ }
                int rowTextY = PackUiSizing.alignTextY(rowY, this.presetRowHeight(), this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
                if (row.header) {
                    PackUiListRenderer.drawRow(context, this.textRenderer, row.label, x + 2, rowY, contentWidth, this.presetRowHeight(), false, false, PackUiListRenderer.RowTone.WARNING);
                } else {
                    if (row.note) {
                        PackUiListRenderer.drawRow(context, this.textRenderer, row.label, x + 2, rowY, contentWidth, this.presetRowHeight(), false, false, PackUiListRenderer.RowTone.NORMAL);
                    } else {
                        if (row.entry == null) { /* goto @776; */ }
                        boolean selected = row.entry.name().equals(this.selectedPresetName);
                        boolean hovered = mouseX >= x + 2 && mouseX < x + 2 + contentWidth && mouseY >= rowY && mouseY < rowY + this.presetRowHeight();
                        PackUiListRenderer.drawRow(context, this.textRenderer, "", x + 2, rowY, contentWidth, this.presetRowHeight(), hovered, selected, row.entry.builtIn() ? PackUiListRenderer.RowTone.WARNING : PackUiListRenderer.RowTone.NORMAL);
                        int textColor = selected ? PackUtilColors.rowSelectedText() : row.entry.builtIn() ? -4729601 : PackUtilColors.textLight();
                        String prefix = row.entry.builtIn() ? "[DEV] " : "[USR] ";
                        String name = PackUtilText.trimToWidth(this.textRenderer, prefix + row.entry.name(), contentWidth - 70, PackUtilText.Tone.BODY);
                        PackUtilText.draw(context, this.textRenderer, name, textColor, x + 5, rowTextY, false);
                        String counts = row.entry.c2sCount() + " / " + row.entry.s2cCount();
                        int countsWidth = PackUtilText.width(this.textRenderer, counts, PackUtilText.Tone.BODY);
                        PackUtilText.draw(context, this.textRenderer, counts, textColor, x + contentWidth - countsWidth - 1, rowTextY, false);
                    }
                }
                PackUiListRenderer.drawDivider(context, x + 2, rowY + this.presetRowHeight(), contentWidth);
                L793: ;
                rowY = rowY + this.presetRowStep();
            }
        }
        finally {
            viewport.disableScissor(context);
            throw var32;
        }
        PackUiScrollbar.draw(context, scrollbar, scrollbar.contains((double)mouseX, (double)mouseY), this.presetScrollbarDragging);
        footer = maxScroll > 0 ? "Scroll: " + Math.min(rows.size(), Math.round((float)this.presetListState.scroll.targetOffset() / (float)this.presetRowStep()) + 1) + "/" + Math.max(1, Math.round((float)maxScroll / (float)this.presetRowStep()) + 1) : this.selectedPresetName == null ? "Select a preset row" : "Selected: " + this.selectedPresetName;
        PackUtilText.draw(context, this.textRenderer, footer, PackUtilText.Tone.MUTED, x + 4, y + listHeight + this.footerGap(), false);
        return y + listHeight + this.footerHeight() + this.footerGap();
    }

    private List<PackUtilCustomFilterPresetOverlay.PresetRow> buildPresetRows() {
        PackUtilPresetManager manager = PackUtilPresetManager.get();
        List<PackUtilCustomFilterPresetOverlay.PresetRow> rows = new ArrayList();
        rows.add(PackUtilCustomFilterPresetOverlay.PresetRow.header("Developer Templates"));
        List<PackUtilPresetManager.PresetEntry> userEntries = manager.getBuiltInPresetEntries().iterator();
        while (userEntries.hasNext()) {
            PresetEntry entry = (PackUtilPresetManager.PresetEntry)userEntries.next();
            rows.add(PackUtilCustomFilterPresetOverlay.PresetRow.entry(entry));
        }
        rows.add(PackUtilCustomFilterPresetOverlay.PresetRow.header("User Presets"));
        userEntries = manager.getUserPresetEntries();
        if (userEntries.isEmpty()) {
            rows.add(PackUtilCustomFilterPresetOverlay.PresetRow.note("No user presets yet"));
        } else {
            entry = userEntries.iterator();
            while (entry.hasNext()) {
                PresetEntry entry = (PackUtilPresetManager.PresetEntry)entry.next();
                rows.add(PackUtilCustomFilterPresetOverlay.PresetRow.entry(entry));
            }
        }
        return rows;
    }

    private void saveNamedPreset() {
        String name = this.sanitizeNameField();
        if (name == null) {
            PackUtilClientMessaging.sendPrefixed("Enter a preset name first.");
            return;
        }
        if (PackUtilPresetManager.get().savePreset(name)) {
            this.selectedPresetName = name;
            this.nameField.setText(name);
        }
    }

    private void loadSelectedPreset() {
        String presetName = this.resolveTargetPresetName();
        if (presetName == null) {
            PackUtilClientMessaging.sendPrefixed("Select a preset first.");
            return;
        }
        if (!PackUtilPresetManager.get().loadPreset(presetName)) { /* goto L66; */ }
        this.selectedPresetName = PackUtilPresetManager.get().getPresetEntry(presetName) != null ? PackUtilPresetManager.get().getPresetEntry(presetName).name() : presetName;
        this.nameField.setText(this.selectedPresetName);
    }

    private void overwriteSelectedPreset() {
        String presetName = this.resolveTargetPresetName();
        if (presetName == null) {
            PackUtilClientMessaging.sendPrefixed("Select a user preset first.");
            return;
        }
        PresetEntry entry = PackUtilPresetManager.get().getPresetEntry(presetName);
        if (entry == null || entry.builtIn()) {
            PackUtilClientMessaging.sendPrefixed("Select a user preset to overwrite.");
            return;
        }
        if (PackUtilPresetManager.get().overwriteUserPreset(entry.name())) {
            this.selectedPresetName = entry.name();
            this.nameField.setText(entry.name());
        }
    }

    private void deleteSelectedPreset() {
        String presetName = this.resolveTargetPresetName();
        if (presetName == null) {
            PackUtilClientMessaging.sendPrefixed("Select a user preset first.");
            return;
        }
        PresetEntry entry = PackUtilPresetManager.get().getPresetEntry(presetName);
        if (entry == null || entry.builtIn()) {
            PackUtilClientMessaging.sendPrefixed("Developer presets cannot be deleted.");
            return;
        }
        if (PackUtilPresetManager.get().deleteUserPreset(entry.name())) {
            if (entry.name().equals(this.selectedPresetName)) {
                this.selectedPresetName = null;
            }
            this.nameField.setText("");
        }
    }

    private void resetDefaults() {
        PackUtilModule module = PackUtilModule.get();
        module.resetC2SPacketsToDefault();
        module.resetS2CPacketsToDefault();
        PackUtilClientMessaging.sendPrefixed("Reset current filter to default packet lists.");
    }

    private String sanitizeNameField() {
        String value = this.nameField.text();
        if (value == null) {
            return null;
        }
        value = value.trim();
        return value.isEmpty() ? null : value;
    }

    private String resolveTargetPresetName() {
        if (this.selectedPresetName != null) {
            PresetEntry selectedEntry = PackUtilPresetManager.get().getPresetEntry(this.selectedPresetName);
            if (selectedEntry != null) {
                return selectedEntry.name();
            }
        }
        typedName = this.sanitizeNameField();
        if (typedName == null) {
            return null;
        }
        PresetEntry typedEntry = PackUtilPresetManager.get().getPresetEntry(typedName);
        return typedEntry != null ? typedEntry.name() : null;
    }

    private PackUtilPresetManager.PresetEntry getSelectedPresetEntry() {
        if (this.selectedPresetName == null) {
            return null;
        }
        return PackUtilPresetManager.get().getPresetEntry(this.selectedPresetName);
    }

    private boolean canSaveNamed() {
        String name = this.sanitizeNameField();
        return name != null && !PackUtilPresetManager.get().isReservedPresetName(name);
    }

    private boolean canLoadSelected() {
        return this.resolveTargetPresetName() != null;
    }

    private boolean canOverwriteSelected() {
        PresetEntry entry = this.getSelectedPresetEntry();
        return entry != null && !entry.builtIn();
    }

    private boolean canDeleteSelected() {
        return this.canOverwriteSelected();
    }

    private int drawAction(class_332 context, int mouseX, int mouseY, int x, int y, int width, String label, Runnable action, boolean enabled) {
        this.drawActionButton(context, mouseX, mouseY, x, y, width, label, enabled);
        this.buttons.add(new PackUtilCustomFilterPresetOverlay.ActionButton(x, y, width, this.actionHeight(), action, enabled));
        return y + this.actionHeight() + this.actionGap();
    }

    private int drawActionRow(class_332 context, int mouseX, int mouseY, int x, int y, int buttonWidth, String leftLabel, Runnable leftAction, boolean leftEnabled, String rightLabel, Runnable rightAction, boolean rightEnabled) {
        this.drawActionButton(context, mouseX, mouseY, x, y, buttonWidth, leftLabel, leftEnabled);
        this.buttons.add(new PackUtilCustomFilterPresetOverlay.ActionButton(x, y, buttonWidth, this.actionHeight(), leftAction, leftEnabled));
        int rightX = x + buttonWidth + this.actionGap();
        int rightWidth = this.panelWidth - this.panelInset() * 2 - buttonWidth - this.actionGap();
        this.drawActionButton(context, mouseX, mouseY, rightX, y, rightWidth, rightLabel, rightEnabled);
        this.buttons.add(new PackUtilCustomFilterPresetOverlay.ActionButton(rightX, y, rightWidth, this.actionHeight(), rightAction, rightEnabled));
        return y + this.actionHeight() + this.actionGap();
    }

    private void drawActionButton(class_332 context, int mouseX, int mouseY, int x, int y, int width, String label, boolean enabled) {
        if (enabled) {
            PackUiOverlayButton enabledButton = PackUiOverlayButton.create(x, y, width, this.actionHeight(), class_2561.method_43470(label), PackUtilCustomFilterPresetOverlay::lambda$drawActionButton$0);
            enabledButton.setVariant(PackUiOverlayButton.Variant.SECONDARY);
            PackUiOverlayButton.renderStyled(context, this.textRenderer, enabledButton, mouseX, mouseY);
            return;
        }
        disabledButton = PackUiOverlayButton.create(x, y, width, this.actionHeight(), class_2561.method_43470(label), PackUtilCustomFilterPresetOverlay::lambda$drawActionButton$1);
        disabledButton.active = false;
        disabledButton.setVariant(PackUiOverlayButton.Variant.GHOST);
        PackUiOverlayButton.renderStyled(context, this.textRenderer, disabledButton, mouseX, mouseY);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        if (button == 0) {
            if (mouseX >= (double)this.panelX) {
                if (mouseX < (double)(this.panelX + this.panelWidth)) {
                    if (mouseY >= (double)this.panelY) {
                        if (mouseY < (double)(this.panelY + 16)) {
                            PackUtilWindowLayout bounds = this.getBounds();
                            if (this.isOverCloseButton(mouseX, mouseY, bounds)) {
                                this.setVisible(false);
                                return true;
                            }
                            if (this.isOverCollapseButton(mouseX, mouseY, bounds)) {
                                this.toggleCollapsed();
                                return true;
                            }
                            this.dragging = true;
                            this.dragOffsetX = mouseX - (double)this.panelX;
                            this.dragOffsetY = mouseY - (double)this.panelY;
                            this.clearFocus();
                            return true;
                        }
                    }
                }
            }
        }
        if (this.collapsed) {
            return false;
        }
        if (button == 0) {
            scrollbar = this.presetListState.scrollbarMetrics;
            if (scrollbar != null) {
                if (scrollbar.hasScroll()) {
                    if (scrollbar.contains(mouseX, mouseY)) {
                        this.presetScrollbarDragging = true;
                        this.presetScrollbarGrabOffset = Math.max(0, (int)mouseY - scrollbar.thumbY());
                        this.presetListState.scroll.setFromThumbStepped(scrollbar, mouseY, this.presetScrollbarGrabOffset, this.presetRowStep());
                        return true;
                    }
                }
            }
        }
        if (this.handleTextFieldClick(this.nameField, mouseX, mouseY, button)) {
            return true;
        }
        if (button == 0) {
            if (this.presetListState.contains(mouseX, mouseY)) {
                row = this.presetListState.getRowAt(mouseY);
                if (row != null) {
                    if (row.entry != null) {
                        this.selectedPresetName = row.entry.name();
                        this.nameField.setText(this.selectedPresetName);
                        this.clearFocus();
                        return true;
                    }
                }
            }
        }
        this.clearFocus();
        if (button != 0) { /* goto L390; */ }
        row = this.buttons.iterator();
        while (row.hasNext()) {
            ActionButton actionButton = (PackUtilCustomFilterPresetOverlay.ActionButton)row.next();
            if (actionButton.contains(mouseX, mouseY)) {
                if (actionButton.enabled()) continue;
                return true;
                actionButton.action.run();
                return true;
            }
        }
        return this.isMouseOver(mouseX, mouseY);
    }

    private boolean handleTextFieldClick(PackUiTextField field, double mouseX, double mouseY, int button) {
        boolean clicked = field.mouseClicked(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button);
        if (clicked) {
            this.clearFocus();
            field.setFocused(true);
        }
        return clicked;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (this.nameField.mouseReleased(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button)) {
            return true;
        }
        this.presetScrollbarDragging = false;
        if (button == 0 && this.presetScrollbarDragging) {
            return true;
        }
        if (button == 0) {
            if (this.dragging || this.resizing) {
                this.saveLayout();
            }
            this.dragging = false;
            this.resizing = false;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.nameField.mouseDragged(this.inputContext(mouseX, mouseY), (float)mouseX, (float)mouseY, button, (float)deltaX, (float)deltaY)) {
            return true;
        }
        if (this.presetScrollbarDragging) {
            this.presetListState.scroll.setFromThumbStepped(this.presetListState.scrollbarMetrics, mouseY, this.presetScrollbarGrabOffset, this.presetRowStep());
            return true;
        }
        PackUtilWindowLayout nextBounds = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.resizeStartWidth + (int)Math.round(mouseX - this.resizeStartMouseX), this.resizeStartHeight + (int)Math.round(mouseY - this.resizeStartMouseY), this.visible, this.collapsed));
        if (this.resizing && button == 0) {
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            this.panelWidth = nextBounds.width;
            this.panelHeight = nextBounds.height;
            return true;
        }
        nextBounds = this.clampToScreen(this, new PackUtilWindowLayout((int)(mouseX - this.dragOffsetX), (int)(mouseY - this.dragOffsetY), this.panelWidth, this.panelHeight, this.visible, this.collapsed));
        if (this.dragging && button == 0) {
            this.panelX = nextBounds.x;
            this.panelY = nextBounds.y;
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (this.presetListState.contains(mouseX, mouseY)) {
            int maxScroll = Math.max(0, this.presetListState.rows.size() * this.presetRowStep() - this.alignViewportHeight(Math.max(1, this.presetListState.height - 4), this.presetRowStep()));
            this.presetListState.scroll.nudge(amount, (float)this.presetRowStep(), maxScroll);
            return true;
        }
        return false;
    }

    private PackUiScrollbar.Metrics computePresetScrollbarMetrics(int x, int y, int width, int listHeight, int contentHeight, int scrollOffset) {
        int viewHeight = Math.max(1, this.alignViewportHeight(Math.max(1, listHeight - 4), this.presetRowStep()));
        return PackUiScrollbar.compute(contentHeight, viewHeight, x + width - 5, y + 2, this.scrollbarTrackWidth(), Math.max(1, listHeight - 4), scrollOffset);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (keyCode == 256) {
            if (this.nameField.isFocused()) {
                this.clearFocus();
                return true;
            }
            this.setVisible(false);
            return true;
        }
        if (keyCode == 257 || keyCode == 335) {
            if (this.nameField.isFocused()) {
                if (this.canSaveNamed()) {
                    this.saveNamedPreset();
                    return true;
                }
            }
        }
        if (!this.nameField.isFocused()) {
            return false;
        }
        return this.nameField.keyPressed(this.inputContext(0, 0), keyCode, scanCode, modifiers);
    }

    public boolean charTyped(char chr, int modifiers) {
        if (!this.visible || !this.nameField.isFocused()) {
            return false;
        }
        return this.nameField.charTyped(this.inputContext(0, 0), chr, modifiers);
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!this.visible) {
            return false;
        }
        PackUtilWindowLayout bounds = this.getBounds();
        int frameHeight = this.collapsed ? 16 : this.panelHeight;
        if (mouseX >= (double)bounds.x && mouseX <= (double)(bounds.x + bounds.width) && mouseY >= (double)bounds.y && mouseY <= (double)(bounds.y + frameHeight)) {
            return true;
        }
        return mouseX >= (double)this.nameField.x() && mouseX <= (double)(this.nameField.x() + this.nameField.width()) && mouseY >= (double)this.nameField.y() && mouseY <= (double)(this.nameField.y() + this.nameField.height());
    }

    private void clearFocus() {
        this.nameField.setFocused(false);
    }

    private PackUiRenderContext renderContext(class_332 context, int mouseX, int mouseY, float delta) {
        PackUiViewport viewport = PackUiViewport.current(1f);
        return new PackUiRenderContext(context, this.textRenderer, viewport, this.theme, viewport.toUiX((double)mouseX), viewport.toUiY((double)mouseY), delta);
    }

    private PackUiRenderContext inputContext(double mouseX, double mouseY) {
        PackUiViewport viewport = PackUiViewport.current(1f);
        return new PackUiRenderContext(null, this.textRenderer, viewport, this.theme, viewport.toUiX(mouseX), viewport.toUiY(mouseY), 0f);
    }

    private int defaultPanelWidth() {
        return 236;
    }

    private int defaultPanelHeight() {
        return 318;
    }

    private int minimumPanelHeight() {
        return 250;
    }

    private int panelInset() {
        return 10;
    }

    private int topInset() {
        return 6;
    }

    private int contentBottomPadding() {
        return 12;
    }

    private int infoLineHeight() {
        return this.theme.lineHeight(PackUiTone.MUTED, 1);
    }

    private int sectionHeaderHeight() {
        return this.theme.lineHeight(PackUiTone.LABEL, 0);
    }

    private int actionHeight() {
        return 13;
    }

    private int actionGap() {
        return 2;
    }

    private int sectionGap() {
        return 6;
    }

    private int inputHeight() {
        return 16;
    }

    private int presetRowHeight() {
        return 14;
    }

    private int presetRowStep() {
        return this.presetRowHeight() + 1;
    }

    private int footerGap() {
        return 4;
    }

    private int footerHeight() {
        return this.theme.lineHeight(PackUiTone.MUTED, 1);
    }

    private int scrollbarGutter() {
        return 8;
    }

    private int scrollbarTrackWidth() {
        return 3;
    }

    private int listMinimumHeight() {
        return 52;
    }
}
