/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.PackUtilDropAction;

private static enum PackUtilFabricatorOverlay.FabricatorAction {
    public static final PackUtilFabricatorOverlay.FabricatorAction CLICK = new PackUtilFabricatorOverlay.FabricatorAction.1("CLICK", 0, "Click", "Use Left or Right on the resolved slot.");
    public static final PackUtilFabricatorOverlay.FabricatorAction QUICK_MOVE = new PackUtilFabricatorOverlay.FabricatorAction.2("QUICK_MOVE", 1, "Quick Move", "Shift-click the resolved slot.");
    public static final PackUtilFabricatorOverlay.FabricatorAction PICKUP_ALL = new PackUtilFabricatorOverlay.FabricatorAction.3("PICKUP_ALL", 2, "Pickup All", "Double-click the resolved slot. Usually needs you to hold a matching stack first.");
    public static final PackUtilFabricatorOverlay.FabricatorAction CRAFT_RESULT = new PackUtilFabricatorOverlay.FabricatorAction.4("CRAFT_RESULT", 3, "Craft", "Choose a craftable item, set the total amount, then send, queue, or add it to a macro.");
    public static final PackUtilFabricatorOverlay.FabricatorAction DROP = new PackUtilFabricatorOverlay.FabricatorAction.5("DROP", 4, "Drop", "Drop from the resolved slot. If slot and item are both set, both must match.");
    final String displayName;
    final String description;
    private static final /* synthetic */ PackUtilFabricatorOverlay.FabricatorAction[] $VALUES;

    public static PackUtilFabricatorOverlay.FabricatorAction[] values() {
        return (PackUtilFabricatorOverlay.FabricatorAction[])$VALUES.clone();
    }

    public static PackUtilFabricatorOverlay.FabricatorAction valueOf(String name) {
        return (PackUtilFabricatorOverlay.FabricatorAction)Enum.valueOf(PackUtilFabricatorOverlay.FabricatorAction.class, name);
    }

    private PackUtilFabricatorOverlay.FabricatorAction(String var1, String var2) {
        super(var1, var2);
        this.displayName = displayName;
        this.description = description;
    }

    boolean usesClickSelector() {
        return false;
    }

    boolean usesDropToggle() {
        return false;
    }

    boolean isCraftAction() {
        return false;
    }

    String getDescription(boolean dropWholeStack) {
        return this.description;
    }

    abstract PackUtilDropAction toPacketAction(boolean var1);

    static {
        $VALUES = PackUtilFabricatorOverlay.FabricatorAction.$values();
    }
}
