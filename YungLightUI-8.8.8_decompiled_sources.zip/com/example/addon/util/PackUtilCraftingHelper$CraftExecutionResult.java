/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static final class PackUtilCraftingHelper.CraftExecutionResult {
    public final boolean success;
    public final String message;
    public final int craftedAmount;

    private PackUtilCraftingHelper.CraftExecutionResult(boolean success, String message, int craftedAmount) {
        this.success = success;
        this.message = message;
        this.craftedAmount = craftedAmount;
    }

    public static PackUtilCraftingHelper.CraftExecutionResult success(String message, int craftedAmount) {
        return new PackUtilCraftingHelper.CraftExecutionResult(true, message, craftedAmount);
    }

    public static PackUtilCraftingHelper.CraftExecutionResult failure(String message) {
        return new PackUtilCraftingHelper.CraftExecutionResult(false, message, 0);
    }
}
