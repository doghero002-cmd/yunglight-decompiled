/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static enum PackUtilLANSync.SyncState {
    public static final PackUtilLANSync.SyncState IDLE = new PackUtilLANSync.SyncState("IDLE", 0);
    public static final PackUtilLANSync.SyncState PREPARING = new PackUtilLANSync.SyncState("PREPARING", 1);
    public static final PackUtilLANSync.SyncState ALL_READY = new PackUtilLANSync.SyncState("ALL_READY", 2);
    public static final PackUtilLANSync.SyncState DISPATCHING_GO = new PackUtilLANSync.SyncState("DISPATCHING_GO", 3);
    public static final PackUtilLANSync.SyncState EXECUTING = new PackUtilLANSync.SyncState("EXECUTING", 4);
    public static final PackUtilLANSync.SyncState REPORTING = new PackUtilLANSync.SyncState("REPORTING", 5);
    public static final PackUtilLANSync.SyncState DONE = new PackUtilLANSync.SyncState("DONE", 6);
    private static final /* synthetic */ PackUtilLANSync.SyncState[] $VALUES;

    public static PackUtilLANSync.SyncState[] values() {
        return (PackUtilLANSync.SyncState[])$VALUES.clone();
    }

    public static PackUtilLANSync.SyncState valueOf(String name) {
        return (PackUtilLANSync.SyncState)Enum.valueOf(PackUtilLANSync.SyncState.class, name);
    }

    private PackUtilLANSync.SyncState() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUtilLANSync.SyncState.$values();
    }
}
