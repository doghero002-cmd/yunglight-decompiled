/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

private static final record PackUtilPacketInspector.ParsedChatLine {
    private final String sender;
    private final String message;

    private PackUtilPacketInspector.ParsedChatLine(String sender, String message) {
        this.sender = sender;
        this.message = message;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String sender() {
        return this.sender;
    }

    public String message() {
        return this.message;
    }
}
