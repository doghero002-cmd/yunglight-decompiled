/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

public static final class PackUtilPacketInspector.InspectionLine {
    private final String text;
    private final int color;

    public PackUtilPacketInspector.InspectionLine(String text, int color) {
        this.text = text;
        this.color = color;
    }

    public String getText() {
        return this.text;
    }

    public int getColor() {
        return this.color;
    }
}
