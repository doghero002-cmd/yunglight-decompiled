/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import java.util.List;
import net.minecraft.class_2596;

private static final class PackUtilCustomFilterOverlay.PacketListState {
    private int x;
    private int y;
    private int width;
    private int height;
    private final PackUiSmoothScroll scroll = new PackUiSmoothScroll();
    private PackUiScrollbar.Metrics scrollbarMetrics = null;
    private List<Class<? extends class_2596<?>>> filteredPackets = List.of();

    private PackUtilCustomFilterOverlay.PacketListState() {
    }

    private void setBounds(int x, int y, int width, int height, PackUiScrollbar.Metrics scrollbarMetrics) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scrollbarMetrics = scrollbarMetrics;
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
    }
}
