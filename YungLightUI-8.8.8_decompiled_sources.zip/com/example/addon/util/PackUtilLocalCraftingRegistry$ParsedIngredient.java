/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_1856;

private static final class PackUtilLocalCraftingRegistry.ParsedIngredient {
    final class_1856 ingredient;
    final String signature;

    private PackUtilLocalCraftingRegistry.ParsedIngredient(class_1856 ingredient, String signature) {
        this.ingredient = ingredient;
        this.signature = signature;
    }
}
