/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import com.example.addon.util.macro.ToggleModuleAction;

static class PackUtilCompatManager.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode;

    static {
        $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode = new int[ToggleModuleAction.ToggleMode.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.ENABLE.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.DISABLE.ordinal()] = 2;
            /* goto L39; */
            var0 = null;
            L39: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.DISABLE.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
