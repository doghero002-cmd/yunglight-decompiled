/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.util;

import net.minecraft.class_310;
import net.minecraft.class_332;

public final class PackUtilUiScale {
    private PackUtilUiScale() {
    }

    public static double toVirtual(double value) {
        return value;
    }

    public static int getVirtualScreenWidth() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_22683() == null) {
            return 0;
        }
        return mc.method_22683().method_4486();
    }

    public static int getVirtualScreenHeight() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_22683() == null) {
            return 0;
        }
        return mc.method_22683().method_4502();
    }

    public static void pushOverlayScale(class_332 context) {
    }

    public static void popOverlayScale(class_332 context) {
    }

    public static void enableOverlayScissor(class_332 context, int x1, int y1, int x2, int y2) {
        context.method_44379(x1, y1, x2, y2);
    }
}
