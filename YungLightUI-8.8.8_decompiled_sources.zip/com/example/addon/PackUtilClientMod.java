/*
 * Decompiled with https://jar.tools
 */
package com.example.addon;

import com.example.addon.YungLightAddon;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.modules.PackUtilModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public final class PackUtilClientMod
implements ClientModInitializer {
    public void onInitializeClient() {
        YungLightAddon.FOLDER.mkdirs();
        PackUiText.eagerInitFonts();
        PackUtilModule.get().initialize();
        ClientTickEvents.END_CLIENT_TICK.register(PackUtilClientMod::lambda$onInitializeClient$0);
        ClientPlayConnectionEvents.JOIN.register(PackUtilClientMod::lambda$onInitializeClient$1);
        ClientPlayConnectionEvents.DISCONNECT.register(PackUtilClientMod::lambda$onInitializeClient$2);
        ItemTooltipCallback.EVENT.register(PackUtilClientMod::lambda$onInitializeClient$3);
    }
}
