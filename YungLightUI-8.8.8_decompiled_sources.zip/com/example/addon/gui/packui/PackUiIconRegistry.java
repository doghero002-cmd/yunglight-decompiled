/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2960;

public final class PackUiIconRegistry {
    private final Map<String, class_2960> icons = new LinkedHashMap();

    public PackUiIconRegistry register(String key, class_2960 textureId) {
        if (key == null || key.isBlank() || textureId == null) {
            return this;
        }
        this.icons.put(key, textureId);
        return this;
    }

    public class_2960 get(String key) {
        return (class_2960)this.icons.get(key);
    }
}
