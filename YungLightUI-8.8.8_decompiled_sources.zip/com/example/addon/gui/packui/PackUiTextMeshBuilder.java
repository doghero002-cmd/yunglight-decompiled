/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiVertexFormats;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.system.MemoryUtil;

final class PackUiTextMeshBuilder {
    private static final VertexFormat FORMAT = PackUiVertexFormats.POS2_TEXTURE_COLOR;
    private static final VertexFormat.class_5596 DRAW_MODE = VertexFormat.class_5596.field_27379;
    private final int vertexSize = FORMAT.getVertexSize();
    private final int primitiveIndicesCount = DRAW_MODE.field_27384;
    private ByteBuffer vertices;
    private long verticesPointerStart;
    private long verticesPointer;
    private ByteBuffer indices;
    private long indicesPointer;
    private int vertexI;
    private int indicesCount;
    private boolean building;

    PackUiTextMeshBuilder() {
    }

    void begin() {
        if (this.building) {
            throw new IllegalStateException("PackUiTextMeshBuilder.begin() called twice.");
        }
        this.ensureCapacity(256, 384);
        this.verticesPointer = this.verticesPointerStart;
        this.vertexI = 0;
        this.indicesCount = 0;
        this.building = true;
    }

    PackUiTextMeshBuilder pos(double x, double y) {
        long p = this.verticesPointer;
        MemoryUtil.memPutFloat(p, (float)x);
        MemoryUtil.memPutFloat(p + 4L, (float)y);
        this.verticesPointer = this.verticesPointer + 8L;
        return this;
    }

    PackUiTextMeshBuilder tex(double u, double v) {
        long p = this.verticesPointer;
        MemoryUtil.memPutFloat(p, (float)u);
        MemoryUtil.memPutFloat(p + 4L, (float)v);
        this.verticesPointer = this.verticesPointer + 8L;
        return this;
    }

    PackUiTextMeshBuilder color(int argb) {
        long p = this.verticesPointer;
        MemoryUtil.memPutByte(p, (byte)(argb >>> 16 & 255));
        MemoryUtil.memPutByte(p + 1L, (byte)(argb >>> 8 & 255));
        MemoryUtil.memPutByte(p + 2L, (byte)(argb & 255));
        MemoryUtil.memPutByte(p + 3L, (byte)(argb >>> 24 & 255));
        this.verticesPointer = this.verticesPointer + 4L;
        return this;
    }

    int next() {
        this.vertexI = this.vertexI + 1;
        return this.vertexI;
    }

    void quad(int i1, int i2, int i3, int i4) {
        long p = this.indicesPointer + (long)this.indicesCount * 4L;
        MemoryUtil.memPutInt(p, i1);
        MemoryUtil.memPutInt(p + 4L, i2);
        MemoryUtil.memPutInt(p + 8L, i3);
        MemoryUtil.memPutInt(p + 12L, i3);
        MemoryUtil.memPutInt(p + 16L, i4);
        MemoryUtil.memPutInt(p + 20L, i1);
        this.indicesCount = this.indicesCount + 6;
    }

    void ensureCapacity(int vertexCount, int indexCount) {
        if (this.vertices == null || this.indices == null) {
            this.vertices = BufferUtils.createByteBuffer(this.vertexSize * Math.max(256, vertexCount));
            this.verticesPointerStart = MemoryUtil.memAddress0(this.vertices);
            this.verticesPointer = this.verticesPointerStart;
            this.indices = BufferUtils.createByteBuffer(4 * Math.max(384, indexCount));
            this.indicesPointer = MemoryUtil.memAddress0(this.indices);
            return;
        }
        if ((this.vertexI + vertexCount) * this.vertexSize >= this.vertices.capacity()) {
            int offset = (int)(this.verticesPointer - this.verticesPointerStart);
            int newSize = Math.max(this.vertices.capacity() * 2, this.vertices.capacity() + vertexCount * this.vertexSize);
            ByteBuffer newVertices = BufferUtils.createByteBuffer(newSize);
            MemoryUtil.memCopy(MemoryUtil.memAddress0(this.vertices), MemoryUtil.memAddress0(newVertices), (long)offset);
            this.vertices = newVertices;
            this.verticesPointerStart = MemoryUtil.memAddress0(this.vertices);
            this.verticesPointer = this.verticesPointerStart + (long)offset;
        }
        if ((this.indicesCount + indexCount) * 4 >= this.indices.capacity()) {
            newSize = Math.max(this.indices.capacity() * 2, this.indices.capacity() + indexCount * 4);
            newIndices = BufferUtils.createByteBuffer(newSize);
            MemoryUtil.memCopy(MemoryUtil.memAddress0(this.indices), MemoryUtil.memAddress0(newIndices), (long)this.indicesCount * 4L);
            this.indices = newIndices;
            this.indicesPointer = MemoryUtil.memAddress0(this.indices);
        }
    }

    void end() {
        if (!this.building) {
            throw new IllegalStateException("PackUiTextMeshBuilder.end() called without begin().");
        }
        this.building = false;
    }

    boolean isBuilding() {
        return this.building;
    }

    int getIndicesCount() {
        return this.indicesCount;
    }

    GpuBuffer getVertexBuffer() {
        this.vertices.limit((int)(this.verticesPointer - this.verticesPointerStart));
        return FORMAT.uploadImmediateVertexBuffer(this.vertices);
    }

    GpuBuffer getIndexBuffer() {
        this.indices.limit(this.indicesCount * 4);
        return FORMAT.uploadImmediateIndexBuffer(this.indices);
    }
}
