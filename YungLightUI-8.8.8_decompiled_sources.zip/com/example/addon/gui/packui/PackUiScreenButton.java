/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiOverlayButton;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUiScreenButton {
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private final class_2561 label;
    private final Runnable action;
    private PackUiOverlayButton.Variant variant;
    private boolean active = true;

    public PackUiScreenButton(int x, int y, int width, int height, class_2561 label, PackUiOverlayButton.Variant variant, Runnable action) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.label = label == null ? class_2561.method_43473() : label;
        this.variant = variant == null ? PackUiOverlayButton.Variant.SECONDARY : variant;
        this.action = action;
    }

    public PackUiScreenButton setVariant(PackUiOverlayButton.Variant variant) {
        this.variant = variant == null ? PackUiOverlayButton.Variant.SECONDARY : variant;
        return this;
    }

    public PackUiScreenButton setActive(boolean active) {
        this.active = active;
        return this;
    }

    public void render(class_332 context, class_327 textRenderer, int mouseX, int mouseY) {
        PackUiOverlayButton button = PackUiOverlayButton.create(this.x, this.y, this.width, this.height, this.label, this::lambda$render$0);
        button.setVariant(this.variant);
        button.active = this.active;
        PackUiOverlayButton.renderStyled(context, textRenderer, button, mouseX, mouseY);
    }

    public boolean click(double mouseX, double mouseY, int mouseButton) {
        if (!this.active || mouseButton != 0) {
            return false;
        }
        if (!this.contains(mouseX, mouseY)) {
            return false;
        }
        if (this.action != null) {
            this.action.run();
        }
        return true;
    }

    public boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }
}
