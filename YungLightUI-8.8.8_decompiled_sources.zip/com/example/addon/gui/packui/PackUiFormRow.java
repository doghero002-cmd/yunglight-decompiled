/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiFormRow
extends PackUiContainer {
    private final PackUiNode labelNode;
    private final PackUiNode controlNode;
    private PackUiInsets padding = PackUiInsets.NONE;
    private int gap = 0;
    private float labelWidth = -1f;
    private boolean alignControlEnd = false;

    public PackUiFormRow(PackUiNode labelNode, PackUiNode controlNode) {
        this.labelNode = this.add(labelNode);
        this.controlNode = this.add(controlNode);
    }

    public PackUiFormRow setPadding(PackUiInsets padding) {
        this.padding = padding == null ? PackUiInsets.NONE : padding;
        return this;
    }

    public PackUiFormRow setGap(int gap) {
        this.gap = Math.max(0, gap);
        return this;
    }

    public PackUiFormRow setLabelWidth(float labelWidth) {
        this.labelWidth = Math.max(0f, labelWidth);
        return this;
    }

    public PackUiFormRow setAlignControlEnd(boolean alignControlEnd) {
        this.alignControlEnd = alignControlEnd;
        return this;
    }

    public PackUiNode labelNode() {
        return this.labelNode;
    }

    public PackUiNode controlNode() {
        return this.controlNode;
    }

    private float resolvedLabelWidth(PackUiRenderContext context) {
        if (this.labelWidth > 0f) {
            return this.labelWidth;
        }
        return this.labelNode == null ? 0f : this.labelNode.preferredWidth(context);
    }

    public float preferredWidth(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float total = (float)scaledPadding.horizontal();
        total = total + this.resolvedLabelWidth(context);
        if (this.labelNode != null) {
            if (this.labelNode.isVisible()) {
                if (this.controlNode != null) {
                    if (this.controlNode.isVisible()) {
                        total = total + (float)scaledGap;
                    }
                }
            }
        }
        if (this.controlNode != null) {
            if (this.controlNode.isVisible()) {
                total = total + this.controlNode.preferredWidth(context);
            }
        }
        return total;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        float labelHeight = this.labelNode != null && this.labelNode.isVisible() ? this.labelNode.preferredHeight(context, availableWidth) : 0f;
        float controlHeight = this.controlNode != null && this.controlNode.isVisible() ? this.controlNode.preferredHeight(context, availableWidth) : 0f;
        return (float)scaledPadding.top() + Math.max(labelHeight, controlHeight) + (float)scaledPadding.bottom();
    }

    protected void layoutChildren(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float innerX = this.x + (float)scaledPadding.left();
        float innerY = this.y + (float)scaledPadding.top();
        float innerWidth = Math.max(0f, this.width - (float)scaledPadding.horizontal());
        float innerHeight = Math.max(0f, this.height - (float)scaledPadding.vertical());
        float resolvedLabelWidth = Math.min(this.resolvedLabelWidth(context), innerWidth);
        float controlX = innerX;
        if (this.labelNode == null) { /* goto L193; */ }
        if (!this.labelNode.isVisible()) { /* goto L193; */ }
        float labelHeight = Math.min(innerHeight, this.labelNode.preferredHeight(context, resolvedLabelWidth));
        float labelY = innerY + Math.max(0f, (innerHeight - labelHeight) / 2f);
        this.labelNode.setBounds(innerX, labelY, resolvedLabelWidth, labelHeight);
        controlX = innerX + resolvedLabelWidth + (float)(this.controlNode != null && this.controlNode.isVisible() ? scaledGap : 0);
        L193: ;
        if (this.controlNode != null) {
            if (this.controlNode.isVisible()) {
                controlWidth = Math.max(0f, innerX + innerWidth - controlX);
                if (!this.controlNode.growX()) {
                    controlWidth = Math.min(controlWidth, this.controlNode.preferredWidth(context));
                }
                if (this.alignControlEnd) {
                    if (!this.controlNode.growX()) {
                        controlX = Math.max(controlX, innerX + innerWidth - controlWidth);
                    }
                }
                controlHeight = Math.min(innerHeight, this.controlNode.preferredHeight(context, controlWidth));
                float controlY = innerY + Math.max(0f, (innerHeight - controlHeight) / 2f);
                this.controlNode.setBounds(controlX, controlY, controlWidth, controlHeight);
            }
        }
    }
}
