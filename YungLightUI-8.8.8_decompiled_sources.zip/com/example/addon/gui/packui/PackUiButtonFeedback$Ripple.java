/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

private static final class PackUiButtonFeedback.Ripple {
    private final float centerX;
    private final float centerY;
    private final float maxRadius;
    private float age;

    private PackUiButtonFeedback.Ripple(float centerX, float centerY, float maxRadius) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.maxRadius = maxRadius;
    }
}
