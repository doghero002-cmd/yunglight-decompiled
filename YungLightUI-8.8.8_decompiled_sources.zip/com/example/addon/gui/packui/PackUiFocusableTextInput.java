/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public interface PackUiFocusableTextInput {
    public boolean isFocused();

    public void setFocused(boolean var1);
}
