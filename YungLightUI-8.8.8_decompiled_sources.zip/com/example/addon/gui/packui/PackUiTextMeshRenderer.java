/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiTextMeshBuilder;
import com.example.addon.gui.packui.PackUiTextMeshUniforms;
import com.example.addon.gui.packui.PackUiTextPipelines;
import com.example.addon.gui.packui.PackUiTextTexture;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.OptionalInt;
import net.minecraft.class_310;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;

final class PackUiTextMeshRenderer {
    private static final Matrix4f PROJECTION = new Matrix4f();
    private static final Matrix4f MODEL_VIEW = new Matrix4f();

    private PackUiTextMeshRenderer() {
    }

    static void draw(PackUiTextMeshBuilder mesh, PackUiTextTexture texture, Matrix3x2fc transform) {
        if (mesh.isBuilding()) {
            mesh.end();
        }
        int indexCount = mesh.getIndicesCount();
        if (indexCount <= 0) {
            return;
        }
        GpuBuffer vertexBuffer = mesh.getVertexBuffer();
        GpuBuffer indexBuffer = mesh.getIndexBuffer();
        PROJECTION.setOrtho(0f, (float)class_310.method_1551().method_22683().method_4486(), (float)class_310.method_1551().method_22683().method_4502(), 0f, -1000f, 1000f);
        MODEL_VIEW.set(transform.m00(), transform.m10(), 0f, 0f, transform.m01(), transform.m11(), 0f, 0f, 0f, 0f, 1f, 0f, transform.m20(), transform.m21(), 0f, 1f);
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().mul(MODEL_VIEW);
        GpuBufferSlice meshData = PackUiTextMeshUniforms.write(PROJECTION, RenderSystem.getModelViewStack());
        RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(PackUiTextMeshRenderer::lambda$draw$0, class_310.method_1551().method_1522().method_71639(), OptionalInt.empty());
        pass.setPipeline(PackUiTextPipelines.UI_TEXT);
        pass.setUniform("MeshData", meshData);
        pass.bindTexture("u_Texture", texture.method_71659(), texture.method_75484());
        pass.setVertexBuffer(0, vertexBuffer);
        pass.setIndexBuffer(indexBuffer, VertexFormat.class_5595.field_27373);
        pass.drawIndexed(0, 0, indexCount, 1);
        pass.close();
        RenderSystem.getModelViewStack().popMatrix();
    }
}
