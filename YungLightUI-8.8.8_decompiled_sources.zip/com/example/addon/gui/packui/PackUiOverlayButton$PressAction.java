/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiOverlayButton;

@FunctionalInterface
public static interface PackUiOverlayButton.PressAction {
    public void onPress(PackUiOverlayButton var1);
}
