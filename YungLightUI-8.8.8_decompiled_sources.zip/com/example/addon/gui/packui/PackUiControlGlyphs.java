/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAssets;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class PackUiControlGlyphs {
    private PackUiControlGlyphs() {
    }

    public static boolean isCloseIcon(class_2960 icon) {
        return PackUiAssets.ICON_WINDOW_CLOSE.equals(icon);
    }

    public static boolean isChevronIcon(class_2960 icon) {
        return PackUiAssets.ICON_WINDOW_CHEVRON_RIGHT.equals(icon) || PackUiAssets.ICON_WINDOW_CHEVRON_DOWN.equals(icon) || PackUiAssets.ICON_WINDOW_CHEVRON_UP.equals(icon);
    }

    public static void drawKnownIcon(class_332 context, class_2960 icon, int x, int y, int size, int color, int shadowColor, float alpha) {
        if (icon == null || context == null || size <= 0) {
            return;
        }
        if (PackUiControlGlyphs.isCloseIcon(icon)) {
            PackUiControlGlyphs.drawClose(context, x, y, size, color, shadowColor, alpha);
            return;
        }
        if (PackUiAssets.ICON_WINDOW_CHEVRON_RIGHT.equals(icon)) {
            PackUiControlGlyphs.drawChevron(context, x, y, size, PackUiControlGlyphs.ChevronDirection.RIGHT, color, shadowColor, alpha);
            return;
        }
        if (PackUiAssets.ICON_WINDOW_CHEVRON_DOWN.equals(icon)) {
            PackUiControlGlyphs.drawChevron(context, x, y, size, PackUiControlGlyphs.ChevronDirection.DOWN, color, shadowColor, alpha);
            return;
        }
        if (PackUiAssets.ICON_WINDOW_CHEVRON_UP.equals(icon)) {
            PackUiControlGlyphs.drawChevron(context, x, y, size, PackUiControlGlyphs.ChevronDirection.UP, color, shadowColor, alpha);
        }
    }

    public static void drawClose(class_332 context, int x, int y, int size, int color, int shadowColor, float alpha) {
        PackUiControlGlyphs.drawTexture(context, PackUiAssets.ICON_WINDOW_CLOSE, x, y, size, alpha, 0f);
    }

    public static void drawChevron(class_332 context, int x, int y, int size, PackUiControlGlyphs.ChevronDirection direction, int color, int shadowColor, float alpha) {
        switch (direction.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                class_2960 icon = PackUiAssets.ICON_WINDOW_CHEVRON_RIGHT;
                break;
            case 1::
                icon = PackUiAssets.ICON_WINDOW_CHEVRON_DOWN;
                break;
            case 2::
                icon = PackUiAssets.ICON_WINDOW_CHEVRON_UP;
                break;
        }
        PackUiControlGlyphs.drawTexture(context, icon, x, y, size, alpha, 0f);
    }

    public static void drawChevronProgress(class_332 context, int x, int y, int size, float progress, int color, int shadowColor, float alpha) {
        float clamped = Math.max(0f, Math.min(1f, progress));
        PackUiControlGlyphs.drawTexture(context, PackUiAssets.ICON_WINDOW_CHEVRON_RIGHT, x, y, size, alpha, clamped * 1.5707964f);
    }

    private static int applyAlpha(int color, float alpha) {
        int baseAlpha = color >>> 24 & 255;
        int outAlpha = Math.max(0, Math.min(255, Math.round((float)baseAlpha * Math.max(0f, Math.min(1f, alpha)))));
        return outAlpha << 24 | color & 16777215;
    }

    private static void drawTexture(class_332 context, class_2960 icon, int x, int y, int size, float alpha, float rotationRadians) {
        if (context == null || icon == null || size <= 0 || alpha <= 0.001f) {
            return;
        }
        if (Math.abs(rotationRadians) <= 0.0001f) {
            context.method_70845(icon, x, y, x + size, y + size, 0f, 1f, 0f, 1f);
            if (alpha < 0.999f) {
                int overlayAlpha = Math.max(0, Math.min(255, Math.round((1f - alpha) * 255f)));
                context.method_25294(x, y, x + size, y + size, overlayAlpha << 24 | 460553);
            }
            return;
        }
        half = (float)size / 2f;
        context.method_51448().pushMatrix();
        context.method_51448().translate((float)x + half, (float)y + half);
        context.method_51448().rotate(rotationRadians);
        context.method_51448().translate(-half, -half);
        context.method_70845(icon, 0, 0, size, size, 0f, 1f, 0f, 1f);
        context.method_51448().popMatrix();
        if (alpha < 0.999f) {
            int overlayAlpha = Math.max(0, Math.min(255, Math.round((1f - alpha) * 255f)));
            context.method_25294(x, y, x + size, y + size, overlayAlpha << 24 | 460553);
        }
    }
}
