/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiColumn
extends PackUiContainer {
    private PackUiInsets padding = PackUiInsets.NONE;
    private int gap = 0;

    public PackUiColumn setPadding(PackUiInsets padding) {
        this.padding = padding == null ? PackUiInsets.NONE : padding;
        return this;
    }

    public PackUiColumn setGap(int gap) {
        this.gap = Math.max(0, gap);
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float innerWidth = Math.max(0f, availableWidth - (float)scaledPadding.horizontal());
        float total = (float)(scaledPadding.top() + scaledPadding.bottom());
        boolean first = true;
        var var8 = this.children.iterator();
        while (var8.hasNext()) {
            PackUiNode child = (PackUiNode)var8.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            if (first) continue;
            total = total + (float)scaledGap;
            total = total + child.preferredHeight(context, innerWidth);
            first = false;
        }
        return total;
    }

    protected void layoutChildren(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float innerX = this.x + (float)scaledPadding.left();
        float cursorY = this.y + (float)scaledPadding.top();
        float innerWidth = Math.max(0f, this.width - (float)scaledPadding.horizontal());
        var var7 = this.children.iterator();
        while (var7.hasNext()) {
            PackUiNode child = (PackUiNode)var7.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            float childHeight = child.preferredHeight(context, innerWidth);
            child.setBounds(innerX, cursorY, innerWidth, childHeight);
            cursorY = cursorY + (childHeight + (float)scaledGap);
        }
    }
}
