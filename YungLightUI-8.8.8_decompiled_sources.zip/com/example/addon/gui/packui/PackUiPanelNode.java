/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiColumn;
import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiPanelNode
extends PackUiContainer {
    private final PackUiColumn content = new PackUiColumn();
    private boolean active = true;
    private PackUiInsets padding = PackUiInsets.all(6);
    private boolean drawBorder = true;
    private boolean drawFill = true;

    public PackUiPanelNode() {
        this.add(this.content);
    }

    public PackUiColumn content() {
        return this.content;
    }

    public PackUiPanelNode setActive(boolean active) {
        this.active = active;
        return this;
    }

    public PackUiPanelNode setPadding(PackUiInsets padding) {
        this.padding = padding == null ? PackUiInsets.NONE : padding;
        return this;
    }

    public PackUiPanelNode setDrawBorder(boolean drawBorder) {
        this.drawBorder = drawBorder;
        return this;
    }

    public PackUiPanelNode setDrawFill(boolean drawFill) {
        this.drawFill = drawFill;
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        return (float)scaledPadding.horizontal() + this.content.preferredWidth(context);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        return (float)scaledPadding.vertical() + this.content.preferredHeight(context, Math.max(0f, availableWidth - (float)scaledPadding.horizontal()));
    }

    protected void layoutChildren(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        this.content.setBounds(this.x + (float)scaledPadding.left(), this.y + (float)scaledPadding.top(), Math.max(0f, this.width - (float)scaledPadding.horizontal()), Math.max(0f, this.height - (float)scaledPadding.vertical()));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        PackUiRenderContext drawContext = context.withAlpha(this.active ? 1f : 0.56f);
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        int fill = this.active ? drawContext.theme().windowFill() : -1744369911;
        int border = this.active ? drawContext.theme().borderColor() : drawContext.theme().borderSoft();
        if (this.drawFill) {
            drawContext.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, drawContext.applyAlpha(fill));
        }
        if (this.drawBorder) {
            drawContext.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + 1, drawContext.applyAlpha(border));
            drawContext.drawContext().method_25294(drawX, drawY + drawH - 1, drawX + drawW, drawY + drawH, drawContext.applyAlpha(border));
            drawContext.drawContext().method_25294(drawX, drawY, drawX + 1, drawY + drawH, drawContext.applyAlpha(border));
            drawContext.drawContext().method_25294(drawX + drawW - 1, drawY, drawX + drawW, drawY + drawH, drawContext.applyAlpha(border));
            drawContext.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + 2, drawContext.applyAlpha(620756991));
            drawContext.drawContext().method_25294(drawX + 1, drawY + 1, drawX + 2, drawY + drawH - 1, drawContext.applyAlpha(620756991));
            drawContext.drawContext().method_25294(drawX + 1, drawY + drawH - 2, drawX + drawW - 1, drawY + drawH - 1, drawContext.applyAlpha(402653184));
            drawContext.drawContext().method_25294(drawX + drawW - 2, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, drawContext.applyAlpha(402653184));
        }
        super.render(drawContext);
    }
}
