/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class PackUiContainer
extends PackUiNode {
    protected final List<PackUiNode> children = new ArrayList();

    public <T extends PackUiNode> T add(T child) {
        if (child != null) {
            this.children.add(child);
        }
        return child;
    }

    public void clearChildren() {
        this.children.clear();
    }

    public List<PackUiNode> children() {
        return Collections.unmodifiableList(this.children);
    }

    protected abstract void layoutChildren(PackUiRenderContext var1);

    public void layout(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        this.layoutChildren(context);
        var var2 = this.children.iterator();
        while (var2.hasNext()) {
            PackUiNode child = (PackUiNode)var2.next();
            if (child != null) {
                if (!child.isVisible()) continue;
                child.layout(context);
            }
        }
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        this.layout(context);
        var var2 = this.children.iterator();
        while (var2.hasNext()) {
            PackUiNode child = (PackUiNode)var2.next();
            if (child != null) {
                if (!child.isVisible()) continue;
                child.render(context);
            }
        }
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        for (int i = this.children.size() - 1; i >= 0; i--) {
            PackUiNode child = (PackUiNode)this.children.get(i);
            if (!child != null && child.isVisible() && child.contains(mouseX, mouseY) && child.mouseClicked(context, mouseX, mouseY, button)) continue;
            return true;
        }
        return false;
    }

    public boolean mouseReleased(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (!this.visible) {
            return false;
        }
        for (int i = this.children.size() - 1; i >= 0; i--) {
            PackUiNode child = (PackUiNode)this.children.get(i);
            if (!child != null && child.isVisible() && child.mouseReleased(context, mouseX, mouseY, button)) continue;
            return true;
        }
        return false;
    }

    public boolean mouseDragged(PackUiRenderContext context, float mouseX, float mouseY, int button, float deltaX, float deltaY) {
        if (!this.visible) {
            return false;
        }
        for (int i = this.children.size() - 1; i >= 0; i--) {
            PackUiNode child = (PackUiNode)this.children.get(i);
            if (!child != null && child.isVisible() && child.mouseDragged(context, mouseX, mouseY, button, deltaX, deltaY)) continue;
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(PackUiRenderContext context, float mouseX, float mouseY, float amount) {
        if (!this.visible) {
            return false;
        }
        for (int i = this.children.size() - 1; i >= 0; i--) {
            PackUiNode child = (PackUiNode)this.children.get(i);
            if (!child != null && child.isVisible() && child.contains(mouseX, mouseY) && child.mouseScrolled(context, mouseX, mouseY, amount)) continue;
            return true;
        }
        return false;
    }

    public boolean keyPressed(PackUiRenderContext context, int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        for (int i = this.children.size() - 1; i >= 0; i--) {
            PackUiNode child = (PackUiNode)this.children.get(i);
            if (!child != null && child.isVisible() && child.keyPressed(context, keyCode, scanCode, modifiers)) continue;
            return true;
        }
        return false;
    }

    public boolean charTyped(PackUiRenderContext context, char chr, int modifiers) {
        if (!this.visible) {
            return false;
        }
        for (int i = this.children.size() - 1; i >= 0; i--) {
            PackUiNode child = (PackUiNode)this.children.get(i);
            if (!child != null && child.isVisible() && child.charTyped(context, chr, modifiers)) continue;
            return true;
        }
        return false;
    }
}
