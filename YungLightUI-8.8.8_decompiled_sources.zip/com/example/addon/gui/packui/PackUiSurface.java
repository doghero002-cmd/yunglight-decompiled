/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiFocusableTextInput;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiViewport;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class PackUiSurface {
    private final PackUiTheme theme;
    private final PackUiNode root;
    private final float density;

    public PackUiSurface(PackUiTheme theme, PackUiNode root) {
        this(theme, root, 2f);
    }

    public PackUiSurface(PackUiTheme theme, PackUiNode root, float density) {
        this.theme = theme == null ? new PackUiTheme() : theme;
        this.root = root;
        this.density = density <= 0f ? 2f : density;
    }

    public PackUiViewport viewport() {
        return PackUiViewport.current(this.density);
    }

    public void render(class_332 drawContext, int mouseX, int mouseY, float delta) {
        if (this.root == null) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return;
        }
        PackUiViewport viewport = this.viewport();
        viewport.push(drawContext);
        try {
            PackUiRenderContext context = new PackUiRenderContext(drawContext, mc.field_1772, viewport, this.theme, viewport.toUiX((double)mouseX), viewport.toUiY((double)mouseY), delta);
            this.root.render(context);
        }
        finally {
            viewport.pop(drawContext);
            throw var8;
        }
    }

    public PackUiRenderContext measurementContext() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return null;
        }
        PackUiViewport viewport = this.viewport();
        return new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, 0f, 0f, 0f);
    }

    public float measurePreferredHeight(float availableWidth) {
        if (this.root == null) {
            return 0f;
        }
        PackUiRenderContext context = this.measurementContext();
        if (context == null) {
            return 0f;
        }
        return this.root.preferredHeight(context, availableWidth);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (this.root == null) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return false;
        }
        PackUiViewport viewport = this.viewport();
        PackUiRenderContext context = new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, viewport.toUiX(mouseX), viewport.toUiY(mouseY), 0f);
        return this.root.mouseClicked(context, viewport.toUiX(mouseX), viewport.toUiY(mouseY), button);
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (this.root == null) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return false;
        }
        PackUiViewport viewport = this.viewport();
        PackUiRenderContext context = new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, viewport.toUiX(mouseX), viewport.toUiY(mouseY), 0f);
        return this.root.mouseReleased(context, viewport.toUiX(mouseX), viewport.toUiY(mouseY), button);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.root == null) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return false;
        }
        PackUiViewport viewport = this.viewport();
        PackUiRenderContext context = new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, viewport.toUiX(mouseX), viewport.toUiY(mouseY), 0f);
        return this.root.mouseDragged(context, viewport.toUiX(mouseX), viewport.toUiY(mouseY), button, (float)(deltaX / (double)viewport.drawScaleX()), (float)(deltaY / (double)viewport.drawScaleY()));
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (this.root == null) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return false;
        }
        PackUiViewport viewport = this.viewport();
        PackUiRenderContext context = new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, viewport.toUiX(mouseX), viewport.toUiY(mouseY), 0f);
        return this.root.mouseScrolled(context, viewport.toUiX(mouseX), viewport.toUiY(mouseY), (float)amount);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.root == null) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return false;
        }
        PackUiViewport viewport = this.viewport();
        PackUiRenderContext context = new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, 0f, 0f, 0f);
        return this.root.keyPressed(context, keyCode, scanCode, modifiers);
    }

    public boolean charTyped(char chr, int modifiers) {
        if (this.root == null) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return false;
        }
        PackUiViewport viewport = this.viewport();
        PackUiRenderContext context = new PackUiRenderContext(null, mc.field_1772, viewport, this.theme, 0f, 0f, 0f);
        return this.root.charTyped(context, chr, modifiers);
    }

    public boolean hasFocusedTextInput() {
        return this.hasFocusedTextInput(this.root);
    }

    public void clearFocusedTextInputs() {
        this.clearFocusedTextInputs(this.root);
    }

    private boolean hasFocusedTextInput(PackUiNode node) {
        if (node == null || !node.isVisible()) {
            return false;
        }
        if (node instanceof PackUiFocusableTextInput) {
            PackUiFocusableTextInput input = (PackUiFocusableTextInput)node;
            if (input.isFocused()) {
                return true;
            }
        }
        if (!node instanceof PackUiContainer) { /* goto L92; */ }
        container = (PackUiContainer)node;
        var var3 = container.children().iterator();
        while (var3.hasNext()) {
            PackUiNode child = (PackUiNode)var3.next();
            if (!this.hasFocusedTextInput(child)) continue;
            return true;
        }
        return false;
    }

    private void clearFocusedTextInputs(PackUiNode node) {
        if (node == null || !node.isVisible()) {
            return;
        }
        if (node instanceof PackUiFocusableTextInput) {
            PackUiFocusableTextInput input = (PackUiFocusableTextInput)node;
            input.setFocused(false);
        }
        if (!node instanceof PackUiContainer) { /* goto L82; */ }
        container = (PackUiContainer)node;
        var var3 = container.children().iterator();
        while (var3.hasNext()) {
            PackUiNode child = (PackUiNode)var3.next();
            this.clearFocusedTextInputs(child);
        }
    }
}
