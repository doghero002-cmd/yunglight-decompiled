/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiFocusableTextInput;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_5250;

public class PackUiTextField
extends PackUiNode
implements PackUiFocusableTextInput {
    private static final int DEFAULT_MAX_LENGTH = 512;
    private String value = "";
    private String placeholder = "";
    private int maxLength = 512;
    private float minWidth = 56f;
    private float maxWidth = 340282350000000000000000000000000000000f;
    private float preferredWidth = -1f;
    private int horizontalPadding = 6;
    private int fixedHeight = -1;
    private int textYOffset = 1;
    private boolean editable = true;
    private boolean drawBackground = true;
    private boolean focused = false;
    private int cursor = 0;
    private int selectionAnchor = 0;
    private int viewOffset = 0;
    private int wrapViewLine = 0;
    private boolean draggingSelection = false;
    private boolean multiline = false;
    private long blinkStartMs = System.currentTimeMillis();
    private class_2960 fontId = null;
    private PackUiTone textTone = PackUiTone.BODY;
    private PackUiTone placeholderTone = PackUiTone.MUTED;
    private Predicate<String> filter;
    private Consumer<String> onChange;
    private Consumer<String> onSubmit;
    private Function<String, class_2561> displayTextProvider;

    public PackUiTextField() {
        this.filter = PackUiTextField::lambda$new$0;
        this.height = 16f;
    }

    public PackUiTextField setText(String value) {
        String sanitized = this.sanitize(value);
        if (!Objects.equals(this.value, sanitized)) {
            this.value = sanitized;
            if (this.cursor > this.value.length()) {
                this.cursor = this.value.length();
            }
            if (this.selectionAnchor > this.value.length()) {
                this.selectionAnchor = this.value.length();
            }
            if (this.onChange != null) {
                this.onChange.accept(this.value);
            }
        }
        this.ensureSelectionOrder();
        this.viewOffset = Math.min(this.viewOffset, this.value.length());
        return this;
    }

    public String text() {
        return this.value;
    }

    public PackUiTextField setPlaceholder(String placeholder) {
        this.placeholder = placeholder == null ? "" : placeholder;
        return this;
    }

    public PackUiTextField setMaxLength(int maxLength) {
        this.maxLength = Math.max(1, maxLength);
        this.setText(this.value);
        return this;
    }

    public PackUiTextField setMinWidth(float minWidth) {
        this.minWidth = Math.max(0f, minWidth);
        return this;
    }

    public PackUiTextField setMaxWidth(float maxWidth) {
        this.maxWidth = Math.max(this.minWidth, maxWidth);
        return this;
    }

    public PackUiTextField setPreferredWidth(float preferredWidth) {
        this.preferredWidth = preferredWidth;
        return this;
    }

    public PackUiTextField setHorizontalPadding(int horizontalPadding) {
        this.horizontalPadding = Math.max(0, horizontalPadding);
        return this;
    }

    public PackUiTextField setFieldHeight(int fixedHeight) {
        this.fixedHeight = Math.max(1, fixedHeight);
        return this;
    }

    public PackUiTextField setTextYOffset(int textYOffset) {
        this.textYOffset = textYOffset;
        return this;
    }

    public PackUiTextField setEditable(boolean editable) {
        this.editable = editable;
        if (!editable) {
            this.setFocused(false);
        }
        return this;
    }

    public boolean isEditable() {
        return this.editable;
    }

    public PackUiTextField setDrawBackground(boolean drawBackground) {
        this.drawBackground = drawBackground;
        return this;
    }

    public PackUiTextField setFontId(class_2960 fontId) {
        this.fontId = fontId;
        return this;
    }

    public PackUiTextField setTextTone(PackUiTone textTone) {
        this.textTone = textTone == null ? PackUiTone.BODY : textTone;
        return this;
    }

    public PackUiTextField setPlaceholderTone(PackUiTone placeholderTone) {
        this.placeholderTone = placeholderTone == null ? PackUiTone.MUTED : placeholderTone;
        return this;
    }

    public PackUiTextField setFilter(Predicate<String> filter) {
        this.filter = filter == null ? PackUiTextField::lambda$setFilter$1 : filter;
        return this;
    }

    public PackUiTextField setOnChange(Consumer<String> onChange) {
        this.onChange = onChange;
        return this;
    }

    public PackUiTextField setOnSubmit(Consumer<String> onSubmit) {
        this.onSubmit = onSubmit;
        return this;
    }

    public PackUiTextField setDisplayTextProvider(Function<String, class_2561> displayTextProvider) {
        this.displayTextProvider = displayTextProvider;
        return this;
    }

    public PackUiTextField setMultiline(boolean multiline) {
        this.multiline = multiline;
        if (multiline) {
            this.viewOffset = 0;
        } else {
            this.wrapViewLine = 0;
        }
        return this;
    }

    public PackUiTextField setGrowX(boolean growX) {
        super.setGrowX(growX);
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        if (this.preferredWidth > 0f) {
            return PackUiSizing.clamp(this.preferredWidth, this.minWidth, this.maxWidth);
        }
        String sample = this.value.isEmpty() ? this.placeholder : this.value;
        if (sample.isEmpty()) {
            sample = "Text";
        }
        class_2960 font = this.resolvedFont(context);
        int color = context.theme().color(this.textTone);
        return PackUiSizing.fitTextWidth(context.textRenderer(), sample, font, color, (float)context.theme().scale(this.horizontalPadding + 2), this.minWidth, this.maxWidth);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        int resolvedFixedHeight = this.fixedHeight > 0 ? this.fixedHeight : Math.max(context.theme().buttonHeight(), context.theme().scale(16));
        int contentHeight = context.theme().fontHeight(this.textTone) + context.theme().scale(5);
        return (float)Math.max(12, Math.max(resolvedFixedHeight, contentHeight));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        boolean hovered = this.contains(context.mouseX(), context.mouseY());
        float hover = this.updateHover(hovered, context.delta());
        class_2960 font = this.resolvedFont(context);
        int fontHeight = context.theme().fontHeight(this.textTone);
        int scaledHorizontalPadding = context.theme().scale(this.horizontalPadding);
        int textYOffsetPx = context.theme().fieldTextNudge() + this.textYOffset - 1;
        int contentInset = context.theme().scale(3);
        int frameInset = context.theme().scale(2);
        int lineSpacing = context.theme().scale(1);
        int bodyColor = context.theme().color(this.textTone);
        int placeholderColor = context.theme().color(this.placeholderTone);
        int bg = this.focused ? -1559491569 : 2081032460;
        int border = !this.editable ? context.theme().color(PackUiTone.MUTED) : this.focused ? context.theme().headerAccent() : hover > 0f ? -3390139 : context.theme().borderColor();
        int innerW = Math.max(1, drawW - scaledHorizontalPadding * 2 - frameInset);
        RichMetrics richMetrics = this.value.isEmpty() ? null : this.buildRichMetrics(this.value);
        if (!this.multiline) {
            this.ensureViewOffset(context.textRenderer(), font, bodyColor, innerW, richMetrics);
        }
        if (this.drawBackground) {
            context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(bg));
        }
        int hoverTint = (int)(hover * 14f) << 24 | 16723759;
        if (this.editable && hover > 0f && !this.focused) {
            context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(hoverTint));
        }
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + 1, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY + drawH - 1, drawX + drawW, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY, drawX + 1, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX + drawW - 1, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(border));
        if (!this.editable) {
            context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(1712592152));
        } else {
            if (this.focused) {
                context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(318716731));
            }
        }
        textX = drawX + scaledHorizontalPadding;
        if (this.value.isEmpty()) {
            if (this.multiline) {
                int textY = drawY + contentInset + textYOffsetPx;
                context.viewport().enableScissor(context.drawContext(), (float)(drawX + 1), (float)(drawY + 1), (float)(drawX + drawW - 1), (float)(drawY + drawH - 1));
            }
        }
        try {
            String displayPlaceholder = this.wrapPlainText(context.textRenderer(), font, placeholderColor, this.placeholder, innerW).iterator();
            while (displayPlaceholder.hasNext()) {
                String line = (String)displayPlaceholder.next();
                if (textY + fontHeight > drawY + drawH - frameInset) {
                } else {
                    PackUiText.draw(context.drawContext(), context.textRenderer(), line, font, context.applyAlpha(placeholderColor), textX, textY, false);
                    textY = textY + (fontHeight + lineSpacing);
                }
            }
        }
        finally {
            context.viewport().disableScissor(context.drawContext());
            throw selectionStart;
        }
        if (this.focused) {
            if (this.blinkVisible()) {
                context.drawContext().method_25294(textX, drawY + contentInset, textX + 1, drawY + contentInset + fontHeight, context.applyAlpha(-4627));
            }
        }
        /* goto @1958; */
        L839: ;
        textY = PackUiSizing.alignTextY(drawY, drawH, fontHeight, textYOffsetPx);
        displayPlaceholder = PackUiText.trimToWidth(context.textRenderer(), this.placeholder, innerW, font, placeholderColor);
        PackUiText.draw(context.drawContext(), context.textRenderer(), displayPlaceholder, font, context.applyAlpha(placeholderColor), textX, textY, false);
        if (this.focused) {
            if (this.blinkVisible()) {
                context.drawContext().method_25294(textX, drawY + contentInset, textX + 1, drawY + drawH - contentInset, context.applyAlpha(-4627));
            }
        }
        /* goto @1958; */
        L944: ;
        if (this.multiline) {
            wrappedLines = this.wrapValueLines(context.textRenderer(), font, bodyColor, innerW, richMetrics);
            lineHeight = fontHeight + lineSpacing;
            visibleLineCount = Math.max(1, Math.max(1, drawH - context.theme().scale(6)) / lineHeight);
            this.ensureWrapViewLine(visibleLineCount, wrappedLines);
            selectionStart = Math.min(this.cursor, this.selectionAnchor);
            int selectionEnd = Math.max(this.cursor, this.selectionAnchor);
            int startLine = Math.min(this.wrapViewLine, Math.max(0, wrappedLines.size() - 1));
            int endLine = Math.min(wrappedLines.size(), startLine + visibleLineCount);
            context.viewport().enableScissor(context.drawContext(), (float)(drawX + 1), (float)(drawY + 1), (float)(drawX + drawW - 1), (float)(drawY + drawH - 1));
        }
        try {
            int lineY = drawY + contentInset + textYOffsetPx;
            for (int lineIndex = startLine; lineIndex < endLine; lineIndex++) {
                WrappedLine line = (PackUiTextField.WrappedLine)wrappedLines.get(lineIndex);
                if (selectionStart != selectionEnd) {
                    int visibleSelectionStart = Math.max(selectionStart, line.start());
                    int visibleSelectionEnd = Math.min(selectionEnd, line.end());
                    if (visibleSelectionStart < visibleSelectionEnd) {
                        int selectionX = textX + this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, line.start(), visibleSelectionStart);
                        int selectionW = this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, visibleSelectionStart, visibleSelectionEnd);
                        context.drawContext().method_25294(selectionX, lineY - 1, selectionX + selectionW, lineY + fontHeight + lineSpacing, context.applyAlpha(1728006730));
                    }
                }
                if (richMetrics != null) {
                    lineText = this.buildRichSubstringText(this.value, richMetrics, line.start(), line.end());
                    context.drawContext().method_51439(context.textRenderer(), lineText, textX, lineY, context.applyAlpha(bodyColor), false);
                } else {
                    lineText = this.value.substring(line.start(), line.end());
                    PackUiText.draw(context.drawContext(), context.textRenderer(), lineText, font, context.applyAlpha(bodyColor), textX, lineY, false);
                }
                lineY = lineY + lineHeight;
            }
        }
        finally {
            context.viewport().disableScissor(context.drawContext());
            throw var36;
        }
        if (this.focused) {
            if (this.blinkVisible()) {
                cursorLine = this.lineIndexForCursor(wrappedLines, this.cursor);
                if (cursorLine >= startLine) {
                    if (cursorLine < endLine) {
                        line = (PackUiTextField.WrappedLine)wrappedLines.get(cursorLine);
                        visibleCursor = Math.min(this.cursor, line.end());
                        caretX = textX + this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, line.start(), visibleCursor);
                        caretY = drawY + contentInset + textYOffsetPx + (cursorLine - startLine) * lineHeight;
                        context.drawContext().method_25294(caretX, caretY - 1, caretX + 1, caretY + fontHeight + lineSpacing, context.applyAlpha(-4627));
                    }
                }
            }
        }
        /* goto @1958; */
        L1559: ;
        textY = PackUiSizing.alignTextY(drawY, drawH, fontHeight, textYOffsetPx);
        visibleEnd = this.visibleEndIndex(context.textRenderer(), font, bodyColor, innerW, richMetrics);
        selectionStart = Math.min(this.cursor, this.selectionAnchor);
        selectionEnd = Math.max(this.cursor, this.selectionAnchor);
        if (selectionStart != selectionEnd) {
            visibleSelectionStart = Math.max(selectionStart, this.viewOffset);
            visibleSelectionEnd = Math.min(selectionEnd, visibleEnd);
            if (visibleSelectionStart < visibleSelectionEnd) {
                selectionX = textX + this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, this.viewOffset, visibleSelectionStart);
                selectionW = this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, visibleSelectionStart, visibleSelectionEnd);
                context.drawContext().method_25294(selectionX, drawY + 2, selectionX + selectionW, drawY + drawH - 2, context.applyAlpha(1728006730));
            }
        }
        if (richMetrics != null) {
            visibleRichText = this.buildRichSubstringText(this.value, richMetrics, this.viewOffset, visibleEnd);
            context.viewport().enableScissor(context.drawContext(), (float)(drawX + 1), (float)(drawY + 1), (float)(drawX + drawW - 1), (float)(drawY + drawH - 1));
        }
        try {
            context.drawContext().method_51439(context.textRenderer(), visibleRichText, textX, textY, context.applyAlpha(bodyColor), false);
        }
        finally {
            context.viewport().disableScissor(context.drawContext());
            throw var37;
        }
        /* goto L1882; */
        L1845: ;
        PackUiText.draw(context.drawContext(), context.textRenderer(), this.value.substring(this.viewOffset, visibleEnd), font, context.applyAlpha(bodyColor), textX, textY, false);
        L1882: ;
        caretX = textX + this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, this.viewOffset, this.cursor);
        if (this.focused && this.blinkVisible()) {
            context.drawContext().method_25294(caretX, drawY + contentInset, caretX + 1, drawY + drawH - contentInset, context.applyAlpha(-4627));
        }
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (!this.editable || button != 0 || !this.contains(mouseX, mouseY)) {
            return false;
        }
        this.focused = true;
        this.draggingSelection = true;
        int innerW = Math.max(1, Math.round(this.width) - context.theme().scale(this.horizontalPadding) * 2 - context.theme().scale(2));
        class_2960 font = this.resolvedFont(context);
        int bodyColor = context.theme().color(this.textTone);
        RichMetrics richMetrics = this.buildRichMetrics(this.value);
        if (this.multiline) {
            List<PackUiTextField.WrappedLine> wrappedLines = this.wrapValueLines(context.textRenderer(), font, bodyColor, innerW, richMetrics);
            int lineHeight = context.theme().fontHeight(this.textTone) + context.theme().scale(1);
            int visibleLineCount = Math.max(1, Math.max(1, Math.round(this.height) - context.theme().scale(6)) / lineHeight);
            this.ensureWrapViewLine(visibleLineCount, wrappedLines);
            int clickCursor = this.cursorFromMousePosition(context.textRenderer(), font, bodyColor, mouseX - (this.x + (float)context.theme().scale(this.horizontalPadding)), mouseY - (this.y + (float)context.theme().scale(3 + this.textYOffset)), wrappedLines, richMetrics);
        } else {
            this.ensureViewOffset(context.textRenderer(), font, bodyColor, innerW, richMetrics);
            int clickCursor = this.cursorFromMouseX(context.textRenderer(), font, bodyColor, mouseX - (this.x + (float)context.theme().scale(this.horizontalPadding)), richMetrics);
        }
        this.cursor = clickCursor;
        this.selectionAnchor = clickCursor;
        this.restartBlink();
        return true;
    }

    public boolean mouseReleased(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        this.draggingSelection = false;
        if (button == 0 && this.draggingSelection) {
            return this.focused;
        }
        return false;
    }

    public boolean mouseDragged(PackUiRenderContext context, float mouseX, float mouseY, int button, float deltaX, float deltaY) {
        if (!this.editable || !this.focused || !this.draggingSelection || button != 0) {
            return false;
        }
        class_2960 font = this.resolvedFont(context);
        int bodyColor = context.theme().color(this.textTone);
        int innerW = Math.max(1, Math.round(this.width) - context.theme().scale(this.horizontalPadding) * 2 - context.theme().scale(2));
        RichMetrics richMetrics = this.buildRichMetrics(this.value);
        if (this.multiline) {
            List<PackUiTextField.WrappedLine> wrappedLines = this.wrapValueLines(context.textRenderer(), font, bodyColor, innerW, richMetrics);
            int lineHeight = context.theme().fontHeight(this.textTone) + context.theme().scale(1);
            int visibleLineCount = Math.max(1, Math.max(1, Math.round(this.height) - context.theme().scale(6)) / lineHeight);
            this.ensureWrapViewLine(visibleLineCount, wrappedLines);
            this.cursor = this.cursorFromMousePosition(context.textRenderer(), font, bodyColor, mouseX - (this.x + (float)context.theme().scale(this.horizontalPadding)), mouseY - (this.y + (float)context.theme().scale(3 + this.textYOffset)), wrappedLines, richMetrics);
        } else {
            this.ensureViewOffset(context.textRenderer(), font, bodyColor, innerW, richMetrics);
            this.cursor = this.cursorFromMouseX(context.textRenderer(), font, bodyColor, mouseX - (this.x + (float)context.theme().scale(this.horizontalPadding)), richMetrics);
        }
        this.restartBlink();
        return true;
    }

    public boolean keyPressed(PackUiRenderContext context, int keyCode, int scanCode, int modifiers) {
        if (!this.focused || !this.editable) {
            return false;
        }
        boolean ctrl = modifiers & 2 != 0;
        boolean shift = modifiers & 1 != 0;
        switch (keyCode) {
            case 256::
                this.setFocused(false);
                return true;
            case 257::
            case 335::
                if (this.onSubmit != null) {
                    this.onSubmit.accept(this.value);
                }
                return true;
            case 65::
                if (ctrl) {
                    this.selectionAnchor = 0;
                    this.cursor = this.value.length();
                    this.restartBlink();
                    return true;
                }
            case 67::
                if (ctrl) {
                    this.copySelection();
                    return true;
                }
            case 88::
                if (ctrl) {
                    this.copySelection();
                    this.deleteSelection();
                    return true;
                }
            case 86::
                if (ctrl) {
                    this.pasteClipboard();
                    return true;
                }
            case 263::
                this.moveCursor(-1, shift);
                return true;
            case 262::
                this.moveCursor(1, shift);
                return true;
            case 265::
                if (this.multiline) {
                    this.moveCursorVertically(context, -1, shift);
                    return true;
                }
            case 264::
                if (this.multiline) {
                    this.moveCursorVertically(context, 1, shift);
                    return true;
                }
            case 268::
                this.setCursor(0, shift);
                return true;
            case 269::
                this.setCursor(this.value.length(), shift);
                return true;
            case 259::
                if (this.deleteSelection()) {
                    return true;
                }
                if (this.cursor > 0) {
                    this.replaceRange(this.cursor - 1, this.cursor, "");
                }
                return true;
            case 261::
                if (this.deleteSelection()) {
                    return true;
                }
                if (this.cursor < this.value.length()) {
                    this.replaceRange(this.cursor, this.cursor + 1, "");
                }
                return true;
            default:
                return false;
        }
    }

    public boolean charTyped(PackUiRenderContext context, char chr, int modifiers) {
        if (!this.focused || !this.editable || !this.isAllowedCharacter(chr)) {
            return false;
        }
        this.replaceSelection(Character.toString(chr));
        return true;
    }

    public boolean isFocused() {
        return this.focused;
    }

    public void setFocused(boolean focused) {
        this.focused = focused && this.editable;
        this.draggingSelection = false;
        this.restartBlink();
    }

    public PackUiTextField setSelectionEnd(int selectionEnd) {
        this.cursor = Math.max(0, Math.min(this.value.length(), selectionEnd));
        this.restartBlink();
        return this;
    }

    private class_2960 resolvedFont(PackUiRenderContext context) {
        return this.fontId != null ? this.fontId : context.theme().fontFor(PackUiTone.BODY);
    }

    private boolean blinkVisible() {
        return (System.currentTimeMillis() - this.blinkStartMs) / 530L % 2L == 0L;
    }

    private void restartBlink() {
        this.blinkStartMs = System.currentTimeMillis();
    }

    private void ensureSelectionOrder() {
        this.cursor = Math.max(0, Math.min(this.cursor, this.value.length()));
        this.selectionAnchor = Math.max(0, Math.min(this.selectionAnchor, this.value.length()));
    }

    private int visibleEndIndex(class_327 renderer, class_2960 font, int color, int availableWidth, PackUiTextField.RichMetrics richMetrics) {
        int end = this.viewOffset;
        while (end < this.value.length()) {
            if (this.renderSubstringWidth(renderer, font, color, this.value, richMetrics, this.viewOffset, end + 1) > availableWidth) {
            } else {
                end++;
            }
        }
        return end;
    }

    private void ensureViewOffset(class_327 renderer, class_2960 font, int color, int availableWidth, PackUiTextField.RichMetrics richMetrics) {
        this.ensureSelectionOrder();
        if (this.cursor < this.viewOffset) {
            this.viewOffset = this.cursor;
        }
        while (this.renderSubstringWidth(renderer, font, color, this.value, richMetrics, this.viewOffset, this.cursor) > availableWidth) {
            if (this.viewOffset >= this.cursor) break;
            this.viewOffset = this.viewOffset + 1;
        }
        while (this.viewOffset > 0) {
            if (this.renderSubstringWidth(renderer, font, color, this.value, richMetrics, this.viewOffset - 1, this.cursor) > availableWidth) {
            } else {
                this.viewOffset = this.viewOffset - 1;
            }
        }
        this.viewOffset = Math.max(0, Math.min(this.viewOffset, this.value.length()));
    }

    private int cursorFromMouseX(class_327 renderer, class_2960 font, int color, float mouseInnerX, PackUiTextField.RichMetrics richMetrics) {
        float clampedX = Math.max(0f, mouseInnerX);
        int best = this.viewOffset;
        int bestDistance = 2147483647;
        for (int i = this.viewOffset; i <= this.value.length(); i++) {
            int charX = this.renderSubstringWidth(renderer, font, color, this.value, richMetrics, this.viewOffset, i);
            int distance = Math.abs(Math.round(clampedX) - charX);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = i;
            } else {
                if ((float)charX <= clampedX) { /* goto @101; */ }
                /* goto @107; */
            }
        }
        return best;
    }

    private List<String> wrapPlainText(class_327 renderer, class_2960 font, int color, String text, int availableWidth) {
        if (text == null || text.isEmpty()) {
            return List.of("");
        }
        List<String> wrapped = new ArrayList();
        var var7 = this.wrapLinesForText(renderer, font, color, text, availableWidth, null).iterator();
        while (var7.hasNext()) {
            WrappedLine line = (PackUiTextField.WrappedLine)var7.next();
            wrapped.add(text.substring(line.start(), line.renderEnd()));
        }
        return wrapped.isEmpty() ? List.of("") : wrapped;
    }

    private PackUiTextField.RichMetrics buildRichMetrics(String sourceValue) {
        if (this.displayTextProvider == null || sourceValue == null || sourceValue.isEmpty()) {
            return null;
        }
        class_2561 richDisplay = (class_2561)this.displayTextProvider.apply(sourceValue);
        if (richDisplay == null) {
            return null;
        }
        String richText = richDisplay.getString();
        if (!Objects.equals(richText, sourceValue)) {
            return null;
        }
        List<class_2583> rawStyles = new ArrayList(richText.length());
        richDisplay.method_27658(PackUiTextField::lambda$buildRichMetrics$2 /* captured: rawStyles */, class_2583.field_24360);
        List<class_2583> charStyles = new ArrayList(rawStyles);
        if (charStyles.isEmpty()) {
            return null;
        }
        while (charStyles.size() < richText.length()) {
            charStyles.add(class_2583.field_24360);
        }
        if (charStyles.size() > richText.length()) {
            charStyles = new ArrayList(charStyles.subList(0, richText.length()));
        }
        return new PackUiTextField.RichMetrics(richText, charStyles);
    }

    private class_2561 buildRichSubstringText(String sourceText, PackUiTextField.RichMetrics richMetrics, int start, int end) {
        int safeStart = Math.max(0, Math.min(start, sourceText.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, sourceText.length()));
        if (richMetrics == null || safeStart >= safeEnd) {
            return class_2561.method_43470(sourceText.substring(safeStart, safeEnd));
        }
        class_5250 out = class_2561.method_43473();
        StringBuilder segment = new StringBuilder();
        class_2583 currentStyle = null;
        for (int i = safeStart; i < safeEnd; i++) {
            class_2583 style = (class_2583)richMetrics.styles().get(Math.min(i, richMetrics.styles().size() - 1));
            if (currentStyle == null) {
                currentStyle = style;
            } else {
                if (!currentStyle.equals(style)) {
                    out.method_10852(class_2561.method_43470(segment.toString()).method_10862(currentStyle));
                    segment.setLength(0);
                    currentStyle = style;
                }
            }
            segment.append(sourceText.charAt(i));
        }
        if (segment.isEmpty()) { /* goto L218; */ }
        out.method_10852(class_2561.method_43470(segment.toString()).method_10862(currentStyle == null ? class_2583.field_24360 : currentStyle));
        return out;
    }

    private int renderSubstringWidth(class_327 renderer, class_2960 font, int color, String sourceText, PackUiTextField.RichMetrics richMetrics, int start, int end) {
        int safeStart = Math.max(0, Math.min(start, sourceText.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, sourceText.length()));
        if (safeStart >= safeEnd) {
            return 0;
        }
        if (richMetrics == null) {
            return this.substringWidth(renderer, font, color, sourceText.substring(safeStart, safeEnd));
        }
        return renderer.method_27525(this.buildRichSubstringText(sourceText, richMetrics, safeStart, safeEnd));
    }

    private List<PackUiTextField.WrappedLine> wrapValueLines(class_327 renderer, class_2960 font, int color, int availableWidth, PackUiTextField.RichMetrics richMetrics) {
        return this.wrapLinesForText(renderer, font, color, this.value, availableWidth, richMetrics);
    }

    private List<PackUiTextField.WrappedLine> wrapLinesForText(class_327 renderer, class_2960 font, int color, String text, int availableWidth, PackUiTextField.RichMetrics richMetrics) {
        List<PackUiTextField.WrappedLine> lines = new ArrayList();
        String safeText = text == null ? "" : text;
        if (safeText.isEmpty()) {
            lines.add(new PackUiTextField.WrappedLine(0, 0, 0));
            return lines;
        }
        int start = 0;
        while (start < safeText.length()) {
            int end = start;
            int lastBreak = -1;
            while (end < safeText.length()) {
                char ch = safeText.charAt(end);
                if (!Character.isWhitespace(ch)) continue;
                lastBreak = end + 1;
                if (this.renderSubstringWidth(renderer, font, color, safeText, richMetrics, start, end + 1) > availableWidth) {
                    if (end == start) {
                        end++;
                    } else {
                        if (!lastBreak > start) continue;
                        end = lastBreak;
                    }
                } else {
                    end++;
                }
            }
            if (!end <= start) continue;
            end = Math.min(start + 1, safeText.length());
            if (!end > safeText.length()) continue;
            end = safeText.length();
            for (renderEnd = end; renderEnd > start; renderEnd--) {
                if (!Character.isWhitespace(safeText.charAt(renderEnd - 1))) break;
            }
            if (!renderEnd < start) continue;
            renderEnd = start;
            lines.add(new PackUiTextField.WrappedLine(start, end, renderEnd));
            start = end;
        }
        return lines.isEmpty() ? List.of(new PackUiTextField.WrappedLine(0, 0, 0)) : lines;
    }

    private void ensureWrapViewLine(int visibleLineCount, List<PackUiTextField.WrappedLine> wrappedLines) {
        if (wrappedLines.isEmpty()) {
            this.wrapViewLine = 0;
            return;
        }
        int cursorLine = this.lineIndexForCursor(wrappedLines, this.cursor);
        int maxStart = Math.max(0, wrappedLines.size() - visibleLineCount);
        if (cursorLine < this.wrapViewLine) {
            this.wrapViewLine = cursorLine;
        }
        if (cursorLine >= this.wrapViewLine + visibleLineCount) {
            this.wrapViewLine = cursorLine - visibleLineCount + 1;
        }
        this.wrapViewLine = Math.max(0, Math.min(this.wrapViewLine, maxStart));
    }

    private int lineIndexForCursor(List<PackUiTextField.WrappedLine> wrappedLines, int index) {
        if (wrappedLines.isEmpty()) {
            return 0;
        }
        int clamped = Math.max(0, Math.min(index, this.value.length()));
        for (int i = 0; i < wrappedLines.size(); i++) {
            WrappedLine line = (PackUiTextField.WrappedLine)wrappedLines.get(i);
            if (!clamped < line.end()) continue;
            return i;
            if (clamped == line.end()) {
                if (i != wrappedLines.size() - 1) continue;
                return i;
                if (clamped != line.start()) continue;
                return i;
            }
        }
        return wrappedLines.size() - 1;
    }

    private int cursorFromMousePosition(class_327 renderer, class_2960 font, int color, float mouseInnerX, float mouseInnerY, List<PackUiTextField.WrappedLine> wrappedLines, PackUiTextField.RichMetrics richMetrics) {
        if (wrappedLines.isEmpty()) {
            return 0;
        }
        PackUiTheme theme = new PackUiTheme();
        int lineHeight = theme.lineHeight(this.textTone, 1);
        int lineIndex = this.wrapViewLine + Math.max(0, Math.round((mouseInnerY - 1f) / (float)lineHeight));
        lineIndex = Math.max(0, Math.min(lineIndex, wrappedLines.size() - 1));
        WrappedLine line = (PackUiTextField.WrappedLine)wrappedLines.get(lineIndex);
        return this.cursorFromMouseXForLine(renderer, font, color, mouseInnerX, line, richMetrics);
    }

    private int cursorFromMouseXForLine(class_327 renderer, class_2960 font, int color, float mouseInnerX, PackUiTextField.WrappedLine line, PackUiTextField.RichMetrics richMetrics) {
        float clampedX = Math.max(0f, mouseInnerX);
        int best = line.start();
        int bestDistance = 2147483647;
        int visibleEnd = Math.max(line.start(), line.end());
        for (int i = line.start(); i <= visibleEnd; i++) {
            int charX = this.renderSubstringWidth(renderer, font, color, this.value, richMetrics, line.start(), i);
            int distance = Math.abs(Math.round(clampedX) - charX);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = i;
            } else {
                if ((float)charX <= clampedX) { /* goto @114; */ }
                /* goto @120; */
            }
        }
        return Math.max(line.start(), Math.min(best, line.end()));
    }

    private void moveCursorVertically(PackUiRenderContext context, int direction, boolean keepSelection) {
        class_2960 font = this.resolvedFont(context);
        int bodyColor = context.theme().color(this.textTone);
        int innerW = Math.max(1, Math.round(this.width) - context.theme().scale(this.horizontalPadding) * 2 - context.theme().scale(2));
        RichMetrics richMetrics = this.buildRichMetrics(this.value);
        List<PackUiTextField.WrappedLine> wrappedLines = this.wrapValueLines(context.textRenderer(), font, bodyColor, innerW, richMetrics);
        if (wrappedLines.isEmpty()) {
            return;
        }
        int currentLineIndex = this.lineIndexForCursor(wrappedLines, this.cursor);
        int targetLineIndex = Math.max(0, Math.min(wrappedLines.size() - 1, currentLineIndex + direction));
        if (targetLineIndex == currentLineIndex) {
            return;
        }
        WrappedLine currentLine = (PackUiTextField.WrappedLine)wrappedLines.get(currentLineIndex);
        int visibleCursor = Math.min(this.cursor, currentLine.renderEnd());
        int cursorX = this.renderSubstringWidth(context.textRenderer(), font, bodyColor, this.value, richMetrics, currentLine.start(), visibleCursor);
        WrappedLine targetLine = (PackUiTextField.WrappedLine)wrappedLines.get(targetLineIndex);
        int targetCursor = this.cursorFromMouseXForLine(context.textRenderer(), font, bodyColor, (float)cursorX, targetLine, richMetrics);
        this.setCursor(targetCursor, keepSelection);
    }

    private void moveCursor(int delta, boolean keepSelection) {
        this.setCursor(Math.max(0, Math.min(this.value.length(), this.cursor + delta)), keepSelection);
    }

    private void setCursor(int nextCursor, boolean keepSelection) {
        this.cursor = Math.max(0, Math.min(this.value.length(), nextCursor));
        if (!keepSelection) {
            this.selectionAnchor = this.cursor;
        }
        this.restartBlink();
    }

    private boolean hasSelection() {
        return this.cursor != this.selectionAnchor;
    }

    private void copySelection() {
        if (!this.hasSelection()) {
            return;
        }
        int start = Math.min(this.cursor, this.selectionAnchor);
        int end = Math.max(this.cursor, this.selectionAnchor);
        class_310.method_1551().field_1774.method_1455(this.value.substring(start, end));
    }

    private void pasteClipboard() {
        String clipboard = class_310.method_1551().field_1774.method_1460();
        if (clipboard == null || clipboard.isEmpty()) {
            return;
        }
        this.replaceSelection(this.sanitize(clipboard));
    }

    private boolean deleteSelection() {
        if (!this.hasSelection()) {
            return false;
        }
        int start = Math.min(this.cursor, this.selectionAnchor);
        int end = Math.max(this.cursor, this.selectionAnchor);
        this.replaceRange(start, end, "");
        return true;
    }

    private void replaceSelection(String replacement) {
        int start = Math.min(this.cursor, this.selectionAnchor);
        int end = Math.max(this.cursor, this.selectionAnchor);
        this.replaceRange(start, end, replacement);
    }

    private void replaceRange(int start, int end, String replacement) {
        int safeStart = Math.max(0, Math.min(start, this.value.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, this.value.length()));
        String sanitizedReplacement = this.sanitize(replacement);
        String next = this.value.substring(0, safeStart) + sanitizedReplacement + this.value.substring(safeEnd);
        if (next.length() > this.maxLength) {
            next = next.substring(0, this.maxLength);
        }
        if (!this.filter.test(next)) {
            return;
        }
        this.value = next;
        this.cursor = Math.min(next.length(), safeStart + sanitizedReplacement.length());
        this.selectionAnchor = this.cursor;
        this.restartBlink();
        if (this.onChange != null) {
            this.onChange.accept(this.value);
        }
    }

    private String sanitize(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            if (sb.length() >= this.maxLength) break;
            char chr = input.charAt(i);
            if (!this.isAllowedCharacter(chr)) {
            } else {
                sb.append(chr);
            }
        }
        next = sb.toString();
        return this.filter.test(next) ? next : this.value;
    }

    private boolean isAllowedCharacter(char chr) {
        return chr >= 32 && chr != 127 && chr != 10 && chr != 13;
    }

    private int substringWidth(class_327 renderer, class_2960 font, int color, String text) {
        return PackUiText.width(renderer, text, font, color);
    }
}
