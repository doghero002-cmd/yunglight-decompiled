/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiViewport;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUiRenderContext {
    private final class_332 drawContext;
    private final class_327 textRenderer;
    private final PackUiViewport viewport;
    private final PackUiTheme theme;
    private final float mouseX;
    private final float mouseY;
    private final float delta;
    private final float alpha;

    public PackUiRenderContext(class_332 drawContext, class_327 textRenderer, PackUiViewport viewport, PackUiTheme theme, float mouseX, float mouseY, float delta) {
        this(drawContext, textRenderer, viewport, theme, mouseX, mouseY, delta, 1f);
    }

    public PackUiRenderContext(class_332 drawContext, class_327 textRenderer, PackUiViewport viewport, PackUiTheme theme, float mouseX, float mouseY, float delta, float alpha) {
        this.drawContext = drawContext;
        this.textRenderer = textRenderer;
        this.viewport = viewport;
        this.theme = theme;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        this.delta = delta;
        this.alpha = Math.max(0f, Math.min(1f, alpha));
    }

    public class_332 drawContext() {
        return this.drawContext;
    }

    public class_327 textRenderer() {
        return this.textRenderer;
    }

    public PackUiViewport viewport() {
        return this.viewport;
    }

    public PackUiTheme theme() {
        return this.theme;
    }

    public float mouseX() {
        return this.mouseX;
    }

    public float mouseY() {
        return this.mouseY;
    }

    public float delta() {
        return this.delta;
    }

    public float alpha() {
        return this.alpha;
    }

    public PackUiRenderContext withAlpha(float alpha) {
        return new PackUiRenderContext(this.drawContext, this.textRenderer, this.viewport, this.theme, this.mouseX, this.mouseY, this.delta, alpha);
    }

    public int applyAlpha(int color) {
        return PackUiRenderContext.applyAlpha(color, this.alpha);
    }

    public void drawTexturedQuad(class_2960 textureId, int x1, int y1, int x2, int y2) {
        if (this.drawContext == null || textureId == null) {
            return;
        }
        this.drawContext.method_70845(textureId, x1, y1, x2, y2, 0f, 1f, 0f, 1f);
        if (this.alpha < 0.999f) {
            int overlayAlpha = Math.max(0, Math.min(255, Math.round((1f - this.alpha) * 255f)));
            this.drawContext.method_25294(x1, y1, x2, y2, overlayAlpha << 24 | 460553);
        }
    }

    public static int applyAlpha(int color, float alpha) {
        int a = color >>> 24 & 255;
        int scaled = Math.max(0, Math.min(255, Math.round((float)a * Math.max(0f, Math.min(1f, alpha)))));
        return scaled << 24 | color & 16777215;
    }
}
