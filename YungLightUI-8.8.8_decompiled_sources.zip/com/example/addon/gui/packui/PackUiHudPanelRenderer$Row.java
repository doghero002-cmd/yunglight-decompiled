/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiHudPanelRenderer;
import com.example.addon.gui.packui.PackUiTone;
import net.minecraft.class_2960;

public static final record PackUiHudPanelRenderer.Row {
    private final String text;
    private final class_2960 font;
    private final int color;

    public PackUiHudPanelRenderer.Row(String text, class_2960 font, int color) {
        this.text = text;
        this.font = font;
        this.color = color;
    }

    public static PackUiHudPanelRenderer.Row body(String text, int color) {
        return new PackUiHudPanelRenderer.Row(text, PackUiHudPanelRenderer.THEME.fontFor(PackUiTone.BODY), color);
    }

    public static PackUiHudPanelRenderer.Row muted(String text) {
        return new PackUiHudPanelRenderer.Row(text, PackUiHudPanelRenderer.THEME.fontFor(PackUiTone.MUTED), PackUiHudPanelRenderer.THEME.color(PackUiTone.MUTED));
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String text() {
        return this.text;
    }

    public class_2960 font() {
        return this.font;
    }

    public int color() {
        return this.color;
    }
}
