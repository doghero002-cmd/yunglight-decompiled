/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import java.nio.ByteBuffer;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import org.lwjgl.system.MemoryUtil;

final class PackUiTextTexture
extends class_1044 {
    PackUiTextTexture(int width, int height) {
        this.field_56974 = RenderSystem.getDevice().createTexture("", 15, TextureFormat.RED8, width, height, 1, 1);
        this.field_63613 = RenderSystem.getSamplerCache().method_75293(AddressMode.REPEAT, AddressMode.REPEAT, FilterMode.LINEAR, FilterMode.LINEAR, false);
        this.field_60597 = RenderSystem.getDevice().createTextureView(this.field_56974);
    }

    void upload(ByteBuffer buffer) {
        class_1011 image = new class_1011(class_1011.class_1012.field_4998, this.method_68004().getWidth(0), this.method_68004().getHeight(0), false);
        buffer.rewind();
        MemoryUtil.memCopy(MemoryUtil.memAddress(buffer), image.method_67769(), (long)buffer.remaining());
        RenderSystem.getDevice().createCommandEncoder().writeToTexture(this.field_56974, image);
        image.close();
    }
}
