/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiCompactRow
extends PackUiContainer {
    private PackUiInsets padding = PackUiInsets.NONE;
    private int gap = 0;
    private boolean underlineOnHover = false;
    private int underlineColor = -50373;
    private float occupiedWidth = 0f;

    public PackUiCompactRow setPadding(PackUiInsets padding) {
        this.padding = padding == null ? PackUiInsets.NONE : padding;
        return this;
    }

    public PackUiCompactRow setGap(int gap) {
        this.gap = Math.max(0, gap);
        return this;
    }

    public PackUiCompactRow setUnderlineOnHover(boolean underlineOnHover) {
        this.underlineOnHover = underlineOnHover;
        return this;
    }

    public PackUiCompactRow setUnderlineColor(int underlineColor) {
        this.underlineColor = underlineColor;
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float total = (float)scaledPadding.horizontal();
        int visibleCount = 0;
        var var6 = this.children.iterator();
        while (var6.hasNext()) {
            PackUiNode child = (PackUiNode)var6.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            total = total + child.preferredWidth(context);
            visibleCount++;
        }
        if (visibleCount > 1) {
            total = total + (float)((visibleCount - 1) * scaledGap);
        }
        return total;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        float tallest = 0f;
        var var5 = this.children.iterator();
        while (var5.hasNext()) {
            PackUiNode child = (PackUiNode)var5.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            tallest = Math.max(tallest, child.preferredHeight(context, availableWidth));
        }
        return (float)scaledPadding.top() + tallest + (float)scaledPadding.bottom();
    }

    protected void layoutChildren(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float innerX = this.x + (float)scaledPadding.left();
        float innerY = this.y + (float)scaledPadding.top();
        float innerWidth = Math.max(0f, this.width - (float)scaledPadding.horizontal());
        float innerHeight = Math.max(0f, this.height - (float)scaledPadding.vertical());
        float fixedWidth = 0f;
        int growCount = 0;
        int visibleCount = 0;
        float totalGap = this.children.iterator();
        while (totalGap.hasNext()) {
            PackUiNode child = (PackUiNode)totalGap.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            visibleCount++;
            if (child.growX()) {
                growCount++;
            } else {
                fixedWidth = fixedWidth + child.preferredWidth(context);
            }
        }
        totalGap = (float)(Math.max(0, visibleCount - 1) * scaledGap);
        freeWidth = Math.max(0f, innerWidth - fixedWidth - totalGap);
        float growWidth = growCount > 0 ? freeWidth / (float)growCount : 0f;
        float cursorX = innerX;
        this.occupiedWidth = 0f;
        var var15 = this.children.iterator();
        while (var15.hasNext()) {
            PackUiNode child = (PackUiNode)var15.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            float childWidth = child.growX() ? growWidth : child.preferredWidth(context);
            float childHeight = Math.min(innerHeight, child.preferredHeight(context, childWidth));
            float childY = innerY + Math.max(0f, (innerHeight - childHeight) / 2f);
            child.setBounds(cursorX, childY, childWidth, childHeight);
            cursorX = cursorX + (childWidth + (float)scaledGap);
        }
        this.occupiedWidth = Math.max(0f, cursorX - innerX - (float)(visibleCount > 0 ? scaledGap : 0));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        super.render(context);
        if (this.underlineOnHover) {
            float hover = this.updateHover(this.contains(context.mouseX(), context.mouseY()), context.delta());
            if (hover <= 0f || context.drawContext() == null) {
                return;
            }
            PackUiInsets scaledPadding = context.theme().scale(this.padding);
            int drawX = Math.round(this.x + (float)scaledPadding.left());
            int drawY = Math.round(this.y + this.height - (float)context.theme().scale(1));
            float underlineAreaWidth = Math.max(this.occupiedWidth, this.width - (float)scaledPadding.horizontal());
            int underlineWidth = Math.max(1, Math.round(underlineAreaWidth * hover));
            int underlineX = drawX + Math.max(0, Math.round((underlineAreaWidth - (float)underlineWidth) / 2f));
            context.drawContext().method_25294(underlineX, drawY, underlineX + underlineWidth, drawY + context.theme().scale(1), this.underlineColor);
        }
    }
}
