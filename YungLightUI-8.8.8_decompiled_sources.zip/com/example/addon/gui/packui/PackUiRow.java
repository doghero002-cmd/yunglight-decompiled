/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiRow
extends PackUiContainer {
    private PackUiInsets padding = PackUiInsets.NONE;
    private int gap = 0;

    public PackUiRow setPadding(PackUiInsets padding) {
        this.padding = padding == null ? PackUiInsets.NONE : padding;
        return this;
    }

    public PackUiRow setGap(int gap) {
        this.gap = Math.max(0, gap);
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        float tallest = 0f;
        float innerWidth = Math.max(0f, availableWidth - (float)scaledPadding.horizontal());
        var var6 = this.children.iterator();
        while (var6.hasNext()) {
            PackUiNode child = (PackUiNode)var6.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            tallest = Math.max(tallest, child.preferredHeight(context, innerWidth));
        }
        return (float)scaledPadding.top() + tallest + (float)scaledPadding.bottom();
    }

    protected void layoutChildren(PackUiRenderContext context) {
        PackUiInsets scaledPadding = context.theme().scale(this.padding);
        int scaledGap = context.theme().scale(this.gap);
        float innerX = this.x + (float)scaledPadding.left();
        float innerY = this.y + (float)scaledPadding.top();
        float innerWidth = Math.max(0f, this.width - (float)scaledPadding.horizontal());
        float innerHeight = Math.max(0f, this.height - (float)scaledPadding.vertical());
        float fixedWidth = 0f;
        int growCount = 0;
        int visibleCount = 0;
        float totalGap = this.children.iterator();
        while (totalGap.hasNext()) {
            PackUiNode child = (PackUiNode)totalGap.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            visibleCount++;
            if (child.growX()) {
                growCount++;
            } else {
                fixedWidth = fixedWidth + child.preferredWidth(context);
            }
        }
        totalGap = (float)(Math.max(0, visibleCount - 1) * scaledGap);
        freeWidth = Math.max(0f, innerWidth - fixedWidth - totalGap);
        float growWidth = growCount > 0 ? freeWidth / (float)growCount : 0f;
        float cursorX = innerX;
        var var15 = this.children.iterator();
        while (var15.hasNext()) {
            PackUiNode child = (PackUiNode)var15.next();
            if (child == null) continue;
            while (!child.isVisible()) {
            }
            float childWidth = child.growX() ? growWidth : child.preferredWidth(context);
            float childHeight = Math.max(innerHeight, child.preferredHeight(context, childWidth));
            child.setBounds(cursorX, innerY, childWidth, childHeight);
            cursorX = cursorX + (childWidth + (float)scaledGap);
        }
    }
}
