/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiScrollViewport;
import net.minecraft.class_327;
import net.minecraft.class_332;

@FunctionalInterface
public static interface PackUiScrollViewport.RowRenderer {
    public void render(class_332 var1, class_327 var2, PackUiScrollViewport.ScrollRow var3, int var4, int var5, int var6, int var7, int var8, int var9);
}
