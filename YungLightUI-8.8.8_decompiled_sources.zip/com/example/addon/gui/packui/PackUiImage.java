/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import net.minecraft.class_2960;

public class PackUiImage
extends PackUiNode {
    private final class_2960 textureId;

    public PackUiImage(class_2960 textureId, float width, float height) {
        this.textureId = textureId;
        this.width = Math.max(0f, width);
        this.height = Math.max(0f, height);
    }

    public float preferredWidth(PackUiRenderContext context) {
        return this.width;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return this.height;
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible || this.textureId == null || context.drawContext() == null) {
            return;
        }
        context.drawTexturedQuad(this.textureId, Math.round(this.x), Math.round(this.y), Math.round(this.x + this.width), Math.round(this.y + this.height));
    }
}
