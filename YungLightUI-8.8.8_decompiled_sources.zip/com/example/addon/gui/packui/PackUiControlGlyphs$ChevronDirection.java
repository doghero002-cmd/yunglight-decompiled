/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static enum PackUiControlGlyphs.ChevronDirection {
    public static final PackUiControlGlyphs.ChevronDirection RIGHT = new PackUiControlGlyphs.ChevronDirection("RIGHT", 0);
    public static final PackUiControlGlyphs.ChevronDirection DOWN = new PackUiControlGlyphs.ChevronDirection("DOWN", 1);
    public static final PackUiControlGlyphs.ChevronDirection UP = new PackUiControlGlyphs.ChevronDirection("UP", 2);
    private static final /* synthetic */ PackUiControlGlyphs.ChevronDirection[] $VALUES;

    public static PackUiControlGlyphs.ChevronDirection[] values() {
        return (PackUiControlGlyphs.ChevronDirection[])$VALUES.clone();
    }

    public static PackUiControlGlyphs.ChevronDirection valueOf(String name) {
        return (PackUiControlGlyphs.ChevronDirection)Enum.valueOf(PackUiControlGlyphs.ChevronDirection.class, name);
    }

    private PackUiControlGlyphs.ChevronDirection() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUiControlGlyphs.ChevronDirection.$values();
    }
}
