/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiColumn;
import com.example.addon.gui.packui.PackUiLabel;
import com.example.addon.gui.packui.PackUiRow;
import com.example.addon.gui.packui.PackUiSpacer;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.gui.packui.PackUiWindowNode;

public final class PackUiKeybindBlueprint {
    private PackUiKeybindBlueprint() {
    }

    public static PackUiWindowNode buildPreview() {
        PackUiWindowNode window = new PackUiWindowNode("Settings");
        PackUiColumn content = window.content();
        content.add(new PackUiLabel("In-game only (no GUI open)", PackUiTone.MUTED));
        content.add(new PackUiSpacer(0f, 4f));
        PackUiKeybindBlueprint.addRow(content, "Load GUI", "None");
        PackUiKeybindBlueprint.addRow(content, "Flush Queue", "None");
        PackUiKeybindBlueprint.addRow(content, "Clear Queue", "None");
        PackUiKeybindBlueprint.addRow(content, "Toggle Logger", "None");
        PackUiKeybindBlueprint.addRow(content, "Toggle Send", "None");
        PackUiKeybindBlueprint.addRow(content, "Toggle Delay", "None");
        return window;
    }

    private static void addRow(PackUiColumn content, String label, String binding) {
        PackUiRow row = new PackUiRow().setGap(6);
        row.add(new PackUiLabel(label, PackUiTone.BODY).setGrowX(true));
        row.add(new PackUiButton(binding, PackUiButton.Variant.SECONDARY, PackUiKeybindBlueprint::lambda$addRow$0));
        row.add(new PackUiButton("X", PackUiButton.Variant.DANGER, PackUiKeybindBlueprint::lambda$addRow$1));
        content.add(row);
    }
}
