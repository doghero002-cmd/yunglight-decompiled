/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButtonFeedback;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import net.minecraft.class_2960;

public class PackUiButton
extends PackUiNode {
    private String text;
    private PackUiButton.Variant variant;
    private Runnable onPress;
    private float minWidth = 26f;
    private float maxWidth = 340282350000000000000000000000000000000f;
    private float preferredWidth = -1f;
    private int horizontalPadding = 8;
    private int fixedHeight = -1;
    private int textYOffset = 0;
    private class_2960 leadingIcon;
    private int iconSize = 10;
    private int iconGap = 4;
    private PackUiButton.ContentAlignment contentAlignment = PackUiButton.ContentAlignment.CENTER;
    private PackUiTone tone = PackUiTone.BODY;

    private class_2960 resolvedFont(PackUiTheme theme, int height) {
        return theme.fontFor(this.tone);
    }

    private PackUiButtonFeedback feedbackState() {
        return PackUiButtonFeedback.forKey("button:" + Math.round(this.x) + ":" + Math.round(this.y) + ":" + Math.round(this.width) + ":" + Math.round(this.height) + ":" + String.valueOf(this.variant) + ":" + String.valueOf(this.tone) + ":" + String.valueOf(this.contentAlignment) + ":" + this.leadingIcon == null ? "none" : this.leadingIcon.toString());
    }

    public PackUiButton(String text, PackUiButton.Variant variant, Runnable onPress) {
        this.text = text == null ? "" : text;
        this.variant = variant == null ? PackUiButton.Variant.SECONDARY : variant;
        this.onPress = onPress;
        this.height = 16f;
    }

    public PackUiButton setText(String text) {
        this.text = text == null ? "" : text;
        return this;
    }

    public PackUiButton setVariant(PackUiButton.Variant variant) {
        this.variant = variant == null ? PackUiButton.Variant.SECONDARY : variant;
        return this;
    }

    public PackUiButton setOnPress(Runnable onPress) {
        this.onPress = onPress;
        return this;
    }

    public PackUiButton setMinWidth(float minWidth) {
        this.minWidth = Math.max(0f, minWidth);
        return this;
    }

    public PackUiButton setMaxWidth(float maxWidth) {
        this.maxWidth = Math.max(this.minWidth, maxWidth);
        return this;
    }

    public PackUiButton setPreferredWidth(float preferredWidth) {
        this.preferredWidth = preferredWidth;
        return this;
    }

    public PackUiButton setHorizontalPadding(int horizontalPadding) {
        this.horizontalPadding = Math.max(0, horizontalPadding);
        return this;
    }

    public PackUiButton setButtonHeight(int fixedHeight) {
        this.fixedHeight = Math.max(1, fixedHeight);
        return this;
    }

    public PackUiButton setTextYOffset(int textYOffset) {
        this.textYOffset = textYOffset;
        return this;
    }

    public PackUiButton setLeadingIcon(class_2960 leadingIcon) {
        this.leadingIcon = leadingIcon;
        return this;
    }

    public PackUiButton setIconSize(int iconSize) {
        this.iconSize = Math.max(1, iconSize);
        return this;
    }

    public PackUiButton setIconGap(int iconGap) {
        this.iconGap = Math.max(0, iconGap);
        return this;
    }

    public PackUiButton setContentAlignment(PackUiButton.ContentAlignment contentAlignment) {
        this.contentAlignment = contentAlignment == null ? PackUiButton.ContentAlignment.CENTER : contentAlignment;
        return this;
    }

    public PackUiButton setTone(PackUiTone tone) {
        this.tone = tone == null ? PackUiTone.BODY : tone;
        return this;
    }

    public PackUiButton setGrowX(boolean growX) {
        super.setGrowX(growX);
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        int measureHeight = this.fixedHeight > 0 ? this.fixedHeight : context.theme().buttonHeight();
        class_2960 font = this.resolvedFont(context.theme(), measureHeight);
        int scaledHorizontalPadding = context.theme().scale(this.horizontalPadding);
        int scaledIconSize = context.theme().scale(this.iconSize);
        int scaledIconGap = context.theme().scale(this.iconGap);
        float fittedWidth = PackUiSizing.fitTextWidth(context.textRenderer(), this.text, font, context.theme().color(PackUiTone.BODY), (float)scaledHorizontalPadding, this.minWidth, this.maxWidth);
        if (this.leadingIcon != null) {
            fittedWidth = fittedWidth + (float)(scaledIconSize + scaledIconGap);
        }
        if (this.preferredWidth > 0f) {
            return PackUiSizing.clamp(Math.max(this.preferredWidth, fittedWidth), this.minWidth, this.maxWidth);
        }
        return PackUiSizing.clamp(fittedWidth, this.minWidth, this.maxWidth);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        int resolvedFixedHeight = this.fixedHeight > 0 ? this.fixedHeight : context.theme().buttonHeight();
        int contentHeight = context.theme().fontHeight(this.tone) + context.theme().scale(4);
        return (float)Math.max(12, Math.max(resolvedFixedHeight, contentHeight));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        class_2960 font = this.resolvedFont(context.theme(), drawH);
        boolean hovered = this.enabled && this.contains(context.mouseX(), context.mouseY());
        PackUiButtonFeedback feedback = this.feedbackState();
        float hover = feedback.update(hovered, this.enabled && PackUiButtonFeedback.isPrimaryPointerDown(), context.mouseX() - this.x, context.mouseY() - this.y, this.width, this.height);
        float clickGlow = feedback.clickGlowProgress();
        int scaledHorizontalPadding = context.theme().scale(this.horizontalPadding);
        int scaledIconSize = context.theme().scale(this.iconSize);
        int scaledIconGap = context.theme().scale(this.iconGap);
        int borderThickness = Math.max(1, context.theme().scale(1));
        int availableTextWidth = Math.max(1, drawW - scaledHorizontalPadding * 2 - (this.leadingIcon != null ? scaledIconSize + scaledIconGap : 0));
        String displayText = PackUiText.trimToWidth(context.textRenderer(), this.text, availableTextWidth, font, -2828);
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int bg = -1366352092;
                break;
            case 1::
                bg = -1978528239;
                break;
            case 2::
                bg = 1074924815;
                break;
            case 3::
                bg = -1725756143;
                break;
            case 4::
                bg = -2012207590;
                break;
        }
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int border = -30841;
                break;
            case 1::
            case 2::
                border = -7392975;
                break;
            case 3::
                border = -4896696;
                break;
            case 4::
                border = -8269408;
                break;
        }
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int borderGlow = -23388;
                break;
            case 1::
            case 2::
                borderGlow = -39836;
                break;
            case 3::
                borderGlow = -28528;
                break;
            case 4::
                borderGlow = -5575744;
                break;
        }
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int textColor = -2828;
                break;
            case 1::
            case 2::
                textColor = -991522;
                break;
            case 3::
                textColor = -42406;
                break;
            case 4::
                textColor = -4656181;
                break;
        }
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int rippleRing = -19790;
                break;
            case 1::
            case 2::
                rippleRing = -36752;
                break;
            case 3::
                rippleRing = -30070;
                break;
            case 4::
                rippleRing = -6363465;
                break;
        }
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                int rippleFill = -7711;
                break;
            case 1::
            case 2::
                rippleFill = -13622;
                break;
            case 3::
                rippleFill = -11823;
                break;
            case 4::
                rippleFill = -2623518;
                break;
        }
        float hoverVisual = Math.max(hover * 0.9f, clickGlow * 0.55f);
        border = PackUiSizing.lerpColor(border, borderGlow, Math.min(1f, hover * 0.35f + clickGlow * 0.85f));
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(bg));
        if (hoverVisual <= 0f) { /* goto L920; */ }
        switch (this.variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 4::
                int hoverBase = 3332202;
                break;
            case 3::
                hoverBase = 16726843;
                break;
            case 0::
                hoverBase = 16735838;
                break;
            case 1::
            case 2::
                hoverBase = 16726843;
                break;
        }
        int hoverTint = (int)Math.min(42f, hover * 24f + clickGlow * 12f) << 24 | hoverBase;
        context.drawContext().method_25294(drawX + borderThickness, drawY + borderThickness, drawX + drawW - borderThickness, drawY + drawH - borderThickness, context.applyAlpha(hoverTint));
        L920: ;
        if (clickGlow > 0f) {
            pressGlow = (int)(clickGlow * 14f) << 24 | rippleFill & 16777215;
            context.drawContext().method_25294(drawX + borderThickness, drawY + borderThickness, drawX + drawW - borderThickness, drawY + drawH - borderThickness, context.applyAlpha(pressGlow));
        }
        feedback.render(context.drawContext(), drawX + borderThickness, drawY + borderThickness, Math.max(0, drawW - borderThickness * 2), Math.max(0, drawH - borderThickness * 2), rippleRing, rippleFill, context.alpha());
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + borderThickness, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY + drawH - borderThickness, drawX + drawW, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY, drawX + borderThickness, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX + drawW - borderThickness, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(border));
        textWidth = PackUiText.width(context.textRenderer(), displayText, font, textColor);
        contentWidth = textWidth + (this.leadingIcon != null ? scaledIconSize + scaledIconGap : 0);
        int contentX = this.contentAlignment == PackUiButton.ContentAlignment.START ? drawX + scaledHorizontalPadding : PackUiSizing.centerInside(drawX, drawW, contentWidth);
        int textY = PackUiSizing.alignTextY(drawY, drawH, context.theme().fontHeight(this.tone), context.theme().buttonTextNudge() + this.textYOffset);
        if (this.leadingIcon != null) {
            int iconY = drawY + Math.max(1, (drawH - scaledIconSize) / 2);
            context.drawTexturedQuad(this.leadingIcon, contentX, iconY, contentX + scaledIconSize, iconY + scaledIconSize);
        }
        textX = contentX + (this.leadingIcon != null ? scaledIconSize + scaledIconGap : 0);
        PackUiText.draw(context.drawContext(), context.textRenderer(), displayText, font, context.applyAlpha(textColor), textX, textY, false);
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (!this.enabled || !this.contains(mouseX, mouseY) || button != 0) {
            return false;
        }
        this.feedbackState().triggerPress(mouseX - this.x, mouseY - this.y, this.width, this.height);
        if (this.onPress != null) {
            this.onPress.run();
        }
        return true;
    }
}
