/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.mojang.blaze3d.buffers.Std140Builder;
import java.nio.ByteBuffer;
import net.minecraft.class_11280;
import org.joml.Matrix4f;

private static final class PackUiTextMeshUniforms.Data
implements class_11280.class_11281 {
    private Matrix4f proj;
    private Matrix4f modelView;

    private PackUiTextMeshUniforms.Data() {
    }

    public void method_71104(ByteBuffer buffer) {
        Std140Builder.intoBuffer(buffer).putMat4f(this.proj).putMat4f(this.modelView);
    }

    public boolean equals(Object o) {
        return false;
    }
}
