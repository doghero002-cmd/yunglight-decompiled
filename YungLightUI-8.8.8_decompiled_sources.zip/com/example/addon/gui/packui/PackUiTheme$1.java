/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiTone;

static class PackUiTheme.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$gui$packui$PackUiTone;

    static {
        $SwitchMap$com$example$addon$gui$packui$PackUiTone = new int[PackUiTone.values().length];
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.TITLE.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.LABEL.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.LABEL.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.BODY.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.BODY.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.MUTED.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.MUTED.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.ACCENT.ordinal()] = 5;
            /* goto L84; */
            var0 = null;
            L84: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiTone[PackUiTone.ACCENT.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
