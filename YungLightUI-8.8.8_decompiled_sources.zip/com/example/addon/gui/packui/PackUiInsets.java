/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public final record PackUiInsets {
    private final int left;
    private final int top;
    private final int right;
    private final int bottom;
    public static final PackUiInsets NONE = new PackUiInsets(0, 0, 0, 0);

    public PackUiInsets(int left, int top, int right, int bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    public static PackUiInsets all(int value) {
        return new PackUiInsets(value, value, value, value);
    }

    public static PackUiInsets symmetric(int horizontal, int vertical) {
        return new PackUiInsets(horizontal, vertical, horizontal, vertical);
    }

    public int horizontal() {
        return this.left + this.right;
    }

    public int vertical() {
        return this.top + this.bottom;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int left() {
        return this.left;
    }

    public int top() {
        return this.top;
    }

    public int right() {
        return this.right;
    }

    public int bottom() {
        return this.bottom;
    }
}
