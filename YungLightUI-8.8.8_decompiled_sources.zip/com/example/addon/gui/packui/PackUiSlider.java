/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import java.util.function.Consumer;

public class PackUiSlider
extends PackUiNode {
    private float min = 0f;
    private float max = 1f;
    private float value = 0f;
    private float step = 0f;
    private boolean dragging = false;
    private Consumer<Float> onChange;
    private Consumer<Float> onRelease;

    public PackUiSlider() {
        this.height = 12f;
    }

    public PackUiSlider setRange(float min, float max) {
        this.min = min;
        this.max = Math.max(min, max);
        this.setValue(this.value);
        return this;
    }

    public PackUiSlider setStep(float step) {
        this.step = Math.max(0f, step);
        this.setValue(this.value);
        return this;
    }

    public PackUiSlider setValue(float value) {
        float snapped = this.snap(this.clamp(value));
        if (Math.abs(this.value - snapped) > 0.0001f) {
            this.value = snapped;
            if (this.onChange != null) {
                this.onChange.accept(this.value);
            }
        }
        return this;
    }

    public float value() {
        return this.value;
    }

    public PackUiSlider setOnChange(Consumer<Float> onChange) {
        this.onChange = onChange;
        return this;
    }

    public PackUiSlider setOnRelease(Consumer<Float> onRelease) {
        this.onRelease = onRelease;
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return 12f;
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        int centerY = drawY + Math.round((float)drawH / 2f);
        float ratio = this.normalized();
        int knobX = drawX + Math.round(ratio * (float)drawW);
        int fillColor = PackUiSizing.lerpColor(-42406, -10035062, ratio);
        int trackHalf = Math.max(1, Math.min(3, drawH / 3));
        int knobHalf = Math.max(2, Math.min(4, drawH / 2));
        int knobTop = drawY + Math.max(1, (drawH - Math.max(6, drawH - 2)) / 2);
        int knobBottom = drawY + drawH - Math.max(1, (drawH - Math.max(6, drawH - 2)) / 2);
        context.drawContext().method_25294(drawX, centerY - trackHalf, drawX + drawW, centerY + trackHalf, context.applyAlpha(2081032460));
        context.drawContext().method_25294(drawX, centerY - trackHalf, drawX + drawW, centerY - trackHalf + 1, context.applyAlpha(-7392975));
        context.drawContext().method_25294(drawX, centerY + trackHalf - 1, drawX + drawW, centerY + trackHalf, context.applyAlpha(-7392975));
        context.drawContext().method_25294(drawX, centerY - trackHalf, knobX, centerY + trackHalf, context.applyAlpha(fillColor));
        context.drawContext().method_25294(knobX - knobHalf, knobTop, knobX + knobHalf, knobBottom, context.applyAlpha(-986896));
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (button != 0 || !this.contains(mouseX, mouseY)) {
            return false;
        }
        this.dragging = true;
        this.updateFromMouse(mouseX);
        return true;
    }

    public boolean mouseReleased(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (button == 0) {
            if (this.dragging) {
                this.dragging = false;
                if (this.onRelease != null) {
                    this.onRelease.accept(this.value);
                }
                return true;
            }
        }
        return false;
    }

    public boolean mouseDragged(PackUiRenderContext context, float mouseX, float mouseY, int button, float deltaX, float deltaY) {
        if (!this.dragging || button != 0) {
            return false;
        }
        this.updateFromMouse(mouseX);
        return true;
    }

    private void updateFromMouse(float mouseX) {
        if (this.width <= 0f) {
            return;
        }
        float ratio = (mouseX - this.x) / this.width;
        this.setValue(this.min + Math.max(0f, Math.min(1f, ratio)) * (this.max - this.min));
    }

    private float normalized() {
        if (this.max <= this.min) {
            return 0f;
        }
        return (this.value - this.min) / (this.max - this.min);
    }

    private float clamp(float value) {
        return Math.max(this.min, Math.min(this.max, value));
    }

    private float snap(float value) {
        if (this.step <= 0f) {
            return value;
        }
        return this.min + (float)Math.round((value - this.min) / this.step) * this.step;
    }
}
