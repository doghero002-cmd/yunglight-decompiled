/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2960;

public final class PackUiFontRegistry {
    private final Map<String, class_2960> fonts = new LinkedHashMap();
    private class_2960 defaultFont;

    public PackUiFontRegistry register(String key, class_2960 fontId) {
        if (key == null || key.isBlank() || fontId == null) {
            return this;
        }
        this.fonts.put(key, fontId);
        if (this.defaultFont == null) {
            this.defaultFont = fontId;
        }
        return this;
    }

    public class_2960 get(String key) {
        class_2960 font = (class_2960)this.fonts.get(key);
        return font != null ? font : this.defaultFont;
    }

    public class_2960 getDefault() {
        return this.defaultFont;
    }
}
