/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.util.PackUtilUiScale;
import net.minecraft.class_332;

public final class PackUiViewport {
    private final float uiWidth;
    private final float uiHeight;

    private PackUiViewport(float uiWidth, float uiHeight) {
        this.uiWidth = Math.max(1f, uiWidth);
        this.uiHeight = Math.max(1f, uiHeight);
    }

    public static PackUiViewport current(float density) {
        return new PackUiViewport((float)PackUtilUiScale.getVirtualScreenWidth(), (float)PackUtilUiScale.getVirtualScreenHeight());
    }

    public float uiWidth() {
        return this.uiWidth;
    }

    public float uiHeight() {
        return this.uiHeight;
    }

    public float drawScaleX() {
        return 1f;
    }

    public float drawScaleY() {
        return 1f;
    }

    public float toUiX(double screenX) {
        return (float)screenX;
    }

    public float toUiY(double screenY) {
        return (float)screenY;
    }

    public void push(class_332 context) {
    }

    public void pop(class_332 context) {
    }

    public void enableScissor(class_332 context, float x1, float y1, float x2, float y2) {
        PackUtilUiScale.enableOverlayScissor(context, Math.round(x1), Math.round(y1), Math.round(x2), Math.round(y2));
    }

    public void disableScissor(class_332 context) {
        context.method_44380();
    }
}
