/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiRow;
import com.example.addon.gui.packui.PackUiTone;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

public class PackUiTabStrip
extends PackUiContainer {
    private final PackUiRow row = new PackUiRow().setGap(2);
    private final List<PackUiButton> buttons = new ArrayList();
    private String[] tabs = new String[0];
    private int activeIndex = 0;
    private IntConsumer onSelect;

    public PackUiTabStrip() {
        this.add(this.row);
    }

    public PackUiTabStrip setTabs(String ... tabs) {
        this.tabs = tabs == null ? new String[0] : (String[])tabs.clone();
        this.rebuildButtons();
        return this;
    }

    public PackUiTabStrip setActiveIndex(int activeIndex) {
        this.activeIndex = Math.max(0, Math.min(Math.max(0, this.tabs.length - 1), activeIndex));
        this.refreshButtonVariants();
        return this;
    }

    public PackUiTabStrip setOnSelect(IntConsumer onSelect) {
        this.onSelect = onSelect;
        this.rebuildButtons();
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return this.row.preferredHeight(context, availableWidth);
    }

    protected void layoutChildren(PackUiRenderContext context) {
        this.row.setBounds(this.x, this.y, this.width, this.row.preferredHeight(context, this.width));
    }

    private void rebuildButtons() {
        this.row.clearChildren();
        this.buttons.clear();
        for (int i = 0; i < this.tabs.length; i++) {
            int tabIndex = i;
            PackUiButton button = new PackUiButton(this.tabs[i], i == this.activeIndex ? PackUiButton.Variant.PRIMARY : PackUiButton.Variant.GHOST, this::lambda$rebuildButtons$0 /* captured: tabIndex */).setGrowX(true).setTone(PackUiTone.LABEL);
            this.buttons.add(button);
            this.row.add(button);
        }
    }

    private void refreshButtonVariants() {
        for (int i = 0; i < this.buttons.size(); i++) {
            ((PackUiButton)this.buttons.get(i)).setVariant(i == this.activeIndex ? PackUiButton.Variant.PRIMARY : PackUiButton.Variant.GHOST);
        }
    }
}
