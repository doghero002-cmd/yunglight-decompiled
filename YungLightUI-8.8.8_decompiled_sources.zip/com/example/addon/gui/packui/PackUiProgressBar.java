/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;

public class PackUiProgressBar
extends PackUiNode {
    private float progress = 0f;
    private int startColor = -42406;
    private int endColor = -10035062;
    private int borderColor = -7392975;
    private int fillBackground = 2081032460;

    public PackUiProgressBar() {
        this.height = 12f;
    }

    public PackUiProgressBar setProgress(float progress) {
        this.progress = Math.max(0f, Math.min(1f, progress));
        return this;
    }

    public PackUiProgressBar setGradient(int startColor, int endColor) {
        this.startColor = startColor;
        this.endColor = endColor;
        return this;
    }

    public PackUiProgressBar setBorderColor(int borderColor) {
        this.borderColor = borderColor;
        return this;
    }

    public PackUiProgressBar setFillBackground(int fillBackground) {
        this.fillBackground = fillBackground;
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return 12f;
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        int innerW = Math.max(0, drawW - 2);
        int fillW = Math.max(0, Math.min(innerW, Math.round((float)innerW * this.progress)));
        int fillColor = PackUiSizing.lerpColor(this.startColor, this.endColor, this.progress);
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(this.fillBackground));
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + 1, context.applyAlpha(this.borderColor));
        context.drawContext().method_25294(drawX, drawY + drawH - 1, drawX + drawW, drawY + drawH, context.applyAlpha(this.borderColor));
        context.drawContext().method_25294(drawX, drawY, drawX + 1, drawY + drawH, context.applyAlpha(this.borderColor));
        context.drawContext().method_25294(drawX + drawW - 1, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(this.borderColor));
        if (fillW > 0) {
            context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + 1 + fillW, drawY + drawH - 1, context.applyAlpha(fillColor));
        }
    }
}
