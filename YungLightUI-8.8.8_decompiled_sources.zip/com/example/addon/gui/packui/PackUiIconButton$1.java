/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButton;

static class PackUiIconButton.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant;

    static {
        $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant = new int[PackUiButton.Variant.values().length];
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.PRIMARY.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.SECONDARY.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.SECONDARY.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.GHOST.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.GHOST.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.DANGER.ordinal()] = 4;
            /* goto @69; */
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.DANGER.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.SUCCESS.ordinal()] = 5;
            /* goto L84; */
            var0 = null;
            L84: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[PackUiButton.Variant.SUCCESS.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
