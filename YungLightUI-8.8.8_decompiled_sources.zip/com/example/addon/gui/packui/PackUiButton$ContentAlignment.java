/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static enum PackUiButton.ContentAlignment {
    public static final PackUiButton.ContentAlignment CENTER = new PackUiButton.ContentAlignment("CENTER", 0);
    public static final PackUiButton.ContentAlignment START = new PackUiButton.ContentAlignment("START", 1);
    private static final /* synthetic */ PackUiButton.ContentAlignment[] $VALUES;

    public static PackUiButton.ContentAlignment[] values() {
        return (PackUiButton.ContentAlignment[])$VALUES.clone();
    }

    public static PackUiButton.ContentAlignment valueOf(String name) {
        return (PackUiButton.ContentAlignment)Enum.valueOf(PackUiButton.ContentAlignment.class, name);
    }

    private PackUiButton.ContentAlignment() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUiButton.ContentAlignment.$values();
    }
}
