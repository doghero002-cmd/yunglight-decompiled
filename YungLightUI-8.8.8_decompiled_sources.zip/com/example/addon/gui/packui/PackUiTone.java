/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public enum PackUiTone {
    public static final PackUiTone TITLE = new PackUiTone("TITLE", 0);
    public static final PackUiTone LABEL = new PackUiTone("LABEL", 1);
    public static final PackUiTone BODY = new PackUiTone("BODY", 2);
    public static final PackUiTone MUTED = new PackUiTone("MUTED", 3);
    public static final PackUiTone ACCENT = new PackUiTone("ACCENT", 4);
    private static final /* synthetic */ PackUiTone[] $VALUES;

    public static PackUiTone[] values() {
        return (PackUiTone[])$VALUES.clone();
    }

    public static PackUiTone valueOf(String name) {
        return (PackUiTone)Enum.valueOf(PackUiTone.class, name);
    }

    private PackUiTone() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUiTone.$values();
    }
}
