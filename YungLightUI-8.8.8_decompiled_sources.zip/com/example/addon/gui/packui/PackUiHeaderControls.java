/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiControlGlyphs;
import com.example.addon.gui.packui.PackUiRenderContext;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class PackUiHeaderControls {
    private static final float ANIMATION_DURATION_SECONDS = 0f;
    private static final float COLLAPSED_CLOSE_VISIBILITY = 0.72f;

    private PackUiHeaderControls() {
    }

    public static float animate(float current, float target, float delta) {
        float amount = 1f;
        if (current < target) {
            return Math.min(target, current + amount);
        }
        if (current > target) {
            return Math.max(target, current - amount);
        }
        return current;
    }

    public static int controlY(int panelY, int headerHeight, int controlSize) {
        return panelY + Math.max(1, (headerHeight - controlSize) / 2);
    }

    public static int closeX(int panelX, int panelWidth, int controlSize, int rightInset) {
        return panelX + panelWidth - controlSize - rightInset;
    }

    public static int expandedArrowX(int closeX, int gap, int arrowWidth) {
        return closeX - gap - arrowWidth;
    }

    public static boolean isCloseHit(float visibility, double mouseX, double mouseY, int x, int y, int controlSize) {
        return mouseX >= (double)x && mouseX <= (double)(x + controlSize) && mouseY >= (double)y && mouseY <= (double)(y + controlSize);
    }

    public static void drawAnimatedArrow(class_332 context, int x, int y, int size, float expandedProgress, float alpha) {
        PackUiControlGlyphs.drawChevron(context, x, y, size, PackUiHeaderControls.clamp01(expandedProgress) >= 0.5f ? PackUiControlGlyphs.ChevronDirection.DOWN : PackUiControlGlyphs.ChevronDirection.RIGHT, -725523, -1002629349, alpha);
    }

    public static void drawCloseButton(class_332 context, int x, int y, int width, int height, float hover, boolean active, float visibility) {
        float shownVisibility = 0.72f + 0.27999997f * PackUiHeaderControls.clamp01(visibility);
        float alpha = PackUiHeaderControls.clamp01((active ? 1f : 0.56f) * shownVisibility);
        int bg = active ? 1880492557 : 1310001162;
        int border = active ? -4896696 : -1434832591;
        context.method_25294(x, y, x + width, y + height, PackUiRenderContext.applyAlpha(bg, alpha));
        context.method_25294(x, y, x + width, y + 1, PackUiRenderContext.applyAlpha(border, alpha));
        context.method_25294(x, y + height - 1, x + width, y + height, PackUiRenderContext.applyAlpha(border, alpha));
        context.method_25294(x, y, x + 1, y + height, PackUiRenderContext.applyAlpha(border, alpha));
        context.method_25294(x + width - 1, y, x + width, y + height, PackUiRenderContext.applyAlpha(border, alpha));
        if (hover > 0f) {
            int hoverTint = (int)(PackUiHeaderControls.clamp01(hover) * 18f) << 24 | 16730698;
            context.method_25294(x + 1, y + 1, x + width - 1, y + height - 1, PackUiRenderContext.applyAlpha(hoverTint, alpha));
        }
        PackUiControlGlyphs.drawClose(context, x + 1, y + 1, Math.max(1, Math.min(width, height) - 2), -594194, -699786721, alpha);
    }

    private static void drawIcon(class_332 context, class_2960 icon, int x, int y, int size, float alpha) {
        if (context == null || icon == null || size <= 0 || alpha <= 0.001f) {
            return;
        }
        if (PackUiControlGlyphs.isCloseIcon(icon) || PackUiControlGlyphs.isChevronIcon(icon)) {
            PackUiControlGlyphs.drawKnownIcon(context, icon, x, y, size, -725523, -1002629349, alpha);
            return;
        }
        context.method_70845(icon, x, y, x + size, y + size, 0f, 1f, 0f, 1f);
        if (alpha < 0.999f) {
            int overlayAlpha = Math.max(0, Math.min(255, Math.round((1f - alpha) * 255f)));
            context.method_25294(x, y, x + size, y + size, overlayAlpha << 24 | 460553);
        }
    }

    private static float clamp01(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
