/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

private static final record PackUiAtlasTextRenderer.Glyph {
    private final float x0;
    private final float y0;
    private final float x1;
    private final float y1;
    private final float u0;
    private final float v0;
    private final float u1;
    private final float v1;
    private final float advance;

    private PackUiAtlasTextRenderer.Glyph(float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, float advance) {
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
        this.u0 = u0;
        this.v0 = v0;
        this.u1 = u1;
        this.v1 = v1;
        this.advance = advance;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public float x0() {
        return this.x0;
    }

    public float y0() {
        return this.y0;
    }

    public float x1() {
        return this.x1;
    }

    public float y1() {
        return this.y1;
    }

    public float u0() {
        return this.u0;
    }

    public float v0() {
        return this.v0;
    }

    public float u1() {
        return this.u1;
    }

    public float v1() {
        return this.v1;
    }

    public float advance() {
        return this.advance;
    }
}
