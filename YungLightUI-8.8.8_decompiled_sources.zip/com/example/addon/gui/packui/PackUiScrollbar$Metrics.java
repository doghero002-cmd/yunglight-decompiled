/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static final record PackUiScrollbar.Metrics {
    private final int trackX;
    private final int trackY;
    private final int trackWidth;
    private final int trackHeight;
    private final int thumbY;
    private final int thumbHeight;
    private final int maxScroll;

    public PackUiScrollbar.Metrics(int trackX, int trackY, int trackWidth, int trackHeight, int thumbY, int thumbHeight, int maxScroll) {
        this.trackX = trackX;
        this.trackY = trackY;
        this.trackWidth = trackWidth;
        this.trackHeight = trackHeight;
        this.thumbY = thumbY;
        this.thumbHeight = thumbHeight;
        this.maxScroll = maxScroll;
    }

    public boolean hasScroll() {
        return this.maxScroll > 0;
    }

    public boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.trackX && mouseX < (double)(this.trackX + this.trackWidth) && mouseY >= (double)this.trackY && mouseY < (double)(this.trackY + this.trackHeight);
    }

    public boolean overThumb(double mouseX, double mouseY) {
        return this.hasScroll() && mouseX >= (double)this.trackX && mouseX < (double)(this.trackX + this.trackWidth) && mouseY >= (double)this.thumbY && mouseY < (double)(this.thumbY + this.thumbHeight);
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int trackX() {
        return this.trackX;
    }

    public int trackY() {
        return this.trackY;
    }

    public int trackWidth() {
        return this.trackWidth;
    }

    public int trackHeight() {
        return this.trackHeight;
    }

    public int thumbY() {
        return this.thumbY;
    }

    public int thumbHeight() {
        return this.thumbHeight;
    }

    public int maxScroll() {
        return this.maxScroll;
    }
}
