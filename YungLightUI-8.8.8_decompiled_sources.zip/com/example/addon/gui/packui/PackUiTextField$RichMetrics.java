/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import java.util.List;
import net.minecraft.class_2583;

private static final record PackUiTextField.RichMetrics {
    private final String text;
    private final List<class_2583> styles;

    private PackUiTextField.RichMetrics(String text, List<class_2583> styles) {
        this.text = text;
        this.styles = styles;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String text() {
        return this.text;
    }

    public List<class_2583> styles() {
        return this.styles;
    }
}
