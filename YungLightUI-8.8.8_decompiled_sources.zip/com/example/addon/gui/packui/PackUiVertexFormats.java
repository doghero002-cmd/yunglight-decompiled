/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiVertexFormatElements;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;

final class PackUiVertexFormats {
    static final VertexFormat POS2_TEXTURE_COLOR = VertexFormat.builder().add("Position", PackUiVertexFormatElements.POS2).add("Texture", VertexFormatElement.UV).add("Color", VertexFormatElement.COLOR).build();

    private PackUiVertexFormats() {
    }
}
