/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAtlasTextRenderer;
import java.nio.ByteBuffer;
import java.util.Map;

private static final class PackUiAtlasTextRenderer.PrecomputedAtlas {
    final Map<Integer, PackUiAtlasTextRenderer.Glyph> glyphs;
    final PackUiAtlasTextRenderer.Glyph fallbackGlyph;
    final float ascent;
    final int packedHeight;
    final ByteBuffer bitmap;

    PackUiAtlasTextRenderer.PrecomputedAtlas(Map<Integer, PackUiAtlasTextRenderer.Glyph> glyphs, PackUiAtlasTextRenderer.Glyph fallbackGlyph, float ascent, int packedHeight, ByteBuffer bitmap) {
        this.glyphs = glyphs;
        this.fallbackGlyph = fallbackGlyph;
        this.ascent = ascent;
        this.packedHeight = packedHeight;
        this.bitmap = bitmap;
    }
}
