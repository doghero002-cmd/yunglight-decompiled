/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.lwjgl.glfw.GLFW;

public final class PackUiButtonFeedback {
    private static final float HOVER_IN_SECONDS = 0.2f;
    private static final float HOVER_OUT_SECONDS = 0.1f;
    private static final float CLICK_GLOW_SECONDS = 0.18f;
    private static final float RIPPLE_SECONDS = 0.42f;
    private static final int MAX_RIPPLES = 2;
    private static final long STALE_NANOS = 12000000000L;
    private static final int MAX_TRACKED_KEYS = 768;
    private static final Map<String, PackUiButtonFeedback> KEYED_STATES = new ConcurrentHashMap();
    private static long lastPruneNanos = System.nanoTime();
    private final ArrayDeque<PackUiButtonFeedback.Ripple> ripples = new ArrayDeque();
    private long lastUpdateNanos = System.nanoTime();
    private long lastSeenNanos = this.lastUpdateNanos;
    private float hoverProgress;
    private float clickGlowProgress;
    private boolean pointerDown;

    public static PackUiButtonFeedback forKey(String key) {
        PackUiButtonFeedback.pruneIfNeeded();
        PackUiButtonFeedback feedback = (PackUiButtonFeedback)KEYED_STATES.computeIfAbsent(key, PackUiButtonFeedback::lambda$forKey$0);
        feedback.lastSeenNanos = System.nanoTime();
        return feedback;
    }

    public static boolean isPrimaryPointerDown() {
        class_310 client = class_310.method_1551();
        return client != null && client.method_22683() != null && GLFW.glfwGetMouseButton(client.method_22683().method_4490(), 0) == 1;
    }

    public float update(boolean hovered, boolean pressed, float localMouseX, float localMouseY, float width, float height) {
        float delta = this.tick();
        this.hoverProgress = PackUiButtonFeedback.animate(this.hoverProgress, hovered ? 1f : 0f, hovered ? 0.2f : 0.1f, delta);
        if (hovered) {
            if (pressed) {
                if (!this.pointerDown) {
                    this.triggerPress(localMouseX, localMouseY, width, height);
                }
            }
        }
        this.pointerDown = pressed;
        this.lastSeenNanos = System.nanoTime();
        return this.hoverProgress;
    }

    public void triggerPress(float localMouseX, float localMouseY, float width, float height) {
        float safeWidth = Math.max(1f, width);
        float safeHeight = Math.max(1f, height);
        float clampedX = PackUiButtonFeedback.clamp(localMouseX, 0f, safeWidth);
        float clampedY = PackUiButtonFeedback.clamp(localMouseY, 0f, safeHeight);
        float maxRadius = Math.max(Math.max(PackUiButtonFeedback.distance(clampedX, clampedY, 0f, 0f), PackUiButtonFeedback.distance(clampedX, clampedY, safeWidth, 0f)), Math.max(PackUiButtonFeedback.distance(clampedX, clampedY, 0f, safeHeight), PackUiButtonFeedback.distance(clampedX, clampedY, safeWidth, safeHeight))) + 1.5f;
        if (this.ripples.size() >= 2) {
            this.ripples.removeFirst();
        }
        this.ripples.addLast(new PackUiButtonFeedback.Ripple(clampedX, clampedY, maxRadius));
        this.clickGlowProgress = 1f;
        this.pointerDown = true;
        this.lastSeenNanos = System.nanoTime();
    }

    float hoverProgress() {
        return this.hoverProgress;
    }

    public float clickGlowProgress() {
        return this.clickGlowProgress;
    }

    public void render(class_332 context, int x, int y, int width, int height, int ringRgb, int fillRgb, float alphaScale) {
        if (context == null || width <= 0 || height <= 0 || alphaScale <= 0.001f || this.ripples.isEmpty()) {
            return;
        }
        int clipX2 = x + width;
        int clipY2 = y + height;
        context.method_44379(x, y, clipX2, clipY2);
        try {
            var var11 = this.ripples.iterator();
            while (var11.hasNext()) {
                Ripple ripple = (PackUiButtonFeedback.Ripple)var11.next();
                float t = PackUiButtonFeedback.clamp(ripple.age / 0.42f, 0f, 1f);
                float eased = 1f - (float)Math.pow((double)(1f - t), 3);
                float outerRadius = ripple.maxRadius * eased;
                float thickness = Math.max(1.2f, Math.min(4f, outerRadius * 0.18f));
                float innerRadius = Math.max(0f, outerRadius - thickness);
                float fade = 1f - t;
                PackUiButtonFeedback.drawRing(context, (float)x + ripple.centerX, (float)y + ripple.centerY, innerRadius, outerRadius, PackUiButtonFeedback.alphaColor(ringRgb, alphaScale * 0.26f * fade));
                PackUiButtonFeedback.drawDisc(context, (float)x + ripple.centerX, (float)y + ripple.centerY, Math.max(0.9f, outerRadius * 0.2f), PackUiButtonFeedback.alphaColor(fillRgb, alphaScale * 0.11f * fade));
            }
        }
        finally {
            context.method_44380();
            throw var19;
        }
    }

    private float tick() {
        long now = System.nanoTime();
        float delta = PackUiButtonFeedback.clamp((float)(now - this.lastUpdateNanos) / 1000000000f, 0f, 0.05f);
        this.lastUpdateNanos = now;
        if (this.clickGlowProgress > 0f) {
            this.clickGlowProgress = Math.max(0f, this.clickGlowProgress - delta / 0.18f);
        }
        Iterator<PackUiButtonFeedback.Ripple> iterator = this.ripples.iterator();
        while (iterator.hasNext()) {
            Ripple ripple = (PackUiButtonFeedback.Ripple)iterator.next();
            ripple.age = ripple.age + delta;
            if (!ripple.age >= 0.42f) continue;
            iterator.remove();
        }
        return delta;
    }

    private static void pruneIfNeeded() {
        long now = System.nanoTime();
        if (KEYED_STATES.size() < 768 && now - lastPruneNanos < 2000000000L) {
            return;
        }
        lastPruneNanos = now;
        KEYED_STATES.entrySet().removeIf(PackUiButtonFeedback::lambda$pruneIfNeeded$1 /* captured: now */);
    }

    private static float animate(float current, float target, float durationSeconds, float deltaSeconds) {
        if (durationSeconds <= 0f) {
            return target;
        }
        float amount = PackUiButtonFeedback.clamp(deltaSeconds / durationSeconds, 0f, 1f);
        if (current < target) {
            return Math.min(target, current + amount);
        }
        if (current > target) {
            return Math.max(target, current - amount);
        }
        return current;
    }

    private static int alphaColor(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(PackUiButtonFeedback.clamp(alpha, 0f, 1f) * 255f)));
        return a << 24 | rgb & 16777215;
    }

    private static void drawDisc(class_332 context, float centerX, float centerY, float radius, int color) {
        if (color >>> 24 & 255 <= 0 || radius <= 0.5f) {
            return;
        }
        float radiusSq = radius * radius;
        int top = (int)Math.floor((double)(centerY - radius));
        int bottom = (int)Math.ceil((double)(centerY + radius));
        for (int py = top; py < bottom; py++) {
            float dy = (float)py + 0.5f - centerY;
            float dxSq = radiusSq - dy * dy;
            if (dxSq <= 0f) {
            } else {
                float dx = (float)Math.sqrt((double)dxSq);
                int x1 = (int)Math.floor((double)(centerX - dx));
                int x2 = (int)Math.ceil((double)(centerX + dx));
                if (!x2 > x1) continue;
                context.method_25294(x1, py, x2, py + 1, color);
            }
        }
    }

    private static void drawRing(class_332 context, float centerX, float centerY, float innerRadius, float outerRadius, int color) {
        if (color >>> 24 & 255 <= 0 || outerRadius <= 0.5f) {
            return;
        }
        float outerSq = outerRadius * outerRadius;
        float innerSq = innerRadius * innerRadius;
        int top = (int)Math.floor((double)(centerY - outerRadius));
        int bottom = (int)Math.ceil((double)(centerY + outerRadius));
        for (int py = top; py < bottom; py++) {
            float dy = (float)py + 0.5f - centerY;
            float outerDxSq = outerSq - dy * dy;
            if (outerDxSq <= 0f) {
            } else {
                float outerDx = (float)Math.sqrt((double)outerDxSq);
                float innerDx = innerRadius > Math.abs(dy) ? (float)Math.sqrt((double)Math.max(0f, innerSq - dy * dy)) : 0f;
                int leftOuter = (int)Math.floor((double)(centerX - outerDx));
                int leftInner = (int)Math.ceil((double)(centerX - innerDx));
                int rightInner = (int)Math.floor((double)(centerX + innerDx));
                int rightOuter = (int)Math.ceil((double)(centerX + outerDx));
                if (innerDx <= 0.5f) { /* goto L200; */ }
                if (rightInner <= leftInner) {
                    if (!rightOuter > leftOuter) continue;
                    context.method_25294(leftOuter, py, rightOuter, py + 1, color);
                } else {
                    if (!leftInner > leftOuter) continue;
                    context.method_25294(leftOuter, py, leftInner, py + 1, color);
                    if (!rightOuter > rightInner) continue;
                    context.method_25294(rightInner, py, rightOuter, py + 1, color);
                }
            }
        }
    }

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        return (float)Math.sqrt((double)(dx * dx + dy * dy));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
