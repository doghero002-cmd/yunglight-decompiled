/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiSpacer
extends PackUiNode {
    public PackUiSpacer(float width, float height) {
        this.width = Math.max(0f, width);
        this.height = Math.max(0f, height);
    }

    public float preferredWidth(PackUiRenderContext context) {
        return context.theme().scale(this.width);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return context.theme().scale(this.height);
    }
}
