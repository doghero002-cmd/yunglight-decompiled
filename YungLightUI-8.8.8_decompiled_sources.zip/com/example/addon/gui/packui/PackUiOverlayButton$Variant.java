/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static enum PackUiOverlayButton.Variant {
    public static final PackUiOverlayButton.Variant SECONDARY = new PackUiOverlayButton.Variant("SECONDARY", 0);
    public static final PackUiOverlayButton.Variant DANGER = new PackUiOverlayButton.Variant("DANGER", 1);
    public static final PackUiOverlayButton.Variant SUCCESS = new PackUiOverlayButton.Variant("SUCCESS", 2);
    public static final PackUiOverlayButton.Variant PRIMARY = new PackUiOverlayButton.Variant("PRIMARY", 3);
    public static final PackUiOverlayButton.Variant GHOST = new PackUiOverlayButton.Variant("GHOST", 4);
    private static final /* synthetic */ PackUiOverlayButton.Variant[] $VALUES;

    public static PackUiOverlayButton.Variant[] values() {
        return (PackUiOverlayButton.Variant[])$VALUES.clone();
    }

    public static PackUiOverlayButton.Variant valueOf(String name) {
        return (PackUiOverlayButton.Variant)Enum.valueOf(PackUiOverlayButton.Variant.class, name);
    }

    private PackUiOverlayButton.Variant() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUiOverlayButton.Variant.$values();
    }
}
