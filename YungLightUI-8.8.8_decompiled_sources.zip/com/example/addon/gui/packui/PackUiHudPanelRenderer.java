/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUiHudPanelRenderer {
    private static final PackUiTheme THEME = new PackUiTheme();

    private PackUiHudPanelRenderer() {
    }

    public static int render(class_332 context, class_327 textRenderer, int x, int y, int width, String title, List<PackUiHudPanelRenderer.Row> rows, int accentColor) {
        String titleTrimmed = PackUiText.trimToWidth(textRenderer, title, width - 12, THEME.fontFor(PackUiTone.LABEL), THEME.color(PackUiTone.BODY));
        ArrayList<PackUiHudPanelRenderer.Row> trimmedRows = new ArrayList(rows.size());
        var var10 = rows.iterator();
        while (var10.hasNext()) {
            Row row = (PackUiHudPanelRenderer.Row)var10.next();
            trimmedRows.add(new PackUiHudPanelRenderer.Row(PackUiText.trimToWidth(textRenderer, row.text(), width - 12, row.font(), row.color()), row.font(), row.color()));
        }
        return PackUiHudPanelRenderer.renderPreTrimmed(context, textRenderer, x, y, width, titleTrimmed, trimmedRows, accentColor);
    }

    public static int renderPreTrimmed(class_332 context, class_327 textRenderer, int x, int y, int width, String title, List<PackUiHudPanelRenderer.Row> rows, int accentColor) {
        int headerHeight = Math.max(THEME.headerHeight(), THEME.lineHeight(PackUiTone.LABEL, 2));
        int rowHeight = THEME.lineHeight(PackUiTone.BODY, 2);
        int bodyPadding = 6;
        int contentHeight = Math.max(rowHeight, rows.size() * rowHeight);
        int height = headerHeight + bodyPadding + contentHeight + 6;
        context.method_25294(x, y, x + width, y + height, THEME.windowFill());
        context.method_25294(x + 1, y + 1, x + width - 1, y + headerHeight, THEME.headerFill());
        context.method_25294(x, y, x + width, y + 1, accentColor);
        context.method_25294(x, y + height - 1, x + width, y + height, THEME.borderColor());
        context.method_25294(x, y, x + 1, y + height, THEME.borderColor());
        context.method_25294(x + width - 1, y, x + width, y + height, THEME.borderColor());
        context.method_25294(x + 1, y + 1, x + width - 1, y + 2, 620756991);
        int padX = 6;
        int titleY = PackUiSizing.alignTextY(y, headerHeight, THEME.fontHeight(PackUiTone.LABEL), THEME.bodyTextNudge());
        PackUiText.draw(context, textRenderer, title, THEME.fontFor(PackUiTone.LABEL), THEME.color(PackUiTone.BODY), x + padX, titleY, false);
        int rowY = y + headerHeight + 4;
        var var16 = rows.iterator();
        while (var16.hasNext()) {
            Row row = (PackUiHudPanelRenderer.Row)var16.next();
            PackUiText.draw(context, textRenderer, row.text(), row.font(), row.color(), x + padX, PackUiSizing.alignTextY(rowY, rowHeight, THEME.fontHeight(PackUiTone.BODY), THEME.bodyTextNudge()), false);
            rowY = rowY + rowHeight;
        }
        return height;
    }
}
