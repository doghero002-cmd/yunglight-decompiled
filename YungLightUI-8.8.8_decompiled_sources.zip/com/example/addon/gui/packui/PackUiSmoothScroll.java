/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiScrollbar;

public final class PackUiSmoothScroll {
    private static final float SMOOTH_SPEED = 24f;
    private int targetOffset = 0;
    private float visualOffset = 0f;
    private boolean initialized = false;

    public void restore(int offset) {
        this.targetOffset = Math.max(0, offset);
        this.visualOffset = (float)this.targetOffset;
        this.initialized = true;
    }

    public void setTarget(int offset, int maxScroll) {
        this.targetOffset = PackUiSmoothScroll.clamp(offset, maxScroll);
        if (!this.initialized) {
            this.visualOffset = (float)this.targetOffset;
            this.initialized = true;
        }
    }

    public void jumpTo(int offset, int maxScroll) {
        this.targetOffset = PackUiSmoothScroll.clamp(offset, maxScroll);
        this.visualOffset = (float)this.targetOffset;
        this.initialized = true;
    }

    public void nudge(double amount, float stepPixels, int maxScroll) {
        this.setTarget(this.targetOffset - Math.round((float)amount * stepPixels), maxScroll);
    }

    public void setFromThumb(PackUiScrollbar.Metrics metrics, double mouseY, int grabOffset) {
        if (metrics == null) {
            this.jumpTo(0, 0);
            return;
        }
        this.setTarget(PackUiScrollbar.scrollFromThumb(metrics, mouseY, grabOffset), metrics.maxScroll());
    }

    public void setFromThumbStepped(PackUiScrollbar.Metrics metrics, double mouseY, int grabOffset, int stepSize) {
        if (metrics == null) {
            this.jumpTo(0, 0);
            return;
        }
        int rawScroll = PackUiScrollbar.scrollFromThumb(metrics, mouseY, grabOffset);
        int steppedScroll = rawScroll / stepSize * stepSize;
        this.setTarget(steppedScroll, metrics.maxScroll());
    }

    public int tick(float delta, int maxScroll) {
        this.targetOffset = PackUiSmoothScroll.clamp(this.targetOffset, maxScroll);
        this.visualOffset = (float)this.targetOffset;
        this.initialized = true;
        return Math.round(this.visualOffset);
    }

    public int targetOffset() {
        return this.targetOffset;
    }

    public int visualOffsetInt() {
        return Math.round(this.visualOffset);
    }

    private static int clamp(int value, int max) {
        return Math.max(0, Math.min(max, value));
    }
}
