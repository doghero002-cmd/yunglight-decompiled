/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static class PackUiScrollViewport.DrawBounds {
    public final int x;
    public final int y;
    public final int width;
    public final int height;

    public PackUiScrollViewport.DrawBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
}
