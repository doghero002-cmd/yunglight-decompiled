/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiText;
import java.util.Collection;
import net.minecraft.class_2960;
import net.minecraft.class_327;

public final class PackUiSizing {
    private PackUiSizing() {
    }

    public static float clamp(float value, float min, float max) {
        float safeMax = Math.max(min, max);
        return Math.max(min, Math.min(value, safeMax));
    }

    public static float fitTextWidth(class_327 renderer, String text, class_2960 fontId, int color, float horizontalPadding, float minWidth, float maxWidth) {
        float textWidth = (float)PackUiText.width(renderer, text == null ? "" : text, fontId, color);
        return PackUiSizing.clamp(textWidth + horizontalPadding * 2f, minWidth, maxWidth);
    }

    public static int fitTextWidthInt(class_327 renderer, String text, class_2960 fontId, int color, int horizontalPadding, int minWidth, int maxWidth) {
        return Math.round(PackUiSizing.fitTextWidth(renderer, text, fontId, color, (float)horizontalPadding, (float)minWidth, (float)maxWidth));
    }

    public static int measureWidestText(class_327 renderer, class_2960 fontId, int color, Collection<String> values) {
        if (renderer == null || values == null || values.isEmpty()) {
            return 0;
        }
        int widest = 0;
        var var5 = values.iterator();
        while (var5.hasNext()) {
            String value = (String)var5.next();
            widest = Math.max(widest, PackUiText.width(renderer, value == null ? "" : value, fontId, color));
        }
        return widest;
    }

    public static int centerInside(int outerStart, int outerSize, int innerSize) {
        return outerStart + Math.max(0, (outerSize - innerSize) / 2);
    }

    public static int alignMiddle(int outerStart, int outerSize, int innerSize) {
        return PackUiSizing.centerInside(outerStart, outerSize, innerSize);
    }

    public static int alignTextY(int boxY, int boxHeight, int fontHeight, int offset) {
        return boxY + PackUiSizing.alignMiddle(0, boxHeight, fontHeight) + offset;
    }

    public static int lerpColor(int from, int to, float t) {
        float clamped = Math.max(0f, Math.min(1f, t));
        int a1 = from >>> 24 & 255;
        int r1 = from >>> 16 & 255;
        int g1 = from >>> 8 & 255;
        int b1 = from & 255;
        int a2 = to >>> 24 & 255;
        int r2 = to >>> 16 & 255;
        int g2 = to >>> 8 & 255;
        int b2 = to & 255;
        int a = Math.round((float)a1 + (float)(a2 - a1) * clamped);
        int r = Math.round((float)r1 + (float)(r2 - r1) * clamped);
        int g = Math.round((float)g1 + (float)(g2 - g1) * clamped);
        int b = Math.round((float)b1 + (float)(b2 - b1) * clamped);
        return a << 24 | r << 16 | g << 8 | b;
    }
}
