/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiColumn;
import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTone;
import net.minecraft.class_2960;

public class PackUiWindowNode
extends PackUiContainer {
    private static final float BODY_FADE_DURATION_SECONDS = 0f;
    private final PackUiColumn content = new PackUiColumn();
    private String title;
    private class_2960 titleIcon;
    private boolean showBody = true;
    private float bodyFadeAlpha = 1f;
    private boolean active = true;
    private boolean headerHovered = false;
    private boolean centerTitle = true;
    private PackUiTone titleTone = PackUiTone.TITLE;
    private int titleLeftInset = 10;
    private int titleRightInset = 10;
    private long lastAnimationNanos = System.nanoTime();

    public PackUiWindowNode(String title) {
        this.title = title == null ? "" : title;
        this.content.setGap(4).setPadding(PackUiInsets.all(6));
        this.add(this.content);
    }

    public PackUiColumn content() {
        return this.content;
    }

    public PackUiWindowNode setTitle(String title) {
        this.title = title == null ? "" : title;
        return this;
    }

    public PackUiWindowNode setTitleIcon(class_2960 titleIcon) {
        this.titleIcon = titleIcon;
        return this;
    }

    public PackUiWindowNode setShowBody(boolean showBody) {
        this.showBody = showBody;
        return this;
    }

    public PackUiWindowNode restoreShowBody(boolean showBody) {
        this.showBody = showBody;
        this.bodyFadeAlpha = showBody ? 1f : 0f;
        this.lastAnimationNanos = System.nanoTime();
        return this;
    }

    public PackUiWindowNode syncShowBody(boolean showBody) {
        return this.restoreShowBody(showBody);
    }

    public float bodyFadeAlpha() {
        this.updateBodyFadeAlpha();
        return this.bodyFadeAlpha;
    }

    public PackUiWindowNode setActive(boolean active) {
        this.active = active;
        return this;
    }

    public PackUiWindowNode setHeaderHovered(boolean headerHovered) {
        this.headerHovered = headerHovered;
        return this;
    }

    public PackUiWindowNode setCenterTitle(boolean centerTitle) {
        this.centerTitle = centerTitle;
        return this;
    }

    public PackUiWindowNode setTitleTone(PackUiTone titleTone) {
        this.titleTone = titleTone == null ? PackUiTone.TITLE : titleTone;
        return this;
    }

    public PackUiWindowNode setTitleAreaInsets(int titleLeftInset, int titleRightInset) {
        this.titleLeftInset = Math.max(0, titleLeftInset);
        this.titleRightInset = Math.max(0, titleRightInset);
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        this.updateBodyFadeAlpha();
        int headerH = Math.max(context.theme().headerHeight(), context.theme().lineHeight(this.titleTone, 4));
        float bodyHeight = this.shouldShowBodyArea() ? this.content.preferredHeight(context, availableWidth) : 0f;
        return (float)headerH + bodyHeight;
    }

    protected void layoutChildren(PackUiRenderContext context) {
        this.updateBodyFadeAlpha();
        int headerH = Math.max(context.theme().headerHeight(), context.theme().lineHeight(this.titleTone, 4));
        boolean showContent = this.shouldShowBodyArea();
        this.content.setVisible(showContent);
        this.content.setBounds(this.x, this.y + (float)headerH, this.width, showContent ? Math.max(0f, this.height - (float)headerH) : 0f);
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        this.updateBodyFadeAlpha();
        PackUiRenderContext drawContext = context.withAlpha(this.active ? 1f : 0.56f);
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        int headerH = Math.max(context.theme().headerHeight(), context.theme().lineHeight(this.titleTone, 4));
        int titleColor = context.theme().color(this.titleTone);
        int titleFont = context.theme().fontHeight(this.titleTone);
        int frameFill = this.active ? context.theme().windowFill() : -1744369911;
        int headerFill = this.active ? -1005449198 : -1979053556;
        int border = this.active ? context.theme().borderColor() : context.theme().borderSoft();
        int accent = this.active ? context.theme().headerAccent() : -1434836960;
        int scaledTitleLeftInset = context.theme().scale(this.titleLeftInset);
        int scaledTitleRightInset = context.theme().scale(this.titleRightInset);
        drawContext.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, drawContext.applyAlpha(frameFill));
        drawContext.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + headerH - 1, drawContext.applyAlpha(headerFill));
        drawContext.drawContext().method_25294(drawX + 1, drawY + headerH, drawX + drawW - 1, drawY + drawH - 1, drawContext.applyAlpha(this.active ? 335544320 : 251658240));
        drawContext.drawContext().method_25294(drawX, drawY + headerH - 1, drawX + drawW, drawY + headerH, drawContext.applyAlpha(accent));
        drawContext.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + 1, drawContext.applyAlpha(border));
        drawContext.drawContext().method_25294(drawX, drawY + drawH - 1, drawX + drawW, drawY + drawH, drawContext.applyAlpha(border));
        drawContext.drawContext().method_25294(drawX, drawY, drawX + 1, drawY + drawH, drawContext.applyAlpha(border));
        drawContext.drawContext().method_25294(drawX + drawW - 1, drawY, drawX + drawW, drawY + drawH, drawContext.applyAlpha(border));
        int titleX = drawX + scaledTitleLeftInset;
        int titleY = PackUiSizing.alignTextY(drawY, headerH, titleFont, context.theme().bodyTextNudge());
        int titleAreaX = drawX + scaledTitleLeftInset;
        int titleAreaWidth = Math.max(20, drawW - scaledTitleLeftInset - scaledTitleRightInset);
        if (this.titleIcon != null) {
            int iconSize = context.theme().scale(10);
            int iconY = drawY + Math.max(1, (headerH - iconSize) / 2);
            int iconX = drawX + context.theme().scale(10);
            drawContext.drawTexturedQuad(this.titleIcon, iconX, iconY, iconX + iconSize, iconY + iconSize);
            titleAreaX = drawX + scaledTitleLeftInset + context.theme().scale(14);
            titleAreaWidth = Math.max(20, drawW - (titleAreaX - drawX) - scaledTitleRightInset);
            titleX = titleAreaX;
        } else {
            if (this.centerTitle) {
                titleX = titleAreaX;
            }
        }
        String displayTitle = PackUiText.trimToWidth(drawContext.textRenderer(), this.title, titleAreaWidth, drawContext.theme().fontFor(this.titleTone), titleColor);
        if (this.centerTitle) {
            int titleWidth = PackUiText.width(drawContext.textRenderer(), displayTitle, drawContext.theme().fontFor(this.titleTone), titleColor);
            titleX = PackUiSizing.centerInside(titleAreaX, titleAreaWidth, titleWidth);
        }
        PackUiText.draw(drawContext.drawContext(), drawContext.textRenderer(), displayTitle, drawContext.theme().fontFor(this.titleTone), drawContext.applyAlpha(titleColor), titleX, titleY, false);
        if (this.shouldShowBodyArea()) {
            clipTop = Math.round(this.y + (float)headerH);
            int clipBottom = Math.round(this.y + this.height);
            if (clipBottom > clipTop) {
                drawContext.viewport().enableScissor(drawContext.drawContext(), this.x, this.y + (float)headerH, this.x + this.width, this.y + this.height);
            }
        }
        try {
            super.render(drawContext);
        }
        finally {
            drawContext.viewport().disableScissor(drawContext.drawContext());
            throw coverAlpha;
        }
        coverAlpha = 1f - this.bodyFadeAlpha;
        if (coverAlpha > 0.001f) {
            float easedCover = 1f - (float)Math.pow((double)(1f - coverAlpha), 2);
            float fadeAlpha = Math.min(0.96f, 0.1f + easedCover * 0.86f);
            drawContext.drawContext().method_25294(drawX + 1, clipTop, drawX + drawW - 1, clipBottom, PackUiRenderContext.applyAlpha(-704050933, fadeAlpha));
        }
    }

    private boolean shouldShowBodyArea() {
        return this.showBody || this.bodyFadeAlpha > 0.001f;
    }

    private void updateBodyFadeAlpha() {
        this.lastAnimationNanos = System.nanoTime();
        this.bodyFadeAlpha = this.showBody ? 1f : 0f;
    }
}
