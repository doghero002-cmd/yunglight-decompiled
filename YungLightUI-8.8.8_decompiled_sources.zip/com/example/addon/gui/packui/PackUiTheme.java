/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiAtlasTextRenderer;
import com.example.addon.gui.packui.PackUiFontRegistry;
import com.example.addon.gui.packui.PackUiIconRegistry;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiTone;
import net.minecraft.class_2960;

public final class PackUiTheme {
    public static final float DEFAULT_DENSITY = 2f;
    private static final int BODY_FONT_HEIGHT = 11;
    private static final int LABEL_FONT_HEIGHT = 12;
    private static final int TITLE_FONT_HEIGHT = 13;
    private static final int HEADER_HEIGHT = 16;
    private static final int CONTENT_PADDING = 4;
    private static final int ROW_GAP = 2;
    private static final int BUTTON_HEIGHT = 14;
    private static final int LABEL_GAP = 1;
    private final PackUiFontRegistry fonts = new PackUiFontRegistry();
    private final PackUiIconRegistry icons = new PackUiIconRegistry();
    private final int windowRadius = 0;

    public PackUiTheme() {
        this.windowRadius = 0;
        this.fonts.register("default", PackUiAssets.FONT_BODY);
        this.fonts.register("title", PackUiAssets.FONT_TITLE);
        this.fonts.register("body", PackUiAssets.FONT_BODY);
        this.fonts.register("label", PackUiAssets.FONT_LABEL);
        this.icons.register("keybinds", PackUiAssets.ICON_KEYBINDS);
        this.icons.register("lansync", PackUiAssets.ICON_LANSYNC);
        this.icons.register("macros", PackUiAssets.ICON_MACROS);
        this.icons.register("fabricator", PackUiAssets.ICON_FABRICATOR);
        this.icons.register("filter", PackUiAssets.ICON_FILTER);
        this.icons.register("packet_logger", PackUiAssets.ICON_PACKET_LOGGER);
        this.icons.register("packet_q_editor", PackUiAssets.ICON_PACKET_Q_EDITOR);
        this.icons.register("server_info", PackUiAssets.ICON_SERVER_INFO);
        this.icons.register("main_menu_category", PackUiAssets.ICON_MAIN_MENU_CATEGORY);
        this.icons.register("packet_category", PackUiAssets.ICON_PACKET_CATEGORY);
        this.icons.register("screen_category", PackUiAssets.ICON_SCREEN_CATEGORY);
        this.icons.register("chat_category", PackUiAssets.ICON_CHAT_CATEGORY);
    }

    public PackUiFontRegistry fonts() {
        return this.fonts;
    }

    public PackUiIconRegistry icons() {
        return this.icons;
    }

    public class_2960 fontFor(PackUiTone tone) {
        switch (PackUiTheme.1.$SwitchMap$com$example$addon$gui$packui$PackUiTone[tone.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                return PackUiAssets.FONT_TITLE;
            case 2::
                return PackUiAssets.FONT_LABEL;
            case 3::
            case 4::
            case 5::
                return PackUiAssets.FONT_BODY;
        }
    }

    public int windowRadius() {
        return 0;
    }

    public int headerHeight() {
        return Math.max(16, this.lineHeight(PackUiTone.LABEL, 3));
    }

    public int contentPadding() {
        return 4;
    }

    public int rowGap() {
        return 2;
    }

    public int buttonHeight() {
        return Math.max(14, this.lineHeight(PackUiTone.BODY, 3));
    }

    public int labelGap() {
        return 1;
    }

    public float scaleFactor() {
        return 1f;
    }

    public int scale(int value) {
        return value;
    }

    public float scale(float value) {
        return value;
    }

    public PackUiInsets scale(PackUiInsets insets) {
        if (insets == null) {
            return PackUiInsets.NONE;
        }
        return new PackUiInsets(this.scale(insets.left()), this.scale(insets.top()), this.scale(insets.right()), this.scale(insets.bottom()));
    }

    public int fontHeight(PackUiTone tone) {
        class_2960 fontId = this.fontFor(tone);
        if (PackUiAtlasTextRenderer.supports(fontId)) {
            if (PackUiAtlasTextRenderer.isReady()) {
                int atlasHeight = PackUiAtlasTextRenderer.height(fontId);
                if (atlasHeight > 0) {
                    return atlasHeight;
                }
            }
        }
        switch (PackUiTheme.1.$SwitchMap$com$example$addon$gui$packui$PackUiTone[tone.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                return 13;
            case 2::
                return 12;
            case 3::
            case 4::
            case 5::
                return 11;
        }
    }

    public int lineHeight(PackUiTone tone, int extraSpacing) {
        switch (PackUiTheme.1.$SwitchMap$com$example$addon$gui$packui$PackUiTone[tone.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                int minimumSpacing = 3;
                break;
            case 2::
                minimumSpacing = 2;
                break;
            case 3::
            case 4::
            case 5::
                minimumSpacing = 2;
                break;
        }
        return this.fontHeight(tone) + Math.max(this.scale(extraSpacing), minimumSpacing);
    }

    public int bodyTextNudge() {
        return 1;
    }

    public int buttonTextNudge() {
        return 1;
    }

    public int fieldTextNudge() {
        return 1;
    }

    public int color(PackUiTone tone) {
        switch (PackUiTheme.1.$SwitchMap$com$example$addon$gui$packui$PackUiTone[tone.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
            case 2::
            case 3::
                return -791321;
            case 4::
                return -4743522;
            case 5::
                return -45747;
        }
    }

    public int windowFill() {
        return -1005975028;
    }

    public int headerFill() {
        return -804187884;
    }

    public int headerAccent() {
        return -50373;
    }

    public int borderColor() {
        return -5035221;
    }

    public int borderSoft() {
        return -1435820000;
    }

    public int hoverFill() {
        return 1713245712;
    }

    public int dangerFill() {
        return -1440084462;
    }

    public int dangerBorder() {
        return -33411;
    }
}
