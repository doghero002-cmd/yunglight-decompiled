/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTone;

public class PackUiMetricLabel
extends PackUiNode {
    private String key;
    private String value;
    private int keyColor = -4743522;
    private int valueColor = -791321;

    public PackUiMetricLabel(String key, String value) {
        this.key = key == null ? "" : key;
        this.value = value == null ? "" : value;
        this.height = 9f;
    }

    public PackUiMetricLabel setKey(String key) {
        this.key = key == null ? "" : key;
        return this;
    }

    public PackUiMetricLabel setValue(String value) {
        this.value = value == null ? "" : value;
        return this;
    }

    public PackUiMetricLabel setKeyColor(int keyColor) {
        this.keyColor = keyColor;
        return this;
    }

    public PackUiMetricLabel setValueColor(int valueColor) {
        this.valueColor = valueColor;
        return this;
    }

    public PackUiMetricLabel setGrowX(boolean growX) {
        super.setGrowX(growX);
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        String combined = this.key + this.value;
        return (float)PackUiText.width(context.textRenderer(), combined, context.theme().fontFor(PackUiTone.BODY), this.valueColor);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return (float)Math.max(context.theme().fontHeight(PackUiTone.BODY) + context.theme().scale(2), context.theme().lineHeight(PackUiTone.BODY, 2));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        String keyText = this.key == null ? "" : this.key;
        String valueText = this.value == null ? "" : this.value;
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        PackUiText.draw(context.drawContext(), context.textRenderer(), keyText, context.theme().fontFor(PackUiTone.BODY), context.applyAlpha(this.keyColor), drawX, PackUiSizing.alignTextY(drawY, Math.round(this.height), context.theme().fontHeight(PackUiTone.BODY), context.theme().bodyTextNudge()), false);
        int keyWidth = PackUiText.width(context.textRenderer(), keyText, context.theme().fontFor(PackUiTone.BODY), this.keyColor);
        String trimmedValue = PackUiText.trimToWidth(context.textRenderer(), valueText, Math.max(1, Math.round(this.width) - keyWidth), context.theme().fontFor(PackUiTone.BODY), this.valueColor);
        PackUiText.draw(context.drawContext(), context.textRenderer(), trimmedValue, context.theme().fontFor(PackUiTone.BODY), context.applyAlpha(this.valueColor), drawX + keyWidth, PackUiSizing.alignTextY(drawY, Math.round(this.height), context.theme().fontHeight(PackUiTone.BODY), context.theme().bodyTextNudge()), false);
    }
}
