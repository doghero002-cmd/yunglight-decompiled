/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiAtlasTextRenderer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;

public final class PackUiText {
    private static final Map<class_2960, class_11719> FONT_CACHE = new ConcurrentHashMap();

    private PackUiText() {
    }

    public static class_5250 literal(String value, class_2960 fontId, int color) {
        return class_2561.method_43470(value == null ? "" : value).method_10862(class_2583.field_24360.method_27704(PackUiText.fontSource(fontId)).method_36139(color));
    }

    private static class_11719 fontSource(class_2960 fontId) {
        if (fontId == null) {
            return (class_11719)FONT_CACHE.computeIfAbsent(PackUiAssets.FONT_FALLBACK, class_11719.class_11721::new);
        }
        return (class_11719)FONT_CACHE.computeIfAbsent(fontId, class_11719.class_11721::new);
    }

    public static int width(class_327 renderer, String value, class_2960 fontId, int color) {
        if (PackUiAtlasTextRenderer.supports(fontId)) {
            if (PackUiAtlasTextRenderer.isReady()) {
                int w = PackUiAtlasTextRenderer.width(value, fontId);
                if (w > 0) {
                    return w;
                }
            }
        }
        return renderer.method_27525(PackUiText.literal(value, fontId, color));
    }

    public static int fontHeight(class_2960 fontId) {
        if (PackUiAtlasTextRenderer.supports(fontId)) {
            if (PackUiAtlasTextRenderer.isReady()) {
                int h = PackUiAtlasTextRenderer.height(fontId);
                if (h > 0) {
                    return h;
                }
            }
        }
        return 9;
    }

    public static String trimToWidth(class_327 renderer, String value, int maxWidth, class_2960 fontId, int color) {
        if (PackUiAtlasTextRenderer.supports(fontId) && PackUiAtlasTextRenderer.isReady()) {
            return PackUiAtlasTextRenderer.trimToWidth(value, maxWidth, fontId);
        }
        if (value == null || value.isEmpty()) {
            return "";
        }
        int allowedWidth = maxWidth + 4;
        if (PackUiText.width(renderer, value, fontId, color) <= allowedWidth) {
            return value;
        }
        String suffix = "...";
        if (PackUiText.width(renderer, suffix, fontId, color) > allowedWidth) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        String bestFit = "";
        int i = 0;
        while (i < value.length()) {
            int codePoint = value.codePointAt(i);
            builder.appendCodePoint(codePoint);
            String candidate = builder.toString();
            if (!PackUiText.width(renderer, candidate, fontId, color) <= allowedWidth) continue;
            bestFit = candidate;
            if (PackUiText.width(renderer, candidate + suffix, fontId, color) > allowedWidth) {
            } else {
                i = i + Character.charCount(codePoint);
            }
        }
        return bestFit.isEmpty() ? "" : bestFit + suffix;
    }

    public static void draw(class_332 context, class_327 renderer, String value, class_2960 fontId, int color, int x, int y, boolean shadow) {
        PackUiAtlasTextRenderer.draw(context, value, fontId, color, x, y, shadow);
        if (PackUiAtlasTextRenderer.supports(fontId) && PackUiAtlasTextRenderer.isReady()) {
            return;
        }
        context.method_51439(renderer, PackUiText.literal(value, fontId, color), x, y, color, shadow);
    }

    public static void eagerInitFonts() {
        PackUiAtlasTextRenderer.eagerInit();
    }

    public static void beginManagedLayer(class_332 context) {
        PackUiAtlasTextRenderer.beginManagedLayer(context);
    }

    public static void endManagedLayer(class_332 context) {
        PackUiAtlasTextRenderer.endManagedLayer(context);
    }

    public static void interOverlayFlush(class_332 context) {
        PackUiAtlasTextRenderer.interOverlayFlush(context);
    }
}
