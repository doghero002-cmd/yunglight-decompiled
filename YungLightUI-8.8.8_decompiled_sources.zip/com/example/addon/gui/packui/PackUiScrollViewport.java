/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.util.PackUtilUiScale;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUiScrollViewport {
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private final int rowHeight;
    private final int scrollbarWidth;
    private int contentHeight = 0;
    private int scrollOffset = 0;
    private boolean scrollbarDragging = false;
    private int scrollbarGrabOffset = 0;
    private int activeBorderColor = 0;
    private final int clipLeft;
    private final int clipTop;
    private final int clipRight;
    private final int clipBottom;

    public PackUiScrollViewport(int x, int y, int width, int height, int rowHeight, int scrollbarWidth) {
        this.x = x;
        this.y = y;
        this.width = Math.max(4, width);
        this.height = Math.max(4, height);
        this.rowHeight = Math.max(1, rowHeight);
        this.scrollbarWidth = Math.max(0, scrollbarWidth);
        this.clipLeft = this.x;
        this.clipTop = this.y;
        this.clipRight = this.x + this.width;
        this.clipBottom = this.y + this.height;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getContentWidth() {
        return this.width - this.scrollbarWidth - 3;
    }

    public int getInnerWidth() {
        return this.width - 2;
    }

    public int getRowHeight() {
        return this.rowHeight;
    }

    public int getContentHeight() {
        return this.contentHeight;
    }

    public int getScrollOffset() {
        return this.scrollOffset;
    }

    private int getViewHeight() {
        return Math.max(0, this.clipBottom - this.clipTop);
    }

    private int getEffectiveViewHeight() {
        int viewHeight = this.getViewHeight();
        if (viewHeight <= 0 || this.rowHeight <= 0) {
            return 0;
        }
        int fullRows = viewHeight / this.rowHeight;
        if (fullRows > 0) {
            return fullRows * this.rowHeight;
        }
        return viewHeight;
    }

    private int getEffectiveClipBottom() {
        return this.clipTop + this.getEffectiveViewHeight();
    }

    public void setContentHeight(int height) {
        this.contentHeight = Math.max(0, height);
        this.clampScroll();
    }

    public int getMaxScroll() {
        int viewHeight = this.getEffectiveViewHeight();
        return Math.max(0, this.contentHeight - viewHeight);
    }

    public void jumpTo(int offset) {
        this.scrollOffset = this.quantizeToSteps(Math.max(0, Math.min(offset, this.getMaxScroll())));
    }

    public void scrollBy(int deltaRows) {
        int deltaPixels = deltaRows * this.rowHeight;
        this.jumpTo(this.scrollOffset + deltaPixels);
    }

    public void scrollToBottom() {
        this.jumpTo(this.getMaxScroll());
    }

    public void scrollToTop() {
        this.jumpTo(0);
    }

    private void clampScroll() {
        int max = this.getMaxScroll();
        if (this.scrollOffset > max) {
            this.scrollOffset = this.quantizeToSteps(max);
        }
    }

    private int quantizeToSteps(int offset) {
        if (this.rowHeight <= 0) {
            return 0;
        }
        return offset / this.rowHeight * this.rowHeight;
    }

    public int getVisibleRows() {
        int viewHeight = this.getEffectiveViewHeight();
        if (viewHeight <= 0 || this.rowHeight <= 0) {
            return 0;
        }
        return (viewHeight + this.rowHeight - 1) / this.rowHeight;
    }

    public int getFirstVisibleRow() {
        if (this.rowHeight <= 0) {
            return 0;
        }
        return this.scrollOffset / this.rowHeight;
    }

    public int getLastVisibleRow() {
        int viewHeight = this.getEffectiveViewHeight();
        if (viewHeight <= 0 || this.rowHeight <= 0) {
            return -1;
        }
        int lastVisiblePixel = viewHeight - 1;
        if (this.scrollOffset < 0 || this.scrollOffset > 2147483647 - lastVisiblePixel) {
            return 2147483647 / this.rowHeight;
        }
        return (this.scrollOffset + lastVisiblePixel) / this.rowHeight;
    }

    public int getRowScreenY(int rowIndex) {
        return this.y + rowIndex * this.rowHeight - this.scrollOffset;
    }

    public boolean isRowVisible(int rowY) {
        int effectiveClipBottom = this.getEffectiveClipBottom();
        return rowY + this.rowHeight > this.clipTop && rowY < effectiveClipBottom;
    }

    public int clampY(int y) {
        return Math.max(this.clipTop, Math.min(y, this.getEffectiveClipBottom()));
    }

    public int clampHeight(int y, int height) {
        int maxBottom = Math.min(y + height, this.getEffectiveClipBottom());
        return Math.max(0, maxBottom - y);
    }

    public PackUiScrollViewport.DrawBounds getRowDrawBounds(int rowY) {
        if (!this.isRowVisible(rowY)) {
            return null;
        }
        int drawY = Math.max(rowY, this.clipTop);
        int drawBottom = Math.min(rowY + this.rowHeight, this.getEffectiveClipBottom());
        int drawHeight = drawBottom - drawY;
        if (drawHeight <= 0) {
            return null;
        }
        return new PackUiScrollViewport.DrawBounds(this.clipLeft, drawY, this.clipRight - this.clipLeft, drawHeight);
    }

    public void beginRender(class_332 ctx, int borderColor, int fillColor) {
        this.activeBorderColor = borderColor;
        ctx.method_25294(this.x, this.y, this.x + this.width, this.y + this.height, fillColor);
        PackUtilUiScale.enableOverlayScissor(ctx, this.clipLeft, this.clipTop, this.clipRight, this.clipBottom);
    }

    public void renderContent(class_332 ctx, class_327 textRenderer, List<? extends PackUiScrollViewport.ScrollRow> rows, PackUiScrollViewport.RowRenderer renderer) {
        int startRow = Math.max(0, this.getFirstVisibleRow() - 1);
        int endRow = Math.min(rows.size(), startRow + this.getVisibleRows() + 2);
        for (int i = startRow; i < endRow; i++) {
            int rowY = this.getRowScreenY(i);
            DrawBounds bounds = this.getRowDrawBounds(rowY);
            if (bounds != null) {
                ScrollRow row = (PackUiScrollViewport.ScrollRow)rows.get(i);
                renderer.render(ctx, textRenderer, row, i, bounds.x, bounds.y, bounds.width, bounds.height, rowY);
            }
        }
    }

    public void renderSimple(class_332 ctx, int totalRows, BiConsumer<Integer, PackUiScrollViewport.DrawBounds> rowRenderer) {
        int startRow = Math.max(0, this.getFirstVisibleRow() - 1);
        int endRow = Math.min(totalRows, startRow + this.getVisibleRows() + 2);
        for (int i = startRow; i < endRow; i++) {
            int rowY = this.getRowScreenY(i);
            DrawBounds bounds = this.getRowDrawBounds(rowY);
            if (bounds == null) continue;
            rowRenderer.accept(i, bounds);
        }
    }

    public void endRender(class_332 ctx) {
        ctx.method_44380();
        ctx.method_25294(this.x, this.y, this.x + this.width, this.y + 1, this.activeBorderColor);
        ctx.method_25294(this.x, this.y + this.height - 1, this.x + this.width, this.y + this.height, this.activeBorderColor);
        ctx.method_25294(this.x, this.y, this.x + 1, this.y + this.height, this.activeBorderColor);
        ctx.method_25294(this.x + this.width - 1, this.y, this.x + this.width, this.y + this.height, this.activeBorderColor);
    }

    public void renderScrollbar(class_332 ctx, double mouseX, double mouseY) {
        if (this.getMaxScroll() <= 0) {
            return;
        }
        int trackX = this.x + this.width - this.scrollbarWidth - 2;
        int trackY = this.y + 2;
        int trackWidth = this.scrollbarWidth;
        int trackHeight = this.height - 4;
        Metrics metrics = PackUiScrollbar.compute(this.contentHeight, this.getEffectiveViewHeight(), trackX, trackY, trackWidth, trackHeight, this.scrollOffset);
        boolean hovered = metrics.contains(mouseX, mouseY);
        PackUiScrollbar.draw(ctx, metrics, hovered, this.scrollbarDragging);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!this.contains(mouseX, mouseY)) {
            return false;
        }
        if (this.getMaxScroll() <= 0) {
            return false;
        }
        int deltaRows = amount > 0 ? -1 : 1;
        this.scrollBy(deltaRows);
        return true;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (this.getMaxScroll() <= 0) {
            return false;
        }
        Metrics metrics = this.getScrollbarMetrics();
        if (metrics == null) {
            return false;
        }
        if (metrics.overThumb(mouseX, mouseY)) {
            this.scrollbarDragging = true;
            this.scrollbarGrabOffset = (int)Math.round(mouseY) - metrics.thumbY();
            return true;
        }
        if (metrics.contains(mouseX, mouseY)) {
            int newScroll = PackUiScrollbar.scrollFromThumb(metrics, mouseY, this.scrollbarGrabOffset);
            this.jumpTo(this.quantizeToSteps(newScroll));
            this.scrollbarDragging = true;
            this.scrollbarGrabOffset = metrics.thumbHeight() / 2;
            return true;
        }
        return false;
    }

    public void mouseReleased() {
        this.scrollbarDragging = false;
        this.scrollbarGrabOffset = 0;
    }

    public void mouseDragged(double mouseX, double mouseY) {
        if (!this.scrollbarDragging) {
            return;
        }
        Metrics metrics = this.getScrollbarMetrics();
        if (metrics == null) {
            return;
        }
        int newScroll = PackUiScrollbar.scrollFromThumb(metrics, mouseY, this.scrollbarGrabOffset);
        this.jumpTo(this.quantizeToSteps(newScroll));
    }

    public boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }

    public PackUiScrollbar.Metrics getScrollbarMetrics() {
        if (this.getMaxScroll() <= 0) {
            return null;
        }
        int trackX = this.x + this.width - this.scrollbarWidth - 2;
        int trackY = this.y + 2;
        int trackWidth = this.scrollbarWidth;
        int trackHeight = this.height - 4;
        return PackUiScrollbar.compute(this.contentHeight, this.getEffectiveViewHeight(), trackX, trackY, trackWidth, trackHeight, this.scrollOffset);
    }

    public boolean isScrollbarDragging() {
        return this.scrollbarDragging;
    }

    public boolean isScrollbarHovered(double mouseX, double mouseY) {
        Metrics metrics = this.getScrollbarMetrics();
        return metrics != null && metrics.contains(mouseX, mouseY);
    }
}
