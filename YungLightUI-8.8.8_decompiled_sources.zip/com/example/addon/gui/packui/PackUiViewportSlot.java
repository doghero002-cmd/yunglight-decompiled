/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;

public class PackUiViewportSlot
extends PackUiNode {
    private float preferredHeight = 64f;

    public PackUiViewportSlot setPreferredHeight(float preferredHeight) {
        this.preferredHeight = Math.max(0f, preferredHeight);
        return this;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return context.theme().scale(this.preferredHeight);
    }
}
