/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButtonFeedback;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTone;

public class PackUiInfoRow
extends PackUiNode {
    private String label;
    private String value;
    private float labelWidth = 76f;
    private PackUiTone labelTone = PackUiTone.MUTED;
    private PackUiTone valueTone = PackUiTone.BODY;
    private Integer valueColorOverride;
    private int textYOffset = 0;
    private Runnable onPress;

    public PackUiInfoRow(String label, String value) {
        this.label = label == null ? "" : label;
        this.value = value == null ? "--" : value;
        this.height = 12f;
    }

    public PackUiInfoRow setLabel(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public PackUiInfoRow setValue(String value) {
        this.value = value == null ? "--" : value;
        return this;
    }

    public PackUiInfoRow setLabelWidth(float labelWidth) {
        this.labelWidth = Math.max(24f, labelWidth);
        return this;
    }

    public PackUiInfoRow setLabelTone(PackUiTone labelTone) {
        this.labelTone = labelTone == null ? PackUiTone.MUTED : labelTone;
        return this;
    }

    public PackUiInfoRow setValueTone(PackUiTone valueTone) {
        this.valueTone = valueTone == null ? PackUiTone.BODY : valueTone;
        return this;
    }

    public PackUiInfoRow setValueColorOverride(Integer valueColorOverride) {
        this.valueColorOverride = valueColorOverride;
        return this;
    }

    public PackUiInfoRow setTextYOffset(int textYOffset) {
        this.textYOffset = textYOffset;
        return this;
    }

    public PackUiInfoRow setOnPress(Runnable onPress) {
        this.onPress = onPress;
        return this;
    }

    private boolean isClickable() {
        return this.onPress != null && this.enabled;
    }

    private PackUiButtonFeedback feedbackState() {
        return PackUiButtonFeedback.forKey("info-row:" + Math.round(this.x) + ":" + Math.round(this.y) + ":" + Math.round(this.width) + ":" + Math.round(this.height) + ":" + this.label + ":" + this.value);
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        int baselineHeight = 12;
        int labelHeight = context.theme().fontHeight(this.labelTone) + context.theme().scale(3);
        int valueHeight = context.theme().fontHeight(this.valueTone) + context.theme().scale(3);
        return (float)Math.max(baselineHeight, Math.max(labelHeight, valueHeight));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        int minSegment = context.theme().scale(24);
        int labelW = Math.round(Math.min(this.labelWidth, (float)Math.max(minSegment, drawW - minSegment)));
        int valueX = drawX + labelW;
        int valueW = Math.max(1, drawW - labelW);
        boolean clickable = this.isClickable();
        boolean hovered = clickable && this.contains(context.mouseX(), context.mouseY());
        PackUiButtonFeedback feedback = clickable ? this.feedbackState() : null;
        float hover = clickable ? feedback.update(hovered, PackUiButtonFeedback.isPrimaryPointerDown(), context.mouseX() - this.x, context.mouseY() - this.y, this.width, this.height) : 0f;
        float clickGlow = clickable ? feedback.clickGlowProgress() : 0f;
        if (clickable) {
            if (hover > 0f || clickGlow > 0f) {
                int hoverTint = (int)Math.min(22f, hover * 12f + clickGlow * 8f) << 24 | 16726843;
                context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(hoverTint));
            }
            feedback.render(context.drawContext(), drawX, drawY, drawW, drawH, -37266, -12851, context.alpha());
        }
        labelColor = clickable && hovered ? PackUiSizing.lerpColor(context.theme().color(this.labelTone), -791321, 0.35f) : context.theme().color(this.labelTone);
        int valueColor = this.valueColorOverride != null ? this.valueColorOverride.intValue() : context.theme().color(this.valueTone);
        if (clickable) {
            if (hovered) {
                valueColor = PackUiSizing.lerpColor(valueColor, -2314, 0.28f);
            }
        }
        int labelTextY = PackUiSizing.alignTextY(drawY, drawH, context.theme().fontHeight(this.labelTone), context.theme().bodyTextNudge() + this.textYOffset);
        int valueTextY = PackUiSizing.alignTextY(drawY, drawH, context.theme().fontHeight(this.valueTone), context.theme().bodyTextNudge() + this.textYOffset);
        String displayLabel = PackUiText.trimToWidth(context.textRenderer(), this.label, Math.max(1, labelW - context.theme().scale(4)), context.theme().fontFor(this.labelTone), labelColor);
        String displayValue = PackUiText.trimToWidth(context.textRenderer(), this.value, Math.max(1, valueW - context.theme().scale(2)), context.theme().fontFor(this.valueTone), valueColor);
        PackUiText.draw(context.drawContext(), context.textRenderer(), displayLabel, context.theme().fontFor(this.labelTone), context.applyAlpha(labelColor), drawX, labelTextY, false);
        PackUiText.draw(context.drawContext(), context.textRenderer(), displayValue, context.theme().fontFor(this.valueTone), context.applyAlpha(valueColor), valueX, valueTextY, false);
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (button != 0 || !this.isClickable() || !this.contains(mouseX, mouseY)) {
            return false;
        }
        this.feedbackState().triggerPress(mouseX - this.x, mouseY - this.y, this.width, this.height);
        this.onPress.run();
        return true;
    }
}
