/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiVertexFormats;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import net.minecraft.class_10789;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

public final class PackUiTextPipelines {
    static final RenderPipeline UI_TEXT = RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("yunglight", "pipeline/ui_text")).withVertexFormat(PackUiVertexFormats.POS2_TEXTURE_COLOR, VertexFormat.class_5596.field_27379).withVertexShader(class_2960.method_60655("yunglight", "shaders/text.vert")).withFragmentShader(class_2960.method_60655("yunglight", "shaders/text.frag")).withSampler("u_Texture").withUniform("MeshData", class_10789.field_60031).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withBlend(BlendFunction.TRANSLUCENT).withCull(true).build();

    private PackUiTextPipelines() {
    }

    public static void precompile(class_3300 resources) {
        RenderSystem.getDevice().precompilePipeline(UI_TEXT, PackUiTextPipelines::lambda$precompile$0 /* captured: resources */);
    }

    private static String readShaderSource(class_3300 resources, class_2960 identifier) {
        class_3298 resource = (class_3298)resources.method_14486(identifier).orElseThrow(PackUiTextPipelines::lambda$readShaderSource$1 /* captured: identifier */);
        InputStream in = resource.method_14482();
        String var4 = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        if (in != null) {
            in.close();
        }
        return var4;
        L74: ;
        throw var4;
    }
}
