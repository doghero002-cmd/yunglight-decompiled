/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static enum PackUiButton.Variant {
    public static final PackUiButton.Variant PRIMARY = new PackUiButton.Variant("PRIMARY", 0);
    public static final PackUiButton.Variant SECONDARY = new PackUiButton.Variant("SECONDARY", 1);
    public static final PackUiButton.Variant GHOST = new PackUiButton.Variant("GHOST", 2);
    public static final PackUiButton.Variant DANGER = new PackUiButton.Variant("DANGER", 3);
    public static final PackUiButton.Variant SUCCESS = new PackUiButton.Variant("SUCCESS", 4);
    private static final /* synthetic */ PackUiButton.Variant[] $VALUES;

    public static PackUiButton.Variant[] values() {
        return (PackUiButton.Variant[])$VALUES.clone();
    }

    public static PackUiButton.Variant valueOf(String name) {
        return (PackUiButton.Variant)Enum.valueOf(PackUiButton.Variant.class, name);
    }

    private PackUiButton.Variant() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUiButton.Variant.$values();
    }
}
