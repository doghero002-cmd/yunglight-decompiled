/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiTextMeshBuilder;
import com.example.addon.gui.packui.PackUiTextMeshRenderer;
import com.example.addon.gui.packui.PackUiTextTexture;
import com.example.addon.mixininterface.PackUtilGameRendererAccess;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTTPackContext;
import org.lwjgl.stb.STBTTPackRange;
import org.lwjgl.stb.STBTTPackedchar;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.system.MemoryStack;

final class PackUiAtlasTextRenderer {
    private static final String FONT_RESOURCE_PATH = "/assets/yunglight/font/dm_sans/pack_ui_regular.ttf";
    private static final int ATLAS_SIZE = 2048;
    private static final Map<PackUiAtlasTextRenderer.FontRole, PackUiAtlasTextRenderer.PackUiAtlasFont> FONT_CACHE = new ConcurrentHashMap();
    private static class_332 managedContext;
    private static int managedLayerDepth;
    private static final PackUiTextMeshBuilder frameMesh = new PackUiTextMeshBuilder();
    private static boolean batching;
    private static PackUiTextTexture batchTexture;
    private static ByteBuffer cachedFontBuffer;
    private static final AtomicBoolean fontsReady = new AtomicBoolean(false);
    private static final AtomicBoolean initStarted = new AtomicBoolean(false);
    private static final Map<PackUiAtlasTextRenderer.FontRole, PackUiAtlasTextRenderer.PrecomputedAtlas> precomputedAtlases = new ConcurrentHashMap();

    private PackUiAtlasTextRenderer() {
    }

    public static void eagerInit() {
        if (!initStarted.compareAndSet(false, true)) {
            return;
        }
        try {
            ByteBuffer fontBuffer = PackUiAtlasTextRenderer.getCachedFontBuffer();
            PrecomputedAtlas shared = PackUiAtlasTextRenderer.precomputeSharedAtlas(fontBuffer);
            var var2 = PackUiAtlasTextRenderer.FontRole.values();
            var var3 = var2.length;
            for (int var4 = 0; var4 < var3; var4++) {
                FontRole role = var2[var4];
                precomputedAtlases.put(role, shared);
            }
            fontsReady.set(true);
        }
        catch (IOException e) {
            fontsReady.set(false);
            L79: ;
            return;
        }
    }

    public static boolean isReady() {
        return fontsReady.get();
    }

    public static boolean supports(class_2960 fontId) {
        return PackUiAssets.FONT_BODY.equals(fontId) || PackUiAssets.FONT_LABEL.equals(fontId) || PackUiAssets.FONT_TITLE.equals(fontId) || PackUiAssets.FONT_FALLBACK.equals(fontId);
    }

    public static int width(String value, class_2960 fontId) {
        if (!PackUiAtlasTextRenderer.supports(fontId) || value == null || value.isEmpty()) {
            return 0;
        }
        PackUiAtlasFont f = PackUiAtlasTextRenderer.fontOrNull(fontId);
        if (f == null) {
            return 0;
        }
        return f.width(value);
    }

    public static int height(class_2960 fontId) {
        if (!PackUiAtlasTextRenderer.supports(fontId)) {
            return 0;
        }
        PackUiAtlasFont f = PackUiAtlasTextRenderer.fontOrNull(fontId);
        if (f == null) {
            return 0;
        }
        return f.height();
    }

    public static String trimToWidth(String value, int maxWidth, class_2960 fontId) {
        if (PackUiAtlasTextRenderer.supports(fontId)) {
            if (value == null) { /* goto @18; */ }
        }
        return value == null ? "" : value;
        if (maxWidth <= 0) {
            return "";
        }
        PackUiAtlasFont font = PackUiAtlasTextRenderer.fontOrNull(fontId);
        if (font == null) {
            return value;
        }
        int allowedWidth = maxWidth + 4;
        if (font.width(value) <= allowedWidth) {
            return value;
        }
        String suffix = "...";
        int suffixWidth = font.width(suffix);
        if (suffixWidth > allowedWidth) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        String bestFit = "";
        int i = 0;
        while (i < value.length()) {
            int codePoint = value.codePointAt(i);
            builder.appendCodePoint(codePoint);
            String candidate = builder.toString();
            if (!font.width(candidate) <= allowedWidth) continue;
            bestFit = candidate;
            if (font.width(candidate + suffix) > allowedWidth) {
            } else {
                i = i + Character.charCount(codePoint);
            }
        }
        return bestFit.isEmpty() ? "" : bestFit + suffix;
    }

    public static void draw(class_332 context, String value, class_2960 fontId, int color, int x, int y, boolean shadow) {
        if (context == null || value == null || value.isEmpty()) {
            return;
        }
        if (!PackUiAtlasTextRenderer.supports(fontId)) {
            return;
        }
        PackUiAtlasFont f = PackUiAtlasTextRenderer.fontOrNull(fontId);
        if (f == null) {
            return;
        }
        if (batching) {
            if (batchTexture != null) {
                if (batchTexture != f.texture) {
                    PackUiAtlasTextRenderer.flushCurrentBatch();
                }
            }
            if (batchTexture == null) {
                batchTexture = f.texture;
            }
            f.appendTo(frameMesh, value, color, x, y, shadow);
        } else {
            PackUiAtlasTextRenderer.flushGuiState();
            context.method_71048();
            frameMesh.begin();
            f.appendTo(frameMesh, value, color, x, y, shadow);
            PackUiTextMeshRenderer.draw(frameMesh, f.texture, context.method_51448());
        }
    }

    static void beginBatch() {
        if (batching) {
            return;
        }
        frameMesh.begin();
        batchTexture = null;
        batching = true;
    }

    private static void flushCurrentBatch() {
        if (batchTexture == null || managedContext == null) {
            return;
        }
        PackUiTextMeshRenderer.draw(frameMesh, batchTexture, managedContext.method_51448());
        frameMesh.begin();
        batchTexture = null;
    }

    static void endBatch(class_332 context) {
        if (!batching) {
            return;
        }
        batching = false;
        if (context == null || batchTexture == null) {
            if (frameMesh.isBuilding()) {
                frameMesh.end();
            }
            return;
        }
        PackUiAtlasTextRenderer.flushGuiState();
        context.method_71048();
        PackUiTextMeshRenderer.draw(frameMesh, batchTexture, context.method_51448());
        batchTexture = null;
    }

    static void interOverlayFlush(class_332 context) {
        if (!batching || managedContext == null) {
            return;
        }
        PackUiAtlasTextRenderer.endBatch(context);
        context.method_71048();
        PackUiAtlasTextRenderer.beginBatch();
    }

    static void beginManagedLayer(class_332 context) {
        if (context == null) {
            return;
        }
        if (managedContext == context) {
            managedLayerDepth = managedLayerDepth + 1;
            return;
        }
        if (managedLayerDepth > 0) {
            return;
        }
        managedContext = context;
        managedLayerDepth = 1;
        PackUiAtlasTextRenderer.beginBatch();
    }

    static void endManagedLayer(class_332 context) {
        if (context == null || managedContext != context) {
            return;
        }
        managedLayerDepth = managedLayerDepth - 1;
        if (managedLayerDepth > 0) {
            return;
        }
        PackUiAtlasTextRenderer.endBatch(context);
        context.method_71048();
        managedContext = null;
        managedLayerDepth = 0;
    }

    private static void flushGuiState() {
        var var1 = class_310.method_1551().field_1773;
        if (var1 instanceof PackUtilGameRendererAccess) {
            PackUtilGameRendererAccess access = (PackUtilGameRendererAccess)var1;
            access.packutil$flushGuiState();
        }
    }

    public static void resetFrameUploadGate() {
    }

    private static PackUiAtlasTextRenderer.PackUiAtlasFont fontOrNull(class_2960 fontId) {
        FontRole role = PackUiAtlasTextRenderer.FontRole.fromIdentifier(fontId);
        PackUiAtlasFont cached = (PackUiAtlasTextRenderer.PackUiAtlasFont)FONT_CACHE.get(role);
        if (cached != null) {
            return cached;
        }
        if (!fontsReady.get()) {
            return null;
        }
        PrecomputedAtlas pre = (PackUiAtlasTextRenderer.PrecomputedAtlas)precomputedAtlases.get(PackUiAtlasTextRenderer.FontRole.BODY);
        if (pre == null) {
            return null;
        }
        PackUiTextTexture sharedTexture = new PackUiTextTexture(2048, 2048);
        sharedTexture.upload(pre.bitmap);
        var var5 = PackUiAtlasTextRenderer.FontRole.values();
        var var6 = var5.length;
        for (int var7 = 0; var7 < var6; var7++) {
            FontRole r = var5[var7];
            FONT_CACHE.put(r, new PackUiAtlasTextRenderer.PackUiAtlasFont(pre, r, sharedTexture));
        }
        return (PackUiAtlasTextRenderer.PackUiAtlasFont)FONT_CACHE.get(role);
    }

    private static PackUiAtlasTextRenderer.PrecomputedAtlas precomputeSharedAtlas(ByteBuffer fontBuffer) {
        fontBuffer.rewind();
        STBTTFontinfo fontInfo = STBTTFontinfo.create();
        if (!STBTruetype.stbtt_InitFont(fontInfo, fontBuffer)) {
            throw new IllegalStateException("Failed to initialize font /assets/yunglight/font/dm_sans/pack_ui_regular.ttf");
        }
        int packedHeight = PackUiAtlasTextRenderer.packedPixelHeight(PackUiAtlasTextRenderer.FontRole.TITLE);
        ByteBuffer bitmap = BufferUtils.createByteBuffer(4194304);
        STBTTPackContext packContext = STBTTPackContext.create();
        STBTTPackedchar.Buffer[] tmp0 = new STBTTPackedchar.Buffer[6];
        tmp0[0] = STBTTPackedchar.create(95);
        tmp0[1] = STBTTPackedchar.create(96);
        tmp0[2] = STBTTPackedchar.create(128);
        tmp0[3] = STBTTPackedchar.create(144);
        tmp0[4] = STBTTPackedchar.create(256);
        tmp0[5] = STBTTPackedchar.create(1);
        Buffer[] packedRanges = tmp0;
        STBTruetype.stbtt_PackBegin(packContext, bitmap, 2048, 2048, 0, 1);
        STBTruetype.stbtt_PackSetOversampling(packContext, 2, 2);
        Buffer packRanges = STBTTPackRange.create(packedRanges.length);
        packRanges.put(STBTTPackRange.create().set((float)packedHeight, 32, null, 95, packedRanges[0], 2, 2));
        packRanges.put(STBTTPackRange.create().set((float)packedHeight, 160, null, 96, packedRanges[1], 2, 2));
        packRanges.put(STBTTPackRange.create().set((float)packedHeight, 256, null, 128, packedRanges[2], 2, 2));
        packRanges.put(STBTTPackRange.create().set((float)packedHeight, 880, null, 144, packedRanges[3], 2, 2));
        packRanges.put(STBTTPackRange.create().set((float)packedHeight, 1024, null, 256, packedRanges[4], 2, 2));
        packRanges.put(STBTTPackRange.create().set((float)packedHeight, 8734, null, 1, packedRanges[5], 2, 2));
        packRanges.flip();
        STBTruetype.stbtt_PackFontRanges(packContext, fontBuffer, 0, packRanges);
        STBTruetype.stbtt_PackEnd(packContext);
        float stbScale = STBTruetype.stbtt_ScaleForPixelHeight(fontInfo, (float)packedHeight);
        MemoryStack stack = MemoryStack.stackPush();
        try {
            IntBuffer ascentBuffer = stack.mallocInt(1);
            STBTruetype.stbtt_GetFontVMetrics(fontInfo, ascentBuffer, null, null);
            int fontAscent = ascentBuffer.get(0);
        }
        catch (Throwable i) {
            if (stack == null) { /* goto L386; */ }
            stack.close();
            /* goto L386; */
            Buffer chars = null;
            i.addSuppressed(chars);
            L386: ;
            throw i;
        }
        try {
            stack.close();
        }
        catch (Throwable chars) {
            i.addSuppressed(chars);
            L386: ;
            throw i;
        }
        throw i;
        L389: ;
        glyphs = new HashMap();
        for (i = 0; i < packedRanges.length; i++) {
            chars = packedRanges[i];
            int offset = ((STBTTPackRange)packRanges.get(i)).first_unicode_codepoint_in_range();
            for (int j = 0; j < chars.capacity(); j++) {
                STBTTPackedchar glyph = (STBTTPackedchar)chars.get(j);
                glyphs.put(j + offset, new PackUiAtlasTextRenderer.Glyph(glyph.xoff(), glyph.yoff(), glyph.xoff2(), glyph.yoff2(), (float)glyph.x0() / 2048f, (float)glyph.y0() / 2048f, (float)glyph.x1() / 2048f, (float)glyph.y1() / 2048f, glyph.xadvance()));
            }
        }
        fallbackGlyph = (PackUiAtlasTextRenderer.Glyph)glyphs.getOrDefault(32, new PackUiAtlasTextRenderer.Glyph(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, Math.max(2f, (float)packedHeight / 3f)));
        ascent = (float)fontAscent * stbScale;
        return new PackUiAtlasTextRenderer.PrecomputedAtlas(glyphs, fallbackGlyph, ascent, packedHeight, bitmap);
    }

    private static synchronized ByteBuffer getCachedFontBuffer() throws IOException {
        if (cachedFontBuffer != null) {
            cachedFontBuffer.rewind();
            return cachedFontBuffer;
        }
        InputStream input = PackUiAtlasTextRenderer.class.getResourceAsStream("/assets/yunglight/font/dm_sans/pack_ui_regular.ttf");
        try {
            if (input == null) {
                throw new IOException("Missing font resource /assets/yunglight/font/dm_sans/pack_ui_regular.ttf");
            }
            byte[] bytes = input.readAllBytes();
            ByteBuffer buffer = BufferUtils.createByteBuffer(bytes.length);
            buffer.put(bytes);
            buffer.flip();
            cachedFontBuffer = buffer;
            var var3 = buffer;
        }
        catch (Throwable bytes) {
            if (input == null) { /* goto L96; */ }
            input.close();
            /* goto L96; */
            buffer = null;
            bytes.addSuppressed(buffer);
            L96: ;
            throw bytes;
        }
        try {
            input.close();
        }
        catch (Throwable buffer) {
            bytes.addSuppressed(buffer);
            L96: ;
            throw bytes;
        }
        throw bytes;
    }

    private static int packedPixelHeight(PackUiAtlasTextRenderer.FontRole role) {
        switch (role.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
            case 3::
                return 30;
            case 1::
                return 33;
            case 2::
                return 36;
        }
    }

    private static int displayPixelHeight(PackUiAtlasTextRenderer.FontRole role) {
        switch (role.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
            case 3::
                return 11;
            case 1::
                return 12;
            case 2::
                return 13;
        }
    }
}
