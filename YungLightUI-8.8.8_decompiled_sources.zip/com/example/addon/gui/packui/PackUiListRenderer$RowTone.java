/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static enum PackUiListRenderer.RowTone {
    public static final PackUiListRenderer.RowTone NORMAL = new PackUiListRenderer.RowTone("NORMAL", 0);
    public static final PackUiListRenderer.RowTone READY = new PackUiListRenderer.RowTone("READY", 1);
    public static final PackUiListRenderer.RowTone WARNING = new PackUiListRenderer.RowTone("WARNING", 2);
    public static final PackUiListRenderer.RowTone DANGER = new PackUiListRenderer.RowTone("DANGER", 3);
    private static final /* synthetic */ PackUiListRenderer.RowTone[] $VALUES;

    public static PackUiListRenderer.RowTone[] values() {
        return (PackUiListRenderer.RowTone[])$VALUES.clone();
    }

    public static PackUiListRenderer.RowTone valueOf(String name) {
        return (PackUiListRenderer.RowTone)Enum.valueOf(PackUiListRenderer.RowTone.class, name);
    }

    private PackUiListRenderer.RowTone() {
        super(var1, var2);
    }

    static {
        $VALUES = PackUiListRenderer.RowTone.$values();
    }
}
