/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiColumn;
import com.example.addon.gui.packui.PackUiContainer;
import com.example.addon.gui.packui.PackUiHeaderControls;
import com.example.addon.gui.packui.PackUiInsets;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTone;

public class PackUiAccordionSection
extends PackUiContainer {
    private static final float BODY_FADE_DURATION_SECONDS = 0.14f;
    private final PackUiColumn content = new PackUiColumn();
    private String title;
    private boolean expanded = true;
    private float bodyFadeAlpha = 1f;
    private int headerHeight = 18;
    private int contentTopGap = 2;
    private long lastAnimationNanos = System.nanoTime();

    public PackUiAccordionSection(String title) {
        this.title = title == null ? "" : title;
        this.content.setPadding(PackUiInsets.NONE).setGap(2);
        this.add(this.content);
    }

    public PackUiColumn content() {
        return this.content;
    }

    public PackUiAccordionSection setTitle(String title) {
        this.title = title == null ? "" : title;
        return this;
    }

    public PackUiAccordionSection setExpanded(boolean expanded) {
        this.expanded = expanded;
        return this;
    }

    public PackUiAccordionSection syncExpanded(boolean expanded) {
        this.expanded = expanded;
        this.bodyFadeAlpha = expanded ? 1f : 0f;
        this.lastAnimationNanos = System.nanoTime();
        return this;
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public PackUiAccordionSection setHeaderHeight(int headerHeight) {
        this.headerHeight = Math.max(12, headerHeight);
        return this;
    }

    public PackUiAccordionSection setContentTopGap(int contentTopGap) {
        this.contentTopGap = Math.max(0, contentTopGap);
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        return Math.max((float)(PackUiText.width(context.textRenderer(), this.title, context.theme().fontFor(PackUiTone.LABEL), context.theme().color(PackUiTone.LABEL)) + context.theme().scale(18)), this.content.preferredWidth(context));
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        this.updateBodyFadeAlpha();
        int scaledHeaderHeight = Math.max(context.theme().scale(this.headerHeight), context.theme().lineHeight(PackUiTone.LABEL, 4));
        if (!this.shouldShowBodyArea()) {
            return (float)scaledHeaderHeight;
        }
        int scaledContentTopGap = context.theme().scale(this.contentTopGap);
        float bodyHeight = (float)scaledContentTopGap + this.content.preferredHeight(context, availableWidth);
        return (float)scaledHeaderHeight + bodyHeight;
    }

    protected void layoutChildren(PackUiRenderContext context) {
        this.updateBodyFadeAlpha();
        int scaledHeaderHeight = Math.max(context.theme().scale(this.headerHeight), context.theme().lineHeight(PackUiTone.LABEL, 4));
        int scaledContentTopGap = context.theme().scale(this.contentTopGap);
        boolean showContent = this.shouldShowBodyArea();
        float contentY = this.y + (float)scaledHeaderHeight + (showContent ? (float)scaledContentTopGap : 0f);
        float contentH = showContent ? Math.max(0f, this.height - (float)scaledHeaderHeight - (float)scaledContentTopGap) : 0f;
        this.content.setVisible(showContent);
        this.content.setBounds(this.x, contentY, this.width, contentH);
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        this.updateBodyFadeAlpha();
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawHeaderH = Math.max(context.theme().scale(this.headerHeight), context.theme().lineHeight(PackUiTone.LABEL, 4));
        boolean hovered = context.mouseX() >= this.x && context.mouseX() <= this.x + this.width && context.mouseY() >= this.y && context.mouseY() <= this.y + (float)drawHeaderH;
        float hover = this.updateHover(hovered, context.delta());
        int fill = this.expanded ? -787344874 : -1206972653;
        int border = context.theme().borderColor();
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawHeaderH, context.applyAlpha(fill));
        if (hover > 0f) {
            int hoverTint = (int)(hover * 18f) << 24 | 16726843;
            context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + drawHeaderH - 1, context.applyAlpha(hoverTint));
        }
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + 1, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY + drawHeaderH - 1, drawX + drawW, drawY + drawHeaderH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY, drawX + 1, drawY + drawHeaderH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX + drawW - 1, drawY, drawX + drawW, drawY + drawHeaderH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + 2, context.applyAlpha(896213538));
        context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + 2, drawY + drawHeaderH - 1, context.applyAlpha(896213538));
        context.drawContext().method_25294(drawX + 1, drawY + drawHeaderH - 2, drawX + drawW - 1, drawY + drawHeaderH - 1, context.applyAlpha(570425344));
        context.drawContext().method_25294(drawX + drawW - 2, drawY + 1, drawX + drawW - 1, drawY + drawHeaderH - 1, context.applyAlpha(570425344));
        titleColor = context.theme().color(PackUiTone.LABEL);
        int titleY = PackUiSizing.alignTextY(drawY, drawHeaderH, context.theme().fontHeight(PackUiTone.LABEL), context.theme().bodyTextNudge());
        PackUiText.draw(context.drawContext(), context.textRenderer(), this.title, context.theme().fontFor(PackUiTone.LABEL), context.applyAlpha(titleColor), drawX + context.theme().scale(6), titleY, false);
        int toggleSize = context.theme().scale(10);
        int toggleX = drawX + drawW - context.theme().scale(6) - toggleSize;
        int toggleY = drawY + Math.max(1, (drawHeaderH - toggleSize) / 2);
        PackUiHeaderControls.drawAnimatedArrow(context.drawContext(), toggleX, toggleY, toggleSize, this.expanded ? 1f : 0f, 1f);
        if (this.shouldShowBodyArea()) {
            int clipTop = Math.round(this.y + (float)drawHeaderH);
            int clipBottom = Math.round(this.y + this.height);
            if (clipBottom > clipTop) {
                context.viewport().enableScissor(context.drawContext(), this.x, this.y + (float)drawHeaderH, this.x + this.width, this.y + this.height);
            }
        }
        try {
            super.render(context);
        }
        finally {
            context.viewport().disableScissor(context.drawContext());
            throw coverAlpha;
        }
        coverAlpha = 1f - this.bodyFadeAlpha;
        if (coverAlpha > 0.001f) {
            float easedCover = 1f - (float)Math.pow((double)(1f - coverAlpha), 2);
            float fadeAlpha = Math.min(0.96f, 0.1f + easedCover * 0.86f);
            context.drawContext().method_25294(drawX + 1, clipTop, drawX + drawW - 1, clipBottom, PackUiRenderContext.applyAlpha(-704050933, fadeAlpha));
        }
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        int scaledHeaderHeight = Math.max(context.theme().scale(this.headerHeight), context.theme().lineHeight(PackUiTone.LABEL, 4));
        if (button != 0) { /* goto L95; */ }
        if (mouseX < this.x) { /* goto L95; */ }
        if (mouseX > this.x + this.width) { /* goto L95; */ }
        if (mouseY < this.y) { /* goto L95; */ }
        if (mouseY > this.y + (float)scaledHeaderHeight) { /* goto L95; */ }
        this.expanded = !this.expanded;
        return true;
        return this.expanded && super.mouseClicked(context, mouseX, mouseY, button);
    }

    private boolean shouldShowBodyArea() {
        return this.expanded || this.bodyFadeAlpha > 0.001f;
    }

    private void updateBodyFadeAlpha() {
        long now = System.nanoTime();
        float elapsedSeconds = Math.max(0f, (float)(now - this.lastAnimationNanos) / 1000000000f);
        this.lastAnimationNanos = now;
        float target = this.expanded ? 1f : 0f;
        if (this.bodyFadeAlpha == target) {
            return;
        }
        float step = Math.min(1f, elapsedSeconds / 0.14f);
        if (target > this.bodyFadeAlpha) {
            this.bodyFadeAlpha = Math.min(target, this.bodyFadeAlpha + step);
        } else {
            this.bodyFadeAlpha = Math.max(target, this.bodyFadeAlpha - step);
        }
        if (Math.abs(this.bodyFadeAlpha - target) < 0.01f) {
            this.bodyFadeAlpha = target;
        }
    }
}
