/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButtonFeedback;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.PackUtilText;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUiOverlayButton {
    private static final PackUiTheme THEME = new PackUiTheme();
    private static final int HORIZONTAL_PADDING = 4;
    public boolean active = true;
    public boolean visible = true;
    private int x;
    private int y;
    private int width;
    private int height;
    private class_2561 message;
    private PackUiOverlayButton.Variant variant = PackUiOverlayButton.Variant.SECONDARY;
    private PackUiTone tone = PackUiTone.BODY;
    private final PackUiOverlayButton.PressAction primaryAction;
    private final PackUiOverlayButton.PressAction secondaryAction;

    private static class_2960 resolvedFont(int height) {
        return THEME.fontFor(PackUiTone.BODY);
    }

    private static int fittedWidth(int requestedWidth, int height, class_2561 message) {
        if (requestedWidth > 0) {
            return requestedWidth;
        }
        class_310 client = class_310.method_1551();
        class_327 renderer = client == null ? null : client.field_1772;
        if (renderer == null) {
            return requestedWidth;
        }
        String label = PackUtilText.sanitizeUiLabel(message == null ? "" : message.getString());
        class_2960 font = PackUiOverlayButton.resolvedFont(height);
        int measured = PackUiSizing.fitTextWidthInt(renderer, label, font, THEME.color(PackUiTone.BODY), 4, requestedWidth, 2147483647);
        return Math.max(requestedWidth, measured);
    }

    private PackUiOverlayButton(int x, int y, int width, int height, class_2561 message, PackUiOverlayButton.PressAction primaryAction, PackUiOverlayButton.PressAction secondaryAction) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.message = message == null ? class_2561.method_43473() : message;
        this.primaryAction = primaryAction;
        this.secondaryAction = secondaryAction;
    }

    public static PackUiOverlayButton create(int x, int y, int width, int height, class_2561 message, PackUiOverlayButton.PressAction pressAction) {
        return new PackUiOverlayButton(x, y, PackUiOverlayButton.fittedWidth(width, height, message), height, message, pressAction, null);
    }

    public static PackUiOverlayButton create(int x, int y, int width, int height, class_2561 message, PackUiOverlayButton.PressAction pressAction, PackUiOverlayButton.PressAction secondaryPressAction) {
        return new PackUiOverlayButton(x, y, PackUiOverlayButton.fittedWidth(width, height, message), height, message, pressAction, secondaryPressAction);
    }

    public PackUiOverlayButton setTone(PackUiTone tone) {
        this.tone = tone == null ? PackUiTone.BODY : tone;
        return this;
    }

    public static boolean fireIfHit(PackUiOverlayButton button, double mouseX, double mouseY, int mouseButton) {
        if (button == null || !button.visible || !button.active) {
            return false;
        }
        if (mouseButton == 0) { /* goto L31; */ }
        if (mouseButton != 1 || !button.contains(mouseX, mouseY)) {
            return false;
        }
        PackUiOverlayButton.feedbackFor(button).triggerPress((float)(mouseX - (double)button.x), (float)(mouseY - (double)button.y), (float)button.width, (float)button.height);
        PressAction action = mouseButton == 1 ? button.secondaryAction : button.primaryAction;
        if (action == null) {
            return false;
        }
        action.onPress(button);
        return true;
    }

    public static void renderStyled(class_332 context, class_327 textRenderer, PackUiOverlayButton button, int mouseX, int mouseY) {
        if (button == null || !button.visible) {
            return;
        }
        String label = PackUtilText.sanitizeUiLabel(button.message.getString());
        String upperLabel = label.toUpperCase();
        boolean compactSymbol = label.length() == 1 && button.width <= 14;
        PackUiTone resolvedTone = compactSymbol ? PackUiTone.LABEL : button.tone;
        class_2960 font = THEME.fontFor(resolvedTone);
        boolean inferredDanger = "x".equalsIgnoreCase(label) || label.toLowerCase().contains("delete") || label.toLowerCase().contains("clear");
        boolean toggleOn = label.startsWith("[x]") || label.startsWith("[X]") || label.startsWith("[✓]") || upperLabel.equals("ON") || upperLabel.endsWith(": ON") || upperLabel.equals("MODE: ENABLE") || upperLabel.equals("ENABLE") || upperLabel.equals("ENABLED") || upperLabel.endsWith(": ENABLED");
        boolean toggleOff = label.startsWith("[ ]") || upperLabel.equals("OFF") || upperLabel.endsWith(": OFF") || upperLabel.equals("MODE: DISABLE") || upperLabel.equals("DISABLE") || upperLabel.equals("DISABLED") || upperLabel.endsWith(": DISABLED");
        Variant variant = button.variant;
        if (variant == PackUiOverlayButton.Variant.SECONDARY) {
            if (inferredDanger) {
                variant = PackUiOverlayButton.Variant.DANGER;
            }
        }
        if (variant == PackUiOverlayButton.Variant.SECONDARY) {
            if (toggleOn) {
                variant = PackUiOverlayButton.Variant.SUCCESS;
            }
        }
        if (variant == PackUiOverlayButton.Variant.SECONDARY) {
            if (toggleOff) {
                variant = PackUiOverlayButton.Variant.DANGER;
            }
        }
        boolean hovered = button.contains((double)mouseX, (double)mouseY);
        PackUiButtonFeedback feedback = PackUiOverlayButton.feedbackFor(button);
        float hover = feedback.update(hovered && button.active, button.active && PackUiButtonFeedback.isPrimaryPointerDown(), (float)(mouseX - button.x), (float)(mouseY - button.y), (float)button.width, (float)button.height);
        float clickGlow = feedback.clickGlowProgress();
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 3::
                int bg = -1366352092;
                break;
            case 0::
                bg = button.active ? 1947142925 : -1609428202;
                break;
            case 4::
                bg = button.active ? 1209142543 : 705827606;
                break;
            case 1::
                bg = button.active ? -1910895600 : -1609428202;
                break;
            case 2::
                bg = button.active ? -2012207590 : -1609428202;
                break;
        }
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 3::
                int border = -30841;
                break;
            case 0::
            case 4::
                border = button.active ? THEME.borderSoft() : -9744304;
                break;
            case 1::
                border = -4896696;
                break;
            case 2::
                border = -8269408;
                break;
        }
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 3::
                int borderGlow = -23388;
                break;
            case 0::
            case 4::
                borderGlow = -39836;
                break;
            case 1::
                borderGlow = -28528;
                break;
            case 2::
                borderGlow = -5575744;
                break;
        }
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 3::
                int textColor = -2828;
                break;
            case 0::
            case 4::
                textColor = button.active ? THEME.color(PackUiTone.BODY) : THEME.color(PackUiTone.MUTED);
                break;
            case 1::
                textColor = button.active ? -42406 : -6521989;
                break;
            case 2::
                textColor = button.active ? -4656181 : -7821680;
                break;
        }
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 3::
                int rippleRing = -19790;
                break;
            case 0::
            case 4::
                rippleRing = -36752;
                break;
            case 1::
                rippleRing = -30070;
                break;
            case 2::
                rippleRing = -6363465;
                break;
        }
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 3::
                int rippleFill = -7711;
                break;
            case 0::
            case 4::
                rippleFill = -13622;
                break;
            case 1::
                rippleFill = -11823;
                break;
            case 2::
                rippleFill = -2623518;
                break;
        }
        float hoverVisual = Math.max(hover * 0.9f, clickGlow * 0.55f);
        border = PackUiSizing.lerpColor(border, borderGlow, Math.min(1f, hover * 0.35f + clickGlow * 0.85f));
        context.method_25294(button.x, button.y, button.x + button.width, button.y + button.height, bg);
        context.method_25294(button.x, button.y, button.x + button.width, button.y + 1, border);
        context.method_25294(button.x, button.y + button.height - 1, button.x + button.width, button.y + button.height, border);
        context.method_25294(button.x, button.y, button.x + 1, button.y + button.height, border);
        context.method_25294(button.x + button.width - 1, button.y, button.x + button.width, button.y + button.height, border);
        if (hoverVisual <= 0f) { /* goto L1445; */ }
        if (!button.active) { /* goto L1445; */ }
        switch (variant.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 2::
                int hoverTint = (int)Math.min(38f, hover * 24f + clickGlow * 12f) << 24 | 3332202;
                break;
            case 1::
                hoverTint = (int)Math.min(38f, hover * 24f + clickGlow * 12f) << 24 | 16726843;
                break;
            case 3::
                hoverTint = (int)Math.min(38f, hover * 24f + clickGlow * 12f) << 24 | 16735838;
                break;
            case 0::
            case 4::
                hoverTint = (int)Math.min(30f, hover * 18f + clickGlow * 10f) << 24 | 16726843;
                break;
        }
        context.method_25294(button.x + 1, button.y + 1, button.x + button.width - 1, button.y + button.height - 1, hoverTint);
        L1445: ;
        pressGlow = (int)(clickGlow * 14f) << 24 | rippleFill & 16777215;
        if (clickGlow > 0f && button.active) {
            context.method_25294(button.x + 1, button.y + 1, button.x + button.width - 1, button.y + button.height - 1, pressGlow);
        }
        feedback.render(context, button.x + 1, button.y + 1, Math.max(0, button.width - 2), Math.max(0, button.height - 2), rippleRing, rippleFill, 1f);
        availableTextWidth = Math.max(1, button.width - (compactSymbol ? 2 : 6));
        String displayText = PackUiText.trimToWidth(textRenderer, label, availableTextWidth, font, textColor);
        int textWidth = PackUiText.width(textRenderer, displayText, font, textColor);
        int textX = button.x + Math.max(2, (button.width - textWidth) / 2);
        int textY = PackUiSizing.alignTextY(button.y, button.height, THEME.fontHeight(resolvedTone), compactSymbol ? 0 : THEME.buttonTextNudge());
        PackUiText.draw(context, textRenderer, displayText, font, textColor, textX, textY, false);
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return this.height;
    }

    public class_2561 getMessage() {
        return this.message;
    }

    public void setMessage(class_2561 message) {
        this.message = message == null ? class_2561.method_43473() : message;
    }

    public PackUiOverlayButton.Variant getVariant() {
        return this.variant;
    }

    public PackUiOverlayButton setVariant(PackUiOverlayButton.Variant variant) {
        this.variant = variant == null ? PackUiOverlayButton.Variant.SECONDARY : variant;
        return this;
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY < (double)(this.y + this.height);
    }

    private static PackUiButtonFeedback feedbackFor(PackUiOverlayButton button) {
        return PackUiButtonFeedback.forKey("overlay:" + button.x + ":" + button.y + ":" + button.width + ":" + button.height + ":" + String.valueOf(button.variant) + ":" + String.valueOf(button.tone) + ":" + PackUtilText.sanitizeUiLabel(button.message == null ? "" : button.message.getString()));
    }
}
