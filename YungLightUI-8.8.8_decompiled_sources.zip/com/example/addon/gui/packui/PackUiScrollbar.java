/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiTheme;
import net.minecraft.class_332;

public final class PackUiScrollbar {
    private static final PackUiTheme THEME = new PackUiTheme();

    private PackUiScrollbar() {
    }

    public static PackUiScrollbar.Metrics compute(int contentPixels, int viewPixels, int trackX, int trackY, int trackWidth, int trackHeight, int scrollOffset) {
        return PackUiScrollbar.compute(contentPixels, viewPixels, trackX, trackY, trackWidth, trackHeight, (float)scrollOffset);
    }

    public static PackUiScrollbar.Metrics compute(int contentPixels, int viewPixels, int trackX, int trackY, int trackWidth, int trackHeight, float scrollOffset) {
        if (contentPixels <= 0 || viewPixels <= 0 || trackHeight <= 0) {
            return new PackUiScrollbar.Metrics(trackX, trackY, trackWidth, trackHeight, trackY, trackHeight, 0);
        }
        int maxScroll = Math.max(0, contentPixels - viewPixels);
        if (maxScroll <= 0) {
            return new PackUiScrollbar.Metrics(trackX, trackY, trackWidth, trackHeight, trackY, trackHeight, 0);
        }
        int thumbHeight = Math.max(18, (int)((float)viewPixels / (float)Math.max(1, contentPixels) * (float)trackHeight));
        thumbHeight = Math.min(trackHeight, thumbHeight);
        int travel = Math.max(1, trackHeight - thumbHeight);
        float clampedScroll = Math.max(0f, Math.min(scrollOffset, (float)maxScroll));
        int thumbY = trackY + Math.round(clampedScroll / (float)maxScroll * (float)travel);
        return new PackUiScrollbar.Metrics(trackX, trackY, trackWidth, trackHeight, thumbY, thumbHeight, maxScroll);
    }

    public static void draw(class_332 context, PackUiScrollbar.Metrics metrics, boolean hovered, boolean dragging) {
        if (metrics == null || !metrics.hasScroll()) {
            return;
        }
        int trackColor = 873468180;
        int thumbColor = dragging ? THEME.headerAccent() : hovered ? -2593941 : THEME.borderSoft();
        int shine = hovered || dragging ? 687865855 : 352321535;
        context.method_25294(metrics.trackX(), metrics.trackY(), metrics.trackX() + metrics.trackWidth(), metrics.trackY() + metrics.trackHeight(), trackColor);
        context.method_25294(metrics.trackX(), metrics.trackY(), metrics.trackX() + metrics.trackWidth(), metrics.trackY() + 1, THEME.borderColor());
        context.method_25294(metrics.trackX(), metrics.trackY() + metrics.trackHeight() - 1, metrics.trackX() + metrics.trackWidth(), metrics.trackY() + metrics.trackHeight(), THEME.borderColor());
        context.method_25294(metrics.trackX(), metrics.thumbY(), metrics.trackX() + metrics.trackWidth(), metrics.thumbY() + metrics.thumbHeight(), thumbColor);
        context.method_25294(metrics.trackX(), metrics.thumbY(), metrics.trackX() + metrics.trackWidth(), metrics.thumbY() + 1, shine);
    }

    public static int scrollFromThumb(PackUiScrollbar.Metrics metrics, double mouseY, int grabOffset) {
        if (metrics == null || !metrics.hasScroll()) {
            return 0;
        }
        int travel = Math.max(1, metrics.trackHeight() - metrics.thumbHeight());
        int thumbTop = (int)Math.round(mouseY) - grabOffset;
        thumbTop = Math.max(metrics.trackY(), Math.min(metrics.trackY() + travel, thumbTop));
        float progress = (float)(thumbTop - metrics.trackY()) / (float)travel;
        return Math.max(0, Math.min(metrics.maxScroll(), Math.round(progress * (float)metrics.maxScroll())));
    }
}
