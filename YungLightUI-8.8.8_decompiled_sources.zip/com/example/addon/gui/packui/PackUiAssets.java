/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import net.minecraft.class_2960;

public final class PackUiAssets {
    public static final class_2960 FONT_BODY = class_2960.method_60655("yunglight", "pack_ui_body");
    public static final class_2960 FONT_LABEL = class_2960.method_60655("yunglight", "pack_ui_label");
    public static final class_2960 FONT_TITLE = class_2960.method_60655("yunglight", "pack_ui_title");
    public static final class_2960 FONT_FALLBACK = class_2960.method_60655("yunglight", "pack_ui_fallback");
    public static final class_2960 ICON_KEYBINDS = PackUiAssets.icon("keybinds");
    public static final class_2960 ICON_LANSYNC = PackUiAssets.icon("lansync");
    public static final class_2960 ICON_MACROS = PackUiAssets.icon("macros");
    public static final class_2960 ICON_FABRICATOR = PackUiAssets.icon("fabricator");
    public static final class_2960 ICON_FILTER = PackUiAssets.icon("filter");
    public static final class_2960 ICON_PACKET_LOGGER = PackUiAssets.icon("packetlogger");
    public static final class_2960 ICON_PACKET_Q_EDITOR = PackUiAssets.icon("packetqeditor");
    public static final class_2960 ICON_SERVER_INFO = PackUiAssets.icon("serverinfo");
    public static final class_2960 ICON_MAIN_MENU_CATEGORY = PackUiAssets.icon("mainmenucategory");
    public static final class_2960 ICON_PACKET_CATEGORY = PackUiAssets.icon("packetcategory");
    public static final class_2960 ICON_SCREEN_CATEGORY = PackUiAssets.icon("screencategory");
    public static final class_2960 ICON_CHAT_CATEGORY = PackUiAssets.icon("chatcategory");
    public static final class_2960 ICON_WINDOW_CLOSE = PackUiAssets.icon("windowclose");
    public static final class_2960 ICON_WINDOW_CHEVRON_UP = PackUiAssets.icon("windowchevronup");
    public static final class_2960 ICON_WINDOW_CHEVRON_DOWN = PackUiAssets.icon("windowchevrondown");
    public static final class_2960 ICON_WINDOW_CHEVRON_RIGHT = PackUiAssets.icon("windowchevronright");
    public static final class_2960 ICON_LIST_SELECTED = PackUiAssets.icon("listselected");

    private PackUiAssets() {
    }

    public static class_2960 bodyFont(int scalePercent) {
        return FONT_BODY;
    }

    public static class_2960 labelFont(int scalePercent) {
        return FONT_LABEL;
    }

    public static class_2960 titleFont(int scalePercent) {
        return FONT_TITLE;
    }

    public static class_2960 fallbackFont(int scalePercent) {
        return FONT_FALLBACK;
    }

    private static class_2960 icon(String name) {
        return class_2960.method_60655("yunglight", "textures/gui/packui/icons/" + name + ".png");
    }
}
