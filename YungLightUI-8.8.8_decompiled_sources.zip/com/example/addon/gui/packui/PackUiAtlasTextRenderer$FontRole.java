/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAssets;
import net.minecraft.class_2960;

private static enum PackUiAtlasTextRenderer.FontRole {
    public static final PackUiAtlasTextRenderer.FontRole BODY = new PackUiAtlasTextRenderer.FontRole("BODY", 0);
    public static final PackUiAtlasTextRenderer.FontRole LABEL = new PackUiAtlasTextRenderer.FontRole("LABEL", 1);
    public static final PackUiAtlasTextRenderer.FontRole TITLE = new PackUiAtlasTextRenderer.FontRole("TITLE", 2);
    public static final PackUiAtlasTextRenderer.FontRole FALLBACK = new PackUiAtlasTextRenderer.FontRole("FALLBACK", 3);
    private static final /* synthetic */ PackUiAtlasTextRenderer.FontRole[] $VALUES;

    public static PackUiAtlasTextRenderer.FontRole[] values() {
        return (PackUiAtlasTextRenderer.FontRole[])$VALUES.clone();
    }

    public static PackUiAtlasTextRenderer.FontRole valueOf(String name) {
        return (PackUiAtlasTextRenderer.FontRole)Enum.valueOf(PackUiAtlasTextRenderer.FontRole.class, name);
    }

    private PackUiAtlasTextRenderer.FontRole() {
        super(var1, var2);
    }

    private static PackUiAtlasTextRenderer.FontRole fromIdentifier(class_2960 fontId) {
        if (PackUiAssets.FONT_TITLE.equals(fontId)) {
            return TITLE;
        }
        if (PackUiAssets.FONT_LABEL.equals(fontId)) {
            return LABEL;
        }
        if (PackUiAssets.FONT_FALLBACK.equals(fontId)) {
            return FALLBACK;
        }
        return BODY;
    }

    static {
        $VALUES = PackUiAtlasTextRenderer.FontRole.$values();
    }
}
