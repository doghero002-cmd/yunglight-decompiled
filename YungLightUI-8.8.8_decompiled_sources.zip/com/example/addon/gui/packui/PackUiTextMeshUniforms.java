/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAtlasTextRenderer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import net.minecraft.class_11280;
import org.joml.Matrix4f;

public final class PackUiTextMeshUniforms {
    private static final int SIZE = new Std140SizeCalculator().putMat4f().putMat4f().get();
    private static final PackUiTextMeshUniforms.Data DATA = new PackUiTextMeshUniforms.Data();
    private static final class_11280<PackUiTextMeshUniforms.Data> STORAGE = new class_11280("PackUI Text UBO", SIZE, 16);

    private PackUiTextMeshUniforms() {
    }

    public static void flipFrame() {
        STORAGE.method_71100();
        PackUiAtlasTextRenderer.resetFrameUploadGate();
    }

    static GpuBufferSlice write(Matrix4f proj, Matrix4f modelView) {
        DATA.proj = proj;
        DATA.modelView = modelView;
        return STORAGE.method_71102(DATA);
    }
}
