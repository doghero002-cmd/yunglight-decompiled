/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButton;
import com.example.addon.gui.packui.PackUiButtonFeedback;
import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import net.minecraft.class_2960;

public class PackUiIconButton
extends PackUiNode {
    private final class_2960 icon;
    private final PackUiButton.Variant variant;
    private Runnable onPress;
    private int iconPadding = 4;

    public PackUiIconButton(class_2960 icon, PackUiButton.Variant variant, Runnable onPress) {
        this.icon = icon;
        this.variant = variant == null ? PackUiButton.Variant.GHOST : variant;
        this.onPress = onPress;
        this.width = 20f;
        this.height = 20f;
    }

    private PackUiButtonFeedback feedbackState() {
        return PackUiButtonFeedback.forKey("icon-button:" + Math.round(this.x) + ":" + Math.round(this.y) + ":" + Math.round(this.width) + ":" + Math.round(this.height) + ":" + String.valueOf(this.variant) + ":" + this.icon == null ? "none" : this.icon.toString());
    }

    public PackUiIconButton setOnPress(Runnable onPress) {
        this.onPress = onPress;
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        return this.width;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return this.height;
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawW = Math.round(this.width);
        int drawH = Math.round(this.height);
        boolean hovered = this.enabled && this.contains(context.mouseX(), context.mouseY());
        PackUiButtonFeedback feedback = this.feedbackState();
        float hover = feedback.update(hovered, this.enabled && PackUiButtonFeedback.isPrimaryPointerDown(), context.mouseX() - this.x, context.mouseY() - this.y, this.width, this.height);
        float clickGlow = feedback.clickGlowProgress();
        switch (PackUiIconButton.1.$SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[this.variant.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                int bg = -1366352092;
                break;
            case 2::
                bg = -1978528239;
                break;
            case 3::
                bg = 1074924815;
                break;
            case 4::
                bg = -1725756143;
                break;
            case 5::
                bg = -2012207590;
                break;
        }
        switch (PackUiIconButton.1.$SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[this.variant.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                int border = -30841;
                break;
            case 2::
            case 3::
                border = -7392975;
                break;
            case 4::
                border = -4896696;
                break;
            case 5::
                border = -8269408;
                break;
        }
        switch (PackUiIconButton.1.$SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[this.variant.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                int borderGlow = -23388;
                break;
            case 2::
            case 3::
                borderGlow = -39836;
                break;
            case 4::
                borderGlow = -28528;
                break;
            case 5::
                borderGlow = -5575744;
                break;
        }
        switch (PackUiIconButton.1.$SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[this.variant.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                int rippleRing = -19790;
                break;
            case 2::
            case 3::
                rippleRing = -36752;
                break;
            case 4::
                rippleRing = -30070;
                break;
            case 5::
                rippleRing = -6363465;
                break;
        }
        switch (PackUiIconButton.1.$SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[this.variant.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 1::
                int rippleFill = -7711;
                break;
            case 2::
            case 3::
                rippleFill = -13622;
                break;
            case 4::
                rippleFill = -11823;
                break;
            case 5::
                rippleFill = -2623518;
                break;
        }
        float hoverVisual = Math.max(hover * 0.9f, clickGlow * 0.55f);
        border = PackUiSizing.lerpColor(border, borderGlow, Math.min(1f, hover * 0.35f + clickGlow * 0.85f));
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(bg));
        if (hoverVisual <= 0f) { /* goto L725; */ }
        switch (PackUiIconButton.1.$SwitchMap$com$example$addon$gui$packui$PackUiButton$Variant[this.variant.ordinal()]) {
            default:
                throw new MatchException(null, null);
            case 5::
                int hoverBase = 3332202;
                break;
            case 4::
                hoverBase = 16726843;
                break;
            case 1::
                hoverBase = 16735838;
                break;
            case 2::
            case 3::
                hoverBase = 16726843;
                break;
        }
        int hoverTint = (int)Math.min(42f, hover * 24f + clickGlow * 12f) << 24 | hoverBase;
        context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(hoverTint));
        L725: ;
        if (clickGlow > 0f) {
            pressGlow = (int)(clickGlow * 14f) << 24 | rippleFill & 16777215;
            context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(pressGlow));
        }
        feedback.render(context.drawContext(), drawX + 1, drawY + 1, Math.max(0, drawW - 2), Math.max(0, drawH - 2), rippleRing, rippleFill, context.alpha());
        context.drawContext().method_25294(drawX, drawY, drawX + drawW, drawY + 1, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY + drawH - 1, drawX + drawW, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX, drawY, drawX + 1, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX + drawW - 1, drawY, drawX + drawW, drawY + drawH, context.applyAlpha(border));
        context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + drawW - 1, drawY + 2, context.applyAlpha(620756991));
        context.drawContext().method_25294(drawX + 1, drawY + 1, drawX + 2, drawY + drawH - 1, context.applyAlpha(620756991));
        context.drawContext().method_25294(drawX + 1, drawY + drawH - 2, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(402653184));
        context.drawContext().method_25294(drawX + drawW - 2, drawY + 1, drawX + drawW - 1, drawY + drawH - 1, context.applyAlpha(402653184));
        if (this.icon != null) {
            context.drawTexturedQuad(this.icon, drawX + this.iconPadding, drawY + this.iconPadding, drawX + drawW - this.iconPadding, drawY + drawH - this.iconPadding);
        }
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        if (!this.enabled || !this.contains(mouseX, mouseY) || button != 0) {
            return false;
        }
        this.feedbackState().triggerPress(mouseX - this.x, mouseY - this.y, this.width, this.height);
        if (this.onPress != null) {
            this.onPress.run();
        }
        return true;
    }
}
