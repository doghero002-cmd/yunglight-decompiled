/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

public static interface PackUiScrollViewport.ScrollRow {
    public String getLabel();

    public boolean isSelected();

    public boolean isEnabled();
}
