/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTone;
import net.minecraft.class_2960;

public class PackUiIconLabel
extends PackUiNode {
    private String text;
    private class_2960 icon;
    private PackUiTone tone = PackUiTone.LABEL;
    private int iconSize = 12;
    private int iconGap = 5;

    public PackUiIconLabel(String text, class_2960 icon) {
        this.text = text == null ? "" : text;
        this.icon = icon;
        this.height = 14f;
    }

    public PackUiIconLabel setText(String text) {
        this.text = text == null ? "" : text;
        return this;
    }

    public PackUiIconLabel setIcon(class_2960 icon) {
        this.icon = icon;
        return this;
    }

    public PackUiIconLabel setTone(PackUiTone tone) {
        this.tone = tone == null ? PackUiTone.LABEL : tone;
        return this;
    }

    public PackUiIconLabel setIconSize(int iconSize) {
        this.iconSize = Math.max(1, iconSize);
        return this;
    }

    public PackUiIconLabel setIconGap(int iconGap) {
        this.iconGap = Math.max(0, iconGap);
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        int textWidth = PackUiText.width(context.textRenderer(), this.text, context.theme().fontFor(this.tone), context.theme().color(this.tone));
        int scaledIconSize = context.theme().scale(this.iconSize);
        int scaledIconGap = context.theme().scale(this.iconGap);
        return (float)(textWidth + (this.icon != null ? scaledIconSize + scaledIconGap : 0));
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return (float)Math.max(context.theme().fontHeight(this.tone) + context.theme().scale(2), context.theme().scale(this.iconSize + 1));
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        int drawX = Math.round(this.x);
        int drawY = Math.round(this.y);
        int drawH = Math.round(this.height);
        int textColor = context.theme().color(this.tone);
        int contentX = drawX;
        int scaledIconSize = context.theme().scale(this.iconSize);
        int scaledIconGap = context.theme().scale(this.iconGap);
        if (this.icon != null) {
            int iconY = drawY + Math.max(1, (drawH - scaledIconSize) / 2);
            context.drawTexturedQuad(this.icon, drawX, iconY, drawX + scaledIconSize, iconY + scaledIconSize);
            contentX = contentX + (scaledIconSize + scaledIconGap);
        }
        textY = PackUiSizing.alignTextY(drawY, drawH, context.theme().fontHeight(this.tone), context.theme().bodyTextNudge());
        PackUiText.draw(context.drawContext(), context.textRenderer(), this.text, context.theme().fontFor(this.tone), context.applyAlpha(textColor), contentX, textY, false);
    }
}
