/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

private static final record PackUiTextField.WrappedLine {
    private final int start;
    private final int end;
    private final int renderEnd;

    private PackUiTextField.WrappedLine(int start, int end, int renderEnd) {
        this.start = start;
        this.end = end;
        this.renderEnd = renderEnd;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int start() {
        return this.start;
    }

    public int end() {
        return this.end;
    }

    public int renderEnd() {
        return this.renderEnd;
    }
}
