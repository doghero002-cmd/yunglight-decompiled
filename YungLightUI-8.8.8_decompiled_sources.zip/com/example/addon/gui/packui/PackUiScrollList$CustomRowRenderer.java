/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import net.minecraft.class_327;
import net.minecraft.class_332;

@FunctionalInterface
public static interface PackUiScrollList.CustomRowRenderer<T> {
    public void render(class_332 var1, class_327 var2, T var3, int var4, boolean var5, boolean var6, int var7, int var8, int var9, int var10, int var11);
}
