/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiRenderContext;

public abstract class PackUiNode {
    protected float x;
    protected float y;
    protected float width;
    protected float height;
    protected boolean visible = true;
    protected boolean enabled = true;
    protected boolean growX = false;
    protected float hoverProgress = 0f;

    public float x() {
        return this.x;
    }

    public float y() {
        return this.y;
    }

    public float width() {
        return this.width;
    }

    public float height() {
        return this.height;
    }

    public PackUiNode setBounds(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = Math.max(0f, width);
        this.height = Math.max(0f, height);
        return this;
    }

    public PackUiNode setVisible(boolean visible) {
        this.visible = visible;
        return this;
    }

    public PackUiNode setEnabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public PackUiNode setGrowX(boolean growX) {
        this.growX = growX;
        return this;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public boolean growX() {
        return this.growX;
    }

    public boolean contains(float px, float py) {
        return this.visible && px >= this.x && px <= this.x + this.width && py >= this.y && py <= this.y + this.height;
    }

    protected float animate(float current, float target, float speed, float delta) {
        float amount = Math.max(0.04f, delta * speed);
        if (current < target) {
            return Math.min(target, current + amount);
        }
        if (current > target) {
            return Math.max(target, current - amount);
        }
        return current;
    }

    protected float updateHover(boolean hovered, float delta) {
        this.hoverProgress = this.animate(this.hoverProgress, hovered ? 1f : 0f, 7.5f, delta);
        return this.hoverProgress;
    }

    public float preferredWidth(PackUiRenderContext context) {
        return this.width;
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return this.height;
    }

    public void layout(PackUiRenderContext context) {
    }

    public void render(PackUiRenderContext context) {
    }

    public boolean mouseClicked(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        return false;
    }

    public boolean mouseReleased(PackUiRenderContext context, float mouseX, float mouseY, int button) {
        return false;
    }

    public boolean mouseDragged(PackUiRenderContext context, float mouseX, float mouseY, int button, float deltaX, float deltaY) {
        return false;
    }

    public boolean mouseScrolled(PackUiRenderContext context, float mouseX, float mouseY, float amount) {
        return false;
    }

    public boolean keyPressed(PackUiRenderContext context, int keyCode, int scanCode, int modifiers) {
        return false;
    }

    public boolean charTyped(PackUiRenderContext context, char chr, int modifiers) {
        return false;
    }
}
