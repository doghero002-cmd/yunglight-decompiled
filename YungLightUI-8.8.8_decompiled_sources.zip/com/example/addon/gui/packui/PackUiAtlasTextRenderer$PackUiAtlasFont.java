/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiAtlasTextRenderer;
import com.example.addon.gui.packui.PackUiTextMeshBuilder;
import com.example.addon.gui.packui.PackUiTextTexture;
import java.util.Map;

private static final class PackUiAtlasTextRenderer.PackUiAtlasFont {
    private final PackUiTextTexture texture;
    private final Map<Integer, PackUiAtlasTextRenderer.Glyph> glyphs;
    private final PackUiAtlasTextRenderer.Glyph fallbackGlyph;
    private final float ascent;
    private final int displayLineHeight;
    private final float drawScale;

    private PackUiAtlasTextRenderer.PackUiAtlasFont(PackUiAtlasTextRenderer.PrecomputedAtlas pre, PackUiAtlasTextRenderer.FontRole role, PackUiTextTexture sharedTexture) {
        this.glyphs = pre.glyphs;
        this.fallbackGlyph = pre.fallbackGlyph;
        this.ascent = pre.ascent;
        this.displayLineHeight = PackUiAtlasTextRenderer.displayPixelHeight(role);
        this.drawScale = (float)this.displayLineHeight / (float)pre.packedHeight;
        this.texture = sharedTexture;
    }

    private int width(String value) {
        float width = 0f;
        int i = 0;
        while (i < value.length()) {
            int codePoint = value.codePointAt(i);
            width = width + this.glyph(codePoint).advance * this.drawScale;
            i = i + Character.charCount(codePoint);
        }
        return Math.round(width);
    }

    private int height() {
        return this.displayLineHeight;
    }

    private void appendTo(PackUiTextMeshBuilder mesh, String value, int color, int x, int y, boolean shadow) {
        if (shadow) {
            int shadowAlpha = Math.max(0, Math.min(255, (color >>> 24 & 255) - 90));
            int shadowColor = shadowAlpha << 24 | 1052688;
            this.appendGlyphs(mesh, value, shadowColor, (float)x + Math.max(0.75f, this.drawScale), (float)y + Math.max(0.75f, this.drawScale));
        }
        this.appendGlyphs(mesh, value, color, (float)x, (float)y);
    }

    private void appendGlyphs(PackUiTextMeshBuilder mesh, String value, int color, float x, float y) {
        float cursorX = x;
        float baselineY = y + this.ascent * this.drawScale;
        mesh.ensureCapacity(value.length() * 4, value.length() * 6);
        int i = 0;
        while (i < value.length()) {
            int codePoint = value.codePointAt(i);
            Glyph glyph = this.glyph(codePoint);
            float x0 = cursorX + glyph.x0 * this.drawScale;
            float y0 = baselineY + glyph.y0 * this.drawScale;
            float x1 = cursorX + glyph.x1 * this.drawScale;
            float y1 = baselineY + glyph.y1 * this.drawScale;
            int i1 = mesh.pos((double)x0, (double)y0).tex((double)glyph.u0, (double)glyph.v0).color(color).next();
            if (x1 > x0 && y1 > y0) {
                int i2 = mesh.pos((double)x0, (double)y1).tex((double)glyph.u0, (double)glyph.v1).color(color).next();
                int i3 = mesh.pos((double)x1, (double)y1).tex((double)glyph.u1, (double)glyph.v1).color(color).next();
                int i4 = mesh.pos((double)x1, (double)y0).tex((double)glyph.u1, (double)glyph.v0).color(color).next();
                mesh.quad(i1, i2, i3, i4);
            }
            cursorX = cursorX + glyph.advance * this.drawScale;
            i = i + Character.charCount(codePoint);
        }
    }

    private PackUiAtlasTextRenderer.Glyph glyph(int codePoint) {
        return (PackUiAtlasTextRenderer.Glyph)this.glyphs.getOrDefault(codePoint, this.fallbackGlyph);
    }
}
