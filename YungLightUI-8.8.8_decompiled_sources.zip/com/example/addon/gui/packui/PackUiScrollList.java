/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiScrollViewport;
import com.example.addon.util.PackUtilColors;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PackUiScrollList<T> {
    private final PackUiScrollViewport viewport;
    private final Function<T, String> labelExtractor;
    private final BiConsumer<T, Boolean> selectionHandler;
    private final List<T> items = new ArrayList();
    private int selectedIndex = -1;
    private boolean enabled = true;
    private int borderColor = PackUtilColors.secondary();
    private int backgroundColor = 905969664;
    private int selectedTextColor = PackUtilColors.rowSelectedText();
    private int normalTextColor = -1;
    private int disabledTextColor = PackUtilColors.textDim();
    private Function<T, String> badgeExtractor;
    private Function<T, Integer> badgeColorExtractor;
    private Function<T, String> secondaryTextExtractor;
    private int secondaryTextColor = PackUtilColors.textDim();

    public PackUiScrollList(int x, int y, int width, int height, int rowHeight, int scrollbarWidth, Function<T, String> labelExtractor, BiConsumer<T, Boolean> selectionHandler) {
        this.viewport = new PackUiScrollViewport(x, y, width, height, rowHeight, scrollbarWidth);
        this.labelExtractor = labelExtractor;
        this.selectionHandler = selectionHandler;
    }

    public void setItems(List<T> items) {
        this.items.clear();
        if (items != null) {
            this.items.addAll(items);
        }
        this.updateContentHeight();
    }

    public void setItems(T[] items) {
        this.items.clear();
        if (items == null) { /* goto L51; */ }
        var var2 = items;
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            T item = var2[var4];
            this.items.add(item);
        }
        this.updateContentHeight();
    }

    public void addItem(T item) {
        this.items.add(item);
        this.updateContentHeight();
    }

    public void clear() {
        this.items.clear();
        this.selectedIndex = -1;
        this.updateContentHeight();
    }

    private void updateContentHeight() {
        int contentHeight = this.items.size() * this.viewport.getRowHeight();
        this.viewport.setContentHeight(contentHeight);
    }

    public void setSelectedIndex(int index) {
        if (index >= -1) {
            if (index < this.items.size()) {
                this.selectedIndex = index;
                if (index >= 0) {
                    if (this.selectionHandler != null) {
                        this.selectionHandler.accept(this.items.get(index), true);
                    }
                }
            }
        }
    }

    public int getSelectedIndex() {
        return this.selectedIndex;
    }

    public T getSelectedItem() {
        return this.selectedIndex >= 0 && this.selectedIndex < this.items.size() ? this.items.get(this.selectedIndex) : null;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setBadgeExtractor(Function<T, String> extractor, Function<T, Integer> colorExtractor) {
        this.badgeExtractor = extractor;
        this.badgeColorExtractor = colorExtractor;
    }

    public void setSecondaryTextExtractor(Function<T, String> extractor) {
        this.secondaryTextExtractor = extractor;
    }

    public void setColors(int border, int background, int selectedText, int normalText, int disabledText) {
        this.borderColor = border;
        this.backgroundColor = background;
        this.selectedTextColor = selectedText;
        this.normalTextColor = normalText;
        this.disabledTextColor = disabledText;
    }

    public void render(class_332 ctx, class_327 textRenderer, double mouseX, double mouseY) {
        this.viewport.beginRender(ctx, this.borderColor, this.backgroundColor);
        try {
            this.renderContent(ctx, textRenderer, mouseX, mouseY);
        }
        finally {
            this.viewport.endRender(ctx);
            throw var7;
        }
        this.viewport.renderScrollbar(ctx, mouseX, mouseY);
    }

    public void renderCustom(class_332 ctx, class_327 textRenderer, double mouseX, double mouseY, PackUiScrollList.CustomRowRenderer<T> customRenderer) {
        this.viewport.beginRender(ctx, this.borderColor, this.backgroundColor);
        try {
            this.viewport.renderSimple(ctx, this.items.size(), this::lambda$renderCustom$0 /* captured: mouseX, mouseY, customRenderer, ctx, textRenderer */);
        }
        finally {
            this.viewport.endRender(ctx);
            throw var8;
        }
        this.viewport.renderScrollbar(ctx, mouseX, mouseY);
    }

    private void renderContent(class_332 ctx, class_327 textRenderer, double mouseX, double mouseY) {
        this.viewport.renderSimple(ctx, this.items.size(), this::lambda$renderContent$1 /* captured: mouseX, mouseY, ctx, textRenderer */);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.enabled) {
            return false;
        }
        if (this.viewport.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (this.viewport.contains(mouseX, mouseY)) {
            int relativeY = (int)Math.round(mouseY) - this.viewport.getY() - 1 + this.viewport.getScrollOffset();
            int rowIndex = relativeY / this.viewport.getRowHeight();
            if (rowIndex >= 0) {
                if (rowIndex < this.items.size()) {
                    this.setSelectedIndex(rowIndex);
                    return true;
                }
            }
        }
        return false;
    }

    public void mouseReleased() {
        this.viewport.mouseReleased();
    }

    public void mouseDragged(double mouseX, double mouseY) {
        this.viewport.mouseDragged(mouseX, mouseY);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return this.viewport.mouseScrolled(mouseX, mouseY, amount);
    }

    public void scrollToSelected() {
        if (this.selectedIndex < 0) {
            return;
        }
        int rowTop = this.selectedIndex * this.viewport.getRowHeight();
        int rowBottom = rowTop + this.viewport.getRowHeight();
        int viewTop = this.viewport.getScrollOffset();
        int viewHeight = this.viewport.getHeight() - 2;
        int viewBottom = viewTop + viewHeight;
        if (rowTop < viewTop) {
            this.viewport.jumpTo(rowTop);
        } else {
            if (rowBottom > viewBottom) {
                this.viewport.jumpTo(rowBottom - viewHeight);
            }
        }
    }

    public T getItem(int index) {
        return index >= 0 && index < this.items.size() ? this.items.get(index) : null;
    }

    public int size() {
        return this.items.size();
    }

    public boolean isEmpty() {
        return this.items.isEmpty();
    }

    private boolean isHovered(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= (double)x && mouseX < (double)(x + width) && mouseY >= (double)y && mouseY < (double)(y + height);
    }

    public int getX() {
        return this.viewport.getX();
    }

    public int getY() {
        return this.viewport.getY();
    }

    public int getWidth() {
        return this.viewport.getWidth();
    }

    public int getHeight() {
        return this.viewport.getHeight();
    }

    public int getContentWidth() {
        return this.viewport.getContentWidth();
    }

    public int getRowHeight() {
        return this.viewport.getRowHeight();
    }

    public int getScrollOffset() {
        return this.viewport.getScrollOffset();
    }

    public void jumpTo(int offset) {
        this.viewport.jumpTo(offset);
    }

    public void scrollBy(int rows) {
        this.viewport.scrollBy(rows);
    }

    public boolean contains(double x, double y) {
        return this.viewport.contains(x, y);
    }

    public boolean isScrollbarDragging() {
        return this.viewport.isScrollbarDragging();
    }

    public boolean isScrollbarHovered(double mouseX, double mouseY) {
        return this.viewport.isScrollbarHovered(mouseX, mouseY);
    }
}
