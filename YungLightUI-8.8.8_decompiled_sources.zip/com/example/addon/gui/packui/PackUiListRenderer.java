/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiButtonFeedback;
import com.example.addon.gui.packui.PackUiControlGlyphs;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;

public final class PackUiListRenderer {
    private static final PackUiTheme THEME = new PackUiTheme();
    private static final int HEADER_ACTION_RIGHT_INSET = 2;

    private PackUiListRenderer() {
    }

    public static void drawFrame(class_332 context, int x, int y, int width, int height, boolean focused) {
        int bg = focused ? -787278824 : -988803052;
        int border = focused ? THEME.headerAccent() : THEME.borderColor();
        context.method_25294(x, y, x + width, y + height, bg);
        context.method_25294(x, y, x + width, y + 1, border);
        context.method_25294(x, y + height - 1, x + width, y + height, border);
        context.method_25294(x, y, x + 1, y + height, border);
        context.method_25294(x + width - 1, y, x + width, y + height, border);
        context.method_25294(x + 1, y + 1, x + width - 1, y + 2, 385875967);
    }

    public static void drawHeader(class_332 context, class_327 textRenderer, String title, int x, int y) {
        PackUiText.draw(context, textRenderer, title, THEME.fontFor(PackUiTone.LABEL), THEME.color(PackUiTone.MUTED), x, y, false);
    }

    public static void drawHeaderAction(class_332 context, class_327 textRenderer, String label, boolean enabled, int listX, int listWidth, int headerY, int mouseX, int mouseY) {
        int buttonHeight = 13;
        int buttonWidth = Math.max(54, PackUiText.width(textRenderer, label, THEME.fontFor(PackUiTone.BODY), THEME.color(PackUiTone.BODY)) + 12);
        int buttonX = listX + listWidth - buttonWidth - 2;
        int buttonY = headerY + Math.max(0, (THEME.lineHeight(PackUiTone.LABEL, 1) - buttonHeight) / 2) - 1;
        PackUiOverlayButton button = PackUiOverlayButton.create(buttonX, buttonY, buttonWidth, buttonHeight, class_2561.method_43470(label), PackUiListRenderer::lambda$drawHeaderAction$0);
        button.active = enabled;
        button.setVariant(enabled ? PackUiOverlayButton.Variant.SECONDARY : PackUiOverlayButton.Variant.GHOST);
        PackUiOverlayButton.renderStyled(context, textRenderer, button, mouseX, mouseY);
    }

    public static void drawEmptyState(class_332 context, class_327 textRenderer, String text, int x, int y, int width) {
        String trimmed = PackUiText.trimToWidth(textRenderer, text, Math.max(1, width - 10), THEME.fontFor(PackUiTone.MUTED), THEME.color(PackUiTone.MUTED));
        int textY = PackUiSizing.alignTextY(y, 14, THEME.fontHeight(PackUiTone.MUTED), THEME.bodyTextNudge());
        PackUiText.draw(context, textRenderer, trimmed, THEME.fontFor(PackUiTone.MUTED), THEME.color(PackUiTone.MUTED), x + 6, textY, false);
    }

    public static void drawRow(class_332 context, class_327 textRenderer, String label, int x, int y, int width, int height, boolean hovered, boolean selected, PackUiListRenderer.RowTone tone) {
        PackUiListRenderer.drawRow(context, textRenderer, class_2561.method_43470(label == null ? "" : label), x, y, width, height, hovered, selected, tone, false);
    }

    public static void drawRow(class_332 context, class_327 textRenderer, class_2561 label, int x, int y, int width, int height, boolean hovered, boolean selected, PackUiListRenderer.RowTone tone, boolean useMinecraftText) {
        int bg = selected ? -1323091925 : hovered ? 1327766045 : 639113758;
        switch (tone.ordinal()) {
            default:
                throw new MatchException(null, null);
            case 1::
                int fg = selected ? -1507344 : -6426438;
                break;
            case 2::
                fg = selected ? -3104 : -14726;
                break;
            case 3::
                fg = selected ? -5398 : -29556;
                break;
            case 0::
                fg = selected ? -2828 : THEME.color(PackUiTone.BODY);
                break;
        }
        int rightInset = 6;
        int textX = x + 6;
        context.method_25294(x, y, x + width, y + height, bg);
        int textWidth = Math.max(1, x + width - rightInset - textX);
        int textY = PackUiSizing.alignTextY(y, height, THEME.fontHeight(PackUiTone.BODY), THEME.bodyTextNudge());
        if (useMinecraftText) {
            List<class_5481> wrapped = textRenderer.method_1728(label == null ? class_2561.method_43473() : label, textWidth);
            class_5481 line = wrapped.isEmpty() ? class_2561.method_43473().method_30937() : (class_5481)wrapped.get(0);
            context.method_51430(textRenderer, line, textX, textY, fg, false);
        } else {
            String trimmed = PackUiText.trimToWidth(textRenderer, label == null ? "" : label.getString(), textWidth, THEME.fontFor(PackUiTone.BODY), fg);
            PackUiText.draw(context, textRenderer, trimmed, THEME.fontFor(PackUiTone.BODY), fg, textX, textY, false);
        }
    }

    public static void drawDivider(class_332 context, int x, int y, int width) {
        context.method_25294(x + 5, y, x + width - 5, y + 1, 721420287);
    }

    public static void drawIconButton(class_332 context, int x, int y, int size, class_2960 icon, boolean hovered, boolean danger) {
        PackUiButtonFeedback feedback = PackUiButtonFeedback.forKey("list-icon:" + x + ":" + y + ":" + size + ":" + danger + ":" + String.valueOf(icon));
        float hover = feedback.update(hovered, PackUiButtonFeedback.isPrimaryPointerDown(), 0.5f * (float)size, 0.5f * (float)size, (float)size, (float)size);
        float clickGlow = feedback.clickGlowProgress();
        int bg = danger ? 2081951248 : 1678840084;
        int border = danger ? -4896696 : THEME.borderColor();
        int borderGlow = danger ? -28528 : -39836;
        int rippleRing = danger ? -30070 : -36752;
        int rippleFill = danger ? -11823 : -13622;
        float hoverVisual = Math.max(hover * 0.9f, clickGlow * 0.55f);
        border = PackUiSizing.lerpColor(border, borderGlow, Math.min(1f, hover * 0.35f + clickGlow * 0.85f));
        context.method_25294(x, y, x + size, y + size, bg);
        if (hoverVisual <= 0f) { /* goto L288; */ }
        int hoverTint = danger ? (int)Math.min(38f, hover * 24f + clickGlow * 12f) << 24 | 16726843 : (int)Math.min(30f, hover * 18f + clickGlow * 10f) << 24 | 16726843;
        context.method_25294(x + 1, y + 1, x + size - 1, y + size - 1, hoverTint);
        L288: ;
        if (clickGlow > 0f) {
            pressGlow = (int)(clickGlow * 14f) << 24 | rippleFill & 16777215;
            context.method_25294(x + 1, y + 1, x + size - 1, y + size - 1, pressGlow);
        }
        feedback.render(context, x + 1, y + 1, Math.max(0, size - 2), Math.max(0, size - 2), rippleRing, rippleFill, 1f);
        context.method_25294(x, y, x + size, y + 1, border);
        context.method_25294(x, y + size - 1, x + size, y + size, border);
        context.method_25294(x, y, x + 1, y + size, border);
        context.method_25294(x + size - 1, y, x + size, y + size, border);
        iconInset = Math.max(1, (size - 10) / 2);
        int iconSize = Math.max(1, size - iconInset * 2);
        if (PackUiControlGlyphs.isCloseIcon(icon) || PackUiControlGlyphs.isChevronIcon(icon)) {
            int iconColor = danger ? -17477 : -857880;
            int iconShadow = danger ? -699852257 : -1204153320;
            PackUiControlGlyphs.drawKnownIcon(context, icon, x + iconInset, y + iconInset, iconSize, iconColor, iconShadow, 1f);
        } else {
            context.method_70845(icon, x + iconInset, y + iconInset, x + size - iconInset, y + size - iconInset, 0f, 1f, 0f, 1f);
        }
    }

    public static int rowTextWidth(int totalWidth, boolean selected, boolean hasTrailingButton) {
        int reserved = 12 + (hasTrailingButton ? 18 : 6);
        return Math.max(1, totalWidth - reserved);
    }
}
