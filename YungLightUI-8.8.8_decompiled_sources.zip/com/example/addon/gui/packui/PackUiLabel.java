/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.packui;

import com.example.addon.gui.packui.PackUiNode;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTone;

public class PackUiLabel
extends PackUiNode {
    private String text;
    private PackUiTone tone;
    private boolean shadow;
    private boolean trimToBounds;

    public PackUiLabel(String text, PackUiTone tone) {
        this.text = text == null ? "" : text;
        this.tone = tone == null ? PackUiTone.BODY : tone;
        this.height = 10f;
    }

    public PackUiLabel setText(String text) {
        this.text = text == null ? "" : text;
        return this;
    }

    public PackUiLabel setTone(PackUiTone tone) {
        this.tone = tone == null ? PackUiTone.BODY : tone;
        return this;
    }

    public PackUiLabel setShadow(boolean shadow) {
        this.shadow = shadow;
        return this;
    }

    public PackUiLabel setTrimToBounds(boolean trimToBounds) {
        this.trimToBounds = trimToBounds;
        return this;
    }

    public PackUiLabel setGrowX(boolean growX) {
        super.setGrowX(growX);
        return this;
    }

    public float preferredWidth(PackUiRenderContext context) {
        return (float)PackUiText.width(context.textRenderer(), this.text, context.theme().fontFor(this.tone), context.theme().color(this.tone));
    }

    public float preferredHeight(PackUiRenderContext context, float availableWidth) {
        return (float)context.theme().lineHeight(this.tone, 3);
    }

    public void render(PackUiRenderContext context) {
        if (!this.visible) {
            return;
        }
        String displayText = this.text;
        if (this.trimToBounds) {
            if (this.width > 0f) {
                displayText = PackUiText.trimToWidth(context.textRenderer(), this.text, Math.round(this.width), context.theme().fontFor(this.tone), context.theme().color(this.tone));
            }
        }
        PackUiText.draw(context.drawContext(), context.textRenderer(), displayText, context.theme().fontFor(this.tone), context.applyAlpha(context.theme().color(this.tone)), Math.round(this.x), PackUiSizing.alignTextY(Math.round(this.y), Math.round(this.height), context.theme().fontHeight(this.tone), context.theme().bodyTextNudge()), this.shadow);
    }
}
