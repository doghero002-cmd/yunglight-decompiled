/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

import com.example.addon.gui.macro.editor.ActionFieldSchema;
import com.example.addon.gui.macro.editor.CaptureMode;
import com.example.addon.gui.macro.editor.FieldDef;
import com.example.addon.gui.macro.editor.FieldType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public static final class ActionFieldSchema.Builder {
    private final List<FieldDef> fields = new ArrayList();
    private String pendingKey;
    private String pendingLabel;
    private FieldType pendingType;
    private int min = -2147483648;
    private int max = 2147483647;
    private double decMin = -179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    private double decMax = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    private List<String> enumOpts;
    private String showWhenKey;
    private boolean showWhenInv;
    private String showWhenValue;
    private String addLabel;
    private String[] xyzKeys;
    private boolean xyzDouble;
    private CaptureMode captureMode = CaptureMode.NONE;
    private String[] exclusiveWith;

    private void commit() {
        if (this.pendingKey == null) {
            return;
        }
        this.fields.add(new FieldDef(this.pendingKey, this.pendingLabel, this.pendingType, this.min, this.max, this.decMin, this.decMax, this.enumOpts, this.showWhenKey, this.showWhenInv, this.showWhenValue, this.addLabel, this.xyzKeys, this.xyzDouble, this.captureMode, this.exclusiveWith));
        this.pendingKey = null;
        this.pendingLabel = null;
        this.pendingType = null;
        this.min = -2147483648;
        this.max = 2147483647;
        this.decMin = -179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        this.decMax = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        this.enumOpts = null;
        this.showWhenKey = null;
        this.showWhenInv = false;
        this.showWhenValue = null;
        this.addLabel = null;
        this.xyzKeys = null;
        this.xyzDouble = false;
        this.captureMode = CaptureMode.NONE;
        this.exclusiveWith = null;
    }

    private ActionFieldSchema.Builder start(String key, String label, FieldType type) {
        this.commit();
        this.pendingKey = key;
        this.pendingLabel = label;
        this.pendingType = type;
        return this;
    }

    public ActionFieldSchema.Builder toggle(String key, String label) {
        return this.start(key, label, FieldType.TOGGLE);
    }

    public ActionFieldSchema.Builder number(String key, String label) {
        return this.start(key, label, FieldType.NUMBER);
    }

    public ActionFieldSchema.Builder decimal(String key, String label) {
        return this.start(key, label, FieldType.DECIMAL);
    }

    public ActionFieldSchema.Builder text(String key, String label) {
        return this.start(key, label, FieldType.TEXT);
    }

    public ActionFieldSchema.Builder stringList(String key, String label) {
        return this.start(key, label, FieldType.STRING_LIST);
    }

    public ActionFieldSchema.Builder blockPos(String key, String label) {
        return this.start(key, label, FieldType.BLOCK_POS);
    }

    public ActionFieldSchema.Builder slot(String key, String label) {
        return this.start(key, label, FieldType.SLOT);
    }

    public ActionFieldSchema.Builder enumField(String key, String label, String ... options) {
        this.start(key, label, FieldType.ENUM);
        this.enumOpts = new ArrayList(Arrays.asList(options));
        return this;
    }

    public ActionFieldSchema.Builder range(int min, int max) {
        this.min = min;
        this.max = max;
        return this;
    }

    public ActionFieldSchema.Builder decRange(double min, double max) {
        this.decMin = min;
        this.decMax = max;
        return this;
    }

    public ActionFieldSchema.Builder showWhen(String key) {
        this.showWhenKey = key;
        this.showWhenInv = false;
        return this;
    }

    public ActionFieldSchema.Builder hideWhen(String key) {
        this.showWhenKey = key;
        this.showWhenInv = true;
        return this;
    }

    public ActionFieldSchema.Builder showWhenEnum(String key, String value) {
        this.showWhenValue = this.showWhenValue + "|" + value;
        if (key.equals(this.showWhenKey) && !this.showWhenInv && this.showWhenValue != null && !this.showWhenValue.isEmpty()) {
        } else {
            this.showWhenKey = key;
            this.showWhenInv = false;
            this.showWhenValue = value;
        }
        return this;
    }

    public ActionFieldSchema.Builder hideWhenEnum(String key, String value) {
        this.showWhenValue = this.showWhenValue + "|" + value;
        if (key.equals(this.showWhenKey) && this.showWhenInv && this.showWhenValue != null && !this.showWhenValue.isEmpty()) {
        } else {
            this.showWhenKey = key;
            this.showWhenInv = true;
            this.showWhenValue = value;
        }
        return this;
    }

    public ActionFieldSchema.Builder addLabel(String label) {
        this.addLabel = label;
        return this;
    }

    public ActionFieldSchema.Builder xyzKeys(String ... keys) {
        this.xyzKeys = keys;
        return this;
    }

    public ActionFieldSchema.Builder xyzDouble(boolean v) {
        this.xyzDouble = v;
        return this;
    }

    public ActionFieldSchema.Builder captureBlock() {
        this.captureMode = CaptureMode.BLOCK_ID;
        return this;
    }

    public ActionFieldSchema.Builder captureEntity() {
        this.captureMode = CaptureMode.ENTITY_ID;
        return this;
    }

    public ActionFieldSchema.Builder captureCatalog() {
        this.captureMode = CaptureMode.BLOCK_CATALOG;
        return this;
    }

    public ActionFieldSchema.Builder captureItemSlot() {
        this.captureMode = CaptureMode.ITEM_SLOT;
        return this;
    }

    public ActionFieldSchema.Builder exclusiveWith(String ... keys) {
        this.exclusiveWith = keys;
        return this;
    }

    public ActionFieldSchema build() {
        this.commit();
        return new ActionFieldSchema(new ArrayList(this.fields));
    }
}
