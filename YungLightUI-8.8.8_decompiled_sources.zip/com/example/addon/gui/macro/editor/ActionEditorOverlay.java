/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

import com.example.addon.gui.macro.editor.ActionFieldRegistry;
import com.example.addon.gui.macro.editor.ActionFieldSchema;
import com.example.addon.gui.macro.editor.CaptureMode;
import com.example.addon.gui.macro.editor.FieldDef;
import com.example.addon.gui.macro.editor.FieldType;
import com.example.addon.gui.packui.PackUiAssets;
import com.example.addon.gui.packui.PackUiListRenderer;
import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiRenderContext;
import com.example.addon.gui.packui.PackUiScrollViewport;
import com.example.addon.gui.packui.PackUiScrollbar;
import com.example.addon.gui.packui.PackUiSizing;
import com.example.addon.gui.packui.PackUiSmoothScroll;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.util.IPackUtilOverlay;
import com.example.addon.util.PackUtilChatField;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilClipboardHelper;
import com.example.addon.util.PackUtilColors;
import com.example.addon.util.PackUtilCompatManager;
import com.example.addon.util.PackUtilCraftingHelper;
import com.example.addon.util.PackUtilDropAction;
import com.example.addon.util.PackUtilInventoryHelper;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketNamer;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilPacketSelectorOverlay;
import com.example.addon.util.PackUtilRegistryLabels;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.PackUtilUiScale;
import com.example.addon.util.PackUtilWindow;
import com.example.addon.util.PackUtilWindowLayout;
import com.example.addon.util.macro.CloseGuiAction;
import com.example.addon.util.macro.CraftAction;
import com.example.addon.util.macro.DelayPacketsAction;
import com.example.addon.util.macro.DropAction;
import com.example.addon.util.macro.InventoryAuditAction;
import com.example.addon.util.macro.ItemAction;
import com.example.addon.util.macro.ItemTarget;
import com.example.addon.util.macro.LookAtBlockAction;
import com.example.addon.util.macro.MacroAction;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.MacroExecutor;
import com.example.addon.util.macro.OpenContainerAction;
import com.example.addon.util.macro.PayAction;
import com.example.addon.util.macro.RotateAction;
import com.example.addon.util.macro.SelectSlotAction;
import com.example.addon.util.macro.SendPacketAction;
import com.example.addon.util.macro.StoreItemAction;
import com.example.addon.util.macro.SwapSlotsAction;
import com.example.addon.util.macro.ToggleModuleAction;
import com.example.addon.util.macro.UseItemAction;
import com.example.addon.util.macro.WaitForChatAction;
import com.example.addon.util.macro.WaitForCooldownAction;
import com.example.addon.util.macro.WaitForEntityAction;
import com.example.addon.util.macro.WaitForLanStepAction;
import com.example.addon.util.macro.WaitForPacketAction;
import com.example.addon.util.macro.WaitForSlotChangeAction;
import com.example.addon.util.macro.WaitForSoundAction;
import com.example.addon.util.macro.XCarryAction;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.Predicate;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_1693;
import net.minecraft.class_1735;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3908;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_640;
import net.minecraft.class_7264;
import net.minecraft.class_7923;

public class ActionEditorOverlay
extends PackUtilWindow
implements IPackUtilOverlay {
    private static final class_310 MC = class_310.method_1551();
    private static final int DEFAULT_W = 208;
    private static final int COMPACT_W = 184;
    private static final int MIN_W = 168;
    private static final int MIN_H = 96;
    private static final int COMPACT_MIN_H = 88;
    private static final int PAD = 4;
    private static final int ROW_H = 15;
    private static final int ROW_GAP = 2;
    private static final int FOOTER_H = 22;
    private static final int LABEL_MIN_W = 44;
    private static final int LABEL_MAX_W = 68;
    private static final int FIELD_GAP = 3;
    private static final int CATALOG_LIST_H = 60;
    private static final int CATALOG_ITEM_H = 13;
    private static final int CAPTURE_BTN_W = 52;
    private static final int SEL_LIST_MAX_VIS = 4;
    private static final int SEL_ITEM_H = 15;
    private static final int CONTAINER_LIST_VISIBLE_ROWS = 2;
    private static final int CRAFT_LIST_ROWS = 4;
    private static final int CRAFT_LIST_H = 52;
    private static final int SCROLLBAR_W = 5;
    private static final int WAIT_CHAT_ROW_H = 34;
    private static final int WAIT_CHAT_VISIBLE_ROWS = 4;
    private static final int WAIT_CHAT_PATTERN_H = 40;
    private static final double WAIT_ENTITY_NEARBY_LIST_RADIUS = 16;
    private static final int EDITOR_HINT_ROW_H = 11;
    private static final int EDITOR_HINT_MAX_CHARS = "Waits until the main hand item cooldown is ready again.".length();
    private static final int EDITOR_GHOST_MAX_CHARS = 16;
    private static final long CAPTURE_TOAST_LIFETIME_MS = 700L;
    private static final float CAPTURE_TOAST_ENTER_MS = 140f;
    private static final float CAPTURE_TOAST_EXIT_MS = 180f;
    private static final int CAPTURE_TOAST_MAX_VISIBLE = 4;
    private static final int CAPTURE_TOAST_GAP = 4;
    private static final int CAPTURE_TOAST_HEIGHT = 18;
    private static final int CAPTURE_TOAST_SUCCESS = -10035062;
    private static final int CAPTURE_TOAST_ERROR = -38037;
    private static List<String> ALL_BLOCK_IDS;
    private static List<String> ALL_SOUND_IDS;
    private static List<String> ALL_ENTITY_IDS;
    private static List<String> ALL_ITEM_IDS;
    private final class_327 textRenderer;
    private final PackUiTheme theme = new PackUiTheme();
    private final PackUtilPacketSelectorOverlay packetSelectorOverlay;
    private int panelX = 320;
    private int panelY = 60;
    private int panelW = 208;
    private int panelH = 96;
    private boolean visible = false;
    private boolean dragging = false;
    private double dragOffX;
    private double dragOffY;
    private boolean restoreVisibleAfterCapture = false;
    private class_437 screenBeforeGBreak;
    private class_437 screenBeforeCapture;
    private boolean entitySpecificCaptureMode = false;
    private MacroAction targetAction;
    private class_2487 workingTag;
    private ActionFieldSchema schema;
    private Runnable onSaveCallback;
    private final Map<String, PackUtilChatField> textFields = new LinkedHashMap();
    private final Map<String, Boolean> toggleStates = new LinkedHashMap();
    private final Map<String, Integer> enumIndices = new LinkedHashMap();
    private final Map<String, List<String>> stringLists = new LinkedHashMap();
    private final Map<String, ItemTarget> editorItemFields = new HashMap();
    private final Map<String, List<ItemTarget>> editorItemLists = new HashMap();
    private final Map<String, PackUtilChatField> addFields = new LinkedHashMap();
    private final Map<String, Integer> catalogScrollOffsets = new HashMap();
    private final Map<String, PackUiSmoothScroll> catalogScrollStates = new HashMap();
    private final Map<String, PackUiScrollViewport> catalogScrollViewports = new HashMap();
    private final Map<String, int[]> catalogListBounds = new HashMap();
    private final Map<String, Integer> stringListEditIndex = new HashMap();
    private final Map<String, String> stringListEditPendingText = new HashMap();
    private final Map<String, Integer> selectedScrollOffsets = new HashMap();
    private final Map<String, PackUiSmoothScroll> selectedScrollStates = new HashMap();
    private final Map<String, PackUiScrollViewport> selectedScrollViewports = new HashMap();
    private final Map<String, int[]> selectedListBounds = new HashMap();
    private int scrollOffset = 0;
    private ItemAction itemAction;
    private String itemSlotCapturePendingKey;
    private List<IPackUtilOverlay> captureHiddenOverlays;
    private final List<ActionEditorOverlay.CaptureToast> captureToasts = new ArrayList();
    private List<CraftAction.CraftEntry> craftEntries;
    private List<PackUtilCraftingHelper.CraftableRecipeOption> craftAllRecipes;
    private List<PackUtilCraftingHelper.CraftableRecipeOption> craftFilteredRecipes;
    private PackUtilCraftingHelper.CraftableRecipeOption craftSelectedRecipe;
    private int craftRecipeScrollOffset;
    private boolean craftUseMax;
    private String craftLastQuery;
    private int[] craftRecipeListBounds;
    private DropAction dropAction;
    private int itemEditIndex = -1;
    private int dropEditIndex = -1;
    private int wscEditIndex = -1;
    private List<WaitForSlotChangeAction.WaitEntry> wscEntries;
    private WaitForSlotChangeAction.WaitMode wscAddMode = WaitForSlotChangeAction.WaitMode.NOT_EMPTY;
    private int wscAddCount = 1;
    private boolean suppressItemEntryLiveUpdate = false;
    private boolean suppressDropEntryLiveUpdate = false;
    private boolean suppressWscLiveUpdate = false;
    private boolean suppressDropCountEditorUpdate = false;
    private int waitChatSourceFilterMode = 0;
    private boolean waitChatFuzzySliderDragging = false;
    private int waitChatFuzzySliderX = -1;
    private int waitChatFuzzySliderY = -1;
    private int waitChatFuzzySliderW = 0;
    private int waitChatFuzzySliderH = 0;
    private boolean rotateSmoothnessSliderDragging = false;
    private int rotateSmoothnessSliderX = -1;
    private int rotateSmoothnessSliderY = -1;
    private int rotateSmoothnessSliderW = 0;
    private int rotateSmoothnessSliderH = 0;
    private boolean suppressWaitChatPatternSync = false;
    private List<WaitForLanStepAction.LanStepEntry> lanStepEntries;
    private final List<String> payScannedPlayers = new ArrayList();
    private boolean payPlayerScanPerformed = false;
    private final List<String> meteorModuleNames = new ArrayList();
    private List<ToggleModuleAction.ModuleEntry> toggleModuleEntries;
    private Runnable onPreSave;
    private final List<ActionEditorOverlay.HitRegion> hitRegions = new ArrayList();
    private float frameDelta = 0f;
    private final List<ActionEditorOverlay.ScrollDragRegion> scrollDragRegions = new ArrayList();
    private IntConsumer activeScrollDragHandler = null;
    private static ActionEditorOverlay sharedInstance;

    public static ActionEditorOverlay getSharedOverlay() {
        if (sharedInstance == null) {
            sharedInstance = new ActionEditorOverlay(MC.field_1772);
            PackUtilOverlayManager.get().register(sharedInstance);
        }
        return sharedInstance;
    }

    private static boolean isCompactEditorType(MacroActionType type) {
        if (type == null) {
            return false;
        }
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$util$macro$MacroActionType[type.ordinal()]) {
            case 1::
            case 2::
            case 3::
            case 4::
            case 5::
                return true;
            default:
                return false;
        }
    }

    private int preferredPanelWidthFor(MacroAction action) {
        return ActionEditorOverlay.isCompactEditorType(action == null ? null : action.getType()) ? 184 : 208;
    }

    private int currentMinPanelHeight() {
        return ActionEditorOverlay.isCompactEditorType(this.targetAction == null ? null : this.targetAction.getType()) ? 88 : 96;
    }

    public static boolean supportsActionEditor(MacroAction action) {
        if (action == null) {
            return false;
        }
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$util$macro$MacroActionType[action.getType().ordinal()]) {
            case 6::
            case 7::
            case 8::
            case 9::
            case 10::
            case 11::
                return true;
            default:
                return !ActionFieldRegistry.get(action.getType()).fields().isEmpty();
        }
    }

    public static ActionEditorOverlay getSharedOverlayIfExists() {
        return sharedInstance;
    }

    public ActionEditorOverlay(class_327 textRenderer) {
        this.textRenderer = textRenderer;
        this.packetSelectorOverlay = new PackUtilPacketSelectorOverlay(textRenderer);
    }

    public void open(MacroAction action, Runnable onPreSave, Runnable onSave) {
        this.targetAction = action;
        this.onPreSave = onPreSave;
        this.onSaveCallback = onSave;
        this.workingTag = action.toTag();
        this.schema = ActionFieldRegistry.get(action.getType());
        this.scrollOffset = 0;
        this.textFields.clear();
        this.toggleStates.clear();
        this.enumIndices.clear();
        this.stringLists.clear();
        this.editorItemFields.clear();
        this.editorItemLists.clear();
        this.addFields.clear();
        this.catalogScrollOffsets.clear();
        this.catalogScrollStates.clear();
        this.catalogScrollViewports.clear();
        this.catalogListBounds.clear();
        this.selectedScrollOffsets.clear();
        this.selectedScrollStates.clear();
        this.selectedScrollViewports.clear();
        this.selectedListBounds.clear();
        this.packetSelectorOverlay.close();
        this.prepareWorkingTagForEditor(action);
        ItemAction ia = this.schema.fields().iterator();
        while (ia.hasNext()) {
            FieldDef field = (FieldDef)ia.next();
            String key = field.key();
            switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$gui$macro$editor$FieldType[field.type().ordinal()]) {
                case 1::
                    this.toggleStates.put(key, this.workingTag.method_10545(key) ? this.workingTag.method_68566(key, false) : false);
                    break;
                case 2::
                    int v = this.workingTag.method_10545(key) ? this.workingTag.method_68083(key, 0) : 0;
                    PackUtilChatField f = this.makeField(80);
                    f.setNumericOnly(true);
                    f.setText(String.valueOf(v));
                    this.textFields.put(key, f);
                    break;
                case 3::
                    v = this.workingTag.method_10545(key) ? this.workingTag.method_68563(key, 0) : 0;
                    PackUtilChatField f = this.makeField(80);
                    f.setFilter(ActionEditorOverlay::lambda$open$0);
                    f.setText(ActionEditorOverlay.fmtDouble(v));
                    this.textFields.put(key, f);
                    break;
                case 4::
                    v = this.workingTag.method_10545(key) ? this.workingTag.method_68564(key, "") : "";
                    f = this.makeField(80);
                    f.setText(v);
                    this.textFields.put(key, f);
                    break;
                case 5::
                    v = this.workingTag.method_10545(key) ? this.workingTag.method_68564(key, "") : "";
                    opts = field.enumOptions();
                    idx = opts.indexOf(v);
                    if (!idx < 0) continue;
                    idx = opts.indexOf(v.toUpperCase());
                    this.enumIndices.put(key, Math.max(0, idx));
                    break;
                case 6::
                    v = this.workingTag.method_10545(key) ? this.workingTag.method_68083(key, 0) : 0;
                    f = this.makeField(50);
                    f.setNumericOnly(false);
                    f.setText(String.valueOf(v));
                    this.textFields.put(key, f);
                    break;
                case 7::
                    xyzKeys = field.xyzKeys();
                    dbl = field.xyzDouble();
                    for (i = 0; i < 3; i++) {
                        PackUtilChatField f = this.makeField(50);
                        if (dbl) {
                            f.setFilter(ActionEditorOverlay::lambda$open$1);
                            double v = this.workingTag.method_10545(xyzKeys[i]) ? this.workingTag.method_68563(xyzKeys[i], 0) : 0;
                            f.setText(ActionEditorOverlay.fmtDouble(v));
                        } else {
                            f.setNumericOnly(true);
                            int v = this.workingTag.method_10545(xyzKeys[i]) ? this.workingTag.method_68083(xyzKeys[i], 0) : 0;
                            f.setText(String.valueOf(v));
                        }
                        this.textFields.put(key + "_" + i, f);
                    }
                    break;
                case 8::
                    list = new ArrayList();
                    if (!this.workingTag.method_10545(key)) { /* goto L990; */ }
                    nl = (class_2499)this.workingTag.method_10554(key).orElse(new class_2499());
                    modes = nl.iterator();
                    while (modes.hasNext()) {
                        el = (class_2520)modes.next();
                        s = (String)el.method_68658().orElse("");
                        if (s.isEmpty()) continue;
                        list.add(s);
                    }
                    this.stringLists.put(key, list);
                    af = this.makeField(80);
                    if (field.captureMode() == CaptureMode.BLOCK_CATALOG) {
                        af.setPlaceholder(class_2561.method_43470("Search blocks..."));
                    } else {
                        af.setPlaceholder(class_2561.method_43470("Search / " + field.addLabel()));
                        af.setSubmitHandler(this::lambda$open$2 /* captured: key, field, af */);
                    }
                    this.addFields.put(key, af);
                default:
            }
        }
        this.itemAction = null;
        this.itemSlotCapturePendingKey = null;
        this.itemEditIndex = -1;
        this.dropEditIndex = -1;
        if (!action instanceof ItemAction) { /* goto L1742; */ }
        ia = (ItemAction)action;
        this.itemAction = new ItemAction();
        this.itemAction.itemNames = new ArrayList(ia.itemNames);
        this.itemAction.itemTargets = this.copyEditorTargets(ia.itemTargets, ia.itemNames);
        this.itemAction.itemTimes = new ArrayList(ia.itemTimes);
        this.itemAction.itemActionIdx = new ArrayList(ia.itemActionIdx);
        this.itemAction.itemButtons = new ArrayList(ia.itemButtons);
        while (this.itemAction.itemTimes.size() < this.itemAction.itemNames.size()) {
            this.itemAction.itemTimes.add(1);
        }
        while (this.itemAction.itemActionIdx.size() < this.itemAction.itemNames.size()) {
            this.itemAction.itemActionIdx.add(0);
        }
        while (this.itemAction.itemButtons.size() < this.itemAction.itemNames.size()) {
            this.itemAction.itemButtons.add(0);
        }
        this.itemAction.targetSlot = ia.targetSlot;
        this.itemAction.useSlot = ia.useSlot;
        this.itemAction.actionIndex = ia.actionIndex;
        this.itemAction.button = ia.button;
        this.itemAction.times = ia.times;
        this.itemAction.waitForGui = ia.waitForGui;
        this.itemAction.guiName = ia.guiName != null ? ia.guiName : "";
        this.itemAction.waitForItem = ia.waitForItem;
        for (i = 0; i < this.itemAction.itemNames.size(); i++) {
            f = this.makeField(28);
            f.setNumericOnly(true);
            f.setText(String.valueOf(this.itemAction.getItemTime(i)));
            this.textFields.put("item_times_" + i, f);
        }
        addF = this.makeField(120);
        addF.setPlaceholder(class_2561.method_43470("Item name"));
        addF.setChangedListener(this::lambda$open$3);
        this.addFields.put("_item_add", addF);
        addSlotF = this.makeField(52);
        addSlotF.setNumericOnly(true);
        addSlotF.setPlaceholder(class_2561.method_43470("Slot"));
        addSlotF.setChangedListener(this::lambda$open$4);
        this.textFields.put("item_entrySlot", addSlotF);
        this.toggleStates.put("item_waitForGui", ia.waitForGui);
        this.toggleStates.put("item_waitForItem", ia.waitForItem);
        guiF = this.makeField(80);
        guiF.setText(ia.guiName != null ? ia.guiName : "");
        this.textFields.put("item_guiName", guiF);
        L1742: ;
        this.wscEditIndex = -1;
        this.wscEntries = new ArrayList();
        this.wscAddMode = WaitForSlotChangeAction.WaitMode.NOT_EMPTY;
        this.wscAddCount = 1;
        if (!action instanceof WaitForSlotChangeAction) { /* goto L1835; */ }
        wsc = (WaitForSlotChangeAction)action;
        wscSlotF = wsc.entries.iterator();
        while (wscSlotF.hasNext()) {
            e = (WaitForSlotChangeAction.WaitEntry)wscSlotF.next();
            this.wscEntries.add(e.copy());
        }
        if (action.getType() == MacroActionType.WAIT_SLOT_CHANGE) {
            wscAddF = this.makeField(120);
            wscAddF.setPlaceholder(class_2561.method_43470("Item name (optional)"));
            wscAddF.setChangedListener(this::lambda$open$5);
            this.addFields.put("_wsc_add", wscAddF);
            wscSlotF = this.makeField(52);
            wscSlotF.setNumericOnly(true);
            wscSlotF.setPlaceholder(class_2561.method_43470("Slot #"));
            wscSlotF.setChangedListener(this::lambda$open$6);
            this.textFields.put("wsc_slot", wscSlotF);
            wscCountF = this.makeField(36);
            wscCountF.setNumericOnly(true);
            wscCountF.setPlaceholder(class_2561.method_43470("Count"));
            wscCountF.setChangedListener(this::lambda$open$7);
            this.textFields.put("wsc_count", wscCountF);
        }
        this.craftEntries = null;
        this.craftAllRecipes = null;
        this.craftFilteredRecipes = null;
        this.craftSelectedRecipe = null;
        this.craftRecipeScrollOffset = 0;
        this.craftUseMax = false;
        this.craftLastQuery = null;
        this.craftRecipeListBounds = null;
        if (!action instanceof CraftAction) { /* goto L2262; */ }
        craftAction = (CraftAction)action;
        this.craftEntries = craftAction.copyEntries();
        for (i = 0; i < this.craftEntries.size(); i++) {
            entry = (CraftAction.CraftEntry)this.craftEntries.get(i);
            f = this.makeField(44);
            f.setNumericOnly(true);
            f.setText(String.valueOf(entry.amount));
            this.textFields.put("craft_amount_" + i, f);
            this.toggleStates.put("craft_useMax_" + i, entry.useMaxAmount);
        }
        amtF = this.makeField(44);
        amtF.setNumericOnly(true);
        amtF.setText("1");
        this.textFields.put("_craft_amount", amtF);
        srchF = this.makeField(180);
        srchF.setPlaceholder(class_2561.method_43470("Search recipes..."));
        this.addFields.put("_craft_search", srchF);
        this.craftAllRecipes = PackUtilCraftingHelper.getCraftableRecipes(MC);
        this.craftFilteredRecipes = PackUtilCraftingHelper.filterRecipes(this.craftAllRecipes, "");
        L2262: ;
        if (action instanceof WaitForPacketAction) {
            waitForPacketAction = (WaitForPacketAction)action;
            this.stringLists.put("packetNames", this.sanitizeWaitPacketTargets(waitForPacketAction.effectiveList()));
        }
        this.dropAction = null;
        if (!action instanceof DropAction) { /* goto L2892; */ }
        da = (DropAction)action;
        this.dropAction = new DropAction();
        this.dropAction.mode = da.mode;
        this.dropAction.dropCount = da.dropCount;
        this.dropAction.itemNames = new ArrayList(da.itemNames);
        this.dropAction.itemTargets = this.copyEditorTargets(da.itemTargets, da.itemNames);
        this.dropAction.itemCounts = new ArrayList(da.itemCounts);
        this.dropAction.waitForGui = da.waitForGui;
        this.dropAction.guiName = da.guiName != null ? da.guiName : "";
        this.dropAction.useHandlerSlots = da.useHandlerSlots;
        while (this.dropAction.itemCounts.size() < this.dropAction.itemNames.size()) {
            this.dropAction.itemCounts.add(1);
        }
        for (i = 0; i < this.dropAction.itemNames.size(); i++) {
            f = this.makeField(32);
            f.setNumericOnly(true);
            f.setText(String.valueOf(this.dropAction.itemCounts.get(i)));
            this.textFields.put("drop_count_" + i, f);
        }
        cntF = this.makeField(60);
        cntF.setNumericOnly(true);
        cntF.setText(String.valueOf(da.dropCount));
        cntF.setChangedListener(this::lambda$open$8);
        this.textFields.put("drop_globalCount", cntF);
        addDropF = this.makeField(120);
        addDropF.setPlaceholder(class_2561.method_43470("Item name..."));
        addDropF.setChangedListener(this::lambda$open$9);
        this.addFields.put("_drop_add", addDropF);
        addDropSlotF = this.makeField(52);
        addDropSlotF.setNumericOnly(true);
        addDropSlotF.setPlaceholder(class_2561.method_43470("Slot"));
        addDropSlotF.setChangedListener(this::lambda$open$10);
        this.textFields.put("drop_entrySlot", addDropSlotF);
        dropGuiF = this.makeField(80);
        dropGuiF.setText(da.guiName != null ? da.guiName : "");
        this.textFields.put("drop_guiName", dropGuiF);
        this.toggleStates.put("drop_waitForGui", da.waitForGui);
        this.toggleStates.put("drop_useHandlerSlots", da.useHandlerSlots);
        modes = DropAction.DropMode.values();
        mi = 0;
        i = 0;
        while (i < modes.length) {
            if (modes[i] == da.mode) {
                mi = i;
            } else {
                i++;
            }
        }
        this.enumIndices.put("drop_mode", mi);
        this.syncDropCountEditorField();
        L2892: ;
        this.lanStepEntries = null;
        if (!action instanceof WaitForLanStepAction) { /* goto L3241; */ }
        wls = (WaitForLanStepAction)action;
        this.lanStepEntries = new ArrayList();
        i = wls.entries.iterator();
        while (i.hasNext()) {
            e = (WaitForLanStepAction.LanStepEntry)i.next();
            this.lanStepEntries.add(new WaitForLanStepAction.LanStepEntry(e.username, e.step));
        }
        for (i = 0; i < this.lanStepEntries.size(); i++) {
            e = (WaitForLanStepAction.LanStepEntry)this.lanStepEntries.get(i);
            uf = this.makeField(80);
            uf.setText(e.username);
            this.textFields.put("lan_user_" + i, uf);
            sf = this.makeField(40);
            sf.setNumericOnly(true);
            sf.setText(String.valueOf(e.step));
            this.textFields.put("lan_step_" + i, sf);
        }
        newUF = this.makeField(80);
        newUF.setPlaceholder(class_2561.method_43470("Peer name..."));
        this.addFields.put("_lan_user_add", newUF);
        newSF = this.makeField(40);
        newSF.setNumericOnly(true);
        newSF.setText("1");
        this.addFields.put("_lan_step_add", newSF);
        dsF = this.makeField(60);
        dsF.setNumericOnly(true);
        dsF.setText(String.valueOf(wls.defaultStep));
        this.textFields.put("lan_defaultStep", dsF);
        this.toggleStates.put("lan_filterByUser", wls.filterByUser);
        L3241: ;
        this.entitySpecificCaptureMode = false;
        if (action instanceof WaitForSoundAction) {
            search = (PackUtilChatField)this.addFields.get("soundIds");
            if (search != null) {
                search.setPlaceholder(class_2561.method_43470("Search sound id..."));
            }
        }
        if (action instanceof WaitForEntityAction) {
            search = (PackUtilChatField)this.addFields.get("entityIds");
            if (search != null) {
                search.setPlaceholder(class_2561.method_43470("Search entity type..."));
            }
        }
        if (action instanceof LookAtBlockAction) {
            search = (PackUtilChatField)this.addFields.get("entityIds");
            if (search != null) {
                search.setPlaceholder(class_2561.method_43470("Search entity type..."));
            }
        }
        if (action instanceof StoreItemAction) {
            search = (PackUtilChatField)this.addFields.get("targetItems");
            if (search != null) {
                search.setPlaceholder(class_2561.method_43470("Search item id..."));
            }
        }
        if (action instanceof InventoryAuditAction) {
            search = (PackUtilChatField)this.addFields.get("targetItems");
            if (search != null) {
                search.setPlaceholder(class_2561.method_43470("Item name"));
            }
        }
        this.payScannedPlayers.clear();
        this.payPlayerScanPerformed = false;
        if (action instanceof PayAction) {
            search = (PackUtilChatField)this.addFields.get("players");
            if (search != null) {
                search.setPlaceholder(class_2561.method_43470("Search or add player..."));
            }
        }
        this.meteorModuleNames.clear();
        this.toggleModuleEntries = null;
        if (!action instanceof ToggleModuleAction) { /* goto L3665; */ }
        search = this.makeField(180);
        search.setPlaceholder(class_2561.method_43470("Search Meteor module..."));
        this.addFields.put("_toggle_module_search", search);
        this.refreshMeteorModuleNames();
        toggleModuleAction = (ToggleModuleAction)action;
        this.toggleModuleEntries = new ArrayList();
        initialPattern = toggleModuleAction.entries.iterator();
        while (initialPattern.hasNext()) {
            entry = (ToggleModuleAction.ModuleEntry)initialPattern.next();
            if (entry != null) {
                if (entry.moduleName != null) {
                    if (entry.moduleName.isBlank()) continue;
                    this.toggleModuleEntries.add(new ToggleModuleAction.ModuleEntry(entry.moduleName, entry.toggleMode));
                }
            }
        }
        if (action instanceof WaitForChatAction) {
            search = this.makeField(180);
            search.setPlaceholder(class_2561.method_43470("Search recent chat..."));
            this.addFields.put("_wait_chat_search", search);
            this.waitChatSourceFilterMode = 0;
            this.waitChatFuzzySliderDragging = false;
            this.clearWaitChatFuzzySliderBounds();
            patternField = (PackUtilChatField)this.textFields.get("pattern");
            if (patternField != null) {
                patternField.setMultiline(true);
                patternField.setHeight(40);
                initialPattern = this.getWaitChatPatternComponent(this.workingTag.method_68564("pattern", ""));
                visiblePattern = initialPattern.getString();
                this.workingTag.method_10582("pattern", visiblePattern);
                this.workingTag.method_10582("patternJson", MacroExecutor.serializeTextComponent(initialPattern));
                patternField.setDisplayTextProvider(this::getWaitChatPatternComponent);
                this.suppressWaitChatPatternSync = true;
                patternField.setText(visiblePattern);
                this.suppressWaitChatPatternSync = false;
                patternField.setChangedListener(this::lambda$open$11);
            }
        } else {
            this.suppressWaitChatPatternSync = false;
            this.waitChatFuzzySliderDragging = false;
            this.clearWaitChatFuzzySliderBounds();
        }
        if (action instanceof RotateAction) {
            this.rotateSmoothnessSliderDragging = false;
            this.clearRotateSmoothnessSliderBounds();
            rotateAction = (RotateAction)action;
            smoothnessField = (PackUtilChatField)this.textFields.get("smoothness");
            smoothness = RotateAction.clampSmoothness(rotateAction.smoothness);
            this.workingTag.method_10569("smoothness", smoothness);
            if (smoothnessField != null) {
                smoothnessField.setText(String.valueOf(smoothness));
            }
        } else {
            if (action instanceof LookAtBlockAction) {
                lookAtAction = (LookAtBlockAction)action;
                this.rotateSmoothnessSliderDragging = false;
                this.clearRotateSmoothnessSliderBounds();
                smoothnessField = (PackUtilChatField)this.textFields.get("smoothness");
                smoothness = RotateAction.clampSmoothness(lookAtAction.smoothness);
                this.workingTag.method_10569("smoothness", smoothness);
                if (smoothnessField != null) {
                    smoothnessField.setText(String.valueOf(smoothness));
                }
            } else {
                this.rotateSmoothnessSliderDragging = false;
                this.clearRotateSmoothnessSliderBounds();
            }
        }
        if (action.getType() != MacroActionType.INVENTORY) {
            if (action.getType() == MacroActionType.CLOSE_GUI) { /* goto @4070; */ }
        }
        this.toggleStates.put("sendPacket", !this.workingTag.method_68566("sendPacket", true));
        L4105: ;
        if (action.getType() != MacroActionType.STORE_ITEM) { /* goto L4152; */ }
        this.toggleStates.put("closeSendPkt", !this.workingTag.method_68566("closeSendPkt", true));
        this.refreshItemTextDisplayProviders();
        this.applyEditorPlaceholders();
        this.panelW = this.preferredPanelWidthFor(action);
        contentH = this.computeContentH();
        desiredH = 20 + contentH + 22 + 4;
        minH = this.currentMinPanelHeight();
        maxH = Math.max(minH, PackUtilUiScale.getVirtualScreenHeight() * 4 / 5);
        this.panelH = Math.max(minH, Math.min(maxH, desiredH));
        this.visible = true;
        PackUtilOverlayManager.get().bringToFront(this);
    }

    public String getOverlayId() {
        return "packutil-action-editor";
    }

    public int getMinWidth() {
        return 168;
    }

    public int getMinHeight() {
        return this.currentMinPanelHeight();
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean v) {
        this.visible = v;
        if (v) {
            this.hitRegions.clear();
            this.scrollDragRegions.clear();
        }
    }

    public PackUtilWindowLayout getBounds() {
        int neededH = 20 + this.computeContentH() + 22 + 4;
        int minH = this.currentMinPanelHeight();
        int maxH = Math.max(minH, PackUtilUiScale.getVirtualScreenHeight() * 4 / 5);
        int h = Math.max(minH, Math.min(maxH, neededH));
        return new PackUtilWindowLayout(this.panelX, this.panelY, this.panelW, h, this.visible, false);
    }

    public void setBounds(PackUtilWindowLayout b) {
        PackUtilWindowLayout c = this.clampToScreen(this, b);
        this.panelX = c.x;
        this.panelY = c.y;
        this.panelW = Math.max(168, c.width);
        this.panelH = Math.max(this.currentMinPanelHeight(), c.height);
        this.visible = c.visible;
    }

    public boolean isMouseOver(double mx, double my) {
        if (!this.packetSelectorOverlay.isVisible()) {
            if (mx >= (double)this.panelX) {
                if (mx < (double)(this.panelX + this.panelW)) {
                    if (my < (double)this.panelY) { /* goto @71; */ }
                }
            }
        }
        return this.visible;
    }

    public boolean isOverDragBar(double mx, double my) {
        return this.visible && mx >= (double)this.panelX && mx < (double)(this.panelX + this.panelW) && my >= (double)this.panelY && my < (double)(this.panelY + 16);
    }

    public boolean hasTextFieldFocused() {
        if (this.packetSelectorOverlay.hasTextFieldFocused()) {
            return true;
        }
        var var1 = this.textFields.values().iterator();
        while (var1.hasNext()) {
            PackUtilChatField f = (PackUtilChatField)var1.next();
            if (!f.isFocused()) continue;
            return true;
        }
        var1 = this.addFields.values().iterator();
        while (var1.hasNext()) {
            f = (PackUtilChatField)var1.next();
            if (!f.isFocused()) continue;
            return true;
        }
        return false;
    }

    public void clearTextFieldFocus() {
        this.textFields.values().forEach(ActionEditorOverlay::lambda$clearTextFieldFocus$12);
        this.addFields.values().forEach(ActionEditorOverlay::lambda$clearTextFieldFocus$13);
    }

    public boolean wantsItemSlotCapture() {
        return this.itemSlotCapturePendingKey != null;
    }

    public boolean shouldRenderHandledScreenCaptureBanner() {
        return this.itemSlotCapturePendingKey != null;
    }

    public String getHandledScreenCaptureTitle() {
        return "Capturing " + this.getHandledScreenCaptureTargetLabel() + " - " + this.getCaptureActionLabel();
    }

    public String getHandledScreenCaptureInstruction() {
        if ("_item_entries".equals(this.itemSlotCapturePendingKey) || "_drop_entries".equals(this.itemSlotCapturePendingKey)) {
            return "Right-click a slot to set slot + item. Esc = cancel";
        }
        if ("_wsc_entries".equals(this.itemSlotCapturePendingKey)) {
            return "Right-click slots to add items or exact slots. Esc = done";
        }
        if (this.stringLists.containsKey(this.itemSlotCapturePendingKey)) {
            if (this.isXCarryListKey(this.itemSlotCapturePendingKey)) {
                return "Right-click slots to add items, or empty slots for exact slots. Esc = done";
            }
            return "Right-click slots to add item names. Esc = done";
        }
        return "Right-click a slot in this screen. Esc = cancel";
    }

    public String getHandledScreenCaptureHoverText(class_1735 slot, String itemName, String registryId) {
        if (slot == null) {
            return "";
        }
        int visibleSlot = PackUtilInventoryHelper.toUserVisibleSlot(MC, slot.field_7874);
        String slotText = visibleSlot >= 0 ? String.valueOf(visibleSlot) : "Handler " + slot.field_7874;
        String slotDetail = "Handler " + slot.field_7874;
        String itemText = !registryId.isEmpty() ? registryId : !itemName.isEmpty() ? itemName : "Empty slot";
        return slotText.equals(slotDetail) ? "Hover: " + slotText + " | " + itemText : "Hover: " + slotText + " | " + slotDetail + " | " + itemText;
    }

    public boolean cancelCaptureIfActive() {
        if (this.itemSlotCapturePendingKey == null) {
            return false;
        }
        this.itemSlotCapturePendingKey = null;
        this.exitCaptureMode(false, false);
        return true;
    }

    public boolean hasActiveCaptureSession() {
        PackUtilSharedState state = PackUtilSharedState.get();
        return this.itemSlotCapturePendingKey != null || this.captureHiddenOverlays != null || this.restoreVisibleAfterCapture || this.screenBeforeCapture != null || this.screenBeforeGBreak != null || state.hasCaptureCancelCallback() || state.hasBlockCaptureCallback() || state.hasEntityCaptureCallback() || state.hasAttackCaptureCallback() || state.isGBreakCapturing();
    }

    public boolean onInventorySlotCapture(class_1735 slot, String itemName, String registryId) {
        int visibleSlot = slot != null ? PackUtilInventoryHelper.toUserVisibleSlot(MC, slot.field_7874) : -1;
        ItemTarget capturedTarget = this.captureItemTarget(slot, itemName, registryId, visibleSlot);
        if (this.itemSlotCapturePendingKey != null) {
            if (!itemName.isEmpty()) { /* goto @52; */ }
        }
        return false;
        L52: ;
        String key = this.itemSlotCapturePendingKey;
        this.applyCapturedItemEntry(capturedTarget);
        if ("_item_entries".equals(key) && this.itemAction != null) {
            this.itemSlotCapturePendingKey = null;
            this.exitCaptureMode(false, false);
            return true;
        }
        this.applyCapturedDropEntry(capturedTarget);
        if ("_drop_entries".equals(key) && this.dropAction != null) {
            this.itemSlotCapturePendingKey = null;
            this.exitCaptureMode(false, false);
            return true;
        }
        if (!"_wsc_entries".equals(key)) { /* goto L401; */ }
        String rawTarget = capturedTarget.toLegacyEntry();
        if (rawTarget == null) {
            this.showCaptureToast("Nothing to add from that slot", -38037);
            return true;
        }
        String norm = StoreItemAction.normalizeTargetEntry(rawTarget);
        if (norm == null || norm.isBlank()) {
            this.showCaptureToast("Nothing to add from that slot", -38037);
            return true;
        }
        String disp = StoreItemAction.formatTargetEntry(norm);
        if (this.wscEditIndex >= 0) {
            if (this.wscEditIndex >= this.wscEntries.size()) { /* goto @313; */ }
            if (!this.wscTargetExistsOtherThan(norm, this.wscEditIndex)) {
                WaitEntry entry = (WaitForSlotChangeAction.WaitEntry)this.wscEntries.get(this.wscEditIndex);
                entry.target = norm;
                entry.itemTarget = capturedTarget.copy();
                this.syncWscEditorFromEntry(entry);
                this.showCaptureToast("Updated: " + disp, -10035062);
            } else {
                this.showCaptureToast("Already in list: " + disp, -38037);
            }
        } else {
            if (this.wscTargetExists(norm)) {
                this.showCaptureToast("Already added: " + disp, -38037);
            } else {
                WaitEntry entry = new WaitForSlotChangeAction.WaitEntry(norm, this.wscAddMode, this.wscAddCount);
                entry.itemTarget = capturedTarget.copy();
                entry.target = norm;
                this.wscEntries.add(entry);
                this.showCaptureToast("Added: " + disp, -10035062);
            }
        }
        return true;
        L401: ;
        if (!this.stringLists.containsKey(key)) { /* goto L622; */ }
        list = (List)this.stringLists.get(key);
        if (list == null) {
            return false;
        }
        if (this.isXCarryListKey(key)) { /* goto L490; */ }
        result = this.isStoreItemTargetListKey(key) ? this.tryAddCapturedStoreItemEntry(slot, itemName, registryId, visibleSlot, list) : this.tryAddCapturedStringListEntry(this.findField(key), key, list, this.isInventoryAuditTargetListKey(key) ? ActionEditorOverlay.stripSlotFromTarget(capturedTarget).toLegacyEntry() : this.usesStoreTargetFormatting(key) ? capturedTarget.toLegacyEntry() : itemName);
        if (result != null) {
            if (result.added()) {
                if (this.usesStoreTargetFormatting(key) || this.isXCarryListKey(key) || this.isInventoryAuditTargetListKey(key)) {
                    this.editorItemLists.put(key, this.buildStructuredListTargets(key));
                }
            }
        }
        if (result != null) {
            if (result.message() != null) {
                if (!result.message().isBlank()) {
                    this.showCaptureToast(result.message(), result.accentColor());
                }
            }
        }
        return true;
        L622: ;
        tf = (PackUtilChatField)this.textFields.get(key);
        if (tf == null) { /* goto L771; */ }
        field = this.findField(key);
        if (field != null) {
            if (field.type() == FieldType.SLOT) {
                tf.setText(String.valueOf(Math.max(0, visibleSlot)));
            }
        } else {
            tf.setText(capturedTarget.editorText());
            if ("itemName".equals(key) || "fromItemName".equals(key) || "toItemName".equals(key) || this.editorItemFields.containsKey(key)) {
                this.editorItemFields.put(key, capturedTarget.copy());
            }
        }
        this.itemSlotCapturePendingKey = null;
        this.exitCaptureMode(false, false);
        return true;
        L771: ;
        return false;
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }
        this.frameDelta = delta;
        this.hitRegions.clear();
        this.scrollDragRegions.clear();
        this.catalogListBounds.clear();
        int neededH = 20 + this.computeContentH() + 22 + 4;
        int minH = this.currentMinPanelHeight();
        int maxH = Math.max(minH, PackUtilUiScale.getVirtualScreenHeight() * 4 / 5);
        this.panelH = Math.max(minH, Math.min(maxH, neededH));
        title = this.targetAction != null ? ActionEditorOverlay.formatTypeName(this.targetAction.getType()) : "Edit Action";
        bounds = this.getBounds();
        this.renderWindowFrame(context, mouseX, mouseY, bounds, title, false, this.dragging);
        clipBody = this.beginWindowBodyClip(context, bounds, false);
        try {
            int frameH = this.getRenderedFrameHeight(bounds, false);
            int bodyTop = this.panelY + 16;
            int bodyBtm = this.panelY + frameH;
            if (bodyBtm > bodyTop + 1) {
                this.renderBody(context, mouseX, mouseY, delta, bodyTop, bodyBtm);
            }
        }
        finally {
            this.endWindowBodyClip(context, true);
            throw var11;
        }
        this.renderWindowInactiveOverlay(context, bounds, false, this.dragging);
        if (this.packetSelectorOverlay.isVisible()) {
            this.packetSelectorOverlay.render(context, mouseX, mouseY, delta);
        }
    }

    private void renderBody(class_332 context, int mouseX, int mouseY, float delta, int bodyTop, int bodyBtm) {
        if (this.itemAction != null) {
            int x = this.panelX + 4;
            int w = this.panelW - 8;
            this.renderItemPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
        } else {
            if (this.targetAction != null) {
                if (this.targetAction.getType() == MacroActionType.SEND_PACKET) {
                    int x = this.panelX + 4;
                    int w = this.panelW - 8;
                    this.renderSendPacketPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                }
            } else {
                if (this.targetAction != null) {
                    if (this.targetAction.getType() == MacroActionType.WAIT_PACKET) {
                        int x = this.panelX + 4;
                        int w = this.panelW - 8;
                        this.renderWaitPacketPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                    }
                } else {
                    if (this.targetAction != null) {
                        if (this.targetAction.getType() == MacroActionType.WAIT_SOUND) {
                            int x = this.panelX + 4;
                            int w = this.panelW - 8;
                            this.renderWaitSoundPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                        }
                    } else {
                        if (this.targetAction != null) {
                            if (this.targetAction.getType() == MacroActionType.WAIT_ENTITY) {
                                int x = this.panelX + 4;
                                int w = this.panelW - 8;
                                this.renderWaitEntityPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                            }
                        } else {
                            if (this.targetAction != null) {
                                if (this.targetAction.getType() == MacroActionType.USE_ITEM) {
                                    int x = this.panelX + 4;
                                    int w = this.panelW - 8;
                                    this.renderUseItemPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                }
                            } else {
                                if (this.targetAction != null) {
                                    if (this.targetAction.getType() == MacroActionType.LOOK_AT_BLOCK) {
                                        int x = this.panelX + 4;
                                        int w = this.panelW - 8;
                                        this.renderLookAtPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                    }
                                } else {
                                    if (this.targetAction != null) {
                                        if (this.targetAction.getType() == MacroActionType.ROTATE) {
                                            int x = this.panelX + 4;
                                            int w = this.panelW - 8;
                                            this.renderRotatePanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                        }
                                    } else {
                                        if (this.targetAction != null) {
                                            if (this.targetAction.getType() == MacroActionType.GO_TO) {
                                                int x = this.panelX + 4;
                                                int w = this.panelW - 8;
                                                this.renderGoToPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                            }
                                        } else {
                                            if (this.targetAction != null) {
                                                if (this.targetAction.getType() == MacroActionType.SWAP_SLOTS) {
                                                    int x = this.panelX + 4;
                                                    int w = this.panelW - 8;
                                                    this.renderSwapSlotsPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                }
                                            } else {
                                                if (this.targetAction != null) {
                                                    if (this.targetAction.getType() == MacroActionType.CLICK) {
                                                        int x = this.panelX + 4;
                                                        int w = this.panelW - 8;
                                                        this.renderClickPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                    }
                                                } else {
                                                    if (this.targetAction != null) {
                                                        if (this.targetAction.getType() == MacroActionType.DISCONNECT) {
                                                            int x = this.panelX + 4;
                                                            int w = this.panelW - 8;
                                                            this.renderDisconnectPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                        }
                                                    } else {
                                                        if (this.targetAction != null) {
                                                            if (this.targetAction.getType() == MacroActionType.WAIT_GUI) {
                                                                int x = this.panelX + 4;
                                                                int w = this.panelW - 8;
                                                                this.renderWaitGuiPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                            }
                                                        } else {
                                                            if (this.targetAction != null) {
                                                                if (this.targetAction.getType() == MacroActionType.WAIT_CHAT) {
                                                                    int x = this.panelX + 4;
                                                                    int w = this.panelW - 8;
                                                                    this.renderWaitChatPanel(context, x, bodyTop, bodyBtm - 22, w, mouseX, mouseY, delta);
                                                                }
                                                            } else {
                                                                if (this.targetAction != null) {
                                                                    if (this.targetAction.getType() == MacroActionType.SELECT_SLOT) {
                                                                        int x = this.panelX + 4;
                                                                        int w = this.panelW - 8;
                                                                        this.renderSelectSlotPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                    }
                                                                } else {
                                                                    if (this.targetAction != null) {
                                                                        if (this.targetAction.getType() == MacroActionType.WAIT_COOLDOWN) {
                                                                            int x = this.panelX + 4;
                                                                            int w = this.panelW - 8;
                                                                            this.renderWaitCooldownPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                        }
                                                                    } else {
                                                                        if (this.targetAction != null) {
                                                                            if (this.targetAction.getType() == MacroActionType.OPEN_CONTAINER) {
                                                                                int x = this.panelX + 4;
                                                                                int w = this.panelW - 8;
                                                                                this.renderOpenContainerPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                            }
                                                                        } else {
                                                                            if (this.targetAction != null) {
                                                                                if (this.targetAction.getType() == MacroActionType.WAIT_SLOT_CHANGE) {
                                                                                    int x = this.panelX + 4;
                                                                                    int w = this.panelW - 8;
                                                                                    this.renderWaitSlotChangePanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                }
                                                                            } else {
                                                                                if (this.targetAction != null) {
                                                                                    if (this.targetAction.getType() == MacroActionType.DELAY_PACKETS) {
                                                                                        int x = this.panelX + 4;
                                                                                        int w = this.panelW - 8;
                                                                                        this.renderDelayPacketsPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                    }
                                                                                } else {
                                                                                    if (this.targetAction != null) {
                                                                                        if (this.targetAction.getType() == MacroActionType.MINE) {
                                                                                            int x = this.panelX + 4;
                                                                                            int w = this.panelW - 8;
                                                                                            this.renderMinePanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                        }
                                                                                    } else {
                                                                                        if (this.targetAction != null) {
                                                                                            if (this.targetAction.getType() == MacroActionType.PAY) {
                                                                                                int x = this.panelX + 4;
                                                                                                int w = this.panelW - 8;
                                                                                                this.renderPayPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                            }
                                                                                        } else {
                                                                                            if (this.targetAction != null) {
                                                                                                if (this.targetAction.getType() == MacroActionType.INVENTORY_AUDIT) {
                                                                                                    int x = this.panelX + 4;
                                                                                                    int w = this.panelW - 8;
                                                                                                    this.renderInventoryAuditPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                                }
                                                                                            } else {
                                                                                                if (this.targetAction != null) {
                                                                                                    if (this.targetAction.getType() == MacroActionType.STORE_ITEM) {
                                                                                                        int x = this.panelX + 4;
                                                                                                        int w = this.panelW - 8;
                                                                                                        this.renderStoreItemPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                                    }
                                                                                                } else {
                                                                                                    if (this.targetAction != null) {
                                                                                                        if (this.targetAction.getType() == MacroActionType.TOGGLE_MODULE) {
                                                                                                            int x = this.panelX + 4;
                                                                                                            int w = this.panelW - 8;
                                                                                                            this.renderToggleModulePanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                                        }
                                                                                                    } else {
                                                                                                        if (this.craftEntries != null) {
                                                                                                            int x = this.panelX + 4;
                                                                                                            int w = this.panelW - 8;
                                                                                                            this.renderCraftPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                                        } else {
                                                                                                            if (this.dropAction != null) {
                                                                                                                int x = this.panelX + 4;
                                                                                                                int w = this.panelW - 8;
                                                                                                                this.renderDropPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                                            } else {
                                                                                                                if (this.lanStepEntries != null) {
                                                                                                                    int x = this.panelX + 4;
                                                                                                                    int w = this.panelW - 8;
                                                                                                                    this.renderLanStepPanel(context, x, bodyTop, w, mouseX, mouseY, delta);
                                                                                                                } else {
                                                                                                                    if (this.schema == null) { /* goto @2024; */ }
                                                                                                                    if (this.schema.fields().isEmpty()) { /* goto @2024; */ }
                                                                                                                    int contentBtm = bodyBtm - 22;
                                                                                                                    int contentAreaH = contentBtm - bodyTop;
                                                                                                                    int totalContentH = this.computeContentH();
                                                                                                                    int maxScroll = Math.max(0, totalContentH - contentAreaH);
                                                                                                                    this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxScroll));
                                                                                                                    boolean needsScroll = maxScroll > 0;
                                                                                                                    int sbReserve = needsScroll ? 6 : 0;
                                                                                                                    int x = this.panelX + 4;
                                                                                                                    int w = this.panelW - 8 - sbReserve;
                                                                                                                    PackUtilUiScale.enableOverlayScissor(context, this.panelX + 1, bodyTop, this.panelX + this.panelW - 1, contentBtm);
                                                                                                                    int y = bodyTop + 4 - this.scrollOffset;
                                                                                                                    int sbX = this.schema.fields().iterator();
                                                                                                                    while (sbX.hasNext()) {
                                                                                                                        FieldDef field = (FieldDef)sbX.next();
                                                                                                                        while (field.type() == FieldType.STRING_LIST) {
                                                                                                                        }
                                                                                                                        while (!this.isFieldVisible(field)) {
                                                                                                                        }
                                                                                                                        this.renderRow(context, field, x, y, w, mouseX, mouseY, delta);
                                                                                                                        y = y + (this.rowH(field) + 2);
                                                                                                                    }
                                                                                                                    sbX = this.schema.fields().iterator();
                                                                                                                    while (sbX.hasNext()) {
                                                                                                                        field = (FieldDef)sbX.next();
                                                                                                                        while (field.type() != FieldType.STRING_LIST) {
                                                                                                                        }
                                                                                                                        while (!this.isFieldVisible(field)) {
                                                                                                                        }
                                                                                                                        this.renderRow(context, field, x, y, w, mouseX, mouseY, delta);
                                                                                                                        y = y + (this.rowH(field) + 2);
                                                                                                                    }
                                                                                                                    this.renderPacketActionButtons(context, x, y, w, mouseX, mouseY);
                                                                                                                    if (this.targetAction != null && this.targetAction.getType() == MacroActionType.PACKET) {
                                                                                                                        y += 52;
                                                                                                                    }
                                                                                                                    this.renderSendPacketButtons(context, x, y, w, mouseX, mouseY);
                                                                                                                    if (this.targetAction != null && this.targetAction.getType() == MacroActionType.SEND_PACKET) {
                                                                                                                        y += 52;
                                                                                                                    }
                                                                                                                    if (this.targetAction != null) {
                                                                                                                        if (this.targetAction.getType() == MacroActionType.DELAY_PACKETS) {
                                                                                                                            this.renderDelayPacketsPresetButtons(context, x, y, w, mouseX, mouseY);
                                                                                                                        }
                                                                                                                    }
                                                                                                                    context.method_44380();
                                                                                                                    if (needsScroll) {
                                                                                                                        sbX = this.panelX + this.panelW - 5 - 1;
                                                                                                                        this.drawScrollbar(context, sbX, bodyTop, contentAreaH, totalContentH, contentAreaH, 1, this.scrollOffset);
                                                                                                                        capSbY = bodyTop;
                                                                                                                        int capSbH = contentAreaH;
                                                                                                                        this.scrollDragRegions.add(new ActionEditorOverlay.ScrollDragRegion(sbX, bodyTop, 5, contentAreaH, this::lambda$renderBody$14 /* captured: capSbH, capSbY, maxScroll */));
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.renderFooter(context, bodyBtm - 22, mouseX, mouseY);
    }

    private void renderItemPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        int headerBtnW = 44;
        PackUiText.draw(ctx, this.textRenderer, "Items / Exact Slots (" + this.itemAction.itemNames.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        boolean canClearAll = !this.itemAction.itemNames.isEmpty();
        int clearX = x + w - headerBtnW;
        this.renderOverlayButton(ctx, clearX, cy, headerBtnW, 14, "Clear", PackUiOverlayButton.Variant.DANGER, canClearAll, mx, my, this::lambda$renderItemPanel$15);
        cy += 13;
        int selAreaH = 60;
        int sbX = x + w - 5;
        PackUiScrollViewport itemViewport = this.getOrCreateViewport(this.selectedScrollViewports, "_item_entries", x, cy, w, selAreaH, 15, 5);
        itemViewport.setContentHeight(this.itemAction.itemNames.size() * 15);
        this.selectedListBounds.put("_item_entries", cy, selAreaH);
        itemViewport.renderScrollbar(ctx, (double)mx, (double)my);
        PackUtilDropAction[] ACTIONS = PackUtilDropAction.values();
        int sbGap = 7;
        int delW = 13;
        int itemW = w - sbGap - delW - 2;
        if (!this.itemAction.itemNames.isEmpty()) {
            itemViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstVis = itemViewport.getFirstVisibleRow();
            int iy0 = cy - itemViewport.getScrollOffset() % 15;
            for (int i = firstVis; i < this.itemAction.itemNames.size(); i++) {
                if (i > itemViewport.getLastVisibleRow()) break;
                int iy = itemViewport.getRowScreenY(i);
                if (iy == -2147483648) {
                } else {
                    String entry = (String)this.itemAction.itemNames.get(i);
                    int eiActIdx = this.itemAction.getItemActionIdx(i);
                    PackUtilDropAction eiAct = ACTIONS[eiActIdx];
                    int eiBtn = this.itemAction.getItemButton(i);
                    boolean selected = i == this.itemEditIndex;
                    ItemTarget entryTarget = this.targetAt(this.itemAction.itemTargets, this.itemAction.itemNames, i);
                    class_2561 displayName = this.formatItemTargetText(entryTarget, entry);
                    boolean rowHovered = mx >= x && mx < x + itemW && my >= iy && my < iy + 13;
                    String summaryAct = eiAct.shortName;
                    if (eiAct != PackUtilDropAction.SWAP) { /* goto L514; */ }
                    /* note: clearing non-empty stack before goto */
                    /* goto L559; */
                    L514: ;
                    switch (eiBtn) {
                        case 1::
                            String summaryBtn = "R";
                            break;
                        case 2::
                            summaryBtn = "M";
                            break;
                        default:
                            summaryBtn = "L";
                            break;
                    }
                    int times = this.itemAction.getItemTime(i);
                    String summary = " • " + summaryAct + " " + summaryBtn + times != 1 ? " ×" + times : "";
                    class_2561 rowLabel = class_2561.method_43473().method_10852(displayName).method_10852(class_2561.method_43470(summary).method_27694(ActionEditorOverlay::lambda$renderItemPanel$16));
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, rowLabel, x, iy, itemW, 13, rowHovered, selected, PackUiListRenderer.RowTone.NORMAL, true);
                    int fi = i;
                    if (!iy + 13 > cy && iy < cy + selAreaH) continue;
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, Math.max(cy, iy), itemW, Math.min(iy + 13, cy + selAreaH) - Math.max(cy, iy), this::lambda$renderItemPanel$17 /* captured: fi */));
                    if (iy + 13 > cy) {
                        if (iy < cy + selAreaH) {
                            delX = x + itemW + 2;
                            int fi = i;
                            this.renderIconDeleteButton(ctx, delX, iy, delW, mx, my, this::lambda$renderItemPanel$18 /* captured: fi */);
                        }
                    }
                }
            }
            itemViewport.endRender(ctx);
        } else {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "No rows yet. Add an item or exact slot.", x, cy, w - 5 - 1);
        }
        cy = cy + selAreaH;
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        int addPickW = 32;
        int addBtnW = 34;
        int slotW = 26;
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_item_add");
        PackUtilChatField entrySlotF = (PackUtilChatField)this.textFields.get("item_entrySlot");
        if (addF == null) { /* goto L1131; */ }
        if (entrySlotF == null) { /* goto L1131; */ }
        int pickX = x + w - addBtnW - 3 - addPickW;
        int plusX = x + w - addBtnW;
        int slotX = pickX - 3 - slotW;
        addF.setX(x);
        addF.setY(cy + 1);
        addF.setWidth(slotX - x - 2);
        addF.render(ctx, mx, my, delta);
        entrySlotF.setX(slotX);
        entrySlotF.setY(cy + 1);
        entrySlotF.setWidth(slotW);
        entrySlotF.render(ctx, mx, my, delta);
        boolean capturing = "_item_entries".equals(this.itemSlotCapturePendingKey);
        String pickLbl = capturing ? "Done" : "Pick";
        this.renderOverlayButton(ctx, pickX, cy, addPickW, 14, pickLbl, capturing ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderItemPanel$19);
        String addLbl = this.itemEditIndex >= 0 ? "New" : "+Add";
        this.renderOverlayButton(ctx, plusX, cy, addBtnW, 14, addLbl, PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderItemPanel$20);
        L1131: ;
        cy += 16;
        cy += 4;
        if (this.itemEditIndex < 0) { /* goto L1478; */ }
        if (this.itemEditIndex >= this.itemAction.itemNames.size()) { /* goto L1478; */ }
        eiActIdx = this.itemAction.getItemActionIdx(this.itemEditIndex);
        eiAct = ACTIONS[eiActIdx];
        eiBtn = this.itemAction.getItemButton(this.itemEditIndex);
        btnActive = eiAct == PackUtilDropAction.PICKUP || eiAct == PackUtilDropAction.SWAP;
        editIdx = this.itemEditIndex;
        editActW = 54;
        int editBtnW = 28;
        int editTimesW = 28;
        int editGap = 3;
        this.renderOverlayButton(ctx, x, cy, editActW, 14, eiAct.shortName, PackUiOverlayButton.Variant.SECONDARY, true, mx, my, this::lambda$renderItemPanel$21 /* captured: editIdx */);
        if (eiAct != PackUtilDropAction.SWAP) { /* goto L1303; */ }
        /* note: clearing non-empty stack before goto */
        /* goto L1347; */
        L1303: ;
        switch (eiBtn) {
            case 1::
                String btnLbl = "R";
                break;
            case 2::
                btnLbl = "M";
                break;
            default:
                btnLbl = "L";
                break;
        }
        this.renderOverlayButton(ctx, x + editActW + editGap, cy, editBtnW, 14, btnLbl, eiAct == PackUtilDropAction.SWAP ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.GHOST, btnActive, mx, my, this::lambda$renderItemPanel$22 /* captured: editIdx */);
        PackUtilChatField tf = (PackUtilChatField)this.textFields.get("item_times_" + this.itemEditIndex);
        if (tf != null) {
            tf.setX(x + editActW + editGap + editBtnW + editGap);
            tf.setY(cy + 1);
            tf.setWidth(editTimesW);
            tf.render(ctx, mx, my, delta);
        }
        cy += 16;
        L1478: ;
        itemHint = "Blank name + slot = exact slot. Name + slot = that item in that slot.";
        if (this.itemEditIndex >= 0) {
            if (this.itemEditIndex < this.itemAction.itemNames.size()) {
                if (this.itemAction.getItemAction(this.itemEditIndex) == PackUtilDropAction.SWAP) {
                    itemHint = "Swap uses the blue H1-H9 button to pick which hotbar slot gets swapped.";
                }
            }
        }
        cy = this.renderEditorHint(ctx, x, cy, w, itemHint);
        this.renderInlineToggle(ctx, font, "item_waitForGui", "Wait for GUI", x, cy, w, mx, my);
        cy += 17;
        if (((Boolean)this.toggleStates.getOrDefault("item_waitForGui", false)).booleanValue()) {
            guiF = (PackUtilChatField)this.textFields.get("item_guiName");
            if (guiF != null) {
                lw = this.labelWidth(w, "GUI Name", font);
                this.drawLabel(ctx, "GUI Name", x, cy, lw, font);
                guiF.setX(this.controlX(x, lw));
                guiF.setY(cy + 2);
                guiF.setWidth(this.controlWidth(w, lw));
                guiF.render(ctx, mx, my, delta);
            }
            cy += 17;
        } else {
            guiF = (PackUtilChatField)this.textFields.get("item_guiName");
            if (guiF != null) {
                guiF.setX(-1000);
            }
        }
        this.renderInlineToggle(ctx, font, "item_waitForItem", "Wait for Item", x, cy, w, mx, my);
        cy += 17;
    }

    private void addItemEntry(ItemTarget target) {
        this.addTargetEntry(this.itemAction.itemTargets, this.itemAction.itemNames, target);
        while (this.itemAction.itemTimes.size() < this.itemAction.itemNames.size()) {
            this.itemAction.itemTimes.add(1);
        }
        while (this.itemAction.itemActionIdx.size() < this.itemAction.itemNames.size()) {
            this.itemAction.itemActionIdx.add(0);
        }
        while (this.itemAction.itemButtons.size() < this.itemAction.itemNames.size()) {
            this.itemAction.itemButtons.add(0);
        }
        int idx = this.itemAction.itemNames.size() - 1;
        PackUtilChatField f = this.makeField(28);
        f.setNumericOnly(true);
        f.setText("1");
        this.textFields.put("item_times_" + idx, f);
    }

    private void rebuildItemFields() {
        this.textFields.keySet().removeIf(ActionEditorOverlay::lambda$rebuildItemFields$23);
        this.trimTargetEntries(this.itemAction.itemTargets, this.itemAction.itemNames.size());
        while (this.itemAction.itemTimes.size() > this.itemAction.itemNames.size()) {
            this.itemAction.itemTimes.remove(this.itemAction.itemTimes.size() - 1);
        }
        while (this.itemAction.itemActionIdx.size() > this.itemAction.itemNames.size()) {
            this.itemAction.itemActionIdx.remove(this.itemAction.itemActionIdx.size() - 1);
        }
        while (this.itemAction.itemButtons.size() > this.itemAction.itemNames.size()) {
            this.itemAction.itemButtons.remove(this.itemAction.itemButtons.size() - 1);
        }
        for (int i = 0; i < this.itemAction.itemNames.size(); i++) {
            PackUtilChatField f = this.makeField(28);
            f.setNumericOnly(true);
            f.setText(String.valueOf(this.itemAction.getItemTime(i)));
            this.textFields.put("item_times_" + i, f);
        }
    }

    private void toggleItemEditSelection(int index) {
        if (this.itemEditIndex == index) {
            this.clearItemEditSelection();
            return;
        }
        this.itemEditIndex = index;
        this.syncItemEntryEditorFromSelection();
    }

    private void clearItemEditSelection() {
        this.itemEditIndex = -1;
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_item_add");
        this.suppressItemEntryLiveUpdate = true;
        if (addF != null) {
            addF.setText("");
        }
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("item_entrySlot");
        if (slotF != null) {
            slotF.setText("");
        }
        this.suppressItemEntryLiveUpdate = false;
    }

    private void syncItemEntryEditorFromSelection() {
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_item_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("item_entrySlot");
        if (addF == null || slotF == null) {
            return;
        }
        this.suppressItemEntryLiveUpdate = true;
        if (this.itemEditIndex < 0 || this.itemEditIndex >= this.itemAction.itemNames.size()) {
            addF.setText("");
            slotF.setText("");
            this.suppressItemEntryLiveUpdate = false;
            return;
        }
        ItemTarget target = this.targetAt(this.itemAction.itemTargets, this.itemAction.itemNames, this.itemEditIndex);
        addF.setText(target.editorText());
        slotF.setText(target.hasSlot() ? String.valueOf(target.slot) : "");
        this.suppressItemEntryLiveUpdate = false;
    }

    private void applyItemEntryEditor() {
        this.applyItemEntryEditor(false);
    }

    private void handleItemEntryEditorChanged() {
        if (this.suppressItemEntryLiveUpdate || this.itemAction == null) {
            return;
        }
        if (this.itemEditIndex < 0 || this.itemEditIndex >= this.itemAction.itemNames.size()) {
            return;
        }
        this.applyItemEntryEditor(true);
    }

    private void applyItemEntryEditor(boolean preserveSelection) {
        if (this.itemAction == null) {
            return;
        }
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_item_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("item_entrySlot");
        if (addF == null || slotF == null) {
            return;
        }
        String nameText = addF.getText().strip();
        String slotText = slotF.getText().strip();
        ItemTarget target = this.buildEntryTargetFromEditor(nameText, slotText, this.targetAt(this.itemAction.itemTargets, this.itemAction.itemNames, this.itemEditIndex));
        String entry = target.toLegacyEntry();
        if (entry == null || entry.isBlank()) {
            return;
        }
        if (this.itemEditIndex >= 0) {
            if (this.itemEditIndex < this.itemAction.itemNames.size()) {
                if (!this.containsEntryOtherThan(this.itemAction.itemNames, entry, this.itemEditIndex)) {
                    this.setTargetAt(this.itemAction.itemTargets, this.itemAction.itemNames, this.itemEditIndex, target);
                }
            }
        } else {
            if (!this.itemAction.itemNames.contains(entry)) {
                this.addItemEntry(target);
            }
        }
        if (target.hasSlot()) {
            this.itemAction.targetSlot = target.slot;
            this.itemAction.useSlot = true;
        } else {
            this.itemAction.targetSlot = -1;
            this.itemAction.useSlot = false;
        }
        if (!preserveSelection) {
            this.clearItemEditSelection();
        }
    }

    private void applyCapturedItemEntry(ItemTarget target) {
        if (this.itemAction == null) {
            return;
        }
        String entry = target == null ? "" : target.toLegacyEntry();
        if (entry.isBlank()) {
            return;
        }
        int targetIndex = this.itemEditIndex;
        if (targetIndex >= 0) {
            if (targetIndex < this.itemAction.itemNames.size()) {
                if (!this.containsEntryOtherThan(this.itemAction.itemNames, entry, targetIndex)) {
                    this.setTargetAt(this.itemAction.itemTargets, this.itemAction.itemNames, targetIndex, target.copy());
                }
            }
        } else {
            targetIndex = this.itemAction.itemNames.indexOf(entry);
            if (targetIndex < 0) {
                this.addItemEntry(target.copy());
                targetIndex = this.itemAction.itemNames.size() - 1;
            }
        }
        this.itemEditIndex = targetIndex;
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_item_add");
        if (addF != null) {
            addF.setText(target.editorText());
        }
    }

    private void renderInlineToggle(class_332 ctx, class_2960 font, String stateKey, String label, int x, int y, int w, int mx, int my) {
        boolean val = ((Boolean)this.toggleStates.getOrDefault(stateKey, false)).booleanValue();
        int lw = this.labelWidth(w, label, font, 34);
        this.drawLabel(ctx, label, x, y, lw, font);
        int btnW = 34;
        int btnH = 14;
        int btnX = x + w - btnW;
        this.renderOverlayButton(ctx, btnX, y + 2, btnW, btnH, val ? "ON" : "OFF", val ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER, true, mx, my, this::lambda$renderInlineToggle$24 /* captured: stateKey */);
    }

    private void renderCraftPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int removeW = 13;
        int maxTogW = 42;
        int amountW = 44;
        int headerBtnW = 44;
        int cy = bodyTop + 4;
        PackUiText.draw(ctx, this.textRenderer, "Craft Entries (" + this.craftEntries.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        boolean canClearEntries = !this.craftEntries.isEmpty();
        this.renderOverlayButton(ctx, x + w - headerBtnW, cy, headerBtnW, 14, "Clear", PackUiOverlayButton.Variant.DANGER, canClearEntries, mx, my, this::lambda$renderCraftPanel$25);
        cy += 13;
        int selAreaH = 60;
        PackUiScrollViewport craftViewport = this.getOrCreateViewport(this.selectedScrollViewports, "_craft_entries", x, cy, w, selAreaH, 15, 5);
        craftViewport.setContentHeight(this.craftEntries.size() * 15);
        this.selectedListBounds.put("_craft_entries", cy, selAreaH);
        craftViewport.renderScrollbar(ctx, (double)mx, (double)my);
        int sbGap = 7;
        if (!this.craftEntries.isEmpty()) {
            craftViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstSel = craftViewport.getFirstVisibleRow();
            for (int i = firstSel; i < this.craftEntries.size(); i++) {
                if (i > craftViewport.getLastVisibleRow()) break;
                int siy = craftViewport.getRowScreenY(i);
                if (siy == -2147483648) {
                } else {
                    CraftEntry entry = (CraftAction.CraftEntry)this.craftEntries.get(i);
                    boolean useMax = ((Boolean)this.toggleStates.getOrDefault("craft_useMax_" + i, false)).booleanValue();
                    int removeX = x + w - sbGap - removeW;
                    int fi = i;
                    this.renderIconDeleteButton(ctx, removeX, siy + 1, removeW, mx, my, this::lambda$renderCraftPanel$26 /* captured: fi */);
                    int maxX = removeX - 3 - maxTogW;
                    String mLbl = useMax ? "Max: On" : "Max: Off";
                    int fii = i;
                    this.renderOverlayButton(ctx, maxX, siy + 1, maxTogW, 13, mLbl, useMax ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderCraftPanel$27 /* captured: fii */);
                    if (!useMax) {
                        int amtX = maxX - 3 - amountW;
                        PackUtilChatField af = (PackUtilChatField)this.textFields.get("craft_amount_" + i);
                        if (af != null) {
                            af.setX(amtX);
                            af.setY(siy + 1);
                            af.setWidth(amountW);
                            af.render(ctx, mx, my, delta);
                        }
                    }
                    nameW = useMax ? maxX - 3 - x : maxX - 3 - amountW - 3 - x;
                    rowHovered = mx >= x && mx < x + nameW && my >= siy && my < siy + 13;
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, entry.resultName, x, siy, Math.max(1, nameW), 13, rowHovered, false, useMax ? PackUiListRenderer.RowTone.READY : PackUiListRenderer.RowTone.NORMAL);
                }
            }
            craftViewport.endRender(ctx);
        } else {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "No craft entries yet.", x, cy, w - 5 - 1);
        }
        cy = cy + selAreaH;
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        int refreshW = 44;
        PackUtilChatField srchF = (PackUtilChatField)this.addFields.get("_craft_search");
        if (srchF != null) {
            srchF.setX(x);
            srchF.setY(cy);
            srchF.setWidth(w - refreshW - 3);
            srchF.render(ctx, mx, my, delta);
        }
        int rfX = x + w - refreshW;
        this.renderOverlayButton(ctx, rfX, cy, refreshW, 14, "Reload", PackUiOverlayButton.Variant.SECONDARY, true, mx, my, this::refreshCraftRecipes);
        cy += 16;
        String query = srchF != null ? srchF.getText() : "";
        if (query.equals(this.craftLastQuery)) { /* goto L908; */ }
        this.craftFilteredRecipes = PackUtilCraftingHelper.filterRecipes(this.craftAllRecipes != null ? this.craftAllRecipes : List.of(), query);
        this.craftLastQuery = query;
        this.craftRecipeScrollOffset = 0;
        if (this.craftSelectedRecipe != null) {
            if (this.craftFilteredRecipes == null || !this.craftFilteredRecipes.contains(this.craftSelectedRecipe)) {
                this.craftSelectedRecipe = null;
            }
        }
        List<PackUtilCraftingHelper.CraftableRecipeOption> filtered = this.craftFilteredRecipes != null ? this.craftFilteredRecipes : List.of();
        int recipeListH = 52;
        PackUiScrollViewport recipeViewport = this.getOrCreateViewport(this.catalogScrollViewports, "_craft_recipe_browser", x, cy, w, recipeListH, 13, 5);
        recipeViewport.setContentHeight(filtered.size() * 13);
        int[] tmp1 = new int[2];
        tmp1[0] = cy;
        tmp1[1] = recipeListH;
        this.craftRecipeListBounds = tmp1;
        recipeViewport.renderScrollbar(ctx, (double)mx, (double)my);
        int recW = w - 5 - 1;
        if (filtered.isEmpty()) {
            if (this.craftAllRecipes == null) { /* goto L1040; */ }
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, this.craftAllRecipes.isEmpty() ? "No craftable recipes. Use Reload." : "No recipes match the search.", x, cy, recW);
        } else {
            recipeViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstRec = recipeViewport.getFirstVisibleRow();
            for (int i = firstRec; i < filtered.size(); i++) {
                if (i > recipeViewport.getLastVisibleRow()) break;
                int ry = recipeViewport.getRowScreenY(i);
                if (ry == -2147483648) {
                } else {
                    CraftableRecipeOption opt = (PackUtilCraftingHelper.CraftableRecipeOption)filtered.get(i);
                    boolean inList = this.craftEntries.stream().anyMatch(ActionEditorOverlay::lambda$renderCraftPanel$28 /* captured: opt */);
                    boolean hov = !inList && mx >= x && mx < x + recW && my >= ry && my < ry + 13;
                    RowTone tone = inList ? PackUiListRenderer.RowTone.READY : opt.craftableNow ? PackUiListRenderer.RowTone.NORMAL : PackUiListRenderer.RowTone.WARNING;
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, opt.label, x, ry, recW, 13, hov, inList, tone);
                    String cnt = "×" + opt.result.method_7947();
                    if (!opt.result != null && opt.result.method_7947() > 1) continue;
                    PackUiText.draw(ctx, this.textRenderer, cnt, font, PackUtilColors.textDim(), x + recW - this.uiWidth(font, cnt) - 2, ry + 2, false);
                    fOpt = opt;
                    boolean fInList = inList;
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, ry, recW, 13, this::lambda$renderCraftPanel$30 /* captured: fInList, fOpt */));
                }
            }
            recipeViewport.endRender(ctx);
        }
    }

    private void refreshCraftRecipes() {
        this.craftAllRecipes = PackUtilCraftingHelper.getCraftableRecipes(MC);
        this.craftLastQuery = null;
        this.craftSelectedRecipe = null;
        this.craftRecipeScrollOffset = 0;
    }

    private void addCraftEntry() {
        if (this.craftSelectedRecipe == null) {
            return;
        }
        PackUtilChatField amtF = (PackUtilChatField)this.textFields.get("_craft_amount");
        int amount = 1;
        if (amtF == null) { /* goto @56; */ }
        try {
            amount = Math.max(1, Integer.parseInt(amtF.getText().strip()));
        }
        catch (NumberFormatException newEntry) {
            newEntry = CraftAction.CraftEntry.fromOption(this.craftSelectedRecipe, amount, this.craftUseMax);
            int i = 0;
            L72: ;
            if (i < this.craftEntries.size()) {
                CraftEntry existing = (CraftAction.CraftEntry)this.craftEntries.get(i);
                if (newEntry.recipeKey == null || !newEntry.recipeKey.equals(existing.recipeKey)) {
                    if (newEntry.recipeId < 0) { /* goto @224; */ }
                }
                existing.amount = newEntry.amount;
                existing.useMaxAmount = newEntry.useMaxAmount;
                this.toggleStates.put("craft_useMax_" + i, newEntry.useMaxAmount);
                PackUtilChatField f = (PackUtilChatField)this.textFields.get("craft_amount_" + i);
                if (f != null) {
                    f.setText(String.valueOf(newEntry.amount));
                }
                return;
            }
        }
        newEntry = CraftAction.CraftEntry.fromOption(this.craftSelectedRecipe, amount, this.craftUseMax);
        for (i = 0; i < this.craftEntries.size(); i++) {
            existing = (CraftAction.CraftEntry)this.craftEntries.get(i);
            if (newEntry.recipeKey == null || !newEntry.recipeKey.equals(existing.recipeKey)) {
                if (newEntry.recipeId < 0) { /* goto @224; */ }
            }
            existing.amount = newEntry.amount;
            existing.useMaxAmount = newEntry.useMaxAmount;
            this.toggleStates.put("craft_useMax_" + i, newEntry.useMaxAmount);
            f = (PackUtilChatField)this.textFields.get("craft_amount_" + i);
            if (f == null) continue;
            f.setText(String.valueOf(newEntry.amount));
            return;
            L224: ;
        }
        this.craftEntries.add(newEntry);
        idx = this.craftEntries.size() - 1;
        f = this.makeField(44);
        f.setNumericOnly(true);
        f.setText(String.valueOf(newEntry.amount));
        this.textFields.put("craft_amount_" + idx, f);
        this.toggleStates.put("craft_useMax_" + idx, newEntry.useMaxAmount);
    }

    private void rebuildCraftFields() {
        this.textFields.keySet().removeIf(ActionEditorOverlay::lambda$rebuildCraftFields$31);
        for (int i = 0; i < this.craftEntries.size(); i++) {
            CraftEntry entry = (CraftAction.CraftEntry)this.craftEntries.get(i);
            PackUtilChatField f = this.makeField(44);
            f.setNumericOnly(true);
            f.setText(String.valueOf(entry.amount));
            this.textFields.put("craft_amount_" + i, f);
            if (this.toggleStates.containsKey("craft_useMax_" + i)) continue;
            this.toggleStates.put("craft_useMax_" + i, entry.useMaxAmount);
        }
        this.toggleStates.keySet().removeIf(this::lambda$rebuildCraftFields$32);
    }

    private void renderDropPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        int headerBtnW = 44;
        PackUiText.draw(ctx, this.textRenderer, "Drop Entries (" + this.dropAction.itemNames.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        boolean canClearAll = !this.dropAction.itemNames.isEmpty();
        int clearX = x + w - headerBtnW;
        this.renderOverlayButton(ctx, clearX, cy, headerBtnW, 14, "Clear", PackUiOverlayButton.Variant.DANGER, canClearAll, mx, my, this::lambda$renderDropPanel$33);
        cy += 13;
        int selAreaH = 60;
        PackUiScrollViewport dropViewport = this.getOrCreateViewport(this.selectedScrollViewports, "_drop_entries", x, cy, w, selAreaH, 15, 5);
        dropViewport.setContentHeight(this.dropAction.itemNames.size() * 15);
        this.selectedListBounds.put("_drop_entries", cy, selAreaH);
        dropViewport.renderScrollbar(ctx, (double)mx, (double)my);
        int sbGap = 7;
        int delW = 13;
        int dropItemW = w - sbGap - delW - 2;
        if (!this.dropAction.itemNames.isEmpty()) {
            dropViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstVis = dropViewport.getFirstVisibleRow();
            for (int i = firstVis; i < this.dropAction.itemNames.size(); i++) {
                if (i > dropViewport.getLastVisibleRow()) break;
                int iy = dropViewport.getRowScreenY(i);
                if (iy == -2147483648) {
                } else {
                    String entry = (String)this.dropAction.itemNames.get(i);
                    boolean selected = i == this.dropEditIndex;
                    ItemTarget entryTarget = this.targetAt(this.dropAction.itemTargets, this.dropAction.itemNames, i);
                    class_2561 displayName = this.formatItemTargetText(entryTarget, entry);
                    int cnt = i < this.dropAction.itemCounts.size() ? ((Integer)this.dropAction.itemCounts.get(i)).intValue() : false;
                    String summary = " • " + !cnt ? "all" : "×" + cnt;
                    class_2561 rowLabel = class_2561.method_43473().method_10852(displayName).method_10852(class_2561.method_43470(summary).method_27694(ActionEditorOverlay::lambda$renderDropPanel$34));
                    boolean rowHovered = mx >= x && mx < x + dropItemW && my >= iy && my < iy + 13;
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, rowLabel, x, iy, dropItemW, 13, rowHovered, selected, PackUiListRenderer.RowTone.NORMAL, true);
                    int fi = i;
                    if (!iy + 13 > cy && iy < cy + selAreaH) continue;
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, Math.max(cy, iy), dropItemW, Math.min(iy + 13, cy + selAreaH) - Math.max(cy, iy), this::lambda$renderDropPanel$35 /* captured: fi */));
                    if (iy + 13 > cy) {
                        if (iy < cy + selAreaH) {
                            delX = x + dropItemW + 2;
                            int fi = i;
                            this.renderIconDeleteButton(ctx, delX, iy, delW, mx, my, this::lambda$renderDropPanel$36 /* captured: fi */);
                        }
                    }
                }
            }
            dropViewport.endRender(ctx);
        } else {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "No entries yet. Add an item or exact slot.", x, cy, w - 5 - 1);
        }
        cy = cy + selAreaH;
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        int addPickW = 32;
        int addBtnW = 34;
        int slotW = 44;
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_drop_add");
        PackUtilChatField entrySlotF = (PackUtilChatField)this.textFields.get("drop_entrySlot");
        if (addF == null) { /* goto L1020; */ }
        if (entrySlotF == null) { /* goto L1020; */ }
        int pickX = x + w - addBtnW - 3 - addPickW;
        int plusX = x + w - addBtnW;
        int slotX = pickX - 3 - slotW;
        addF.setX(x);
        addF.setY(cy + 1);
        addF.setWidth(slotX - x - 2);
        addF.render(ctx, mx, my, delta);
        entrySlotF.setX(slotX);
        entrySlotF.setY(cy + 1);
        entrySlotF.setWidth(slotW);
        entrySlotF.render(ctx, mx, my, delta);
        boolean capturing = "_drop_entries".equals(this.itemSlotCapturePendingKey);
        String pickLbl = capturing ? "Done" : "Pick";
        this.renderOverlayButton(ctx, pickX, cy, addPickW, 14, pickLbl, capturing ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderDropPanel$37);
        String addLbl = this.dropEditIndex >= 0 ? "New" : "+Add";
        this.renderOverlayButton(ctx, plusX, cy, addBtnW, 14, addLbl, PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderDropPanel$38);
        L1020: ;
        cy += 16;
        cy += 4;
        editingSelectedDrop = this.dropEditIndex >= 0 && this.dropEditIndex < this.dropAction.itemNames.size();
        dropHint = editingSelectedDrop ? "Editing this row. 0 means drop the full stack from that slot or item." : "No row selected. The controls below set defaults for new rows you add.";
        cy = this.renderEditorHint(ctx, x, cy, w, dropHint);
        dropAllSelected = editingSelectedDrop ? this.getDropEntryCount(this.dropEditIndex) == 0 : this.dropAction.mode == DropAction.DropMode.ALL;
        lw = this.labelWidth(w, editingSelectedDrop ? "Selected Row" : "Default Mode", font);
        this.drawLabel(ctx, editingSelectedDrop ? "Selected Row" : "Default Mode", x, cy, lw, font);
        ctrlX = this.controlX(x, lw);
        ctrlW = this.controlWidth(w, lw);
        int leftW = (ctrlW - 2) / 2;
        int rightX = ctrlX + leftW + 2;
        int rightW = ctrlW - leftW - 2;
        this.renderOverlayButton(ctx, ctrlX, cy + 2, leftW, 14, "Drop All", dropAllSelected ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderDropPanel$39);
        this.renderOverlayButton(ctx, rightX, cy + 2, rightW, 14, "Times", !dropAllSelected ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderDropPanel$40);
        cy += 17;
        cntF = (PackUtilChatField)this.textFields.get("drop_globalCount");
        this.syncDropCountEditorField();
        if (cntF == null) { /* goto L1444; */ }
        lw = this.labelWidth(w, editingSelectedDrop ? "Selected Count" : "Default Count", font);
        this.drawLabel(ctx, editingSelectedDrop ? "Selected Count" : "Default Count", x, cy, lw, font);
        cntF.setX(this.controlX(x, lw));
        cntF.setY(cy + 2);
        cntF.setWidth(this.controlWidth(w, lw));
        cntF.render(ctx, mx, my, delta);
        cy += 17;
        L1444: ;
        this.renderInlineToggle(ctx, font, "drop_waitForGui", "Wait for GUI", x, cy, w, mx, my);
        cy += 17;
        if (((Boolean)this.toggleStates.getOrDefault("drop_waitForGui", false)).booleanValue()) {
            guiF = (PackUtilChatField)this.textFields.get("drop_guiName");
            if (guiF != null) {
                lw = this.labelWidth(w, "GUI Name", font);
                this.drawLabel(ctx, "GUI Name", x, cy, lw, font);
                guiF.setX(this.controlX(x, lw));
                guiF.setY(cy + 2);
                guiF.setWidth(this.controlWidth(w, lw));
                guiF.render(ctx, mx, my, delta);
            }
            cy += 17;
        } else {
            guiF = (PackUtilChatField)this.textFields.get("drop_guiName");
            if (guiF != null) {
                guiF.setX(-1000);
            }
        }
    }

    private void addDropEntry(ItemTarget target, int count) {
        if (target == null) {
            return;
        }
        String entry = target.toLegacyEntry();
        if (entry.isEmpty()) {
            return;
        }
        this.addTargetEntry(this.dropAction.itemTargets, this.dropAction.itemNames, target);
        int safeCount = Math.max(0, count);
        this.dropAction.itemCounts.add(safeCount);
        int idx = this.dropAction.itemNames.size() - 1;
        PackUtilChatField f = this.makeField(32);
        f.setNumericOnly(true);
        f.setText(String.valueOf(safeCount));
        int fieldIndex = idx;
        f.setChangedListener(this::lambda$addDropEntry$41 /* captured: fieldIndex */);
        this.textFields.put("drop_count_" + idx, f);
    }

    private void rebuildDropFields() {
        this.textFields.keySet().removeIf(ActionEditorOverlay::lambda$rebuildDropFields$42);
        this.trimTargetEntries(this.dropAction.itemTargets, this.dropAction.itemNames.size());
        while (this.dropAction.itemCounts.size() > this.dropAction.itemNames.size()) {
            this.dropAction.itemCounts.remove(this.dropAction.itemCounts.size() - 1);
        }
        for (int i = 0; i < this.dropAction.itemNames.size(); i++) {
            PackUtilChatField f = this.makeField(32);
            f.setNumericOnly(true);
            f.setText(String.valueOf(this.dropAction.itemCounts.get(i)));
            int fieldIndex = i;
            f.setChangedListener(this::lambda$rebuildDropFields$43 /* captured: fieldIndex */);
            this.textFields.put("drop_count_" + i, f);
        }
    }

    private void toggleDropEditSelection(int index) {
        if (this.dropEditIndex == index) {
            this.clearDropEditSelection();
            return;
        }
        this.dropEditIndex = index;
        this.syncDropEntryEditorFromSelection();
        this.syncDropCountEditorField();
    }

    private void clearDropEditSelection() {
        this.dropEditIndex = -1;
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_drop_add");
        this.suppressDropEntryLiveUpdate = true;
        if (addF != null) {
            addF.setText("");
        }
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("drop_entrySlot");
        if (slotF != null) {
            slotF.setText("");
        }
        this.suppressDropEntryLiveUpdate = false;
        this.syncDropCountEditorField();
    }

    private void syncDropEntryEditorFromSelection() {
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_drop_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("drop_entrySlot");
        if (addF == null || slotF == null) {
            return;
        }
        this.suppressDropEntryLiveUpdate = true;
        if (this.dropEditIndex < 0 || this.dropEditIndex >= this.dropAction.itemNames.size()) {
            addF.setText("");
            slotF.setText("");
            this.suppressDropEntryLiveUpdate = false;
            return;
        }
        ItemTarget target = this.targetAt(this.dropAction.itemTargets, this.dropAction.itemNames, this.dropEditIndex);
        addF.setText(target.editorText());
        slotF.setText(target.hasSlot() ? String.valueOf(target.slot) : "");
        this.suppressDropEntryLiveUpdate = false;
        this.syncDropCountEditorField();
    }

    private void applyDropEntryEditor() {
        this.applyDropEntryEditor(false);
    }

    private void handleDropEntryEditorChanged() {
        if (this.suppressDropEntryLiveUpdate || this.dropAction == null) {
            return;
        }
        if (this.dropEditIndex < 0 || this.dropEditIndex >= this.dropAction.itemNames.size()) {
            return;
        }
        this.applyDropEntryEditor(true);
    }

    private void applyDropEntryEditor(boolean preserveSelection) {
        if (this.dropAction == null) {
            return;
        }
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_drop_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("drop_entrySlot");
        if (addF == null || slotF == null) {
            return;
        }
        String nameText = addF.getText().strip();
        String slotText = slotF.getText().strip();
        ItemTarget target = this.buildEntryTargetFromEditor(nameText, slotText, this.targetAt(this.dropAction.itemTargets, this.dropAction.itemNames, this.dropEditIndex));
        String entry = target.toLegacyEntry();
        if (entry.isBlank()) {
            return;
        }
        if (this.dropEditIndex >= 0) {
            if (this.dropEditIndex < this.dropAction.itemNames.size()) {
                if (!this.containsEntryOtherThan(this.dropAction.itemNames, entry, this.dropEditIndex)) {
                    this.setTargetAt(this.dropAction.itemTargets, this.dropAction.itemNames, this.dropEditIndex, target);
                }
            }
        } else {
            if (!this.dropAction.itemNames.contains(entry)) {
                this.addDropEntry(target, this.currentDropEditorCount());
            }
        }
        if (!preserveSelection) {
            this.clearDropEditSelection();
        }
    }

    private void applyCapturedDropEntry(ItemTarget target) {
        if (this.dropAction == null) {
            return;
        }
        String entry = target == null ? "" : target.toLegacyEntry();
        if (entry.isBlank()) {
            return;
        }
        int targetIndex = this.dropEditIndex;
        if (targetIndex >= 0) {
            if (targetIndex < this.dropAction.itemNames.size()) {
                if (!this.containsEntryOtherThan(this.dropAction.itemNames, entry, targetIndex)) {
                    this.setTargetAt(this.dropAction.itemTargets, this.dropAction.itemNames, targetIndex, target.copy());
                }
            }
        } else {
            targetIndex = this.dropAction.itemNames.indexOf(entry);
            if (targetIndex < 0) {
                this.addDropEntry(target.copy(), this.currentDropEditorCount());
                targetIndex = this.dropAction.itemNames.size() - 1;
            }
        }
        this.dropEditIndex = targetIndex;
        this.syncDropEntryEditorFromSelection();
        this.syncDropCountEditorField();
    }

    private int currentDropEditorCount() {
        PackUtilChatField globalCountField = (PackUtilChatField)this.textFields.get("drop_globalCount");
        if (this.dropEditIndex >= 0 && this.dropEditIndex < this.dropAction.itemCounts.size()) {
            return Math.max(0, ((Integer)this.dropAction.itemCounts.get(this.dropEditIndex)).intValue());
        }
        if (((Integer)this.enumIndices.getOrDefault("drop_mode", 0)).intValue() == 0) {
            return 0;
        }
        try {
            return Math.max(0, Integer.parseInt(globalCountField.getText().strip()));
        }
        catch (NumberFormatException e2) {
            return Math.max(0, this.dropAction.dropCount);
        }
    }

    private int getDropEntryCount(int index) {
        if (this.dropAction == null || index < 0 || index >= this.dropAction.itemNames.size()) {
            return 1;
        }
        while (this.dropAction.itemCounts.size() <= index) {
            this.dropAction.itemCounts.add(1);
        }
        return Math.max(0, ((Integer)this.dropAction.itemCounts.get(index)).intValue());
    }

    private void setDropEntryCount(int index, int count) {
        if (this.dropAction == null || index < 0 || index >= this.dropAction.itemNames.size()) {
            return;
        }
        while (this.dropAction.itemCounts.size() <= index) {
            this.dropAction.itemCounts.add(1);
        }
        int safeCount = Math.max(0, count);
        this.dropAction.itemCounts.set(index, safeCount);
        PackUtilChatField rowField = (PackUtilChatField)this.textFields.get("drop_count_" + index);
        if (rowField != null) {
            rowField.setText(String.valueOf(safeCount));
        }
    }

    private void syncDropCountEditorField() {
        if (this.dropAction == null) {
            return;
        }
        PackUtilChatField countField = (PackUtilChatField)this.textFields.get("drop_globalCount");
        if (countField == null) {
            return;
        }
        boolean editingSelectedDrop = this.dropEditIndex >= 0 && this.dropEditIndex < this.dropAction.itemNames.size();
        boolean dropAll = editingSelectedDrop ? this.getDropEntryCount(this.dropEditIndex) == 0 : this.dropAction.mode == DropAction.DropMode.ALL;
        int displayCount = editingSelectedDrop ? Math.max(1, this.getDropEntryCount(this.dropEditIndex)) : Math.max(1, this.dropAction.dropCount);
        this.suppressDropCountEditorUpdate = true;
        countField.setText(String.valueOf(displayCount));
        countField.setEditable(!dropAll);
        this.suppressDropCountEditorUpdate = false;
    }

    private void handleDropCountEditorChanged() {
        if (this.suppressDropCountEditorUpdate || this.dropAction == null) {
            return;
        }
        PackUtilChatField countField = (PackUtilChatField)this.textFields.get("drop_globalCount");
        if (countField == null) {
            return;
        }
        boolean editingSelectedDrop = this.dropEditIndex >= 0 && this.dropEditIndex < this.dropAction.itemNames.size();
        boolean dropAll = editingSelectedDrop ? this.getDropEntryCount(this.dropEditIndex) == 0 : this.dropAction.mode == DropAction.DropMode.ALL;
        if (dropAll) {
            return;
        }
        try {
            int value = Math.max(1, Integer.parseInt(countField.getText().strip()));
            if (editingSelectedDrop) {
                this.setDropEntryCount(this.dropEditIndex, value);
            } else {
                this.dropAction.dropCount = value;
            }
        }
        catch (NumberFormatException value) {
            return;
        }
    }

    private void renderLanStepPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        boolean filterByUser = ((Boolean)this.toggleStates.getOrDefault("lan_filterByUser", false)).booleanValue();
        this.renderInlineToggle(ctx, font, "lan_filterByUser", "Specific Peers", x, cy, w, mx, my);
        cy += 17;
        PackUtilChatField dsF = (PackUtilChatField)this.textFields.get("lan_defaultStep");
        if (dsF == null) { /* goto L204; */ }
        if (!filterByUser) { /* goto L105; */ }
        if (!this.lanStepEntries.isEmpty()) { /* goto L204; */ }
        L105: ;
        int lw = this.labelWidth(w, filterByUser ? "Fallback Step" : "Any Peer Step", font);
        this.drawLabel(ctx, filterByUser ? "Fallback Step" : "Any Peer Step", x, cy, lw, font);
        dsF.setX(this.controlX(x, lw));
        dsF.setY(cy + 2);
        dsF.setWidth(this.controlWidth(w, lw));
        dsF.render(ctx, mx, my, delta);
        cy += 17;
        L204: ;
        summary = !filterByUser ? "Continue when any LAN peer reaches the target step." : this.lanStepEntries.isEmpty() ? "Add peers below to narrow it down. Until then, it waits for any peer at the fallback step." : "Each peer below must reach its step before this continues.";
        cy = this.renderEditorHint(ctx, x, cy, w, summary);
        if (!filterByUser) {
            return;
        }
        if (!this.lanStepEntries.isEmpty()) {
            PackUiText.draw(ctx, this.textRenderer, "Peers (" + this.lanStepEntries.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
            cy += 13;
        }
        boolean hasEntries = !this.lanStepEntries.isEmpty();
        int visibleRows = hasEntries ? Math.min(3, Math.max(1, this.lanStepEntries.size())) : 1;
        int selAreaH = hasEntries ? visibleRows * 15 : 12;
        PackUiScrollViewport lanViewport = null;
        if (hasEntries) {
            lanViewport = this.getOrCreateViewport(this.selectedScrollViewports, "_lan_entries", x, cy, w, selAreaH, 15, 5);
            lanViewport.setContentHeight(this.lanStepEntries.size() * 15);
        }
        this.selectedListBounds.put("_lan_entries", cy, selAreaH);
        if (hasEntries) {
            if (lanViewport != null) {
                lanViewport.renderScrollbar(ctx, (double)mx, (double)my);
            }
        }
        int sbGap = 7;
        int removeW = 13;
        int stepW = 40;
        int gapPx = 2;
        int removeX = x + w - sbGap - removeW;
        int stepX = removeX - gapPx - stepW;
        int userW = stepX - x - gapPx;
        if (hasEntries) {
            if (lanViewport == null) { /* goto @778; */ }
            lanViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstVis = lanViewport.getFirstVisibleRow();
            for (int i = firstVis; i < this.lanStepEntries.size(); i++) {
                if (i > lanViewport.getLastVisibleRow()) break;
                int iy = lanViewport.getRowScreenY(i);
                if (iy == -2147483648) {
                } else {
                    ctx.method_25294(x, iy, stepX - gapPx, iy + 13, -15528948);
                    PackUtilChatField uf = (PackUtilChatField)this.textFields.get("lan_user_" + i);
                    if (uf != null) {
                        uf.setX(x);
                        uf.setY(iy + 1);
                        uf.setWidth(userW);
                        uf.render(ctx, mx, my, delta);
                    }
                    PackUtilChatField sf = (PackUtilChatField)this.textFields.get("lan_step_" + i);
                    if (sf != null) {
                        sf.setX(stepX);
                        sf.setY(iy + 1);
                        sf.setWidth(stepW);
                        sf.render(ctx, mx, my, delta);
                    }
                    int fi = i;
                    this.renderIconDeleteButton(ctx, removeX, iy + 1, removeW, mx, my, this::lambda$renderLanStepPanel$44 /* captured: fi */);
                }
            }
            lanViewport.endRender(ctx);
        } else {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "No peer filters yet.", x, cy, w - 5 - 1);
        }
        cy = cy + selAreaH;
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        int addBtnW = 36;
        PackUtilChatField newUF = (PackUtilChatField)this.addFields.get("_lan_user_add");
        PackUtilChatField newSF = (PackUtilChatField)this.addFields.get("_lan_step_add");
        int plusX = x + w - addBtnW;
        if (newUF != null && newSF != null) {
            int stepAX = plusX - 3 - stepW;
            int userAW = stepAX - x - 2;
            newUF.setX(x);
            newUF.setY(cy + 1);
            newUF.setWidth(userAW);
            newUF.render(ctx, mx, my, delta);
            newSF.setX(stepAX);
            newSF.setY(cy + 1);
            newSF.setWidth(stepW);
            newSF.render(ctx, mx, my, delta);
            this.renderOverlayButton(ctx, plusX, cy, addBtnW, 14, "+Add", PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderLanStepPanel$45 /* captured: newUF, newSF */);
        }
    }

    private void rebuildLanStepFields() {
        this.textFields.keySet().removeIf(ActionEditorOverlay::lambda$rebuildLanStepFields$46);
        for (int i = 0; i < this.lanStepEntries.size(); i++) {
            LanStepEntry e = (WaitForLanStepAction.LanStepEntry)this.lanStepEntries.get(i);
            PackUtilChatField uf = this.makeField(80);
            uf.setText(e.username);
            this.textFields.put("lan_user_" + i, uf);
            PackUtilChatField sf = this.makeField(40);
            sf.setNumericOnly(true);
            sf.setText(String.valueOf(e.step));
            this.textFields.put("lan_step_" + i, sf);
        }
    }

    private void renderPacketActionButtons(class_332 ctx, int x, int y, int w, int mx, int my) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int btnH = 14;
        int halfW = (w - 4) / 2;
        int topY = y + 2;
        int bottomY = y + 20;
        String info = this.buildPacketActionInfo();
        PackUiText.draw(ctx, this.textRenderer, PackUiText.trimToWidth(this.textRenderer, info, w, font, -1), font, PackUtilColors.textDim(), x, y - 10, false);
        this.renderActionButton(ctx, x, topY, halfW, btnH, "Queue First", mx, my, this::lambda$renderPacketActionButtons$47);
        this.renderActionButton(ctx, x + halfW + 4, topY, halfW, btnH, "Paste Base64", mx, my, this::lambda$renderPacketActionButtons$48);
        this.renderActionButton(ctx, x, bottomY, w, btnH, "Clear Raw Packet", mx, my, this::lambda$renderPacketActionButtons$49);
    }

    private void renderWaitPacketPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        boolean filterByUser = ((Boolean)this.toggleStates.getOrDefault("lan_filterByUser", false)).booleanValue();
        int halfW = (w - 4) / 2;
        List<String> c2sTargets = this.getWaitPacketTargets("C2S");
        List<String> s2cTargets = this.getWaitPacketTargets("S2C");
        String summary = c2sTargets.isEmpty() && s2cTargets.isEmpty() ? "No packets selected. This step will continue on the next packet in either direction." : "This step continues as soon as any selected C2S or S2C packet arrives.";
        cy = this.renderEditorHint(ctx, x, cy, w, summary);
        this.renderActionButton(ctx, x, cy, halfW, 14, "Add C2S", mx, my, this::lambda$renderWaitPacketPanel$50);
        this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Add S2C", mx, my, this::lambda$renderWaitPacketPanel$51);
        cy += 18;
        this.renderActionButton(ctx, x, cy, halfW, 14, "Load Queue", mx, my, this::loadWaitPacketTargetsFromQueue);
        this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Clear All", mx, my, this::lambda$renderWaitPacketPanel$52);
        cy += 20;
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "wait_packet_c2s", "C2S Packets", c2sTargets, this::removeWaitPacketTarget, this::formatWaitPacketTarget, ActionEditorOverlay::lambda$renderWaitPacketPanel$53, this::lambda$renderWaitPacketPanel$54, "No C2S packets selected");
        cy += 4;
        this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "wait_packet_s2c", "S2C Packets", s2cTargets, this::removeWaitPacketTarget, this::formatWaitPacketTarget, ActionEditorOverlay::lambda$renderWaitPacketPanel$55, this::lambda$renderWaitPacketPanel$56, "No S2C packets selected");
    }

    private void renderSendPacketPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        List<PackUtilSharedState.QueuedPacket> actionPackets = this.getWorkingQueuedPackets();
        List<PackUtilSharedState.QueuedPacket> queuePackets = PackUtilSharedState.get().getDelayedPackets();
        if (queuePackets == null) {
            queuePackets = Collections.emptyList();
        }
        List<PackUtilSharedState.QueuedPacket> finalQueuePackets = queuePackets;
        PackUiText.draw(ctx, this.textRenderer, "Action Packets (" + actionPackets.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        this.renderOverlayButton(ctx, x + w - 44, cy, 44, 14, "Clear", PackUiOverlayButton.Variant.DANGER, !actionPackets.isEmpty(), mx, my, this::lambda$renderSendPacketPanel$57);
        cy += 13;
        cy = this.renderQueuedPacketList(ctx, x, cy, w, mx, my, delta, "_send_packet_action", actionPackets, true, this::lambda$renderSendPacketPanel$58);
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        PackUtilChatField nameField = (PackUtilChatField)this.textFields.get("customName");
        if (nameField != null) {
            int lw = this.labelWidth(w, "Name", font);
            this.drawLabel(ctx, "Name", x, cy, lw, font);
            nameField.setX(this.controlX(x, lw));
            nameField.setY(cy + 2);
            nameField.setWidth(this.controlWidth(w, lw));
            nameField.render(ctx, mx, my, delta);
            cy += 17;
        }
        this.renderInlineToggle(ctx, font, "waitForGui", "Wait for GUI", x, cy, w, mx, my);
        cy += 17;
        if (((Boolean)this.toggleStates.getOrDefault("waitForGui", false)).booleanValue()) {
            guiField = (PackUtilChatField)this.textFields.get("guiName");
            if (guiField != null) {
                int lw = this.labelWidth(w, "GUI Name", font);
                this.drawLabel(ctx, "GUI Name", x, cy, lw, font);
                guiField.setX(this.controlX(x, lw));
                guiField.setY(cy + 2);
                guiField.setWidth(this.controlWidth(w, lw));
                guiField.render(ctx, mx, my, delta);
                cy += 17;
            }
        } else {
            guiField = (PackUtilChatField)this.textFields.get("guiName");
            if (guiField != null) {
                guiField.setX(-1000);
            }
        }
        cy += 2;
        halfW = (w - 4) / 2;
        this.renderActionButton(ctx, x, cy, halfW, 14, "From Queue", mx, my, this::lambda$renderSendPacketPanel$59 /* captured: finalQueuePackets */);
        this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Paste Base64", mx, my, this::lambda$renderSendPacketPanel$60);
        cy += 18;
        this.renderActionButton(ctx, x, cy, halfW, 14, "Clear", mx, my, this::lambda$renderSendPacketPanel$61);
        this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "GBreak", mx, my, this::startGBreakCaptureForEditor);
        cy += 20;
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        PackUiText.draw(ctx, this.textRenderer, "Current Queue (" + finalQueuePackets.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        cy += 13;
        this.renderQueuedPacketList(ctx, x, cy, w, mx, my, delta, "_send_packet_queue", finalQueuePackets, false, this::lambda$renderSendPacketPanel$62 /* captured: finalQueuePackets */);
    }

    private int renderQueuedPacketList(class_332 ctx, int x, int y, int w, int mx, int my, float delta, String listKey, List<PackUtilSharedState.QueuedPacket> packets, boolean removable, IntConsumer rowAction) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int listH = 60;
        PackUiScrollViewport packetViewport = this.getOrCreateViewport(this.selectedScrollViewports, listKey, x, y, w, listH, 15, 5);
        packetViewport.setContentHeight(packets.size() * 15);
        this.selectedListBounds.put(listKey, y, listH);
        packetViewport.renderScrollbar(ctx, (double)mx, (double)my);
        int removeW = removable ? 13 : 0;
        int textW = w - 5 - 2 - (removable ? removeW + 2 : 0);
        if (!packets.isEmpty()) { /* goto L170; */ }
        PackUiText.draw(ctx, this.textRenderer, removable ? "(none - use GBreak, queue, or Paste)" : "(queue empty)", font, PackUtilColors.textDim(), x, y + 2, false);
        return y + listH;
        packetViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
        int firstVis = packetViewport.getFirstVisibleRow();
        for (int i = firstVis; i < packets.size(); i++) {
            if (i > packetViewport.getLastVisibleRow()) break;
            int iy = packetViewport.getRowScreenY(i);
            if (iy == -2147483648) {
            } else {
                QueuedPacket qp = (PackUtilSharedState.QueuedPacket)packets.get(i);
                String pname = qp != null && qp.packet != null ? PackUtilPacketNamer.getFriendlyName(qp.packet) : "???";
                String rowText = i + 1 + ". " + pname + " d=" + qp != null ? qp.getDelay() : 0;
                boolean hovered = mx >= x && mx < x + textW && my >= iy && my < iy + 13;
                PackUiListRenderer.drawRow(ctx, this.textRenderer, rowText, x, iy, textW, 13, hovered, false, PackUiListRenderer.RowTone.NORMAL);
                int rowIndex = i;
                if (removable) continue;
                this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, textW, 13, ActionEditorOverlay::lambda$renderQueuedPacketList$63 /* captured: rowAction, rowIndex */));
                if (removable) {
                    int removeX = x + textW + 2;
                    this.renderIconDeleteButton(ctx, removeX, iy, removeW, mx, my, ActionEditorOverlay::lambda$renderQueuedPacketList$64 /* captured: rowAction, rowIndex */);
                }
            }
        }
        packetViewport.endRender(ctx);
        return y + listH;
    }

    private void renderSendPacketButtons(class_332 ctx, int x, int y, int w, int mx, int my) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int btnH = 14;
        int halfW = (w - 4) / 2;
        int topY = y + 2;
        int bottomY = y + 20;
        String info = this.buildSendPacketInfo();
        PackUiText.draw(ctx, this.textRenderer, PackUiText.trimToWidth(this.textRenderer, info, w, font, -1), font, PackUtilColors.textDim(), x, y - 10, false);
        this.renderActionButton(ctx, x, topY, halfW, btnH, "From Queue", mx, my, this::lambda$renderSendPacketButtons$65);
        this.renderActionButton(ctx, x + halfW + 4, topY, halfW, btnH, "Paste Base64", mx, my, this::lambda$renderSendPacketButtons$66);
        this.renderActionButton(ctx, x, bottomY, halfW, btnH, "Clear", mx, my, this::lambda$renderSendPacketButtons$67);
        this.renderActionButton(ctx, x + halfW + 4, bottomY, halfW, btnH, "GBreak", mx, my, this::lambda$renderSendPacketButtons$70);
    }

    private void renderDelayPacketsPresetButtons(class_332 ctx, int x, int y, int w, int mx, int my) {
        int btnH = 14;
        int halfW = (w - 4) / 2;
        int x2 = x + halfW + 4;
        this.renderOverlayButton(ctx, x, y + 2, halfW, btnH, "Default", PackUiOverlayButton.Variant.SECONDARY, true, mx, my, this::lambda$renderDelayPacketsPresetButtons$71);
        this.renderOverlayButton(ctx, x2, y + 2, halfW, btnH, "Module", PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderDelayPacketsPresetButtons$72);
    }

    private PackUiOverlayButton renderOverlayButton(class_332 ctx, int x, int y, int w, int h, String label, PackUiOverlayButton.Variant variant, boolean active, int mx, int my, Runnable action) {
        PackUiOverlayButton button = PackUiOverlayButton.create(x, y, w, h, class_2561.method_43470(label), ActionEditorOverlay::lambda$renderOverlayButton$73 /* captured: action */);
        button.setVariant(variant);
        button.active = active;
        PackUiOverlayButton.renderStyled(ctx, this.textRenderer, button, mx, my);
        this.hitRegions.add(new ActionEditorOverlay.HitRegion(button, action));
        return button;
    }

    private void renderIconDeleteButton(class_332 ctx, int x, int y, int size, int mx, int my, Runnable action) {
        boolean hovered = mx >= x && mx < x + size && my >= y && my < y + size;
        PackUiListRenderer.drawIconButton(ctx, x, y, size, PackUiAssets.ICON_WINDOW_CLOSE, hovered, true);
        this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, y, size, size, ActionEditorOverlay::lambda$renderIconDeleteButton$74 /* captured: x, y, size, action */));
    }

    private void renderActionButton(class_332 ctx, int x, int y, int w, int h, String label, int mx, int my, Runnable action) {
        this.renderOverlayButton(ctx, x, y, w, h, label, PackUiOverlayButton.Variant.SECONDARY, true, mx, my, action);
    }

    private int renderEditorHint(class_332 ctx, int x, int y, int w, String text) {
        return this.renderEditorHint(ctx, x, y, w, text, PackUtilColors.textDim());
    }

    private int renderEditorHint(class_332 ctx, int x, int y, int w, String text, int color) {
        String hint = this.formatEditorHint(text);
        if (hint.isEmpty()) {
            return y;
        }
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        PackUiText.draw(ctx, this.textRenderer, PackUiText.trimToWidth(this.textRenderer, hint, Math.max(10, w), font, color), font, color, x, y + 2, false);
        return y + 11;
    }

    private String formatEditorHint(String text) {
        if (text == null) {
            return "";
        }
        String normalized = text.trim().replaceAll("\\s+", " ");
        if (normalized.isEmpty()) {
            return "";
        }
        var var4 = normalized;
        int var5 = -1;
        switch (var4.hashCode()) {
            case 1308442059::
                if (!var4.equals("Blank name + slot = exact slot. Name + slot = that item in that slot.")) { /* goto @957; */ }
                var5 = 0;
                /* goto @957; */
            case -928495395::
                if (!var4.equals("Swap uses the blue H1-H9 button to pick which hotbar slot gets swapped.")) { /* goto @957; */ }
                var5 = 1;
                /* goto @957; */
            case -1703809120::
                if (!var4.equals("Editing this row. 0 means drop the full stack from that slot or item.")) { /* goto @957; */ }
                var5 = 2;
                /* goto @957; */
            case -1425437306::
                if (!var4.equals("No row selected. The controls below set defaults for new rows you add.")) { /* goto @957; */ }
                var5 = 3;
                /* goto @957; */
            case 1087260599::
                if (!var4.equals("Continue when any LAN peer reaches the target step.")) { /* goto @957; */ }
                var5 = 4;
                /* goto @957; */
            case -930797083::
                if (!var4.equals("Add peers below to narrow it down. Until then, it waits for any peer at the fallback step.")) { /* goto @957; */ }
                var5 = 5;
                /* goto @957; */
            case -962273399::
                if (!var4.equals("Each peer below must reach its step before this continues.")) { /* goto @957; */ }
                var5 = 6;
                /* goto @957; */
            case 1031449772::
                if (!var4.equals("No packets selected. This step will continue on the next packet in either direction.")) { /* goto @957; */ }
                var5 = 7;
                /* goto @957; */
            case -320073715::
                if (!var4.equals("This step continues as soon as any selected C2S or S2C packet arrives.")) { /* goto @957; */ }
                var5 = 8;
                /* goto @957; */
            case -621554833::
                if (!var4.equals("Capture only marks the block. It will not open it.")) { /* goto @957; */ }
                var5 = 9;
                /* goto @957; */
            case -877907580::
                if (!var4.equals("0,0,0 uses the current container when open, otherwise the closest nearby one.")) { /* goto @957; */ }
                var5 = 10;
                /* goto @957; */
            case -2106236064::
                if (!var4.equals("Pick on an item adds the item. Pick on an empty slot adds that exact slot.")) { /* goto @957; */ }
                var5 = 11;
                /* goto @957; */
            case 546439063::
                if (!var4.equals("Pick only accepts chest/custom GUI slots here.")) { /* goto @957; */ }
                var5 = 12;
                /* goto @957; */
            case 1105304122::
                if (!var4.equals("Pick only accepts player inventory slots here.")) { /* goto @957; */ }
                var5 = 13;
                /* goto @957; */
            case -753314444::
                if (!var4.equals("No payment targets selected yet.")) { /* goto @957; */ }
                var5 = 14;
                /* goto @957; */
            case -933454588::
                if (!var4.equals("Click a scanned name to toggle it, or use All to add the filtered scan results.")) { /* goto @957; */ }
                var5 = 15;
                /* goto @957; */
            case 2050118160::
                if (!var4.equals("The search box also lets you manually add a player by pressing Enter.")) { /* goto @957; */ }
                var5 = 16;
                /* goto @957; */
            case 611507558::
                if (!var4.equals("Pick modules below, then click the mode chip on each row.")) { /* goto @957; */ }
                var5 = 17;
                /* goto @957; */
            case 290940928::
                if (!var4.equals("Each row runs with its own Toggle / Enable / Disable setting.")) { /* goto @957; */ }
                var5 = 18;
                /* goto @957; */
            case -639306734::
                if (!var4.equals("Capture View fills in your current yaw and pitch.")) { /* goto @957; */ }
                var5 = 19;
                /* goto @957; */
            case 791465872::
                if (!var4.equals("Wait for Arrival continues only after Baritone finishes.")) { /* goto @957; */ }
                var5 = 20;
                /* goto @957; */
            case -8607168::
                if (!var4.equals("Simple disconnect. Delay only controls how long to wait before closing the connection.")) { /* goto @957; */ }
                var5 = 21;
                /* goto @957; */
            case -806011472::
                if (!var4.equals("Sends lag packets, then the selected kick packet. Packet Count controls how hard it pushes.")) { /* goto @957; */ }
                var5 = 22;
                /* goto @957; */
            case 394770128::
                if (!var4.equals("Kick Dupe will run the next eligible macro actions inside the lag sandwich, then kick.")) { /* goto @957; */ }
                var5 = 23;
                /* goto @957; */
            case -1579095803::
                if (!var4.equals("Kick Dupe will try to use a bundle, then kick.")) { /* goto @957; */ }
                var5 = 24;
                /* goto @957; */
            case -560950425::
                if (!var4.equals("Automatically detects teleport/world change and disconnects at the perfect timing for dupe exploits.")) { /* goto @957; */ }
                var5 = 25;
                /* goto @957; */
            case -1642845228::
                if (!var4.equals("Waits until the current GUI closes.")) { /* goto @957; */ }
                var5 = 26;
                /* goto @957; */
            case -1830035187::
                if (!var4.equals("Waits until a GUI opens.")) { /* goto @957; */ }
                var5 = 27;
                /* goto @957; */
            case -1427994301::
                if (!var4.equals("Blank pattern waits for any incoming server or plugin message.")) { /* goto @957; */ }
                var5 = 28;
                /* goto @957; */
            case 1465456035::
                if (!var4.equals("Blank pattern waits for any incoming chat line.")) { /* goto @957; */ }
                var5 = 29;
                /* goto @957; */
            case -1512930989::
                if (!var4.equals("Regex is on, so the pattern must match with Java regex rules.")) { /* goto @957; */ }
                var5 = 30;
                /* goto @957; */
            case -1940885496::
                if (!var4.equals("No Meteor modules found right now.")) { /* goto @957; */ }
                var5 = 31;
                /* goto @957; */
            case -1372949048::
                if (!var4.equals("Press Scan to load the current server players.")) { /* goto @957; */ }
                var5 = 32;
                /* goto @957; */
            case -1806971585::
                if (!var4.equals("Click a row to use that message.")) { /* goto @957; */ }
                var5 = 33;
                /* goto @957; */
            case 749125688::
                if (var4.equals("Pick target blocks, then choose the stop rule you want.")) {
                    var5 = 34;
                }
            default:
                switch (var5) {
                    case 0::
                        String exact = "Blank name + slot = exact slot.";
                        break;
                    case 1::
                        exact = "Use H1-H9 to pick the swap slot.";
                        break;
                    case 2::
                        exact = "Editing row. 0 = full stack.";
                        break;
                    case 3::
                        exact = "No row picked. Controls set new-row defaults.";
                        break;
                    case 4::
                        exact = "Waits for any LAN peer step.";
                        break;
                    case 5::
                        exact = "Add peers below or use fallback.";
                        break;
                    case 6::
                        exact = "All listed peers must reach their step.";
                        break;
                    case 7::
                        exact = "No filters: next packet continues.";
                        break;
                    case 8::
                        exact = "Waits for any chosen packet.";
                        break;
                    case 9::
                        exact = "Capture only marks the block.";
                        break;
                    case 10::
                        exact = "0,0,0 = current or nearest container.";
                        break;
                    case 11::
                        exact = "Filled slot = item. Empty slot = exact slot.";
                        break;
                    case 12::
                        exact = "Pick only works on GUI slots here.";
                        break;
                    case 13::
                        exact = "Pick only works in your inventory here.";
                        break;
                    case 14::
                        exact = "No players selected.";
                        break;
                    case 15::
                        exact = "Click names to toggle, or use All.";
                        break;
                    case 16::
                        exact = "Press Enter to add a typed player.";
                        break;
                    case 17::
                        exact = "Pick modules, then set each mode.";
                        break;
                    case 18::
                        exact = "Each row keeps its own mode.";
                        break;
                    case 19::
                        exact = "Capture View fills yaw and pitch.";
                        break;
                    case 20::
                        exact = "Waits until Baritone arrives.";
                        break;
                    case 21::
                        exact = "Simple disconnect after the delay.";
                        break;
                    case 22::
                        exact = "Sends lag, then the kick packet.";
                        break;
                    case 23::
                        exact = "Runs next actions inside the dupe kick.";
                        break;
                    case 24::
                        exact = "Tries bundle dupe, then kicks.";
                        break;
                    case 25::
                        exact = "Auto-disconnects at the perfect dupe timing.";
                        break;
                    case 26::
                        exact = "Waits for the GUI to close.";
                        break;
                    case 27::
                        exact = "Waits for any GUI to open.";
                        break;
                    case 28::
                        exact = "Blank pattern = any server message.";
                        break;
                    case 29::
                        exact = "Blank pattern = any chat line.";
                        break;
                    case 30::
                        exact = "Regex mode uses Java regex rules.";
                        break;
                    case 31::
                        exact = "No modules found.";
                        break;
                    case 32::
                        exact = "Press Scan for players.";
                        break;
                    case 33::
                        exact = "Click a row to use it.";
                        break;
                    case 34::
                        exact = "Pick blocks, then choose a stop rule.";
                        break;
                    default:
                        exact = "";
                        break;
                }
                if (!exact.isEmpty()) {
                    return this.fitEditorHintText(exact);
                }
                normalized = normalized.replace("Waits until", "Waits for").replace("Continue when", "Continues when").replace("This step continues as soon as", "Continues when").replace("the selected", "chosen").replace("the current", "this").replace("current ", "").replace("number of times", "times").replace("the chosen number of times", "times").replace("the chosen ticks", "set ticks").replace("only after", "after").replace("It will not", "Won't").replace("selected kick packet", "kick packet").replace("Packet Count controls how hard it pushes", "Packet Count controls force").replace("the open handler", "the open GUI").replace("player inventory", "inventory").replace("inventory slot", "slot").replace("the matched item into", "it into").replace("first matching visible slot", "first visible match").replace("contains an item that matches the optional name", "matches the optional item").replace("becomes empty", "turns empty").replace("reaches the target count", "hits the target count").replace("drops below the target count", "drops below the target").replace("on the first content or count change in that exact slot", "on the first exact slot change").replace("the block under your crosshair", "your target block").replace("the entity under your crosshair", "your target entity").replace("whatever is under your crosshair", "your target").replace("will attack or break", "acts on").replace("will interact with", "uses").replace("the currently selected hotbar item", "the held item");
                return this.fitEditorHintText(normalized);
        }
    }

    private void applyEditorPlaceholders() {
        if (this.schema == null) { /* goto L118; */ }
        var var1 = this.schema.fields().iterator();
        while (var1.hasNext()) {
            FieldDef field = (FieldDef)var1.next();
            switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$gui$macro$editor$FieldType[field.type().ordinal()]) {
                case 2::
                case 3::
                case 4::
                case 6::
                    this.applyTextFieldPlaceholder(field.key(), this.resolveFieldPlaceholder(field));
                    break;
                case 7::
                    this.applyBlockPosPlaceholders(field.key());
                    break;
                case 5::
                default:
            }
        }
        this.applyTextFieldPlaceholder("item_guiName", "Any GUI");
        this.applyTextFieldPlaceholder("drop_guiName", "Any GUI");
        this.applyTextFieldPlaceholder("lan_defaultStep", "Any step");
        this.applyTextFieldPlaceholder("item_entrySlot", "Slot");
        this.applyTextFieldPlaceholder("drop_entrySlot", "Slot #");
        this.applyTextFieldPlaceholder("_craft_amount", "1");
        this.applyTextFieldPlaceholder("_lan_step_add", "1");
        this.applyTextFieldPlaceholder("drop_globalCount", "1");
        this.applyTextFieldPlaceholder("amountInput", "1k");
        this.applyAddFieldPlaceholder("_item_add", "Any item");
        this.applyAddFieldPlaceholder("_drop_add", "Any item");
        this.applyAddFieldPlaceholder("_craft_search", "Find recipe");
        this.applyAddFieldPlaceholder("_lan_user_add", "Peer name");
        this.applyAddFieldPlaceholder("soundIds", "Find sound");
        this.applyAddFieldPlaceholder("entityIds", "Find entity");
        this.applyAddFieldPlaceholder("targetItems", "Item name");
        this.applyAddFieldPlaceholder("players", "Find player");
        this.applyAddFieldPlaceholder("_toggle_module_search", "Find module");
        this.applyAddFieldPlaceholder("_wait_chat_search", "Find chat");
    }

    private void applyTextFieldPlaceholder(String key, String placeholder) {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get(key);
        this.setEditorPlaceholder(field, placeholder);
    }

    private void applyAddFieldPlaceholder(String key, String placeholder) {
        PackUtilChatField field = (PackUtilChatField)this.addFields.get(key);
        this.setEditorPlaceholder(field, placeholder);
    }

    private void applyBlockPosPlaceholders(String key) {
        this.applyTextFieldPlaceholder(key + "_0", "X");
        this.applyTextFieldPlaceholder(key + "_1", "Y");
        this.applyTextFieldPlaceholder(key + "_2", "Z");
    }

    private void setEditorPlaceholder(PackUtilChatField field, String placeholder) {
        if (field == null || placeholder == null || placeholder.isBlank()) {
            return;
        }
        field.setPlaceholder(class_2561.method_43470(this.fitEditorGhostText(placeholder)));
    }

    private String resolveFieldPlaceholder(FieldDef field) {
        if (field == null) {
            return "";
        }
        var var2 = field.key();
        int var3 = -1;
        switch (var2.hashCode()) {
            case 372599398::
                if (!var2.equals("guiName")) { /* goto @979; */ }
                var3 = 0;
                /* goto @979; */
            case 564843313::
                if (!var2.equals("waitGuiName")) { /* goto @979; */ }
                var3 = 1;
                /* goto @979; */
            case -1328534051::
                if (!var2.equals("guiTitle")) { /* goto @979; */ }
                var3 = 2;
                /* goto @979; */
            case -791090288::
                if (!var2.equals("pattern")) { /* goto @979; */ }
                var3 = 3;
                /* goto @979; */
            case 954925063::
                if (!var2.equals("message")) { /* goto @979; */ }
                var3 = 4;
                /* goto @979; */
            case -1724546052::
                if (!var2.equals("description")) { /* goto @979; */ }
                var3 = 5;
                /* goto @979; */
            case -1581702082::
                if (!var2.equals("customText")) { /* goto @979; */ }
                var3 = 6;
                /* goto @979; */
            case 110371416::
                if (!var2.equals("title")) { /* goto @979; */ }
                var3 = 7;
                /* goto @979; */
            case -1581885028::
                if (!var2.equals("customName")) { /* goto @979; */ }
                var3 = 8;
                /* goto @979; */
            case -2055695131::
                if (!var2.equals("commandTemplate")) { /* goto @979; */ }
                var3 = 9;
                /* goto @979; */
            case -1231385006::
                if (!var2.equals("amountInput")) { /* goto @979; */ }
                var3 = 10;
                /* goto @979; */
            case 1177331774::
                if (!var2.equals("itemName")) { /* goto @979; */ }
                var3 = 11;
                /* goto @979; */
            case -1247684088::
                if (!var2.equals("fromItemName")) { /* goto @979; */ }
                var3 = 12;
                /* goto @979; */
            case 1157263321::
                if (!var2.equals("toItemName")) { /* goto @979; */ }
                var3 = 13;
                /* goto @979; */
            case -870351081::
                if (!var2.equals("moduleName")) { /* goto @979; */ }
                var3 = 14;
                /* goto @979; */
            case 3533310::
                if (!var2.equals("slot")) { /* goto @979; */ }
                var3 = 15;
                /* goto @979; */
            case -1244688184::
                if (!var2.equals("fromSlot")) { /* goto @979; */ }
                var3 = 16;
                /* goto @979; */
            case -868894951::
                if (!var2.equals("toSlot")) { /* goto @979; */ }
                var3 = 17;
                /* goto @979; */
            case -661669145::
                if (!var2.equals("slotNumber")) { /* goto @979; */ }
                var3 = 18;
                /* goto @979; */
            case 486580015::
                if (!var2.equals("targetSlot")) { /* goto @979; */ }
                var3 = 19;
                /* goto @979; */
            case 218491247::
                if (!var2.equals("healthThreshold")) { /* goto @979; */ }
                var3 = 20;
                /* goto @979; */
            case 119407::
                if (!var2.equals("yaw")) { /* goto @979; */ }
                var3 = 21;
                /* goto @979; */
            case 106677056::
                if (!var2.equals("pitch")) { /* goto @979; */ }
                var3 = 22;
                /* goto @979; */
            case 1550347913::
                if (!var2.equals("delayMs")) { /* goto @979; */ }
                var3 = 23;
                /* goto @979; */
            case -1657359693::
                if (!var2.equals("delayTicks")) { /* goto @979; */ }
                var3 = 24;
                /* goto @979; */
            case -802893721::
                if (!var2.equals("clickCount")) { /* goto @979; */ }
                var3 = 25;
                /* goto @979; */
            case -309069880::
                if (!var2.equals("useCount")) { /* goto @979; */ }
                var3 = 26;
                /* goto @979; */
            case 1191582967::
                if (!var2.equals("holdTicks")) { /* goto @979; */ }
                var3 = 27;
                /* goto @979; */
            case 505588071::
                if (!var2.equals("packetCount")) { /* goto @979; */ }
                var3 = 28;
                /* goto @979; */
            case -1974210183::
                if (!var2.equals("maxDistance")) { /* goto @979; */ }
                var3 = 29;
                /* goto @979; */
            case -1307079248::
                if (!var2.equals("stopSlotsUsed")) { /* goto @979; */ }
                var3 = 30;
                /* goto @979; */
            case 1040995577::
                if (!var2.equals("slotsUsedThreshold")) { /* goto @979; */ }
                var3 = 31;
                /* goto @979; */
            case -445781937::
                if (!var2.equals("minedCountTarget")) { /* goto @979; */ }
                var3 = 32;
                /* goto @979; */
            case -890767906::
                if (!var2.equals("timeoutSeconds")) { /* goto @979; */ }
                var3 = 33;
                /* goto @979; */
            case 130154818::
                if (!var2.equals("durationTicks")) { /* goto @979; */ }
                var3 = 34;
                /* goto @979; */
            case 1447311504::
                if (!var2.equals("tickOffset")) { /* goto @979; */ }
                var3 = 35;
                /* goto @979; */
            case -643520670::
                if (!var2.equals("preGenCount")) { /* goto @979; */ }
                var3 = 36;
                /* goto @979; */
            case 727742542::
                if (!var2.equals("revisionOffset")) { /* goto @979; */ }
                var3 = 37;
                /* goto @979; */
            case -480311169::
                if (!var2.equals("maxWaitMs")) { /* goto @979; */ }
                var3 = 38;
                /* goto @979; */
            case -1522037242::
                if (var2.equals("bufferMs")) {
                    var3 = 39;
                }
            default:
                /* decompile fallback: stack underflow while reading return @ offset 1334 opcode areturn (stack_before=0) */
                /* decompile technical detail:
                 * category: other
                 * stage: operand_stack_simulation
                 * detail: stack underflow while reading return @ offset 1334 opcode areturn (stack_before=0)
                 * explanation: the simulated JVM operand stack became inconsistent at the reported bytecode offset and opcode, so structured Java emission was aborted
                 * emitted_body: raw bytecode disassembly follows
                 */
                // 979: load
                // 980: tableswitch
                // 1156: ldc
                // 1159: goto
                // 1162: ldc
                // 1165: goto
                // 1168: ldc
                // 1171: goto
                // 1174: ldc
                // 1177: goto
                // 1180: ldc
                // 1183: goto
                // 1186: ldc
                // 1189: goto
                // 1192: ldc
                // 1195: goto
                // 1198: ldc
                // 1201: goto
                // 1204: ldc
                // 1207: goto
                // 1210: ldc
                // 1213: goto
                // 1216: ldc
                // 1219: goto
                // 1222: ldc
                // 1225: goto
                // 1228: ldc
                // 1231: goto
                // 1234: ldc
                // 1237: goto
                // 1240: ldc
                // 1243: goto
                // 1246: ldc
                // 1249: goto
                // 1252: ldc
                // 1255: goto
                // 1258: ldc
                // 1261: goto
                // 1264: getstatic
                // 1267: load
                // 1268: invokevirtual
                // 1271: invokevirtual
                // 1274: arrayload
                // 1275: tableswitch
                // 1308: load
                // 1309: load
                // 1310: invokevirtual
                // 1313: invokevirtual
                // 1316: goto
                // 1319: ldc
                // 1322: goto
                // 1325: ldc
                // 1328: goto
                // 1331: ldc
                // 1334: areturn
        }
    }

    private String fitEditorGhostText(String text) {
        String normalized = text == null ? "" : text.trim().replaceAll("\\s+", " ");
        if (normalized.length() <= 16) {
            return normalized;
        }
        int cutoff = normalized.lastIndexOf(32, 13);
        if (cutoff < 5) {
            cutoff = 13;
        }
        return normalized.substring(0, Math.max(1, cutoff)).trim() + "...";
    }

    private String fitEditorHintText(String text) {
        String normalized = text == null ? "" : text.trim().replaceAll("\\s+", " ");
        if (normalized.length() <= EDITOR_HINT_MAX_CHARS) {
            return normalized;
        }
        int cutoff = normalized.lastIndexOf(32, EDITOR_HINT_MAX_CHARS - 3);
        if (cutoff < 8) {
            cutoff = EDITOR_HINT_MAX_CHARS - 3;
        }
        return normalized.substring(0, Math.max(1, cutoff)).trim() + "...";
    }

    private void renderRow(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my, float delta) {
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$gui$macro$editor$FieldType[field.type().ordinal()]) {
            case 1::
                this.renderToggle(ctx, field, x, y, w, mx, my);
                /* goto @179; */
            case 2::
            case 3::
            case 4::
            case 6::
                this.renderTextField(ctx, field, x, y, w, mx, my, delta);
                /* goto @179; */
            case 5::
                this.renderEnum(ctx, field, x, y, w, mx, my);
                /* goto @179; */
            case 7::
                this.renderBlockPos(ctx, field, x, y, w, mx, my, delta);
                /* goto @179; */
            case 8::
                if (field.captureMode() == CaptureMode.BLOCK_CATALOG) {
                    this.renderStringListCatalog(ctx, field, x, y, w, mx, my, delta);
                } else {
                    this.renderStringList(ctx, field, x, y, w, mx, my, delta);
                }
            default:
                return;
        }
    }

    private void renderToggle(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my) {
        String key = field.key();
        boolean val = ((Boolean)this.toggleStates.getOrDefault(key, false)).booleanValue();
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int btnW = 34;
        int btnH = 14;
        int lw = this.labelWidth(w, field.label(), font, btnW);
        this.drawLabel(ctx, field.label(), x, y, lw, font);
        int btnX = x + w - btnW;
        this.renderOverlayButton(ctx, btnX, y + 2, btnW, btnH, val ? "ON" : "OFF", val ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER, true, mx, my, this::lambda$renderToggle$75 /* captured: key, field */);
    }

    private void renderTextField(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my, float delta) {
        String key = field.key();
        PackUtilChatField tf = (PackUtilChatField)this.textFields.get(key);
        if (tf == null) {
            return;
        }
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        if (this.isWaitChatPatternField(field)) {
            PackUiText.draw(ctx, this.textRenderer, field.label(), font, PackUtilColors.textSecondary(), x, y + 2, false);
            tf.setX(x);
            tf.setY(y + 13);
            tf.setWidth(w);
            tf.setHeight(40);
            tf.render(ctx, mx, my, delta);
            return;
        }
        int lw = this.labelWidth(w, field.label(), font, field.captureMode() == CaptureMode.ITEM_SLOT ? 88 : 56);
        this.drawLabel(ctx, field.label(), x, y, lw, font);
        int tfX = this.controlX(x, lw);
        if (field.captureMode() == CaptureMode.ITEM_SLOT) {
            int pickW = 30;
            int tfW = this.controlWidth(w, lw) - pickW - 2;
            tf.setX(tfX);
            tf.setY(y + 2);
            tf.setWidth(tfW);
            tf.render(ctx, mx, my, delta);
            int pkX = tfX + tfW + 2;
            boolean capt = key.equals(this.itemSlotCapturePendingKey);
            String fKey = key;
            this.renderOverlayButton(ctx, pkX, y + 2, pickW, 14, capt ? "Done" : "Pick", capt ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderTextField$76 /* captured: fKey */);
        } else {
            int tfW = this.controlWidth(w, lw);
            tf.setX(tfX);
            tf.setY(y + 2);
            tf.setWidth(tfW);
            tf.render(ctx, mx, my, delta);
        }
    }

    private boolean isWaitChatPatternField(FieldDef field) {
        return field != null && "pattern".equals(field.key()) && this.targetAction != null && this.targetAction.getType() == MacroActionType.WAIT_CHAT;
    }

    private void renderEnum(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my) {
        String key = field.key();
        List<String> opts = field.enumOptions();
        if (opts.isEmpty()) {
            return;
        }
        int idx = Math.min(((Integer)this.enumIndices.getOrDefault(key, 0)).intValue(), opts.size() - 1);
        String val = (String)opts.get(idx);
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int lw = this.labelWidth(w, field.label(), font, 72);
        this.drawLabel(ctx, field.label(), x, y, lw, font);
        int ctrlX = this.controlX(x, lw);
        int ctrlW = this.controlWidth(w, lw);
        int arwW = 10;
        int arwH = 14;
        int valW = ctrlW - arwW * 2 - 4;
        this.renderOverlayButton(ctx, ctrlX, y + 2, arwW, arwH, "<", PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderEnum$77 /* captured: key, opts */);
        int valX = ctrlX + arwW + 2;
        ctx.method_25294(valX, y + 2, valX + valW, y + 2 + arwH, -15331826);
        String trimmed = PackUiText.trimToWidth(this.textRenderer, val, valW - 4, font, -1);
        int textX = valX + Math.max(0, (valW - this.uiWidth(font, trimmed)) / 2);
        int enumTextY = PackUiSizing.alignTextY(y + 2, arwH, this.theme.fontHeight(PackUiTone.BODY), this.theme.buttonTextNudge());
        PackUiText.draw(ctx, this.textRenderer, trimmed, font, PackUtilColors.textPrimary(), textX, enumTextY, false);
        int nxtX = ctrlX + ctrlW - arwW;
        this.renderOverlayButton(ctx, nxtX, y + 2, arwW, arwH, ">", PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderEnum$78 /* captured: key, opts */);
    }

    private void renderBlockPos(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my, float delta) {
        String key = field.key();
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        String[] tmp0 = new String[3];
        tmp0[0] = "X";
        tmp0[1] = "Y";
        tmp0[2] = "Z";
        String[] axis = tmp0;
        boolean hasCapture = field.captureMode() != CaptureMode.NONE;
        int capBtnW = 52;
        int capBtnH = 14;
        int labelW = hasCapture ? w - capBtnW - 4 : w;
        PackUiText.draw(ctx, this.textRenderer, field.label(), font, PackUtilColors.textSecondary(), x, y + 3, false);
        if (hasCapture) {
            int cbX = x + labelW + 4;
            this.renderOverlayButton(ctx, cbX, y, capBtnW, capBtnH, "Capture", PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderBlockPos$79 /* captured: field */);
        }
        fieldW = (w - 4) / 3;
        for (int i = 0; i < 3; i++) {
            PackUtilChatField tf = (PackUtilChatField)this.textFields.get(key + "_" + i);
            if (tf == null) {
            } else {
                int fx = x + i * (fieldW + 2);
                PackUiText.draw(ctx, this.textRenderer, axis[i], font, PackUtilColors.textDim(), fx, y + 15 + 3, false);
                tf.setX(fx + 9);
                tf.setY(y + 15 + 1);
                tf.setWidth(fieldW - 9);
                tf.render(ctx, mx, my, delta);
            }
        }
    }

    private void renderStringList(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my, float delta) {
        String key = field.key();
        List<String> lst = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        PackUtilChatField af = (PackUtilChatField)this.addFields.get(key);
        boolean editable = this.isEditableStringList(key);
        int editIdx = editable ? (Integer)this.stringListEditIndex.getOrDefault(key, -1) : -1;
        if (editIdx >= lst.size()) {
            editIdx = -1;
            this.stringListEditIndex.put(key, -1);
        }
        String filter = !editable && af != null ? af.getText().toLowerCase() : "";
        String emptyHint = this.getStringListEmptyHint(key);
        List<Integer> filtered = new ArrayList();
        for (int i = 0; i < lst.size(); i++) {
            if (!filter.isEmpty() || ((String)lst.get(i)).toLowerCase().contains(filter)) continue;
            filtered.add(i);
        }
        sectionLabel = filter.isEmpty() ? field.label() + " (" + lst.size() + ")" : field.label() + " (" + filtered.size() + "/" + lst.size() + ")";
        PackUiText.draw(ctx, this.textRenderer, sectionLabel, font, PackUtilColors.textSecondary(), x, y + 2, false);
        boolean hasCapture = field.captureMode() != CaptureMode.NONE;
        boolean hasSlotField = editable && this.usesMinecraftTextRendering(key);
        int btnH = 14;
        int addBtnW = 34;
        int slotW = hasSlotField ? 44 : 0;
        int capBtnW = hasCapture ? 52 : 0;
        int capBtnX = x + w - capBtnW;
        int addBtnX = (hasCapture ? capBtnX : x + w) - 3 - addBtnW;
        int slotX = hasSlotField ? addBtnX - 2 - slotW : 0;
        int addY = y + 13;
        PackUtilChatField slotField = hasSlotField ? (PackUtilChatField)this.textFields.get(key + "_slot") : null;
        slotField = this.makeField(slotW);
        if (hasSlotField && slotField == null) {
            slotField.setNumericOnly(true);
            slotField.setPlaceholder(class_2561.method_43470("Slot#"));
            this.textFields.put(key + "_slot", slotField);
        }
        if (af == null) { /* goto L569; */ }
        af.setX(x);
        af.setY(addY + 1);
        af.setWidth((hasSlotField ? slotX : addBtnX) - x - 2);
        af.render(ctx, mx, my, delta);
        L569: ;
        slotField.setX(slotX);
        if (hasSlotField && slotField != null) {
            slotField.setY(addY + 1);
            slotField.setWidth(slotW);
            slotField.render(ctx, mx, my, delta);
        }
        if (!editable) { /* goto L802; */ }
        if (editIdx < 0) { /* goto L802; */ }
        if (editIdx >= lst.size()) { /* goto L802; */ }
        if (af == null) { /* goto L802; */ }
        String nameText = af.getText().strip();
        String slotText = hasSlotField && slotField != null ? slotField.getText().strip() : "";
        String entry = ActionEditorOverlay.buildEntryFromNameAndSlot(nameText, slotText);
        if (entry.isEmpty()) { /* goto L802; */ }
        String normalized = this.isXCarryListKey(key) ? this.normalizeXCarryEntry(entry) : this.usesStoreTargetFormatting(key) ? StoreItemAction.normalizeTargetEntry(entry) : entry;
        if (normalized != null) {
            if (!normalized.isBlank()) {
                if (!normalized.equals(lst.get(editIdx))) {
                    lst.set(editIdx, normalized);
                    if (this.usesMinecraftTextRendering(key)) {
                        this.editorItemLists.put(key, this.buildStructuredListTargets(key));
                    }
                }
            }
        }
        fSlotField = slotField;
        if (af != null) {
            this.renderOverlayButton(ctx, addBtnX, addY, addBtnW, btnH, "+Add", PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderStringList$80 /* captured: af, hasSlotField, fSlotField, field, lst, key */);
        }
        if (!hasCapture) { /* goto L982; */ }
        isItemSlot = field.captureMode() == CaptureMode.ITEM_SLOT;
        capturing = isItemSlot && key.equals(this.itemSlotCapturePendingKey);
        fKey = key;
        FieldDef fField = field;
        List<String> fLst = lst;
        this.renderOverlayButton(ctx, capBtnX, addY, capBtnW, btnH, isItemSlot ? capturing ? "Done" : "Pick" : "Capture", capturing ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderStringList$81 /* captured: isItemSlot, fKey, fField, fLst */);
        L982: ;
        itemsY = addY + btnH + 2;
        selAreaH = 60;
        delW = 13;
        strViewport = this.getOrCreateViewport(this.selectedScrollViewports, key, x, itemsY, w, selAreaH, 15, 5);
        strViewport.setContentHeight(filtered.size() * 15);
        this.selectedListBounds.put(key, itemsY, selAreaH);
        strViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (!filtered.isEmpty()) {
            rowAreaW = w - 5 - 1 - delW - 2;
            strViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstVi = strViewport.getFirstVisibleRow();
            for (int vi = firstVi; vi < filtered.size(); vi++) {
                if (vi > strViewport.getLastVisibleRow()) break;
                int ri = ((Integer)filtered.get(vi)).intValue();
                int iy = strViewport.getRowScreenY(vi);
                if (iy == -2147483648) {
                } else {
                    class_2561 displayValue = this.formatStringListEntryText(key, (String)lst.get(ri), ri);
                    boolean selected = editable && ri == editIdx;
                    boolean hovered = mx >= x && mx < x + rowAreaW && my >= iy && my < iy + 13;
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, displayValue, x, iy, rowAreaW, 13, hovered, selected, PackUiListRenderer.RowTone.NORMAL, this.usesMinecraftTextRendering(key));
                    if (!editable) { /* goto L1371; */ }
                    int fri = ri;
                    PackUtilChatField fSlotF2 = hasSlotField ? (PackUtilChatField)this.textFields.get(key + "_slot") : null;
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, rowAreaW, 13, this::lambda$renderStringList$82 /* captured: key, fri, af, fSlotF2, lst */));
                    L1371: ;
                    delX = x + rowAreaW + 2;
                    fRi = ri;
                    this.renderIconDeleteButton(ctx, delX, iy, delW, mx, my, this::lambda$renderStringList$83 /* captured: lst, fRi, editable, key, af */);
                }
            }
            strViewport.endRender(ctx);
        } else {
            if (emptyHint != null) {
                if (!emptyHint.isBlank()) {
                    itemW = w - 5 - 1;
                    ctx.method_25294(x, itemsY, x + itemW, itemsY + 12, PackUtilColors.rowNormal());
                    PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, emptyHint, x, itemsY, itemW);
                }
            }
        }
    }

    private String getStringListEmptyHint(String key) {
        if (this.isInventoryAuditTargetListKey(key)) {
            List<String> selected = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
            if (selected.isEmpty()) {
                return "Add at least one target before running this audit.";
            }
        }
        return null;
    }

    private void renderStringListCatalog(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my, float delta) {
        String key = field.key();
        List<String> sel = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        PackUtilChatField af = (PackUtilChatField)this.addFields.get(key);
        String filter = af != null ? af.getText().toLowerCase() : "";
        int cy = y;
        PackUiText.draw(ctx, this.textRenderer, field.label() + " (" + sel.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        cy += 13;
        int delW = 13;
        int selAreaH = 60;
        PackUiScrollViewport catSelViewport = this.getOrCreateViewport(this.selectedScrollViewports, key, x, cy, w, selAreaH, 15, 5);
        catSelViewport.setContentHeight(sel.size() * 15);
        this.selectedListBounds.put(key, cy, selAreaH);
        catSelViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (!sel.isEmpty()) {
            int delX = x + w - 5 - 2 - delW;
            catSelViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstSel = catSelViewport.getFirstVisibleRow();
            for (int i = firstSel; i < sel.size(); i++) {
                if (i > catSelViewport.getLastVisibleRow()) break;
                int siy = catSelViewport.getRowScreenY(i);
                if (siy == -2147483648) {
                } else {
                    String display = PackUtilRegistryLabels.block((String)sel.get(i));
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, display, x, siy, delX - x - 1, 13, mx >= x && mx < delX - 1 && my >= siy && my < siy + 13, false, PackUiListRenderer.RowTone.NORMAL);
                    int fi = i;
                    this.renderIconDeleteButton(ctx, delX, siy, delW, mx, my, this::lambda$renderStringListCatalog$84 /* captured: sel, fi, key */);
                }
            }
            catSelViewport.endRender(ctx);
        } else {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "(none selected)", x, cy, w - 5 - 1);
        }
        cy = cy + selAreaH;
        ctx.method_25294(x, cy + 1, x + w, cy + 2, PackUtilColors.subPanelBorder());
        cy += 5;
        if (af != null) {
            af.setX(x);
            af.setY(cy);
            af.setWidth(w);
            af.render(ctx, mx, my, delta);
        }
        cy += 14;
        int headerH = 15;
        int capBtnH2 = 14;
        int cbX = x + w - 52;
        int headerTextW = Math.max(24, cbX - x - 4);
        String headerLabel = PackUiText.trimToWidth(this.textRenderer, "Available Blocks", headerTextW, font, PackUtilColors.textSecondary());
        int headerTextY = PackUiSizing.alignTextY(cy, headerH, this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
        this.renderOverlayButton(ctx, cbX, cy, 52, capBtnH2, "Capture", PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderStringListCatalog$85 /* captured: field, sel */);
        PackUiText.draw(ctx, this.textRenderer, headerLabel, font, PackUtilColors.textSecondary(), x, headerTextY, false);
        cy = cy + (headerH + 2);
        List<String> all = ActionEditorOverlay.getAllBlockIds();
        List<String> filtered = new ArrayList();
        int catItemW = all.iterator();
        while (catItemW.hasNext()) {
            String id = (String)catItemW.next();
            if (!ActionEditorOverlay.matchesListFilter(filter, id, ActionEditorOverlay.trimMinecraftPrefix(id), PackUtilRegistryLabels.block(id))) continue;
            filtered.add(id);
        }
        catItemW = w - 5 - 1;
        catViewport = this.getOrCreateViewport(this.catalogScrollViewports, key, x, cy, w, 60, 13, 5);
        catViewport.setContentHeight(filtered.size() * 13);
        this.catalogListBounds.put(key, cy, 60);
        catViewport.renderScrollbar(ctx, (double)mx, (double)my);
        catViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
        int firstItem = catViewport.getFirstVisibleRow();
        for (int i = firstItem; i < filtered.size(); i++) {
            if (i > catViewport.getLastVisibleRow()) break;
            int iy = catViewport.getRowScreenY(i);
            if (iy == -2147483648) {
            } else {
                String id = (String)filtered.get(i);
                String display = PackUtilRegistryLabels.block(id);
                boolean already = sel.contains(id);
                boolean hov = mx >= x && mx < x + catItemW && my >= iy && my < iy + 13;
                PackUiListRenderer.drawRow(ctx, this.textRenderer, display, x, iy, catItemW, 13, hov, already, already ? PackUiListRenderer.RowTone.READY : PackUiListRenderer.RowTone.NORMAL);
                if (!already) {
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, catItemW, 13, ActionEditorOverlay::lambda$renderStringListCatalog$86 /* captured: sel, id */));
                } else {
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, catItemW, 13, ActionEditorOverlay::lambda$renderStringListCatalog$87 /* captured: sel, id */));
                }
            }
        }
        catViewport.endRender(ctx);
    }

    private void renderFooter(class_332 ctx, int footerY, int mx, int my) {
        int btnH = 16;
        int btnY = footerY + (22 - btnH) / 2;
        int btnW = 58;
        int gap = 6;
        int total = btnW * 2 + gap;
        int sx = this.panelX + (this.panelW - total) / 2;
        ctx.method_25294(this.panelX + 4, footerY, this.panelX + this.panelW - 4, footerY + 1, PackUtilColors.subPanelBorder());
        this.renderOverlayButton(ctx, sx, btnY, btnW, btnH, "Cancel", PackUiOverlayButton.Variant.SECONDARY, true, mx, my, this::lambda$renderFooter$88);
        int saveX = sx + btnW + gap;
        this.renderOverlayButton(ctx, saveX, btnY, btnW, btnH, "Save", PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderFooter$89);
    }

    private void enterCaptureMode() {
        this.clearCaptureToasts();
        this.captureHiddenOverlays = new ArrayList();
        var var1 = PackUtilOverlayManager.get().getOverlays().iterator();
        while (var1.hasNext()) {
            IPackUtilOverlay o = (IPackUtilOverlay)var1.next();
            if (o != this) {
                if (o.isVisible()) {
                    o.saveLayout();
                    this.captureHiddenOverlays.add(o);
                    o.setVisible(false);
                }
            }
        }
        this.saveLayout();
        this.clearTextFieldFocus();
        this.restoreVisibleAfterCapture = this.visible;
        this.visible = false;
    }

    private void enterEditorOnlyCaptureMode() {
        this.clearCaptureToasts();
        this.captureHiddenOverlays = null;
        this.saveLayout();
        this.clearTextFieldFocus();
        this.restoreVisibleAfterCapture = this.visible;
        this.visible = false;
    }

    private void restoreCaptureHiddenOverlays() {
        if (this.captureHiddenOverlays == null) {
            return;
        }
        PackUtilOverlayManager manager = PackUtilOverlayManager.get();
        var var2 = this.captureHiddenOverlays.iterator();
        while (var2.hasNext()) {
            IPackUtilOverlay overlay = (IPackUtilOverlay)var2.next();
            manager.register(overlay);
            overlay.setVisible(true);
            overlay.saveLayout();
        }
        this.captureHiddenOverlays = null;
    }

    private void clearCaptureCallbacks(boolean cancelGBreak) {
        PackUtilSharedState state = PackUtilSharedState.get();
        state.setCaptureCancelCallback(null);
        state.setBlockCaptureCallback(null);
        state.setEntityCaptureCallback(null);
        state.setAttackCaptureCallback(null);
        state.setEntityCaptureSpecific(false);
        if (cancelGBreak) {
            if (state.isGBreakCapturing()) {
                state.cancelGBreakCapture();
            }
        }
    }

    private void exitCaptureMode(boolean reopenInventory, boolean closeCurrentScreen) {
        this.restoreCaptureHiddenOverlays();
        this.clearCaptureCallbacks(false);
        this.visible = this.restoreVisibleAfterCapture;
        this.restoreVisibleAfterCapture = false;
        this.hitRegions.clear();
        this.scrollDragRegions.clear();
        PackUtilOverlayManager.get().bringToFront(this);
        if (reopenInventory) {
            if (this.screenBeforeCapture != null) {
                MC.execute(this::lambda$exitCaptureMode$90);
            }
        }
        if (closeCurrentScreen) {
            MC.execute(ActionEditorOverlay::lambda$exitCaptureMode$91);
        }
        this.screenBeforeCapture = null;
        this.refreshInteractiveLayout();
    }

    private void closeEditor(boolean save) {
        this.restoreCaptureHiddenOverlays();
        this.restoreVisibleAfterCapture = false;
        this.clearCaptureCallbacks(true);
        this.clearCaptureToasts();
        if (save) {
            if (this.targetAction != null) {
                if (this.onPreSave != null) {
                    this.onPreSave.run();
                }
                this.flushToWorkingTag();
                this.targetAction.fromTag(this.workingTag);
                if (this.onSaveCallback != null) {
                    this.onSaveCallback.run();
                }
            }
        }
        this.packetSelectorOverlay.close();
        this.visible = false;
        this.targetAction = null;
        this.workingTag = null;
        this.schema = null;
        this.itemAction = null;
        this.itemSlotCapturePendingKey = null;
        this.craftEntries = null;
        this.craftAllRecipes = null;
        this.craftFilteredRecipes = null;
        this.craftSelectedRecipe = null;
        this.craftRecipeListBounds = null;
        this.dropAction = null;
        this.editorItemFields.clear();
        this.editorItemLists.clear();
        this.lanStepEntries = null;
        this.toggleModuleEntries = null;
        this.onPreSave = null;
        this.onSaveCallback = null;
        this.screenBeforeGBreak = null;
        this.screenBeforeCapture = null;
    }

    private void clearCaptureToasts() {
        this.captureToasts.clear();
    }

    private void pruneCaptureToasts(long nowNanos) {
        this.captureToasts.removeIf(ActionEditorOverlay::lambda$pruneCaptureToasts$92 /* captured: nowNanos */);
    }

    private void showCaptureToast(String message, int accentColor) {
        if (message == null || message.isBlank()) {
            return;
        }
        long nowNanos = System.nanoTime();
        this.pruneCaptureToasts(nowNanos);
        if (this.captureToasts.size() >= 4) {
            this.captureToasts.remove(0);
        }
        this.captureToasts.add(new ActionEditorOverlay.CaptureToast(message, nowNanos, accentColor));
    }

    public boolean hasHandledScreenCaptureToasts() {
        this.pruneCaptureToasts(System.nanoTime());
        return !this.captureToasts.isEmpty();
    }

    public void renderHandledScreenCaptureToasts(class_332 context, int anchorX, int anchorY, int anchorWidth) {
        if (context == null || this.textRenderer == null || anchorWidth <= 0) {
            return;
        }
        long nowNanos = System.nanoTime();
        this.pruneCaptureToasts(nowNanos);
        if (this.captureToasts.isEmpty()) {
            return;
        }
        int y = anchorY;
        for (int i = this.captureToasts.size() - 1; i >= 0; i--) {
            CaptureToast toast = (ActionEditorOverlay.CaptureToast)this.captureToasts.get(i);
            float ageMs = Math.max(0f, (float)(nowNanos - toast.shownAtNanos()) / 1000000f);
            float enter = this.clamp01(ageMs / 140f);
            float exit = this.clamp01((700f - ageMs) / 180f);
            float alpha = Math.min(this.easeOutCubic(enter), this.easeOutCubic(exit));
            if (alpha <= 0.001f) {
            } else {
                float scale = 0.9f + 0.1f * this.easeOutBack(enter);
                float offsetY = (1f - this.easeOutCubic(enter)) * -10f + (1f - exit) * 4f;
                int maxToastWidth = Math.min(anchorWidth, 260);
                String trimmed = PackUiText.trimToWidth(this.textRenderer, toast.message(), maxToastWidth - 14, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY));
                int textWidth = PackUiText.width(this.textRenderer, trimmed, this.theme.fontFor(PackUiTone.BODY), this.theme.color(PackUiTone.BODY));
                int toastWidth = Math.max(124, Math.min(maxToastWidth, textWidth + 18));
                int drawX = anchorX + Math.max(0, (anchorWidth - toastWidth) / 2);
                int drawY = Math.round((float)y + offsetY);
                int drawH = 18;
                float centerX = (float)drawX + (float)toastWidth / 2f;
                float centerY = (float)drawY + (float)drawH / 2f;
                context.method_51448().pushMatrix();
                context.method_51448().translate(centerX, centerY);
                context.method_51448().scale(scale, scale);
                context.method_51448().translate(-centerX, -centerY);
                int fill = PackUiRenderContext.applyAlpha(-703459308, alpha);
                int border = PackUiRenderContext.applyAlpha(toast.accentColor(), alpha);
                int highlight = PackUiRenderContext.applyAlpha(620756991, alpha);
                int textColor = PackUiRenderContext.applyAlpha(-723724, alpha);
                context.method_25294(drawX, drawY, drawX + toastWidth, drawY + drawH, fill);
                context.method_25294(drawX, drawY, drawX + toastWidth, drawY + 1, border);
                context.method_25294(drawX, drawY + drawH - 1, drawX + toastWidth, drawY + drawH, border);
                context.method_25294(drawX, drawY, drawX + 1, drawY + drawH, border);
                context.method_25294(drawX + toastWidth - 1, drawY, drawX + toastWidth, drawY + drawH, border);
                context.method_25294(drawX + 1, drawY + 1, drawX + toastWidth - 1, drawY + 2, highlight);
                int toastTextY = PackUiSizing.alignTextY(drawY, drawH, this.theme.fontHeight(PackUiTone.BODY), this.theme.bodyTextNudge());
                PackUiText.draw(context, this.textRenderer, trimmed, this.theme.fontFor(PackUiTone.BODY), textColor, drawX + 8, toastTextY, false);
                context.method_51448().popMatrix();
                y = y + (drawH + 4);
            }
        }
    }

    private float clamp01(float value) {
        return Math.max(0f, Math.min(1f, value));
    }

    private float easeOutCubic(float value) {
        float t = this.clamp01(value);
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    private float easeOutBack(float value) {
        float t = this.clamp01(value);
        float c1 = 1.70158f;
        float c3 = c1 + 1f;
        float x = t - 1f;
        return 1f + c3 * x * x * x + c1 * x * x;
    }

    private void flushToWorkingTag() {
        if (this.workingTag == null) {
            return;
        }
        if (this.itemAction != null) {
            if (this.itemEditIndex >= 0) {
                if (this.itemEditIndex < this.itemAction.itemNames.size()) {
                    this.applyItemEntryEditor();
                }
            }
            int i = false;
            L47: ;
            if (i < this.itemAction.itemNames.size()) {
                PackUtilChatField tf = (PackUtilChatField)this.textFields.get("item_times_" + i);
            }
        }
        try {
            while (this.itemAction.itemTimes.size() <= i) {
                this.itemAction.itemTimes.add(1);
            }
            this.itemAction.itemTimes.set(i, Math.max(1, Integer.parseInt(tf.getText().strip())));
        }
        catch (NumberFormatException af) {
            i++;
            /* goto @47; */
            L163: ;
            this.itemAction.waitForGui = ((Boolean)this.toggleStates.getOrDefault("item_waitForGui", false)).booleanValue();
            this.itemAction.waitForItem = ((Boolean)this.toggleStates.getOrDefault("item_waitForItem", false)).booleanValue();
            guiF = (PackUtilChatField)this.textFields.get("item_guiName");
            if (guiF != null) {
                this.itemAction.guiName = guiF.getText();
            }
            if (!this.itemAction.itemNames.isEmpty()) {
                this.itemAction.useSlot = false;
                this.itemAction.targetSlot = -1;
                this.itemAction.actionIndex = 0;
                this.itemAction.button = 0;
                this.itemAction.times = 1;
            }
            this.workingTag = this.itemAction.toTag();
            return;
        }
        i++;
        /* goto @47; */
        L163: ;
        this.itemAction.waitForGui = ((Boolean)this.toggleStates.getOrDefault("item_waitForGui", false)).booleanValue();
        this.itemAction.waitForItem = ((Boolean)this.toggleStates.getOrDefault("item_waitForItem", false)).booleanValue();
        guiF = (PackUtilChatField)this.textFields.get("item_guiName");
        if (guiF != null) {
            this.itemAction.guiName = guiF.getText();
        }
        if (!this.itemAction.itemNames.isEmpty()) {
            this.itemAction.useSlot = false;
            this.itemAction.targetSlot = -1;
            this.itemAction.actionIndex = 0;
            this.itemAction.button = 0;
            this.itemAction.times = 1;
        }
        this.workingTag = this.itemAction.toTag();
        return;
        L319: ;
        if (this.craftEntries != null) {
            i = false;
            L328: ;
            if (i < this.craftEntries.size()) {
                entry = (CraftAction.CraftEntry)this.craftEntries.get(i);
                af = (PackUtilChatField)this.textFields.get("craft_amount_" + i);
            }
        }
        try {
            entry.amount = Math.max(1, Integer.parseInt(af.getText().strip()));
        }
        catch (NumberFormatException sf) {
            entry.useMaxAmount = ((Boolean)this.toggleStates.getOrDefault("craft_useMax_" + i, false)).booleanValue();
            i++;
            /* goto @328; */
            L436: ;
            entryTags = new class_2499();
            f = this.craftEntries.iterator();
            while (f.hasNext()) {
                entry = (CraftAction.CraftEntry)f.next();
                if (!entry.hasRecipe()) continue;
                entryTags.add(entry.toTag());
            }
        }
        entry.useMaxAmount = ((Boolean)this.toggleStates.getOrDefault("craft_useMax_" + i, false)).booleanValue();
        i++;
        /* goto @328; */
        L436: ;
        entryTags = new class_2499();
        f = this.craftEntries.iterator();
        while (f.hasNext()) {
            entry = (CraftAction.CraftEntry)f.next();
            if (!entry.hasRecipe()) continue;
            entryTags.add(entry.toTag());
        }
        this.workingTag.method_10566("entries", entryTags);
        return;
        L505: ;
        if (this.dropAction != null) {
            if (this.dropEditIndex >= 0) {
                if (this.dropEditIndex < this.dropAction.itemNames.size()) {
                    this.applyDropEntryEditor();
                }
            }
            i = false;
            L544: ;
            if (i < this.dropAction.itemNames.size()) {
                f = (PackUtilChatField)this.textFields.get("drop_count_" + i);
            }
        }
        try {
            this.dropAction.itemCounts.set(i, Math.max(0, Integer.parseInt(f.getText().strip())));
        }
        catch (NumberFormatException guiF) {
            i++;
            /* goto @544; */
            while (this.dropAction.itemCounts.size() < this.dropAction.itemNames.size()) {
                this.dropAction.itemCounts.add(1);
            }
        }
        i++;
        /* goto @544; */
        while (this.dropAction.itemCounts.size() < this.dropAction.itemNames.size()) {
            this.dropAction.itemCounts.add(1);
        }
        cntF = (PackUtilChatField)this.textFields.get("drop_globalCount");
        try {
            this.dropAction.dropCount = Math.max(1, Integer.parseInt(cntF.getText().strip()));
        }
        catch (NumberFormatException modes) {
            modes = DropAction.DropMode.values();
            this.dropAction.mode = modes[Math.min(((Integer)this.enumIndices.getOrDefault("drop_mode", 0)).intValue(), modes.length - 1)];
            this.dropAction.waitForGui = ((Boolean)this.toggleStates.getOrDefault("drop_waitForGui", false)).booleanValue();
            this.dropAction.useHandlerSlots = true;
            guiF = (PackUtilChatField)this.textFields.get("drop_guiName");
            if (guiF != null) {
                this.dropAction.guiName = guiF.getText();
            }
            this.workingTag = this.dropAction.toTag();
            return;
        }
        modes = DropAction.DropMode.values();
        this.dropAction.mode = modes[Math.min(((Integer)this.enumIndices.getOrDefault("drop_mode", 0)).intValue(), modes.length - 1)];
        this.dropAction.waitForGui = ((Boolean)this.toggleStates.getOrDefault("drop_waitForGui", false)).booleanValue();
        this.dropAction.useHandlerSlots = true;
        guiF = (PackUtilChatField)this.textFields.get("drop_guiName");
        if (guiF != null) {
            this.dropAction.guiName = guiF.getText();
        }
        this.workingTag = this.dropAction.toTag();
        return;
        L838: ;
        if (this.lanStepEntries != null) {
            i = false;
            L847: ;
            if (i < this.lanStepEntries.size()) {
                e = (WaitForLanStepAction.LanStepEntry)this.lanStepEntries.get(i);
                uf = (PackUtilChatField)this.textFields.get("lan_user_" + i);
                if (uf != null) {
                    e.username = uf.getText();
                }
                sf = (PackUtilChatField)this.textFields.get("lan_step_" + i);
            }
        }
        try {
            e.step = Math.max(1, Integer.parseInt(sf.getText().strip()));
        }
        catch (NumberFormatException idx) {
            i++;
            /* goto @847; */
            L960: ;
            entryList = new class_2499();
            dsF = this.lanStepEntries.iterator();
            while (dsF.hasNext()) {
                e = (WaitForLanStepAction.LanStepEntry)dsF.next();
                entryList.add(e.toTag());
            }
        }
        i++;
        /* goto @847; */
        L960: ;
        entryList = new class_2499();
        dsF = this.lanStepEntries.iterator();
        while (dsF.hasNext()) {
            e = (WaitForLanStepAction.LanStepEntry)dsF.next();
            entryList.add(e.toTag());
        }
        this.workingTag.method_10566("entries", entryList);
        this.workingTag.method_10556("filterByUser", ((Boolean)this.toggleStates.getOrDefault("lan_filterByUser", false)).booleanValue());
        dsF = (PackUtilChatField)this.textFields.get("lan_defaultStep");
        try {
            this.workingTag.method_10569("defaultStep", Math.max(1, Integer.parseInt(dsF.getText().strip())));
        }
        catch (NumberFormatException entry) {
            if (this.toggleModuleEntries == null) { /* goto @1220; */ }
            entriesTag = new class_2499();
            packetList = this.toggleModuleEntries.iterator();
            while (packetList.hasNext()) {
                entry = (ToggleModuleAction.ModuleEntry)packetList.next();
                if (entry != null) {
                    if (entry.moduleName != null) {
                        if (entry.moduleName.isBlank()) continue;
                        entriesTag.add(entry.toTag());
                    }
                }
            }
        }
        if (this.toggleModuleEntries == null) { /* goto L1220; */ }
        entriesTag = new class_2499();
        packetList = this.toggleModuleEntries.iterator();
        while (packetList.hasNext()) {
            entry = (ToggleModuleAction.ModuleEntry)packetList.next();
            if (entry != null) {
                if (entry.moduleName != null) {
                    if (entry.moduleName.isBlank()) continue;
                    entriesTag.add(entry.toTag());
                }
            }
        }
        this.workingTag.method_10566("entries", entriesTag);
        this.workingTag.method_10582("moduleName", "");
        this.workingTag.method_10582("toggleMode", ToggleModuleAction.ToggleMode.TOGGLE.name());
        return;
        L1220: ;
        if (this.targetAction == null) { /* goto L1347; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_PACKET) { /* goto L1347; */ }
        targets = this.sanitizeWaitPacketTargets(this.getOrCreateWaitPacketTargets());
        packetList = new class_2499();
        key = targets.iterator();
        while (key.hasNext()) {
            target = (String)key.next();
            packetList.add(class_2519.method_23256(target));
        }
        this.workingTag.method_10566("packetNames", packetList);
        this.workingTag.method_10582("packetName", targets.isEmpty() ? "" : (String)targets.get(0));
        return;
        if (this.schema == null) {
            return;
        }
        mode = this.schema.fields().iterator();
        L1368: ;
        if (!mode.hasNext()) { /* goto @1890; */ }
        field = (FieldDef)mode.next();
        key = field.key();
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$gui$macro$editor$FieldType[field.type().ordinal()]) {
            case 1::
                this.workingTag.method_10556(key, ((Boolean)this.toggleStates.getOrDefault(key, false)).booleanValue());
                /* goto @1887; */
            case 2::
            case 6::
                f = (PackUtilChatField)this.textFields.get(key);
                try {
                    this.workingTag.method_10569(key, Integer.parseInt(f.getText().strip()));
                }
                catch (NumberFormatException idx) {
                    /* goto @1887; */
                }
                /* goto @1887; */
            case 3::
                f = (PackUtilChatField)this.textFields.get(key);
                try {
                    this.workingTag.method_10549(key, Double.parseDouble(f.getText().strip()));
                }
                catch (NumberFormatException idx) {
                    /* goto @1887; */
                }
                /* goto @1887; */
            case 4::
                f = (PackUtilChatField)this.textFields.get(key);
                if (f != null) {
                    this.workingTag.method_10582(key, f.getText());
                }
                /* goto @1887; */
            case 5::
                opts = field.enumOptions();
                if (!opts.isEmpty()) {
                    idx = Math.min(((Integer)this.enumIndices.getOrDefault(key, 0)).intValue(), opts.size() - 1);
                    this.workingTag.method_10582(key, (String)opts.get(idx));
                }
                /* goto @1887; */
            case 7::
                xyzKeys = field.xyzKeys();
                dbl = field.xyzDouble();
                int i = 0;
                L1697: ;
                if (i >= 3) { /* goto @1801; */ }
                PackUtilChatField f = (PackUtilChatField)this.textFields.get(key + "_" + i);
                if (f == null) {
                } else {
                    String t = f.getText().strip();
                }
                try {
                    this.workingTag.method_10549(xyzKeys[i], Double.parseDouble(t));
                }
                catch (NumberFormatException e9) {
                    /* goto @1795; */
                }
                try {
                    this.workingTag.method_10569(xyzKeys[i], Integer.parseInt(t));
                }
                catch (NumberFormatException e9) {
                    i++;
                    /* goto @1697; */
                    L1801: ;
                    /* goto @1887; */
                }
                i++;
                /* goto @1697; */
                L1801: ;
                /* goto @1887; */
            case 8::
                items = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
                nbt = new class_2499();
                i = items.iterator();
                while (i.hasNext()) {
                    s = (String)i.next();
                    nbt.add(class_2519.method_23256(s));
                }
                this.workingTag.method_10566(key, nbt);
            default:
        }
        try {
            this.workingTag.method_10569(key, Integer.parseInt(f.getText().strip()));
        }
        catch (NumberFormatException idx) {
            /* goto @1887; */
        }
        /* goto @1887; */
        L1526: ;
        f = (PackUtilChatField)this.textFields.get(key);
        try {
            this.workingTag.method_10549(key, Double.parseDouble(f.getText().strip()));
        }
        catch (NumberFormatException idx) {
            /* goto @1887; */
        }
        /* goto @1887; */
        L1573: ;
        f = (PackUtilChatField)this.textFields.get(key);
        if (f != null) {
            this.workingTag.method_10582(key, f.getText());
        }
        /* goto @1887; */
        L1609: ;
        opts = field.enumOptions();
        if (!opts.isEmpty()) {
            idx = Math.min(((Integer)this.enumIndices.getOrDefault(key, 0)).intValue(), opts.size() - 1);
            this.workingTag.method_10582(key, (String)opts.get(idx));
        }
        /* goto @1887; */
        L1682: ;
        xyzKeys = field.xyzKeys();
        dbl = field.xyzDouble();
        i = 0;
        L1697: ;
        if (i >= 3) { /* goto @1801; */ }
        f = (PackUtilChatField)this.textFields.get(key + "_" + i);
        if (f == null) {
        } else {
            t = f.getText().strip();
        }
        try {
            this.workingTag.method_10549(xyzKeys[i], Double.parseDouble(t));
        }
        catch (NumberFormatException e9) {
            /* goto @1795; */
        }
        try {
            this.workingTag.method_10569(xyzKeys[i], Integer.parseInt(t));
        }
        catch (NumberFormatException e9) {
            i++;
            /* goto @1697; */
            L1801: ;
            /* goto @1887; */
        }
        i++;
        /* goto @1697; */
        L1801: ;
        /* goto L1887; */
        L1804: ;
        items = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
        nbt = new class_2499();
        i = items.iterator();
        while (i.hasNext()) {
            s = (String)i.next();
            nbt.add(class_2519.method_23256(s));
        }
        this.workingTag.method_10566(key, nbt);
        L1887: ;
        /* goto @1368; */
        L1890: ;
        this.rewriteStructuredEditorTargets();
        if (this.targetAction == null) { /* goto L1998; */ }
        if (this.targetAction.getType() != MacroActionType.INVENTORY) { /* goto L1998; */ }
        mode = this.currentEnumValue("mode");
        if ("CLOSE".equals(mode)) {
            this.workingTag.method_10556("waitForGui", false);
        }
        this.workingTag.method_10582("guiName", "");
        this.workingTag.method_10556("sendPacket", !((Boolean)this.toggleStates.getOrDefault("sendPacket", false)).booleanValue());
        if (this.targetAction == null) { /* goto L2162; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_SLOT_CHANGE) { /* goto L2162; */ }
        nbtEntries = new class_2499();
        if (this.wscEntries == null) { /* goto L2150; */ }
        toUseItemName = this.wscEntries.iterator();
        while (toUseItemName.hasNext()) {
            e = (WaitForSlotChangeAction.WaitEntry)toUseItemName.next();
            ec = new class_2487();
            target = e.resolvedTarget();
            if (!target.hasSlot() || target.hasIdentity()) continue;
            ec.method_10566("target", target.toTag());
            ec.method_10582("mode", e.waitMode.name());
            ec.method_10569("count", Math.max(1, e.targetCount));
            nbtEntries.add(ec);
        }
        this.workingTag.method_10566("entries", nbtEntries);
        L2162: ;
        if (this.targetAction == null) { /* goto L2273; */ }
        if (this.targetAction.getType() != MacroActionType.USE_ITEM) { /* goto L2273; */ }
        mode = this.workingTag.method_68564("useMode", "AUTOMATIC");
        if ("CUSTOM_HOLD".equals(mode)) {
            this.workingTag.method_10569("useCount", 1);
            if (this.workingTag.method_68083("holdTicks", 0) <= 0) {
                this.workingTag.method_10569("holdTicks", 20);
            }
        } else {
            if (this.workingTag.method_68083("useCount", 0) <= 0) {
                this.workingTag.method_10569("useCount", 1);
            }
        }
        if (this.targetAction == null) { /* goto L2381; */ }
        if (this.targetAction.getType() != MacroActionType.SWAP_SLOTS) { /* goto L2381; */ }
        fromUseItemName = this.workingTag.method_68566("fromUseItemName", false);
        toUseItemName = this.workingTag.method_68566("toUseItemName", false);
        if (fromUseItemName) {
            this.workingTag.method_10569("fromSlot", -1);
        } else {
            this.workingTag.method_10582("fromItemName", "");
        }
        if (toUseItemName) {
            this.workingTag.method_10569("toSlot", -1);
        } else {
            this.workingTag.method_10582("toItemName", "");
        }
        this.workingTag.method_10549("arrivalRadius", 2);
        if (this.targetAction != null && this.targetAction.getType() == MacroActionType.GO_TO && !this.workingTag.method_68566("waitForArrival", false)) {
            this.workingTag.method_10569("timeoutMs", 60000);
        }
        if (this.targetAction != null) {
            if (this.targetAction.getType() == MacroActionType.CLICK) {
                if (!this.workingTag.method_68566("waitForGui", false)) {
                    this.workingTag.method_10582("guiName", "");
                }
                if ("MIDDLE".equals(this.workingTag.method_68564("clickType", "RIGHT"))) {
                    this.workingTag.method_10582("clickType", "RIGHT");
                }
                if (this.workingTag.method_68083("clickCount", 0) <= 0) {
                    this.workingTag.method_10569("clickCount", 1);
                }
            }
        }
        if (this.targetAction == null) { /* goto L2660; */ }
        if (this.targetAction.getType() != MacroActionType.DISCONNECT) { /* goto L2660; */ }
        mode = this.workingTag.method_68564("mode", "DISCONNECT");
        if ("DISCONNECT".equals(mode)) {
            this.workingTag.method_10556("useNextAction", false);
        } else {
            if (this.workingTag.method_68083("packetCount", 0) <= 0) {
                this.workingTag.method_10569("packetCount", 200);
            }
        }
        if (!"KICK_DUPE".equals(mode)) {
            this.workingTag.method_10556("useNextAction", false);
        }
        if (this.targetAction == null) { /* goto L2722; */ }
        if (this.targetAction.getType() != MacroActionType.CLOSE_GUI) { /* goto L2722; */ }
        this.workingTag.method_10556("sendPacket", !((Boolean)this.toggleStates.getOrDefault("sendPacket", false)).booleanValue());
        if (this.targetAction == null) { /* goto L2784; */ }
        if (this.targetAction.getType() != MacroActionType.SAVE_GUI) { /* goto L2784; */ }
        this.workingTag.method_10556("sendPacket", !((Boolean)this.toggleStates.getOrDefault("sendPacket", false)).booleanValue());
        if (this.targetAction == null) { /* goto L2846; */ }
        if (this.targetAction.getType() != MacroActionType.STORE_ITEM) { /* goto L2846; */ }
        this.workingTag.method_10556("closeSendPkt", !((Boolean)this.toggleStates.getOrDefault("closeSendPkt", false)).booleanValue());
        if (this.targetAction == null) { /* goto L2937; */ }
        if (this.targetAction.getType() != MacroActionType.OPEN_CONTAINER) { /* goto L2937; */ }
        this.workingTag.method_10582("guiName", "");
        selectedTargets = (List)this.stringLists.getOrDefault("entityTargets", Collections.emptyList());
        entityTarget = selectedTargets.isEmpty() ? "" : (String)selectedTargets.get(0);
        this.workingTag.method_10582("entityTarget", entityTarget);
        L2937: ;
        if (this.targetAction != null) {
            if (this.targetAction.getType() == MacroActionType.WAIT_CHAT) {
                this.workingTag.method_10569("fuzzyPercent", WaitForChatAction.clampFuzzyPercent(this.getWaitChatFuzzyPercent()));
                if (!this.workingTag.method_68566("waitForGui", false)) {
                    this.workingTag.method_10582("waitGuiName", "");
                }
            }
        }
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (!this.visible) {
            return false;
        }
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.mouseClicked(mx, my, button);
        }
        int imx = (int)mx;
        int imy = (int)my;
        if (this.isOverCloseButton(mx, my, this.getBounds())) {
            this.closeEditor(false);
            return true;
        }
        if (this.isOverDragBar(mx, my)) {
            this.dragging = true;
            this.dragOffX = mx - (double)this.panelX;
            this.dragOffY = my - (double)this.panelY;
            PackUtilOverlayManager.get().bringToFront(this);
            return true;
        }
        if (!this.isMouseOver(mx, my)) {
            return false;
        }
        PackUtilOverlayManager.get().bringToFront(this);
        class_11910 mi = new class_11910(button, 0);
        class_11909 click = new class_11909((double)imx, (double)imy, mi);
        PackUtilChatField focused = null;
        PackUtilChatField ff = this.textFields.entrySet().iterator();
        while (ff.hasNext()) {
            Map.Entry<String, PackUtilChatField> entry = (Map.Entry)ff.next();
            String baseKey = ((String)entry.getKey()).replaceAll("_\\d+$", "");
            FieldDef fld = this.getField(baseKey);
            while (fld != null) {
                if (this.isFieldVisible(fld)) break;
            }
            if (!((PackUtilChatField)entry.getValue()).mouseClicked(click, false)) { /* goto @272; */ }
            focused = (PackUtilChatField)entry.getValue();
            break;
        }
        if (focused != null) { /* goto L388; */ }
        ff = this.addFields.entrySet().iterator();
        while (ff.hasNext()) {
            entry = (Map.Entry)ff.next();
            fld = this.getField((String)entry.getKey());
            while (fld != null) {
                if (this.isFieldVisible(fld)) break;
            }
            if (!((PackUtilChatField)entry.getValue()).mouseClicked(click, false)) { /* goto @385; */ }
            focused = (PackUtilChatField)entry.getValue();
            break;
        }
        if (focused != null) {
            ff = focused;
            this.textFields.values().forEach(ActionEditorOverlay::lambda$mouseClicked$93 /* captured: ff */);
            this.addFields.values().forEach(ActionEditorOverlay::lambda$mouseClicked$94 /* captured: ff */);
            return true;
        }
        this.clearTextFieldFocus();
        this.waitChatFuzzySliderDragging = true;
        if (button == 0 && this.isOverWaitChatFuzzySlider(imx, imy)) {
            this.updateWaitChatFuzzyPercentFromMouse(imx);
            return true;
        }
        this.rotateSmoothnessSliderDragging = true;
        if (button == 0 && this.isOverRotateSmoothnessSlider(imx, imy)) {
            this.updateRotateSmoothnessFromMouse(imx);
            return true;
        }
        ff = this.selectedScrollViewports.values().iterator();
        while (ff.hasNext()) {
            vp = (PackUiScrollViewport)ff.next();
            if (vp.isScrollbarHovered(mx, my)) {
                vp.mouseClicked(mx, my, button);
                return true;
            }
        }
        ff = this.catalogScrollViewports.values().iterator();
        while (ff.hasNext()) {
            vp = (PackUiScrollViewport)ff.next();
            if (vp.isScrollbarHovered(mx, my)) {
                vp.mouseClicked(mx, my, button);
                return true;
            }
        }
        ff = this.scrollDragRegions.iterator();
        while (ff.hasNext()) {
            r = (ActionEditorOverlay.ScrollDragRegion)ff.next();
            if (r.contains(imx, imy)) {
                this.activeScrollDragHandler = r.handler();
                this.activeScrollDragHandler.accept(imy);
                return true;
            }
        }
        ff = this.hitRegions.iterator();
        while (ff.hasNext()) {
            r = (ActionEditorOverlay.HitRegion)ff.next();
            if (r.contains(imx, imy)) {
                if (r.fire(mx, my, button)) {
                    this.refreshInteractiveLayout();
                    return true;
                }
            }
        }
        return true;
    }

    public boolean mouseReleased(double mx, double my, int button) {
        if (this.packetSelectorOverlay.isVisible() && this.packetSelectorOverlay.mouseReleased(mx, my, button)) {
            return true;
        }
        boolean consumed = false;
        var var7 = this.selectedScrollViewports.values().iterator();
        while (var7.hasNext()) {
            PackUiScrollViewport vp = (PackUiScrollViewport)var7.next();
            if (vp.isScrollbarDragging()) {
                vp.mouseReleased();
                consumed = true;
            }
        }
        var7 = this.catalogScrollViewports.values().iterator();
        while (var7.hasNext()) {
            vp = (PackUiScrollViewport)var7.next();
            if (vp.isScrollbarDragging()) {
                vp.mouseReleased();
                consumed = true;
            }
        }
        if (this.activeScrollDragHandler != null) {
            this.activeScrollDragHandler = null;
            consumed = true;
        }
        if (this.waitChatFuzzySliderDragging) {
            this.waitChatFuzzySliderDragging = false;
            consumed = true;
        }
        if (this.rotateSmoothnessSliderDragging) {
            this.rotateSmoothnessSliderDragging = false;
            consumed = true;
        }
        if (this.dragging) {
            this.dragging = false;
            consumed = true;
        }
        return consumed;
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (this.packetSelectorOverlay.isVisible() && this.packetSelectorOverlay.mouseDragged(mx, my, button, dx, dy)) {
            return true;
        }
        if (this.waitChatFuzzySliderDragging) {
            this.updateWaitChatFuzzyPercentFromMouse((int)mx);
            return true;
        }
        if (this.rotateSmoothnessSliderDragging) {
            this.updateRotateSmoothnessFromMouse((int)mx);
            return true;
        }
        if (this.dragging) {
            this.panelX = (int)(mx - this.dragOffX);
            this.panelY = (int)(my - this.dragOffY);
            PackUtilWindowLayout c = this.clampToScreen(this);
            this.panelX = c.x;
            this.panelY = c.y;
            return true;
        }
        c = this.selectedScrollViewports.values().iterator();
        while (c.hasNext()) {
            PackUiScrollViewport vp = (PackUiScrollViewport)c.next();
            if (vp.isScrollbarDragging()) {
                vp.mouseDragged(mx, my);
                return true;
            }
        }
        c = this.catalogScrollViewports.values().iterator();
        while (c.hasNext()) {
            vp = (PackUiScrollViewport)c.next();
            if (vp.isScrollbarDragging()) {
                vp.mouseDragged(mx, my);
                return true;
            }
        }
        if (this.activeScrollDragHandler != null) {
            this.activeScrollDragHandler.accept((int)my);
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mx, double my, double amount) {
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.mouseScrolled(mx, my, amount);
        }
        if (!this.visible || !this.isMouseOver(mx, my)) {
            return false;
        }
        var var7 = this.selectedScrollViewports.entrySet().iterator();
        while (var7.hasNext()) {
            Map.Entry<String, PackUiScrollViewport> entry = (Map.Entry)var7.next();
            PackUiScrollViewport vp = (PackUiScrollViewport)entry.getValue();
            if (vp.contains(mx, my)) {
                vp.mouseScrolled(mx, my, amount);
                return true;
            }
        }
        var7 = this.catalogScrollViewports.entrySet().iterator();
        while (var7.hasNext()) {
            entry = (Map.Entry)var7.next();
            vp = (PackUiScrollViewport)entry.getValue();
            if (vp.contains(mx, my)) {
                vp.mouseScrolled(mx, my, amount);
                return true;
            }
        }
        this.craftRecipeScrollOffset = Math.max(0, this.craftRecipeScrollOffset - (int)(amount * 13));
        if (this.craftRecipeListBounds != null && my >= (double)this.craftRecipeListBounds[0] && my < (double)(this.craftRecipeListBounds[0] + this.craftRecipeListBounds[1])) {
            return true;
        }
        this.scrollOffset = Math.max(0, this.scrollOffset - (int)(amount * 12));
        return true;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.keyPressed(keyCode, scanCode, modifiers);
        }
        if (keyCode == 256) {
            if (this.cancelCaptureIfActive()) {
                return true;
            }
            if (this.hasTextFieldFocused()) {
                this.clearTextFieldFocus();
                return true;
            }
            this.closeEditor(false);
            return true;
        }
        class_11908 ki = new class_11908(keyCode, scanCode, modifiers);
        var var5 = this.textFields.values().iterator();
        while (var5.hasNext()) {
            PackUtilChatField f = (PackUtilChatField)var5.next();
            if (f.isFocused()) {
                f.keyPressed(ki);
                return true;
            }
        }
        var5 = this.addFields.values().iterator();
        while (var5.hasNext()) {
            f = (PackUtilChatField)var5.next();
            if (f.isFocused()) {
                f.keyPressed(ki);
                return true;
            }
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        if (!this.visible) {
            return false;
        }
        if (this.packetSelectorOverlay.isVisible()) {
            return this.packetSelectorOverlay.charTyped(chr, modifiers);
        }
        class_11905 ci = new class_11905(chr, modifiers);
        var var4 = this.textFields.values().iterator();
        while (var4.hasNext()) {
            PackUtilChatField f = (PackUtilChatField)var4.next();
            if (f.isFocused()) {
                if (!f.charTyped(ci)) continue;
                return true;
            }
        }
        var4 = this.addFields.values().iterator();
        while (var4.hasNext()) {
            f = (PackUtilChatField)var4.next();
            if (f.isFocused()) {
                if (!f.charTyped(ci)) continue;
                return true;
            }
        }
        return false;
    }

    private boolean isFieldVisible(FieldDef field) {
        if (this.targetAction != null) {
            if (this.targetAction.getType() == MacroActionType.INVENTORY) {
                String mode = this.currentEnumValue("mode");
                if ("waitForGui".equals(field.key()) || "guiName".equals(field.key())) {
                    return "OPEN".equals(mode);
                }
                if ("sendPacket".equals(field.key())) {
                    return "CLOSE".equals(mode);
                }
            }
        }
        if (this.targetAction == null) { /* goto L216; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_ENTITY) { /* goto L216; */ }
        checkMode = this.currentEnumValue("checkMode");
        if ("centerOnPlayer".equals(field.key()) || "radius".equals(field.key()) || "mustBeLookingAt".equals(field.key())) {
            return "RADIUS".equals(checkMode);
        }
        if (!"pos".equals(field.key())) { /* goto L216; */ }
        return "RADIUS".equals(checkMode) && !((Boolean)this.toggleStates.getOrDefault("centerOnPlayer", false)).booleanValue();
        if (this.targetAction == null) { /* goto L471; */ }
        if (this.targetAction.getType() != MacroActionType.INVENTORY_AUDIT) { /* goto L471; */ }
        mode = this.currentEnumValue("mode");
        String openMode = this.currentEnumValue("openMode");
        boolean isDupeMode = "DUPE".equals(mode) || "DUPE_SPAM".equals(mode);
        boolean isDupeSpam = "DUPE_SPAM".equals(mode);
        if ("targetItems".equals(field.key())) {
            return isDupeMode;
        }
        if (!"openCommand".equals(field.key())) { /* goto L340; */ }
        return isDupeMode && "COMMAND".equals(openMode);
        if (!"containerPos".equals(field.key())) { /* goto L374; */ }
        return isDupeMode && "CONTAINER".equals(openMode);
        if ("spamCount".equals(field.key()) || "spamDelayMs".equals(field.key())) {
            return isDupeSpam;
        }
        if ("openMode".equals(field.key()) || "dupeVector".equals(field.key()) || "iterations".equals(field.key()) || "maxTransferAttempts".equals(field.key()) || "transferRetryDelayMs".equals(field.key())) {
            return isDupeMode;
        }
        if (!field.hasShowWhen()) {
            return true;
        }
        if (field.showWhenValue() != null) {
            if (field.showWhenValue().isEmpty()) { /* goto @565; */ }
            currentValue = this.currentEnumValue(field.showWhenKey());
            cond = false;
            dep = field.showWhenValue().split("\\|");
            isDupeSpam = dep.length;
            int var6 = 0;
            while (var6 < isDupeSpam) {
                String allowed = dep[var6];
                if (allowed.equals(currentValue)) {
                    cond = true;
                } else {
                    var6++;
                }
            }
        } else {
            cond = ((Boolean)this.toggleStates.getOrDefault(field.showWhenKey(), false)).booleanValue();
        }
        visible = field.showWhenInverted() ? !cond : cond;
        if (visible) {
            if (!field.showWhenInverted()) {
                dep = this.getField(field.showWhenKey());
                if (dep != null) {
                    if (!this.isFieldVisible(dep)) {
                        visible = false;
                    }
                }
            }
        }
        return visible;
    }

    private String currentEnumValue(String key) {
        if (this.schema == null) {
            return "";
        }
        var var2 = this.schema.fields().iterator();
        L24: ;
        if (!var2.hasNext()) { /* goto L134; */ }
        FieldDef field = (FieldDef)var2.next();
        if (!field.key().equals(key)) { /* goto L24; */ }
        while (field.type() != FieldType.ENUM) {
        }
        List<String> opts = field.enumOptions();
        if (opts.isEmpty()) {
            return "";
        }
        int idx = Math.min(((Integer)this.enumIndices.getOrDefault(key, 0)).intValue(), opts.size() - 1);
        return (String)opts.get(idx);
        L134: ;
        return "";
    }

    private void prepareWorkingTagForEditor(MacroAction action) {
        if (action == null || this.workingTag == null) {
            return;
        }
        if (action instanceof SelectSlotAction) {
            SelectSlotAction selectSlotAction = (SelectSlotAction)action;
            this.primeStructuredField("itemName", selectSlotAction.itemTarget, selectSlotAction.itemName, null);
        }
        if (action instanceof UseItemAction) {
            useItemAction = (UseItemAction)action;
            this.primeStructuredField("itemName", useItemAction.itemTarget, useItemAction.itemName, null);
        }
        if (action instanceof WaitForCooldownAction) {
            waitForCooldownAction = (WaitForCooldownAction)action;
            this.primeStructuredField("itemName", waitForCooldownAction.itemTarget, waitForCooldownAction.itemName, null);
        }
        if (action instanceof CloseGuiAction) {
            closeGuiAction = (CloseGuiAction)action;
            this.primeStructuredField("itemName", closeGuiAction.itemTarget, closeGuiAction.itemName, "targetSlot");
        }
        if (action instanceof SwapSlotsAction) {
            swapSlotsAction = (SwapSlotsAction)action;
            this.primeStructuredField("fromItemName", swapSlotsAction.fromItemTarget, swapSlotsAction.fromItemName, null);
            this.primeStructuredField("toItemName", swapSlotsAction.toItemTarget, swapSlotsAction.toItemName, null);
        }
        if (action instanceof StoreItemAction) {
            storeItemAction = (StoreItemAction)action;
            this.primeStructuredList("targetItems", storeItemAction.itemTargets, storeItemAction.targetItems);
        }
        if (action instanceof XCarryAction) {
            xCarryAction = (XCarryAction)action;
            this.primeStructuredList("entries", xCarryAction.entryTargets, xCarryAction.entries);
        }
        if (action instanceof InventoryAuditAction) {
            inventoryAuditAction = (InventoryAuditAction)action;
            this.primeStructuredList("targetItems", inventoryAuditAction.itemTargets, inventoryAuditAction.targetItems);
        }
    }

    private void primeStructuredField(String key, ItemTarget source, String legacyValue, String slotKey) {
        ItemTarget resolved = this.resolveEditorTarget(source, legacyValue);
        if (!resolved.hasSlot() && !resolved.hasIdentity()) {
            return;
        }
        this.editorItemFields.put(key, resolved.copy());
        this.workingTag.method_10582(key, resolved.editorText());
        if (slotKey != null) {
            if (resolved.hasSlot()) {
                this.workingTag.method_10569(slotKey, resolved.slot);
            }
        }
    }

    private void refreshItemTextDisplayProviders() {
        this.bindStructuredItemFieldDisplay("itemName");
        this.bindStructuredItemFieldDisplay("fromItemName");
        this.bindStructuredItemFieldDisplay("toItemName");
        this.bindTransientItemEditorDisplay("_item_add");
        this.bindTransientItemEditorDisplay("_drop_add");
        this.bindTransientItemEditorDisplay("_wsc_add");
    }

    private void bindStructuredItemFieldDisplay(String key) {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get(key);
        if (field == null) {
            return;
        }
        field.setDisplayTextProvider(this::lambda$bindStructuredItemFieldDisplay$95 /* captured: key */);
    }

    private void bindTransientItemEditorDisplay(String key) {
        PackUtilChatField field = (PackUtilChatField)this.addFields.get(key);
        if (field == null) {
            return;
        }
        field.setDisplayTextProvider(this::lambda$bindTransientItemEditorDisplay$96 /* captured: key */);
    }

    private class_2561 resolveStructuredItemFieldDisplay(String key, String value) {
        return this.richItemFieldDisplay((ItemTarget)this.editorItemFields.get(key), value);
    }

    private class_2561 resolveTransientItemEditorDisplay(String key, String value) {
        var var3 = key;
        int var4 = -1;
        switch (var3.hashCode()) {
            case 1268355796::
                if (!var3.equals("_item_add")) { /* goto @89; */ }
                var4 = 0;
                /* goto @89; */
            case -341706576::
                if (!var3.equals("_drop_add")) { /* goto @89; */ }
                var4 = 1;
                /* goto @89; */
            case -311279574::
                if (var3.equals("_wsc_add")) {
                    var4 = 2;
                }
            default:
                switch (var4) {
                    case 0::
                        return this.richItemFieldDisplay(this.itemAction != null && this.itemEditIndex >= 0 && this.itemEditIndex < this.itemAction.itemNames.size() ? this.targetAt(this.itemAction.itemTargets, this.itemAction.itemNames, this.itemEditIndex) : null, value);
                    case 1::
                        return this.richItemFieldDisplay(this.dropAction != null && this.dropEditIndex >= 0 && this.dropEditIndex < this.dropAction.itemNames.size() ? this.targetAt(this.dropAction.itemTargets, this.dropAction.itemNames, this.dropEditIndex) : null, value);
                    case 2::
                        return this.richItemFieldDisplay(this.wscEntries != null && this.wscEditIndex >= 0 && this.wscEditIndex < this.wscEntries.size() ? ((WaitForSlotChangeAction.WaitEntry)this.wscEntries.get(this.wscEditIndex)).resolvedTarget() : null, value);
                    default:
                        return null;
                }
        }
    }

    private class_2561 richItemFieldDisplay(ItemTarget target, String value) {
        if (target == null) {
            return null;
        }
        class_2561 rich = target.displayComponent();
        if (rich == null) {
            return null;
        }
        String safeValue = value == null ? "" : value;
        return safeValue.equals(rich.getString()) ? rich.method_27661() : null;
    }

    private void primeStructuredList(String key, List<ItemTarget> source, List<String> legacyValues) {
        List<ItemTarget> resolved = this.copyEditorTargets(source, legacyValues);
        if (resolved.isEmpty()) {
            return;
        }
        this.editorItemLists.put(key, ItemTarget.copyList(resolved));
        class_2499 listTag = new class_2499();
        var var6 = resolved.iterator();
        while (var6.hasNext()) {
            ItemTarget target = (ItemTarget)var6.next();
            while (target == null) {
            }
            String entry = target.toLegacyEntry();
            if (entry.isBlank()) continue;
            listTag.add(class_2519.method_23256(entry));
        }
        this.workingTag.method_10566(key, listTag);
    }

    private ItemTarget resolveEditorTarget(ItemTarget source, String legacyValue) {
        if (source != null) {
            if (source.hasSlot() || source.hasIdentity()) {
                return source.copy();
            }
        }
        return ItemTarget.fromLegacyEntry(legacyValue);
    }

    private List<ItemTarget> copyEditorTargets(List<ItemTarget> source, List<String> legacyValues) {
        List<ItemTarget> resolved = ItemTarget.copyList(source);
        if (!resolved.isEmpty()) {
            return resolved;
        }
        List<ItemTarget> parsed = new ArrayList();
        if (legacyValues == null) {
            return parsed;
        }
        var var5 = legacyValues.iterator();
        while (var5.hasNext()) {
            String legacyValue = (String)var5.next();
            ItemTarget target = ItemTarget.fromLegacyEntry(legacyValue);
            if (!target.hasSlot() || target.hasIdentity()) continue;
            parsed.add(target);
        }
        return parsed;
    }

    private ItemTarget buildStructuredFieldTarget(String key, String slotKey) {
        PackUtilChatField valueField = (PackUtilChatField)this.textFields.get(key);
        String text = valueField == null ? "" : valueField.getText().strip();
        ItemTarget previous = (ItemTarget)this.editorItemFields.get(key);
        int slot = -1;
        boolean slotDriven = false;
        if (slotKey != null) {
            PackUtilChatField slotField = (PackUtilChatField)this.textFields.get(slotKey);
            slot = slotField == null ? -1 : this.parseHandlerSlotField(slotField.getText(), -1);
            slotDriven = true;
        } else {
            if (previous != null) {
                if (previous.hasSlot()) {
                    slot = previous.slot;
                }
            }
        }
        if (text.isEmpty()) {
            if (!slotDriven || slot < 0) {
                return new ItemTarget();
            }
        }
        if (previous != null) {
            if (text.equals(previous.editorText())) {
                ItemTarget preserved = previous.copy();
                if (slotDriven) {
                    preserved.slot = slot;
                }
                return preserved;
            }
        }
        if (slot >= 0) {
            if (!text.isEmpty()) {
                raw = "#" + slot + "|" + text;
            }
        } else {
            if (slot >= 0) {
                raw = "#" + slot;
            } else {
                raw = text;
            }
        }
        return ItemTarget.fromLegacyEntry(raw);
    }

    private List<ItemTarget> buildStructuredListTargets(String key) {
        List<String> values = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
        List<ItemTarget> previous = (List)this.editorItemLists.getOrDefault(key, Collections.emptyList());
        boolean[] used = new boolean[previous.size()];
        List<ItemTarget> rebuilt = new ArrayList();
        var var6 = values.iterator();
        while (var6.hasNext()) {
            String value = (String)var6.next();
            String entry = value == null ? "" : value.strip();
            while (entry.isEmpty()) {
            }
            ItemTarget preserved = null;
            int i = 0;
            while (i < previous.size()) {
                ItemTarget candidate = (ItemTarget)previous.get(i);
                if (used[i] == 0) {
                    if (candidate == null) {
                    } else {
                        if (entry.equals(candidate.toLegacyEntry())) {
                            preserved = candidate.copy();
                            used[i] = 1;
                        }
                    }
                } else {
                    i++;
                }
            }
            if (preserved != null) continue;
            preserved = ItemTarget.fromLegacyEntry(entry);
            if (!preserved.hasSlot() || preserved.hasIdentity()) continue;
            rebuilt.add(preserved);
        }
        this.editorItemLists.put(key, ItemTarget.copyList(rebuilt));
        return rebuilt;
    }

    private void rewriteStructuredEditorTargets() {
        if (this.targetAction == null || this.workingTag == null) {
            return;
        }
        if (this.targetAction instanceof SelectSlotAction) {
            this.writeStructuredField("itemName", this.buildStructuredFieldTarget("itemName", null));
        }
        if (this.targetAction instanceof UseItemAction) {
            this.writeStructuredField("itemName", this.buildStructuredFieldTarget("itemName", null));
        }
        if (this.targetAction instanceof WaitForCooldownAction) {
            this.writeStructuredField("itemName", this.buildStructuredFieldTarget("itemName", null));
        }
        if (this.targetAction instanceof CloseGuiAction) {
            this.writeStructuredField("itemName", this.buildStructuredFieldTarget("itemName", "targetSlot"));
        }
        if (this.targetAction instanceof SwapSlotsAction) {
            this.writeStructuredField("fromItemName", this.buildStructuredFieldTarget("fromItemName", null));
            this.writeStructuredField("toItemName", this.buildStructuredFieldTarget("toItemName", null));
        }
        if (this.targetAction instanceof StoreItemAction) {
            this.writeStructuredList("targetItems", this.buildStructuredListTargets("targetItems"));
        }
        if (this.targetAction instanceof XCarryAction) {
            this.writeStructuredList("entries", this.buildStructuredListTargets("entries"));
        }
        if (this.targetAction instanceof InventoryAuditAction) {
            this.writeStructuredList("targetItems", this.buildStructuredListTargets("targetItems"));
        }
    }

    private void writeStructuredField(String key, ItemTarget target) {
        if (target != null) {
            if (target.hasSlot()) { /* goto @39; */ }
        }
        this.workingTag.method_10551(key);
        this.editorItemFields.remove(key);
        return;
        L39: ;
        this.workingTag.method_10566(key, target.toTag());
        this.editorItemFields.put(key, target.copy());
    }

    private void writeStructuredList(String key, List<ItemTarget> targets) {
        this.workingTag.method_10566(key, ItemTarget.toTagList(targets));
    }

    private void refreshInteractiveLayout() {
        this.hitRegions.clear();
        this.scrollDragRegions.clear();
        this.catalogListBounds.clear();
        this.selectedListBounds.clear();
        int neededH = 20 + this.computeContentH() + 22 + 4;
        int minH = this.currentMinPanelHeight();
        int maxH = Math.max(minH, PackUtilUiScale.getVirtualScreenHeight() * 4 / 5);
        this.panelH = Math.max(minH, Math.min(maxH, neededH));
        PackUtilWindowLayout clamped = this.clampToScreen(this, new PackUtilWindowLayout(this.panelX, this.panelY, this.panelW, this.panelH, this.visible, false));
        this.panelX = clamped.x;
        this.panelY = clamped.y;
        this.panelW = clamped.width;
        this.panelH = clamped.height;
    }

    private void toggleWscEditSelection(int index) {
        if (this.wscEditIndex == index) {
            this.wscEditIndex = -1;
            this.clearWscEditorFields();
        } else {
            this.wscEditIndex = index;
            if (this.wscEntries != null) {
                if (index < this.wscEntries.size()) {
                    this.syncWscEditorFromEntry((WaitForSlotChangeAction.WaitEntry)this.wscEntries.get(index));
                }
            }
        }
    }

    private void syncWscEditorFromEntry(WaitForSlotChangeAction.WaitEntry e) {
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_wsc_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("wsc_slot");
        PackUtilChatField countF = (PackUtilChatField)this.textFields.get("wsc_count");
        if (addF == null || slotF == null) {
            return;
        }
        this.suppressWscLiveUpdate = true;
        ItemTarget target = e.resolvedTarget();
        addF.setText(target.editorText());
        slotF.setText(target.hasSlot() ? String.valueOf(target.slot) : "");
        if (countF != null) {
            countF.setText(String.valueOf(Math.max(1, e.targetCount)));
        }
        this.suppressWscLiveUpdate = false;
    }

    private void clearWscEditorFields() {
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_wsc_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("wsc_slot");
        PackUtilChatField countF = (PackUtilChatField)this.textFields.get("wsc_count");
        this.suppressWscLiveUpdate = true;
        if (addF != null) {
            addF.setText("");
        }
        if (slotF != null) {
            slotF.setText("");
        }
        if (countF != null) {
            countF.setText("");
        }
        this.suppressWscLiveUpdate = false;
    }

    private void handleWscEntryEditorChanged() {
        if (this.suppressWscLiveUpdate || this.wscEntries == null) {
            return;
        }
        if (this.wscEditIndex < 0 || this.wscEditIndex >= this.wscEntries.size()) {
            return;
        }
        PackUtilChatField addF = (PackUtilChatField)this.addFields.get("_wsc_add");
        PackUtilChatField slotF = (PackUtilChatField)this.textFields.get("wsc_slot");
        if (addF == null || slotF == null) {
            return;
        }
        String nameText = addF.getText().strip();
        String slotText = slotF.getText().strip();
        WaitEntry entry = (WaitForSlotChangeAction.WaitEntry)this.wscEntries.get(this.wscEditIndex);
        ItemTarget target = this.buildEntryTargetFromEditor(nameText, slotText, entry.resolvedTarget());
        String rawTarget = target.toLegacyEntry();
        String norm = rawTarget.isEmpty() ? "" : StoreItemAction.normalizeTargetEntry(rawTarget);
        if (norm == null) {
            norm = "";
        }
        if (!this.wscTargetExistsOtherThan(norm, this.wscEditIndex)) {
            entry.target = norm;
            entry.itemTarget = target;
        }
    }

    private void handleWscCountChanged() {
        if (this.suppressWscLiveUpdate || this.wscEntries == null) {
            return;
        }
        PackUtilChatField countF = (PackUtilChatField)this.textFields.get("wsc_count");
        if (countF == null) {
            return;
        }
        try {
            int count = Integer.parseInt(countF.getText().strip());
        }
        catch (NumberFormatException ignored) {
            return;
        }
        count = Math.max(1, count);
        (WaitForSlotChangeAction.WaitEntry)this.wscEntries.get(this.wscEditIndex).targetCount = count;
        if (this.wscEditIndex >= 0 && this.wscEditIndex < this.wscEntries.size()) {
        } else {
            this.wscAddCount = count;
        }
    }

    private void applyWscAddEntry(PackUtilChatField addF, PackUtilChatField slotF) {
        if (this.wscEntries == null) {
            return;
        }
        String nameText = addF.getText().strip();
        String slotText = slotF.getText().strip();
        ItemTarget target = this.buildEntryTargetFromEditor(nameText, slotText, null);
        String rawTarget = target.toLegacyEntry();
        String norm = rawTarget.isEmpty() ? "" : StoreItemAction.normalizeTargetEntry(rawTarget);
        if (norm == null) {
            norm = "";
        }
        if (!this.wscTargetExists(norm)) {
            WaitEntry entry = new WaitForSlotChangeAction.WaitEntry(norm, this.wscAddMode, this.wscAddCount);
            entry.itemTarget = target;
            entry.target = norm;
            this.wscEntries.add(entry);
            addF.setText("");
            slotF.setText("");
        }
    }

    private boolean wscTargetExists(String normTarget) {
        if (this.wscEntries == null) {
            return false;
        }
        var var2 = this.wscEntries.iterator();
        while (var2.hasNext()) {
            WaitEntry e = (WaitForSlotChangeAction.WaitEntry)var2.next();
            if (!e.target.equals(normTarget)) continue;
            return true;
        }
        return false;
    }

    private boolean wscTargetExistsOtherThan(String normTarget, int ignoreIdx) {
        if (this.wscEntries == null) {
            return false;
        }
        for (int i = 0; i < this.wscEntries.size(); i++) {
            if (!i != ignoreIdx && ((WaitForSlotChangeAction.WaitEntry)this.wscEntries.get(i)).target.equals(normTarget)) continue;
            return true;
        }
        return false;
    }

    private boolean isWaitSlotChangeEntryKey(String key) {
        return this.targetAction != null && this.targetAction.getType() == MacroActionType.WAIT_SLOT_CHANGE && "targetEntries".equals(key);
    }

    private boolean isStoreItemTargetListKey(String key) {
        return this.targetAction != null && this.targetAction.getType() == MacroActionType.STORE_ITEM && "targetItems".equals(key);
    }

    private boolean isInventoryAuditTargetListKey(String key) {
        return this.targetAction != null && this.targetAction.getType() == MacroActionType.INVENTORY_AUDIT && "targetItems".equals(key);
    }

    private boolean usesStoreTargetFormatting(String key) {
        return this.isStoreItemTargetListKey(key) || this.isInventoryAuditTargetListKey(key);
    }

    private String buildHandlerEntryFromEditor(String nameText, String slotText) {
        String trimmedName = nameText == null ? "" : nameText.trim();
        int slot = this.parseHandlerSlotField(slotText, -1);
        if (!trimmedName.isEmpty() && slot >= 0) {
            return "#" + slot + "|" + trimmedName;
        }
        if (!trimmedName.isEmpty()) {
            return trimmedName;
        }
        return slot >= 0 ? "#" + slot : null;
    }

    private ItemTarget captureItemTarget(class_1735 slot, String itemName, String registryId, int visibleSlot) {
        if (slot != null && slot.method_7677() != null && !slot.method_7677().method_7960()) {
            return ItemTarget.capture(slot.method_7677(), visibleSlot);
        }
        if (visibleSlot >= 0) {
            return ItemTarget.slotOnly(visibleSlot);
        }
        if (registryId.isBlank()) { /* goto @60; */ }
        String fallback = registryId != null ? registryId.trim() : itemName == null ? "" : itemName.trim();
        return ItemTarget.fromLegacyEntry(fallback);
    }

    private static ItemTarget stripSlotFromTarget(ItemTarget target) {
        if (target == null) {
            return new ItemTarget();
        }
        if (!target.hasSlot()) {
            return target;
        }
        ItemTarget copy = target.copy();
        copy.slot = -1;
        return copy;
    }

    private ItemTarget buildEntryTargetFromEditor(String nameText, String slotText, ItemTarget previous) {
        String trimmedName = nameText == null ? "" : nameText.strip();
        int slot = this.parseHandlerSlotField(slotText, -1);
        if (trimmedName.isEmpty() && slot < 0) {
            return new ItemTarget();
        }
        if (previous == null) { /* goto L90; */ }
        if (!trimmedName.equals(previous.editorText())) { /* goto L90; */ }
        int previousSlot = previous.hasSlot() ? previous.slot : -1;
        if (previousSlot == slot) {
            return previous.copy();
        }
        if (slot >= 0) {
            if (!trimmedName.isEmpty()) {
                raw = "#" + slot + "|" + trimmedName;
            }
        } else {
            if (slot >= 0) {
                raw = "#" + slot;
            } else {
                raw = trimmedName;
            }
        }
        return ItemTarget.fromLegacyEntry(raw);
    }

    private ItemTarget targetAt(List<ItemTarget> targets, List<String> legacyEntries, int index) {
        if (targets != null) {
            if (index >= 0) {
                if (index < targets.size()) {
                    ItemTarget target = (ItemTarget)targets.get(index);
                    if (target != null) {
                        if (target.hasSlot() || target.hasIdentity()) {
                            return target;
                        }
                    }
                }
            }
        }
        if (legacyEntries != null && index >= 0 && index < legacyEntries.size()) {
            return ItemTarget.fromLegacyEntry((String)legacyEntries.get(index));
        }
        return new ItemTarget();
    }

    private void setTargetAt(List<ItemTarget> targets, List<String> legacyEntries, int index, ItemTarget target) {
        if (targets == null || legacyEntries == null || index < 0) {
            return;
        }
        while (targets.size() <= index) {
            targets.add(new ItemTarget());
        }
        while (legacyEntries.size() <= index) {
            legacyEntries.add("");
        }
        ItemTarget stored = target == null ? new ItemTarget() : target;
        targets.set(index, stored);
        legacyEntries.set(index, stored.toLegacyEntry());
    }

    private void addTargetEntry(List<ItemTarget> targets, List<String> legacyEntries, ItemTarget target) {
        if (targets == null || legacyEntries == null || target == null) {
            return;
        }
        targets.add(target);
        legacyEntries.add(target.toLegacyEntry());
    }

    private void trimTargetEntries(List<ItemTarget> targets, int size) {
        if (targets == null) {
            return;
        }
        while (targets.size() > size) {
            targets.remove(targets.size() - 1);
        }
        while (targets.size() < size) {
            targets.add(new ItemTarget());
        }
    }

    private boolean isEditableStringList(String key) {
        return this.isXCarryListKey(key) || this.isStoreItemTargetListKey(key) || this.isInventoryAuditTargetListKey(key) || this.isWaitSlotChangeEntryKey(key);
    }

    private boolean isXCarryListKey(String key) {
        return this.targetAction != null && this.targetAction.getType() == MacroActionType.XCARRY && "entries".equals(key);
    }

    private boolean isOpenContainerEntityListKey(String key) {
        return this.targetAction != null && this.targetAction.getType() == MacroActionType.OPEN_CONTAINER && "entityTargets".equals(key);
    }

    private ActionEditorOverlay.CaptureListAddResult tryAddCapturedStoreItemEntry(class_1735 slot, String itemName, String registryId, int visibleSlot, List<String> entries) {
        if (slot == null || visibleSlot < 0) {
            return new ActionEditorOverlay.CaptureListAddResult(false, "Could not read that slot", -38037);
        }
        String mode = this.currentEnumValue("mode");
        boolean playerInventorySlot = PackUtilInventoryHelper.isPlayerInventorySlot(MC, slot);
        if ("LOOT".equals(mode) && playerInventorySlot) {
            return new ActionEditorOverlay.CaptureListAddResult(false, "Steal only accepts chest/custom GUI slots", -38037);
        }
        if ("STORE".equals(mode) && !playerInventorySlot) {
            return new ActionEditorOverlay.CaptureListAddResult(false, "Store only accepts player inventory slots", -38037);
        }
        String rawEntry = ActionEditorOverlay.stripSlotFromTarget(this.captureItemTarget(slot, itemName, registryId, visibleSlot)).toLegacyEntry();
        return this.tryAddCapturedStringListEntry(this.findField("targetItems"), "targetItems", entries, rawEntry);
    }

    private String normalizeXCarryEntry(String raw) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (!trimmed.startsWith("#")) {
            if (trimmed.matches("\\d+")) {
                trimmed = "#" + trimmed;
            }
        }
        return XCarryAction.normalizeEntry(trimmed);
    }

    private boolean addStringListEntry(FieldDef field, List<String> entries, String rawEntry) {
        if (entries == null || rawEntry == null) {
            return false;
        }
        String entry = rawEntry.strip();
        if (entry.isEmpty()) {
            return false;
        }
        if (field != null) {
            if (this.isXCarryListKey(field.key())) {
                entry = this.normalizeXCarryEntry(entry);
                if (entry == null || entries.contains(entry)) {
                    return false;
                }
                if (entries.size() >= 4) {
                    PackUtilClientMessaging.sendPrefixed("XCarry can only store 4 crafting-grid entries.");
                    return false;
                }
                entries.add(entry);
                return true;
            }
        }
        if (field != null) {
            if (this.isOpenContainerEntityListKey(field.key())) {
                if (entry.isBlank()) {
                    return false;
                }
                entries.clear();
                entries.add(entry);
                return true;
            }
        }
        if (field != null) {
            if (this.usesStoreTargetFormatting(field.key()) || this.isWaitSlotChangeEntryKey(field.key())) {
                entry = StoreItemAction.normalizeTargetEntry(entry);
                if (entry == null || entry.isBlank() || entries.contains(entry)) {
                    return false;
                }
                entries.add(entry);
                return true;
            }
        }
        if (field != null) {
            if ("players".equals(field.key())) {
                if (this.containsIgnoreCase(entries, entry)) {
                    return false;
                }
                entries.add(entry);
                return true;
            }
        }
        entries.add(entry);
        return true;
    }

    private ActionEditorOverlay.CaptureListAddResult tryAddCapturedStringListEntry(FieldDef field, String key, List<String> entries, String rawEntry) {
        if (entries == null) {
            return null;
        }
        String entry = rawEntry == null ? "" : rawEntry.strip();
        if (entry.isEmpty()) {
            return new ActionEditorOverlay.CaptureListAddResult(false, "Nothing to add from that slot", -38037);
        }
        if (field != null) {
            if (this.isXCarryListKey(field.key())) {
                entry = this.normalizeXCarryEntry(entry);
                if (entry == null || entry.isBlank()) {
                    return new ActionEditorOverlay.CaptureListAddResult(false, "Could not read that XCarry entry", -38037);
                }
                String formatted = this.formatStringListEntry(key, entry);
                if (entries.contains(entry)) {
                    return new ActionEditorOverlay.CaptureListAddResult(false, "Already added " + formatted, -38037);
                }
                if (entries.size() >= 4) {
                    return new ActionEditorOverlay.CaptureListAddResult(false, "XCarry limit reached: 4 entries max", -38037);
                }
                entries.add(entry);
                return new ActionEditorOverlay.CaptureListAddResult(true, "Added " + formatted, -10035062);
            }
        }
        if (field != null) {
            if (this.usesStoreTargetFormatting(field.key()) || this.isWaitSlotChangeEntryKey(field.key())) {
                entry = StoreItemAction.normalizeTargetEntry(entry);
                if (entry == null || entry.isBlank()) {
                    return new ActionEditorOverlay.CaptureListAddResult(false, "Could not read that slot target", -38037);
                }
            }
        }
        if (field != null) {
            if (this.isOpenContainerEntityListKey(field.key())) {
                entries.clear();
            }
        }
        formatted = this.formatStringListEntry(key, entry);
        if (entries.contains(entry)) {
            return new ActionEditorOverlay.CaptureListAddResult(false, "Already added " + formatted, -38037);
        }
        entries.add(entry);
        return new ActionEditorOverlay.CaptureListAddResult(true, "Added " + formatted, -10035062);
    }

    private String formatStringListEntry(String key, String entry) {
        if (this.isXCarryListKey(key)) {
            String formatted = XCarryAction.formatEntry(entry);
            if (!formatted.isEmpty()) {
                return formatted;
            }
        }
        if (this.usesStoreTargetFormatting(key) || this.isWaitSlotChangeEntryKey(key)) {
            return StoreItemAction.formatTargetEntry(entry);
        }
        if (this.isOpenContainerEntityListKey(key)) {
            return this.formatEntityEntry(entry);
        }
        return entry == null ? "" : entry;
    }

    private class_2561 formatStringListEntryText(String key, String entry, int index) {
        if (this.usesMinecraftTextRendering(key)) {
            ItemTarget target = this.resolveStructuredListTarget(key, index, entry);
            return this.formatItemTargetText(target, this.formatStringListEntry(key, entry));
        }
        return class_2561.method_43470(this.formatStringListEntry(key, entry));
    }

    private ItemTarget resolveStructuredListTarget(String key, int index, String entry) {
        List<ItemTarget> targets = this.buildStructuredListTargets(key);
        if (index >= 0) {
            if (index < targets.size()) {
                ItemTarget target = (ItemTarget)targets.get(index);
                if (target != null) {
                    if (target.hasSlot() || target.hasIdentity()) {
                        return target.copy();
                    }
                }
            }
        }
        parsed = ItemTarget.fromLegacyEntry(entry);
        return parsed.hasSlot() || parsed.hasIdentity() ? parsed : null;
    }

    private boolean usesMinecraftTextRendering(String key) {
        return this.usesStoreTargetFormatting(key) || this.isXCarryListKey(key);
    }

    private class_2561 formatItemTargetText(ItemTarget target, String fallback) {
        String safeFallback = fallback == null ? "" : fallback;
        if (target == null) {
            return class_2561.method_43470(safeFallback);
        }
        boolean hasSlot = target.hasSlot();
        boolean hasIdentity = target.hasIdentity();
        if (hasSlot && hasIdentity) {
            return class_2561.method_43470(target.slot + ": ").method_10852(target.listComponent().method_27661());
        }
        if (hasSlot) {
            return class_2561.method_43470("#" + target.slot);
        }
        if (hasIdentity) {
            class_2561 display = target.listComponent();
            if (display != null) {
                if (!display.getString().isBlank()) {
                    return display.method_27661();
                }
            }
        }
        return class_2561.method_43470(safeFallback);
    }

    private static String buildEntryFromNameAndSlot(String name, String slotText) {
        String n = name == null ? "" : name.strip();
        int slot = -1;
        if (slotText == null) { /* goto @47; */ }
        try {
            slot = Integer.parseInt(slotText.replaceAll("[^0-9]", ""));
        }
        catch (NumberFormatException e4) {
            if (slot >= 0) {
                if (!n.isEmpty()) {
                    return "#" + slot + "|" + n;
                }
            }
        }
        if (slot >= 0 && !n.isEmpty()) {
            return "#" + slot + "|" + n;
        }
        if (slot >= 0) {
            return "#" + slot;
        }
        return n;
    }

    private String parseHandlerEntryName(String entry) {
        if (entry == null || entry.isBlank()) {
            return "";
        }
        if (!entry.startsWith("#")) {
            return entry;
        }
        int separator = entry.indexOf(124);
        return separator >= 0 && separator + 1 < entry.length() ? entry.substring(separator + 1).trim() : "";
    }

    private int parseHandlerSlotField(String text, int fallback) {
        String raw = text == null ? "" : text.trim();
        if (raw.isEmpty()) {
            return fallback;
        }
        String cleaned = raw.replaceAll("[^0-9]", "");
        if (cleaned.isEmpty()) {
            return fallback;
        }
        try {
            int slot = Integer.parseInt(cleaned);
            return slot < 0 ? fallback : slot;
        }
        catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private int parseSlotEntryValue(String entry) {
        if (entry == null || !entry.startsWith("#")) {
            return -1;
        }
        try {
            int separator = entry.indexOf(124);
            String raw = separator >= 0 ? entry.substring(1, separator) : entry.substring(1);
            return Integer.parseInt(raw);
        }
        catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private boolean containsEntryOtherThan(List<String> entries, String entry, int ignoreIndex) {
        for (int i = 0; i < entries.size(); i++) {
            if (!i != ignoreIndex && ((String)entries.get(i)).equals(entry)) continue;
            return true;
        }
        return false;
    }

    private List<PackUtilSharedState.QueuedPacket> getWorkingQueuedPackets() {
        if (this.workingTag == null) {
            return new ArrayList();
        }
        SendPacketAction action = new SendPacketAction();
        action.fromTag(this.workingTag);
        return new ArrayList(action.packets);
    }

    private void setWorkingQueuedPackets(List<PackUtilSharedState.QueuedPacket> packets) {
        if (this.workingTag == null) {
            return;
        }
        class_2499 packetList = new class_2499();
        if (packets == null) { /* goto L69; */ }
        var var3 = packets.iterator();
        while (var3.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var3.next();
            class_2487 packetTag = PackUtilClipboardHelper.serializeQueuedPacket(qp);
            if (packetTag == null) continue;
            packetList.add(packetTag);
        }
        this.workingTag.method_10566("packets", packetList);
    }

    private String buildSendPacketInfo() {
        List<PackUtilSharedState.QueuedPacket> packets = this.getWorkingQueuedPackets();
        if (packets.isEmpty()) {
            return "Packets: 0";
        }
        String autoName = "";
        var var3 = packets.iterator();
        while (var3.hasNext()) {
            QueuedPacket qp = (PackUtilSharedState.QueuedPacket)var3.next();
            if (qp == null) { /* goto @74; */ }
            if (qp.packet == null) { /* goto @74; */ }
            autoName = PackUtilPacketNamer.getFriendlyName(qp.packet);
            break;
        }
        if (autoName.isEmpty()) {
            return "Packets: " + packets.size();
        }
        return packets.size() == 1 ? "Packets: 1 - " + autoName : "Packets: " + packets.size() + " - " + autoName;
    }

    private void setRawPacketActionData(PackUtilSharedState.QueuedPacket packet) {
        if (this.workingTag == null || packet == null) {
            return;
        }
        List<PackUtilSharedState.QueuedPacket> single = Collections.singletonList(packet);
        String base64 = PackUtilClipboardHelper.serializeQueueToBase64(single);
        if (base64 == null || base64.isBlank()) {
            return;
        }
        this.workingTag.method_10582("packetData", base64);
        if (!this.workingTag.method_10545("description")) { /* goto L77; */ }
        if (!this.workingTag.method_68564("description", "").isBlank()) { /* goto L111; */ }
        L77: ;
        String name = packet.packet != null ? PackUtilPacketNamer.getFriendlyName(packet.packet) : "Packet";
        this.workingTag.method_10582("description", name);
    }

    private String buildPacketActionInfo() {
        if (this.workingTag == null) {
            return "Raw Packet: empty";
        }
        String packetData = this.workingTag.method_68564("packetData", "");
        if (packetData == null || packetData.isBlank()) {
            return "Raw Packet: empty";
        }
        String description = this.workingTag.method_68564("description", "");
        return description == null || description.isBlank() ? "Raw Packet: loaded" : "Raw Packet: " + description;
    }

    private void startGBreakCaptureForEditor() {
        PackUtilSharedState state = PackUtilSharedState.get();
        this.screenBeforeGBreak = MC.field_1755;
        this.enterEditorOnlyCaptureMode();
        state.setCaptureCancelCallback(this::lambda$startGBreakCaptureForEditor$97 /* captured: state */);
        MC.execute(ActionEditorOverlay::lambda$startGBreakCaptureForEditor$98);
        PackUtilClientMessaging.sendPrefixed("GBreak: Break a block to capture the insta-break packet");
        state.startGBreakCapture(this::lambda$startGBreakCaptureForEditor$100);
    }

    private void startLookAtEntityCapture() {
        if (!(this.targetAction instanceof LookAtBlockAction)) {
            return;
        }
        class_437 previousScreen = MC.field_1755;
        this.enterEditorOnlyCaptureMode();
        PackUtilSharedState state = PackUtilSharedState.get();
        state.setCaptureCancelCallback(this::lambda$startLookAtEntityCapture$101 /* captured: previousScreen, state */);
        MC.execute(ActionEditorOverlay::lambda$startLookAtEntityCapture$102);
        state.setEntityCaptureSpecific(this.entitySpecificCaptureMode);
        state.setEntityCaptureCallback(this::lambda$startLookAtEntityCapture$105 /* captured: previousScreen */);
    }

    private void renderWaitSoundPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "waitForGui", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "waitGuiName", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "checkDistance", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "maxDistance", x, cy, w, mx, my, delta);
        List<String> selected = (List)this.stringLists.getOrDefault("soundIds", Collections.emptyList());
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "wait_sound_selected", "Sounds", selected, this::lambda$renderWaitSoundPanel$106 /* captured: selected */, PackUtilRegistryLabels::sound, "(any sound - add to filter)");
        PackUtilChatField search = (PackUtilChatField)this.addFields.get("soundIds");
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(w);
            search.render(ctx, mx, my, delta);
        }
        cy += 18;
        List<String> filtered = new ArrayList();
        String filter = search != null ? search.getText().trim().toLowerCase() : "";
        var var14 = ActionEditorOverlay.getAllSoundIds().iterator();
        while (var14.hasNext()) {
            String id = (String)var14.next();
            if (!ActionEditorOverlay.matchesListFilter(filter, id, ActionEditorOverlay.trimMinecraftPrefix(id), PackUtilRegistryLabels.sound(id))) continue;
            filtered.add(id);
        }
        Objects.requireNonNull(selected);
        this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "wait_sound_search", filtered, 6, ActionEditorOverlay::lambda$renderWaitSoundPanel$107 /* captured: selected */, selected::contains, PackUtilRegistryLabels::sound);
    }

    private void renderWaitEntityPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "checkMode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "radius", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "centerOnPlayer", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "pos", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "mustBeLookingAt", x, cy, w, mx, my, delta);
        List<String> selected = (List)this.stringLists.getOrDefault("entityIds", Collections.emptyList());
        Objects.requireNonNull(selected);
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "wait_entity_selected", "Entities", selected, selected::remove, this::formatEntityEntry, "(any entity - add type or specific)");
        PackUtilChatField search = (PackUtilChatField)this.addFields.get("entityIds");
        int searchW = w - 66;
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(searchW);
            search.render(ctx, mx, my, delta);
        }
        int modeX = x + searchW + 2;
        String modeLabel = this.entitySpecificCaptureMode ? "[Spec]" : "[Type]";
        this.renderActionButton(ctx, modeX, cy, 30, 14, modeLabel, mx, my, this::lambda$renderWaitEntityPanel$108);
        this.renderActionButton(ctx, modeX + 34, cy, 32, 14, "CAP", mx, my, this::startWaitEntityCapture);
        cy += 18;
        List<String> filtered = new ArrayList();
        String filter = search != null ? search.getText().trim().toLowerCase() : "";
        List<String> nearbyEntries = ActionEditorOverlay.getAllEntityIds().iterator();
        while (nearbyEntries.hasNext()) {
            String id = (String)nearbyEntries.next();
            if (!ActionEditorOverlay.matchesListFilter(filter, id, ActionEditorOverlay.trimMinecraftPrefix(id), PackUtilRegistryLabels.entity(id))) continue;
            filtered.add(id);
        }
        Objects.requireNonNull(selected);
        this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "wait_entity_search", filtered, 4, ActionEditorOverlay::lambda$renderWaitEntityPanel$109 /* captured: selected */, selected::contains, PackUtilRegistryLabels::entity);
        cy += 66;
        PackUiText.draw(ctx, this.textRenderer, "Nearby Entities", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        cy += 13;
        nearbyEntries = this.getNearbyEntityEntries();
        this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "wait_entity_nearby", nearbyEntries, 3, this::lambda$renderWaitEntityPanel$111 /* captured: selected */, this::lambda$renderWaitEntityPanel$113 /* captured: selected */, this::formatNearbyEntityEntry);
    }

    private void renderOpenContainerPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "targetMode", x, cy, w, mx, my, delta);
        String targetMode = this.currentEnumValue("targetMode");
        if ("ENTITY".equals(targetMode)) {
            cy = this.renderFieldByKey(ctx, "entityTargets", x, cy, w, mx, my, delta);
        } else {
            if ("BLOCK".equals(targetMode)) {
                cy = this.renderFieldByKey(ctx, "pos", x, cy, w, mx, my, delta);
            }
        }
        cy = this.renderFieldByKey(ctx, "waitForGui", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "guiName", x, cy, w, mx, my, delta);
        if ("ENTITY".equals(targetMode)) {
            cy = this.renderEditorHint(ctx, x, cy, w, "Pick captures the exact container entity. Last Target reuses the most recent open target.");
            List<String> selected = (List)this.stringLists.getOrDefault("entityTargets", Collections.emptyList());
            cy += 13;
            List<String> nearbyEntries = this.getNearbyEntityEntries();
            Objects.requireNonNull(selected);
            this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "open_container_entity_nearby", nearbyEntries, 3, ActionEditorOverlay::lambda$renderOpenContainerPanel$114 /* captured: selected */, selected::contains, this::formatNearbyEntityEntry);
        } else {
            if ("LAST_TARGET".equals(targetMode)) {
                this.renderEditorHint(ctx, x, cy, w, "Uses the last block or entity container you actually opened.");
            } else {
                cy = this.renderEditorHint(ctx, x, cy, w, "Capture only marks the block. It will not open it.");
                this.renderNearbyContainerList(ctx, x, cy, w, mx, my, "open_container_nearby", "pos");
            }
        }
    }

    private void renderNearbyContainerList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, String fieldKey) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        PackUiText.draw(ctx, this.textRenderer, "Nearby Containers", font, PackUtilColors.textSecondary(), x, y + 2, false);
        y += 13;
        List<class_2338> nearbyContainers = this.getNearbyContainerPositions();
        this.renderSearchRegistryList(ctx, x, y, w, mx, my, listKey, nearbyContainers, 2, this::lambda$renderNearbyContainerList$115 /* captured: fieldKey */, this::lambda$renderNearbyContainerList$116 /* captured: fieldKey */, this::formatContainerEntry);
    }

    private void renderStoreItemPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "mode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "allItems", x, cy, w, mx, my, delta);
        List<String> selected = (List)this.stringLists.getOrDefault("targetItems", Collections.emptyList());
        if (((Boolean)this.toggleStates.getOrDefault("allItems", false)).booleanValue()) { /* goto L918; */ }
        Objects.requireNonNull(selected);
        Objects.requireNonNull(selected);
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "store_items_selected", "Target Items", selected, selected::remove, StoreItemAction::formatTargetEntry, this::lambda$renderStoreItemPanel$117 /* captured: selected */, selected::clear, "(nothing selected - search, type #slot, or capture)", true);
        int storeEditIdx = ((Integer)this.stringListEditIndex.getOrDefault("store_items_selected", -1)).intValue();
        boolean storeEditing = storeEditIdx >= 0 && storeEditIdx < selected.size();
        PackUtilChatField search = (PackUtilChatField)this.addFields.get("targetItems");
        int pickW = 32;
        int addBtnW = 34;
        int slotW = 44;
        int capBtnX = x + w - pickW;
        int addBtnX = capBtnX - 3 - addBtnW;
        int slotX = addBtnX - 2 - slotW;
        int nameW = slotX - x - 2;
        PackUtilChatField storeSlotF = (PackUtilChatField)this.textFields.get("store_slot");
        if (storeSlotF == null) {
            storeSlotF = this.makeField(slotW);
            storeSlotF.setNumericOnly(true);
            storeSlotF.setPlaceholder(class_2561.method_43470("Slot#"));
            this.textFields.put("store_slot", storeSlotF);
        }
        String pendingText = (String)this.stringListEditPendingText.remove("store_items_selected");
        if (pendingText == null) { /* goto L403; */ }
        if (search != null) {
            search.setText(this.parseHandlerEntryName(pendingText));
        }
        ItemTarget parsed = ItemTarget.fromLegacyEntry(pendingText);
        storeSlotF.setText(parsed.hasSlot() ? String.valueOf(parsed.slot) : "");
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(nameW);
            search.render(ctx, mx, my, delta);
        }
        storeSlotF.setX(slotX);
        storeSlotF.setY(cy + 1);
        storeSlotF.setWidth(slotW);
        storeSlotF.render(ctx, mx, my, delta);
        if (storeEditing) {
            if (search != null) {
                nameText = search.getText().strip();
                String slotText = storeSlotF.getText().strip();
                String entry = ActionEditorOverlay.buildEntryFromNameAndSlot(nameText, slotText);
                if (!entry.isEmpty()) {
                    String normalized = StoreItemAction.normalizeTargetEntry(entry);
                    if (normalized != null) {
                        if (!normalized.isBlank()) {
                            if (!normalized.equals(selected.get(storeEditIdx))) {
                                selected.set(storeEditIdx, normalized);
                                this.editorItemLists.put("targetItems", this.buildStructuredListTargets("targetItems"));
                            }
                        }
                    }
                }
            }
        }
        fStoreSlotF = storeSlotF;
        this.renderOverlayButton(ctx, addBtnX, cy, addBtnW, 14, "+Add", PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderStoreItemPanel$118 /* captured: search, fStoreSlotF, selected */);
        capturing = "targetItems".equals(this.itemSlotCapturePendingKey);
        this.renderOverlayButton(ctx, capBtnX, cy, pickW, 14, capturing ? "Done" : "Pick", capturing ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderStoreItemPanel$119);
        cy += 18;
        filter = search != null ? search.getText().trim().toLowerCase() : "";
        filtered = new ArrayList();
        String modeHint = ActionEditorOverlay.getAllItemIds().iterator();
        while (modeHint.hasNext()) {
            String id = (String)modeHint.next();
            if (!ActionEditorOverlay.matchesListFilter(filter, id, ActionEditorOverlay.trimMinecraftPrefix(id), PackUtilRegistryLabels.item(id))) continue;
            filtered.add(id);
        }
        Objects.requireNonNull(selected);
        this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "store_items_search", filtered, 6, this::lambda$renderStoreItemPanel$120 /* captured: selected */, selected::contains, PackUtilRegistryLabels::item);
        cy += 82;
        cy = this.renderEditorHint(ctx, x, cy, w, "Pick on an item adds the item. Pick on an empty slot adds that exact slot.");
        modeHint = "LOOT".equals(this.currentEnumValue("mode")) ? "Pick only accepts chest/custom GUI slots here." : "Pick only accepts player inventory slots here.";
        cy = this.renderEditorHint(ctx, x, cy, w, modeHint);
        cy = this.renderFieldByKey(ctx, "persistent", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "closeAfter", x, cy, w, mx, my, delta);
        this.renderFieldByKey(ctx, "closeSendPkt", x, cy, w, mx, my, delta);
    }

    private void renderInventoryAuditPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "mode", x, cy, w, mx, my, delta);
        List<String> selected = (List)this.stringLists.getOrDefault("targetItems", Collections.emptyList());
        FieldDef targetItemsField = this.getField("targetItems");
        if (targetItemsField == null) { /* goto L817; */ }
        if (!this.isFieldVisible(targetItemsField)) { /* goto L817; */ }
        String emptyLabel = this.getStringListEmptyHint("targetItems");
        if (emptyLabel == null || emptyLabel.isBlank()) {
            emptyLabel = "(nothing selected)";
        }
        boolean multipleStacks = ((Boolean)this.toggleStates.getOrDefault("multipleStacks", false)).booleanValue();
        int listTop = cy;
        Objects.requireNonNull(selected);
        Objects.requireNonNull(selected);
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "audit_items_selected", "Targets", selected, selected::remove, StoreItemAction::formatTargetEntry, this::lambda$renderInventoryAuditPanel$121 /* captured: selected */, selected::clear, emptyLabel, true);
        int multiBtnW = 96;
        int clearBtnW = 44;
        int multiBtnX = x + w - clearBtnW - 3 - multiBtnW;
        this.renderOverlayButton(ctx, multiBtnX, listTop, multiBtnW, 14, "Multiple Stacks", multipleStacks ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderInventoryAuditPanel$122);
        int auditEditIdx = ((Integer)this.stringListEditIndex.getOrDefault("audit_items_selected", -1)).intValue();
        boolean auditEditing = auditEditIdx >= 0 && auditEditIdx < selected.size();
        PackUtilChatField search = (PackUtilChatField)this.addFields.get("targetItems");
        int pickW = 32;
        int addBtnW = 34;
        int slotW = 26;
        int pickX = x + w - addBtnW - 3 - pickW;
        int addBtnX = x + w - addBtnW;
        int slotX = pickX - 3 - slotW;
        int nameW = slotX - x - 2;
        PackUtilChatField auditSlotF = (PackUtilChatField)this.textFields.get("audit_slot");
        if (auditSlotF == null) {
            auditSlotF = this.makeField(slotW);
            auditSlotF.setNumericOnly(true);
            auditSlotF.setPlaceholder(class_2561.method_43470("Slot"));
            this.textFields.put("audit_slot", auditSlotF);
        }
        String pendingText = (String)this.stringListEditPendingText.remove("audit_items_selected");
        if (pendingText == null) { /* goto L503; */ }
        if (search != null) {
            search.setText(this.parseHandlerEntryName(pendingText));
        }
        ItemTarget parsed = ItemTarget.fromLegacyEntry(pendingText);
        auditSlotF.setText(parsed.hasSlot() ? String.valueOf(parsed.slot) : "");
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(nameW);
            search.render(ctx, mx, my, delta);
        }
        auditSlotF.setX(slotX);
        auditSlotF.setY(cy + 1);
        auditSlotF.setWidth(slotW);
        auditSlotF.render(ctx, mx, my, delta);
        if (auditEditing) {
            if (search != null) {
                nameText = search.getText().strip();
                String slotText = auditSlotF.getText().strip();
                String entry = ActionEditorOverlay.buildEntryFromNameAndSlot(nameText, slotText);
                if (!entry.isEmpty()) {
                    String normalized = StoreItemAction.normalizeTargetEntry(entry);
                    if (normalized != null) {
                        if (!normalized.isBlank()) {
                            if (!normalized.equals(selected.get(auditEditIdx))) {
                                selected.set(auditEditIdx, normalized);
                                this.editorItemLists.put("targetItems", this.buildStructuredListTargets("targetItems"));
                            }
                        }
                    }
                }
            }
        }
        fAuditSlotF = auditSlotF;
        capturing = "targetItems".equals(this.itemSlotCapturePendingKey);
        this.renderOverlayButton(ctx, pickX, cy, pickW, 14, capturing ? "Done" : "Pick", capturing ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderInventoryAuditPanel$123);
        addLabel = auditEditing ? "New" : "+Add";
        this.renderOverlayButton(ctx, addBtnX, cy, addBtnW, 14, addLabel, PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderInventoryAuditPanel$124 /* captured: search, fAuditSlotF, selected */);
        cy += 18;
        cy = this.renderFieldByKey(ctx, "openMode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "openCommand", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "containerPos", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "dupeVector", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "iterations", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "maxTransferAttempts", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "transferRetryDelayMs", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "spamCount", x, cy, w, mx, my, delta);
        this.renderFieldByKey(ctx, "spamDelayMs", x, cy, w, mx, my, delta);
    }

    private void renderPayPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "commandTemplate", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "amountInput", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "delayEnabled", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "delayMs", x, cy, w, mx, my, delta);
        List<String> selected = (List)this.stringLists.getOrDefault("players", Collections.emptyList());
        Objects.requireNonNull(selected);
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "pay_players_selected", "Players", selected, this::lambda$renderPayPanel$125 /* captured: selected */, ActionEditorOverlay::lambda$renderPayPanel$126, ActionEditorOverlay::lambda$renderPayPanel$127, selected::clear, "(scan the server or add one manually)");
        PackUtilChatField search = (PackUtilChatField)this.addFields.get("players");
        int scanW = 34;
        int allW = 28;
        int searchW = Math.max(80, w - scanW - allW - 4);
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(searchW);
            search.render(ctx, mx, my, delta);
        }
        int scanX = x + searchW + 2;
        int allX = scanX + scanW + 2;
        this.renderActionButton(ctx, scanX, cy, scanW, 14, "Scan", mx, my, this::refreshPayScannedPlayers);
        this.renderActionButton(ctx, allX, cy, allW, 14, "All", mx, my, this::lambda$renderPayPanel$128 /* captured: selected, search */);
        cy += 18;
        List<String> filtered = this.filterEntries(this.payScannedPlayers, search != null ? search.getText() : "");
        if (!this.payPlayerScanPerformed) {
            this.renderRegistryPlaceholder(ctx, x, cy, w, "pay_players_scan", 6, "Press Scan to load the current server players.");
        } else {
            this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "pay_players_scan", filtered, 6, this::lambda$renderPayPanel$129 /* captured: selected */, this::lambda$renderPayPanel$130 /* captured: selected */, ActionEditorOverlay::lambda$renderPayPanel$131);
        }
        cy += 82;
        PackUtilChatField amountField = (PackUtilChatField)this.textFields.get("amountInput");
        long amount = PayAction.parseAmount(amountField != null ? amountField.getText() : "");
        String summary = selected.isEmpty() ? "No players selected." : "Pays " + selected.size() + " player(s) " + PayAction.formatAmount(amount) + " each.";
        cy = this.renderEditorHint(ctx, x, cy, w, summary);
        String hint = this.payPlayerScanPerformed ? "Click a scanned name to toggle it, or use All to add the filtered scan results." : "The search box also lets you manually add a player by pressing Enter.";
        this.renderEditorHint(ctx, x, cy, w, hint);
    }

    private void renderToggleModulePanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        List<ToggleModuleAction.ModuleEntry> selected = this.toggleModuleEntries != null ? this.toggleModuleEntries : Collections.emptyList();
        PackUiText.draw(ctx, this.textRenderer, "Module Actions (" + selected.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        boolean canClear = !selected.isEmpty();
        int clearX = x + w - 44;
        this.renderOverlayButton(ctx, clearX, cy, 44, 14, "Clear", PackUiOverlayButton.Variant.DANGER, canClear, mx, my, this::lambda$renderToggleModulePanel$132 /* captured: selected */);
        cy += 13;
        int listH = 60;
        int itemW = w - 5 - 1;
        PackUiScrollViewport toggleViewport = this.getOrCreateViewport(this.selectedScrollViewports, "toggle_module_selected", x, cy, w, listH, 15, 5);
        toggleViewport.setContentHeight(selected.size() * 15);
        this.selectedListBounds.put("toggle_module_selected", cy, listH);
        toggleViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (selected.isEmpty()) {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "Pick modules below.", x, cy, itemW);
        } else {
            toggleViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int first = toggleViewport.getFirstVisibleRow();
            for (int i = first; i < selected.size(); i++) {
                if (i > toggleViewport.getLastVisibleRow()) break;
                int iy = toggleViewport.getRowScreenY(i);
                if (iy == -2147483648) {
                } else {
                    ModuleEntry entry = (ToggleModuleAction.ModuleEntry)selected.get(i);
                    int removeW = 13;
                    int modeW = 52;
                    int rowW = itemW - removeW - modeW - 4;
                    boolean hovered = mx >= x && mx < x + rowW && my >= iy && my < iy + 13;
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, entry.moduleName, x, iy, rowW, 13, hovered, false, PackUiListRenderer.RowTone.NORMAL);
                    int modeX = x + rowW + 2;
                    String modeLabel = this.formatToggleModeShort(entry.toggleMode);
                    int entryIndex = i;
                    this.renderOverlayButton(ctx, modeX, iy, modeW, 13, modeLabel, entry.toggleMode == ToggleModuleAction.ToggleMode.ENABLE ? PackUiOverlayButton.Variant.SUCCESS : entry.toggleMode == ToggleModuleAction.ToggleMode.DISABLE ? PackUiOverlayButton.Variant.DANGER : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderToggleModulePanel$133 /* captured: entryIndex */);
                    int removeX = modeX + modeW + 2;
                    this.renderIconDeleteButton(ctx, removeX, iy, removeW, mx, my, this::lambda$renderToggleModulePanel$134 /* captured: entryIndex, selected */);
                }
            }
            toggleViewport.endRender(ctx);
        }
        cy = cy + (listH + 4);
        search = (PackUtilChatField)this.addFields.get("_toggle_module_search");
        refreshW = 52;
        addW = 40;
        searchW = Math.max(80, w - refreshW - addW - 4);
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(searchW);
            search.render(ctx, mx, my, delta);
        }
        refreshX = x + searchW + 2;
        addX = refreshX + refreshW + 2;
        this.renderActionButton(ctx, refreshX, cy, refreshW, 14, "Refresh", mx, my, this::refreshMeteorModuleNames);
        this.renderActionButton(ctx, addX, cy, addW, 14, "+Add", mx, my, this::lambda$renderToggleModulePanel$135 /* captured: search */);
        cy += 18;
        filtered = this.filterEntries(this.meteorModuleNames, search != null ? search.getText() : "");
        if (this.meteorModuleNames.isEmpty()) {
            this.renderRegistryPlaceholder(ctx, x, cy, w, "toggle_module_registry", 6, "No Meteor modules found right now.");
        } else {
            this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "toggle_module_registry", filtered, 6, this::addToggleModuleEntry, this::lambda$renderToggleModulePanel$136 /* captured: selected */, ActionEditorOverlay::lambda$renderToggleModulePanel$137);
        }
        cy += 82;
        hint = selected.isEmpty() ? "Pick modules below, then click the mode chip on each row." : "Each row runs with its own Toggle / Enable / Disable setting.";
        this.renderEditorHint(ctx, x, cy, w, hint);
    }

    private void renderRegistryPlaceholder(class_332 ctx, int x, int y, int w, String listKey, int visibleRows, String message) {
        int listH = visibleRows * 13;
        int itemW = w - 5 - 1;
        this.catalogListBounds.put(listKey, y, listH);
        ctx.method_25294(x, y, x + itemW, y + 12, PackUtilColors.rowNormal());
        PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, this.formatEditorHint(message), x, y, itemW);
    }

    private void refreshPayScannedPlayers() {
        this.payScannedPlayers.clear();
        this.payPlayerScanPerformed = true;
        PackUiScrollViewport vp = (PackUiScrollViewport)this.catalogScrollViewports.get("pay_players_scan");
        if (vp != null) {
            vp.jumpTo(0);
        }
        if (MC.method_1562() == null) {
            return;
        }
        var var2 = MC.method_1562().method_2880().iterator();
        while (var2.hasNext()) {
            class_640 entry = (class_640)var2.next();
            if (entry == null) continue;
            while (entry.method_2966() == null) {
            }
            String name = entry.method_2966().name();
            if (name != null) {
                if (!name.isBlank()) {
                    if (this.containsIgnoreCase(this.payScannedPlayers, name)) continue;
                    this.payScannedPlayers.add(name);
                }
            }
        }
        this.payScannedPlayers.sort(String::compareToIgnoreCase);
    }

    private void refreshMeteorModuleNames() {
        this.meteorModuleNames.clear();
        PackUiScrollViewport vp = (PackUiScrollViewport)this.catalogScrollViewports.get("toggle_module_registry");
        if (vp != null) {
            vp.jumpTo(0);
        }
        var var2 = PackUtilCompatManager.getMeteorModuleNames().iterator();
        while (var2.hasNext()) {
            String moduleName = (String)var2.next();
            if (moduleName != null) {
                if (!moduleName.isBlank()) {
                    if (this.containsIgnoreCase(this.meteorModuleNames, moduleName)) continue;
                    this.meteorModuleNames.add(moduleName);
                }
            }
        }
        this.meteorModuleNames.sort(String::compareToIgnoreCase);
    }

    private List<String> filterEntries(List<String> source, String query) {
        if (source == null || source.isEmpty()) {
            return Collections.emptyList();
        }
        String filter = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (filter.isEmpty()) {
            return new ArrayList(source);
        }
        List<String> filtered = new ArrayList();
        var var5 = source.iterator();
        while (var5.hasNext()) {
            String value = (String)var5.next();
            if (value != null) {
                if (!value.toLowerCase(Locale.ROOT).contains(filter)) continue;
                filtered.add(value);
            }
        }
        return filtered;
    }

    private void addFilteredPayPlayers(List<String> selected, String query) {
        if (selected == null) {
            return;
        }
        var var3 = this.filterEntries(this.payScannedPlayers, query).iterator();
        while (var3.hasNext()) {
            String player = (String)var3.next();
            if (this.containsIgnoreCase(selected, player)) continue;
            selected.add(player);
        }
    }

    private void togglePayPlayerSelection(List<String> selected, String player) {
        if (selected == null || player == null || player.isBlank()) {
            return;
        }
        if (this.containsIgnoreCase(selected, player)) {
            this.removeStringIgnoreCase(selected, player);
        } else {
            selected.add(player);
        }
    }

    private boolean containsIgnoreCase(List<String> values, String target) {
        if (values == null || target == null) {
            return false;
        }
        var var3 = values.iterator();
        while (var3.hasNext()) {
            String value = (String)var3.next();
            if (value != null) {
                if (!value.equalsIgnoreCase(target)) continue;
                return true;
            }
        }
        return false;
    }

    private void removeStringIgnoreCase(List<String> values, String target) {
        if (values == null || target == null) {
            return;
        }
        values.removeIf(ActionEditorOverlay::lambda$removeStringIgnoreCase$138 /* captured: target */);
    }

    private void addFirstFilteredModule(String query) {
        List<String> filtered = this.filterEntries(this.meteorModuleNames, query);
        if (!filtered.isEmpty()) {
            this.addToggleModuleEntry((String)filtered.get(0));
        }
    }

    private void addToggleModuleEntry(String moduleName) {
        if (this.toggleModuleEntries == null || moduleName == null || moduleName.isBlank() || this.containsModuleEntry(this.toggleModuleEntries, moduleName)) {
            return;
        }
        this.toggleModuleEntries.add(new ToggleModuleAction.ModuleEntry(moduleName, ToggleModuleAction.ToggleMode.TOGGLE));
    }

    private boolean containsModuleEntry(List<ToggleModuleAction.ModuleEntry> entries, String moduleName) {
        if (entries == null || moduleName == null) {
            return false;
        }
        var var3 = entries.iterator();
        while (var3.hasNext()) {
            ModuleEntry entry = (ToggleModuleAction.ModuleEntry)var3.next();
            if (entry != null) {
                if (entry.moduleName != null) {
                    if (!entry.moduleName.equalsIgnoreCase(moduleName)) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private void cycleToggleModuleEntryMode(int index) {
        if (this.toggleModuleEntries == null || index < 0 || index >= this.toggleModuleEntries.size()) {
            return;
        }
        ModuleEntry entry = (ToggleModuleAction.ModuleEntry)this.toggleModuleEntries.get(index);
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[entry.toggleMode.ordinal()]) {
            default:
                throw new MatchException(null, null);
                /* note: stack not empty at case end */
            case 1::
                entry.toggleMode = ToggleModuleAction.ToggleMode.ENABLE;
                return;
                break;
            case 2::
                entry.toggleMode = ToggleModuleAction.ToggleMode.DISABLE;
                return;
                break;
            case 3::
                entry.toggleMode = ToggleModuleAction.ToggleMode.TOGGLE;
                return;
        }
    }

    private String formatToggleModeShort(ToggleModuleAction.ToggleMode mode) {
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[mode.ordinal()]) {
            case 2::
                return "Enable";
            case 3::
                return "Disable";
            default:
                return "Toggle";
        }
    }

    private void renderWaitSlotChangePanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        int headerBtnW = 44;
        List<WaitForSlotChangeAction.WaitEntry> entries = this.wscEntries != null ? this.wscEntries : new ArrayList();
        if (this.wscEditIndex >= entries.size()) {
            this.wscEditIndex = -1;
        }
        PackUiText.draw(ctx, this.textRenderer, "Items / Slots (" + entries.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        boolean canClear = !entries.isEmpty();
        int clearX = x + w - headerBtnW;
        this.renderOverlayButton(ctx, clearX, cy, headerBtnW, 14, "Clear", PackUiOverlayButton.Variant.DANGER, canClear, mx, my, this::lambda$renderWaitSlotChangePanel$139 /* captured: entries */);
        cy += 13;
        int delW = 13;
        int rowW = w - 5 - 1 - delW - 2;
        int selAreaH = 60;
        PackUiScrollViewport wscViewport = this.getOrCreateViewport(this.selectedScrollViewports, "_wsc_entries", x, cy, w, selAreaH, 15, 5);
        wscViewport.setContentHeight(entries.size() * 15);
        this.selectedListBounds.put("_wsc_entries", cy, selAreaH);
        wscViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (!entries.isEmpty()) {
            wscViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
            int firstVis = wscViewport.getFirstVisibleRow();
            for (int i = firstVis; i < entries.size(); i++) {
                if (i > wscViewport.getLastVisibleRow()) break;
                int iy = wscViewport.getRowScreenY(i);
                if (iy == -2147483648) {
                } else {
                    boolean selected = i == this.wscEditIndex;
                    WaitEntry e = (WaitForSlotChangeAction.WaitEntry)entries.get(i);
                    class_2561 targetDisp = this.formatItemTargetText(e.resolvedTarget(), "(any slot)");
                    String modeSummary = " • " + e.modeLabel();
                    class_2561 rowLabel = class_2561.method_43473().method_10852(targetDisp).method_10852(class_2561.method_43470(modeSummary).method_27694(ActionEditorOverlay::lambda$renderWaitSlotChangePanel$140));
                    boolean rowHovered = mx >= x && mx < x + rowW && my >= iy && my < iy + 13;
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, rowLabel, x, iy, rowW, 13, rowHovered, selected, PackUiListRenderer.RowTone.NORMAL, true);
                    int fi = i;
                    if (iy + 13 > cy) {
                        if (!iy < cy + selAreaH) continue;
                        this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, Math.max(cy, iy), rowW, Math.min(iy + 13, cy + selAreaH) - Math.max(cy, iy), this::lambda$renderWaitSlotChangePanel$141 /* captured: fi */));
                    }
                    int delX = x + rowW + 2;
                    this.renderIconDeleteButton(ctx, delX, iy, delW, mx, my, this::lambda$renderWaitSlotChangePanel$142 /* captured: fi, entries */);
                }
            }
            wscViewport.endRender(ctx);
        } else {
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "No entries yet. Add an item or slot below.", x, cy, w - 5 - 1);
        }
        cy = cy + selAreaH;
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 6;
        PackUtilChatField wscAddF = (PackUtilChatField)this.addFields.get("_wsc_add");
        PackUtilChatField wscSlotF = (PackUtilChatField)this.textFields.get("wsc_slot");
        if (wscAddF == null) { /* goto L869; */ }
        if (wscSlotF == null) { /* goto L869; */ }
        int pickW = 32;
        int slotW = 44;
        int pickX = x + w - pickW;
        int slotX = pickX - 2 - slotW;
        wscAddF.setX(x);
        wscAddF.setY(cy + 1);
        wscAddF.setWidth(slotX - x - 2);
        wscSlotF.setX(slotX);
        wscSlotF.setY(cy + 1);
        wscSlotF.setWidth(slotW);
        wscAddF.render(ctx, mx, my, delta);
        wscSlotF.render(ctx, mx, my, delta);
        boolean capturing = "_wsc_entries".equals(this.itemSlotCapturePendingKey);
        String pickLbl = capturing ? "Done" : "Pick";
        this.renderOverlayButton(ctx, pickX, cy, pickW, 14, pickLbl, capturing ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.PRIMARY, true, mx, my, this::lambda$renderWaitSlotChangePanel$143);
        L869: ;
        cy += 16;
        editing = this.wscEditIndex >= 0 && this.wscEditIndex < entries.size();
        curMode = editing ? ((WaitForSlotChangeAction.WaitEntry)entries.get(this.wscEditIndex)).waitMode : this.wscAddMode;
        curCount = editing ? ((WaitForSlotChangeAction.WaitEntry)entries.get(this.wscEditIndex)).targetCount : this.wscAddCount;
        addBtnW = 34;
        cntW = 36;
        modBtnW = w - addBtnW - 2 - cntW - 2;
        String modeFull = curMode.name().replace("_", " ");
        this.renderOverlayButton(ctx, x, cy, modBtnW, 14, modeFull, PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderWaitSlotChangePanel$144 /* captured: entries */);
        int cntX = x + modBtnW + 2;
        PackUtilChatField countF = (PackUtilChatField)this.textFields.get("wsc_count");
        boolean countRelevant = curMode == WaitForSlotChangeAction.WaitMode.COUNT_AT_LEAST || curMode == WaitForSlotChangeAction.WaitMode.COUNT_BELOW;
        if (countF == null) { /* goto L1237; */ }
        if (countRelevant) {
            countF.setX(cntX);
            countF.setY(cy + 1);
            countF.setWidth(cntW);
            this.suppressWscLiveUpdate = true;
            if (!countF.isFocused() && !this.suppressWscLiveUpdate) {
                countF.setText(String.valueOf(curCount));
                this.suppressWscLiveUpdate = false;
            }
            countF.render(ctx, mx, my, delta);
        } else {
            ctx.method_25294(cntX, cy, cntX + cntW, cy + 14, -15857142);
            this.fillBorder(ctx, cntX, cy, cntW, 14, -14018022);
            PackUiText.draw(ctx, this.textRenderer, "-", font, PackUtilColors.textDim(), cntX + (cntW - this.uiWidth(font, "-")) / 2, cy + 3, false);
        }
        int plusX = cntX + cntW + 2;
        this.renderOverlayButton(ctx, plusX, cy, addBtnW, 14, "+Add", PackUiOverlayButton.Variant.SUCCESS, true, mx, my, this::lambda$renderWaitSlotChangePanel$145 /* captured: wscAddF, wscSlotF */);
        cy += 16;
        this.renderEditorHint(ctx, x, cy, w, this.wscEditIndex >= 0 ? "Editing selected row. Use Mode below to cycle. ALL entries must match." : "Click a row to edit. ALL entries must match before proceeding.");
    }

    private void renderUseItemPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "itemName", x, cy, w, mx, my, delta);
        int btnW = (w - 4) / 2;
        this.renderActionButton(ctx, x, cy, btnW, 14, "Use Held", mx, my, this::fillUseItemFromHeld);
        this.renderActionButton(ctx, x + btnW + 4, cy, btnW, 14, "Use Current", mx, my, this::lambda$renderUseItemPanel$146);
        cy += 18;
        cy = this.renderFieldByKey(ctx, "useMode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "holdTicks", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "useCount", x, cy, w, mx, my, delta);
        String itemTarget = this.currentUseItemTargetLabel();
        String mode = this.currentEnumValue("useMode");
        String hint = "CUSTOM_HOLD".equals(mode) ? "Hold-uses " + itemTarget + " for the set ticks." : "Uses " + itemTarget + " for the set count.";
        this.renderEditorHint(ctx, x, cy, w, hint);
    }

    private void renderRotatePanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "yaw", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "pitch", x, cy, w, mx, my, delta);
        this.renderActionButton(ctx, x, cy, w, 14, "Capture View", mx, my, this::fillRotateFromCurrentView);
        cy += 18;
        cy = this.renderFieldByKey(ctx, "smooth", x, cy, w, mx, my, delta);
        if (((Boolean)this.toggleStates.getOrDefault("smooth", false)).booleanValue()) {
            cy = this.renderRotateSmoothnessSlider(ctx, x, cy, w, mx, my);
        } else {
            this.rotateSmoothnessSliderDragging = false;
            this.clearRotateSmoothnessSliderBounds();
        }
        cy = this.renderFieldByKey(ctx, "waitForCompletion", x, cy, w, mx, my, delta);
        this.renderEditorHint(ctx, x, cy, w, ((Boolean)this.toggleStates.getOrDefault("smooth", false)).booleanValue() ? "Capture View fills in your current yaw and pitch. Smoothness 1 is faster, 10 is slower." : "Capture View fills in your current yaw and pitch.");
    }

    private void renderLookAtPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "targetMode", x, cy, w, mx, my, delta);
        String mode = this.currentEnumValue("targetMode");
        if ("BLOCK".equals(mode)) {
            cy = this.renderFieldByKey(ctx, "searchRadius", x, cy, w, mx, my, delta);
            cy = this.renderFieldByKey(ctx, "blockIds", x, cy, w, mx, my, delta);
        } else {
            if ("ENTITY".equals(mode)) {
                cy = this.renderFieldByKey(ctx, "searchRadius", x, cy, w, mx, my, delta);
                cy = this.renderLookAtEntitySelector(ctx, x, cy, w, mx, my, delta);
            } else {
                cy = this.renderFieldByKey(ctx, "blockPos", x, cy, w, mx, my, delta);
            }
        }
        cy = this.renderFieldByKey(ctx, "smooth", x, cy, w, mx, my, delta);
        if (((Boolean)this.toggleStates.getOrDefault("smooth", false)).booleanValue()) {
            cy = this.renderRotateSmoothnessSlider(ctx, x, cy, w, mx, my);
        } else {
            this.rotateSmoothnessSliderDragging = false;
            this.clearRotateSmoothnessSliderBounds();
        }
        cy = this.renderFieldByKey(ctx, "waitForCompletion", x, cy, w, mx, my, delta);
        var var11 = mode;
        int var12 = -1;
        switch (var11.hashCode()) {
            case 63294573::
                if (!var11.equals("BLOCK")) { /* goto @331; */ }
                var12 = 0;
                /* goto @331; */
            case 2050021347::
                if (var11.equals("ENTITY")) {
                    var12 = 1;
                }
            default:
                switch (var12) {
                    case 0::
                        String hint = "Search blocks and it faces the nearest matching block in range.";
                        break;
                    case 1::
                        hint = "Pick entity types or specific captures and it faces the nearest match in range.";
                        break;
                    default:
                        hint = "Pick a specific block position to face.";
                        break;
                }
                if (((Boolean)this.toggleStates.getOrDefault("smooth", false)).booleanValue()) {
                    hint = hint + " Smoothness 1 is faster, 10 is slower.";
                }
                this.renderEditorHint(ctx, x, cy, w, hint);
                return;
        }
    }

    private int renderLookAtEntitySelector(class_332 ctx, int x, int y, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = y;
        List<String> selected = (List)this.stringLists.getOrDefault("entityIds", Collections.emptyList());
        Objects.requireNonNull(selected);
        cy = this.renderSimpleSelectedList(ctx, x, cy, w, mx, my, "look_at_entity_selected", "Entities", selected, selected::remove, this::formatEntityEntry, "(add entity types or specific captures)");
        PackUtilChatField search = (PackUtilChatField)this.addFields.get("entityIds");
        int searchW = w - 66;
        if (search != null) {
            search.setX(x);
            search.setY(cy + 1);
            search.setWidth(searchW);
            search.render(ctx, mx, my, delta);
        }
        int modeX = x + searchW + 2;
        String modeLabel = this.entitySpecificCaptureMode ? "[Spec]" : "[Type]";
        this.renderActionButton(ctx, modeX, cy, 30, 14, modeLabel, mx, my, this::lambda$renderLookAtEntitySelector$147);
        this.renderActionButton(ctx, modeX + 34, cy, 32, 14, "CAP", mx, my, this::startLookAtEntityCapture);
        cy += 18;
        List<String> filtered = new ArrayList();
        String filter = search != null ? search.getText().trim().toLowerCase() : "";
        List<String> nearbyEntries = ActionEditorOverlay.getAllEntityIds().iterator();
        while (nearbyEntries.hasNext()) {
            String id = (String)nearbyEntries.next();
            if (!ActionEditorOverlay.matchesListFilter(filter, id, ActionEditorOverlay.trimMinecraftPrefix(id), PackUtilRegistryLabels.entity(id))) continue;
            filtered.add(id);
        }
        Objects.requireNonNull(selected);
        this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "look_at_entity_search", filtered, 4, ActionEditorOverlay::lambda$renderLookAtEntitySelector$148 /* captured: selected */, selected::contains, PackUtilRegistryLabels::entity);
        cy += 66;
        PackUiText.draw(ctx, this.textRenderer, "Nearby Entities", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        cy += 13;
        nearbyEntries = this.getNearbyEntityEntries();
        this.renderSearchRegistryList(ctx, x, cy, w, mx, my, "look_at_entity_nearby", nearbyEntries, 3, this::lambda$renderLookAtEntitySelector$150 /* captured: selected */, this::lambda$renderLookAtEntitySelector$152 /* captured: selected */, this::formatNearbyEntityEntry);
        return cy + 39 + 4;
    }

    private void renderGoToPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        FieldDef posField = this.getField("pos");
        if (posField != null) {
            cy = this.renderBlockPosWithoutCapture(ctx, posField, x, cy, w, mx, my, delta);
        }
        this.renderActionButton(ctx, x, cy, w, 14, "Capture Here", mx, my, this::fillGoToFromPlayer);
        cy += 18;
        cy = this.renderFieldByKey(ctx, "waitForArrival", x, cy, w, mx, my, delta);
        this.renderEditorHint(ctx, x, cy, w, "Wait for Arrival continues only after Baritone finishes.");
    }

    private void renderSwapSlotsPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        PackUiText.draw(ctx, this.textRenderer, "From", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        this.renderActionButton(ctx, x + w - 68, cy, 68, 14, "Flip Ends", mx, my, this::swapSwapSlotEndpoints);
        cy += 16;
        cy = this.renderFieldByKey(ctx, "fromUseItemName", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "fromItemName", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "fromSlot", x, cy, w, mx, my, delta);
        ctx.method_25294(x, cy + 2, x + w, cy + 3, PackUtilColors.subPanelBorder());
        cy += 8;
        PackUiText.draw(ctx, this.textRenderer, "To", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        cy += 16;
        cy = this.renderFieldByKey(ctx, "toUseItemName", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "toItemName", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "toSlot", x, cy, w, mx, my, delta);
        this.renderEditorHint(ctx, x, cy, w, this.buildSwapSlotsSummary());
    }

    private void renderClickPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "clickType", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "clickCount", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "waitForGui", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "guiName", x, cy, w, mx, my, delta);
        this.renderEditorHint(ctx, x, cy, w, this.buildClickSummary());
    }

    private void renderDisconnectPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "mode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "delayMs", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "lagMethod", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "kickMethod", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "packetCount", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "useNextAction", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "trigger", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "tolerance", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "bufferMs", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "timeoutSec", x, cy, w, mx, my, delta);
        String mode = this.currentEnumValue("mode");
        var var12 = mode;
        int var13 = -1;
        switch (var12.hashCode()) {
            case 1015497884::
                if (!var12.equals("DISCONNECT")) { /* goto @357; */ }
                var13 = 0;
                /* goto @357; */
            case 2306630::
                if (!var12.equals("KICK")) { /* goto @357; */ }
                var13 = 1;
                /* goto @357; */
            case -275795668::
                if (!var12.equals("AUTO_DISCONNECT")) { /* goto @357; */ }
                var13 = 2;
                /* goto @357; */
            case 1826239647::
                if (var12.equals("KICK_DUPE")) {
                    var13 = 3;
                }
            default:
                switch (var13) {
                    case 0::
                        String hint = "Simple disconnect. Delay only controls how long to wait before closing the connection.";
                        break;
                    case 1::
                        hint = "Sends lag packets, then the selected kick packet. Packet Count controls how hard it pushes.";
                        break;
                    case 2::
                        hint = "Auto-disconnects at the perfect dupe timing.";
                        break;
                    case 3::
                        hint = ((Boolean)this.toggleStates.getOrDefault("useNextAction", false)).booleanValue() ? "Kick Dupe will run the next eligible macro actions inside the lag sandwich, then kick." : "Kick Dupe will try to use a bundle, then kick.";
                        break;
                    default:
                        hint = "Unknown mode";
                        break;
                }
                this.renderEditorHint(ctx, x, cy, w, hint, "DISCONNECT".equals(mode) ? PackUtilColors.textDim() : -19605);
                return;
        }
    }

    private void renderWaitGuiPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "waitMode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "guiTitle", x, cy, w, mx, my, delta);
        String mode = this.currentEnumValue("waitMode");
        String hint = "CLOSE".equals(mode) ? "Waits until the current GUI closes." : "Waits until a GUI opens.";
        this.renderEditorHint(ctx, x, cy, w, hint);
    }

    private void renderSelectSlotPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "itemName", x, cy, w, mx, my, delta);
        int btnW = (w - 4) / 2;
        this.renderActionButton(ctx, x, cy, btnW, 14, "Held", mx, my, this::fillSelectSlotFromHeld);
        this.renderActionButton(ctx, x + btnW + 4, cy, btnW, 14, "Use Slot Only", mx, my, this::clearSelectSlotItemName);
        cy += 18;
        PackUiText.draw(ctx, this.textRenderer, "Fallback Hotbar Slot", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        cy += 12;
        cy = this.renderSelectSlotHotbarPicker(ctx, x, cy, w, mx, my);
        this.renderEditorHint(ctx, x, cy, w, this.buildSelectSlotSummary());
    }

    private int renderSelectSlotHotbarPicker(class_332 ctx, int x, int y, int w, int mx, int my) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int selectedSlot = this.getSelectSlotHotbarIndex();
        int slotGap = 2;
        int cellW = Math.max(16, Math.min(24, (w - slotGap * 8) / 9));
        int totalW = cellW * 9 + slotGap * 8;
        int startX = x + Math.max(0, (w - totalW) / 2);
        for (int slot = 0; slot < 9; slot++) {
            int sx = startX + slot * (cellW + slotGap);
            boolean selected = selectedSlot == slot;
            String label = String.valueOf(slot + 1);
            int clickedSlot = slot;
            this.renderOverlayButton(ctx, sx, y, cellW, 14, label, selected ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderSelectSlotHotbarPicker$153 /* captured: clickedSlot */);
        }
        return y + 18;
    }

    private void renderWaitCooldownPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "itemName", x, cy, w, mx, my, delta);
        int halfW = (w - 4) / 2;
        this.renderActionButton(ctx, x, cy, halfW, 14, this.currentWaitCooldownHandLabel(), mx, my, this::toggleWaitCooldownHand);
        this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Capture Held", mx, my, this::fillWaitCooldownFromHeld);
        cy += 18;
        this.renderActionButton(ctx, x, cy, Math.min(130, w), 14, "Use Hand Item", mx, my, this::clearWaitCooldownItemName);
        cy += 18;
        this.renderEditorHint(ctx, x, cy, w, this.buildWaitCooldownSummary());
    }

    private void renderWaitChatPanel(class_332 ctx, int x, int bodyTop, int contentBottom, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "pattern", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "useRegex", x, cy, w, mx, my, delta);
        if (!((Boolean)this.toggleStates.getOrDefault("useRegex", false)).booleanValue()) {
            cy = this.renderWaitChatFuzzySlider(ctx, x, cy, w, mx, my);
        } else {
            this.waitChatFuzzySliderDragging = false;
            this.clearWaitChatFuzzySliderBounds();
        }
        cy = this.renderFieldByKey(ctx, "serverMessageOnly", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "timeoutMs", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "waitForGui", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "waitGuiName", x, cy, w, mx, my, delta);
        String pattern = this.textFields.containsKey("pattern") ? ((PackUtilChatField)this.textFields.get("pattern")).getText().trim() : "";
        boolean regex = ((Boolean)this.toggleStates.getOrDefault("useRegex", false)).booleanValue();
        int fuzzyPercent = this.getWaitChatFuzzyPercent();
        boolean serverOnly = ((Boolean)this.toggleStates.getOrDefault("serverMessageOnly", false)).booleanValue();
        String hint = pattern.isEmpty() ? serverOnly ? "Blank pattern = any server message." : "Blank pattern = any chat line." : regex ? "Regex mode uses Java regex rules." : "Fuzzy mode ignores case/punctuation. " + fuzzyPercent + "% is looser.";
        cy = this.renderEditorHint(ctx, x, cy, w, hint);
        PackUtilChatField searchField = (PackUtilChatField)this.addFields.get("_wait_chat_search");
        if (searchField != null) {
            searchField.setX(x);
            searchField.setY(cy);
            searchField.setWidth(w);
            searchField.render(ctx, mx, my, delta);
            cy += 18;
        }
        cy = this.renderWaitChatSourceFilterBar(ctx, x, cy, w, mx, my);
        List<MacroExecutor.RecentChatMessage> history = this.filterWaitChatHistory();
        PackUiText.draw(ctx, this.textRenderer, "Recent Messages (" + history.size() + ")", font, PackUtilColors.textSecondary(), x, cy + 2, false);
        PackUiText.draw(ctx, this.textRenderer, PackUiText.trimToWidth(this.textRenderer, this.formatEditorHint("Click a row to use that message."), Math.max(20, w - 122), font, -1), font, PackUtilColors.textDim(), x + 118, cy + 2, false);
        cy += 13;
        int availableListHeight = Math.max(24, contentBottom - cy - 4);
        this.renderWaitChatHistoryList(ctx, x, cy, w, availableListHeight, mx, my, history);
    }

    private int renderWaitChatFuzzySlider(class_332 ctx, int x, int y, int w, int mx, int my) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int percent = this.getWaitChatFuzzyPercent();
        PackUiText.draw(ctx, this.textRenderer, "Match Strength", font, PackUtilColors.textSecondary(), x, y + 2, false);
        String label = percent + "%";
        PackUiText.draw(ctx, this.textRenderer, label, font, PackUtilColors.textDim(), x + w - this.uiWidth(font, label), y + 2, false);
        y += 13;
        int sliderW = w;
        int sliderH = 14;
        int trackH = 4;
        int trackY = y + (sliderH - trackH) / 2;
        this.waitChatFuzzySliderX = x;
        this.waitChatFuzzySliderY = y;
        this.waitChatFuzzySliderW = sliderW;
        this.waitChatFuzzySliderH = sliderH;
        ctx.method_25294(x, y, x + sliderW, y + sliderH, -15921896);
        this.fillBorder(ctx, x, y, sliderW, sliderH, PackUtilColors.subPanelBorder());
        ctx.method_25294(x + 1, trackY, x + sliderW - 1, trackY + trackH, -15397876);
        int[] tmp0 = new int[7];
        tmp0[0] = 40;
        tmp0[1] = 50;
        tmp0[2] = 60;
        tmp0[3] = 70;
        tmp0[4] = 80;
        tmp0[5] = 90;
        tmp0[6] = 100;
        int[] steps = tmp0;
        int knobIndex = Math.max(0, Math.min(6, (percent - 40) / 10));
        int knobCenterX = x + Math.round((float)(sliderW - 1) * ((float)knobIndex / 6f));
        ctx.method_25294(x + 1, trackY, knobCenterX, trackY + trackH, -13345658);
        for (int i = 0; i < steps.length; i++) {
            int step = steps[i];
            int cx = x + Math.round((float)(sliderW - 1) * ((float)i / 6f));
            int tickColor = step <= percent ? -6435073 : -10862528;
            ctx.method_25294(cx, y + 2, cx + 1, y + sliderH - 2, tickColor);
        }
        knobW = 16;
        knobX = Math.max(x, Math.min(x + sliderW - knobW, knobCenterX - knobW / 2));
        hovered = this.isOverWaitChatFuzzySlider(mx, my);
        knobFill = this.waitChatFuzzySliderDragging ? -14202259 : hovered ? -14007198 : -14533802;
        int knobBorder = this.waitChatFuzzySliderDragging ? -5908993 : -7816193;
        ctx.method_25294(knobX, y, knobX + knobW, y + sliderH, knobFill);
        this.fillBorder(ctx, knobX, y, knobW, sliderH, knobBorder);
        return y + sliderH + 2;
    }

    private int renderWaitChatSourceFilterBar(class_332 ctx, int x, int y, int w, int mx, int my) {
        int btnGap = 4;
        int btnW = (w - btnGap * 2) / 3;
        String[] tmp0 = new String[3];
        tmp0[0] = "All";
        tmp0[1] = "Server";
        tmp0[2] = "Player";
        String[] labels = tmp0;
        for (int i = 0; i < labels.length; i++) {
            int bx = x + i * (btnW + btnGap);
            boolean selected = this.waitChatSourceFilterMode == i;
            int filterMode = i;
            this.renderOverlayButton(ctx, bx, y, btnW, 14, labels[i], selected ? PackUiOverlayButton.Variant.PRIMARY : PackUiOverlayButton.Variant.GHOST, true, mx, my, this::lambda$renderWaitChatSourceFilterBar$154 /* captured: filterMode */);
        }
        return y + 16;
    }

    private int getWaitChatFuzzyPercent() {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("fuzzyPercent");
        if (field == null) {
            return 100;
        }
        try {
            return WaitForChatAction.clampFuzzyPercent(Integer.parseInt(field.getText().trim()));
        }
        catch (NumberFormatException ignored) {
            return 100;
        }
    }

    private void setWaitChatFuzzyPercent(int percent) {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("fuzzyPercent");
        if (field != null) {
            field.setText(String.valueOf(WaitForChatAction.clampFuzzyPercent(percent)));
        }
    }

    private void clearWaitChatFuzzySliderBounds() {
        this.waitChatFuzzySliderX = -1;
        this.waitChatFuzzySliderY = -1;
        this.waitChatFuzzySliderW = 0;
        this.waitChatFuzzySliderH = 0;
    }

    private boolean isOverWaitChatFuzzySlider(int mx, int my) {
        return this.waitChatFuzzySliderW > 0 && this.waitChatFuzzySliderH > 0 && mx >= this.waitChatFuzzySliderX && mx < this.waitChatFuzzySliderX + this.waitChatFuzzySliderW && my >= this.waitChatFuzzySliderY && my < this.waitChatFuzzySliderY + this.waitChatFuzzySliderH;
    }

    private void updateWaitChatFuzzyPercentFromMouse(int mouseX) {
        if (this.waitChatFuzzySliderW <= 1) {
            return;
        }
        float normalized = (float)(mouseX - this.waitChatFuzzySliderX) / (float)(this.waitChatFuzzySliderW - 1);
        normalized = Math.max(0f, Math.min(1f, normalized));
        int stepIndex = Math.round(normalized * 6f);
        this.setWaitChatFuzzyPercent(40 + stepIndex * 10);
    }

    private int renderRotateSmoothnessSlider(class_332 ctx, int x, int y, int w, int mx, int my) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int smoothness = this.getRotateSmoothness();
        PackUiText.draw(ctx, this.textRenderer, "Smoothness", font, PackUtilColors.textSecondary(), x, y + 2, false);
        String label = smoothness + " / 10";
        PackUiText.draw(ctx, this.textRenderer, label, font, PackUtilColors.textDim(), x + w - this.uiWidth(font, label), y + 2, false);
        y += 13;
        int sliderW = w;
        int sliderH = 14;
        int trackH = 4;
        int trackY = y + (sliderH - trackH) / 2;
        this.rotateSmoothnessSliderX = x;
        this.rotateSmoothnessSliderY = y;
        this.rotateSmoothnessSliderW = sliderW;
        this.rotateSmoothnessSliderH = sliderH;
        ctx.method_25294(x, y, x + sliderW, y + sliderH, -15921896);
        this.fillBorder(ctx, x, y, sliderW, sliderH, PackUtilColors.subPanelBorder());
        ctx.method_25294(x + 1, trackY, x + sliderW - 1, trackY + trackH, -15397876);
        int knobIndex = Math.max(0, Math.min(9, smoothness - 1));
        int knobCenterX = x + Math.round((float)(sliderW - 1) * ((float)knobIndex / 9f));
        ctx.method_25294(x + 1, trackY, knobCenterX, trackY + trackH, -13345658);
        for (int i = 0; i < 10; i++) {
            int cx = x + Math.round((float)(sliderW - 1) * ((float)i / 9f));
            int tickColor = i <= knobIndex ? -6435073 : -10862528;
            ctx.method_25294(cx, y + 2, cx + 1, y + sliderH - 2, tickColor);
        }
        knobW = 16;
        knobX = Math.max(x, Math.min(x + sliderW - knobW, knobCenterX - knobW / 2));
        hovered = this.isOverRotateSmoothnessSlider(mx, my);
        int knobFill = this.rotateSmoothnessSliderDragging ? -14202259 : hovered ? -14007198 : -14533802;
        int knobBorder = this.rotateSmoothnessSliderDragging ? -5908993 : -7816193;
        ctx.method_25294(knobX, y, knobX + knobW, y + sliderH, knobFill);
        this.fillBorder(ctx, knobX, y, knobW, sliderH, knobBorder);
        return y + sliderH + 2;
    }

    private int getRotateSmoothness() {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("smoothness");
        if (field == null) {
            return 9;
        }
        try {
            return RotateAction.clampSmoothness(Integer.parseInt(field.getText().trim()));
        }
        catch (NumberFormatException ignored) {
            return 9;
        }
    }

    private void setRotateSmoothness(int smoothness) {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("smoothness");
        if (field != null) {
            field.setText(String.valueOf(RotateAction.clampSmoothness(smoothness)));
        }
    }

    private void clearRotateSmoothnessSliderBounds() {
        this.rotateSmoothnessSliderX = -1;
        this.rotateSmoothnessSliderY = -1;
        this.rotateSmoothnessSliderW = 0;
        this.rotateSmoothnessSliderH = 0;
    }

    private boolean isOverRotateSmoothnessSlider(int mx, int my) {
        return this.rotateSmoothnessSliderW > 0 && this.rotateSmoothnessSliderH > 0 && mx >= this.rotateSmoothnessSliderX && mx < this.rotateSmoothnessSliderX + this.rotateSmoothnessSliderW && my >= this.rotateSmoothnessSliderY && my < this.rotateSmoothnessSliderY + this.rotateSmoothnessSliderH;
    }

    private void updateRotateSmoothnessFromMouse(int mouseX) {
        if (this.rotateSmoothnessSliderW <= 1) {
            return;
        }
        float normalized = (float)(mouseX - this.rotateSmoothnessSliderX) / (float)(this.rotateSmoothnessSliderW - 1);
        normalized = Math.max(0f, Math.min(1f, normalized));
        int stepIndex = Math.round(normalized * 9f);
        this.setRotateSmoothness(1 + stepIndex);
    }

    private void applyWaitChatHistoryEntry(MacroExecutor.RecentChatMessage entry) {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("pattern");
        if (field == null) { /* goto L106; */ }
        if (entry == null) { /* goto L106; */ }
        class_2561 patternComponent = entry.displayComponent() != null ? entry.displayComponent().method_27661() : class_2561.method_43470(this.formatWaitChatHistoryEntry(entry));
        this.setWaitChatPatternField(field, patternComponent);
        this.toggleStates.put("useRegex", false);
        this.toggleStates.put("serverMessageOnly", entry.source() == MacroExecutor.ChatSource.SERVER);
    }

    private void setWaitChatPatternField(PackUtilChatField field, class_2561 component) {
        if (field == null) {
            return;
        }
        class_2561 safeComponent = component != null ? component.method_27661() : class_2561.method_43473();
        String visibleText = safeComponent.getString();
        this.workingTag.method_10582("pattern", visibleText);
        this.workingTag.method_10582("patternJson", MacroExecutor.serializeTextComponent(safeComponent));
        this.suppressWaitChatPatternSync = true;
        field.setText(visibleText);
        this.suppressWaitChatPatternSync = false;
    }

    private class_2561 getWaitChatPatternComponent(String fallbackValue) {
        class_2561 exact = MacroExecutor.deserializeTextComponent(this.workingTag != null ? this.workingTag.method_68564("patternJson", "") : "");
        if (exact != null) {
            return exact.method_27661();
        }
        return class_2561.method_43470(fallbackValue == null ? "" : fallbackValue);
    }

    private class_2561 rebuildWaitChatPatternComponent(class_2561 previousComponent, String editedValue) {
        String safeValue = editedValue == null ? "" : editedValue;
        if (previousComponent == null) {
            return class_2561.method_43470(safeValue);
        }
        String previousValue = previousComponent.getString();
        if (previousValue.equals(safeValue)) {
            return previousComponent.method_27661();
        }
        if (safeValue.isEmpty()) {
            return class_2561.method_43473();
        }
        if (previousValue.isEmpty()) {
            return class_2561.method_43470(safeValue);
        }
        List<class_2583> previousStyles = this.flattenWaitChatStyles(previousComponent, previousValue.length());
        if (previousStyles.isEmpty()) {
            return class_2561.method_43470(safeValue);
        }
        int prefix = this.longestCommonPrefix(previousValue, safeValue);
        int suffix = this.longestCommonSuffix(previousValue, safeValue, prefix);
        int previousLength = previousValue.length();
        int nextLength = safeValue.length();
        class_5250 rebuilt = class_2561.method_43473();
        StringBuilder segment = new StringBuilder();
        class_2583 segmentStyle = null;
        for (int i = 0; i < nextLength; i++) {
            class_2583 style = this.styleForEditedWaitChatIndex(previousStyles, previousLength, nextLength, prefix, suffix, i);
            if (segmentStyle == null) {
                segmentStyle = style;
            } else {
                if (!segmentStyle.equals(style)) {
                    rebuilt.method_10852(class_2561.method_43470(segment.toString()).method_10862(segmentStyle));
                    segment.setLength(0);
                    segmentStyle = style;
                }
            }
            segment.append(safeValue.charAt(i));
        }
        if (segment.isEmpty()) { /* goto L281; */ }
        rebuilt.method_10852(class_2561.method_43470(segment.toString()).method_10862(segmentStyle == null ? class_2583.field_24360 : segmentStyle));
        return rebuilt;
    }

    private List<class_2583> flattenWaitChatStyles(class_2561 text, int expectedLength) {
        if (text == null || expectedLength <= 0) {
            return Collections.emptyList();
        }
        List<class_2583> rawStyles = new ArrayList(expectedLength);
        text.method_27658(ActionEditorOverlay::lambda$flattenWaitChatStyles$155 /* captured: rawStyles */, class_2583.field_24360);
        List<class_2583> styles = new ArrayList(rawStyles);
        if (styles.isEmpty()) {
            for (int i = 0; i < expectedLength; i++) {
                styles.add(class_2583.field_24360);
            }
        } else {
            if (styles.size() < expectedLength) {
                class_2583 fill = (class_2583)styles.get(styles.size() - 1);
                while (styles.size() < expectedLength) {
                    styles.add(fill);
                }
            } else {
                if (styles.size() > expectedLength) {
                    styles = new ArrayList(styles.subList(0, expectedLength));
                }
            }
        }
        return styles;
    }

    private int longestCommonPrefix(String left, String right) {
        int max = Math.min(left.length(), right.length());
        for (int index = 0; index < max; index++) {
            if (left.charAt(index) != right.charAt(index)) break;
        }
        return index;
    }

    private int longestCommonSuffix(String previous, String next, int prefixLength) {
        int previousRemaining = previous.length() - prefixLength;
        int nextRemaining = next.length() - prefixLength;
        int max = Math.min(previousRemaining, nextRemaining);
        for (int suffix = 0; suffix < max; suffix++) {
            if (previous.charAt(previous.length() - 1 - suffix) != next.charAt(next.length() - 1 - suffix)) break;
        }
        return suffix;
    }

    private class_2583 styleForEditedWaitChatIndex(List<class_2583> previousStyles, int previousLength, int nextLength, int prefixLength, int suffixLength, int nextIndex) {
        if (previousStyles.isEmpty()) {
            return class_2583.field_24360;
        }
        if (nextIndex < prefixLength) {
            return (class_2583)previousStyles.get(Math.min(nextIndex, previousStyles.size() - 1));
        }
        int nextSuffixStart = nextLength - suffixLength;
        int previousSuffixStart = previousLength - suffixLength;
        int mappedIndex = previousSuffixStart + (nextIndex - nextSuffixStart);
        if (suffixLength > 0 && nextIndex >= nextSuffixStart) {
            return (class_2583)previousStyles.get(Math.max(0, Math.min(mappedIndex, previousStyles.size() - 1)));
        }
        if (prefixLength > 0) {
            anchorIndex = prefixLength - 1;
        } else {
            if (suffixLength > 0) {
                anchorIndex = previousSuffixStart;
            } else {
                anchorIndex = 0;
            }
        }
        return (class_2583)previousStyles.get(Math.max(0, Math.min(anchorIndex, previousStyles.size() - 1)));
    }

    private List<MacroExecutor.RecentChatMessage> filterWaitChatHistory() {
        List<MacroExecutor.RecentChatMessage> history = MacroExecutor.getRecentChatMessages();
        PackUtilChatField searchField = (PackUtilChatField)this.addFields.get("_wait_chat_search");
        String query = searchField != null ? searchField.getText().trim() : "";
        List<MacroExecutor.RecentChatMessage> filtered = new ArrayList();
        String normalizedQuery = query.isEmpty() ? "" : this.normalizeWaitChatSearch(query);
        var var6 = history.iterator();
        while (var6.hasNext()) {
            RecentChatMessage entry = (MacroExecutor.RecentChatMessage)var6.next();
            while (this.waitChatSourceFilterMode == 1) {
                if (entry.source() == MacroExecutor.ChatSource.SERVER) break;
            }
            while (this.waitChatSourceFilterMode == 2) {
                if (entry.source() == MacroExecutor.ChatSource.PLAYER) break;
            }
            while (normalizedQuery.isEmpty()) {
                filtered.add(entry);
            }
            String haystack = this.normalizeWaitChatSearch(this.formatWaitChatHistoryEntry(entry));
            if (!haystack.contains(normalizedQuery)) continue;
            filtered.add(entry);
        }
        return filtered;
    }

    private String normalizeWaitChatSearch(String text) {
        return MacroExecutor.normalizeChatText(text);
    }

    private String formatWaitChatHistoryEntry(MacroExecutor.RecentChatMessage entry) {
        if (entry == null) {
            return "";
        }
        if (entry.displayComponent() != null) {
            String rendered = entry.displayComponent().getString();
            if (rendered != null) {
                if (!rendered.isBlank()) {
                    return rendered;
                }
            }
        }
        sender = entry.sender() == null ? "" : entry.sender().trim();
        String message = entry.message() == null ? "" : entry.message().trim();
        if (!sender.isEmpty() && !message.isEmpty()) {
            return sender + ": " + message;
        }
        if (message.isEmpty()) { /* goto L135; */ }
        return entry.source() == MacroExecutor.ChatSource.SERVER ? "[Server] " : "[Player] " + message;
        return entry.displayText() == null ? "" : entry.displayText();
    }

    private void renderWaitChatHistoryList(class_332 ctx, int x, int y, int w, int listH, int mx, int my, List<MacroExecutor.RecentChatMessage> values) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        listH = Math.max(24, Math.min(listH, 136));
        int itemW = w - 5 - 1;
        PackUiScrollViewport chatViewport = this.getOrCreateViewport(this.selectedScrollViewports, "wait_chat_recent", x, y, w, listH, 34, 5);
        chatViewport.setContentHeight(values.size() * 34);
        this.selectedListBounds.put("wait_chat_recent", y, listH);
        chatViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (values.isEmpty()) {
            ctx.method_25294(x, y, x + itemW, y + 24, PackUtilColors.rowNormal());
            PackUiText.draw(ctx, this.textRenderer, "No recent messages matched your search.", font, PackUtilColors.textDim(), x + 3, y + 3, false);
            PackUiText.draw(ctx, this.textRenderer, "Send or receive chat first, then pick it here.", font, PackUtilColors.textDim(), x + 3, y + 13, false);
            return;
        }
        chatViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
        int first = chatViewport.getFirstVisibleRow();
        for (int i = first; i < values.size(); i++) {
            if (i > chatViewport.getLastVisibleRow()) break;
            int iy = chatViewport.getRowScreenY(i);
            if (iy == -2147483648) {
            } else {
                int itemH = 34;
                if (!iy + itemH > y + listH) continue;
                itemH = Math.max(0, y + listH - iy);
                if (itemH <= 0) {
                } else {
                    RecentChatMessage value = (MacroExecutor.RecentChatMessage)values.get(i);
                    boolean hovered = mx >= x && mx < x + itemW && my >= iy && my < iy + itemH;
                    ctx.method_25294(x, iy, x + itemW, iy + itemH, hovered ? PackUtilColors.rowHover() : PackUtilColors.rowNormal());
                    int border = value.source() == MacroExecutor.ChatSource.SERVER ? hovered ? -20134 : -3376606 : hovered ? -8597761 : -11627064;
                    this.fillBorder(ctx, x, iy, itemW, itemH, border);
                    List<class_5481> wrapped = this.wrapWaitChatDisplayLines(value, Math.max(20, itemW - 6), 3);
                    int textY = iy + 3;
                    if (wrapped.isEmpty()) {
                        PackUiText.draw(ctx, this.textRenderer, "(empty)", font, PackUtilColors.textDim(), x + 3, textY, false);
                    } else {
                        RecentChatMessage selected = wrapped.iterator();
                        while (selected.hasNext()) {
                            class_5481 line = (class_5481)selected.next();
                            if (textY + 8 > iy + itemH) {
                            } else {
                                ctx.method_51430(this.textRenderer, line, x + 3, textY, -1, false);
                                textY += 9;
                            }
                        }
                    }
                    selected = value;
                    this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, itemW, itemH, this::lambda$renderWaitChatHistoryList$156 /* captured: selected */));
                }
            }
        }
        chatViewport.endRender(ctx);
    }

    private List<class_5481> wrapWaitChatDisplayLines(MacroExecutor.RecentChatMessage entry, int maxWidth, int maxLines) {
        class_2561 display = entry != null && entry.displayComponent() != null ? entry.displayComponent() : class_2561.method_43470(this.formatWaitChatHistoryEntry(entry));
        List<class_5481> wrapped = this.textRenderer.method_1728(display, Math.max(20, maxWidth));
        if (wrapped.size() <= maxLines) {
            return wrapped;
        }
        return new ArrayList(wrapped.subList(0, Math.max(0, maxLines)));
    }

    private List<String> wrapWaitChatLines(String text, int maxWidth, int maxLines) {
        List<String> lines = new ArrayList();
        if (text == null || text.isBlank() || maxLines <= 0) {
            return lines;
        }
        String[] words = text.trim().split("\\s+");
        StringBuilder current = new StringBuilder();
        for (int wordIndex = 0; wordIndex < words.length; wordIndex++) {
            String word = words[wordIndex];
            String candidate = current.isEmpty() ? word : String.valueOf(current) + " " + word;
            if (this.uiWidth(candidate) <= maxWidth) {
                current.setLength(0);
                current.append(candidate);
            } else {
                if (!current.isEmpty()) {
                    if (lines.size() == maxLines - 1) {
                        lines.add(this.trimWaitChatLine(String.valueOf(current) + " " + this.joinWaitChatWords(words, wordIndex), maxWidth));
                        return lines;
                    }
                    lines.add(current.toString());
                    current.setLength(0);
                    current.append(word);
                } else {
                    if (lines.size() == maxLines - 1) {
                        lines.add(this.trimWaitChatLine(this.joinWaitChatWords(words, wordIndex), maxWidth));
                        return lines;
                    }
                    lines.add(this.trimWaitChatLine(word, maxWidth));
                }
            }
        }
        if (!current.isEmpty()) {
            if (lines.size() < maxLines) {
                lines.add(current.toString());
            }
        }
        return lines;
    }

    private String joinWaitChatWords(String[] words, int startIndex) {
        StringBuilder out = new StringBuilder();
        for (int i = startIndex; i < words.length; i++) {
            if (!out.length() > 0) continue;
            out.append(32);
            out.append(words[i]);
        }
        return out.toString();
    }

    private String trimWaitChatLine(String text, int maxWidth) {
        String trimmed = text == null ? "" : text;
        while (!trimmed.isEmpty()) {
            if (this.uiWidth(trimmed + "...") <= maxWidth) break;
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed.length() < text == null ? 0 : text.length() ? trimmed + "..." : trimmed;
    }

    private void renderDelayPacketsPanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        int cy = bodyTop + 4;
        int halfW = (w - 4) / 2;
        List<String> c2sTargets = this.getDelayPacketTargets(true);
        List<String> s2cTargets = this.getDelayPacketTargets(false);
        cy = this.renderFieldByKey(ctx, "mode", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "flushOnDisable", x, cy, w, mx, my, delta);
        String mode = this.currentEnumValue("mode");
        if ("ENABLE".equals(mode)) {
            this.renderActionButton(ctx, x, cy, halfW, 14, "Choose C2S (" + c2sTargets.size() + ")", mx, my, this::lambda$renderDelayPacketsPanel$157);
            this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Choose S2C (" + s2cTargets.size() + ")", mx, my, this::lambda$renderDelayPacketsPanel$158);
            cy += 18;
            this.renderActionButton(ctx, x, cy, halfW, 14, "Load Queue", mx, my, this::loadDelayPacketTargetsFromQueue);
            this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Clear All", mx, my, this::clearAllDelayPacketTargets);
            cy += 18;
            this.renderActionButton(ctx, x, cy, halfW, 14, "Default Preset", mx, my, this::applyDefaultDelayPacketPreset);
            this.renderActionButton(ctx, x + halfW + 4, cy, halfW, 14, "Module Preset", mx, my, this::applyModuleDelayPacketPreset);
        }
    }

    private List<String> getDelayPacketTargets(boolean c2s) {
        return (List)this.stringLists.computeIfAbsent(c2s ? "c2sPackets" : "s2cPackets", ActionEditorOverlay::lambda$getDelayPacketTargets$159);
    }

    private void openDelayPacketSelector(boolean c2s) {
        if (c2s) {
            this.packetSelectorOverlay.openToggleC2S(this::lambda$openDelayPacketSelector$160, this.getSelectedDelayPacketClasses(true));
        } else {
            this.packetSelectorOverlay.openToggleS2C(this::lambda$openDelayPacketSelector$161, this.getSelectedDelayPacketClasses(false));
        }
    }

    private List<Class<? extends class_2596<?>>> getSelectedDelayPacketClasses(boolean c2s) {
        List<Class<? extends class_2596<?>>> selected = new ArrayList();
        var var3 = this.getDelayPacketTargets(c2s).iterator();
        while (var3.hasNext()) {
            String target = (String)var3.next();
            Class<? extends class_2596<?>> packetClass = this.resolveDelayPacketClass(target, c2s);
            if (packetClass != null) {
                if (selected.contains(packetClass)) continue;
                selected.add(packetClass);
            }
        }
        return selected;
    }

    private Class<? extends class_2596<?>> resolveDelayPacketClass(String target, boolean c2s) {
        if (target == null || target.isBlank()) {
            return null;
        }
        List<Class<? extends class_2596<?>>> pool = c2s ? new ArrayList(PackUtilPacketRegistry.getC2SPackets()) : new ArrayList(PackUtilPacketRegistry.getS2CPackets());
        var var4 = pool.iterator();
        while (var4.hasNext()) {
            Class<? extends class_2596<?>> candidate = (Class)var4.next();
            String registryName = PackUtilPacketRegistry.getName(candidate);
            if (!this.packetNameMatches(target, registryName)) continue;
            return candidate;
            if (!this.packetNameMatches(target, PackUtilPacketNamer.getFriendlyName(candidate))) continue;
            return candidate;
            if (!this.packetNameMatches(target, candidate.getSimpleName())) continue;
            return candidate;
        }
        return null;
    }

    private void setDelayPacketSelected(boolean c2s, Class<? extends class_2596<?>> packetClass, boolean selected) {
        if (packetClass == null) {
            return;
        }
        List<String> targets = this.getDelayPacketTargets(c2s);
        if (selected) {
            if (!this.containsDelayPacketTarget(targets, packetClass, c2s)) {
                targets.add(PackUtilPacketNamer.getFriendlyName(packetClass));
            }
            return;
        }
        targets.removeIf(this::lambda$setDelayPacketSelected$162 /* captured: packetClass, c2s */);
    }

    private boolean containsDelayPacketTarget(List<String> targets, Class<? extends class_2596<?>> packetClass, boolean c2s) {
        if (targets == null || packetClass == null) {
            return false;
        }
        var var4 = targets.iterator();
        while (var4.hasNext()) {
            String target = (String)var4.next();
            if (!packetClass.equals(this.resolveDelayPacketClass(target, c2s))) continue;
            return true;
        }
        return false;
    }

    private void loadDelayPacketTargetsFromQueue() {
        List<PackUtilSharedState.QueuedPacket> queue = PackUtilSharedState.get().getDelayedPackets();
        if (queue == null || queue.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("Queue is empty");
            return;
        }
        int before = this.getDelayPacketTargets(true).size() + this.getDelayPacketTargets(false).size();
        int after = queue.iterator();
        while (after.hasNext()) {
            QueuedPacket queuedPacket = (PackUtilSharedState.QueuedPacket)after.next();
            if (queuedPacket == null) continue;
            while (queuedPacket.packet == null) {
            }
            Class<? extends class_2596<?>> packetClass = queuedPacket.packet.getClass();
            if (PackUtilPacketRegistry.getC2SPackets().contains(packetClass)) {
                this.setDelayPacketSelected(true, packetClass, true);
            } else {
                if (!PackUtilPacketRegistry.getS2CPackets().contains(packetClass)) continue;
                this.setDelayPacketSelected(false, packetClass, true);
            }
        }
        after = this.getDelayPacketTargets(true).size() + this.getDelayPacketTargets(false).size();
        added = Math.max(0, after - before);
        PackUtilClientMessaging.sendPrefixed(added == 0 ? "Queue did not add any new packet filters" : "Added " + added + " packet filter" + added == 1 ? "" : "s" + " from queue");
    }

    private void clearAllDelayPacketTargets() {
        this.getDelayPacketTargets(true).clear();
        this.getDelayPacketTargets(false).clear();
    }

    private void applyDefaultDelayPacketPreset() {
        DelayPacketsAction tmp = new DelayPacketsAction();
        tmp.applyDefaultPreset();
        this.stringLists.put("c2sPackets", new ArrayList(tmp.c2sPacketNames));
        this.stringLists.put("s2cPackets", new ArrayList(tmp.s2cPacketNames));
    }

    private void applyModuleDelayPacketPreset() {
        DelayPacketsAction tmp = new DelayPacketsAction();
        tmp.applyModulePreset();
        this.stringLists.put("c2sPackets", new ArrayList(tmp.c2sPacketNames));
        this.stringLists.put("s2cPackets", new ArrayList(tmp.s2cPacketNames));
    }

    private String buildDelayPacketDirectionSummary(boolean c2s) {
        String direction = c2s ? "C2S" : "S2C";
        List<String> targets = this.getDelayPacketTargets(c2s);
        if (targets.isEmpty()) {
            return direction + ": none";
        }
        List<String> labels = new ArrayList();
        for (int i = 0; i < targets.size(); i++) {
            if (i >= 3) break;
            String target = (String)targets.get(i);
            Class<? extends class_2596<?>> packetClass = this.resolveDelayPacketClass(target, c2s);
            labels.add(packetClass != null ? PackUtilPacketNamer.getFriendlyName(packetClass) : target);
        }
        summary = direction + ": " + targets.size();
        if (!labels.isEmpty()) {
            summary = summary + " - " + String.join(", ", labels);
        }
        if (targets.size() > labels.size()) {
            summary = summary + ", +" + targets.size() - labels.size();
        }
        return summary;
    }

    private int renderDelayPacketPicker(class_332 ctx, int x, int y, int w, int mx, int my, float delta, boolean c2s) {
        String key = c2s ? "c2sPackets" : "s2cPackets";
        String searchKey = c2s ? "_delay_packets_c2s_search" : "_delay_packets_s2c_search";
        String title = c2s ? "C2S Packets" : "S2C Packets";
        List<String> selected = (List)this.stringLists.getOrDefault(key, Collections.emptyList());
        Objects.requireNonNull(selected);
        y = this.renderSimpleSelectedList(ctx, x, y, w, mx, my, key + "_selected", title, selected, selected::remove, ActionEditorOverlay::lambda$renderDelayPacketPicker$163, "(none selected)");
        PackUtilChatField search = (PackUtilChatField)this.addFields.get(searchKey);
        if (search != null) {
            search.setX(x);
            search.setY(y + 1);
            search.setWidth(w);
            search.render(ctx, mx, my, delta);
        }
        y += 18;
        String filter = search != null ? search.getText().trim().toLowerCase(Locale.ROOT) : "";
        List<String> options = new ArrayList();
        var var16 = this.getPacketNames(c2s).iterator();
        while (var16.hasNext()) {
            String packetName = (String)var16.next();
            if (!filter.isEmpty() || packetName.toLowerCase(Locale.ROOT).contains(filter)) continue;
            options.add(packetName);
        }
        Objects.requireNonNull(selected);
        this.renderSearchRegistryList(ctx, x, y, w, mx, my, key + "_search", options, 5, ActionEditorOverlay::lambda$renderDelayPacketPicker$164 /* captured: selected */, selected::contains, ActionEditorOverlay::lambda$renderDelayPacketPicker$165);
        return y + 65 + 4;
    }

    private void renderMinePanel(class_332 ctx, int x, int bodyTop, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int cy = bodyTop + 4;
        cy = this.renderFieldByKey(ctx, "targetBlocks", x, cy, w, mx, my, delta);
        cy += 4;
        cy = this.renderFieldByKey(ctx, "stopInventoryFull", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "stopSlotsUsed", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "slotsUsedThreshold", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "stopMinedCount", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "minedCountTarget", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "stopAfterTime", x, cy, w, mx, my, delta);
        cy = this.renderFieldByKey(ctx, "timeoutSeconds", x, cy, w, mx, my, delta);
        this.renderEditorHint(ctx, x, cy, w, "Pick target blocks, then choose the stop rule you want.");
    }

    private void fillUseItemFromHeld() {
        if (MC.field_1724 == null) {
            return;
        }
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("itemName");
        if (field == null) {
            return;
        }
        if (MC.field_1724.method_6047().method_7960()) {
            field.setText("");
            this.editorItemFields.remove("itemName");
            return;
        }
        ItemTarget target = ItemTarget.capture(MC.field_1724.method_6047(), MC.field_1724.method_31548().method_67532());
        this.editorItemFields.put("itemName", target);
        field.setText(target.editorText());
    }

    private void fillSelectSlotFromHeld() {
        if (MC.field_1724 == null) {
            return;
        }
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("itemName");
        if (field == null) {
            return;
        }
        if (MC.field_1724.method_6047().method_7960()) {
            field.setText("");
            this.editorItemFields.remove("itemName");
            return;
        }
        ItemTarget target = ItemTarget.capture(MC.field_1724.method_6047(), MC.field_1724.method_31548().method_67532());
        this.editorItemFields.put("itemName", target);
        field.setText(target.editorText());
    }

    private void clearSelectSlotItemName() {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("itemName");
        if (field != null) {
            field.setText("");
        }
        this.editorItemFields.remove("itemName");
    }

    private int getSelectSlotHotbarIndex() {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("slot");
        if (field == null) {
            return 0;
        }
        try {
            return Math.max(0, Math.min(8, Integer.parseInt(field.getText().trim())));
        }
        catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private void setSelectSlotHotbarIndex(int slot) {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("slot");
        if (field != null) {
            field.setText(String.valueOf(Math.max(0, Math.min(8, slot))));
        }
    }

    private String buildSelectSlotSummary() {
        int fallbackSlot = this.getSelectSlotHotbarIndex() + 1;
        PackUtilChatField itemField = (PackUtilChatField)this.textFields.get("itemName");
        String itemName = itemField != null ? itemField.getText().trim() : "";
        return itemName.isEmpty() ? "Uses hotbar slot " + fallbackSlot + "." : "Uses the named item, else slot " + fallbackSlot + ".";
    }

    private String currentUseItemTargetLabel() {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("itemName");
        String item = field != null ? field.getText().trim() : "";
        return item.isEmpty() ? "the held item" : "the named item";
    }

    private void toggleWaitCooldownHand() {
        this.toggleStates.put("checkMainHand", !((Boolean)this.toggleStates.getOrDefault("checkMainHand", true)).booleanValue());
    }

    private String currentWaitCooldownHandLabel() {
        return ((Boolean)this.toggleStates.getOrDefault("checkMainHand", true)).booleanValue() ? "Hand: Main" : "Hand: Off";
    }

    private void fillWaitCooldownFromHeld() {
        if (MC.field_1724 == null) {
            return;
        }
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("itemName");
        if (field == null) {
            return;
        }
        if (MC.field_1724.method_6047().method_7960()) {
            field.setText("");
            this.editorItemFields.remove("itemName");
            return;
        }
        ItemTarget target = ItemTarget.capture(MC.field_1724.method_6047(), MC.field_1724.method_31548().method_67532());
        this.editorItemFields.put("itemName", target);
        field.setText(target.editorText());
    }

    private void clearWaitCooldownItemName() {
        PackUtilChatField field = (PackUtilChatField)this.textFields.get("itemName");
        if (field != null) {
            field.setText("");
        }
        this.editorItemFields.remove("itemName");
    }

    private void fillRotateFromCurrentView() {
        if (MC.field_1724 == null) {
            return;
        }
        PackUtilChatField yawField = (PackUtilChatField)this.textFields.get("yaw");
        PackUtilChatField pitchField = (PackUtilChatField)this.textFields.get("pitch");
        if (yawField != null) {
            yawField.setText(ActionEditorOverlay.fmtDouble((double)MC.field_1724.method_36454()));
        }
        if (pitchField != null) {
            pitchField.setText(ActionEditorOverlay.fmtDouble((double)MC.field_1724.method_36455()));
        }
    }

    private void fillGoToFromPlayer() {
        if (MC.field_1724 == null) {
            return;
        }
        PackUtilChatField xField = (PackUtilChatField)this.textFields.get("pos_0");
        PackUtilChatField yField = (PackUtilChatField)this.textFields.get("pos_1");
        PackUtilChatField zField = (PackUtilChatField)this.textFields.get("pos_2");
        if (xField != null) {
            xField.setText(ActionEditorOverlay.fmtDouble(MC.field_1724.method_23317()));
        }
        if (yField != null) {
            yField.setText(ActionEditorOverlay.fmtDouble(MC.field_1724.method_23318()));
        }
        if (zField != null) {
            zField.setText(ActionEditorOverlay.fmtDouble(MC.field_1724.method_23321()));
        }
    }

    private String buildWaitCooldownSummary() {
        PackUtilChatField itemField = (PackUtilChatField)this.textFields.get("itemName");
        String itemName = itemField != null ? itemField.getText().trim() : "";
        String handLabel = ((Boolean)this.toggleStates.getOrDefault("checkMainHand", true)).booleanValue() ? "main hand" : "off hand";
        if (itemName.isEmpty()) {
            return "Waits for the " + handLabel + " cooldown.";
        }
        return "Waits for the named item cooldown.";
    }

    private void swapSwapSlotEndpoints() {
        boolean fromUseName = ((Boolean)this.toggleStates.getOrDefault("fromUseItemName", false)).booleanValue();
        boolean toUseName = ((Boolean)this.toggleStates.getOrDefault("toUseItemName", false)).booleanValue();
        String fromItem = this.textFields.containsKey("fromItemName") ? ((PackUtilChatField)this.textFields.get("fromItemName")).getText() : "";
        String toItem = this.textFields.containsKey("toItemName") ? ((PackUtilChatField)this.textFields.get("toItemName")).getText() : "";
        String fromSlot = this.textFields.containsKey("fromSlot") ? ((PackUtilChatField)this.textFields.get("fromSlot")).getText() : "";
        String toSlot = this.textFields.containsKey("toSlot") ? ((PackUtilChatField)this.textFields.get("toSlot")).getText() : "";
        this.toggleStates.put("fromUseItemName", toUseName);
        this.toggleStates.put("toUseItemName", fromUseName);
        PackUtilChatField fromItemField = (PackUtilChatField)this.textFields.get("fromItemName");
        PackUtilChatField toItemField = (PackUtilChatField)this.textFields.get("toItemName");
        PackUtilChatField fromSlotField = (PackUtilChatField)this.textFields.get("fromSlot");
        PackUtilChatField toSlotField = (PackUtilChatField)this.textFields.get("toSlot");
        if (fromItemField != null) {
            fromItemField.setText(toItem);
        }
        if (toItemField != null) {
            toItemField.setText(fromItem);
        }
        if (fromSlotField != null) {
            fromSlotField.setText(toSlot);
        }
        if (toSlotField != null) {
            toSlotField.setText(fromSlot);
        }
    }

    private String buildSwapSlotsSummary() {
        return "Swaps the two targets. Name mode uses the first visible match.";
    }

    private String buildClickSummary() {
        String clickType = this.currentEnumValue("clickType");
        var var2 = clickType;
        int var3 = -1;
        switch (var2.hashCode()) {
            case 2332679::
                if (var2.equals("LEFT")) {
                    var3 = 0;
                }
            default:
                switch (var3) {
                    case 0::
                        return "Left click acts on your target.";
                    default:
                        return "Right click uses your target.";
                }
        }
    }

    private String buildWaitSlotSummary(String waitMode) {
        var var2 = waitMode;
        int var3 = -1;
        switch (var2.hashCode()) {
            case 1810362840::
                if (!var2.equals("IS_EMPTY")) { /* goto @109; */ }
                var3 = 0;
                /* goto @109; */
            case 851903629::
                if (!var2.equals("COUNT_AT_LEAST")) { /* goto @109; */ }
                var3 = 1;
                /* goto @109; */
            case 1027842241::
                if (!var2.equals("COUNT_BELOW")) { /* goto @109; */ }
                var3 = 2;
                /* goto @109; */
            case 1755457923::
                if (var2.equals("ANY_CHANGE")) {
                    var3 = 3;
                }
            default:
                switch (var3) {
                    case 0::
                        return "Waits until the slot (or any slot) is empty.";
                    case 1::
                        return "Waits until the slot/item hits the target count.";
                    case 2::
                        return "Waits until the slot/item drops below the count.";
                    case 3::
                        return "Waits for the first change in the specified slot.";
                    default:
                        return "Waits until the slot or item is present. -1 scans all slots.";
                }
        }
    }

    private int renderFieldByKey(class_332 ctx, String key, int x, int y, int w, int mx, int my, float delta) {
        FieldDef field = this.getField(key);
        if (field == null || !this.isFieldVisible(field)) {
            return y;
        }
        this.renderRow(ctx, field, x, y, w, mx, my, delta);
        return y + this.rowH(field) + 2;
    }

    private FieldDef getField(String key) {
        if (this.schema == null) {
            return null;
        }
        var var2 = this.schema.fields().iterator();
        while (var2.hasNext()) {
            FieldDef field = (FieldDef)var2.next();
            if (!field.key().equals(key)) continue;
            return field;
        }
        return null;
    }

    private <T> int renderSimpleSelectedList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, String label, List<T> values, Consumer<T> removeAction, Function<T, String> formatter, String emptyLabel) {
        Objects.requireNonNull(values);
        return this.renderSimpleSelectedList(ctx, x, y, w, mx, my, listKey, label, values, removeAction, formatter, ActionEditorOverlay::lambda$renderSimpleSelectedList$166, values::clear, emptyLabel, false);
    }

    private <T> int renderSimpleSelectedList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, String label, List<T> values, Consumer<T> removeAction, Function<T, String> formatter, Function<T, class_2561> richFormatter, String emptyLabel) {
        Objects.requireNonNull(values);
        return this.renderSimpleSelectedList(ctx, x, y, w, mx, my, listKey, label, values, removeAction, formatter, richFormatter, values::clear, emptyLabel, false);
    }

    private <T> int renderSimpleSelectedList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, String label, List<T> values, Consumer<T> removeAction, Function<T, String> formatter, Function<T, class_2561> richFormatter, Runnable clearAction, String emptyLabel) {
        return this.renderSimpleSelectedList(ctx, x, y, w, mx, my, listKey, label, values, removeAction, formatter, richFormatter, clearAction, emptyLabel, false);
    }

    private <T> int renderSimpleSelectedList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, String label, List<T> values, Consumer<T> removeAction, Function<T, String> formatter, Function<T, class_2561> richFormatter, Runnable clearAction, String emptyLabel, boolean editable) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        int headerBtnW = 44;
        int editIdx = editable ? (Integer)this.stringListEditIndex.getOrDefault(listKey, -1) : -1;
        if (editIdx >= values.size()) {
            editIdx = -1;
            this.stringListEditIndex.put(listKey, -1);
        }
        PackUiText.draw(ctx, this.textRenderer, label + " (" + values.size() + ")", font, PackUtilColors.textSecondary(), x, y + 2, false);
        boolean canClear = !values.isEmpty();
        int clearX = x + w - headerBtnW;
        this.renderOverlayButton(ctx, clearX, y, headerBtnW, 14, "Clear", PackUiOverlayButton.Variant.DANGER, canClear, mx, my, this::lambda$renderSimpleSelectedList$167 /* captured: clearAction, listKey */);
        y += 13;
        int listH = 60;
        int itemW = w - 5 - 1;
        PackUiScrollViewport simpleViewport = this.getOrCreateViewport(this.selectedScrollViewports, listKey, x, y, w, listH, 15, 5);
        simpleViewport.setContentHeight(values.size() * 15);
        this.selectedListBounds.put(listKey, y, listH);
        simpleViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (values.isEmpty()) {
            ctx.method_25294(x, y, x + itemW, y + 12, PackUtilColors.rowNormal());
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, emptyLabel, x, y, itemW);
            return y + listH + 4;
        }
        simpleViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
        int first = simpleViewport.getFirstVisibleRow();
        for (int i = first; i < values.size(); i++) {
            if (i > simpleViewport.getLastVisibleRow()) break;
            int iy = simpleViewport.getRowScreenY(i);
            if (iy == -2147483648) {
            } else {
                T value = values.get(i);
                int removeW = 13;
                int rowW = itemW - removeW - 2;
                boolean selected = editable && i == editIdx;
                boolean hovered = mx >= x && mx < x + rowW && my >= iy && my < iy + 13;
                class_2561 richLabel = richFormatter == null ? null : (class_2561)richFormatter.apply(value);
                if (richLabel != null) {
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, richLabel, x, iy, rowW, 13, hovered, selected, PackUiListRenderer.RowTone.NORMAL, true);
                } else {
                    PackUiListRenderer.drawRow(ctx, this.textRenderer, (String)formatter.apply(value), x, iy, rowW, 13, hovered, selected, PackUiListRenderer.RowTone.NORMAL);
                }
                if (!editable) { /* goto L627; */ }
                int fi = i;
                String rawValue = (String)value;
                String rawText = value instanceof String ? rawValue : (String)formatter.apply(value);
                this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, rowW, 13, this::lambda$renderSimpleSelectedList$168 /* captured: listKey, fi, rawText */));
                L627: ;
                removeX = x + rowW + 2;
                fi2 = i;
                this.renderIconDeleteButton(ctx, removeX, iy, removeW, mx, my, this::lambda$renderSimpleSelectedList$169 /* captured: removeAction, values, fi2, editable, listKey */);
            }
        }
        simpleViewport.endRender(ctx);
        return y + listH + 4;
    }

    private <T> void renderSearchRegistryList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, List<T> values, int visibleRows, Consumer<T> clickAction, Function<T, String> formatter) {
        this.renderSearchRegistryList(ctx, x, y, w, mx, my, listKey, values, visibleRows, clickAction, ActionEditorOverlay::lambda$renderSearchRegistryList$170, formatter);
    }

    private <T> void renderSearchRegistryList(class_332 ctx, int x, int y, int w, int mx, int my, String listKey, List<T> values, int visibleRows, Consumer<T> clickAction, Predicate<T> selectedPredicate, Function<T, String> formatter) {
        int rowH = 13;
        int listH = visibleRows * rowH;
        int itemW = w - 5 - 1;
        PackUiScrollViewport regViewport = this.getOrCreateViewport(this.catalogScrollViewports, listKey, x, y, w, listH, rowH, 5);
        regViewport.setContentHeight(values.size() * rowH);
        this.catalogListBounds.put(listKey, y, listH);
        regViewport.renderScrollbar(ctx, (double)mx, (double)my);
        if (values.isEmpty()) {
            ctx.method_25294(x, y, x + itemW, y + 12, PackUtilColors.rowNormal());
            PackUiListRenderer.drawEmptyState(ctx, this.textRenderer, "No matches", x, y, itemW);
            return;
        }
        regViewport.beginRender(ctx, this.theme.borderSoft(), 905969664);
        int first = regViewport.getFirstVisibleRow();
        for (int i = first; i < values.size(); i++) {
            if (i > regViewport.getLastVisibleRow()) break;
            int iy = regViewport.getRowScreenY(i);
            if (iy == -2147483648) {
            } else {
                T value = values.get(i);
                String display = (String)formatter.apply(value);
                boolean selected = selectedPredicate != null && selectedPredicate.test(value);
                boolean hovered = mx >= x && mx < x + itemW && my >= iy && my < iy + rowH;
                PackUiListRenderer.drawRow(ctx, this.textRenderer, display, x, iy, itemW, rowH, hovered, selected, selected ? PackUiListRenderer.RowTone.READY : PackUiListRenderer.RowTone.NORMAL);
                T clickedValue = value;
                this.hitRegions.add(new ActionEditorOverlay.HitRegion(x, iy, itemW, rowH, ActionEditorOverlay::lambda$renderSearchRegistryList$171 /* captured: clickAction, clickedValue */));
            }
        }
        regViewport.endRender(ctx);
    }

    private void startWaitEntityCapture() {
        if (!(this.targetAction instanceof WaitForEntityAction)) {
            return;
        }
        class_437 previousScreen = MC.field_1755;
        this.enterEditorOnlyCaptureMode();
        PackUtilSharedState state = PackUtilSharedState.get();
        state.setCaptureCancelCallback(this::lambda$startWaitEntityCapture$172 /* captured: previousScreen, state */);
        MC.execute(ActionEditorOverlay::lambda$startWaitEntityCapture$173);
        state.setEntityCaptureSpecific(this.entitySpecificCaptureMode);
        state.setEntityCaptureCallback(this::lambda$startWaitEntityCapture$176 /* captured: previousScreen */);
    }

    private static String trimMinecraftPrefix(String value) {
        return PackUtilRegistryLabels.stripNamespace(value);
    }

    private String formatEntityEntry(String entry) {
        if (entry == null || entry.isBlank()) {
            return "(unknown)";
        }
        if (!entry.startsWith("~")) { /* goto L184; */ }
        String[] parts = entry.split("~", 4);
        String rawName = parts.length >= 4 ? parts[3] : "";
        String type = parts.length >= 3 ? PackUtilRegistryLabels.entity(parts[2]) : "?";
        String uuid = parts.length >= 2 ? parts[1] : "";
        String suffix = uuid.length() >= 4 ? uuid.substring(uuid.length() - 4) : uuid;
        String name = rawName == null ? "" : rawName.trim();
        if (name.isEmpty() || name.equalsIgnoreCase(type) || name.equalsIgnoreCase(ActionEditorOverlay.trimMinecraftPrefix(type))) {
            return type + " #" + suffix;
        }
        return name + " (" + type + " #" + suffix + ")";
        L184: ;
        return PackUtilRegistryLabels.entity(entry);
    }

    private List<String> getNearbyEntityEntries() {
        boolean supportedAction = this.targetAction instanceof WaitForEntityAction || this.targetAction instanceof LookAtBlockAction || this.targetAction instanceof OpenContainerAction;
        if (!supportedAction || MC.field_1724 == null || MC.field_1687 == null) {
            return Collections.emptyList();
        }
        boolean openContainerAction = this.targetAction instanceof OpenContainerAction;
        List<String> result = new ArrayList();
        var var4 = MC.field_1687.method_18112().iterator();
        while (var4.hasNext()) {
            class_1297 entity = (class_1297)var4.next();
            while (entity == MC.field_1724) {
            }
            while ((double)MC.field_1724.method_5739(entity) > 16) {
            }
            while (openContainerAction) {
                if (this.canOpenContainerEntity(entity)) break;
            }
            String typeId = class_7923.field_41177.method_10221(entity.method_5864()).toString();
            String uuid = entity.method_5845();
            String displayName = entity.method_5476().getString().replaceAll("§.", "").trim();
            result.add("~" + uuid + "~" + typeId + "~" + displayName);
        }
        result.sort(Comparator.comparingDouble(this::distanceForNearbyEntityEntry));
        return result;
    }

    private boolean canOpenContainerEntity(class_1297 entity) {
        if (entity == null) {
            return false;
        }
        return entity instanceof class_1693 || entity instanceof class_7264 || entity instanceof class_1496;
    }

    private double distanceForNearbyEntityEntry(String entry) {
        if (MC.field_1724 == null || entry == null || !entry.startsWith("~")) {
            return 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        }
        String[] parts = entry.split("~", 4);
        if (parts.length < 2 || MC.field_1687 == null) {
            return 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        }
        try {
            UUID uuid = UUID.fromString(parts[1]);
            class_1297 entity = MC.field_1687.method_66347(uuid);
            return entity != null ? (double)MC.field_1724.method_5739(entity) : 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        }
        catch (Exception ignored) {
            return 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        }
    }

    private String extractEntityTypeFromNearbyEntry(String entry) {
        if (entry == null || !entry.startsWith("~")) {
            return "";
        }
        String[] parts = entry.split("~", 4);
        return parts.length >= 3 ? parts[2] : "";
    }

    private String entitySpecificEntryPrefix(String entry) {
        if (entry == null || !entry.startsWith("~")) {
            return "";
        }
        String[] parts = entry.split("~", 4);
        return parts.length >= 2 ? "~" + parts[1] + "~" : "";
    }

    private String formatNearbyEntityEntry(String entry) {
        String label = this.formatEntityEntry(entry);
        double dist = this.distanceForNearbyEntityEntry(entry);
        if (dist == 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) {
            return label;
        }
        return label + " (" + String.format(Locale.ROOT, "%.1fm", dist) + ")";
    }

    private List<class_2338> getNearbyContainerPositions() {
        if (MC.field_1724 == null || MC.field_1687 == null) {
            return Collections.emptyList();
        }
        class_2338 center = MC.field_1724.method_24515();
        List<class_2338> found = new ArrayList();
        int range = 10;
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    class_3908 factory = MC.field_1687.method_8320(pos).method_26196(MC.field_1687, pos);
                    if (factory == null) continue;
                    found.add(pos);
                }
            }
        }
        Objects.requireNonNull(center);
        found.sort(Comparator.comparingDouble(center::method_10262));
        return found;
    }

    private String formatContainerEntry(class_2338 pos) {
        if (pos == null) {
            return "(unknown)";
        }
        String blockName = MC.field_1687 != null ? MC.field_1687.method_8320(pos).method_26204().method_9518().getString() : "Container";
        return blockName + " (" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + ")";
    }

    private void fillBlockPosField(String fieldKey, class_2338 pos) {
        if (fieldKey == null || pos == null) {
            return;
        }
        PackUtilChatField fx = (PackUtilChatField)this.textFields.get(fieldKey + "_0");
        PackUtilChatField fy = (PackUtilChatField)this.textFields.get(fieldKey + "_1");
        PackUtilChatField fz = (PackUtilChatField)this.textFields.get(fieldKey + "_2");
        if (fx != null) {
            fx.setText(String.valueOf(pos.method_10263()));
        }
        if (fy != null) {
            fy.setText(String.valueOf(pos.method_10264()));
        }
        if (fz != null) {
            fz.setText(String.valueOf(pos.method_10260()));
        }
    }

    private boolean isCurrentBlockPosField(String fieldKey, class_2338 pos) {
        if (fieldKey == null || pos == null) {
            return false;
        }
        PackUtilChatField fx = (PackUtilChatField)this.textFields.get(fieldKey + "_0");
        PackUtilChatField fy = (PackUtilChatField)this.textFields.get(fieldKey + "_1");
        PackUtilChatField fz = (PackUtilChatField)this.textFields.get(fieldKey + "_2");
        if (fx == null || fy == null || fz == null) {
            return false;
        }
        try {
            int x = (int)Math.round(Double.parseDouble(fx.getText().trim()));
            int y = (int)Math.round(Double.parseDouble(fy.getText().trim()));
            int z = (int)Math.round(Double.parseDouble(fz.getText().trim()));
            return x == pos.method_10263() && y == pos.method_10264() && z == pos.method_10260();
        }
        catch (NumberFormatException ignored) {
            return false;
        }
    }

    private List<String> getOrCreateWaitPacketTargets() {
        return (List)this.stringLists.computeIfAbsent("packetNames", ActionEditorOverlay::lambda$getOrCreateWaitPacketTargets$177);
    }

    private List<String> sanitizeWaitPacketTargets(List<String> rawTargets) {
        List<String> sanitized = new ArrayList();
        var var3 = (rawTargets == null ? Collections.emptyList() : rawTargets).iterator();
        while (var3.hasNext()) {
            String rawTarget = (String)var3.next();
            String normalized = this.normalizeWaitPacketTarget(rawTarget);
            if (!normalized.isEmpty()) {
                if (sanitized.contains(normalized)) continue;
                sanitized.add(normalized);
            }
        }
        return sanitized;
    }

    private String normalizeWaitPacketTarget(String target) {
        String normalized = WaitForPacketAction.normalizeTarget(target);
        if (normalized.isEmpty()) {
            return "";
        }
        if (!WaitForPacketAction.getDirection(normalized).isEmpty()) {
            return normalized;
        }
        Class<? extends class_2596<?>> packetClass = this.resolvePacketClassForTarget("", normalized);
        if (packetClass == null) {
            return normalized;
        }
        if (PackUtilPacketRegistry.getC2SPackets().contains(packetClass)) {
            return this.buildWaitPacketTarget("C2S", packetClass);
        }
        if (PackUtilPacketRegistry.getS2CPackets().contains(packetClass)) {
            return this.buildWaitPacketTarget("S2C", packetClass);
        }
        return normalized;
    }

    private List<String> getWaitPacketTargets(String direction) {
        List<String> filtered = new ArrayList();
        var var3 = this.getOrCreateWaitPacketTargets().iterator();
        while (var3.hasNext()) {
            String target = (String)var3.next();
            String normalized = this.normalizeWaitPacketTarget(target);
            if (!normalized.isEmpty()) {
                if (!direction.equalsIgnoreCase(WaitForPacketAction.getDirection(normalized))) continue;
                filtered.add(normalized);
            }
        }
        return filtered;
    }

    private String formatWaitPacketTarget(String target) {
        return WaitForPacketAction.getDisplayLabel(target);
    }

    private void clearWaitPacketTargets(String direction) {
        this.getOrCreateWaitPacketTargets().removeIf(this::lambda$clearWaitPacketTargets$178 /* captured: direction */);
        PackUiScrollViewport vpC2s = (PackUiScrollViewport)this.selectedScrollViewports.get("wait_packet_c2s");
        if (vpC2s != null) {
            vpC2s.jumpTo(0);
        }
        PackUiScrollViewport vpS2c = (PackUiScrollViewport)this.selectedScrollViewports.get("wait_packet_s2c");
        if (vpS2c != null) {
            vpS2c.jumpTo(0);
        }
    }

    private void removeWaitPacketTarget(String target) {
        String normalized = this.normalizeWaitPacketTarget(target);
        if (normalized.isEmpty()) {
            return;
        }
        this.getOrCreateWaitPacketTargets().removeIf(this::lambda$removeWaitPacketTarget$179 /* captured: normalized */);
    }

    private void openWaitPacketSelector(boolean c2s) {
        if (c2s) {
            this.packetSelectorOverlay.openToggleC2S(this::lambda$openWaitPacketSelector$180, this.getSelectedWaitPacketClasses("C2S"));
        } else {
            this.packetSelectorOverlay.openToggleS2C(this::lambda$openWaitPacketSelector$181, this.getSelectedWaitPacketClasses("S2C"));
        }
    }

    private List<Class<? extends class_2596<?>>> getSelectedWaitPacketClasses(String direction) {
        List<Class<? extends class_2596<?>>> selected = new ArrayList();
        var var3 = this.getWaitPacketTargets(direction).iterator();
        while (var3.hasNext()) {
            String target = (String)var3.next();
            Class<? extends class_2596<?>> packetClass = this.resolvePacketClassForTarget(direction, target);
            if (packetClass != null) {
                if (selected.contains(packetClass)) continue;
                selected.add(packetClass);
            }
        }
        return selected;
    }

    private void setWaitPacketTargetSelected(String direction, Class<? extends class_2596<?>> packetClass, boolean selected) {
        String target = this.buildWaitPacketTarget(direction, packetClass);
        if (target.isEmpty()) {
            return;
        }
        List<String> targets = this.getOrCreateWaitPacketTargets();
        if (selected) {
            Objects.requireNonNull(target);
            if (!targets.stream().map(this::normalizeWaitPacketTarget).anyMatch(target::equals)) {
                targets.add(target);
            }
            return;
        }
        targets.removeIf(this::lambda$setWaitPacketTargetSelected$182 /* captured: target */);
    }

    private void loadWaitPacketTargetsFromQueue() {
        List<PackUtilSharedState.QueuedPacket> queue = PackUtilSharedState.get().getDelayedPackets();
        if (queue == null || queue.isEmpty()) {
            PackUtilClientMessaging.sendPrefixed("Queue is empty");
            return;
        }
        List<String> targets = this.getOrCreateWaitPacketTargets();
        List<String> merged = this.sanitizeWaitPacketTargets(targets);
        int before = merged.size();
        int added = queue.iterator();
        while (added.hasNext()) {
            QueuedPacket queuedPacket = (PackUtilSharedState.QueuedPacket)added.next();
            String target = this.buildWaitPacketTarget(queuedPacket);
            if (!target.isEmpty()) {
                if (merged.contains(target)) continue;
                merged.add(target);
            }
        }
        targets.clear();
        targets.addAll(merged);
        added = Math.max(0, merged.size() - before);
        PackUtilClientMessaging.sendPrefixed(added == 0 ? "Queue did not add any new packet targets" : "Added " + added + " packet target" + added == 1 ? "" : "s" + " from queue");
    }

    private String buildWaitPacketTarget(PackUtilSharedState.QueuedPacket queuedPacket) {
        if (queuedPacket == null || queuedPacket.packet == null) {
            return "";
        }
        Class<? extends class_2596<?>> packetClass = queuedPacket.packet.getClass();
        if (PackUtilPacketRegistry.getC2SPackets().contains(packetClass)) {
            return this.buildWaitPacketTarget("C2S", packetClass);
        }
        if (PackUtilPacketRegistry.getS2CPackets().contains(packetClass)) {
            return this.buildWaitPacketTarget("S2C", packetClass);
        }
        return "";
    }

    private String buildWaitPacketTarget(String direction, Class<? extends class_2596<?>> packetClass) {
        if (packetClass == null) {
            return "";
        }
        String name = PackUtilPacketRegistry.getName(packetClass);
        if (name == null || name.isBlank()) {
            name = PackUtilPacketNamer.getFriendlyName(packetClass);
        }
        return WaitForPacketAction.withDirection(direction, name);
    }

    private Class<? extends class_2596<?>> resolvePacketClassForTarget(String direction, String target) {
        String packetName = WaitForPacketAction.getPacketName(target);
        if (packetName.isBlank()) {
            return null;
        }
        Class<? extends class_2596<?>> direct = PackUtilPacketRegistry.getPacket(packetName);
        if (direct != null) {
            if (direction.isBlank()) {
                return direct;
            }
            if ("C2S".equalsIgnoreCase(direction) && PackUtilPacketRegistry.getC2SPackets().contains(direct)) {
                return direct;
            }
            if ("S2C".equalsIgnoreCase(direction)) {
                if (PackUtilPacketRegistry.getS2CPackets().contains(direct)) {
                    return direct;
                }
            }
        }
        List<Class<? extends class_2596<?>>> pool = new ArrayList();
        if ("C2S".equalsIgnoreCase(direction)) {
            pool.addAll(PackUtilPacketRegistry.getC2SPackets());
        } else {
            if ("S2C".equalsIgnoreCase(direction)) {
                pool.addAll(PackUtilPacketRegistry.getS2CPackets());
            } else {
                pool.addAll(PackUtilPacketRegistry.getC2SPackets());
                pool.addAll(PackUtilPacketRegistry.getS2CPackets());
            }
        }
        var var6 = pool.iterator();
        while (var6.hasNext()) {
            Class<? extends class_2596<?>> candidate = (Class)var6.next();
            String registryName = PackUtilPacketRegistry.getName(candidate);
            if (!this.packetNameMatches(packetName, registryName)) continue;
            return candidate;
            if (!this.packetNameMatches(packetName, PackUtilPacketNamer.getFriendlyName(candidate))) continue;
            return candidate;
            if (!this.packetNameMatches(packetName, candidate.getSimpleName())) continue;
            return candidate;
        }
        return null;
    }

    private boolean packetNameMatches(String expected, String candidate) {
        if (expected == null || expected.isBlank() || candidate == null || candidate.isBlank()) {
            return false;
        }
        String normalizedExpected = expected.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        String normalizedCandidate = candidate.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (normalizedExpected.isEmpty() || normalizedCandidate.isEmpty()) {
            return false;
        }
        if (normalizedExpected.equals(normalizedCandidate)) {
            return true;
        }
        if (normalizedCandidate.endsWith("packet")) {
            String stripped = normalizedCandidate.substring(0, normalizedCandidate.length() - "packet".length());
            if (normalizedExpected.equals(stripped)) {
                return true;
            }
        }
        return normalizedExpected.endsWith(normalizedCandidate) || normalizedCandidate.endsWith(normalizedExpected);
    }

    private List<String> getPacketNames(boolean c2s) {
        List<String> names = new ArrayList();
        var var3 = (c2s ? PackUtilPacketRegistry.getC2SPackets() : PackUtilPacketRegistry.getS2CPackets()).iterator();
        while (var3.hasNext()) {
            Class<? extends class_2596<?>> packetClass = (Class)var3.next();
            String name = PackUtilPacketRegistry.getName(packetClass);
            if (name != null) {
                if (name.isBlank()) continue;
                names.add(name);
            }
        }
        Collections.sort(names);
        return names;
    }

    private int renderBlockPosWithoutCapture(class_332 ctx, FieldDef field, int x, int y, int w, int mx, int my, float delta) {
        class_2960 font = this.theme.fontFor(PackUiTone.BODY);
        this.drawLabel(ctx, field.label(), x, y, w, font);
        y += 13;
        int bw = (w - 4) / 3;
        for (int i = 0; i < 3; i++) {
            PackUtilChatField f = (PackUtilChatField)this.textFields.get(field.key() + "_" + i);
            if (f == null) {
            } else {
                int fx = x + i * (bw + 2);
                f.setX(fx);
                f.setY(y + 1);
                f.setWidth(bw);
                f.render(ctx, mx, my, delta);
            }
        }
        return y + 15 + 2;
    }

    private static List<String> getAllSoundIds() {
        if (ALL_SOUND_IDS != null) { /* goto L80; */ }
        ALL_SOUND_IDS = new ArrayList();
        var var0 = class_7923.field_41172.iterator();
        while (var0.hasNext()) {
            class_3414 soundEvent = (class_3414)var0.next();
            class_2960 id = class_7923.field_41172.method_10221(soundEvent);
            if (id == null) continue;
            ALL_SOUND_IDS.add(id.toString());
        }
        Collections.sort(ALL_SOUND_IDS);
        L80: ;
        return ALL_SOUND_IDS;
    }

    private static List<String> getAllEntityIds() {
        if (ALL_ENTITY_IDS != null) { /* goto L71; */ }
        ALL_ENTITY_IDS = new ArrayList();
        var var0 = class_7923.field_41177.method_10235().iterator();
        while (var0.hasNext()) {
            class_2960 id = (class_2960)var0.next();
            ALL_ENTITY_IDS.add(id.toString());
        }
        Collections.sort(ALL_ENTITY_IDS);
        L71: ;
        return ALL_ENTITY_IDS;
    }

    private static List<String> getAllItemIds() {
        if (ALL_ITEM_IDS != null) { /* goto L71; */ }
        ALL_ITEM_IDS = new ArrayList();
        var var0 = class_7923.field_41178.method_10235().iterator();
        while (var0.hasNext()) {
            class_2960 id = (class_2960)var0.next();
            ALL_ITEM_IDS.add(id.toString());
        }
        Collections.sort(ALL_ITEM_IDS);
        L71: ;
        return ALL_ITEM_IDS;
    }

    private int rowH(FieldDef field) {
        if (this.isWaitChatPatternField(field)) {
            return 53;
        }
        switch (ActionEditorOverlay.1.$SwitchMap$com$example$addon$gui$macro$editor$FieldType[field.type().ordinal()]) {
            case 7::
                return 30;
            case 8::
                return field.captureMode() == CaptureMode.BLOCK_CATALOG ? 165 : 89;
            default:
                return 15;
        }
    }

    private int computeContentH() {
        if (this.itemAction != null) {
            int h = 103;
            h += 16;
            h += 11;
            h += 17;
            if (((Boolean)this.toggleStates.getOrDefault("item_waitForGui", false)).booleanValue()) {
                h += 17;
            }
            h += 17;
            return h;
        }
        if (this.targetAction != null) {
            if (this.targetAction.getType() == MacroActionType.SEND_PACKET) {
                h = 83;
                h += 17;
                h += 17;
                if (((Boolean)this.toggleStates.getOrDefault("waitForGui", false)).booleanValue()) {
                    h += 17;
                }
                h += 119;
                return h;
            }
        }
        if (this.targetAction == null) { /* goto L243; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_SOUND) { /* goto L243; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("waitForGui")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("waitGuiName")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("checkDistance")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("maxDistance")) ? 17 : 0);
        h += 77;
        h += 18;
        h += 78;
        return h;
        if (this.targetAction == null) { /* goto L407; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_ENTITY) { /* goto L407; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("checkMode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("radius")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("centerOnPlayer")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("pos")) ? this.rowH(this.getField("pos")) + 2 : 0);
        h = h + (this.isFieldVisible(this.getField("mustBeLookingAt")) ? 17 : 0);
        h += 77;
        h += 18;
        h += 62;
        h += 52;
        return h;
        if (this.targetAction == null) { /* goto L652; */ }
        if (this.targetAction.getType() != MacroActionType.LOOK_AT_BLOCK) { /* goto L652; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("targetMode")) ? 17 : 0);
        String mode = this.currentEnumValue("targetMode");
        if ("BLOCK".equals(mode)) {
            h = h + (this.isFieldVisible(this.getField("searchRadius")) ? 17 : 0);
            h = h + (this.rowH(this.getField("blockIds")) + 2);
        } else {
            if ("ENTITY".equals(mode)) {
                h = h + (this.isFieldVisible(this.getField("searchRadius")) ? 17 : 0);
                h += 77;
                h += 18;
                h += 66;
                h += 56;
            } else {
                h = h + (this.rowH(this.getField("blockPos")) + 2);
            }
        }
        h = h + (this.isFieldVisible(this.getField("smooth")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("smoothness")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("waitForCompletion")) ? 17 : 0);
        h += 14;
        return h;
        if (this.targetAction == null) { /* goto L799; */ }
        if (this.targetAction.getType() != MacroActionType.ROTATE) { /* goto L799; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("yaw")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("pitch")) ? 17 : 0);
        h += 18;
        h = h + (this.isFieldVisible(this.getField("smooth")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("smoothness")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("waitForCompletion")) ? 17 : 0);
        h += 14;
        return h;
        if (this.targetAction == null) { /* goto L870; */ }
        if (this.targetAction.getType() != MacroActionType.GO_TO) { /* goto L870; */ }
        h = 4;
        h = h + (this.rowH(this.getField("pos")) + 2);
        h += 18;
        h = h + (this.isFieldVisible(this.getField("waitForArrival")) ? 17 : 0);
        h += 14;
        return h;
        if (this.targetAction == null) { /* goto L994; */ }
        if (this.targetAction.getType() != MacroActionType.USE_ITEM) { /* goto L994; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("itemName")) ? 17 : 0);
        h += 18;
        h = h + (this.isFieldVisible(this.getField("useMode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("holdTicks")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("useCount")) ? 17 : 0);
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L1287; */ }
        if (this.targetAction.getType() != MacroActionType.INVENTORY_AUDIT) { /* goto L1287; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("mode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("targetItems")) ? 95 : 0);
        h = h + (this.isFieldVisible(this.getField("openMode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("openCommand")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("containerPos")) ? this.rowH(this.getField("containerPos")) + 2 : 0);
        h = h + (this.isFieldVisible(this.getField("dupeVector")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("iterations")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("maxTransferAttempts")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("transferRetryDelayMs")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("spamCount")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("spamDelayMs")) ? 17 : 0);
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L1458; */ }
        if (this.targetAction.getType() != MacroActionType.SWAP_SLOTS) { /* goto L1458; */ }
        h = 20;
        h = h + (this.isFieldVisible(this.getField("fromUseItemName")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("fromItemName")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("fromSlot")) ? 17 : 0);
        h += 24;
        h = h + (this.isFieldVisible(this.getField("toUseItemName")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("toItemName")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("toSlot")) ? 17 : 0);
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L1579; */ }
        if (this.targetAction.getType() != MacroActionType.CLICK) { /* goto L1579; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("clickType")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("clickCount")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("waitForGui")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("guiName")) ? 17 : 0);
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L1838; */ }
        if (this.targetAction.getType() != MacroActionType.DISCONNECT) { /* goto L1838; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("mode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("delayMs")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("lagMethod")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("kickMethod")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("packetCount")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("useNextAction")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("trigger")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("tolerance")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("bufferMs")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("timeoutSec")) ? 17 : 0);
        h += 11;
        return h;
        if (this.targetAction == null) { /* goto L1913; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_GUI) { /* goto L1913; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("waitMode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("guiTitle")) ? 17 : 0);
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L1971; */ }
        if (this.targetAction.getType() != MacroActionType.SELECT_SLOT) { /* goto L1971; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("itemName")) ? 17 : 0);
        h += 18;
        h += 30;
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L2029; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_COOLDOWN) { /* goto L2029; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("itemName")) ? 17 : 0);
        h += 18;
        h += 18;
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L2256; */ }
        if (this.targetAction.getType() != MacroActionType.WAIT_CHAT) { /* goto L2256; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("pattern")) ? this.rowH(this.getField("pattern")) + 2 : 0);
        h = h + (this.isFieldVisible(this.getField("useRegex")) ? 17 : 0);
        h = h + (!((Boolean)this.toggleStates.getOrDefault("useRegex", false)).booleanValue() ? 29 : 0);
        h = h + (this.isFieldVisible(this.getField("serverMessageOnly")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("timeoutMs")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("waitForGui")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("waitGuiName")) ? 17 : 0);
        h += 18;
        h += 18;
        h += 16;
        h += 149;
        h += 16;
        return h;
        if (this.targetAction == null) { /* goto L2436; */ }
        if (this.targetAction.getType() != MacroActionType.OPEN_CONTAINER) { /* goto L2436; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("targetMode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("pos")) ? this.rowH(this.getField("pos")) + 2 : 0);
        h = h + (this.isFieldVisible(this.getField("entityTargets")) ? this.rowH(this.getField("entityTargets")) + 2 : 0);
        h = h + (this.isFieldVisible(this.getField("waitForGui")) ? 17 : 0);
        targetMode = this.currentEnumValue("targetMode");
        h += 12;
        if ("ENTITY".equals(targetMode)) {
            h += 52;
        } else {
            if ("BLOCK".equals(targetMode)) {
                h += 39;
            }
        }
        return h;
        L2436: ;
        h = 4;
        if (this.targetAction != null && this.targetAction.getType() == MacroActionType.WAIT_SLOT_CHANGE) {
            h += 79;
            h += 16;
            h += 16;
            h += 11;
            return h;
        }
        if (this.targetAction == null) { /* goto L2568; */ }
        if (this.targetAction.getType() != MacroActionType.DELAY_PACKETS) { /* goto L2568; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("mode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("flushOnDisable")) ? 17 : 0);
        if ("ENABLE".equals(this.currentEnumValue("mode"))) {
            h += 54;
        }
        h += 8;
        return h;
        L2568: ;
        if (this.targetAction == null) { /* goto L2776; */ }
        if (this.targetAction.getType() != MacroActionType.MINE) { /* goto L2776; */ }
        h = 4;
        h = h + (this.rowH(this.getField("targetBlocks")) + 2 + 4);
        h = h + (this.isFieldVisible(this.getField("stopInventoryFull")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("stopSlotsUsed")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("slotsUsedThreshold")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("stopMinedCount")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("minedCountTarget")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("stopAfterTime")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("timeoutSeconds")) ? 17 : 0);
        h += 14;
        return h;
        if (this.targetAction == null) { /* goto L2906; */ }
        if (this.targetAction.getType() != MacroActionType.PAY) { /* goto L2906; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("commandTemplate")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("amountInput")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("delayEnabled")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("delayMs")) ? 17 : 0);
        h += 77;
        h += 18;
        h += 82;
        h += 24;
        return h;
        if (this.targetAction == null) { /* goto L3084; */ }
        if (this.targetAction.getType() != MacroActionType.STORE_ITEM) { /* goto L3084; */ }
        h = 4;
        h = h + (this.isFieldVisible(this.getField("mode")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("allItems")) ? 17 : 0);
        if (!((Boolean)this.toggleStates.getOrDefault("allItems", false)).booleanValue()) {
            h += 77;
            h += 18;
            h += 82;
            h += 22;
        }
        h = h + (this.isFieldVisible(this.getField("persistent")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("closeAfter")) ? 17 : 0);
        h = h + (this.isFieldVisible(this.getField("closeSendPkt")) ? 17 : 0);
        return h;
        h = 4;
        if (this.targetAction != null && this.targetAction.getType() == MacroActionType.TOGGLE_MODULE) {
            h += 77;
            h += 18;
            h += 82;
            h += 14;
            return h;
        }
        if (this.craftEntries != null) {
            return 151;
        }
        if (this.dropAction != null) {
            h = 103;
            h += 12;
            h += 17;
            h += 17;
            h += 17;
            if (((Boolean)this.toggleStates.getOrDefault("drop_waitForGui", false)).booleanValue()) {
                h += 17;
            }
            return h;
        }
        if (this.lanStepEntries == null) { /* goto L3295; */ }
        filterByUser = ((Boolean)this.toggleStates.getOrDefault("lan_filterByUser", false)).booleanValue();
        h = 21;
        if (!filterByUser || this.lanStepEntries.isEmpty()) {
            h += 17;
        }
        h += 12;
        if (!filterByUser) { /* goto L3293; */ }
        if (!this.lanStepEntries.isEmpty()) {
            int visibleRows = Math.min(3, Math.max(1, this.lanStepEntries.size()));
            h = h + (13 + visibleRows * 15);
        } else {
            h += 12;
        }
        h += 22;
        L3293: ;
        return h;
        L3295: ;
        if (this.targetAction != null && this.targetAction.getType() == MacroActionType.WAIT_PACKET) {
            return 214;
        }
        if (this.schema == null) {
            return 0;
        }
        h = 4;
        h = this.schema.fields().iterator();
        while (h.hasNext()) {
            FieldDef field = (FieldDef)h.next();
            while (field.type() == FieldType.STRING_LIST) {
            }
            while (!this.isFieldVisible(field)) {
            }
            h = h + (this.rowH(field) + 2);
        }
        h = this.schema.fields().iterator();
        while (h.hasNext()) {
            field = (FieldDef)h.next();
            while (field.type() != FieldType.STRING_LIST) {
            }
            while (!this.isFieldVisible(field)) {
            }
            h = h + (this.rowH(field) + 2);
        }
        if (this.targetAction != null) {
            if (this.targetAction.getType() == MacroActionType.PACKET) {
                h += 52;
            }
        }
        if (this.targetAction != null) {
            if (this.targetAction.getType() == MacroActionType.DELAY_PACKETS) {
                h += 18;
            }
        }
        return h;
    }

    private int computeDisconnectMaxH() {
        int h = 4;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 17;
        h += 11;
        return h;
    }

    private void drawLabel(class_332 ctx, String text, int x, int y, int maxW, class_2960 font) {
        String trimmed = PackUiText.trimToWidth(this.textRenderer, text, maxW - 4, font, -1);
        PackUiText.draw(ctx, this.textRenderer, trimmed, font, PackUtilColors.textPrimary(), x, PackUiSizing.alignTextY(y, 15, this.fontHeight(font), this.theme.bodyTextNudge()), false);
    }

    private int fontHeight(class_2960 font) {
        if (PackUiAssets.FONT_TITLE.equals(font)) {
            return this.theme.fontHeight(PackUiTone.TITLE);
        }
        if (PackUiAssets.FONT_LABEL.equals(font)) {
            return this.theme.fontHeight(PackUiTone.LABEL);
        }
        return this.theme.fontHeight(PackUiTone.BODY);
    }

    private int uiWidth(class_2960 font, String text) {
        return PackUiText.width(this.textRenderer, text == null ? "" : text, font, PackUtilColors.textPrimary());
    }

    private int uiWidth(String text) {
        return this.uiWidth(this.theme.fontFor(PackUiTone.BODY), text);
    }

    private int labelWidth(int totalWidth, String label, class_2960 font) {
        return this.labelWidth(totalWidth, label, font, 56);
    }

    private int labelWidth(int totalWidth, String label, class_2960 font, int minControlWidth) {
        int measured = this.uiWidth(font, label) + 8;
        int availableMax = Math.max(44, totalWidth - Math.max(28, minControlWidth) - 3);
        return Math.max(44, Math.min(measured, availableMax));
    }

    private int controlX(int x, int labelWidth) {
        return x + labelWidth + 3;
    }

    private int controlWidth(int totalWidth, int labelWidth) {
        return Math.max(28, totalWidth - labelWidth - 3);
    }

    private void fillBorder(class_332 ctx, int x, int y, int w, int h, int color) {
        ctx.method_25294(x, y, x + w, y + 1, color);
        ctx.method_25294(x, y + h - 1, x + w, y + h, color);
        ctx.method_25294(x, y, x + 1, y + h, color);
        ctx.method_25294(x + w - 1, y, x + w, y + h, color);
    }

    private void drawScrollbar(class_332 ctx, int trackX, int trackY, int trackH, int totalCount, int visibleCount, int itemH, int scrollOffset) {
        if (totalCount <= visibleCount) {
            return;
        }
        int viewPixels = Math.max(1, Math.min(trackH, visibleCount * itemH));
        int contentPixels = Math.max(0, totalCount * itemH);
        Metrics metrics = PackUiScrollbar.compute(contentPixels, viewPixels, trackX, trackY, 5, trackH, scrollOffset);
        PackUiScrollbar.draw(ctx, metrics, false, false);
    }

    private PackUiSmoothScroll scrollState(Map<String, PackUiSmoothScroll> states, String key, int initialOffset) {
        return (PackUiSmoothScroll)states.computeIfAbsent(key, ActionEditorOverlay::lambda$scrollState$183 /* captured: initialOffset */);
    }

    private PackUiScrollViewport getOrCreateViewport(Map<String, PackUiScrollViewport> viewports, String key, int x, int y, int width, int height, int rowHeight, int scrollbarWidth) {
        PackUiScrollViewport vp = (PackUiScrollViewport)viewports.get(key);
        if (vp == null || vp.getX() != x || vp.getY() != y || vp.getWidth() != width || vp.getHeight() != height) {
            vp = new PackUiScrollViewport(x, y, width, height, rowHeight, scrollbarWidth);
            viewports.put(key, vp);
        }
        return vp;
    }

    private int tickListScroll(String key, Map<String, Integer> targetOffsets, Map<String, PackUiSmoothScroll> states, int maxScroll, float delta) {
        int target = Math.max(0, Math.min(((Integer)targetOffsets.getOrDefault(key, 0)).intValue(), maxScroll));
        targetOffsets.put(key, target);
        PackUiSmoothScroll state = this.scrollState(states, key, target);
        state.setTarget(target, maxScroll);
        return state.tick(delta, maxScroll);
    }

    private PackUtilChatField makeField(int w) {
        return new PackUtilChatField(MC, this.textRenderer, 0, 0, w, 13, false);
    }

    private static String fmtDouble(double v) {
        long lv = (long)v;
        return v == (double)lv ? String.valueOf(lv) : String.valueOf(v);
    }

    private static boolean matchesListFilter(String filter, String ... candidates) {
        String normalized = filter == null ? "" : filter.trim().toLowerCase(Locale.ROOT);
        if (normalized.isEmpty()) {
            return true;
        }
        var var3 = candidates;
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String candidate = var3[var5];
            if (!candidate != null && candidate.toLowerCase(Locale.ROOT).contains(normalized)) continue;
            return true;
        }
        return false;
    }

    private void startCapture(FieldDef field, List<String> lst) {
        this.screenBeforeCapture = MC.field_1755;
        this.enterEditorOnlyCaptureMode();
        MC.execute(ActionEditorOverlay::lambda$startCapture$184);
        PackUtilSharedState state = PackUtilSharedState.get();
        state.setCaptureCancelCallback(this::lambda$startCapture$185);
        if (field.captureMode() == CaptureMode.BLOCK_ID || field.captureMode() == CaptureMode.BLOCK_CATALOG) {
            state.setBlockCaptureCallback(this::lambda$startCapture$186 /* captured: lst */);
        } else {
            if (field.captureMode() == CaptureMode.ENTITY_ID) {
                boolean specificCapture = this.isOpenContainerEntityListKey(field.key());
                state.setEntityCaptureSpecific(specificCapture);
                state.setEntityCaptureCallback(this::lambda$startCapture$187 /* captured: specificCapture, lst */);
            }
        }
    }

    private void startBlockPosCapture(FieldDef field) {
        this.screenBeforeCapture = MC.field_1755;
        this.enterEditorOnlyCaptureMode();
        String key = field.key();
        boolean dbl = field.xyzDouble();
        MC.execute(ActionEditorOverlay::lambda$startBlockPosCapture$188);
        PackUtilSharedState state = PackUtilSharedState.get();
        state.setCaptureCancelCallback(this::lambda$startBlockPosCapture$189);
        state.setBlockCaptureCallback(this::lambda$startBlockPosCapture$190 /* captured: key, dbl */);
    }

    private static List<String> getAllBlockIds() {
        if (ALL_BLOCK_IDS != null) { /* goto L129; */ }
        ALL_BLOCK_IDS = new ArrayList();
        var var0 = class_7923.field_41175.method_10235().iterator();
        while (var0.hasNext()) {
            class_2960 id = (class_2960)var0.next();
            String path = id.method_12832();
            if (path.endsWith("_wall_head")) continue;
            if (path.endsWith("_wall_sign")) continue;
            if (path.endsWith("_wall_banner")) continue;
            if (path.endsWith("_wall_torch")) continue;
            while (path.endsWith("_wall_skull")) {
            }
            ALL_BLOCK_IDS.add(id.toString());
        }
        Collections.sort(ALL_BLOCK_IDS);
        L129: ;
        return ALL_BLOCK_IDS;
    }

    private static String formatTypeName(MacroActionType type) {
        String[] parts = type.name().split("_");
        StringBuilder sb = new StringBuilder();
        var var3 = parts;
        var var4 = var3.length;
        for (int var5 = 0; var5 < var4; var5++) {
            String part = var3[var5];
            if (!sb.length() > 0) continue;
            sb.append(32);
            sb.append(Character.toUpperCase(part.charAt(0)));
            if (!part.length() > 1) continue;
            sb.append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }

    private String getHandledScreenCaptureTargetLabel() {
        if ("_item_entries".equals(this.itemSlotCapturePendingKey) || "_drop_entries".equals(this.itemSlotCapturePendingKey) || "_wsc_entries".equals(this.itemSlotCapturePendingKey)) {
            return "Slot + Item";
        }
        FieldDef field = this.findField(this.itemSlotCapturePendingKey);
        return field != null ? field.label() : "Slot";
    }

    private String getCaptureActionLabel() {
        return this.targetAction != null ? ActionEditorOverlay.formatTypeName(this.targetAction.getType()) : "Action";
    }

    private FieldDef findField(String key) {
        if (this.schema == null || key == null) {
            return null;
        }
        var var2 = this.schema.fields().iterator();
        while (var2.hasNext()) {
            FieldDef field = (FieldDef)var2.next();
            if (!key.equals(field.key())) continue;
            return field;
        }
        return null;
    }
}
