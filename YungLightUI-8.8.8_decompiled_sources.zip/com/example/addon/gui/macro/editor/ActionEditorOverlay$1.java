/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

import com.example.addon.gui.macro.editor.FieldType;
import com.example.addon.util.macro.MacroActionType;
import com.example.addon.util.macro.ToggleModuleAction;

static class ActionEditorOverlay.1 {
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$MacroActionType;
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$gui$macro$editor$FieldType;
    static final /* synthetic */ int[] $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode;

    static {
        $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode = new int[ToggleModuleAction.ToggleMode.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.TOGGLE.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.ENABLE.ordinal()] = 2;
            /* goto @39; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.ENABLE.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.DISABLE.ordinal()] = 3;
            /* goto @54; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$ToggleModuleAction$ToggleMode[ToggleModuleAction.ToggleMode.DISABLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType = new int[FieldType.values().length];
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.TOGGLE.ordinal()] = 1;
            /* goto @78; */
        }
        $SwitchMap$com$example$addon$gui$macro$editor$FieldType = new int[FieldType.values().length];
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.TOGGLE.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.NUMBER.ordinal()] = 2;
            /* goto @93; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.NUMBER.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.DECIMAL.ordinal()] = 3;
            /* goto @108; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.DECIMAL.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.TEXT.ordinal()] = 4;
            /* goto @123; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.TEXT.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.ENUM.ordinal()] = 5;
            /* goto @138; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.ENUM.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.SLOT.ordinal()] = 6;
            /* goto @154; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.SLOT.ordinal()] = 6;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.BLOCK_POS.ordinal()] = 7;
            /* goto @170; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.BLOCK_POS.ordinal()] = 7;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.STRING_LIST.ordinal()] = 8;
            /* goto @186; */
        }
        try {
            $SwitchMap$com$example$addon$gui$macro$editor$FieldType[FieldType.STRING_LIST.ordinal()] = 8;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType = new int[MacroActionType.values().length];
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.INVENTORY.ordinal()] = 1;
            /* goto @210; */
        }
        $SwitchMap$com$example$addon$util$macro$MacroActionType = new int[MacroActionType.values().length];
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.INVENTORY.ordinal()] = 1;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.RESTORE_GUI.ordinal()] = 2;
            /* goto @225; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.RESTORE_GUI.ordinal()] = 2;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SAVE_GUI.ordinal()] = 3;
            /* goto @240; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SAVE_GUI.ordinal()] = 3;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_TOGGLE.ordinal()] = 4;
            /* goto @255; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.SEND_TOGGLE.ordinal()] = 4;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DESYNC.ordinal()] = 5;
            /* goto @270; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DESYNC.ordinal()] = 5;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CRAFT.ordinal()] = 6;
            /* goto @286; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.CRAFT.ordinal()] = 6;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DROP.ordinal()] = 7;
            /* goto @302; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.DROP.ordinal()] = 7;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.ITEM.ordinal()] = 8;
            /* goto @318; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.ITEM.ordinal()] = 8;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_LAN_STEP.ordinal()] = 9;
            /* goto @334; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_LAN_STEP.ordinal()] = 9;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_PACKET.ordinal()] = 10;
            /* goto @350; */
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_PACKET.ordinal()] = 10;
        }
        catch (NoSuchFieldError e0) {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_SLOT_CHANGE.ordinal()] = 11;
            /* goto L366; */
            var0 = null;
            L366: ;
            return;
        }
        try {
            $SwitchMap$com$example$addon$util$macro$MacroActionType[MacroActionType.WAIT_SLOT_CHANGE.ordinal()] = 11;
        }
        catch (NoSuchFieldError e0) {
            return;
        }
    }
}
