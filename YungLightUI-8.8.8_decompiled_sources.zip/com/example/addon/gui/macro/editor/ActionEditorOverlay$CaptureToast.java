/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

private static final record ActionEditorOverlay.CaptureToast {
    private final String message;
    private final long shownAtNanos;
    private final int accentColor;

    private ActionEditorOverlay.CaptureToast(String message, long shownAtNanos, int accentColor) {
        this.message = message;
        this.shownAtNanos = shownAtNanos;
        this.accentColor = accentColor;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public String message() {
        return this.message;
    }

    public long shownAtNanos() {
        return this.shownAtNanos;
    }

    public int accentColor() {
        return this.accentColor;
    }
}
