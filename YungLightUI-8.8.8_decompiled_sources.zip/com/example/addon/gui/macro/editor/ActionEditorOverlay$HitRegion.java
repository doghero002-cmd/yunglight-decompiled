/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

import com.example.addon.gui.macro.editor.ActionEditorOverlay;
import com.example.addon.gui.packui.PackUiOverlayButton;

private static final class ActionEditorOverlay.HitRegion {
    private final int x;
    private final int y;
    private final int w;
    private final int h;
    private final ActionEditorOverlay.HitRegionAction action;

    private ActionEditorOverlay.HitRegion(int x, int y, int w, int h, Runnable action) {
        this(x, y, w, h, ActionEditorOverlay.HitRegion::lambda$new$0 /* captured: action */);
    }

    private ActionEditorOverlay.HitRegion(PackUiOverlayButton button, Runnable action) {
        this(button.getX(), button.getY(), button.getWidth(), button.getHeight(), ActionEditorOverlay.HitRegion::lambda$new$1 /* captured: button */);
    }

    private ActionEditorOverlay.HitRegion(int x, int y, int w, int h, ActionEditorOverlay.HitRegionAction action) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.action = action;
    }

    boolean contains(int mx, int my) {
        return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
    }

    boolean fire(double mx, double my, int mouseButton) {
        return this.action != null && this.action.fire(mx, my, mouseButton);
    }
}
