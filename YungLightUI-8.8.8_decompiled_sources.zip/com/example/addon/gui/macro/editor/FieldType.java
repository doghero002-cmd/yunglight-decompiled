/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

public enum FieldType {
    public static final FieldType TOGGLE = new FieldType("TOGGLE", 0);
    public static final FieldType NUMBER = new FieldType("NUMBER", 1);
    public static final FieldType DECIMAL = new FieldType("DECIMAL", 2);
    public static final FieldType TEXT = new FieldType("TEXT", 3);
    public static final FieldType ENUM = new FieldType("ENUM", 4);
    public static final FieldType STRING_LIST = new FieldType("STRING_LIST", 5);
    public static final FieldType BLOCK_POS = new FieldType("BLOCK_POS", 6);
    public static final FieldType SLOT = new FieldType("SLOT", 7);
    private static final /* synthetic */ FieldType[] $VALUES;

    public static FieldType[] values() {
        return (FieldType[])$VALUES.clone();
    }

    public static FieldType valueOf(String name) {
        return (FieldType)Enum.valueOf(FieldType.class, name);
    }

    private FieldType() {
        super(var1, var2);
    }

    static {
        $VALUES = FieldType.$values();
    }
}
