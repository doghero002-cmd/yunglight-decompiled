/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

import com.example.addon.gui.macro.editor.FieldDef;
import java.util.Collections;
import java.util.List;

public final class ActionFieldSchema {
    private final List<FieldDef> fields;

    private ActionFieldSchema(List<FieldDef> fields) {
        this.fields = Collections.unmodifiableList(fields);
    }

    public List<FieldDef> fields() {
        return this.fields;
    }

    public static ActionFieldSchema.Builder builder() {
        return new ActionFieldSchema.Builder();
    }
}
