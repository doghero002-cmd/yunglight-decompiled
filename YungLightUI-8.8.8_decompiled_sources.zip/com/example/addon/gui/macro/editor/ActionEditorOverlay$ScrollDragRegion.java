/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

import java.util.function.IntConsumer;

private static final record ActionEditorOverlay.ScrollDragRegion {
    private final int x;
    private final int y;
    private final int w;
    private final int h;
    private final IntConsumer handler;

    private ActionEditorOverlay.ScrollDragRegion(int x, int y, int w, int h, IntConsumer handler) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.handler = handler;
    }

    boolean contains(int mx, int my) {
        return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public int x() {
        return this.x;
    }

    public int y() {
        return this.y;
    }

    public int w() {
        return this.w;
    }

    public int h() {
        return this.h;
    }

    public IntConsumer handler() {
        return this.handler;
    }
}
