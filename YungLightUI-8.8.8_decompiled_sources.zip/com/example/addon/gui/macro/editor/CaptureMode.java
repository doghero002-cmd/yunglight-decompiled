/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

public enum CaptureMode {
    public static final CaptureMode NONE = new CaptureMode("NONE", 0);
    public static final CaptureMode BLOCK_ID = new CaptureMode("BLOCK_ID", 1);
    public static final CaptureMode ENTITY_ID = new CaptureMode("ENTITY_ID", 2);
    public static final CaptureMode BLOCK_CATALOG = new CaptureMode("BLOCK_CATALOG", 3);
    public static final CaptureMode ITEM_SLOT = new CaptureMode("ITEM_SLOT", 4);
    private static final /* synthetic */ CaptureMode[] $VALUES;

    public static CaptureMode[] values() {
        return (CaptureMode[])$VALUES.clone();
    }

    public static CaptureMode valueOf(String name) {
        return (CaptureMode)Enum.valueOf(CaptureMode.class, name);
    }

    private CaptureMode() {
        super(var1, var2);
    }

    static {
        $VALUES = CaptureMode.$values();
    }
}
