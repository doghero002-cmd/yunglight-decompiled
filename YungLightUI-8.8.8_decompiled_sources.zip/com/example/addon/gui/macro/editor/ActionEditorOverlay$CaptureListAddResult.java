/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

private static final record ActionEditorOverlay.CaptureListAddResult {
    private final boolean added;
    private final String message;
    private final int accentColor;

    private ActionEditorOverlay.CaptureListAddResult(boolean added, String message, int accentColor) {
        this.added = added;
        this.message = message;
        this.accentColor = accentColor;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public boolean added() {
        return this.added;
    }

    public String message() {
        return this.message;
    }

    public int accentColor() {
        return this.accentColor;
    }
}
