/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.gui.macro.editor;

@FunctionalInterface
private static interface ActionEditorOverlay.HitRegionAction {
    public boolean fire(double var1, double var3, int var5);
}
