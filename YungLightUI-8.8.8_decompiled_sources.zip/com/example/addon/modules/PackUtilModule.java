/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilConfig;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilMacro;
import com.example.addon.util.PackUtilMacroManager;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilPacketRegistry;
import com.example.addon.util.PackUtilServerInfoOverlay;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroConditionRegistry;
import com.example.addon.util.macro.MacroExecutor;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2639;
import net.minecraft.class_2641;
import net.minecraft.class_2815;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2851;
import net.minecraft.class_2877;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_6374;
import net.minecraft.class_7923;
import net.minecraft.class_8590;
import net.minecraft.class_9449;
import net.minecraft.class_9836;
import org.lwjgl.glfw.GLFW;

public final class PackUtilModule {
    private static final class_310 MC = class_310.method_1551();
    private static final PackUtilModule INSTANCE = new PackUtilModule();
    private static final Set<Class<?>> C2S_EXCLUDED_DEFAULTS;
    private PackUtilConfig config;
    private boolean initialized;
    private boolean loadGuiKeyPressed;
    private boolean flushQueueKeyPressed;
    private boolean clearQueueKeyPressed;
    private boolean toggleLoggerKeyPressed;
    private boolean toggleSendKeyPressed;
    private boolean toggleDelayKeyPressed;
    private final Map<String, Boolean> macroKeyStates = new HashMap();
    private List<PackUtilMacro> cachedKeyboundMacros = List.of();
    private long cachedMacroKeybindRevision = -1L;
    private int autoSendTickCounter;
    private int packetLoggerTickCounter;
    private PackUtilPacketLoggerOverlay packetLoggerOverlay;
    private PackUtilServerInfoOverlay serverInfoOverlay;
    private class_1799 tooltipSizeCacheStack;
    private String tooltipSizeCacheText;

    private PackUtilModule() {
        this.tooltipSizeCacheStack = class_1799.field_8037;
    }

    public static PackUtilModule get() {
        return INSTANCE;
    }

    public void initialize() {
        if (this.initialized) {
            return;
        }
        this.config = PackUtilConfig.load();
        this.config.applyRuntimeDefaults();
        PackUtilConfig.setGlobal(this.config);
        if (this.config.c2sPackets.isEmpty()) {
            this.config.c2sPackets = this.encodePackets(this.defaultC2SPackets());
        }
        this.applyConfigToSharedState();
        if (this.config.lanSyncEnabled) {
            PackUtilLANSync.getInstance().start();
        }
        this.initialized = true;
    }

    public void tick() {
        if (!this.initialized || MC == null) {
            return;
        }
        PackUtilLANSync.getInstance().tick();
        MacroConditionRegistry.onTick(MC);
        PackUtilSharedState.get().tickStaggeredSend();
        this.updatePassiveXCarryState();
        PackUtilServerInfoOverlay serverInfo = this.getServerInfoOverlayIfExists();
        if (serverInfo != null) {
            if (serverInfo.isVisible() || serverInfo.shouldRenderBackgroundProbeBanner()) {
                serverInfo.tickBackground();
            }
        }
        if (PackUtilSharedState.get().shouldDelayGuiPackets()) {
            if (MC.method_1562() != null) {
                this.autoSendTickCounter = this.autoSendTickCounter + 1;
                if (this.autoSendTickCounter >= 1) {
                    this.autoSendTickCounter = 0;
                }
            }
        } else {
            this.autoSendTickCounter = 0;
        }
        if (MC.field_1755 == null) {
            this.tickKeybinds();
        } else {
            this.tickKeybinds();
            if (this.config != null && this.config.keybindInsideGui && MC.field_1755 instanceof class_465 && !this.isAnyTextFieldFocused()) {
            } else {
                this.loadGuiKeyPressed = false;
                this.flushQueueKeyPressed = false;
                this.clearQueueKeyPressed = false;
                this.toggleLoggerKeyPressed = false;
                this.toggleSendKeyPressed = false;
                this.toggleDelayKeyPressed = false;
                this.macroKeyStates.clear();
            }
        }
        this.packetLoggerTickCounter = this.packetLoggerTickCounter + 1;
        PackUtilPacketLoggerOverlay logger = this.getPacketLoggerOverlayIfExists();
        if (logger != null) {
            logger.setGameTick(this.packetLoggerTickCounter);
        }
    }

    public void onGameJoin() {
        this.applyRuntimePacketFlowDefaults();
        if (this.config.lanSyncEnabled) {
            if (!PackUtilLANSync.getInstance().isRunning()) {
                PackUtilLANSync.getInstance().start();
            }
        }
        PackUtilLANSync.getInstance().onGameJoined();
    }

    public void onGameLeft() {
        this.loadGuiKeyPressed = false;
        this.flushQueueKeyPressed = false;
        this.clearQueueKeyPressed = false;
        this.toggleLoggerKeyPressed = false;
        this.toggleSendKeyPressed = false;
        this.toggleDelayKeyPressed = false;
    }

    public boolean isActive() {
        return true;
    }

    public void toggle() {
        PackUtilClientMessaging.sendPrefixed("PackUtil is always enabled in standalone mode.");
    }

    public void appendTooltip(class_1799 stack, List<?> lines) {
        if (!this.config.showItemIds || stack == null || stack.method_7960()) {
            return;
        }
        try {
            List rawLines = lines;
            rawLines.add(class_2561.method_43470(class_7923.field_41178.method_10221(stack.method_7909()).toString()).method_27692(class_124.field_1063));
            if (MC != null) {
                if (MC.field_1724 != null) {
                    String sizeText = this.getTooltipSizeText(stack);
                    if (sizeText != null) {
                        if (!sizeText.isEmpty()) {
                            rawLines.add(class_2561.method_43470(sizeText).method_27692(class_124.field_1063));
                        }
                    }
                }
            }
        }
        catch (Exception rawLines) {
            return;
        }
    }

    public boolean handlePacketSend(class_2596<?> packet) {
        PackUtilPacketLoggerOverlay logger = this.getPacketLoggerOverlayIfExists();
        if (logger == null) {
            return false;
        }
        if (logger.isPacketBlocked(packet.getClass())) {
            return true;
        }
        logger.logPacket(packet, "C2S");
        return false;
    }

    public boolean handlePacketReceive(class_2596<?> packet) {
        PackUtilServerInfoOverlay overlay = this.getServerInfoOverlayIfExists();
        if (packet instanceof class_2639) {
            class_2639 suggestions = (class_2639)packet;
            if (overlay != null) {
                overlay.onCommandSuggestions(suggestions.comp_2262(), suggestions);
            }
        }
        if (packet instanceof class_2641) {
            if (overlay != null) {
                overlay.onCommandTreeChanged();
            }
        }
        logger = this.getPacketLoggerOverlayIfExists();
        if (logger == null) {
            return false;
        }
        if (logger.isPacketBlocked(packet.getClass())) {
            return true;
        }
        logger.logPacket(packet, "S2C");
        return false;
    }

    public PackUtilPacketLoggerOverlay getPacketLoggerOverlay() {
        this.packetLoggerOverlay = new PackUtilPacketLoggerOverlay(MC.field_1772);
        if (this.packetLoggerOverlay == null && MC != null && MC.field_1772 != null) {
            this.packetLoggerOverlay.restoreLayout();
        }
        return this.packetLoggerOverlay;
    }

    public PackUtilPacketLoggerOverlay getPacketLoggerOverlayIfExists() {
        return this.packetLoggerOverlay;
    }

    public PackUtilServerInfoOverlay getServerInfoOverlay() {
        this.serverInfoOverlay = new PackUtilServerInfoOverlay(MC.field_1772);
        if (this.serverInfoOverlay == null && MC != null && MC.field_1772 != null) {
            this.serverInfoOverlay.restoreState();
        }
        return this.serverInfoOverlay;
    }

    public PackUtilServerInfoOverlay getServerInfoOverlayIfExists() {
        return this.serverInfoOverlay;
    }

    public boolean isNoPauseOnLostFocus() {
        return this.config.noPauseOnLostFocus;
    }

    public boolean isLANSyncEnabled() {
        return this.config.lanSyncEnabled;
    }

    public boolean isBypassResourcePack() {
        return this.config.pretendPackAccepted;
    }

    public boolean isInventoryMoveEnabled() {
        return this.config != null && this.config.inventoryMove;
    }

    public void setInventoryMoveEnabled(boolean value) {
        if (this.config == null) {
            return;
        }
        this.config.inventoryMove = value;
        this.saveConfig();
    }

    public boolean isXCarryEnabled() {
        return this.config != null && this.config.xCarry;
    }

    public void setXCarryEnabled(boolean value) {
        if (this.config == null) {
            return;
        }
        this.config.xCarry = value;
        this.saveConfig();
    }

    public void setBypassResourcePack(boolean value) {
        this.config.pretendPackAccepted = value;
        PackUtilSharedState.get().setBypassResourcePack(value);
        this.saveConfig();
    }

    public boolean isForceDenyResourcePack() {
        return this.config.autoDenyResourcePack;
    }

    public void setForceDenyResourcePack(boolean value) {
        this.config.autoDenyResourcePack = value;
        PackUtilSharedState.get().setResourcePackForceDeny(value);
        this.saveConfig();
    }

    public boolean useMsSleepMode() {
        return this.config.useMsSleepMode;
    }

    public int getMsSleepInterval() {
        return this.config.msSleepInterval;
    }

    public boolean useInstantExecutionMode() {
        return this.config.instantExecutionMode;
    }

    public int getActionDelayUs() {
        return this.config.actionDelayUs;
    }

    public boolean usePacketBurstMode() {
        return this.config.packetBurstMode;
    }

    public boolean shouldUseDirectFlush() {
        return this.config.useDirectFlush;
    }

    public boolean shouldForceChannelFlush() {
        return this.config.forceChannelFlush;
    }

    public boolean shouldFlushQueueOnDelayDisable() {
        return this.config != null && this.config.flushQueueOnDelayDisable;
    }

    public void setFlushQueueOnDelayDisable(boolean value) {
        if (this.config == null) {
            return;
        }
        this.config.flushQueueOnDelayDisable = value;
        this.saveConfig();
    }

    public boolean shouldUseCustomPackets() {
        return this.config.useCustomPackets;
    }

    public void setUseCustomPackets(boolean value) {
        this.config.useCustomPackets = value;
        PackUtilSharedState.get().setUseCustomPackets(value);
        this.saveConfig();
    }

    public void setSendGuiPackets(boolean value) {
        this.config.sendGuiPackets = value;
        PackUtilSharedState.get().setSendGuiPackets(value);
    }

    public boolean applySendGuiPacketsUiBehavior(boolean value) {
        this.setSendGuiPackets(value);
        this.saveConfig();
        return value;
    }

    public void setDelayGuiPackets(boolean value) {
        this.config.delayGuiPackets = value;
        PackUtilSharedState.get().setDelayGuiPackets(value);
    }

    public int applyDelayGuiPacketsUiBehavior(boolean value) {
        this.setDelayGuiPackets(value);
        this.saveConfig();
        if (!value && this.shouldFlushQueueOnDelayDisable() && MC != null && MC.method_1562() != null) {
            return PackUtilSharedState.get().flushDelayedPackets(MC.method_1562());
        }
        return 0;
    }

    public int flushQueuedPacketsUiBehavior() {
        if (MC == null || MC.method_1562() == null) {
            return 0;
        }
        return PackUtilSharedState.get().flushDelayedPackets(MC.method_1562());
    }

    public int clearQueuedPacketsUiBehavior() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        int count = shared.clearQueuedPackets();
        return count;
    }

    public boolean togglePacketLoggerUiBehavior() {
        PackUtilPacketLoggerOverlay overlay = this.getPacketLoggerOverlay();
        if (overlay == null) {
            return false;
        }
        overlay.toggle();
        return true;
    }

    public boolean restoreSavedScreenUiBehavior() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        if (MC == null) {
            return false;
        }
        if (shared.getStoredScreen() == null || shared.getStoredScreenHandler() == null) {
            return false;
        }
        MC.execute(PackUtilModule::lambda$restoreSavedScreenUiBehavior$0 /* captured: shared */);
        return true;
    }

    public Set<Class<? extends class_2596<?>>> getC2SPackets() {
        return new LinkedHashSet(PackUtilSharedState.get().getC2SPackets());
    }

    public Set<Class<? extends class_2596<?>>> getS2CPackets() {
        return new LinkedHashSet(PackUtilSharedState.get().getS2CPackets());
    }

    public void setC2SPackets(Set<Class<? extends class_2596<?>>> packets) {
        Set<Class<? extends class_2596<?>>> safe = packets == null ? this.defaultC2SPackets() : new LinkedHashSet(packets);
        PackUtilSharedState.get().setC2SPackets(safe);
        this.config.c2sPackets = this.encodePackets(safe);
        this.saveConfig();
    }

    public void setS2CPackets(Set<Class<? extends class_2596<?>>> packets) {
        Set<Class<? extends class_2596<?>>> safe = packets == null ? this.defaultS2CPackets() : new LinkedHashSet(packets);
        PackUtilSharedState.get().setS2CPackets(safe);
        this.config.s2cPackets = this.encodePackets(safe);
        this.saveConfig();
    }

    public void resetC2SPacketsToDefault() {
        this.setC2SPackets(this.defaultC2SPackets());
    }

    public void resetS2CPacketsToDefault() {
        this.setS2CPackets(this.defaultS2CPackets());
    }

    public Set<Class<? extends class_2596<?>>> defaultC2SPackets() {
        Set<Class<? extends class_2596<?>>> defaults = new LinkedHashSet();
        var var2 = PackUtilPacketRegistry.getC2SPackets().iterator();
        while (var2.hasNext()) {
            Class<? extends class_2596<?>> packetClass = (Class)var2.next();
            if (C2S_EXCLUDED_DEFAULTS.contains(packetClass)) continue;
            defaults.add(packetClass);
        }
        defaults.add(class_9449.class);
        defaults.add(class_2877.class);
        return defaults;
    }

    public Set<Class<? extends class_2596<?>>> defaultS2CPackets() {
        return new LinkedHashSet();
    }

    private void applyConfigToSharedState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.applyRuntimePacketFlowDefaults();
        shared.setUseCustomPackets(this.config.useCustomPackets);
        shared.setC2SPackets(this.resolvePackets(this.config.c2sPackets, true));
        shared.setS2CPackets(this.resolvePackets(this.config.s2cPackets, false));
        shared.setAllowSignEditing(this.config.allowSignEditing);
        shared.setResourcePackForceDeny(this.config.autoDenyResourcePack);
        shared.setBypassResourcePack(this.config.pretendPackAccepted);
        shared.setStaggeredPacketSend(this.config.staggeredPacketSend);
        shared.setStaggeredSendDelay(this.config.staggeredSendDelay);
    }

    private void applyRuntimePacketFlowDefaults() {
        if (this.config != null) {
            this.config.applyRuntimeDefaults();
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        shared.setSendGuiPackets(true);
        shared.setDelayGuiPackets(false);
    }

    private void updatePassiveXCarryState() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        if (shared.isXCarryForced()) {
            return;
        }
        boolean active = false;
        if (this.config == null) { /* goto L117; */ }
        if (!this.config.xCarry) { /* goto L117; */ }
        if (MC.field_1724 == null) { /* goto L117; */ }
        if (MC.field_1724.field_7498 == null) { /* goto L117; */ }
        int slotId = 1;
        while (slotId <= 4) {
            if (slotId >= MC.field_1724.field_7498.field_7761.size()) break;
            if (!((class_1735)MC.field_1724.field_7498.field_7761.get(slotId)).method_7677().method_7960()) {
                active = true;
            } else {
                slotId++;
            }
        }
        shared.setXCarryActive(active);
    }

    private void saveConfig() {
        if (this.config == null) {
            return;
        }
        this.config.save();
    }

    private Set<Class<? extends class_2596<?>>> resolvePackets(List<String> names, boolean c2s) {
        Set<Class<? extends class_2596<?>>> resolved = new LinkedHashSet();
        if (names != null) {
            var var4 = names.iterator();
        }
        while (var4.hasNext()) {
            String name = (String)var4.next();
            if (name == null) { /* goto @20; */ }
            while (name.isBlank()) {
            }
            Class<? extends class_2596<?>> packetClass = PackUtilPacketRegistry.getPacket(name);
            try {
                Class<?> direct = Class.forName(name);
                if (class_2596.class.isAssignableFrom(direct)) {
                    Class<? extends class_2596<?>> typed = direct;
                    packetClass = typed;
                }
            }
            catch (ClassNotFoundException direct) {
                if (packetClass != null) {
                    resolved.add(packetClass);
                }
            }
            if (packetClass != null) {
                resolved.add(packetClass);
            }
        }
        if (!resolved.isEmpty()) { /* goto L143; */ }
        return c2s ? this.defaultC2SPackets() : this.defaultS2CPackets();
        return resolved;
    }

    private List<String> encodePackets(Set<Class<? extends class_2596<?>>> packets) {
        List<String> names = new ArrayList();
        var var3 = packets.iterator();
        while (var3.hasNext()) {
            Class<? extends class_2596<?>> packetClass = (Class)var3.next();
            String name = PackUtilPacketRegistry.getName(packetClass);
            names.add(name != null ? name : packetClass.getName());
        }
        return names;
    }

    private void tickKeybinds() {
        PackUtilConfig cfg = this.config;
        if (cfg == null) {
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        this.refreshKeyboundMacroCache();
        if (cfg.keybindLoadGui == -1) { /* goto L73; */ }
        boolean pressed = this.isKeyPressed(cfg.keybindLoadGui);
        if (!pressed) { /* goto L68; */ }
        if (this.loadGuiKeyPressed) { /* goto L68; */ }
        if (this.restoreSavedScreenUiBehavior()) {
            PackUtilClientMessaging.sendPrefixed("GUI restored.");
        } else {
            PackUtilClientMessaging.sendPrefixed("Â§cNo stored GUI.");
        }
        this.loadGuiKeyPressed = pressed;
        L73: ;
        if (cfg.keybindFlushQueue == -1) { /* goto L157; */ }
        pressed = this.isKeyPressed(cfg.keybindFlushQueue);
        if (!pressed) { /* goto L152; */ }
        if (this.flushQueueKeyPressed) { /* goto L152; */ }
        int count = this.flushQueuedPacketsUiBehavior();
        if (count > 0) {
            if (shared.isStaggering()) {
                shared.setPendingQueueCompletionMessage("Sent " + count + " packets.");
            } else {
                PackUtilClientMessaging.sendPrefixed("Sent " + count + " packets.");
            }
        } else {
            PackUtilClientMessaging.sendPrefixed("Queue empty.");
        }
        this.flushQueueKeyPressed = pressed;
        L157: ;
        if (cfg.keybindClearQueue == -1) { /* goto L217; */ }
        pressed = this.isKeyPressed(cfg.keybindClearQueue);
        if (!pressed) { /* goto L212; */ }
        if (this.clearQueueKeyPressed) { /* goto L212; */ }
        count = this.clearQueuedPacketsUiBehavior();
        PackUtilClientMessaging.sendPrefixed(count > 0 ? "Cleared " + count + " packets." : "Queue empty.");
        this.clearQueueKeyPressed = pressed;
        L217: ;
        if (cfg.keybindToggleLogger != -1) {
            pressed = this.isKeyPressed(cfg.keybindToggleLogger);
            if (pressed) {
                if (!this.toggleLoggerKeyPressed) {
                    this.togglePacketLoggerUiBehavior();
                }
            }
            this.toggleLoggerKeyPressed = pressed;
        }
        if (cfg.keybindToggleSend == -1) { /* goto L331; */ }
        pressed = this.isKeyPressed(cfg.keybindToggleSend);
        if (!pressed) { /* goto L326; */ }
        if (this.toggleSendKeyPressed) { /* goto L326; */ }
        newValue = !shared.shouldSendGuiPackets();
        this.applySendGuiPacketsUiBehavior(newValue);
        PackUtilClientMessaging.sendPrefixed("GUI packets: " + newValue ? "enabled" : "disabled");
        L326: ;
        this.toggleSendKeyPressed = pressed;
        L331: ;
        if (cfg.keybindToggleDelay == -1) { /* goto L484; */ }
        pressed = this.isKeyPressed(cfg.keybindToggleDelay);
        if (!pressed) { /* goto L479; */ }
        if (this.toggleDelayKeyPressed) { /* goto L479; */ }
        newValue = !shared.shouldDelayGuiPackets();
        int sent = this.applyDelayGuiPacketsUiBehavior(newValue);
        if (newValue) {
            PackUtilClientMessaging.sendPrefixed("Packet delay: enabled");
        } else {
            if (sent > 0) {
                String completionMessage = "Packet delay: disabled. Sent " + sent + " queued packets.";
                if (shared.isStaggering()) {
                    shared.setPendingQueueCompletionMessage(completionMessage);
                } else {
                    PackUtilClientMessaging.sendPrefixed(completionMessage);
                }
            } else {
                if (!this.shouldFlushQueueOnDelayDisable()) {
                    if (!shared.getDelayedPackets().isEmpty()) { /* goto L464; */ }
                    if (!shared.getStaggeredQueue().isEmpty()) {
                        PackUtilClientMessaging.sendPrefixed("Packet delay: disabled. Queue kept.");
                    }
                } else {
                    PackUtilClientMessaging.sendPrefixed("Packet delay: disabled. Queue empty.");
                }
            }
        }
        this.toggleDelayKeyPressed = pressed;
        L484: ;
        pressed = this.cachedKeyboundMacros.iterator();
        while (pressed.hasNext()) {
            macro = (PackUtilMacro)pressed.next();
            pressed = this.isKeyPressed(macro.keyCode);
            boolean wasPressed = ((Boolean)this.macroKeyStates.getOrDefault(macro.name, false)).booleanValue();
            if (!pressed) { /* goto L578; */ }
            if (wasPressed) { /* goto L578; */ }
            if (MacroExecutor.isRunning()) {
                MacroExecutor.stop();
            } else {
                macro.execute();
            }
            this.macroKeyStates.put(macro.name, pressed);
        }
    }

    private void refreshKeyboundMacroCache() {
        PackUtilMacroManager macroManager = PackUtilMacroManager.get();
        long revision = macroManager.getRevision();
        if (revision == this.cachedMacroKeybindRevision) {
            return;
        }
        List<PackUtilMacro> keyboundMacros = new ArrayList();
        Set<String> activeMacroNames = new HashSet();
        var var6 = macroManager.getAll().iterator();
        while (var6.hasNext()) {
            PackUtilMacro macro = (PackUtilMacro)var6.next();
            if (macro == null) continue;
            while (macro.keyCode == -1) {
            }
            keyboundMacros.add(macro);
            activeMacroNames.add(macro.name);
        }
        this.macroKeyStates.keySet().removeIf(PackUtilModule::lambda$refreshKeyboundMacroCache$1 /* captured: activeMacroNames */);
        this.cachedKeyboundMacros = keyboundMacros;
        this.cachedMacroKeybindRevision = revision;
    }

    private String getTooltipSizeText(class_1799 stack) {
        if (!this.tooltipSizeCacheStack.method_7960()) {
            if (this.tooltipSizeCacheStack.method_7947() == stack.method_7947()) {
                if (class_1799.method_31577(this.tooltipSizeCacheStack, stack)) {
                    return this.tooltipSizeCacheText;
                }
            }
        }
        try {
            class_2487 nbt = (class_2487)class_1799.field_24671.encodeStart(MC.field_1724.method_56673().method_57093(class_2509.field_11560), stack).getOrThrow();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            class_2507.method_55324(nbt, new DataOutputStream(baos));
            int bytes = baos.size();
            String sizeStr = bytes >= 1024 ? String.format("%.1f kB", (double)bytes / 1024) : bytes + " B";
            this.tooltipSizeCacheStack = stack.method_7972();
            this.tooltipSizeCacheText = sizeStr + " data";
            return this.tooltipSizeCacheText;
        }
        catch (IOException e) {
            return null;
        }
    }

    private boolean isAnyTextFieldFocused() {
        return PackUtilOverlayManager.get().isAnyTextFieldFocused();
    }

    private boolean isKeyPressed(int keyCode) {
        return MC != null && MC.method_22683() != null && GLFW.glfwGetKey(MC.method_22683().method_4490(), keyCode) == 1;
    }

    private void restoreSavedScreen() {
        PackUtilSharedState shared = PackUtilSharedState.get();
        if (MC == null) {
            return;
        }
        if (shared.getStoredScreen() == null || shared.getStoredScreenHandler() == null) {
            PackUtilClientMessaging.sendPrefixed("§cNo stored GUI.");
            return;
        }
        MC.method_1507(shared.getStoredScreen());
        class_1703 handler = shared.getStoredScreenHandler();
        if (MC.field_1724 != null) {
            MC.field_1724.field_7512 = handler;
        }
        PackUtilClientMessaging.sendPrefixed("GUI restored.");
    }

    static {
        Class[] tmp0 = new Class[13];
        tmp0[0] = class_2827.class;
        tmp0[1] = class_6374.class;
        tmp0[2] = class_9836.class;
        tmp0[3] = class_8590.class;
        tmp0[4] = class_2848.class;
        tmp0[5] = class_2815.class;
        tmp0[6] = class_2879.class;
        tmp0[7] = class_2851.class;
        tmp0[8] = class_2828.class;
        tmp0[9] = class_2828.class_2830.class;
        tmp0[10] = class_2828.class_2831.class;
        tmp0[11] = class_2828.class_5911.class;
        tmp0[12] = class_2828.class_2829.class;
        C2S_EXCLUDED_DEFAULTS = Set.of(tmp0);
    }
}
