/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilOverlayManager;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public abstract class PackUtilRecipeBookScreenMixin {
    @Unique
    private boolean packutil$isActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }

    @Inject(method={"method_25402"}, at={@At(value="HEAD")}, cancellable=true)
    private void packutil$handleOverlayClick(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (!this.packutil$isActive()) {
            return;
        }
        PackUtilOverlayManager manager = PackUtilOverlayManager.get();
        if (manager.handleMouseClicked(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method={"method_25403"}, at={@At(value="HEAD")}, cancellable=true)
    private void packutil$handleOverlayDrag(class_11909 click, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
        if (!this.packutil$isActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleMouseDragged(click.comp_4798(), click.comp_4799(), click.method_74245(), deltaX, deltaY)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method={"method_25404"}, at={@At(value="HEAD")}, cancellable=true)
    private void packutil$handleOverlayKeys(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
        if (!this.packutil$isActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleKeyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method={"method_25400"}, at={@At(value="HEAD")}, cancellable=true)
    private void packutil$handleOverlayChars(class_11905 input, CallbackInfoReturnable<Boolean> cir) {
        if (!this.packutil$isActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleCharTyped((char)input.comp_4793(), input.comp_4794())) {
            cir.setReturnValue(true);
        }
    }
}
