/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilClientMessaging;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilChatScreenMixin {
    @Inject(method={"method_44056"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$onSendMessage(String message, boolean addToHistory, CallbackInfo ci) {
        if (!"^togglepackutil".equalsIgnoreCase(message.trim())) {
            return;
        }
        PackUtilModule module = PackUtilModule.get();
        module.toggle();
        class_310 mc = class_310.method_1551();
        PackUtilClientMessaging.sendPrefixed("PackUtil is now " + module.isActive() ? "enabled" : "disabled" + ".");
        if (mc.field_1705 != null) {
            mc.field_1705.method_1743().method_1803(message);
        }
        mc.method_1507(null);
        ci.cancel();
    }
}
