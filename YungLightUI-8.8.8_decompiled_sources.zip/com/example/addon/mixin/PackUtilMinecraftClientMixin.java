/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.gui.macro.editor.ActionEditorOverlay;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilSharedState;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class PackUtilMinecraftClientMixin {
    private boolean packutil$escapeWasDown;
    private boolean packutil$inventoryWasDown;

    @Inject(method={"method_1574"}, at={@At(value="HEAD")})
    private void packutil$onTickHead(CallbackInfo ci) {
        PackUtilSharedState.get().onClientTickStart();
    }

    @Inject(method={"method_1536"}, at={@At(value="HEAD")}, cancellable=true)
    private void packutil$onDoAttack(CallbackInfoReturnable<Boolean> cir) {
        if (PackUtilSharedState.get().hasAttackCaptureCallback()) {
            PackUtilSharedState.get().consumeAttackCaptureCallback();
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"method_1508"}, at={@At(value="HEAD")}, cancellable=true)
    private void packutil$cancelCaptureOnEscape(CallbackInfo ci) {
        class_310 client = (class_310)this;
        if (client.method_22683() == null) {
            return;
        }
        boolean escapeDown = GLFW.glfwGetKey(client.method_22683().method_4490(), 256) == 1;
        boolean justPressed = escapeDown && !this.packutil$escapeWasDown;
        this.packutil$escapeWasDown = escapeDown;
        boolean inventoryDown = client.field_1690 != null && client.field_1690.field_1822.method_1434();
        boolean inventoryJustPressed = inventoryDown && !this.packutil$inventoryWasDown;
        this.packutil$inventoryWasDown = inventoryDown;
        if (justPressed || inventoryJustPressed) {
            if (PackUtilSharedState.get().consumeCaptureCancelCallback()) {
                ci.cancel();
                return;
            }
            ActionEditorOverlay actionEditor = ActionEditorOverlay.getSharedOverlayIfExists();
            if (actionEditor != null) {
                if (actionEditor.cancelCaptureIfActive()) {
                    ci.cancel();
                }
            }
        }
    }

    @Inject(method={"method_15995"}, at={@At(value="HEAD")}, cancellable=true)
    private void onWindowFocusChanged(boolean focused, CallbackInfo ci) {
        if (!focused) {
            PackUtilModule module = PackUtilModule.get();
            if (module != null) {
                if (module.isActive()) {
                    if (module.isNoPauseOnLostFocus()) {
                        ci.cancel();
                    }
                }
            }
        }
    }
}
