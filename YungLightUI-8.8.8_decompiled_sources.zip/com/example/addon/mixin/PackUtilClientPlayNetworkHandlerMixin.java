/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroConditionRegistry;
import net.minecraft.class_2649;
import net.minecraft.class_2653;
import net.minecraft.class_2761;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilClientPlayNetworkHandlerMixin {
    @Inject(method={"method_11153"}, at={@At(value="RETURN")})
    private void yang$onInventory(class_2649 packet, CallbackInfo ci) {
        MacroConditionRegistry.onInventorySync(class_310.method_1551());
    }

    @Inject(method={"method_11109"}, at={@At(value="RETURN")})
    private void yang$onSlotUpdate(class_2653 packet, CallbackInfo ci) {
        MacroConditionRegistry.onSlotUpdate(packet.method_11450());
    }

    @Inject(method={"method_11146"}, at={@At(value="RETURN")})
    private void yang$onPlaySound(class_2767 packet, CallbackInfo ci) {
        try {
            String soundId = ((class_3414)packet.method_11894().comp_349()).comp_3319().toString();
            MacroConditionRegistry.onSoundPacket(soundId, packet.method_11890(), packet.method_11889(), packet.method_11893());
        }
        catch (Exception soundId) {
            return;
        }
    }

    @Inject(method={"method_11079"}, at={@At(value="RETURN")})
    private void yang$onWorldTimeUpdate(class_2761 packet, CallbackInfo ci) {
        PackUtilSharedState.get().onServerTimeSyncReceived();
    }
}
