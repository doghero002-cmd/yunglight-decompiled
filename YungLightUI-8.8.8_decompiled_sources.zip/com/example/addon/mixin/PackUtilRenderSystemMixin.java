/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.gui.packui.PackUiTextMeshUniforms;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilRenderSystemMixin {
    @Inject(method={"flipFrame"}, at={@At(value="TAIL")})
    private static void packutil$flipFrame(CallbackInfo info) {
        PackUiTextMeshUniforms.flipFrame();
    }
}
