/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.gui.packui.PackUiTextPipelines;
import net.minecraft.class_10151;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilShaderLoaderMixin {
    @Inject(method={"method_62945(Lnet/minecraft/class_10151$class_10153;Lnet/minecraft/class_3300;Lnet/minecraft/class_3695;)V"}, at={@At(value="TAIL")})
    private void packutil$precompileTextPipelines(class_10151.class_10153 definitions, class_3300 resourceManager, class_3695 profiler, CallbackInfo info) {
        PackUiTextPipelines.precompile(resourceManager);
    }
}
