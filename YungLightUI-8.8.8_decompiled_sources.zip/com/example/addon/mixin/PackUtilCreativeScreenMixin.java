/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilOverlayManager;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public abstract class PackUtilCreativeScreenMixin {
    @Inject(method={"method_25404"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void packutil$keyPressed(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
        PackUtilModule module = PackUtilModule.get();
        if (module == null || !module.isActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleKeyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797())) {
            cir.setReturnValue(true);
            return;
        }
    }

    @Inject(method={"method_25400"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void packutil$charTyped(class_11905 input, CallbackInfoReturnable<Boolean> cir) {
        PackUtilModule module = PackUtilModule.get();
        if (module == null || !module.isActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleCharTyped((char)input.comp_4793(), input.comp_4794())) {
            cir.setReturnValue(true);
            return;
        }
    }
}
