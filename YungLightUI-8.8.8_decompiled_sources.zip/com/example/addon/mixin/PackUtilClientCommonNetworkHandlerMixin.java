/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilClientMessaging;
import com.example.addon.util.PackUtilSharedState;
import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilClientCommonNetworkHandlerMixin {
    protected class_310 field_45588;

    @Shadow
    public abstract void method_52787(class_2596<?> var1);

    @Inject(method={"method_52784"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$onResourcePackSend(class_2720 packet, CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean shouldForceDeny = shared.shouldForceDenyResourcePack();
        boolean shouldBypass = shared.shouldBypassResourcePack();
        if (!shouldForceDeny) {
            if (!shouldBypass || !packet.comp_2161()) {
                return;
            }
        }
        if (shouldBypass) {
            this.method_52787(new class_2856(this.field_45588.method_1548().method_44717(), class_2856.class_2857.field_13016));
            this.method_52787(new class_2856(this.field_45588.method_1548().method_44717(), class_2856.class_2857.field_13017));
        } else {
            this.method_52787(new class_2856(this.field_45588.method_1548().method_44717(), class_2856.class_2857.field_13018));
        }
        PackUtilClientMessaging.sendPrefixed("PackUtil denied server resource pack.");
        ci.cancel();
    }

    private boolean isPackUtilActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }
}
