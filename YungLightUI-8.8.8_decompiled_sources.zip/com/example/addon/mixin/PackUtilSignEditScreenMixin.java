/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilCustomFilterOverlay;
import com.example.addon.util.PackUtilCustomFilterPresetOverlay;
import com.example.addon.util.PackUtilKeybindOverlay;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilLANSyncOverlay;
import com.example.addon.util.PackUtilLauncherOverlay;
import com.example.addon.util.PackUtilMacroEditorOverlay;
import com.example.addon.util.PackUtilMacroListOverlay;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilQueueEditorOverlay;
import com.example.addon.util.PackUtilServerInfoOverlay;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilSignEditScreenMixin
extends class_437 {
    private static final class_310 MC = class_310.method_1551();
    private PackUtilLauncherOverlay launcherOverlay;
    private PackUtilLANSyncOverlay lanSyncOverlay;
    private PackUtilMacroListOverlay macroListOverlay;
    private PackUtilQueueEditorOverlay queueEditorOverlay;
    private PackUtilPacketLoggerOverlay packetLoggerOverlay;
    private PackUtilCustomFilterOverlay customFilterOverlay;
    private PackUtilCustomFilterPresetOverlay customFilterPresetOverlay;
    private PackUtilMacroEditorOverlay macroEditorOverlay;
    private PackUtilKeybindOverlay keybindOverlay;
    private PackUtilServerInfoOverlay serverInfoOverlay;

    protected PackUtilSignEditScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"method_25426"}, at={@At(value="TAIL")})
    private void yang$init(CallbackInfo ci) {
        if (!this.yang$isPackUtilActive()) {
            return;
        }
        PackUtilLANSync.getInstance().setOnSessionStateChanged(PackUtilSignEditScreenMixin::lambda$yang$init$0);
        this.lanSyncOverlay = PackUtilLANSyncOverlay.getSharedOverlay(this.field_22793);
        this.macroListOverlay = new PackUtilMacroListOverlay(this.field_22793);
        this.queueEditorOverlay = new PackUtilQueueEditorOverlay(this.field_22793);
        this.customFilterOverlay = new PackUtilCustomFilterOverlay(this.field_22793);
        this.customFilterPresetOverlay = this.customFilterOverlay.getPresetManagerOverlay();
        this.lanSyncOverlay.restoreState();
        this.macroListOverlay.restoreState();
        this.queueEditorOverlay.restoreState();
        this.customFilterOverlay.restoreLayout();
        if (this.customFilterPresetOverlay != null) {
            this.customFilterPresetOverlay.restoreLayout();
        }
        this.macroEditorOverlay = PackUtilMacroEditorOverlay.getSharedOverlay();
        if (this.macroEditorOverlay != null) {
            this.macroEditorOverlay.restoreState();
        }
        PackUtilOverlayManager manager = PackUtilOverlayManager.get();
        manager.clear();
        manager.register(this.lanSyncOverlay);
        manager.register(this.macroListOverlay);
        manager.register(this.queueEditorOverlay);
        manager.register(this.customFilterOverlay);
        if (this.customFilterPresetOverlay != null) {
            manager.register(this.customFilterPresetOverlay);
        }
        if (this.macroEditorOverlay != null) {
            manager.register(this.macroEditorOverlay);
        }
        PackUtilModule packutilModule = PackUtilModule.get();
        if (packutilModule != null) {
            this.packetLoggerOverlay = packutilModule.getPacketLoggerOverlay();
            if (this.packetLoggerOverlay != null) {
                this.packetLoggerOverlay.restoreLayout();
                manager.register(this.packetLoggerOverlay);
            }
        }
        this.keybindOverlay = new PackUtilKeybindOverlay();
        this.keybindOverlay.restoreLayout();
        manager.register(this.keybindOverlay);
        this.serverInfoOverlay = PackUtilModule.get().getServerInfoOverlay();
        manager.register(this.serverInfoOverlay);
        this.launcherOverlay = new PackUtilLauncherOverlay(this.macroListOverlay, null, this.lanSyncOverlay, this.queueEditorOverlay, this.packetLoggerOverlay, this.customFilterOverlay);
        this.launcherOverlay.setKeybindOverlay(this.keybindOverlay);
        this.launcherOverlay.setServerInfoOverlay(this.serverInfoOverlay);
        this.launcherOverlay.setCloseWithoutPacketAction(PackUtilSignEditScreenMixin::lambda$yang$init$1);
        this.launcherOverlay.restoreLayout();
        manager.register(this.launcherOverlay);
        class_437 screen = (class_437)this;
        ScreenEvents.afterRender(screen).register(this::lambda$yang$init$2);
    }

    public void method_25432() {
        if (this.yang$isPackUtilActive()) {
            if (this.lanSyncOverlay != null) {
                this.lanSyncOverlay.saveState();
            }
            if (this.macroListOverlay != null) {
                this.macroListOverlay.saveState();
            }
            if (this.queueEditorOverlay != null) {
                this.queueEditorOverlay.saveState();
            }
            if (this.macroEditorOverlay != null) {
                this.macroEditorOverlay.saveState();
            }
            if (this.launcherOverlay != null) {
                this.launcherOverlay.saveLayout();
            }
            if (this.packetLoggerOverlay != null) {
                this.packetLoggerOverlay.saveLayout();
            }
            if (this.customFilterOverlay != null) {
                this.customFilterOverlay.saveLayout();
            }
            if (this.customFilterPresetOverlay != null) {
                this.customFilterPresetOverlay.saveLayout();
            }
            if (this.keybindOverlay != null) {
                this.keybindOverlay.saveLayout();
            }
            if (this.serverInfoOverlay != null) {
                this.serverInfoOverlay.saveState();
            }
            PackUtilOverlayManager.get().clear();
        }
        super.method_25432();
    }

    public boolean method_25402(class_11909 click, boolean doubled) {
        if (this.yang$isPackUtilActive() && PackUtilOverlayManager.get().handleMouseClicked(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            return true;
        }
        return super.method_25402(click, doubled);
    }

    public boolean method_25406(class_11909 click) {
        if (this.yang$isPackUtilActive() && PackUtilOverlayManager.get().handleMouseReleased(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            return true;
        }
        return super.method_25406(click);
    }

    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        if (this.yang$isPackUtilActive() && PackUtilOverlayManager.get().handleMouseDragged(click.comp_4798(), click.comp_4799(), click.method_74245(), deltaX, deltaY)) {
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.yang$isPackUtilActive() && PackUtilOverlayManager.get().handleMouseScrolled(mouseX, mouseY, verticalAmount)) {
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean method_25404(class_11908 input) {
        if (this.yang$isPackUtilActive() && PackUtilOverlayManager.get().handleKeyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797())) {
            return true;
        }
        return super.method_25404(input);
    }

    public boolean method_25400(class_11905 input) {
        if (this.yang$isPackUtilActive() && PackUtilOverlayManager.get().handleCharTyped((char)input.comp_4793(), input.comp_4794())) {
            return true;
        }
        return super.method_25400(input);
    }

    @Unique
    private boolean yang$isPackUtilActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }
}
