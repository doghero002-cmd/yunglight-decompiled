/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.gui.macro.editor.ActionEditorOverlay;
import com.example.addon.gui.packui.PackUiBannerRenderer;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilCustomFilterOverlay;
import com.example.addon.util.PackUtilCustomFilterPresetOverlay;
import com.example.addon.util.PackUtilFabricatorOverlay;
import com.example.addon.util.PackUtilInventoryMoveHelper;
import com.example.addon.util.PackUtilKeybindOverlay;
import com.example.addon.util.PackUtilLANSync;
import com.example.addon.util.PackUtilLANSyncOverlay;
import com.example.addon.util.PackUtilLauncherOverlay;
import com.example.addon.util.PackUtilMacroEditorOverlay;
import com.example.addon.util.PackUtilMacroListOverlay;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilQueueEditorOverlay;
import com.example.addon.util.PackUtilServerInfoOverlay;
import com.example.addon.util.PackUtilSharedState;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public abstract class PackUtilHandledScreenMixin<T extends class_1703>
extends class_437 {
    private static final PackUiTheme PACKUI_THEME = new PackUiTheme();
    protected class_1735 field_2787;
    private static final class_310 MC = class_310.method_1551();
    private class_1735 packutil$blockedFocusedSlot;
    private PackUtilLauncherOverlay launcherOverlay;
    private PackUtilFabricatorOverlay fabricatorOverlay;
    private PackUtilLANSyncOverlay lanSyncOverlay;
    private PackUtilMacroListOverlay macroListOverlay;
    private PackUtilQueueEditorOverlay queueEditorOverlay;
    private PackUtilPacketLoggerOverlay packetLoggerOverlay;
    private PackUtilCustomFilterOverlay customFilterOverlay;
    private PackUtilCustomFilterPresetOverlay customFilterPresetOverlay;
    private PackUtilMacroEditorOverlay macroEditorOverlay;
    private PackUtilKeybindOverlay keybindOverlay;
    private PackUtilServerInfoOverlay serverInfoOverlay;
    private boolean coreExpanded = true;
    private boolean queueExpanded = false;
    private boolean toolsExpanded = false;
    private int coreButtonsStartY;
    private int queueHeaderY;
    private int queueButtonsStartY;
    private int queueButtonsEndY;
    private int toolsHeaderY;
    private int toolsButtonsStartY;
    private int toolsButtonsEndY;

    @Shadow
    protected abstract void method_2383(class_1735 var1, int var2, int var3, class_1713 var4);

    protected PackUtilHandledScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"method_25426"}, at={@At(value="TAIL")})
    private void yang$init(CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        PackUtilLANSync.getInstance().setOnSessionStateChanged(PackUtilHandledScreenMixin::lambda$yang$init$0);
        class_465<?> handledScreen = (class_465)this;
        this.fabricatorOverlay = PackUtilFabricatorOverlay.getSharedOverlay(handledScreen);
        this.lanSyncOverlay = PackUtilLANSyncOverlay.getSharedOverlay(this.field_22793);
        this.macroListOverlay = new PackUtilMacroListOverlay(this.field_22793);
        this.queueEditorOverlay = new PackUtilQueueEditorOverlay(this.field_22793);
        this.customFilterOverlay = new PackUtilCustomFilterOverlay(this.field_22793);
        this.customFilterPresetOverlay = this.customFilterOverlay.getPresetManagerOverlay();
        this.fabricatorOverlay.restoreState();
        this.lanSyncOverlay.restoreState();
        this.macroListOverlay.restoreState();
        this.queueEditorOverlay.restoreState();
        this.customFilterOverlay.restoreLayout();
        if (this.customFilterPresetOverlay != null) {
            this.customFilterPresetOverlay.restoreLayout();
        }
        this.macroEditorOverlay = PackUtilMacroEditorOverlay.getSharedOverlay();
        if (this.macroEditorOverlay != null) {
            this.macroEditorOverlay.restoreState();
        }
        PackUtilOverlayManager manager = PackUtilOverlayManager.get();
        manager.clear();
        manager.register(this.fabricatorOverlay);
        manager.register(this.lanSyncOverlay);
        manager.register(this.macroListOverlay);
        manager.register(this.queueEditorOverlay);
        manager.register(this.customFilterOverlay);
        if (this.customFilterPresetOverlay != null) {
            manager.register(this.customFilterPresetOverlay);
        }
        if (this.macroEditorOverlay != null) {
            manager.register(this.macroEditorOverlay);
        }
        manager.register(ActionEditorOverlay.getSharedOverlay());
        PackUtilModule packutilModule = PackUtilModule.get();
        if (packutilModule != null) {
            this.packetLoggerOverlay = packutilModule.getPacketLoggerOverlay();
            if (this.packetLoggerOverlay != null) {
                this.packetLoggerOverlay.restoreLayout();
                manager.register(this.packetLoggerOverlay);
            }
        }
        this.keybindOverlay = new PackUtilKeybindOverlay();
        this.keybindOverlay.restoreLayout();
        manager.register(this.keybindOverlay);
        this.serverInfoOverlay = PackUtilModule.get().getServerInfoOverlay();
        manager.register(this.serverInfoOverlay);
        this.launcherOverlay = new PackUtilLauncherOverlay(this.macroListOverlay, this.fabricatorOverlay, this.lanSyncOverlay, this.queueEditorOverlay, this.packetLoggerOverlay, this.customFilterOverlay);
        this.launcherOverlay.setKeybindOverlay(this.keybindOverlay);
        this.launcherOverlay.setServerInfoOverlay(this.serverInfoOverlay);
        this.launcherOverlay.restoreLayout();
        manager.register(this.launcherOverlay);
        class_437 screen = (class_437)this;
        ScreenEvents.afterRender(screen).register(this::lambda$yang$init$1);
        this.refreshButtonVisibility();
    }

    @Unique
    private void refreshButtonVisibility() {
    }

    @Inject(method={"method_25394"}, at={@At(value="HEAD")})
    private void yang$blockCoveredSlotHover(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().shouldBlockUnderlyingHover((double)mouseX, (double)mouseY)) {
            this.packutil$blockedFocusedSlot = this.field_2787;
            this.field_2787 = null;
        } else {
            this.packutil$blockedFocusedSlot = null;
        }
    }

    @Inject(method={"method_64240"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void packutil$blockCoveredSlotLookup(double mouseX, double mouseY, CallbackInfoReturnable<class_1735> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().shouldBlockUnderlyingHover(mouseX, mouseY)) {
            cir.setReturnValue(null);
        }
    }

    @Inject(method={"method_2387"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void packutil$blockCoveredSlotHitbox(class_1735 slot, double pointX, double pointY, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().shouldBlockUnderlyingHover(pointX, pointY)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"method_2380"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void packutil$blockCoveredHandledTooltip(class_332 context, int x, int y, CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().shouldBlockUnderlyingHover((double)x, (double)y)) {
            ci.cancel();
        }
    }

    @Inject(method={"method_25394"}, at={@At(value="TAIL")})
    public void yang$render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.packutil$blockedFocusedSlot != null) {
            this.field_2787 = this.packutil$blockedFocusedSlot;
            this.packutil$blockedFocusedSlot = null;
        }
    }

    @Unique
    private void renderMacroCaptureBanner(class_332 context) {
        ActionEditorOverlay actionEditor = ActionEditorOverlay.getSharedOverlayIfExists();
        boolean macroCapture = this.macroEditorOverlay != null && this.macroEditorOverlay.shouldRenderHandledScreenCaptureBanner();
        boolean actionCapture = actionEditor != null && actionEditor.shouldRenderHandledScreenCaptureBanner();
        if (!macroCapture && !actionCapture) {
            return;
        }
        if (MC == null || MC.method_22683() == null || this.field_22793 == null) {
            return;
        }
        String title = macroCapture ? this.macroEditorOverlay.getHandledScreenCaptureTitle() : actionEditor.getHandledScreenCaptureTitle();
        String instruction = macroCapture ? this.macroEditorOverlay.getHandledScreenCaptureInstruction() : actionEditor.getHandledScreenCaptureInstruction();
        String hover = "";
        if (this.field_2787 == null) { /* goto L233; */ }
        class_1799 stack = this.field_2787.method_7677();
        String itemName = stack.method_7960() ? "" : stack.method_7964().getString();
        String registryId = stack.method_7960() ? "" : class_7923.field_41178.method_10221(stack.method_7909()).toString();
        hover = macroCapture ? this.macroEditorOverlay.getHandledScreenCaptureHoverText(this.field_2787, itemName, registryId) : actionEditor.getHandledScreenCaptureHoverText(this.field_2787, itemName, registryId);
        maxTextWidth = Math.max(PackUiText.width(this.field_22793, title, PACKUI_THEME.fontFor(PackUiTone.LABEL), PACKUI_THEME.color(PackUiTone.BODY)), PackUiText.width(this.field_22793, instruction, PACKUI_THEME.fontFor(PackUiTone.BODY), PACKUI_THEME.color(PackUiTone.BODY)));
        if (!hover.isEmpty()) {
            maxTextWidth = Math.max(maxTextWidth, PackUiText.width(this.field_22793, hover, PACKUI_THEME.fontFor(PackUiTone.MUTED), PACKUI_THEME.color(PackUiTone.MUTED)));
        }
        boxWidth = Math.min(MC.method_22683().method_4486() - 16, Math.max(250, maxTextWidth + 18));
        boxX = (MC.method_22683().method_4486() - boxWidth) / 2;
        int boxY = 8;
        PackUiBannerRenderer.drawFloatingBanner(context, this.field_22793, PACKUI_THEME, boxX, boxY, boxWidth, title, instruction, hover, PACKUI_THEME.headerAccent());
        if (!actionCapture) { /* goto L461; */ }
        if (actionEditor == null) { /* goto L461; */ }
        if (!actionEditor.hasHandledScreenCaptureToasts()) { /* goto L461; */ }
        int bannerHeight = hover.isEmpty() ? 34 : 46;
        actionEditor.renderHandledScreenCaptureToasts(context, boxX, boxY + bannerHeight + 6, boxWidth);
    }

    @Inject(method={"method_25432"}, at={@At(value="HEAD")})
    private void yang$removed(CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        PackUtilInventoryMoveHelper.releaseMovementKeysIfSafe();
        ActionEditorOverlay actionEditor = ActionEditorOverlay.getSharedOverlayIfExists();
        boolean skipTransientCaptureSave = actionEditor != null && actionEditor.hasActiveCaptureSession();
        if (!skipTransientCaptureSave) {
            if (this.fabricatorOverlay != null) {
                this.fabricatorOverlay.saveState();
            }
            if (this.lanSyncOverlay != null) {
                this.lanSyncOverlay.saveState();
            }
            if (this.macroListOverlay != null) {
                this.macroListOverlay.saveState();
            }
            if (this.queueEditorOverlay != null) {
                this.queueEditorOverlay.saveState();
            }
            if (this.macroEditorOverlay != null) {
                this.macroEditorOverlay.saveState();
            }
            if (this.launcherOverlay != null) {
                this.launcherOverlay.saveLayout();
            }
            if (this.packetLoggerOverlay != null) {
                this.packetLoggerOverlay.saveLayout();
            }
            if (this.customFilterOverlay != null) {
                this.customFilterOverlay.saveLayout();
            }
            if (this.customFilterPresetOverlay != null) {
                this.customFilterPresetOverlay.saveLayout();
            }
            if (this.keybindOverlay != null) {
                this.keybindOverlay.saveLayout();
            }
            if (this.serverInfoOverlay != null) {
                this.serverInfoOverlay.saveState();
            }
        }
        PackUtilOverlayManager.get().clear();
    }

    @Unique
    private boolean isPackUtilActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }

    @Unique
    private void updateButtonLabels() {
    }

    @Unique
    private static String onOff(boolean value) {
        return value ? "ON" : "OFF";
    }

    @Unique
    private static String stateText(boolean value) {
        return value ? "enabled" : "disabled";
    }

    @Inject(method={"method_25402"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$mouseClicked(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();
        PackUtilOverlayManager manager = PackUtilOverlayManager.get();
        if (manager.handleMouseClicked(mouseX, mouseY, button)) {
            cir.setReturnValue(true);
            return;
        }
        if (button != 1) { /* goto L221; */ }
        if (this.field_2787 == null) { /* goto L221; */ }
        class_1799 captureStack = this.field_2787.method_7677();
        String captureItemName = captureStack.method_7960() ? "" : captureStack.method_7964().getString();
        String captureRegistryId = captureStack.method_7960() ? "" : class_7923.field_41178.method_10221(captureStack.method_7909()).toString();
        PackUtilMacroEditorOverlay editor = this.macroEditorOverlay;
        cir.setReturnValue(true);
        if (editor != null && editor.wantsSlotCapture() && editor.onSlotRightClick(this.field_2787, captureItemName, captureRegistryId)) {
            return;
        }
        ActionEditorOverlay actionEditor = ActionEditorOverlay.getSharedOverlayIfExists();
        cir.setReturnValue(true);
        if (actionEditor != null && actionEditor.wantsItemSlotCapture() && actionEditor.onInventorySlotCapture(this.field_2787, captureItemName, captureRegistryId)) {
            return;
        }
        this.fabricatorOverlay.onSlotClick(this.field_2787, button);
        if (this.fabricatorOverlay != null && this.fabricatorOverlay.isVisible() && button == 1 && this.field_2787 != null) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method={"method_25404"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$keyPressed(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        boolean inventoryKey = MC != null && MC.field_1690 != null && MC.field_1690.field_1822.method_1417(input);
        if (inventoryKey) {
            if (PackUtilSharedState.get().consumeCaptureCancelCallback()) {
                cir.setReturnValue(true);
                return;
            }
            ActionEditorOverlay actionEditor = ActionEditorOverlay.getSharedOverlayIfExists();
            if (actionEditor != null) {
                if (actionEditor.cancelCaptureIfActive()) {
                    cir.setReturnValue(true);
                    return;
                }
            }
        }
        if (PackUtilOverlayManager.get().handleKeyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797())) {
            cir.setReturnValue(true);
            return;
        }
        if (input.comp_4795() == 256) {
            if (PackUtilSharedState.get().consumeCaptureCancelCallback()) {
                cir.setReturnValue(true);
                return;
            }
            actionEditor = ActionEditorOverlay.getSharedOverlayIfExists();
            if (actionEditor != null) {
                if (actionEditor.cancelCaptureIfActive()) {
                    cir.setReturnValue(true);
                }
            }
        }
        if (PackUtilInventoryMoveHelper.handleKeyInput(input, true)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method={"keyReleased"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void yang$keyReleased(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilInventoryMoveHelper.handleKeyInput(input, false)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method={"method_25406"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$mouseReleased(class_11909 click, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleMouseReleased(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            cir.setReturnValue(true);
            return;
        }
    }

    @Inject(method={"method_25403"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$mouseDragged(class_11909 click, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleMouseDragged(click.comp_4798(), click.comp_4799(), click.method_74245(), deltaX, deltaY)) {
            cir.setReturnValue(true);
            return;
        }
    }

    @Inject(method={"method_25401"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (PackUtilOverlayManager.get().handleMouseScrolled(mouseX, mouseY, verticalAmount)) {
            cir.setReturnValue(true);
            return;
        }
    }

    public boolean method_25400(class_11905 input) {
        if (!this.isPackUtilActive()) {
            return super.method_25400(input);
        }
        if (PackUtilOverlayManager.get().handleCharTyped((char)input.comp_4793(), input.comp_4794())) {
            return true;
        }
        return super.method_25400(input);
    }
}
