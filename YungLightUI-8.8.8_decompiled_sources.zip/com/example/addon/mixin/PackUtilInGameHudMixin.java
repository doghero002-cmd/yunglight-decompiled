/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.gui.packui.PackUiBannerRenderer;
import com.example.addon.gui.packui.PackUiText;
import com.example.addon.gui.packui.PackUiTheme;
import com.example.addon.gui.packui.PackUiTone;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilMacroProgressRenderer;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilQueueRenderer;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroExecutor;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilInGameHudMixin {
    private static final class_310 MC = class_310.method_1551();
    private static final PackUiTheme PACKUI_THEME = new PackUiTheme();
    private static final int PACKUTIL_RIGHT_PANEL_Y = 20;

    @Inject(method={"method_1753"}, at={@At(value="TAIL")})
    private void yang$renderPackUtilQueue(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        MacroExecutor.onRender(1f);
        if (MC.field_1690.field_1842) {
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean blockCap = shared.hasBlockCaptureCallback();
        boolean entityCap = shared.hasEntityCaptureCallback();
        boolean attackCap = shared.hasAttackCaptureCallback();
        boolean gbreakCap = shared.isGBreakCapturing();
        if (!blockCap) {
            if (!entityCap) {
                if (attackCap) { /* goto @78; */ }
            }
        }
        int sw = MC.method_22683().method_4486();
        int baseY = 8;
        String title = gbreakCap ? "GBreak Capture" : blockCap ? "Block Capture" : entityCap ? "Entity Capture" : "Position Capture";
        String line1 = gbreakCap ? "Break a block to capture the insta-break packet. Esc = cancel" : blockCap ? "Right-click a block to capture it. Esc = cancel" : entityCap ? "Right-click an entity to capture it. Esc = cancel" : "Left-click to capture the target position. Esc = cancel";
        String line2 = "";
        if (gbreakCap) {
            line2 = "Waiting for the block-break packet from your next block break";
        } else {
            if (blockCap) {
                if (MC.field_1765 != null) {
                    if (MC.field_1765.method_17783() == class_239.class_240.field_1332) {
                        if (MC.field_1687 != null) {
                            class_3965 bhr = (class_3965)MC.field_1765;
                            String bn = MC.field_1687.method_8320(bhr.method_17777()).method_26204().method_9518().getString();
                            class_2338 bp = bhr.method_17777();
                            line2 = "§7Aimed at: §f" + bn + " §8(" + bp.method_10263() + ", " + bp.method_10264() + ", " + bp.method_10260() + ")";
                        }
                    }
                }
            } else {
                if (entityCap) {
                    if (MC.field_1692 != null) {
                        if (MC.field_1692 != MC.field_1724) {
                            String eName = MC.field_1692.method_5864().method_5897().getString();
                            String eId = class_7923.field_41177.method_10221(MC.field_1692.method_5864()).toString();
                            line2 = "§7Aimed at: §f" + eName + " §8(" + eId + ")";
                        }
                    }
                }
            }
        }
        line2 = line2.replaceAll("§.", "");
        boxWidth = Math.min(sw - 16, Math.max(270, Math.max(PackUiText.width(MC.field_1772, title, PACKUI_THEME.fontFor(PackUiTone.LABEL), PACKUI_THEME.color(PackUiTone.BODY)), Math.max(PackUiText.width(MC.field_1772, line1, PACKUI_THEME.fontFor(PackUiTone.BODY), PACKUI_THEME.color(PackUiTone.BODY)), line2.isEmpty() ? 0 : PackUiText.width(MC.field_1772, line2, PACKUI_THEME.fontFor(PackUiTone.MUTED), PACKUI_THEME.color(PackUiTone.MUTED)))) + 18));
        boxX = (sw - boxWidth) / 2;
        PackUiBannerRenderer.drawFloatingBanner(context, MC.field_1772, PACKUI_THEME, boxX, baseY, boxWidth, title, line1, line2, PACKUI_THEME.headerAccent());
        L541: ;
        macroRunning = MacroExecutor.isRunning();
        queueSending = shared.hasStaggeredPackets();
        queueVisible = shared.shouldDelayGuiPackets() || shared.hasDelayedPackets() || queueSending;
        screenWidth = MC.method_22683().method_4486();
        y = 20;
        if (queueVisible) {
            x = screenWidth - 170;
            PackUtilQueueRenderer.render(context, MC.field_1772, x, y, 160, 8);
        }
        if (!macroRunning) { /* goto L690; */ }
        macroW = 170;
        if (queueVisible) {
            macroX = screenWidth - 176 - 5 - macroW - 6;
        } else {
            macroX = screenWidth - macroW - 10;
        }
        PackUtilMacroProgressRenderer.render(context, MC.field_1772, macroX, y, macroW, 10);
        L690: ;
        if (MC.field_1755 == null) {
            serverInfoOverlay = PackUtilModule.get().getServerInfoOverlayIfExists();
            if (serverInfoOverlay != null) {
                if (serverInfoOverlay.shouldRenderBackgroundProbeBanner()) {
                    serverInfoOverlay.renderBackgroundProbeBanner(context);
                }
            }
            PackUtilOverlayManager.get().renderAll(context, -1, -1, 0f);
        }
    }

    @Unique
    private boolean isPackUtilActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }
}
