/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.util.PackUtilOverlayManager;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilClickableWidgetMixin {
    protected boolean field_22762;

    @Inject(method={"method_25394(Lnet/minecraft/class_332;IIF)V"}, at={@At(value="FIELD", target="Lnet/minecraft/class_339;field_22762:Z", shift=At.Shift.AFTER)})
    private void packutil$suppressHoverWhenOverlayBlocks(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (PackUtilOverlayManager.get().shouldBlockUnderlyingHover((double)mouseX, (double)mouseY)) {
            this.field_22762 = false;
        }
    }
}
