/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.YungLightAddon;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilContainerTarget;
import com.example.addon.util.PackUtilSharedState;
import com.example.addon.util.macro.MacroExecutor;
import com.example.addon.util.macro.ServerTickTracker;
import io.netty.channel.ChannelFutureListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1735;
import net.minecraft.class_243;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2811;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2820;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_2873;
import net.minecraft.class_2877;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilClientConnectionMixin {
    @Inject(method={"method_10752(Lnet/minecraft/class_2596;Lio/netty/channel/ChannelFutureListener;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void yang$onSendPacket(class_2596<?> packet, ChannelFutureListener listener, CallbackInfo ci) {
        if (packet instanceof class_2885) {
            class_2885 pibp = (class_2885)packet;
            if (PackUtilSharedState.get().consumeBlockCaptureCallback(pibp.method_12543().method_17777())) {
                ci.cancel();
                return;
            }
            PackUtilSharedState.get().setLastInteractedBlockPos(pibp.method_12543().method_17777());
            PackUtilSharedState.get().setLastContainerTarget(PackUtilContainerTarget.forBlock(pibp.method_12543().method_17777()));
        }
        if (packet instanceof class_2824) {
            entityPacket = (class_2824)packet;
            class_1297 targeted = class_310.method_1551().field_1692;
            if (targeted != null) {
                if (targeted != class_310.method_1551().field_1724) {
                    class_1268[] tmp0 = new class_1268[1];
                    tmp0[0] = class_1268.field_5808;
                    class_1268[] capturedHand = tmp0;
                    class_243[] tmp1 = new class_243[1];
                    tmp1[0] = null;
                    class_243[] capturedHitPos = tmp1;
                    boolean[] tmp2 = new boolean[1];
                    tmp2[0] = 0;
                    boolean[] isAttack = tmp2;
                }
            }
        }
        try {
            entityPacket.method_34209(new PackUtilClientConnectionMixin.1(this, capturedHand, capturedHitPos, isAttack));
        }
        catch (Throwable dispName) {
            if (isAttack[0] != 0) { /* goto @203; */ }
            if (capturedHitPos[0] == null) { /* goto @191; */ }
            /* note: clearing non-empty stack before goto */
            /* goto @200; */
        }
        if (isAttack[0] != 0) { /* goto L203; */ }
        PackUtilSharedState.get().setLastContainerTarget(capturedHitPos[0] != null ? PackUtilContainerTarget.forEntityAt(targeted, capturedHand[0], capturedHitPos[0]) : PackUtilContainerTarget.forEntity(targeted, capturedHand[0]));
        if (!packet instanceof class_2824) { /* goto L351; */ }
        if (!PackUtilSharedState.get().hasEntityCaptureCallback()) { /* goto L351; */ }
        targeted = class_310.method_1551().field_1692;
        if (targeted == null) { /* goto L351; */ }
        if (targeted == class_310.method_1551().field_1724) { /* goto L351; */ }
        state = PackUtilSharedState.get();
        if (state.isEntityCaptureSpecific()) {
            uuid = targeted.method_5845();
            typeId = class_7923.field_41177.method_10221(targeted.method_5864()).toString();
            dispName = targeted.method_5476().getString().replaceAll("§.", "").trim();
            payload = "~" + uuid + "~" + typeId + "~" + dispName;
            state.setEntityCaptureSpecific(false);
        } else {
            payload = class_7923.field_41177.method_10221(targeted.method_5864()).toString();
        }
        state.consumeEntityCaptureCallback(payload);
        L351: ;
        if (!this.isPackUtilActive()) {
            return;
        }
        if (!this.isPlayConnectionActive()) {
            return;
        }
        shared = PackUtilSharedState.get();
        ci.cancel();
        if (packet instanceof class_2815 && shared.consumeSuppressNextClosePacket()) {
            return;
        }
        if (packet instanceof class_2815) {
            closePacket = (class_2815)packet;
            if (this.packutil$shouldKeepXCarryOpen(shared, closePacket)) {
                ci.cancel();
                return;
            }
        }
        if (shared.isGBreakCapturing()) {
            if (packet instanceof class_2846) {
                shared.onGBreakPacket(packet);
            }
            return;
        }
        if (PackUtilModule.get().handlePacketSend(packet)) {
            ci.cancel();
            return;
        }
        anyFeatureActive = shared.shouldDelayGuiPackets() || !shared.shouldSendGuiPackets() || shared.shouldUseCustomPackets();
        if (!anyFeatureActive) {
            return;
        }
        if (shared.isFlushing()) {
            return;
        }
        shared.setAllowSignEditing(true);
        if (packet instanceof class_2877 && !shared.shouldEditSigns()) {
            ci.cancel();
            return;
        }
        shared.setAllowBookUpdate(true);
        if (packet instanceof class_2820 && !shared.shouldUpdateBook()) {
            ci.cancel();
            return;
        }
        shouldHandle = false;
        if (shared.shouldUseCustomPackets()) {
            shouldHandle = shared.getC2SPackets().contains(packet.getClass());
        } else {
            shouldHandle = this.isGuiPacket(packet);
        }
        if (!shouldHandle) {
            return;
        }
        YungLightAddon.LOG.debug("[PackUtil] Packet detected: {} | Send={} Delay={} | Custom={}", packet.getClass().getSimpleName(), shared.shouldSendGuiPackets(), shared.shouldDelayGuiPackets(), shared.shouldUseCustomPackets());
        if (!shared.shouldSendGuiPackets()) {
            YungLightAddon.LOG.debug("[PackUtil] CANCELLED packet (send disabled)");
            ci.cancel();
            return;
        }
        if (shared.shouldDelayGuiPackets()) {
            YungLightAddon.LOG.debug("[PackUtil] QUEUED packet (delay enabled)");
            shared.enqueuePacket(packet);
            ci.cancel();
        }
    }

    @Inject(method={"method_10752(Lnet/minecraft/class_2596;Lio/netty/channel/ChannelFutureListener;)V"}, at={@At(value="TAIL")})
    private void yang$afterSendPacket(class_2596<?> packet, ChannelFutureListener listener, CallbackInfo ci) {
        if (!this.isPackUtilActive()) {
            return;
        }
        if (!this.isPlayConnectionActive()) {
            return;
        }
        MacroExecutor.onPacketSent(packet);
    }

    @Unique
    private boolean isGuiPacket(class_2596<?> packet) {
        return packet instanceof class_2813 || packet instanceof class_2811 || packet instanceof class_2873 || packet instanceof class_2846 || packet instanceof class_2886;
    }

    @Inject(method={"method_10759"}, at={@At(value="HEAD")}, cancellable=true)
    private static void yang$onReceivePacket(class_2596<?> packet, class_2547 listener, CallbackInfo ci) {
        ServerTickTracker.onS2CPacket(packet);
        PackUtilModule module = PackUtilModule.get();
        if (module == null || !module.isActive()) {
            return;
        }
        if (!PackUtilClientConnectionMixin.isPlayReceiveListener(listener)) {
            return;
        }
        MacroExecutor.onPacketReceived(packet);
        if (module.handlePacketReceive(packet)) {
            ci.cancel();
            return;
        }
        PackUtilSharedState shared = PackUtilSharedState.get();
        boolean anyFeatureActive = shared.shouldDelayGuiPackets() || !shared.shouldSendGuiPackets() || shared.shouldUseCustomPackets();
        if (!anyFeatureActive) {
            return;
        }
        boolean shouldHandle = false;
        if (shared.shouldUseCustomPackets()) {
            shouldHandle = shared.getS2CPackets().contains(packet.getClass());
        }
        if (!shouldHandle) {
            return;
        }
        YungLightAddon.LOG.debug("[PackUtil] S2C Packet detected: {} | Send={} Delay={}", packet.getClass().getSimpleName(), shared.shouldSendGuiPackets(), shared.shouldDelayGuiPackets());
        if (!shared.shouldSendGuiPackets()) {
            ci.cancel();
            return;
        }
        if (shared.shouldDelayGuiPackets()) {
            shared.enqueuePacket(packet);
            ci.cancel();
        }
    }

    @Unique
    private boolean isPackUtilActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }

    @Unique
    private boolean isPlayConnectionActive() {
        class_310 client = class_310.method_1551();
        return client != null && client.method_1562() != null;
    }

    @Unique
    private static boolean isPlayReceiveListener(class_2547 listener) {
        return listener instanceof class_2602;
    }

    @Unique
    private boolean packutil$shouldKeepXCarryOpen(PackUtilSharedState shared, class_2815 packet) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || !shared.isXCarryActive()) {
            return false;
        }
        PackUtilModule module = PackUtilModule.get();
        boolean allowPassiveXCarry = module != null && module.isXCarryEnabled();
        if (!allowPassiveXCarry && !shared.isXCarryForced()) {
            return false;
        }
        if (packet.method_36168() != client.field_1724.field_7498.field_7763) {
            return false;
        }
        boolean hasItems = false;
        int slotId = 1;
        while (slotId <= 4) {
            if (slotId >= client.field_1724.field_7498.field_7761.size()) break;
            if (!((class_1735)client.field_1724.field_7498.field_7761.get(slotId)).method_7677().method_7960()) {
                hasItems = true;
            } else {
                slotId++;
            }
        }
        shared.setXCarryActive(hasItems);
        shared.setXCarryForced(hasItems && shared.isXCarryForced());
        return hasItems;
    }
}
