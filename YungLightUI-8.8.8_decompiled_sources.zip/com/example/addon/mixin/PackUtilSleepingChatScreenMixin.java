/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilSleepingChatScreenMixin
extends class_437 {
    protected PackUtilSleepingChatScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"method_25426()V"}, at={@At(value="TAIL")})
    private void packutil$init(CallbackInfo ci) {
        PackUtilModule module = PackUtilModule.get();
        if (module == null || !module.isActive()) {
            return;
        }
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Client wake up"), this::lambda$packutil$init$0).method_46434(5, 5, 140, 20).method_46431());
    }
}
