/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.PackUtilModule;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilMultiplayerScreenMixin
extends class_437 {
    protected PackUtilMultiplayerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"method_25426()V"}, at={@At(value="TAIL")})
    private void packutil$init(CallbackInfo ci) {
        PackUtilModule module = PackUtilModule.get();
        if (module == null || !module.isActive()) {
            return;
        }
        int buttonWidth = 160;
        int x = 10;
        int bypassY = this.field_22790 - 55;
        int forceDenyY = this.field_22790 - 30;
        this.method_37063(class_4185.method_46430(class_2561.method_43470(PackUtilMultiplayerScreenMixin.packutil$bypassLabel(module)), PackUtilMultiplayerScreenMixin::lambda$packutil$init$0 /* captured: module */).method_46434(x, bypassY, buttonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470(PackUtilMultiplayerScreenMixin.packutil$forceDenyLabel(module)), PackUtilMultiplayerScreenMixin::lambda$packutil$init$1 /* captured: module */).method_46434(x, forceDenyY, buttonWidth, 20).method_46431());
    }

    private static String packutil$bypassLabel(PackUtilModule module) {
        return "Bypass Resource Pack: " + module.isBypassResourcePack() ? "ON" : "OFF";
    }

    private static String packutil$forceDenyLabel(PackUtilModule module) {
        return "Force Deny: " + module.isForceDenyResourcePack() ? "ON" : "OFF";
    }
}
