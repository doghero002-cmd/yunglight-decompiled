/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.gui.packui.PackUiOverlayButton;
import com.example.addon.gui.packui.PackUiScreenButton;
import com.example.addon.mixin.accessor.PackUtilScreenAccessor;
import com.example.addon.modules.PackUtilModule;
import com.example.addon.util.PackUtilOverlayManager;
import com.example.addon.util.PackUtilPacketLoggerOverlay;
import com.example.addon.util.PackUtilQueueEditorOverlay;
import com.example.addon.util.PackUtilSharedState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3935;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class PackUtilScreenMixin {
    protected class_310 field_22787;
    public int field_22789;
    public int field_22790;
    private static final class_310 MC = class_310.method_1551();
    private boolean packutil$lecternInitialized;
    private PackUtilQueueEditorOverlay packutil$queueEditorOverlay;
    private PackUtilPacketLoggerOverlay packutil$packetLoggerOverlay;
    private final List<PackUiScreenButton> packutil$screenButtons;

    public PackUtilScreenMixin() {
        this.packutil$screenButtons = new ArrayList();
    }

    @Inject(method={"method_25426()V"}, at={@At(value="TAIL")})
    private void packutil$onInit(CallbackInfo ci) {
        class_437 screen = (class_437)this;
        if (!screen instanceof class_3935 || !this.packutil$isModuleActive()) {
            return;
        }
        if (this.packutil$lecternInitialized) {
            if (this.packutil$queueEditorOverlay != null) {
                this.packutil$queueEditorOverlay.restoreState();
            }
            if (this.packutil$queueEditorOverlay != null) {
                PackUtilOverlayManager.get().register(this.packutil$queueEditorOverlay);
            }
            if (this.packutil$packetLoggerOverlay != null) {
                PackUtilOverlayManager.get().register(this.packutil$packetLoggerOverlay);
            }
            return;
        }
        class_327 textRenderer = ((PackUtilScreenAccessor)this).getTextRenderer();
        this.packutil$queueEditorOverlay = new PackUtilQueueEditorOverlay(textRenderer);
        this.packutil$queueEditorOverlay.restoreState();
        PackUtilOverlayManager.get().register(this.packutil$queueEditorOverlay);
        PackUtilModule module = PackUtilModule.get();
        if (module != null) {
            this.packutil$packetLoggerOverlay = module.getPacketLoggerOverlay();
            if (this.packutil$packetLoggerOverlay != null) {
                PackUtilOverlayManager.get().register(this.packutil$packetLoggerOverlay);
            }
        }
        this.packutil$lecternInitialized = true;
    }

    @Inject(method={"method_25394"}, at={@At(value="TAIL")})
    private void packutil$render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!this.packutil$isModuleActive()) {
            return;
        }
        class_437 screen = (class_437)this;
        class_327 textRenderer = ((PackUtilScreenAccessor)this).getTextRenderer();
        if (textRenderer == null) {
            return;
        }
        if (!screen instanceof class_3935 || MC.field_1724 == null) {
            return;
        }
        class_1703 handler = MC.field_1724.field_7512;
        if (handler == null) { /* goto L111; */ }
        var var9 = this.packutil$buildLecternButtons().iterator();
        while (var9.hasNext()) {
            PackUiScreenButton button = (PackUiScreenButton)var9.next();
            button.render(context, textRenderer, mouseX, mouseY);
        }
    }

    @Inject(method={"method_25419"}, at={@At(value="HEAD")})
    private void packutil$onClose(CallbackInfo ci) {
        class_437 screen = (class_437)this;
        if (screen instanceof class_3935) {
            PackUtilOverlayManager.get().unregister(this.packutil$queueEditorOverlay);
            PackUtilOverlayManager.get().unregister(this.packutil$packetLoggerOverlay);
        }
    }

    @Unique
    private boolean packutil$isModuleActive() {
        PackUtilModule module = PackUtilModule.get();
        return module != null && module.isActive();
    }

    @Unique
    private List<PackUiScreenButton> packutil$buildLecternButtons() {
        this.packutil$screenButtons.clear();
        PackUtilSharedState shared = PackUtilSharedState.get();
        int baseX = 5;
        int baseY = 5;
        int defaultWidth = 140;
        int defaultHeight = 20;
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY, defaultWidth, defaultHeight, class_2561.method_43470("Close without packet"), PackUiOverlayButton.Variant.SECONDARY, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$0));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY + 24, defaultWidth, defaultHeight, class_2561.method_43470("De-sync"), PackUiOverlayButton.Variant.DANGER, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$1));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY + 48, defaultWidth, defaultHeight, class_2561.method_43470("Send packets: " + PackUtilScreenMixin.packutil$onOff(shared.shouldSendGuiPackets())), shared.shouldSendGuiPackets() ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$2 /* captured: shared */));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY + 72, defaultWidth, defaultHeight, class_2561.method_43470("Delay packets: " + PackUtilScreenMixin.packutil$onOff(shared.shouldDelayGuiPackets())), shared.shouldDelayGuiPackets() ? PackUiOverlayButton.Variant.SUCCESS : PackUiOverlayButton.Variant.DANGER, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$3 /* captured: shared */));
        int thirdWidth = (defaultWidth - 10) / 3;
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY + 96, thirdWidth, defaultHeight, class_2561.method_43470("Clear Q"), PackUiOverlayButton.Variant.DANGER, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$4));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX + thirdWidth + 5, baseY + 96, thirdWidth, defaultHeight, class_2561.method_43470("Q Editor"), PackUiOverlayButton.Variant.SECONDARY, this::lambda$packutil$buildLecternButtons$5));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX + thirdWidth * 2 + 10, baseY + 96, thirdWidth, defaultHeight, class_2561.method_43470("Pkt Log"), PackUiOverlayButton.Variant.SECONDARY, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$6));
        int halfWidth = (defaultWidth - 5) / 2;
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY + 120, halfWidth, defaultHeight, class_2561.method_43470("Save GUI"), PackUiOverlayButton.Variant.SECONDARY, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$7 /* captured: shared */));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX + halfWidth + 5, baseY + 120, halfWidth, defaultHeight, class_2561.method_43470("Load GUI"), PackUiOverlayButton.Variant.SECONDARY, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$9 /* captured: shared */));
        this.packutil$screenButtons.add(new PackUiScreenButton(baseX, baseY + 144, defaultWidth + 45, defaultHeight, class_2561.method_43470("Disconnect and send packets"), PackUiOverlayButton.Variant.DANGER, PackUtilScreenMixin::lambda$packutil$buildLecternButtons$10 /* captured: shared */));
        return this.packutil$screenButtons;
    }

    @Unique
    private static String packutil$onOff(boolean value) {
        return value ? "ON" : "OFF";
    }

    @Unique
    private static String packutil$stateText(boolean value) {
        return value ? "enabled" : "disabled";
    }
}
