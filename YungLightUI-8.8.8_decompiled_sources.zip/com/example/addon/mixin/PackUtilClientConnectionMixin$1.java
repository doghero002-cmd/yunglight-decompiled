/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2824;

class PackUtilClientConnectionMixin.1
implements class_2824.class_5908 {
    final /* synthetic */ class_1268[] val$capturedHand;
    final /* synthetic */ class_243[] val$capturedHitPos;
    final /* synthetic */ boolean[] val$isAttack;

    PackUtilClientConnectionMixin.1() {
        this.val$capturedHand = capturedHand;
        this.val$capturedHitPos = capturedHitPos;
        this.val$isAttack = isAttack;
    }

    public void method_34219(class_1268 hand) {
        this.val$capturedHand[0] = hand;
    }

    public void method_34220(class_1268 hand, class_243 pos) {
        this.val$capturedHand[0] = hand;
        this.val$capturedHitPos[0] = pos;
    }

    public void method_34218() {
        this.val$isAttack[0] = 1;
    }
}
