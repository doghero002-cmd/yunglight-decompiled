/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin.accessor;

import io.netty.channel.Channel;
import org.spongepowered.asm.mixin.gen.Accessor;

public interface PackUtilClientConnectionAccessor {
    @Accessor(value="field_11651")
    public Channel getChannel();
}
