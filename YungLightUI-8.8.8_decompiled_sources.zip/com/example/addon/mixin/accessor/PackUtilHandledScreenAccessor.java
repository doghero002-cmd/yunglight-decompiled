/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin.accessor;

import net.minecraft.class_1735;
import org.spongepowered.asm.mixin.gen.Accessor;

public interface PackUtilHandledScreenAccessor {
    @Accessor(value="field_2787")
    public class_1735 getFocusedSlot();
}
