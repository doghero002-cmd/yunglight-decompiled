/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin.accessor;

import net.minecraft.class_327;
import org.spongepowered.asm.mixin.gen.Accessor;

public interface PackUtilScreenAccessor {
    @Accessor(value="field_22793")
    public class_327 getTextRenderer();
}
