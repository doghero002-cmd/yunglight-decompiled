/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.mixininterface.PackUtilGameRendererAccess;
import net.minecraft.class_11228;
import net.minecraft.class_758;

public abstract class PackUtilGameRendererMixin
implements PackUtilGameRendererAccess {
    private class_11228 field_59965;
    private class_758 field_60793;

    public void packutil$flushGuiState() {
        this.field_59965.method_70890(this.field_60793.method_71109(class_758.class_4596.field_60101));
        this.field_59965.method_70879();
    }
}
