/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.nbt;

import java.util.List;
import net.minecraft.class_2520;
import net.minecraft.class_2561;

public interface NbtTagParser {
    public void parseTagToList(List<class_2561> var1, class_2520 var2, boolean var3);
}
