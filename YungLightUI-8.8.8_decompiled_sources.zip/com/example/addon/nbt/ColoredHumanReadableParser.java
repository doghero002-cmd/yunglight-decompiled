/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.nbt;

import com.example.addon.nbt.NbtTagParser;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;

public class ColoredHumanReadableParser
implements NbtTagParser {
    private static final int LINE_SPLIT_THRESHOLD = 30;
    private static final class_124 LIST_INDEX = class_124.field_1060;
    private static final class_124 STRING = class_124.field_1076;
    private static final class_124 STRUCTURE = class_124.field_1080;
    private static final class_124 TAG_NAME = class_124.field_1065;

    public void parseTagToList(List<class_2561> tooltip, class_2520 tag, boolean splitLines) {
        if (tag == null) {
            tooltip.add(class_2561.method_43470("No NBT tag").method_27692(class_124.field_1063));
        } else {
            this.unwrapTag(tooltip, tag, "", "", "  ", splitLines);
        }
    }

    private void unwrapTag(List<class_2561> tooltip, class_2520 base, String pad, String tagName, String padIncrement, boolean splitLongStrings) {
        if (base instanceof class_2487) {
            class_2487 compound = (class_2487)base;
            this.addCompoundToTooltip(tooltip, compound, pad, padIncrement, splitLongStrings);
        } else {
            if (base instanceof class_2499) {
                class_2499 list = (class_2499)base;
                this.addListToTooltip(tooltip, list, pad, padIncrement, splitLongStrings);
            } else {
                this.addValueToTooltip(tooltip, base, class_2561.method_43470(tagName).method_27692(TAG_NAME), pad, splitLongStrings);
            }
        }
    }

    private void addCompoundToTooltip(List<class_2561> tooltip, class_2487 tag, String pad, String padIncrement, boolean splitLongStrings) {
        var var6 = tag.method_10541().iterator();
        while (var6.hasNext()) {
            String key = (String)var6.next();
            class_2520 value = tag.method_10580(key);
            while (value == null) {
            }
            boolean nested = value instanceof class_2499 || value instanceof class_2487;
            if (nested) {
                class_2561 subtreeName = class_2561.method_43470(key).method_27692(TAG_NAME);
                class_2561 intro = class_2561.method_43470(pad).method_10852(subtreeName).method_10852(class_2561.method_43470(": {").method_27692(STRUCTURE));
                tooltip.add(intro);
                this.unwrapTag(tooltip, value, pad + padIncrement, key, padIncrement, splitLongStrings);
                tooltip.add(class_2561.method_43470(pad + "}").method_27692(STRUCTURE));
            } else {
                this.addValueToTooltip(tooltip, value, class_2561.method_43470(key).method_27692(TAG_NAME), pad, splitLongStrings);
            }
        }
    }

    private void addListToTooltip(List<class_2561> tooltip, class_2499 list, String pad, String padIncrement, boolean splitLongStrings) {
        for (int index = 0; index < list.size(); index++) {
            class_2520 element = (class_2520)list.get(index);
            class_2561 bracketedIndex = class_2561.method_43470("[").method_27692(STRUCTURE).method_10852(class_2561.method_43470(String.valueOf(index)).method_27692(LIST_INDEX)).method_10852(class_2561.method_43470("]").method_27692(STRUCTURE));
            if (element instanceof class_2499 || element instanceof class_2487) {
                tooltip.add(class_2561.method_43470(pad + " ").method_10852(bracketedIndex).method_10852(class_2561.method_43470(": {").method_27692(STRUCTURE)));
                this.unwrapTag(tooltip, element, pad + padIncrement, "", padIncrement, splitLongStrings);
                tooltip.add(class_2561.method_43470(pad + "}").method_27692(STRUCTURE));
            } else {
                this.addValueToTooltip(tooltip, element, bracketedIndex, pad, splitLongStrings);
            }
        }
    }

    private void addValueToTooltip(List<class_2561> tooltip, class_2520 nbt, class_2561 name, String pad, boolean splitLongStrings) {
        String content = nbt.toString();
        if (!splitLongStrings || content.length() < 30) {
            tooltip.add(class_2561.method_43470(pad).method_10852(name).method_10852(class_2561.method_43470(": ")).method_10852(class_2561.method_43470(content).method_27692(STRING)));
        } else {
            tooltip.add(class_2561.method_43470(pad).method_10852(name).method_10852(class_2561.method_43470(":")));
            int index = 0;
            while (index < content.length()) {
                int nextLength = Math.min(30, content.length() - index);
                String chunk = content.substring(index, index + nextLength);
                tooltip.add(class_2561.method_43470(pad + "   |").method_27692(class_124.field_1075).method_10852(class_2561.method_43470(" " + chunk).method_27692(STRING)));
                index = index + nextLength;
            }
        }
    }
}
