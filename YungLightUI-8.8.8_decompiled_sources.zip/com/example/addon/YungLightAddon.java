/*
 * Decompiled with https://jar.tools
 */
package com.example.addon;

import com.mojang.logging.LogUtils;
import java.io.File;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

public final class YungLightAddon {
    public static final Logger LOG = LogUtils.getLogger();
    public static final String MOD_ID = "packutil";
    public static final File FOLDER = FabricLoader.getInstance().getConfigDir().resolve("packutil").toFile();

    private YungLightAddon() {
    }

    static {
        FOLDER.mkdirs();
    }
}
