# Decompile Summary

**JAR:** YungLightUI-8.8.8.jar  
**Size:** 2907364 bytes  
**SHA-256:** 3553371f839192074b287e9064ed5e1be7022663671d5ccde8d440391481e5c9  
**Processing time:** 1268 ms  

## Statistics

| | Count |
|---|---|
| Total classes | 398 |
| Decompiled (clean) | 394 |
| Decompiled (with warnings) | 4 |
| Failed to parse | 0 |
| Resource files | 44 |

## Resource Files

- `META-INF/MANIFEST.MF`
- `LICENSE_YungLightUI`
- `assets/yunglight/font/bebas_neue.json`
- `assets/yunglight/font/bebas_neue/bebasneue-regular.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_18pt_extrabold.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_18pt_regular.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_24pt_extrabold.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_24pt_regular.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_36pt_extrabold.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_36pt_regular.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_extrabold.ttf`
- `assets/yunglight/font/dm_sans/dm_sans_regular.ttf`
- `assets/yunglight/font/dm_sans/pack_ui_regular.ttf`
- `assets/yunglight/font/pack_ui_body.json`
- `assets/yunglight/font/pack_ui_fallback.json`
- `assets/yunglight/font/pack_ui_label.json`
- `assets/yunglight/font/pack_ui_title.json`
- `assets/yunglight/icon.png`
- `assets/yunglight/shaders/text.frag`
- `assets/yunglight/shaders/text.vert`
- `assets/yunglight/textures/gui/packui/icons/chatcategory.png`
- `assets/yunglight/textures/gui/packui/icons/fabricator.png`
- `assets/yunglight/textures/gui/packui/icons/filter.png`
- `assets/yunglight/textures/gui/packui/icons/keybinds.png`
- `assets/yunglight/textures/gui/packui/icons/lansync.png`
- `assets/yunglight/textures/gui/packui/icons/listselected.png`
- `assets/yunglight/textures/gui/packui/icons/macros.png`
- `assets/yunglight/textures/gui/packui/icons/mainmenucategory.png`
- `assets/yunglight/textures/gui/packui/icons/packetcategory.png`
- `assets/yunglight/textures/gui/packui/icons/packetlogger.png`
- `assets/yunglight/textures/gui/packui/icons/packetqeditor.png`
- `assets/yunglight/textures/gui/packui/icons/screencategory.png`
- `assets/yunglight/textures/gui/packui/icons/serverinfo.png`
- `assets/yunglight/textures/gui/packui/icons/windowchevrondown.png`
- `assets/yunglight/textures/gui/packui/icons/windowchevronright.png`
- `assets/yunglight/textures/gui/packui/icons/windowchevronup.png`
- `assets/yunglight/textures/gui/packui/icons/windowclose.png`
- `assets/yunglight/textures/gui/packutil/button.png`
- `assets/yunglight/textures/gui/packutil/button.png.mcmeta`
- `assets/yunglight/textures/gui/packutil/button_disabled.png`
- `assets/yunglight/textures/gui/packutil/button_highlighted.png`
- `fabric.mod.json`
- `packutil-inspector-mappings.tsv`
- `packutil.mixins.json`

## Classes with Warnings

### com.example.addon.gui.macro.editor.ActionEditorOverlay

**Anomaly reasons:** decompile_fallback, stack_underflow  

**Fallback methods:**

- `private String resolveFieldPlaceholder(FieldDef field)` (1 fallback)

### com.example.addon.util.PackUtilPacketInspectOverlay

**Anomaly reasons:** decompile_fallback, stack_underflow  

**Fallback methods:**

- `public void render(class_332 context, int mouseX, int mouseY, float delta)` (1 fallback)

### com.example.addon.util.PackUtilPacketInspector

**Anomaly reasons:** decompile_fallback, stack_underflow  

**Fallback methods:**

- `<unknown>` (1 fallback)

### com.example.addon.util.macro.MacroExecutor

**Anomaly reasons:** decompile_fallback, stack_underflow, preflight_complexity_guard  

**Fallback methods:**

- `private static void run(PackUtilMacro macro)` (1 fallback)
- `private static void executeSingleActionWithWaits(class_310 mc, MacroAction action, PackUtilModule module) throws InterruptedException` (1 fallback)

